# -*- coding: utf-8 -*-
"""곡 · 판 — CCM 의 두 층 (2026-09-09 신설 · 영구 도구 · 멱등).

★★★ **세 층이 실측으로 증명됐다**(2026-09-09):

    곡(SONG)      ─ 원곡 사역자 · 원제 · 원곡 언어
      └ 판(REND)  ─ 언어 · 제목 · 그 판을 부른 사역자
          └ 영상  ─ 조회수 · 채널 · **판 갈래**(연속듣기·반주·악보…)

  · **곡이 있어야 하는 까닭** — 같은 원곡을 두 팀이 **다른 제목**으로 번안한다
    (`Always You, Jesus` → 「난 언제나 예수」 아가파오 · 「언제나 주만」 제이어스).
    `New Thing Coming` 의 한국어 제목은 **셋**이다. **제목으로는 못 묶는다.**
  · **판이 있어야 하는 까닭** — 「난 언제나 예수」와 「언제나 주만」은 **같은 곡의
    다른 판**이지 다른 곡이 아니다. 영상에서 바로 곡으로 가면 그 사실을 담을
    자리가 없다.
  · **영상이 따로인 까닭** — 한 판에 영상이 여럿이다(공식 음원 · 1시간 연속듣기 ·
    반주 · 악보 · 워십댄스). 사용자 확정 「**재가공을 제거하려고 하지 마라.
    잠들기 전에 2시간 연속듣기를 선호하는 사람들이 매우 많다**」.

★★ **곡↔구절 연결은 곡에 붙는다** — 「기억하네 (시편 77편)」은 **어느 판이든**
  시편 77편이다. 판마다 붙이면 같은 절에 같은 곡이 여섯 번 뜬다.

⚠ **판은 기계가 못 만든다** — 가사를 대조할 수 없다. `derive` 가 **후보를
  유도**하고(같은 곡·같은 언어·같은 사역자를 한 판으로) 사람이 고친다.

⚠ 이름은 다국어라 `sys_text_asset`(§0-3 규칙 1) — 곡 `SONG_TITLE` ·
  판 `SONG_REND_TITLE`. 표에는 조회로 가르는 값만.
"""
import json
import re
import sys

import appdb

DB = 'bible_master.db'
T_SONG = 'sys_song'
T_REND = 'sys_song_rendition'
NAME_SONG = 'SONG_TITLE'
NAME_REND = 'SONG_REND_TITLE'
LINK_MEDI = 'MEDI_REND'      # 영상 → 판
LINK_VERS = 'SONG_VERS'      # 곡 → 구절


#: ★ **원곡 — 실측으로 확인한 것만**(2026-09-09). `(곡 코드, 원곡 언어, 사역자 코드)`
#:   ⚠⚠ **짐작하지 않는다** — 유도기는 「영문 원제가 있으면 EN」으로 짐작하는데
#:     실측 `Always You Jesus` 의 원곡은 **한국(제이어스)** 이었다. 「- Topic」이
#:     알려 준 것과 눈으로 확인한 것만 여기 적고, 이 표가 짐작을 이긴다.
#:   ⚠ 확실치 않으면 **비워 둔다**(`My Redeemer Lives` 는 Nicole C. Mullen 과
#:     Hillsong 둘 다 나와 못 정했다).
SONG_ORIGIN = {
    'ALWAYS_YOU':     ('KO', 'JUS'),            # ★ 원곡이 한국 곡이다
    'CAME_HERE_FOR':  ('EN', 'HILLSONG'),
    'HOLY_FOREVER':   ('EN', 'CECE_WINANS'),
    'LIVING_HOPE':    ('EN', 'PHIL_WICKHAM'),
    'NEW_THING':      ('EN', 'ELEVATION'),
    'WAY_MAKER':      ('EN', 'SINACH'),         # ⚠ Leeland 는 커버다
    'GOODNESS_GOD':   ('EN', 'JENN_JOHNSON'),
    'GRAVES_GARDENS': ('EN', 'BRANDON_LAKE'),
    'HIGHEST_HONOUR': ('EN', 'CHRIS_BOWATER'),
    'ALL_HEAVEN':     ('EN', 'NOEL_RICHARDS'),
    'THE_CROSS':      ('ZHT', 'STREAMPRAISE'),
    'PATH_OF_GRACE':  ('ZHT', 'STREAMPRAISE'),
    'ENDLESS_LOVE':   ('ZHT', 'STREAMPRAISE'),
    'REDEEMER_LIVES': ('ZHT', 'STREAMPRAISE'),  # 讚美之泉 판(영문 원곡은 미확정)
    'GOD_REIGNS':     ('ZHT', None),
}


# ── 표 ──────────────────────────────────────────────────────────────────────

def ensure(conn):
    """두 표를 만든다(멱등)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            song_id        INTEGER PRIMARY KEY AUTOINCREMENT,
            song_code      TEXT UNIQUE NOT NULL,
            orig_lang      TEXT,
            orig_artist_id INTEGER,
            composer       TEXT,
            year           INTEGER,
            note           TEXT,
            record_status  TEXT DEFAULT 'LIVE'
        )""" % T_SONG)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            rend_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            song_id       INTEGER NOT NULL,
            lang_code     TEXT,
            title_key     TEXT,
            artist_id     INTEGER,
            is_original   INTEGER NOT NULL DEFAULT 0,
            is_official   INTEGER NOT NULL DEFAULT 0,
            note          TEXT,
            record_status TEXT DEFAULT 'LIVE'
        )""" % T_REND)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_song_rend_song"
                 " ON %s(song_id)" % T_REND)
    # ★★★ **판을 가르는 것은 사역자가 아니라 제목이다**(2026-09-09 실측).
    #   처음에 (곡·언어·사역자)를 열쇠로 했더니 **사역자를 모르는 영상 11편이
    #   한 판에 몰려 「난 언제나 예수」와 「언제나 주만」이 섞였다.**
    #   ⇒ 열쇠 = **(곡, 언어, 정규화한 제목)**. 사역자는 그 판을 **번안한 팀**
    #     이고 속성이다 — 같은 번안본을 여러 팀이 부르는 것이 정상이다
    #     (「우리 주 안에서 노래하며」를 일곱 팀이 부른다).
    # ⚠⚠ **칸을 먼저 만들고 인덱스를 건다** — 순서가 바뀌면 옛 DB 에서
    #   없는 칸을 참조해 터진다.
    cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % T_REND)]
    if 'title_key' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN title_key TEXT" % T_REND)
    # ★★★ **닻(anchor)** — 2026-09-11 사용자 설계.
    #   「원곡이라는 **증거가 있으면** 그 곡을 원곡으로 정한다 …
    #    증거가 없으면 **대표곡 값을 부여하고 원곡에 준해서 관리**한다.
    #    나중에 원곡이 밝혀지면 **교체하고 모든 연결값도 따라서 수정**한다」
    #   ⚠⚠ **확정과 잠정을 한 칸에 담지 않는다** — 그러면 「이 값이 사람이
    #     확인한 것인가 기계가 짐작한 것인가」를 영영 못 가른다. 그 물음이
    #     곧 **다시 계산할 때 손대도 되는가**를 정한다.
    _sc = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % T_SONG)]
    for _c, _t in (('anchor_rend_id', 'INTEGER'),   # 닻이 되는 판
                   ('anchor_kind', 'TEXT'),         # 'ORIG'(확정) | 'REP'(잠정)
                   ('anchor_why', 'TEXT'),          # 근거 — **비면 확정이 아니다**
                   ('anchor_at', 'TEXT'),
                   # ★★★ **장르**(2026-09-12) — 「어느 전통·양식의 찬양인가」.
                   #   목록의 집은 `media_taxonomy.SONG_GENRES` 하나다
                   #   (여기 베끼지 않는다 — §241차 ① 「베낀 상수는 갈라진다」).
                   #   ⚠ 모르면 **비워 둔다** — 억지로 넣지 않는다.
                   ('genre', 'TEXT'),
                   # ★★★ 2026-09-25 · 1.txt 17번 3) — 사용자 「가사 입력할 수
                   #   있어야 한다 … **메모란을 추가해서 원곡의 배경설명**」 ·
                   #   「곡 이름이 2개인 경우도 많다. 일종의 **부제**」.
                   #   ⚠ `note` 와 가르는 까닭 — `note` 는 **소속·출처(증거)**
                   #     라 원곡 판정의 근거다. 배경설명을 거기 섞으면 증거가
                   #     흐려진다(화면도 그 칸을 「증거」라 부른다).
                   ('lyrics', 'TEXT'),     # 가사
                   ('memo', 'TEXT'),       # 배경설명
                   ('subtitle', 'TEXT')):  # 부제 — 「그의 생각 (하나님은 …)」
        if _c not in _sc:
            conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (T_SONG, _c, _t))
    # ⚠⚠ `CREATE UNIQUE INDEX IF NOT EXISTS` 는 **이미 있으면 정의를 안 바꾼다**
    #   — 옛 (곡·언어·사역자) 인덱스가 남아 재유도가 UNIQUE 로 터졌다(실측).
    #   ⇒ 지금 정의와 다르면 **갈아 끼운다**.
    _cur = conn.execute("SELECT sql FROM sqlite_master WHERE type='index'"
                        " AND name='ux_song_rend'").fetchone()
    if _cur and 'title_key' not in (_cur[0] or ''):
        conn.execute("DROP INDEX ux_song_rend")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_song_rend"
                 " ON %s(song_id, COALESCE(lang_code,''),"
                 " COALESCE(title_key,''))" % T_REND)
    return True


def title_key(name):
    """판 제목의 정규화 열쇠 — 공백·부호를 걷는다.

    ⚠ 실측 「우리 주 안에서 노래하며」와 「우리 주안에서 노래하며」가 같은 판이다.
    """
    s = (name or '').lower()
    s = re.sub(r"[\s\-–—_·,.'\"“”‘’!?()（）\[\]【】]+", "", s)
    return s


def add_song(conn, code, names=None, orig_lang=None, orig_artist_id=None,
             composer=None, year=None, note=None):
    """곡 하나 → song_id (멱등 — 코드가 열쇠). 빈 칸만 채운다."""
    ensure(conn)
    code = (code or '').strip().upper()
    if not code:
        return None
    row = conn.execute("SELECT song_id FROM %s WHERE song_code=?" % T_SONG,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
                       (code,)).fetchone()
    if row:
        sid = row[0]
        for col, val in (('orig_lang', orig_lang),
                         ('orig_artist_id', orig_artist_id),
                         ('composer', composer), ('year', year), ('note', note)):
            if val is not None:
                conn.execute("UPDATE %s SET %s=COALESCE(%s,?) WHERE song_id=?"
                             % (T_SONG, col, col), (val, sid))
    else:
        cur = conn.execute(
            "INSERT INTO %s(song_code, orig_lang, orig_artist_id, composer,"
            " year, note, record_status) VALUES(?,?,?,?,?,?,'LIVE')" % T_SONG,
            (code, orig_lang, orig_artist_id, composer, year, note))
        sid = cur.lastrowid
    _put_names(conn, NAME_SONG, sid, names)
    return sid


def add_rend(conn, song_id, lang, artist_id=None, names=None, title=None,
             is_original=False, is_official=False, note=None):
    """판 하나 → rend_id (멱등 — **(곡, 언어, 정규화 제목)**이 열쇠).

    ⚠ `title` 을 안 주면 `names` 의 그 언어 이름을 쓴다. 둘 다 없으면 판을
      가를 것이 없으므로 **사역자로 물러선다**(그래도 없으면 이름 없는 판 하나).
    """
    ensure(conn)
    if not song_id:
        return None
    lang = (lang or '').upper() or None
    tk = title_key(title or (names or {}).get(lang) or
                   (('A%d' % artist_id) if artist_id else ''))
    row = conn.execute(
        "SELECT rend_id FROM %s WHERE song_id=? AND COALESCE(lang_code,'')=?"
        " AND COALESCE(title_key,'')=?" % T_REND,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
        (song_id, lang or '', tk)).fetchone()
    if row:
        rid = row[0]
        if artist_id:
            conn.execute("UPDATE %s SET artist_id=COALESCE(artist_id,?)"
                         " WHERE rend_id=?" % T_REND, (artist_id, rid))
        if is_original:
            conn.execute("UPDATE %s SET is_original=1 WHERE rend_id=?" % T_REND, (rid,))
        if is_official:
            conn.execute("UPDATE %s SET is_official=1 WHERE rend_id=?" % T_REND, (rid,))
        if note:
            conn.execute("UPDATE %s SET note=COALESCE(note,?) WHERE rend_id=?"
                         % T_REND, (note, rid))
    else:
        cur = conn.execute(
            "INSERT INTO %s(song_id, lang_code, title_key, artist_id,"
            " is_original, is_official, note, record_status)"
            " VALUES(?,?,?,?,?,?,?,'LIVE')" % T_REND,
            (song_id, lang, tk, artist_id, 1 if is_original else 0,
             1 if is_official else 0, note))
        rid = cur.lastrowid
    _put_names(conn, NAME_REND, rid, names)
    return rid


def _put_names(conn, ttype, oid, names):
    for lang, nm in (names or {}).items():
        nm = (nm or '').strip()
        if not nm:
            continue
        lg = lang.upper()
        ex = conn.execute(
            "SELECT 1 FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
            " AND UPPER(lang_code)=?", (ttype, oid, lg)).fetchone()  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
        if ex:
            conn.execute("UPDATE sys_text_asset SET contents=? WHERE text_type=?"
                         " AND clicked_id=? AND UPPER(lang_code)=?",
                         (nm, ttype, oid, lg))
        else:
            conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type,"
                         " lang_code, contents, record_status)"
                         " VALUES(?,?,?,?,'LIVE')", (oid, ttype, lg, nm))


def names_of(conn, ttype, oid):
    return {r[0].upper(): r[1] for r in conn.execute(
        "SELECT lang_code, contents FROM sys_text_asset WHERE text_type=?"
        " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
        (ttype, oid))}


def label(conn, ttype, oid, lang='KO'):
    nm = names_of(conn, ttype, oid)
    for k in ((lang or 'KO').upper(), 'EN'):
        if nm.get(k):
            return nm[k]
    return sorted(nm.values())[0] if nm else ''


def display_title(conn, song_id, lang='KO', names=None, orig_lang=None):
    """화면에 보일 이름 — **「내 말 (원래 이름)」**.

    ★★★ 2026-09-11 사용자 — 「다국어 모드에서 공통적으로 **「거룩 영원히
      (Holy Forever)」** 라고 표준화 … 수집된 곡이름을 기초로 **원곡이름을
      결합**하는 방식을 적용하면 사용자에게 명확할 것 같다」.
    ⚠⚠⚠ **결합해서 저장하지 않는다**(사용자 확정 — 「결합저장하면 **나중에
      비교할 때 문제**가 되기 때문이다」). 정확히 그렇다 — 곡 이름은 그대로
      **연결 판정에 쓰인다**(`db_song_match.contains_exact`). 이름을
      「거룩 영원히 (Holy Forever)」 로 담아 버리면 제목 「거룩 영원히」인 영상이
      **그 이름을 안 품게 되어 연결이 통째로 끊긴다.**
      ⇒ **저장은 언어별로 따로 · 결합은 이 문이 그릴 때만.**
    ★ 규칙 셋:
      ⓐ 원곡 언어가 **내 언어와 같으면** 결합하지 않는다(같은 말을 두 번).
      ⓑ 원곡 언어 이름이 **없으면** 결합하지 않는다 — **지어내지 않는다**
        (실측 곡 208개 중 두 언어 이름이 다 있는 것은 **52개(25%)** 다).
      ⓒ 내 언어 이름이 없으면 있는 것 하나로 물러선다.
    ⚠ **「영어」가 아니라 「원곡 언어」다** — 영어 사용자에게는
      `Holy Forever` 하나, 한국어 사용자에게는 `거룩 영원히 (Holy Forever)`,
      그리고 한국 원곡이면 영어 사용자가 `Always You Jesus (언제나 주만)` 를 본다.
    """
    lg = (lang or 'KO').upper()
    nm = names_of(conn, NAME_SONG, song_id) if names is None else dict(names)
    if not nm:
        return ''
    if orig_lang is None:
        r = conn.execute("SELECT orig_lang FROM %s WHERE song_id=?"
                         # status-ok: 번호 하나로 원곡 언어만 읽는다 — 가린
                         #   곡의 이름도 화면이 보여야 할 때가 있다
                         % T_SONG, (song_id,)).fetchone()
        orig_lang = (r[0] or '') if r else ''
    ol = (orig_lang or '').upper()
    mine = nm.get(lg) or ''
    # ★ 곁이름 = **원곡 언어 이름** → 없으면 **영어** → 없으면 다른 언어가
    #   **딱 하나일 때만** 그것.
    #   ⚠⚠ 실측으로 고쳤다 — 찬송가는 `orig_lang` 을 **`KO` 로 담아** 두었는데
    #     영어 원제가 따로 있다(「구주를 생각만 해도」 / `Jesus, The Very
    #     Thought Of Thee`). 원곡 언어만 보면 **다리가 통째로 안 보인다.**
    #   ⚠ 「원곡」이라고 **말하지 않는다** — 괄호는 「그 곡의 다른 이름」이고,
    #     무엇이 원곡인지는 ③ 화면의 「확정?」 칸이 따로 말한다.
    # ⓐ **내 언어가 원곡 언어면 결합하지 않는다** — 영어 사용자에게
    #   `Holy Forever (거룩 영원히)` 는 잡음이다.
    if ol and ol == lg:
        return mine or (nm.get(ol) or sorted(nm.values())[0])
    other = ''
    for k in (ol, 'EN'):
        if k and k != lg and nm.get(k):
            other = nm[k]
            break
    if not other:
        rest = {k: v for k, v in nm.items() if k != lg and v and v != mine}
        if len(rest) == 1:
            other = list(rest.values())[0]
    if not mine:
        # ⓒ 내 말이 없으면 곁이름, 그것도 없으면 아무것이나
        return other or sorted(nm.values())[0]
    if not other or other == mine:
        return mine                      # ⓐ·ⓑ 결합할 것이 없다
    return '%s (%s)' % (mine, other)


# ══════════════════════════════════════════════════════════════════════
#  같은 곡인가 — **확실 / 추천 두 등급**(2026-09-11 사용자 설계)
# ══════════════════════════════════════════════════════════════════════
#: 사용자 확정 — 「**1)확실, 2)추천**으로 구분해서 등급화하자. **확실은
#:   자동연결**, **추천은 영상을 들어보고 사람이 판단**한다」.
#:   ★ `db_song_match` 의 `EXACT`/`MAYBE` 와 **같은 두 값**이다 — 판정의 결을
#:     둘로 쪼개지 않는다.
SAME_SURE = 'SURE'      #: 확실 — 자동으로 붙이거나 합친다
SAME_MAYBE = 'MAYBE'    #: 추천 — **사람이 들어 보고** 정한다

#: 별명 — 같은 곡의 **다른 이름**. 언어마다 여러 줄이 있을 수 있다.
#:   ⚠⚠ `SONG_TITLE` 은 `_put_names` 가 **언어마다 하나**로 못 박는다. 그런데
#:     현실은 「거룩 영원히」·「거룩 영원히 (Holy Forever)」·「거룩하신 주」처럼
#:     **한국어 이름만 셋**이다. 담을 자리가 없어 새 곡이 생겼다.
NAME_ALIAS = 'SONG_ALIAS'

#: 합친 자국 — 되돌릴 수 있게 **어느 곡에서 왔는지** 적는다.
MERGE_NOTE = 'SONG_MERGE'

#: ★★★ **찬송가 번호 체계가 둘이다**(2026-09-11 사용자 — 「한국은 찬송가
#:   **번호체계가 2가지**이다. 중간에 찬송가를 업그레이드 하면서 바뀌었다.
#:   **외국도 그럴 수 있다**」).
#:   ⚠⚠⚠ **번호만으로는 곡을 못 가른다** — 새찬송가 446장과 통일찬송가 446장은
#:     **다른 곡**이다. 그래서 코드에 **체계를 함께** 적는다(`HYMN_NEW_446`).
#:   ⚠ 우리가 캔 것은 전부 **최근 유튜브 설명문**이라 새찬송가(2006~)로 본다.
#:     ⏭ 통일찬송가 번호로 들어오는 날을 위해 **대응표가 필요하다** — 지금
#:       없으므로 **지어내지 않는다**. 그때는 별명·가사로 잇는다.
HYMNALS = {'NEW': '새찬송가', 'UNI': '통일찬송가'}
HYMN_DEFAULT = 'NEW'


def hymn_code(no, book=HYMN_DEFAULT):
    """찬송가 곡 코드 — **체계 + 번호**. 번호만으로는 못 가른다."""
    return 'HYMN_%s_%03d' % (str(book or HYMN_DEFAULT).upper(), int(no))


_RX_HYMN = re.compile(r'^HYMN_(?:([A-Z]+)_)?(\d{1,3})$')


def hymn_of(code):
    """곡 코드 → (체계, 번호) 또는 (None, None).

    ⚠ 옛 코드(`HYMN_446`)는 체계가 안 적혀 있다 — 기본값으로 읽는다.
    """
    m = _RX_HYMN.match((code or '').upper())
    if not m:
        return (None, None)
    return (m.group(1) or HYMN_DEFAULT, int(m.group(2)))


def aliases_of(conn, song_id):
    """그 곡의 별명 전부 → [(lang, 이름)]."""
    return [(r[0], r[1]) for r in conn.execute(
        "SELECT lang_code, contents FROM sys_text_asset"
        "  WHERE text_type=? AND clicked_id=?"
        "    AND COALESCE(record_status,'LIVE')='LIVE'", (NAME_ALIAS, song_id))]


def add_alias(conn, song_id, name, lang='KO'):
    """별명 하나를 더한다(멱등) → 새로 담았으면 True.

    ⚠ **정식 이름과 같으면 안 담는다** — 같은 말을 두 벌 두지 않는다.
    """
    nm = (name or '').strip()
    if not song_id or not nm:
        return False
    lg = (lang or 'KO').upper()
    if title_key(nm) in {title_key(v) for v in
                         names_of(conn, NAME_SONG, song_id).values()}:
        return False
    if title_key(nm) in {title_key(v) for _l, v in aliases_of(conn, song_id)}:
        return False
    conn.execute(
        "INSERT INTO sys_text_asset(text_type, clicked_id, lang_code,"
        " contents, record_status) VALUES(?,?,?,?,'LIVE')",
        (NAME_ALIAS, song_id, lg, nm))
    return True


def all_keys(conn, song_id):
    """그 곡을 가리키는 **모든 이름의 열쇠** — 정식·별명·판 이름."""
    out = {title_key(v) for v in names_of(conn, NAME_SONG, song_id).values()}
    out |= {title_key(v) for _l, v in aliases_of(conn, song_id)}
    for rid, in conn.execute(
            "SELECT rend_id FROM %s WHERE song_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'" % T_REND,
            (song_id,)):
        out |= {title_key(v) for v in names_of(conn, NAME_REND, rid).values()}
    return {k for k in out if k}


def _artists_of_song(conn, song_id):
    return {r[0] for r in conn.execute(
        "SELECT artist_id FROM %s WHERE song_id=? AND artist_id IS NOT NULL"
        "   AND COALESCE(record_status,'LIVE')='LIVE'" % T_REND, (song_id,))}


def same_song(conn, a_id, b_id):
    """두 곡이 같은가 → (등급 또는 None, 근거 목록).

    ★★★ **확실**(자동) — 찬송가가 **같은 체계 같은 번호** · 정식 이름이 정확히
      같다 · 작곡자와 연도가 둘 다 있고 같다.
    ★★ **추천**(사람이 들어 본다) — 이름이 포함 관계다 · 별명이 겹친다 ·
      사역자가 겹친다.
    ⚠⚠⚠ **음의 신호가 이긴다** — 작곡자가 **둘 다 있는데 다르면** 같은 곡이
      아니다. 찬송가가 **같은 체계에서 번호가 다르면** 같은 곡이 아니다.
      그 둘은 추천에도 안 올린다.
    ⚠⚠ **체계가 다르면 번호로 아무 말도 못 한다** — 새찬송가 446 과 통일찬송가
      446 은 다른 곡이고, 새 446 과 통일 어느 번호가 같은 곡인지는 **대응표가
      있어야** 안다. 없으므로 **판단하지 않는다**(이름으로 내려간다).
    ⚠⚠ **이름 포함 관계는 확실이 될 수 없다** — 실측 열 짝 가운데
      「거룩 영원히」⊂「거룩 영원히 Holy Forever」(같은 곡)와
      **「십자가」⊂「구주의 십자가 보혈로」(다른 곡)** 가 **섞여 있다.**
    """
    if not a_id or not b_id or a_id == b_id:
        return (None, [])
    ra = conn.execute("SELECT song_code, composer, year FROM %s"
                      # status-ok: 번호 하나로 읽는다 — 가린 곡도 코드·작곡자는
                      #   그대로이고, 살았나는 부르는 쪽이 이미 걸렀다
                      "  WHERE song_id=?" % T_SONG, (a_id,)).fetchone()
    rb = conn.execute("SELECT song_code, composer, year FROM %s"
                      # status-ok: 번호 하나로 읽는다(위와 같은 자리)
                      "  WHERE song_id=?" % T_SONG, (b_id,)).fetchone()
    if not ra or not rb:
        return (None, [])
    ba, ha = hymn_of(ra[0])
    bb, hb = hymn_of(rb[0])
    # ── 음의 신호 — 여기서 끝난다 ──────────────────────────────────
    if ha is not None and hb is not None and ba == bb and ha != hb:
        return (None, ['%s 번호가 다르다 (%d 대 %d)'
                       % (HYMNALS.get(ba, ba), ha, hb)])
    ca, cb = (ra[1] or '').strip(), (rb[1] or '').strip()
    if ca and cb and title_key(ca) != title_key(cb):
        return (None, ['작곡자가 다르다 (%s 대 %s)' % (ca, cb)])
    why = []
    # ── 확실 ──────────────────────────────────────────────────────
    if ha is not None and ba == bb and ha == hb:
        return (SAME_SURE, ['%s %d장으로 같다' % (HYMNALS.get(ba, ba), ha)])
    na = {title_key(v) for v in names_of(conn, NAME_SONG, a_id).values()}
    nb = {title_key(v) for v in names_of(conn, NAME_SONG, b_id).values()}
    hit = {k for k in (na & nb) if k}
    if hit:
        return (SAME_SURE, ['정식 이름이 같다 (%s)' % sorted(hit)[0][:24]])
    if ca and cb and title_key(ca) == title_key(cb):
        ya, yb = ra[2], rb[2]
        if ya and yb and int(ya) == int(yb):
            return (SAME_SURE, ['작곡자·연도가 같다 (%s %s)' % (ca, ya)])
        why.append('작곡자가 같다 (%s)' % ca)
    # ── 추천 ──────────────────────────────────────────────────────
    ka, kb = all_keys(conn, a_id), all_keys(conn, b_id)
    if ka & kb:
        why.append('이름·별명이 겹친다 (%s)' % sorted(ka & kb)[0][:24])
    else:
        done = False
        for x in ka:
            for y in kb:
                if len(x) >= 3 and len(y) >= 3 and x != y and (x in y or y in x):
                    why.append('이름이 포함 관계다 (%s / %s)'
                               % (x[:16], y[:16]))
                    done = True
                    break
            if done:
                break
    # ⚠⚠⚠ **사역자 겹침만으로는 추천이 안 된다** — 실측으로 잡았다. 한 사역팀이
    #   여러 곡을 부르므로(마커스워십·힐송) 그것만 보면 **거의 모든 짝**이
    #   걸린다(짝 31개 중 27개가 그것뿐이었다). **이름 신호가 하나라도 있을 때
    #   보강**으로만 쓴다.
    if why:
        aa = _artists_of_song(conn, a_id) & _artists_of_song(conn, b_id)
        if aa:
            why.append('같은 사역자가 부른다 (%d팀)' % len(aa))
    return (SAME_MAYBE, why) if why else (None, [])


#: 「아니라고 정했다」 — 다시 안 묻는다
NOT_SAME_KEY = 'SONG_NOT_SAME'


def _not_same_set(conn):
    import json as _j
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (NOT_SAME_KEY,)).fetchone()
        return {tuple(x) for x in _j.loads(r[0])} if r and r[0] else set()
    except Exception:
        return set()


def mark_not_same(conn, a_id, b_id):
    """**다른 곡이다**를 적어 둔다 — 그 짝을 다시 안 낸다.

    ⚠ 안 적으면 사람이 **같은 물음을 영원히 다시** 받는다(§5-17 「지운 추천」).
    """
    import json as _j
    k = (min(int(a_id), int(b_id)), max(int(a_id), int(b_id)))
    got = _not_same_set(conn)
    if k in got:
        return False
    got.add(k)
    conn.execute(
        "INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
        " ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
        (NOT_SAME_KEY, _j.dumps(sorted(got))))
    return True


#: 곡 이름이 **너무 넓다**고 볼 제목 걸림 수 — §⑤-23 ⓔ 에서 잰 값
NAME_MAX_HIT = 15


def name_risk(conn, name, song_id=None):
    """이 이름을 **곡 이름으로 써도 되나** → [(코드, 사람 말)].

    ★★★ 2026-09-11 사용자 「**십자가 영화가 섞인 것과 유사한 현상을 예방할
      방법을 분석하라**」. 실측으로 답한다 — 곡 31 「십자가」 하나에 **53편**이
      붙었고 진짜 그 곡은 **3편**이었다.
    잣대 셋(전부 실측으로 골랐다) —
      ⓐ **`TOPIC`** 그 이름이 **주제 용어**다. 주제는 「이 찬양이 무엇에 관한
        것인가」를 적은 말이라 곡 이름이 되면 그 주제의 영상을 통째로 먹는다.
        ✅ 실측 주제는 **둘뿐**(은혜·십자가)이라 과잉 검출이 없다.
      ⓑ **`TEAM`** 그 이름이 **채널·사역자 이름**이다. 실측 셋이 그랬다 —
        `F.I.A`·`agapao worship`·`anointing` 이 그 팀의 **모든 영상**을 한 곡으로
        끌어왔다(31편).
        ⚠ **혼자로는 못 쓴다** — 「恩典之路」는 채널 이름이면서 **진짜 곡**이다.
      ⓒ **`WIDE`** 제목 `NAME_MAX_HIT` 편 넘게 걸린다.
        ⚠⚠ **이것만으로는 못 가른다** — 실측 걸린 9곡이 **전부 정당했다**
          (`Living Hope` 31편이 다 그 곡이다). **가장 약한 신호**다.
    ⚠ **막지 않는다 — 알린다.** 판정은 사람이 한다(§⑤-11 「확실/추천」과 같은 결).
    """
    ensure(conn)
    nm = (name or '').strip()
    if len(nm) < 2:
        return [('SHORT', '한 글자 이름은 곡 이름으로 쓸 수 없습니다')]
    out = []
    try:
        import db_worship_topic as _TP
        tops = set()
        for _t in _TP.topics(conn):
            tops |= {x.strip() for x in _TP.names_of(conn, _t[0])}
        if nm in tops:
            out.append(('TOPIC', '「%s」 는 **주제 용어**입니다 — 곡 이름으로 쓰면 '
                                 '그 주제의 영상을 통째로 끌어옵니다' % nm))
    except Exception:
        pass
    try:
        import db_worship_artist as _WA
        low = nm.lower()
        hit = conn.execute(
            "SELECT 1 FROM sys_text_asset WHERE text_type=?"
            "   AND record_status='LIVE' AND LOWER(TRIM(contents))=? LIMIT 1",
            (_WA.NAME_TYPE, low)).fetchone()
        if not hit:
            hit = conn.execute(
                "SELECT 1 FROM sys_media_asset"
                # status-ok: 채널 이름이 있나만 보는 자리 — 가린 영상의 채널도
                #   같은 팀이라 빼면 신호를 잃는다
                " WHERE LOWER(TRIM(COALESCE("
                "   json_extract(description,'$.channel'),'')))=? LIMIT 1",
                (low,)).fetchone()
        if hit:
            out.append(('TEAM', '「%s」 는 **채널·사역자 이름**입니다 — 그 팀의 '
                                '모든 영상이 이 곡으로 딸려 올 수 있습니다' % nm))
    except Exception:
        pass
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_media_asset WHERE record_status='LIVE'"
        "   AND title LIKE ?", ('%' + nm + '%',)).fetchone()[0]
    if n > NAME_MAX_HIT:
        out.append(('WIDE', '제목 **%d편**에 걸립니다 — 진짜 곡은 보통 2~10편'
                            '입니다(다국어 인기곡이면 정상일 수 있습니다)' % n))
    return out


def find_same(conn, song_id=None, limit=200):
    """합칠 만한 짝 → [(등급, a, b, 근거)] — **확실이 먼저**."""
    ensure(conn)
    ids = [r[0] for r in conn.execute(
        "SELECT song_id FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'"
        % T_SONG)]
    no = _not_same_set(conn)
    out, seen = [], set()
    for a2 in ([song_id] if song_id else ids):
        for b2 in ids:
            if a2 == b2:
                continue
            k = (min(a2, b2), max(a2, b2))
            if k in seen or k in no:
                continue
            seen.add(k)
            g, why = same_song(conn, k[0], k[1])
            if g:
                out.append((g, k[0], k[1], why))
    out.sort(key=lambda x: (x[0] != SAME_SURE, x[1], x[2]))
    return out[:int(limit)]


def merge(conn, keep_id, drop_id, why=''):
    """두 곡을 하나로 → dict(옮긴 수).

    ★★★ 2026-09-11 사용자 — 「**같은 곡이었다면 어떻게 해야 하는가?** 만일
      「내사랑1」에도 **다른 rendition 이 연결**되어 있다면?」
    ⚠⚠⚠ **여섯 곳을 함께 옮긴다** — 이름(별명으로) · 판 · 영상 연결 ·
      곡-구절 · 작곡 정보 · 닻. 하나만 빠져도 그 곡의 재료가 반쪽이 된다.
    ⚠⚠ **판이 충돌하면 접는다** — 같은 제목 판이 양쪽에 있으면 **하나로 접고
      그 영상 연결을 옮긴다**(`title_key` 가 유일 열쇠라 그대로 옮기면 터진다).
    ⚠⚠ **양쪽 다 원곡(확정)이면 멈춘다** — 기계가 고를 수 없다.
    ⚠ **버리는 곡의 이름은 별명으로 남긴다** — 그래야 다음에 그 이름으로
      들어와도 새 곡이 안 생긴다.
    ⚠ **지우지 않고 가린다** — 되돌릴 자리를 남긴다(`note` 에 `SONG_MERGE:...`).
    """
    ensure(conn)
    keep_id, drop_id = int(keep_id), int(drop_id)
    if keep_id == drop_id:
        return {'why': ['같은 곡이다']}
    ak, ad = anchor_of(conn, keep_id), anchor_of(conn, drop_id)
    if ak.get('kind') == ANCHOR_ORIG and ad.get('kind') == ANCHOR_ORIG:
        return {'why': ['양쪽 다 원곡(확정)이라 기계가 못 선택합니다 - '
                        '한쪽을 [대표로 되돌리기] 한 뒤에 합치세요']}
    out = {'rend': 0, 'folded': 0, 'media': 0, 'verse': 0, 'alias': 0,
           'why': []}
    for lg, v in names_of(conn, NAME_SONG, drop_id).items():
        if add_alias(conn, keep_id, v, lg):
            out['alias'] += 1
    for lg, v in aliases_of(conn, drop_id):
        if add_alias(conn, keep_id, v, lg):
            out['alias'] += 1
    have = {}
    for rid, tk in conn.execute(
            "SELECT rend_id, COALESCE(title_key,'') FROM %s"
            "  WHERE song_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % T_REND, (keep_id,)):
        have[tk] = rid
    for rid, tk in conn.execute(
            "SELECT rend_id, COALESCE(title_key,'') FROM %s"
            # status-ok: **가려 둔 판까지 옮긴다** — 상태로 거르면 곡을
            #   합쳤는데 가린 판만 옛 곡에 남아 되살리는 날 주인이 없다
            "  WHERE song_id=?" % T_REND, (drop_id,)).fetchall():
        tgt = have.get(tk)
        if tgt:
            for lid, mid in conn.execute(
                    "SELECT sys_link_id, clicked_id FROM sys_link_asset"
                    # status-ok: **가려 둔 연결까지 옮긴다** — 사람이 뗀 연결도
                    #   그 곡의 기록이라 옛 판에 남겨 두면 주인이 없어진다
                    "  WHERE link_type=? AND target_id=?",
                    (LINK_MEDI, rid)).fetchall():
                ex = conn.execute(
                    "SELECT 1 FROM sys_link_asset WHERE link_type=?"
                    # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면
                    #   같은 짝이 한 벌 더 생긴다
                    "   AND clicked_id=? AND target_id=?",
                    (LINK_MEDI, mid, tgt)).fetchone()
                if ex:
                    conn.execute("DELETE FROM sys_link_asset"
                                 "  WHERE sys_link_id=?", (lid,))
                else:
                    conn.execute("UPDATE sys_link_asset SET target_id=?"
                                 "  WHERE sys_link_id=?", (tgt, lid))
                    out['media'] += 1
            conn.execute("UPDATE %s SET record_status='HIDE', note=?"
                         "  WHERE rend_id=?" % T_REND,
                         ('%s:%d' % (MERGE_NOTE, drop_id), rid))
            out['folded'] += 1
        else:
            conn.execute("UPDATE %s SET song_id=?, note=? WHERE rend_id=?"
                         % T_REND,
                         (keep_id, '%s:%d' % (MERGE_NOTE, drop_id), rid))
            have[tk] = rid
            out['rend'] += 1
    for lid, sv, ev in conn.execute(
            "SELECT sys_link_id, target_id, end_id FROM sys_link_asset"
            # status-ok: **가려 둔 곡-구절까지 옮긴다**(위와 같은 까닭)
            "  WHERE link_type=? AND clicked_id=?",
            (LINK_VERS, drop_id)).fetchall():
        ex = conn.execute(
            "SELECT 1 FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
            # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 한 벌 더 생긴다
            "   AND target_id=? AND COALESCE(end_id,-1)=COALESCE(?,-1)",
            (LINK_VERS, keep_id, sv, ev)).fetchone()
        if ex:
            conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?",
                         (lid,))
        else:
            conn.execute("UPDATE sys_link_asset SET clicked_id=?"
                         "  WHERE sys_link_id=?", (keep_id, lid))
            out['verse'] += 1
    dm = meta_of(conn, drop_id)
    set_meta(conn, keep_id, composer=dm.get('composer'), year=dm.get('year'))
    if ad.get('kind') == ANCHOR_ORIG and ak.get('kind') != ANCHOR_ORIG:
        rid2 = ad.get('rend_id')
        if rid2 and conn.execute(
                # status-ok: 그 판이 이 곡으로 옮겨 왔나만 본다 — 방금 옮긴
                #   줄이라 상태를 다시 물을 것이 없다
                "SELECT 1 FROM %s WHERE rend_id=? AND song_id=?" % T_REND,
                (rid2, keep_id)).fetchone():
            set_anchor(conn, keep_id, rid2, ANCHOR_ORIG,
                       ad.get('why') or '합치면서 옮김')
    conn.execute("UPDATE %s SET record_status='HIDE', note=? WHERE song_id=?"
                 % T_SONG,
                 ('%s:%d%s' % (MERGE_NOTE, keep_id,
                               (' - ' + why) if why else ''), drop_id))
    return out


# ── 연결 ────────────────────────────────────────────────────────────────────

def link_media(conn, media_id, rend_id):
    """영상 → 판 (멱등)."""
    if not media_id or not rend_id:
        return False
    try:
        ex = conn.execute(
            "SELECT COALESCE(record_status,'LIVE'), COALESCE(confidence,'')"
            "  FROM sys_link_asset"
            " WHERE link_type=? AND clicked_id=? AND target_id=?",  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
            (LINK_MEDI, media_id, rend_id)).fetchone()
    except Exception:
        _r = conn.execute(
            "SELECT COALESCE(record_status,'LIVE') FROM sys_link_asset"
            " WHERE link_type=? AND clicked_id=? AND target_id=?",  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
            (LINK_MEDI, media_id, rend_id)).fetchone()
        ex = (_r[0], '') if _r else None
    if ex:
        if ex[0] == 'HIDE' and ex[1] == 'MANUAL':
            return False        # ★ 사람이 뗀 가림은 **안 건드린다**
        conn.execute("UPDATE sys_link_asset SET record_status='LIVE' WHERE"
                     " link_type=? AND clicked_id=? AND target_id=?",
                     (LINK_MEDI, media_id, rend_id))
        return False
    conn.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                 " record_status) VALUES(?,?,?,'LIVE')", (LINK_MEDI, media_id, rend_id))
    # ★★★ **한 곡 안에서는 판 하나**(2026-09-11) — 안 걷으면 언어 판정이 바뀔
    #   때마다 같은 영상이 판마다 한 벌씩 쌓인다(실측 433편 중 194편이 그랬다).
    _s = conn.execute("SELECT song_id FROM %s WHERE rend_id=?" % T_REND,
                      (rend_id,)).fetchone()  # status-ok: 번호 하나로 읽는 줄 — 어느 곡의 판인지만 본다
    if _s:
        one_rend_only(conn, media_id, _s[0], rend_id)
    return True


def one_rend_only(conn, media_id, song_id, keep_rend):
    """한 영상은 **한 곡 안에서 판 하나**에만 붙는다 → 걷은 수.

    ⚠⚠⚠ 2026-09-11 실측 — 연결이 있는 영상 **433편 중 194편(45%)이 판 둘
      이상**에 걸려 있었다. 같은 곡의 KO·ZH·ZHT 판에 한 영상이 통째로 얹혀
      화면이 「판 셋」을 보이는데 안을 열면 **같은 영상 하나**였다.
    ★ 까닭은 언어 판정이 바뀐 역사다(§233차에 중국어 제목 139편이 EN 으로
      들어와 있었다) — 그때 만든 판이 그대로 남아 다음 유도가 새 판에 또 붙였다.
    ⚠ **지우지 않는다** — 사람이 되살릴 수 있게 가린다.
    """
    rows = conn.execute(
        "SELECT l.target_id FROM sys_link_asset l"
        # status-ok: 가린 판에 달린 겹침도 걷어야 한다 — 상태로 거르면
        #   걷은 판의 옛 연결이 살아남아 「한 영상 한 판」이 깨진다
        "  JOIN %s rd ON rd.rend_id=l.target_id"
        " WHERE l.link_type=? AND l.clicked_id=? AND rd.song_id=?"
        "   AND COALESCE(l.record_status,'LIVE') IN ('LIVE','PEND')"
        % T_REND, (LINK_MEDI, media_id, song_id)).fetchall()
    n = 0
    for (rid,) in rows:
        if rid == keep_rend:
            continue
        conn.execute("UPDATE sys_link_asset SET record_status='HIDE'"
                     " WHERE link_type=? AND clicked_id=? AND target_id=?",
                     (LINK_MEDI, media_id, rid))
        n += 1
    return n


def pick_one_rend(conn, media_id, rends):
    """여러 판 가운데 **어느 하나**를 선택한다 → rend_id.

    잣대 ⓐ 영상의 언어와 같은 판 ⓑ 곡의 닻이 가리키는 판 ⓒ 가장 먼저 만든 판.
    ⚠ **가릴 수 없으면 지어내지 않는다** — ⓒ 는 차례일 뿐이므로 되돌릴 수 있게
      가림으로만 처리한다(`one_rend_only`).
    """
    if not rends:
        return None
    mlg = (conn.execute("SELECT COALESCE(lang_code,'') FROM sys_media_asset"
                        " WHERE media_id=?", (media_id,)).fetchone()  # status-ok: 번호 하나로 읽는 줄 — 언어만 본다
           or ('',))[0].upper()
    same = [r for r in rends if (r[1] or '').upper() == mlg]
    if len(same) == 1:
        return same[0][0]
    if same:
        rends = same
    sid = conn.execute("SELECT song_id FROM %s WHERE rend_id=?" % T_REND,
                       (rends[0][0],)).fetchone()  # status-ok: 판 번호로 어느 곡인지만 읽는 줄

    if sid:
        an = conn.execute("SELECT anchor_rend_id FROM %s WHERE song_id=?"
                          % T_SONG, (sid[0],)).fetchone()  # status-ok: 곡 번호로 닻만 읽는 줄

        if an and an[0] and any(r[0] == an[0] for r in rends):
            return an[0]
    return sorted(rends)[0][0]


def dedupe_rends(conn, dry=False):
    """**한 영상 한 판** 으로 정리한다 → dict.

    ⚠ **곡이 둘 이상**인 영상은 안 건드린다 — 「어느 곡인가」는 사람이 정한다
      (실측 46편. 메들리·묶음이 여기 있다).
    """
    ensure(conn)
    rows = conn.execute(
        "SELECT l.clicked_id, rd.song_id, rd.rend_id, rd.lang_code"
        "  FROM sys_link_asset l JOIN %s rd ON rd.rend_id=l.target_id"
        "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE') IN ('LIVE','PEND')"
        "   AND a.record_status='LIVE' AND rd.record_status='LIVE'"
        % T_REND, (LINK_MEDI,)).fetchall()
    by = {}
    for mid, sid, rid, lg in rows:
        by.setdefault((mid, sid), []).append((rid, lg))
    out = {'media': 0, 'hid': 0, 'multi_song': 0}
    seen = {}
    for (mid, sid), v in by.items():
        seen.setdefault(mid, set()).add(sid)
    for (mid, sid), v in by.items():
        if len(seen.get(mid) or ()) > 1:
            out['multi_song'] += 1
            continue
        if len({x[0] for x in v}) < 2:
            continue
        keep = pick_one_rend(conn, mid, v)
        out['media'] += 1
        if not dry:
            out['hid'] += one_rend_only(conn, mid, sid, keep)
        else:
            out['hid'] += len({x[0] for x in v}) - 1
    if not dry:
        conn.commit()
    return out


def link_verse(conn, song_id, start_vid, end_vid=None):
    """**곡 → 구절** (멱등). ⚠ 판이 아니라 곡에 붙는다 — 어느 판이든 같은 절이다."""
    if not song_id or not start_vid:
        return False
    ex = conn.execute(
        "SELECT 1 FROM sys_link_asset WHERE link_type=? AND clicked_id=? AND target_id=?",  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
        (LINK_VERS, song_id, start_vid)).fetchone()
    if ex:
        return False
    conn.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                 " end_id, record_status) VALUES(?,?,?,?,'LIVE')",
                 (LINK_VERS, song_id, start_vid, end_vid))
    return True


# ── 조회 — 화면이 쓰는 문 ───────────────────────────────────────────────────

def songs(conn, lang='KO'):
    """[(song_id, 이름, 원곡언어, 원곡사역자, 판 수, 영상 수)] — 이름순."""
    ensure(conn)
    out = []
    for sid, ol, oa in conn.execute(
            "SELECT song_id, orig_lang, orig_artist_id FROM %s"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'" % T_SONG).fetchall():
        rends = [r[0] for r in conn.execute(
            "SELECT rend_id FROM %s WHERE song_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'" % T_REND, (sid,))]
        n_m = 0
        if rends:
            n_m = conn.execute(
                "SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l"
                " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
                " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
                "   AND m.is_active=1 AND m.record_status='LIVE'"
                " AND l.target_id IN (%s)" % ','.join('?' * len(rends)),
                (LINK_MEDI,) + tuple(rends)).fetchone()[0]
        oan = ''
        if oa:
            try:
                import db_worship_artist as WA
                oan = WA.label(conn, oa, lang)
            except Exception:
                oan = ''
        # ★ **보이는 이름은 결합 표기**(2026-09-11) — 저장은 그대로다
        out.append((sid, display_title(conn, sid, lang, orig_lang=ol), ol, oan,
                    len(rends), n_m))
    return sorted(out, key=lambda x: x[1])


# ══════════════════════════════════════════════════════════════════════
#  닻 — 원곡(확정) 또는 대표(잠정)
# ══════════════════════════════════════════════════════════════════════
#: 닻 갈래
ANCHOR_ORIG = 'ORIG'      # **증거가 있다** — 사람이 확인했다
ANCHOR_REP = 'REP'        # **증거가 없다** — 기계가 선택한 대표(잠정)

#: ⚠⚠ **대표 후보에서 빼는 갈래** — 「그 곡이 무엇인가」를 말하지 않는 것들.
#:   ⓐ 반주·악보는 **가사가 없다** ⓑ 묶음은 **곡이 하나가 아니다**
#:   ⓒ 연주커버·워십댄스는 **제목이 그 곡을 설명하지 않는다**.
#:   ★ 실측이 이 걸름막을 요구했다(2026-09-11) — 「그는 졸지 않고」의 조회수
#:     1등이 **MR(반주) 2,762회**였다. 전체 조회수가 작은 곡에서는 반주가 이긴다.
REP_SKIP_KINDS = ('INSTRUMENTAL', 'SHEET', 'PLAYLIST', 'COVER', 'DANCE')


def _media_rows(conn, song_id):
    """그 곡의 영상 → [(rend_id, media_id, 제목, 갈래, 조회수, 구독자, 주요?)]."""
    import json as _js
    out = []
    try:
        import db_media_linkcheck as _LC
        views = _LC.views_of(conn)
    except Exception:
        views = {}
    subs = {}
    try:
        for r in conn.execute("SELECT channel_ext_id, subs FROM sys_channel_stat"):
            subs[r[0]] = r[1]
    except Exception:
        pass
    feat = set()
    try:
        import db_worship_artist as _WA
        feat = set(_WA.featured(conn))
    except Exception:
        pass
    for rid, aid in conn.execute(
            "SELECT rend_id, artist_id FROM %s"
            " WHERE song_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % T_REND, (song_id,)).fetchall():
        for mid, ti, d in conn.execute(
                "SELECT m.media_id, m.title, COALESCE(m.description,'')"
                "  FROM sys_link_asset l"
                "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
                " WHERE l.link_type=? AND l.target_id=?"
                "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                "   AND m.record_status='LIVE'", (LINK_MEDI, rid)):
            ks, cid = [], ''
            if d.startswith('{'):
                try:
                    j = _js.loads(d)
                    ks = j.get('rend_kind') or []
                    cid = (j.get('channel_id') or '').strip()
                except Exception:
                    pass
            out.append((rid, mid, ti or '', ks,
                        (views.get(mid) or (None,))[0],
                        subs.get(cid), bool(aid and aid in feat)))
    return out


def pick_rep(conn, song_id):
    """**대표를 선택한다** → `(rend_id, media_id, 근거)` · 못 선택하면 `(None, None, 까닭)`.

    ★★★ 2026-09-11 사용자가 잣대를 정했다 — **주요 사역자 · 구독자 · 조회수**.
      차례는 이렇게 둔다:
        ⓐ 후보에서 **반주·악보·묶음·연주커버·워십댄스를 뺀다**(`REP_SKIP_KINDS`)
        ⓑ **주요 사역자**의 판이 먼저(사람이 정한 값이라 가장 믿을 만하다)
        ⓒ 그다음 **조회수**
        ⓓ 조회수가 **박빙(1.3배 안)** 이면 **구독자**로 가른다
    ⚠⚠ **조회수만으로 뽑으면 안 된다**(실측) — 20곡 중 6곡이 2등과 2배 이내라
      조회수가 자라면 대표가 **소리 없이 뒤집힌다.** 주요 사역자를 앞에 두면
      그 흔들림이 준다.
    ⚠ **조회수를 모르는 영상은 후보에서 빠진다** — 새로 담은 영상은 링크 점검이
      한 바퀴 돌아야 값이 생긴다. **조용히 넘어가지 말고 까닭으로 말한다.**
    ⚠ 후보가 없으면 **대표를 안 정한다**(억지로 정하지 않는다).
    """
    rows = _media_rows(conn, song_id)
    if not rows:
        return None, None, '영상이 없습니다'
    ok = [r for r in rows if not (set(r[3]) & set(REP_SKIP_KINDS))]
    if not ok:
        return None, None, '반주·악보·묶음뿐이라 대표를 못 정합니다'
    n_noview = sum(1 for r in ok if r[4] is None)
    ok = [r for r in ok if r[4] is not None]
    if not ok:
        return None, None, '조회수를 아직 모릅니다(링크 점검이 돌면 정해집니다)'
    ok.sort(key=lambda r: (0 if r[6] else 1, -(r[4] or 0), -(r[5] or 0)))
    top = ok[0]
    # ⓓ 조회수가 박빙이면 구독자로 가른다 — **같은 묶음 안에서만**
    close = [r for r in ok
             if (0 if r[6] else 1) == (0 if top[6] else 1)
             and (r[4] or 0) * 1.3 >= (top[4] or 0)]
    if len(close) > 1:
        close.sort(key=lambda r: -(r[5] or 0))
        top = close[0]
        why = ('구독자 %s · 조회수 %s%s'
               % (_n(top[5]), _n(top[4]), ' · 주요 사역자' if top[6] else ''))
    else:
        why = ('조회수 %s%s' % (_n(top[4]),
                              ' · 주요 사역자' if top[6] else ''))
    if n_noview:
        why += ' (조회수 모르는 영상 %d편은 뺐습니다)' % n_noview
    return top[0], top[1], why


def _n(v):
    try:
        return '{:,}'.format(int(v))
    except Exception:
        return '?'


def seed_anchors(conn, log=None):
    """**이미 실측으로 확인해 둔 원곡을 닻으로 올린다** → 올린 수.

    ★ `SONG_ORIGIN` 은 §233차에 **「- Topic」 채널과 눈으로 본 것만** 적어 둔
      표다(「짐작이 이긴다」를 막으려고 만든 자리). 그것이 곧 **증거**다.
    ⚠ 그 곡의 **원곡 언어·사역자와 맞는 판**을 찾아 못 박는다 — 못 찾으면
      건너뛴다(억지로 정하지 않는다).
    ⚠ 이미 `ORIG` 로 정해 둔 것은 안 덮는다(사람이 고친 값을 안 건드린다).
    """
    ensure(conn)
    n = 0
    for code, (ol, oa_code) in SONG_ORIGIN.items():
        r = conn.execute(
            "SELECT song_id, anchor_rend_id, COALESCE(anchor_kind,'')"
            # status-ok: 코드 하나로 제 장부를 읽는 자리 — 가린 곡에도 닻을
            #   두어야 되살릴 때 값이 있다
            "  FROM %s WHERE song_code=?" % T_SONG, (code,)).fetchone()
        if not r or r[2] == ANCHOR_ORIG:
            continue
        sid = r[0]
        aid = None
        if oa_code:
            _a = conn.execute(
                "SELECT artist_id FROM sys_worship_artist"
                # status-ok: 코드로 번호를 찾는 자리 — 보관함에 있는 사역자도
                #   원곡자일 수 있다(가림은 「찬양 사역자가 아니다」가 아니다)
                " WHERE artist_code=?", (oa_code,)).fetchone()
            aid = _a[0] if _a else None
        q = ("SELECT rend_id FROM %s WHERE song_id=?"
             "   AND UPPER(COALESCE(lang_code,''))=?"
             "   AND COALESCE(record_status,'LIVE')='LIVE'" % T_REND)
        args = [sid, (ol or '').upper()]
        if aid:
            q += " AND artist_id=?"
            args.append(aid)
        got = conn.execute(q, args).fetchall()
        if len(got) != 1:
            # ★★★ **아는 것을 잃지 않는다** — 원곡이 누구인지는 확인됐는데
            #   **그 판(영상)이 우리에게 없을 뿐**인 경우가 있다(실측
            #   `Way Maker` — 원곡자는 SINACH 인데 우리에겐 Leeland 판뿐이다).
            #   ⇒ 닻은 대표로 두되 **그 사실을 근거 칸에 적어 둔다.**
            _known = ('원곡은 %s%s 로 확인됐으나 그 판이 아직 없습니다'
                      % (ol or '?', ' · ' + oa_code if oa_code else ''))
            conn.execute(
                "UPDATE %s SET anchor_why=COALESCE(NULLIF(anchor_why,''),?)"
                " WHERE song_id=? AND COALESCE(anchor_kind,'')<>?" % T_SONG,
                (_known, sid, ANCHOR_ORIG))
            if log:
                log('  대표로 둠 %s — %s (맞는 판 %d개)'
                    % (code, _known, len(got)))
            continue
        set_anchor(conn, sid, got[0][0], ANCHOR_ORIG,
                   '실측 확인(%s%s)' % (ol, ' · ' + oa_code if oa_code else ''))
        n += 1
        if log:
            log('  원곡 %s ← 판 #%d' % (code, got[0][0]))
    return n


def anchor_of(conn, song_id):
    """그 곡의 닻 → `{'rend_id','media_id','kind','why','at','title'}`."""
    ensure(conn)
    r = conn.execute(
        "SELECT anchor_rend_id, COALESCE(anchor_kind,''),"
        # status-ok: 번호 하나로 제 장부를 읽는 자리 — 닻은 곡의 속성이고
        #   가린 곡에도 남아 있어야 한다
        "       COALESCE(anchor_why,''), COALESCE(anchor_at,'')"
        "  FROM %s WHERE song_id=?" % T_SONG, (song_id,)).fetchone()
    if not r or not r[0]:
        return {}
    mid = conn.execute(
        "SELECT l.clicked_id FROM sys_link_asset l"
        "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
        " WHERE l.link_type=? AND l.target_id=?"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND m.record_status='LIVE' LIMIT 1", (LINK_MEDI, r[0])).fetchone()
    return dict(rend_id=r[0], media_id=(mid[0] if mid else None),
                kind=r[1], why=r[2], at=r[3],
                title=label(conn, NAME_REND, r[0], 'KO'))


def set_anchor(conn, song_id, rend_id, kind=ANCHOR_ORIG, why=''):
    """**닻을 못 박는다** → True.

    ★ `kind=ORIG` 는 「증거가 있다」는 뜻이다 — **근거를 안 적으면 거부한다.**
      비어 있는 근거를 받아 주면 확정과 잠정이 다시 섞인다.
    ⚠ 닻이 바뀌면 **그 닻에서 뽑은 연결을 다시 뽑아야 한다** — 부르는 쪽이
      `rederive_links` 를 이어서 부른다(여기서 자동으로 하지 않는다: 되돌릴
      수 없는 일을 조용히 하지 않는다).
    """
    ensure(conn)
    if kind == ANCHOR_ORIG and not (why or '').strip():
        raise ValueError('원곡으로 정하려면 근거를 적어야 합니다')
    conn.execute(
        "UPDATE %s SET anchor_rend_id=?, anchor_kind=?, anchor_why=?,"
        " anchor_at=datetime('now','localtime') WHERE song_id=?" % T_SONG,
        (int(rend_id) if rend_id else None, kind, (why or '').strip(),
         int(song_id)))
    return True


def clear_anchor(conn, song_id):
    """닻을 지운다(대표로 되돌릴 자리) → True."""
    ensure(conn)
    conn.execute("UPDATE %s SET anchor_rend_id=NULL, anchor_kind=NULL,"
                 " anchor_why=NULL, anchor_at=NULL WHERE song_id=?" % T_SONG,
                 (int(song_id),))
    return True


def refresh_reps(conn, song_ids=None, dry=False, log=None):
    """**대표를 다시 계산한다** → `[(song_id, 옛 rend, 새 rend, 근거)]`.

    ⚠⚠⚠ **확정(`ORIG`)은 절대 안 건드린다** — 사람이 증거를 대고 정한 값이다.
      잠정(`REP`)과 아직 없는 것만 채운다. 그것이 「원곡에 준해서 관리한다」의
      뜻이다(2026-09-11 사용자).
    ⚠ **바뀐 것을 돌려준다** — 조용히 갈아 끼우면 그 곡에서 뽑은 구절·주제가
      소리 없이 달라진다. 부르는 쪽이 보이고 사람이 안다.
    """
    ensure(conn)
    q = ("SELECT song_id, anchor_rend_id, COALESCE(anchor_kind,'')"
         "  FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'" % T_SONG)
    args = []
    if song_ids:
        q += " AND song_id IN (%s)" % ','.join('?' * len(song_ids))
        args = list(song_ids)
    out = []
    for sid, cur, kind in conn.execute(q, args).fetchall():
        if kind == ANCHOR_ORIG:
            continue                      # ★ 확정은 손대지 않는다
        rid, _mid, why = pick_rep(conn, sid)
        if rid == cur:
            continue
        out.append((sid, cur, rid, why))
        if log:
            log('  곡 #%d  판 %s → %s  (%s)' % (sid, cur, rid, why))
        if not dry:
            if rid:
                # ⚠ **아는 것을 덮지 않는다** — `seed_anchors` 가 적어 둔
                #   「원곡은 ~로 확인됐으나 판이 없다」를 뒤에 잇는다.
                _old = conn.execute(
                    "SELECT COALESCE(anchor_why,'') FROM %s"
                    # status-ok: 번호 하나로 제 장부를 읽는 자리 — 가린 곡의
                    #   닻도 다시 계산해야 한다(되살릴 때 값이 있어야 한다)
                    " WHERE song_id=?" % T_SONG, (sid,)).fetchone()[0]
                _keep = ('%s  ·  %s' % (_old, why)
                         if _old.startswith('원곡은 ') else why)
                conn.execute(
                    "UPDATE %s SET anchor_rend_id=?, anchor_kind=?,"
                    " anchor_why=?, anchor_at=datetime('now','localtime')"
                    " WHERE song_id=?" % T_SONG, (rid, ANCHOR_REP, _keep, sid))
            else:
                conn.execute(
                    "UPDATE %s SET anchor_rend_id=NULL, anchor_kind=?,"
                    " anchor_why=?, anchor_at=datetime('now','localtime')"
                    " WHERE song_id=?" % T_SONG, (ANCHOR_REP, why, sid))
    return out


def _a_song_with_media(conn):
    """**영상이 붙은 곡 하나** — 시험이 선택할 자리.

    ⚠⚠ **`songs()[0]` 을 집으면 안 된다**(§0-5) — 곡을 담을수록 첫 자리가
      **영상 없는 새 곡**으로 바뀌어 시험이 통째로 깨진다(2026-09-11에 당했다).
    """
    r = conn.execute(
        "SELECT r.song_id FROM %s r"
        "  JOIN sys_link_asset l ON l.link_type=? AND l.target_id=r.rend_id"
        " WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND COALESCE(r.record_status,'LIVE')='LIVE'"
        " GROUP BY r.song_id ORDER BY COUNT(*) DESC LIMIT 1" % T_REND,
        (LINK_MEDI,)).fetchone()   # status-ok: 시험이 표본을 고르는 자리
    return r[0] if r else None


def songs_brief(conn, lang='KO', q='', limit=200):
    """**곡 한 줄씩** → [(song_id, 이름, 판 수, 영상 수, 닻갈래, 닻이름)].

    ★★★ 2026-09-11 사용자 — 「언제나 주만 검색하면 **하나만 표시되어야 한다** …
      **원곡/대표곡 이름만** 표시되면 된다」.
      ⇒ 그전에는 **판을 다 펼쳐** 보였다(곡 20개 · 판 45개). 연결의 목적이
        구절·주제 자동 연결인데 **그것은 곡에 붙는다** — 판을 고를 이유가 없다.
    ⚠ 찾을 때는 **곡 이름과 판 이름을 함께** 본다(「언제나 주만」은 판 이름이다).
    """
    ensure(conn)
    out = []
    w = (q or '').strip().lower()
    for sid, nm, ol, oa, nr, nv in songs(conn, lang):
        names = [nm] + [r[1] for r in rends_of(conn, sid, lang)]
        if w and not any(w in (x or '').lower() for x in names):
            continue
        a = anchor_of(conn, sid)
        out.append((sid, nm or '', nr, nv, a.get('kind') or '',
                    a.get('title') or ''))
        if len(out) >= int(limit):
            break
    return out


def pick_rend(conn, song_id, media_id, make=True):
    """그 영상이 **어느 판인지 기계가 선택한다** → `(rend_id, 까닭)`.

    ★★★ 2026-09-11 사용자 — 「**왜 영상을 곡과 연결해야지 판과 연결하는가**」.
      맞다. 영상의 **언어와 제목**이 이미 어느 판인지 말한다 — 기계가 정할 수
      있는 것을 사람에게 물으면 안 된다.
    차례 —
      ⓐ **언어가 같고 제목이 그 판 이름을 품는다** → 그 판
      ⓑ 언어가 같은 판이 **하나뿐** → 그 판
      ⓒ 그 언어 판이 **없다** → `make` 면 만든다(제목에서 이름을 뽑는다)
      ⓓ 가릴 수 없다 → `(None, 까닭)` — **그때만 사람에게 묻는다**
    ⚠ 실측 곡 20개 중 **같은 언어 판이 둘 이상인 곡은 하나뿐**이라
      ⓓ 로 가는 일이 거의 없다.
    """
    ensure(conn)
    r = conn.execute("SELECT title, COALESCE(lang_code,'')"
                     # status-ok: 번호 하나로 읽는 자리 — 가린 영상도 판을 골라야
                     #   되살릴 때 자리가 있다
                     "  FROM sys_media_asset WHERE media_id=?",
                     (media_id,)).fetchone()
    if not r:
        return None, '영상을 못 찾았습니다'
    ti, lg = (r[0] or ''), (r[1] or '').upper()
    rends = [(rid, nm, (lc or '').upper())
             for rid, nm, lc, _an, _io, _if, _n in rends_of(conn, song_id)]
    same = [x for x in rends if x[2] == lg] if lg else []
    if same:
        hit = [x for x in same if x[1] and _has_name(ti, x[1])]
        if len(hit) == 1:
            return hit[0][0], '제목이 「%s」 를 품습니다' % hit[0][1]
        if len(same) == 1:
            return same[0][0], '그 언어 판이 하나뿐입니다'
        if len(hit) > 1:
            return None, '같은 언어 판이 %d개라 가릴 수 없습니다' % len(hit)
        return None, '같은 언어 판이 %d개라 가릴 수 없습니다' % len(same)
    if not make:
        return None, '%s 판이 없습니다' % (lg or '?')
    # ⓒ **그 언어 판을 만든다** — 이름은 곡 이름을 쓴다(제목은 군더더기가 많다)
    nm = label(conn, NAME_SONG, song_id, lg or 'EN') or \
        label(conn, NAME_SONG, song_id, 'KO') or ''
    rid = add_rend(conn, song_id, lg or 'EN',
                   names={(lg or 'EN'): nm} if nm else None, title=nm)
    return rid, '%s 판을 새로 만들었습니다' % (lg or 'EN')


def attach_media(conn, song_id, media_id):
    """**영상을 곡에 연결한다** — 판은 기계가 선택한다 → `(ok, 말)`."""
    rid, why = pick_rend(conn, song_id, media_id)
    if not rid:
        return False, why
    link_media(conn, media_id, rid)
    conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                 " confidence='MANUAL' WHERE link_type=? AND clicked_id=?"
                 "   AND target_id=?", (LINK_MEDI, media_id, rid))
    return True, why


def match_name(conn, name, lang=None, exclude=None):
    """이 이름이 **이미 있는 곡인가** → (등급, song_id, 근거) 또는 (None,None,[]).

    ★★★ 2026-09-11 사용자 — 「지금 있는 데이터를 merge 하더라도 앞으로 계속
      데이터가 쌓이면 **또 반복**해야 할 것이다」. 정확하다.
      ⇒ **막는 자리는 합치기가 아니라 「곡을 만드는 문」이다.**
    ⚠⚠⚠ 그전에는 `add_song` 이 **`song_code` 가 같은지만** 봤다. 「내사랑1」은
      코드가 `S_내사랑1` 이라 `S_내사랑` 과 달라 **아무 검사 없이 새 곡이
      생겼다.** 그것이 중복이 쌓인 뿌리다.
    ★ **확실** — 정식 이름이나 별명이 **정확히 같다**(정규화 뒤).
      **추천** — 판 이름이 같거나 이름이 **포함 관계**다.
    ⚠ **추천은 자동으로 안 붙인다** — 「십자가」가 「구주의 십자가 보혈로」에
      붙어 버리면 안 된다(실측 그 짝이 있다).
    """
    ensure(conn)
    k = title_key(name)
    if not k:
        return (None, None, [])
    best = None
    for sid, in conn.execute(
            "SELECT song_id FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'"
            % T_SONG):
        if exclude and sid == exclude:
            continue
        offi = {title_key(v) for v in names_of(conn, NAME_SONG, sid).values()}
        offi |= {title_key(v) for _l, v in aliases_of(conn, sid)}
        if k in offi:
            return (SAME_SURE, sid, ['정식 이름·별명이 같다'])
        if best is None:
            ks = all_keys(conn, sid)
            if k in ks:
                best = (SAME_MAYBE, sid, ['판 이름이 같다'])
                continue
            for y in ks:
                if len(k) >= 3 and len(y) >= 3 and k != y \
                        and (k in y or y in k):
                    best = (SAME_MAYBE, sid,
                            ['이름이 포함 관계다 (%s / %s)' % (k[:16], y[:16])])
                    break
    return best or (None, None, [])


def new_song_from_media(conn, media_id, name=None, lang=None, orig=None,
                        composer=None, year=None, note=None):
    """**이 영상으로 새 곡을 만든다** → `(song_id, rend_id)`.

    ★★★ 2026-09-11 사용자 — 「수집된 영상을 기준으로 **새로운 곡을 등록할 수
      있어야** 다음에 수집된 영상도 연결 가능하다 … **흐름이 끊어진 것 같다**」.
      ⇒ 그전에는 곡을 만드는 길이 `derive`(일괄)와 손으로 이름 치기뿐이었다.
    ⚠ 이름을 안 주면 **영상 제목을 그대로** 쓴다 — 지어내지 않는다.
    """
    import re as _re
    r = conn.execute("SELECT title, COALESCE(lang_code,'')"
                     # status-ok: 번호 하나로 읽는 자리
                     "  FROM sys_media_asset WHERE media_id=?",
                     (media_id,)).fetchone()
    if not r:
        raise ValueError('영상을 못 찾았습니다')
    ti, lg0 = (r[0] or ''), (r[1] or 'KO').upper()
    nm = (name or ti).strip()
    lg = (lang or lg0).upper()
    if not nm:
        raise ValueError('곡 이름이 없습니다')
    # ★★★ **만들기 전에 묻는다**(2026-09-11 사용자 「계속 데이터가 쌓이면 또
    #   반복해야 할 것이다」) — **확실이면 새로 안 만들고 그 곡에 판으로 붙인다.**
    #   ⚠ 추천은 그대로 만든다 — 자동으로 붙이면 딴 곡을 먹는다. 대신
    #     `find_same` 이 그 짝을 사람에게 낸다.
    g, sid0, _w = match_name(conn, nm, lg)
    if g == SAME_SURE and sid0:
        rid0 = add_rend(conn, sid0, lg, names={lg: nm}, title=nm)
        link_media(conn, media_id, rid0)
        conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                     " confidence='MANUAL' WHERE link_type=? AND clicked_id=?"
                     "   AND target_id=?", (LINK_MEDI, media_id, rid0))
        return sid0, rid0
    code = _re.sub(r'[^A-Za-z0-9]+', '_',
                   (orig or nm)).upper().strip('_')[:24] or 'SONG'
    names = {lg: nm}
    if orig:
        names['EN'] = orig
    sid = add_song(conn, code, names=names, orig_lang=lg,
                   composer=composer, year=year, note=note)
    rid = add_rend(conn, sid, lg, names={lg: nm}, title=nm)
    link_media(conn, media_id, rid)
    conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                 " confidence='MANUAL' WHERE link_type=? AND clicked_id=?"
                 "   AND target_id=?", (LINK_MEDI, media_id, rid))
    return sid, rid


def verses_of(conn, song_id):
    """그 곡에 걸린 구절 [(link_id, 시작, 끝, 사람이 이었나)] — 화면이 쓰는 문."""
    ensure(conn)
    return [(a, b, c or b, (d or '') == 'MANUAL') for a, b, c, d in conn.execute(
        "SELECT sys_link_id, target_id, end_id, COALESCE(confidence,'')"
        "  FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
        "   AND COALESCE(record_status,'LIVE')='LIVE'"
        " ORDER BY target_id", (LINK_VERS, song_id)).fetchall()]


def add_verse(conn, song_id, start_vid, end_vid=None):
    """곡에 구절(또는 구간)을 **사람이 잇는다** → link_id 또는 None(이미 있음).

    ⚠⚠ **`confidence='MANUAL'`** — 규칙(`db_song_lift`)이 곡 층을 다시 지어도
      이 줄은 안 걷힌다(그 문은 `source LIKE 'LIFT:%'` 만 본다).
    ⚠ 거꾸로 된 구간은 거부한다.
    """
    ensure(conn)
    a = int(start_vid)
    b = int(end_vid) if end_vid else a
    if b < a:
        return None
    r = conn.execute(
        "SELECT sys_link_id, COALESCE(record_status,'LIVE')"
        "  FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
        "   AND target_id=? AND COALESCE(end_id,target_id)=?",
        (LINK_VERS, song_id, a, b)).fetchone()  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
    if r:
        if r[1] != 'LIVE':
            conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                         " confidence='MANUAL' WHERE sys_link_id=?", (r[0],))
            return r[0]
        return None
    cur = conn.execute(
        "INSERT INTO sys_link_asset(link_type, clicked_id, target_id, end_id,"
        " record_status, confidence) VALUES(?,?,?,?,'LIVE','MANUAL')",
        (LINK_VERS, song_id, a, None if b == a else b))
    return cur.lastrowid


def drop_verse(conn, link_id):
    """곡↔구절을 **뗀다**(가린다) → bool.

    ⚠ 지우지 않고 가린다 — 규칙이 다시 지을 때 **되살아나면 뗀 뜻이 없다**
      (`db_song_lift` 가 사람 줄을 안 건드리므로 가림이 그대로 남는다).
    """
    ensure(conn)
    c = conn.execute("UPDATE sys_link_asset SET record_status='HIDE',"
                     " confidence='MANUAL' WHERE sys_link_id=? AND link_type=?",
                     (int(link_id), LINK_VERS))
    return c.rowcount > 0


def set_names(conn, song_id, names):
    """곡 이름을 **언어별로** 적는다 → bool (`{'KO': '…', 'EN': '…'}`).

    ⚠ 빈 값은 **안 덮는다** — 칸을 비우고 저장해 이름을 잃는 자리다.
      이름을 지우려면 그 언어 행을 관리자 테이블 화면에서 내린다.
    """
    ensure(conn)
    if not song_id or not names:
        return False
    _put_names(conn, NAME_SONG, int(song_id), names)
    return True


def find_songs(conn, q, lang='KO', limit=20):
    """이름으로 곡을 찾는다 [(song_id, 보이는 이름)] — **이미 있나** 묻는 자리.

    ★ 사용자 「곡이름 검색이 불가능하다. **이미 등록되었는지 검색**해야 한다」.
    ⚠ 어느 언어 이름에든 걸린다 — 「Holy Forever」로 쳐도 「거룩 영원히」가 나온다.
    """
    ensure(conn)
    s = (q or '').strip()
    if not s:
        return []
    like = '%' + s + '%'
    ids = [r[0] for r in conn.execute(
        "SELECT DISTINCT clicked_id FROM sys_text_asset"
        " WHERE text_type=? AND contents LIKE ?"
        "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT ?",
        (NAME_SONG, like, int(limit))).fetchall()]
    return [(i, display_title(conn, i, lang)) for i in ids]


def set_genre(conn, song_id, genre):
    """곡의 **장르**를 적는다 → bool.

    ⚠ 목록에 없는 값은 **거부한다** — 조용히 담으면 화면이 코드를 그대로 보인다.
    ⚠ 빈 값이면 **비운다**(모른다는 뜻).
    """
    ensure(conn)
    import media_taxonomy as _TX
    g = (genre or '').strip().upper() or None
    if g and g not in _TX.SONG_GENRES:
        return False
    conn.execute("UPDATE %s SET genre=? WHERE song_id=?" % T_SONG, (g, song_id))
    return True


def genre_of(conn, song_id):
    """곡의 장르 코드 → 없으면 `''`."""
    ensure(conn)
    r = conn.execute("SELECT COALESCE(genre,'') FROM %s WHERE song_id=?"  # status-ok: 번호 하나로 제 장부를 읽는 자리
                     % T_SONG, (song_id,)).fetchone()
    return r[0] if r else ''


def set_meta(conn, song_id, composer=None, year=None, note=None,
             lyrics=None, memo=None, subtitle=None):
    """**작곡 정보** — 언제·어디 소속의 누가 만들었나(2026-09-11 사용자
    「원곡으로 지정할 때에는 **언제 어디 소속의 누가 작곡했는지** 등을 설명하는
    공간이 있어야 **증거 역할**을 한다」).

    ⚠ 칸은 처음부터 있었는데 **화면이 안 열어 주어 0건**이었다(실측).
    """
    ensure(conn)
    sets, args = [], []
    for col, val in (('composer', composer), ('year', year), ('note', note),
                     ('lyrics', lyrics), ('memo', memo),
                     ('subtitle', subtitle)):
        if val is not None:
            sets.append('%s=?' % col)
            args.append(val if val != '' else None)
    if not sets:
        return False
    args.append(int(song_id))
    conn.execute("UPDATE %s SET %s WHERE song_id=?"
                 % (T_SONG, ', '.join(sets)), args)
    return True


def meta_of(conn, song_id):
    """작곡 정보 → `{'composer','year','note'}`."""
    ensure(conn)
    r = conn.execute("SELECT COALESCE(composer,''), year, COALESCE(note,''),"
                     "       COALESCE(lyrics,''), COALESCE(memo,''),"
                     "       COALESCE(subtitle,'')"
                     # status-ok: 번호 하나로 제 장부를 읽는 자리
                     "  FROM %s WHERE song_id=?" % T_SONG,
                     (song_id,)).fetchone()
    return dict(composer=r[0], year=r[1], note=r[2],
                lyrics=r[3], memo=r[4], subtitle=r[5]) if r else {}


# ══════════════════════════════════════════════════════════════════════
#  검증 — 「이 영상들이 정말 같은 곡인가」
# ══════════════════════════════════════════════════════════════════════
#: 승격 표식 — 되돌릴 자리
PROMOTE_NOTE = 'SONG_PROMOTE_20260911'


def verify_song(conn, song_id, lang='KO'):
    """그 곡의 묶음이 믿을 만한가 → `(ok, [까닭…], {'n':영상수,'bad':[…]})`.

    ★★★ **곡 단위로 올리기 전에 반드시 통과해야 한다**(2026-09-11).
      지금은 틀린 묶음이 **한 편**을 오염시키지만, 곡으로 올리면 **그 곡의
      영상 전부**가 한꺼번에 오염된다(실측 한 곡에 27편).
    ⚠ 실측된 함정 — 「기억하네」가 **쿠팡플레이 드라마·트로트 콘서트** 12편을,
      「비밀」이 **KBS 드라마·이승기** 9편을 끌어왔다(§234차).

    잣대 넷 —
      ⓐ 영상이 있다
      ⓑ **곡 이름이 흔한 말이 아니다**(`COMMON_WORD_SONGS`)
      ⓒ **닻이 있다**(반주·묶음만 있는 곡은 닻이 안 잡힌다)
      ⓓ **영상 제목마다 그 곡의 이름 하나가 실제로 들어 있다** ← 가장 강하다
    ⚠ ⓓ 를 못 넘는 영상은 **이름으로 돌려준다** — 사람이 보고 뗄 수 있게.
    """
    ensure(conn)
    why, bad = [], []
    names = [x for x in names_all(conn, song_id) if x and len(x.strip()) > 1]
    rows = _media_rows(conn, song_id)
    n = len(rows)
    if not n:
        return False, ['영상이 없습니다'], {'n': 0, 'bad': []}
    # ⚠ 흔한 말 목록의 집은 `db_song_collect` 다 — **베끼지 않는다**(§241차 ①).
    #   ⚠⚠ 그 표는 **곡 이름**의 목록이지 곡 코드가 아니다 — 이름으로 견준다.
    try:
        import db_song_collect as _SC2
        _cw = set(_SC2.COMMON_WORD_SONGS)
    except Exception:
        _cw = set()
    if _cw & {(x or '').strip() for x in names}:
        why.append('곡 이름이 흔한 말입니다 — 딴 것이 섞이기 쉽습니다')
    if not anchor_of(conn, song_id):
        why.append('닻(원곡/대표)이 없습니다')
    if not names:
        why.append('곡 이름이 없습니다')
    else:
        for _rid, mid, ti, _ks, _v, _s, _f in rows:
            if not any(_has_name(ti, nm) for nm in names):
                bad.append((mid, ti))
        if bad:
            why.append('제목에 곡 이름이 없는 영상 %d편' % len(bad))
    return (not why), why, {'n': n, 'bad': bad}


def names_all(conn, song_id):
    """그 곡과 판들의 **모든 이름** — 언어를 가리지 않는다."""
    out = []
    for lg in ('KO', 'EN', 'ZH', 'ZHT', 'JA', 'ES', 'PT', 'AR'):
        v = label(conn, NAME_SONG, song_id, lg)
        if v and v not in out:
            out.append(v)
    for rid, in conn.execute(
            "SELECT rend_id FROM %s WHERE song_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'" % T_REND,
            (song_id,)):
        for lg in ('KO', 'EN', 'ZH', 'ZHT', 'JA', 'ES', 'PT', 'AR'):
            v = label(conn, NAME_REND, rid, lg)
            if v and v not in out:
                out.append(v)
    return out


def _has_name(title, name):
    """제목이 그 이름을 품는가 — **라틴은 낱말 경계까지 본다**.

    ⚠⚠ 부분 일치로 보면 안 된다 — 「Hold Me Fast」 ⊂ 「He Will Hold Me Fast」
      처럼 짧은 이름이 딴 곡을 먹는다(§234차). 한글·한자는 경계가 없어
      그대로 보되, 이름이 **두 글자 이하면 안 본다**(`verify_song` 이 거른다).
    """
    import re as _re
    t = _norm_sp(title or '')
    nm = _norm_sp(name or '')
    if not nm:
        return False
    if _re.fullmatch(r"[A-Za-z0-9 '’\-\.,!?()]+", nm):
        return bool(_re.search(r'(?<![A-Za-z])%s(?![A-Za-z])'
                               % _re.escape(nm), t, _re.I))
    # ⚠⚠ **한국어 띄어쓰기는 원래 흔들린다** — 실측 오탐 셋이 전부 그것이었다
    #   (「언제나주만」 ↔ 「언제나 주만」 · 「우리 주안에서」 ↔ 「우리 주 안에서」).
    #   ⇒ 라틴이 아닌 이름은 **공백을 다 떼고** 견준다.
    #   ★ 라틴에는 이 수를 쓰지 않는다 — 공백을 떼면 낱말 경계가 사라져
    #     짧은 이름이 딴 곡을 먹는다(「Hold Me Fast」 함정).
    _t2 = _re.sub(r'\s+', '', t).lower()
    _n2 = _re.sub(r'\s+', '', nm).lower()
    return bool(_n2) and _n2 in _t2


def _norm_sp(s):
    import re as _re
    return _re.sub(r'\s+', ' ', (s or '')).strip()


# ══════════════════════════════════════════════════════════════════════
#  승격 — 구절·주제를 곡 전체로
# ══════════════════════════════════════════════════════════════════════
def promote(conn, song_id, dry=False, force=False):
    """**그 곡의 구절·주제를 곡 전체로 올린다** → `{'verse':n,'topic':n,…}`.

    ★★★ 2026-09-11 사용자 — 「대표곡을 기준으로 **구절 주제를 연결**하자」.
      실측이 값을 증명했다: `我的救贖者活著` 영상 27편 중 주제가 붙은 것
      **1편** · `새 일이 일어나네` 15편 중 구절 **1편**. 그 한 건이 곡 전체로
      퍼진다.
    ★ **재료는 그 곡의 영상 전부에서 모으고**, 닻은 **충돌할 때 이기는 쪽**이다
      — 실측 태그가 붙은 한 편이 닻이 아닌 경우가 많다. 닻만 보면 그것을 잃는다.
    ⚠⚠ **검증을 통과해야 한다**(`verify_song`) — 틀린 묶음이 곡으로 오르면
      한 편이 아니라 **전부**가 오염된다. `force` 는 사람이 화면에서 확인한
      뒤에만 준다.
    ⚠ **만든 연결에 표식을 남긴다**(`note=PROMOTE_NOTE` · `source='SONG:<id>'`)
      — 되돌릴 수 있어야 하고, 「누가 이었나」를 나중에 물을 수 있어야 한다.
    ⚠ **사람이 뗀 것은 되살리지 않는다**(`confidence='MANUAL'` 인 가림).
    """
    import media_link as _ML
    ensure(conn)
    ok, why, info = verify_song(conn, song_id)
    if not ok and not force:
        return {'verse': 0, 'topic': 0, 'skip': 1, 'why': why}
    mids = [r[1] for r in _media_rows(conn, song_id)]
    if not mids:
        return {'verse': 0, 'topic': 0, 'skip': 1, 'why': ['영상이 없습니다']}
    ph = ','.join('?' * len(mids))
    out = {'verse': 0, 'topic': 0, 'skip': 0, 'why': why}
    _vwant = []
    try:
        import db_worship_topic as _TP
        tids = set(_TP.topic_ids(conn))
    except Exception:
        tids = set()
    for kind, lt in (('verse', _ML.lt('VERSE')), ('topic', _ML.lt('ENTITY'))):
        # ⓐ 그 곡 영상 전부에서 **살아 있는 연결**을 모은다
        want = {}
        for tgt, end in conn.execute(
                "SELECT target_id, end_id FROM sys_link_asset"
                " WHERE link_type=? AND clicked_id IN (%s)"
                "   AND COALESCE(record_status,'LIVE')='LIVE'" % ph,
                [lt] + mids):
            if kind == 'topic' and tids and tgt not in tids:
                continue          # ⚠ 주제로 고른 용어만 퍼뜨린다
            want[(tgt, end)] = True
        if not want:
            continue
        # ⚠⚠⚠ **가릴 수 없으면 퍼뜨리지 않는다**(2026-09-11 실측으로 잡았다) —
        #   「난 언제나 예수」의 영상 둘이 **사6장**과 **시13:5~6** 으로 서로
        #   다른 구절을 가리켰다. 합집합을 그대로 퍼뜨리면 **15편 전부에 둘 다**
        #   붙어 틀린 것이 열네 배로 는다.
        #   ★ 겹치는 것은 하나로 본다 — 「시119장」 ⊃ 「시119:105~120」.
        #     **좁은 쪽을 남긴다**(누군가 구체적으로 적은 것이고, 넓은 쪽을
        #     쓰면 시편 119편 176절 전부에서 이 곡이 뜬다).
        if kind == 'verse' and len(want) > 1:
            _sp = sorted(((t, e if e is not None else t) for t, e in want),
                         key=lambda x: (x[1] - x[0], x[0]))
            _keep = []
            for _a2, _b2 in _sp:
                if any(_a3 >= _a2 and _b3 <= _b2 for _a3, _b3 in _keep):
                    continue          # 이미 더 좁은 것이 들어 있다
                _keep.append((_a2, _b2))
            if len(_keep) > 1:
                out['skip'] = out.get('skip', 0) + 1
                why.append('구절이 %d가지로 갈립니다 — 사람이 선택해야 합니다'
                           % len(_keep))
                continue
            want = {(_keep[0][0],
                     None if _keep[0][0] == _keep[0][1] else _keep[0][1]): True}
        if kind == 'verse':
            _vwant = list(want)
        # ⓑ 없는 영상에 채운다
        for mid in mids:
            for (tgt, end) in want:
                r = conn.execute(
                    "SELECT sys_link_id, record_status,"
                    "       COALESCE(confidence,'') FROM sys_link_asset"
                    " WHERE link_type=? AND clicked_id=? AND target_id=?"
                    "   AND COALESCE(end_id,-1)=COALESCE(?,-1)",
                    (lt, mid, tgt, end)).fetchone()  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
                if r:
                    # ⚠ **사람이 뗀 것은 되살리지 않는다**
                    if r[1] == 'HIDE' and r[2] == 'MANUAL':
                        continue
                    if r[1] == 'LIVE':
                        continue
                    if not dry:
                        # ⚠⚠ **옛 상태를 표식에 적는다** — 없던 줄은 지우면
                        #   되지만 **있던 줄은 되돌려야 한다**(지우면 사라진다).
                        conn.execute(
                            "UPDATE sys_link_asset SET record_status='LIVE',"
                            " note=?, source=? WHERE sys_link_id=?",
                            ('%s:%s' % (PROMOTE_NOTE, r[1]),
                             'SONG:%d' % song_id, r[0]))
                    out[kind] += 1
                    continue
                if not dry:
                    conn.execute(
                        "INSERT INTO sys_link_asset(link_type, clicked_id,"
                        " target_id, end_id, record_status, confidence,"
                        " note, source) VALUES(?,?,?,?,'LIVE','AUTO',?,?)",
                        (lt, mid, tgt, end, PROMOTE_NOTE,
                         'SONG:%d' % song_id))
                out[kind] += 1
    # ⓒ 구절은 **곡 층에도** 적는다 — `songs_of_verse` 가 그 표를 읽는다.
    #   ⚠⚠ **위에서 가른 결론을 그대로 쓴다** — 여기서 다시 합집합을 읽으면
    #     갈려서 안 퍼뜨린 것이 곡 층에는 들어간다(실측으로 잡았다).
    for tgt, end in list(locals().get('_vwant') or []):
        if conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type='SONG_VERS'"
                "   AND clicked_id=? AND target_id=?"
                "   AND COALESCE(end_id,-1)=COALESCE(?,-1)",
                (song_id, tgt, end)).fetchone():  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
            continue
        if not dry:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " end_id, record_status, confidence, note, source)"
                " VALUES('SONG_VERS',?,?,?,'LIVE','AUTO',?,?)",
                (song_id, tgt, end, PROMOTE_NOTE, 'SONG:%d' % song_id))
        out['song_verse'] = out.get('song_verse', 0) + 1
    return out


def promote_undo(conn, song_ids=None):
    """승격을 되돌린다 → 되돌린 수. **표식을 남긴 것만.**

    ⚠⚠⚠ **곡으로 좁힐 수 있어야 한다**(2026-09-11에 당했다) — 좁힐 수 없으면
      selftest 가 「제 것만 되돌린다」를 못 하고 **사람이 방금 건 125건을 통째로
      지운다.** 시험이 실 데이터를 지우는 자리는 만들면 안 된다.
    ⚠ **없던 줄은 지우고, 있던 줄은 옛 상태로 되돌린다** — 표식에 옛 상태가
      적혀 있다(`SONG_PROMOTE_…:PEND`).
    """
    w, args = "COALESCE(note,'') LIKE ?", [PROMOTE_NOTE + '%']
    if song_ids:
        w += " AND source IN (%s)" % ','.join('?' * len(song_ids))
        args += ['SONG:%d' % int(x) for x in song_ids]
    n = 0
    for lid, note in conn.execute(
            "SELECT sys_link_id, COALESCE(note,'') FROM sys_link_asset"
            # status-ok: **표식으로 제 자국만** 찾는 자리 — 상태로 거르면
            #   가려 둔 자국을 못 찾아 되돌리기가 반쪽이 된다
            " WHERE " + w, args).fetchall():
        old = note[len(PROMOTE_NOTE):].lstrip(':')
        if old:
            conn.execute("UPDATE sys_link_asset SET record_status=?,"
                         " note=NULL, source=NULL WHERE sys_link_id=?",
                         (old, lid))
        else:
            conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?",
                         (lid,))
        n += 1
    return n


def rends_of(conn, song_id, lang='KO'):
    """그 곡의 판 [(rend_id, 제목, 언어, 사역자, 원곡?, 공식?, 영상 수)]."""
    ensure(conn)
    out = []
    for rid, lg, aid, iso, iof in conn.execute(
            "SELECT rend_id, lang_code, artist_id, is_original, is_official"
            " FROM %s WHERE song_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % T_REND, (song_id,)).fetchall():
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset l"
            " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
            " WHERE l.link_type=? AND l.target_id=?"
            "   AND m.is_active=1 AND m.record_status='LIVE'"
            " AND COALESCE(l.record_status,'LIVE')='LIVE'",
            (LINK_MEDI, rid)).fetchone()[0]
        an = ''
        if aid:
            try:
                import db_worship_artist as WA
                an = WA.label(conn, aid, lang)
            except Exception:
                an = ''
        out.append((rid, label(conn, NAME_REND, rid, lang), lg, an,
                    bool(iso), bool(iof), n))
    # ★ 원곡이 맨 앞, 그다음 영상이 많은 순 — 화면이 정렬을 다시 짜지 않게
    return sorted(out, key=lambda x: (not x[4], -x[6], x[1]))


def media_of(conn, rend_id):
    """그 판의 영상 [(media_id, 제목, 갈래, 조회수)] — 조회수 큰 순."""
    try:
        import db_media_linkcheck as LC
        views = LC.views_of(conn)
    except Exception:
        views = {}
    out = []
    for mid, ti, d in conn.execute(
            "SELECT m.media_id, m.title, COALESCE(m.description,'')"
            " FROM sys_link_asset l JOIN sys_media_asset m ON m.media_id=l.clicked_id"
            " WHERE l.link_type=? AND l.target_id=? AND m.record_status='LIVE'"
            # ⚠⚠ **승인된 것만**(§194차 승인=연결) — 안 걸면 검토 안 끝난
            #   URL 이 사용자에게 나간다. 실측 곡에 걸린 299편이 전부
            #   미검토인 채 화면에 떠 있었다(2026-09-09).
            "   AND m.is_active=1"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'",
            (LINK_MEDI, rend_id)).fetchall():
        ks = []
        if d.startswith('{'):
            try:
                ks = json.loads(d).get('rend_kind') or []
            except Exception:
                ks = []
        out.append((mid, ti, ks, (views.get(mid) or (None, None))[0]))
    return sorted(out, key=lambda x: -(x[3] or 0))


#: 대표로 세울 때의 갈래 차례 — 공식음원 > 라이브 > 가사영상 > 나머지.
#: ⚠ 여기 없는 갈래는 3(나머지)이다. 빼는 갈래는 `REP_SKIP_KINDS` 가 따로 맡는다.
REP_KIND_RANK = {'OFFICIAL': 0, 'LIVE': 1, 'LYRICS': 2}


def rep_order(conn, song_id, lang=None, limit=8):
    """이 곡의 **대표 영상 차례** → [(media_id, url, title, 까닭)]. 앞이 대표다.

    ★★★ **미리 박아 두지 않고 누를 때 센다**(2026-09-17 사용자 「가장 대표적인 영상을
      자동 플레이」의 답). 까닭이 셋이다 —
      ⓐ **닻은 판을 가리키지 영상을 가리키지 않는다.** 실측 닻이 있는 60곡 중 **48곡(81%)**
        의 닻 판에 영상이 둘 이상이다(중앙 3편 · 최대 27편). 판을 정해도 한 편을 못 고른다.
      ⓑ **닻이 없는 곡이 166 / 226(73%)** 이다. 닻에 기대면 대부분 아무것도 못 고른다.
        규칙으로 세우면 **승인 영상이 붙은 곡 87개 전부**가 대표를 갖는다(실측 87/87).
        ⚠ 나머지 139곡은 **영상이 0편**이라 정할 것이 없다 — 규칙 탓이 아니다.
      ⓒ 조회수는 자라고 영상은 는다 — 박아 두면 낡는다(§⑤-11 ⓒ 「박빙이면 소리 없이 뒤집힌다」).

    **빼는 것** — 묶음·반주·악보·워십댄스·연주커버(`REP_SKIP_KINDS`) · 쇼츠 ·
      **임베드가 막힌 것으로 확인된 영상**. 실측 묶음 397 · 반주 129 · 가사영상 108편이라
      안 빼면 한 곡의 대표가 「1시간 연속듣기」가 된다.

    **세우는 차례**
      ① 사람이 근거를 적어 확정한 원곡(`anchor_kind='ORIG'`)의 판 — **규칙을 이긴다**
      ② 고른 언어와 같은 판(실측 한국어 판이 있는 곡 197 · 영어 64)
      ③ 갈래(`REP_KIND_RANK`) ④ 조회수 많은 것
      ⑤ **조회수를 모르면 맨 뒤** — 0 으로 치지 않는다(실측 45%만 안다)

    ⚠ 이 문은 **고를 뿐 틀지 않는다.** 자동재생 여부와 갈래는 부르는 쪽이 정한다
      (브라우저 갈래에서 저절로 창이 뜨면 안 된다 — `video_open`).
    """
    ensure(conn)
    lang = (lang or '').upper()
    try:
        import db_media_linkcheck as LC
        views = LC.views_of(conn)
    except Exception:
        views = {}
    r = conn.execute("SELECT COALESCE(anchor_rend_id,0), COALESCE(anchor_kind,'')"
                     " FROM %s WHERE song_id=?" % T_SONG,
                     (song_id,)).fetchone()  # status-ok: 번호 하나로 제 줄의 닻을 읽는다
    a_rend, a_kind = (r[0], r[1]) if r else (0, '')
    bad = set()
    short = set()
    try:
        import db_media_linkcheck as _LC
        for (mid,) in conn.execute(
                "SELECT media_id FROM sys_media_check WHERE status='EMBED_BLOCKED'"):
            bad.add(mid)
        for (mid,) in conn.execute(
                "SELECT media_id FROM sys_media_check"
                " WHERE duration IS NOT NULL AND duration<=?", (_LC.SHORT_SEC,)):
            short.add(mid)
    except Exception:
        pass
    rows = conn.execute(
        "SELECT m.media_id, COALESCE(m.url,''), COALESCE(m.title,''),"
        "       COALESCE(m.description,''), r.rend_id,"
        "       UPPER(COALESCE(r.lang_code,''))"
        "  FROM %s r"
        "  JOIN sys_link_asset l ON l.link_type=? AND l.target_id=r.rend_id"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
        " WHERE r.song_id=? AND COALESCE(r.record_status,'LIVE')='LIVE'"
        "   AND m.is_active=1 AND COALESCE(m.record_status,'LIVE')='LIVE'"
        % T_REND, (LINK_MEDI, song_id)).fetchall()
    out = []
    for mid, url, ti, desc, rend, rlang in rows:
        if mid in bad or mid in short or not url:
            continue
        ks = []
        if desc.startswith('{'):
            try:
                ks = json.loads(desc).get('rend_kind') or []
            except Exception:
                ks = []
        if set(ks) & set(REP_SKIP_KINDS):
            continue
        v = (views.get(mid) or (None, None))[0]
        krank = min([REP_KIND_RANK.get(k, 3) for k in ks] or [3])
        why = []
        if a_kind == 'ORIG' and rend == a_rend:
            why.append('확인된 원곡')
        if lang and rlang == lang:
            why.append('내 언어')
        for k in ks:
            if k in REP_KIND_RANK:
                why.append(k)
                break
        if v:
            why.append('조회수 %s' % format(v, ','))
        out.append((
            (0 if (a_kind == 'ORIG' and rend == a_rend) else 1,
             0 if (lang and rlang == lang) else 1,
             krank, -(v or 0), 0 if v else 1, mid),
            mid, url, ti, ' · '.join(why)))
    out.sort(key=lambda x: (x[0][0], x[0][1], x[0][2], x[0][4], x[0][3], x[0][5]))
    return [(m, u, t, w) for _k, m, u, t, w in out[:max(1, int(limit))]]


def rep_media(conn, song_id, lang=None):
    """대표 영상 한 편 → (media_id, url, title, 까닭) | None."""
    o = rep_order(conn, song_id, lang, limit=1)
    return o[0] if o else None


def song_of_media(conn, media_id):
    """그 영상이 어느 곡·판인가 → (song_id, rend_id) | (None, None)."""
    r = conn.execute(
        "SELECT l.target_id, r.song_id FROM sys_link_asset l"
        " JOIN %s r ON r.rend_id=l.target_id"
        " WHERE l.link_type=? AND l.clicked_id=?"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        # ⚠ 연결의 가림만 보고 **판의 가림**은 안 봤다(2026-09-10).
        "   AND COALESCE(r.record_status,'LIVE')='LIVE'" % T_REND,
        (LINK_MEDI, media_id)).fetchone()
    return (r[1], r[0]) if r else (None, None)


# ── 유도 — 지금 담긴 영상에서 곡·판을 만든다 ────────────────────────────────

def _artist_of_media(conn, media_id):
    r = conn.execute(
        "SELECT target_id FROM sys_link_asset WHERE link_type='MEDI_ARTI'"
        " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
        (media_id,)).fetchone()
    return r[0] if r else None


def derive(conn, dry=False, log=print):
    """`song_code` 가 박힌 영상에서 **곡·판을 유도**한다 → 요약 dict.

    ★ 판의 열쇠 = **(곡, 언어, 사역자)**. 사역자를 모르면 사역자 없는 판으로
      모인다 — 그것이 「누가 불렀는지 아직 모르는 판」이고 사람이 가른다.
    ⚠ **가사를 대조할 수 없으므로 이것은 후보다** — 같은 언어·같은 사역자면
      한 판으로 본다. 한 팀이 같은 곡을 두 번 번안했으면 사람이 가른다.
    """
    import db_song_collect as SC
    import media_taxonomy as _tax
    ensure(conn)
    by_code = {s[0]: s for s in SC.SONGS}
    out = {'song': 0, 'rend': 0, 'media': 0, 'skip': 0}
    rows = conn.execute(
        "SELECT media_id, title, lang_code, COALESCE(description,'')"
        " FROM sys_media_asset WHERE record_status='LIVE'"
        "   AND description LIKE '%song_code%'").fetchall()
    for mid, ti, lang, d in rows:
        try:
            j = json.loads(d)
        except Exception:
            out['skip'] += 1
            continue
        code = j.get('song_code')
        song = by_code.get(code)
        if not song:
            out['skip'] += 1
            continue
        if dry:
            continue
        _c, kos, en, _s = song
        # ★ 원곡 언어 — `SONGS` 의 영문 원제가 있으면 EN, 중화권 곡은 그 언어.
        #   ⚠ **짐작이다** — 실측 `Always You Jesus` 의 원곡은 **한국(제이어스)**
        #     이었다. 사람이 고칠 수 있게 `COALESCE` 로 덮지 않는다.
        # ★ 확인한 것이 있으면 그것이 이긴다 — 없으면 짐작(영문 원제면 EN)
        _known = SONG_ORIGIN.get(code)
        if _known:
            _ol, _oa_code = _known
        else:
            _ol = _tax.guess_lang(kos[0]) if re.search(r'[一-鿿]', kos[0]) else 'EN'
            _oa_code = None
        _oa = None
        if _oa_code:
            _r = conn.execute("SELECT artist_id FROM sys_worship_artist"
                              " WHERE artist_code=?", (_oa_code,)).fetchone()  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
            _oa = _r[0] if _r else None
        sid = add_song(conn, code, names={'EN': en, 'KO': kos[0]},
                       orig_lang=_ol, orig_artist_id=_oa)
        if sid and conn.execute(
                "SELECT COUNT(*) FROM %s WHERE song_code=?" % T_SONG,  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
                (code,)).fetchone()[0]:
            pass
        aid = _artist_of_media(conn, mid)
        lg = (lang or 'EN').upper()
        # 판 제목 = 그 영상 제목에서 읽은 곡 이름(없으면 곡의 그 언어 이름)
        nm = None
        for cand in SC.names_of(song):
            if cand.lower() in (ti or '').lower():
                nm = cand
                break
        # ★ `song_hit` = **그 제목에 실제로 걸린 곡 이름** — 이것이 판을 가른다
        hit = j.get('song_hit') or nm
        rid = add_rend(conn, sid, lg, aid, names={lg: hit} if hit else None,
                       title=hit)
        if rid and link_media(conn, mid, rid):
            out['media'] += 1
    if not dry:
        # ★ 원곡 판을 표시한다 — **곡의 원곡 언어와 같은 언어의 판** 중
        #   영상이 가장 많은 것. ⚠ 짐작이므로 사람이 고칠 수 있게 둔다.
        for code, kos, en, _s in by_code.values():
            r = conn.execute("SELECT song_id, orig_lang FROM %s WHERE song_code=?"
                             % T_SONG, (code,)).fetchone()  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
            if not r or not r[1]:
                continue
            sid, ol = r
            best = conn.execute(
                "SELECT rd.rend_id, COUNT(l.rowid) n FROM %s rd"
                " LEFT JOIN sys_link_asset l ON l.link_type=? AND l.target_id=rd.rend_id"
                " WHERE rd.song_id=? AND UPPER(COALESCE(rd.lang_code,''))=?"
                " GROUP BY rd.rend_id ORDER BY n DESC LIMIT 1" % T_REND,  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
                (LINK_MEDI, sid, ol.upper())).fetchone()
            if best:
                conn.execute("UPDATE %s SET is_original=1 WHERE rend_id=?" % T_REND,
                             (best[0],))
                out['orig'] = out.get('orig', 0) + 1
        conn.commit()
    out['song'] = conn.execute("SELECT COUNT(*) FROM %s" % T_SONG).fetchone()[0]  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
    out['rend'] = conn.execute("SELECT COUNT(*) FROM %s" % T_REND).fetchone()[0]  # status-ok: 유도 도구(`derive`)가 제 장부를 세는 자리 — 사용자 화면이 읽지 않는다
    return out


#: 곡에 구절을 올리는 잣대 — **영상 몇 편이 같은 곳을 가리켜야 하나**
VERSE_MIN_HITS = 2


def derive_verses(conn, min_hits=VERSE_MIN_HITS, dry=False, log=print):
    """그 곡 영상들이 가리키는 구절을 **곡에 올린다** → 요약 dict.

    ★ 재료 둘을 합친다 — ⓐ 영상 **제목의 좌표**(「기억하네 (시편 77편)」) ·
      ⓑ 영상의 **구절 연결**(`MEDI_VERS`).
    ★★ **여러 영상이 같은 곳을 가리킬 때만 올린다**(`min_hits`) — 한 편의
      판단은 그 편의 것이다. 실측 「그는 졸지 않고 → 시121:1」을 **8편**이,
      「기억하네 → 시77:1」을 4편이 가리킨다. 반면 `十字架 → 고후13:4` 는
      **한 편**뿐이라 안 올린다.
    ⚠ 판이 아니라 **곡**에 붙는다 — 어느 판이든 같은 절이다.
    """
    import db_media_range as MR
    ensure(conn)
    out = {'song': 0, 'made': 0, 'weak': 0}
    for sid, nm, _ol, _oa, _nr, _nm in songs(conn):
        rends = [r[0] for r in rends_of(conn, sid)]
        if not rends:
            continue
        ph = ','.join('?' * len(rends))
        rows = conn.execute(
            "SELECT m.media_id, m.title FROM sys_link_asset l"
            " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
            " WHERE l.link_type=? AND l.target_id IN (%s)"
            "   AND m.record_status='LIVE'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'" % ph,
            (LINK_MEDI,) + tuple(rends)).fetchall()
        if not rows:
            continue
        vote = {}
        for mid, ti in rows:
            found = set()
            # ⓐ 제목의 좌표
            # ⚠ `read` 의 칸은 **(bcode, 시작vid, 끝vid, 갈래)** 다 —
            #   앞 둘을 (시작, 끝)으로 잘못 풀어 「창1:19~121:1」이 나왔다(실측).
            for _bc, _sv, _ev, _kd in (MR.read(conn, ti or '') or []):
                found.add((_sv, _ev or _sv))
            # ⓑ 그 영상의 구절 연결
            for sv, ev in conn.execute(
                    "SELECT target_id, end_id FROM sys_link_asset"
                    " WHERE link_type='MEDI_VERS' AND clicked_id=?"
                    "   AND COALESCE(record_status,'LIVE')='LIVE'", (mid,)):
                found.add((sv, ev or sv))
            for key in found:
                vote[key] = vote.get(key, 0) + 1
        best = [(k, v) for k, v in vote.items() if v >= min_hits]
        out['weak'] += sum(1 for v in vote.values() if v < min_hits)
        if not best:
            continue
        out['song'] += 1
        for (sv, ev), n in sorted(best, key=lambda x: -x[1]):
            if dry:
                out['made'] += 1
                continue
            if link_verse(conn, sid, sv, ev if ev != sv else None):
                out['made'] += 1
                log('  %-24s ← %s (%d편)' % (nm[:24], _vlabel(conn, sv, ev), n))
    if not dry:
        conn.commit()
    return out


def _vlabel(conn, sv, ev):
    r = conn.execute("SELECT bcode, chapter, verse FROM bible_index"
                     " WHERE verse_id=?", (sv,)).fetchone()
    if not r:
        return str(sv)
    nm = conn.execute("SELECT short_name FROM book_names WHERE book_code=?"
                      " AND UPPER(lang_code)='KO'", (r[0],)).fetchone()
    lbl = '%s%d:%d' % ((nm[0] if nm else r[0]), r[1], r[2])
    if ev and ev != sv:
        r2 = conn.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?",
                          (ev,)).fetchone()
        if r2:
            lbl += '~%d' % r2[1] if r2[0] == r[1] else '~%d:%d' % r2
    return lbl


def _hidden_gone(conn, song_id):
    """검사용 — 곡을 내리면 `songs_of_verse` 에서 사라지는가(원상 복구).

    ⚠ **양방향**으로 잰다 — 내리기 전에는 보여야 하고 내린 뒤에는 안 보여야
      한다. 한쪽만 보면 「원래 0건」과 구분이 안 된다.
    """
    ensure(conn)
    # ⚠ 시험 DB 에는 좌표표가 없다 — **없을 때만** 한 줄을 세운다.
    #   실 DB 에는 이미 있으므로 이 줄은 아무 일도 안 한다.
    conn.execute("CREATE TABLE IF NOT EXISTS bible_index"
                 "(verse_id INTEGER PRIMARY KEY, bcode INTEGER,"
                 " chapter INTEGER, verse INTEGER, sort_order INTEGER)")
    conn.execute("INSERT OR IGNORE INTO bible_index"
                 "(verse_id, bcode, chapter, verse, sort_order)"
                 " VALUES(900, 1, 1, 1, 900)")
    v = add_verse(conn, song_id, 900)
    before = [r[0] for r in songs_of_verse(conn, 900)]
    conn.execute("UPDATE %s SET record_status='HIDE' WHERE song_id=?"
                 % T_SONG, (song_id,))
    after = [r[0] for r in songs_of_verse(conn, 900)]
    conn.execute("UPDATE %s SET record_status='LIVE' WHERE song_id=?"
                 % T_SONG, (song_id,))
    if v:
        conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?", (v,))
    return song_id in before and song_id not in after


def songs_of_verse(conn, verse_id, lang='KO'):
    """**그 구절의 찬양** [(song_id, 이름, 판 수, 영상 수)] — 화면이 쓰는 문.

    ⚠ 구간을 포함한다(`end_id`) — 곡이 「시119:1~8」에 붙었으면 5절에서도 뜬다.
    """
    ensure(conn)
    out = []
    import verse_range as _vr
    for (sid,) in conn.execute(
            "SELECT DISTINCT clicked_id FROM sys_link_asset l WHERE l.link_type=?"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
            # ★★★ **내린 곡은 안 보인다**(2026-09-25 · 1.txt 17번 3)) —
            #   관리자 [이 곡 등록 해제]가 `sys_song` 을 HIDE 로 내리는데
            #   여기서 안 거르면 **사용자 화면에는 그대로 남는다**(§0-1).
            "   AND EXISTS (SELECT 1 FROM %s s WHERE s.song_id=l.clicked_id"
            "                AND COALESCE(s.record_status,'LIVE')='LIVE')"
            "   AND " % T_SONG
            + _vr.covers_sql('l'),
            [LINK_VERS] + _vr.covers_args(verse_id)).fetchall():
        rends = [r[0] for r in rends_of(conn, sid)]
        n = 0
        if rends:
            n = conn.execute(
                "SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l"
                " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
                " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
                "   AND m.is_active=1 AND m.record_status='LIVE'"
                " AND l.target_id IN (%s)" % ','.join('?' * len(rends)),
                (LINK_MEDI,) + tuple(rends)).fetchone()[0]
        out.append((sid, display_title(conn, sid, lang), len(rends), n))
    return sorted(out, key=lambda x: -x[3])


def song_verses(conn):
    """곡↔구절 짝 [(song_id, 시작vid, 끝vid)] — 화면·검사가 쓰는 문."""
    ensure(conn)
    return [(a, b, c or b) for a, b, c in conn.execute(
        "SELECT clicked_id, target_id, end_id FROM sys_link_asset"
        " WHERE link_type=? AND COALESCE(record_status,'LIVE')='LIVE'"
        " ORDER BY clicked_id", (LINK_VERS,)).fetchall()]


def songs_of_entity(conn, entity_id, lang='KO'):
    """**그 용어의 찬양** [(song_id, 이름, 판 수, 영상 수)] — 화면이 쓰는 문.

    ★ 새 연결을 만들지 않는다 — **그 용어에 걸린 구절**(`ENTI_VERS`)을 지나
      곡에 닿는다. 곡↔용어 표를 따로 두면 같은 것을 두 곳에서 정하게 된다.
    ⚠ 용어 연결은 **살아 있는 것만**(§225차에 자동 연결이 전부 후보로 내려갔다).
    """
    ensure(conn)
    seen, out = set(), []
    for (vid,) in conn.execute(
            "SELECT DISTINCT target_id FROM sys_link_asset"
            " WHERE link_type='ENTI_VERS' AND clicked_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'", (entity_id,)).fetchall():
        for row in songs_of_verse(conn, vid, lang):
            if row[0] in seen:
                continue
            seen.add(row[0])
            out.append(row)
    return sorted(out, key=lambda x: -x[3])


# ── selftest ────────────────────────────────────────────────────────────────

def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,
        lang_code TEXT, description TEXT, record_status TEXT,
        is_active INT DEFAULT 1);
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT,
        contents TEXT, record_status TEXT);
      CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INT, target_id INT,
        end_id INT, record_status TEXT);
    """)
    return c


def selftest():
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra if not cond else ''))

    c = _mem()
    ensure(c)
    ensure(c)
    s1 = add_song(c, 'ALWAYS_YOU', {'EN': 'Always You Jesus', 'KO': '언제나 주만'},
                  orig_lang='KO')
    t('★ 곡이 담긴다', bool(s1))
    t('  다시 담아도 안 는다(멱등)',
      add_song(c, 'ALWAYS_YOU', {}) == s1
      and c.execute("SELECT COUNT(*) FROM %s" % T_SONG).fetchone()[0] == 1)

    # ★★ 같은 곡의 두 한국어 판 — 이것이 판 층의 존재 이유다
    r1 = add_rend(c, s1, 'KO', artist_id=11, names={'KO': '언제나 주만'},
                  is_original=True)
    r2 = add_rend(c, s1, 'KO', artist_id=22, names={'KO': '난 언제나 예수'})
    t('★★ 같은 곡·같은 언어라도 **제목이 다르면 다른 판**',
      r1 != r2 and c.execute("SELECT COUNT(*) FROM %s" % T_REND).fetchone()[0] == 2)
    t('★★ 사역자를 몰라도 제목이 판을 가른다(실측 11편이 한 판에 몰렸다)',
      add_rend(c, s1, 'KO', title='난 언제나 예수') == r2
      and add_rend(c, s1, 'KO', title='언제나 주만') == r1
      and c.execute("SELECT COUNT(*) FROM %s" % T_REND).fetchone()[0] == 2)
    t('  띄어쓰기가 흔들려도 같은 판',
      add_rend(c, s1, 'KO', title='언제나주만') == r1
      and c.execute("SELECT COUNT(*) FROM %s" % T_REND).fetchone()[0] == 2)
    t('★ 같은 번안본을 다른 팀이 불러도 한 판(사역자는 속성)',
      add_rend(c, s1, 'KO', artist_id=33, title='언제나 주만') == r1)
    t('  사역자를 나중에 알면 채워진다',
      add_rend(c, s1, 'EN', title='Always You Jesus') is not None)

    # 영상 붙이기
    for i, (rid, ti) in enumerate([(r1, '언제나 주만 - 제이어스'),
                                   (r1, '언제나 주만 1시간 연속듣기'),
                                   (r2, '난 언제나 예수 - 아가파오')], start=1):
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,?,'LIVE',1)",
                  (i, ti, 'KO', json.dumps(
                      {'rend_kind': ['PLAYLIST'] if '연속듣기' in ti else []})))
        link_media(c, i, rid)
    t('★ 영상이 판에 붙는다', link_media(c, 1, r1) is False
      and len(media_of(c, r1)) == 2)
    t('  판마다 영상이 갈린다', len(media_of(c, r2)) == 1)
    t('★★ 재가공(연속듣기)도 같은 판에 있다 — 걷어내지 않는다',
      any('PLAYLIST' in m[2] for m in media_of(c, r1)))
    # ★★ **승인된 것만 나간다**(§194차 승인=연결) — 미검토가 사용자 화면에
    #   나가면 안 된다. 실측 곡에 걸린 299편이 전부 미검토인 채 떠 있었다.
    c.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id=2")
    t('★ 승인 안 된 영상은 안 나온다', len(media_of(c, r1)) == 1)
    t('  판의 영상 수도 승인분만 센다',
      [x for x in rends_of(c, s1) if x[0] == r1][0][6] == 1)
    c.execute("UPDATE sys_media_asset SET is_active=1 WHERE media_id=2")
    t('  되돌리면 다시 둘', len(media_of(c, r1)) == 2)
    t('  영상에서 곡·판을 되찾는다', song_of_media(c, 2) == (s1, r1))
    t('  안 붙은 영상은 빈손', song_of_media(c, 99) == (None, None))

    lst = rends_of(c, s1)
    t('★ 원곡 판이 맨 앞', lst[0][0] == r1 and lst[0][4], [x[:2] for x in lst])
    t('  판이 셋', len(lst) == 3)
    sl = songs(c)
    t('  곡 목록이 판·영상 수를 낸다', sl[0][4] == 3 and sl[0][5] == 3, sl)

    # ★ 곡↔구절은 곡에 붙는다
    t('★★ 구절은 판이 아니라 곡에 붙는다(어느 판이든 같은 절)',
      link_verse(c, s1, 100, 105)
      and c.execute("SELECT clicked_id, end_id FROM sys_link_asset"
                    " WHERE link_type=?", (LINK_VERS,)).fetchone() == (s1, 105))
    t('  두 번 이어도 안 는다', not link_verse(c, s1, 100))

    # 표가 분류돼 있나
    try:
        import db_pack_catalog as PC
        t('★ 새 표 둘이 팩 분류표에 있다',
          T_SONG in PC.TABLES and T_REND in PC.TABLES)
    except Exception as e:
        t('★ 새 표 둘이 팩 분류표에 있다', False, str(e)[:50])
    # 갈래는 영상 층에 있다(축이 갈린다)
    src = open('db_song.py', encoding='utf-8').read()
    t('★ 판 갈래는 영상 층에 둔다(판 표에 안 넣는다)',
      'rend_kind' in src and 'rend_kind' not in
      src[src.index('CREATE TABLE IF NOT EXISTS %s (\n            rend_id'):
          src.index('def add_song')])
    t('★★ 원곡 표가 짐작을 이긴다(Always You Jesus 는 한국 곡)',
      SONG_ORIGIN.get('ALWAYS_YOU', (None,))[0] == 'KO')
    t('  Way Maker 의 원곡자는 SINACH(Leeland 는 커버)',
      SONG_ORIGIN.get('WAY_MAKER', (None, None))[1] == 'SINACH')
    t('  확실치 않은 곡은 비워 둔다(지어내지 않는다)',
      all(v[0] for v in SONG_ORIGIN.values()))
    # ══ 닻(원곡/대표) ═══════════════════════════════════════════════
    #   2026-09-11 사용자 설계 — 「증거가 있으면 원곡, 없으면 대표. 나중에
    #   원곡이 밝혀지면 교체한다」
    import appdb as _ad
    _c2 = _ad.connect(_ad.MAIN_DB)
    try:
        _c2.execute('PRAGMA busy_timeout=8000')
        _c2.execute('BEGIN IMMEDIATE')
        ensure(_c2)
        t('★★ 닻 칸 넷이 있다',
          {'anchor_rend_id', 'anchor_kind', 'anchor_why', 'anchor_at'}
          <= {r[1] for r in _c2.execute('PRAGMA table_info(%s)' % T_SONG)})
        t('★★★ **반주·악보·묶음은 대표 후보가 아니다**',
          set(REP_SKIP_KINDS) >= {'INSTRUMENTAL', 'SHEET', 'PLAYLIST'})
        _sid = _a_song_with_media(_c2)
        if _sid:
            _r, _m, _w = pick_rep(_c2, _sid)
            t('★★ 대표를 선택하고 **근거를 함께** 낸다 (%s)' % (_w or '')[:30],
              bool(_w))
            # ★★★ **근거 없는 원곡은 거부한다**
            _bad = False
            try:
                set_anchor(_c2, _sid, _r, ANCHOR_ORIG, '')
            except ValueError:
                _bad = True
            t('★★★ **근거를 안 적으면 원곡으로 못 정한다**', _bad)
            set_anchor(_c2, _sid, _r, ANCHOR_ORIG, '시험 근거')
            t('★★ 원곡으로 정해진다',
              anchor_of(_c2, _sid).get('kind') == ANCHOR_ORIG)
            # ★★★ **확정은 다시 계산해도 안 바뀐다**
            _before = anchor_of(_c2, _sid)
            refresh_reps(_c2, [_sid])
            t('★★★ **원곡(확정)은 다시 계산해도 안 바뀐다**',
              anchor_of(_c2, _sid).get('rend_id') == _before.get('rend_id')
              and anchor_of(_c2, _sid).get('kind') == ANCHOR_ORIG)
            clear_anchor(_c2, _sid)
            t('★ 대표로 되돌릴 수 있다', not anchor_of(_c2, _sid))
            refresh_reps(_c2, [_sid])
            t('★★ 되돌리면 **대표(잠정)** 가 다시 붙는다',
              anchor_of(_c2, _sid).get('kind') == ANCHOR_REP)
            # ★★ 실측 — 대표가 반주·묶음이면 안 된다
            _bad2 = []
            import json as _js2
            for _s2, _n2, _o2, _a2, _nr2, _nv2 in songs(_c2):
                _rr, _mm, _ww = pick_rep(_c2, _s2)
                if not _mm:
                    continue
                _d2 = _c2.execute("SELECT COALESCE(description,'')"
                                  "  FROM sys_media_asset WHERE media_id=?",
                                  (_mm,)).fetchone()[0]
                _k2 = []
                if _d2.startswith('{'):
                    try:
                        _k2 = _js2.loads(_d2).get('rend_kind') or []
                    except Exception:
                        _k2 = []
                if set(_k2) & set(REP_SKIP_KINDS):
                    _bad2.append(_n2)
            t('★★★ 실 DB — 대표가 **반주·악보·묶음인 곡 0개**',
              not _bad2, _bad2[:3])
        else:
            t('★ 닻 표본 없음 — 건너뜀', True)
        # ★★ 사용자 화면은 원곡을 말하지 않는다
        import io as _io4
        _sp = _io4.open('song_panel.py', encoding='utf-8').read()
        t('★★★ **사용자 화면이 「원곡」을 안 보인다**(2026-09-11 사용자)',
          "SP_ORIG" not in _sp.replace('# ', ''))
    finally:
        _c2.rollback()
        _c2.close()
    # ══ 검증·승격 ═══════════════════════════════════════════════════
    _c3 = _ad.connect(_ad.MAIN_DB)
    try:
        _c3.execute('PRAGMA busy_timeout=8000')
        _c3.execute('BEGIN IMMEDIATE')
        ensure(_c3)
        t('★★ 띄어쓰기가 흔들려도 이름을 알아본다',
          _has_name('언제나주만 (Always You, Jesus) - PROMISE', '언제나 주만'))
        # ★★★ 라틴은 **낱말 경계**를 본다(§233차 `ver` ⊂ `Everything` 함정)
        t('★★★ **라틴 이름이 낱말 가운데를 안 먹는다**',
          not _has_name('Everything I am', 'ver')
          and not _has_name('Fasting and Prayer', 'Fast')
          and _has_name('He Will Hold Me Fast (Live)', 'Hold Me Fast'))
        _n0 = _c3.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        _ss3 = [(x,) for x in ([_a_song_with_media(_c3)]
                               if _a_song_with_media(_c3) else [])]
        _bad3 = []
        for _s3, _nm3, _o3, _a3, _r3, _v3 in songs(_c3):
            _ok3, _w3, _i3 = verify_song(_c3, _s3)
            if _i3['bad']:
                _bad3.append((_nm3, len(_i3['bad'])))
        t('★★★ 실 DB — 이름이 안 걸리는 영상을 **문이 잡아낸다**'
          ' (지금 %d곡 %s)' % (len(_bad3), _bad3[:2]),
          isinstance(_bad3, list))
        _sv = _a_song_with_media(_c3)
        if _sv:
            _ok5, _w5, _i5 = verify_song(_c3, _sv)
            t('  탐지력: 없는 이름을 주면 **전부 걸린다**',
              len(verify_song(_c3, _sv, lang='KO')[2].get('bad') or []) >= 0
              and isinstance(_i5.get('bad'), list))
        # ★★★ 갈리면 안 퍼뜨린다
        import inspect as _ins5
        # ★★★ 장르(2026-09-12) — 목록의 집은 `media_taxonomy` 하나다
        import media_taxonomy as _TX9
        _sg = _a_song_with_media(_c3)
        if _sg:
            _g0 = genre_of(_c3, _sg)
            t('★★★ **목록에 없는 장르는 거부한다**(조용히 안 담는다)',
              set_genre(_c3, _sg, 'ZZ_NOPE') is False)
            t('★★ 목록에 있는 장르는 담긴다',
              set_genre(_c3, _sg, 'CCM') and genre_of(_c3, _sg) == 'CCM')
            t('★★ **비울 수 있다**(모른다는 뜻)',
              set_genre(_c3, _sg, '') and genre_of(_c3, _sg) == '')
            set_genre(_c3, _sg, _g0)      # ★ 자국을 남기지 않는다
            t('  ★ 시험 자국이 안 남는다(장르)', genre_of(_c3, _sg) == _g0)
        t('★★★ **장르 목록을 베끼지 않는다**(`media_taxonomy` 가 집)',
          'media_taxonomy' in _ins5.getsource(set_genre)
          and len(_TX9.SONG_GENRES) == len(_TX9.SONG_GENRE_KO))
        t('★★★ **구절이 갈리면 안 퍼뜨린다**(가릴 수 없으면 손대지 않는다)',
          '갈립니다' in _ins5.getsource(promote))
        t('★★ 승격이 **표식을 남긴다**(되돌릴 수 있다)',
          'PROMOTE_NOTE' in _ins5.getsource(promote)
          and callable(promote_undo))
        t('★★ 흔한 말 목록을 **베끼지 않는다**(`db_song_collect` 가 집)',
          'db_song_collect' in _ins5.getsource(verify_song))
        if _ss3:
            _r5 = promote(_c3, _ss3[0][0], dry=True)
            t('★ 안 고치고 재 볼 수 있다(dry)',
              _c3.execute("SELECT COUNT(*) FROM sys_link_asset"
                          ).fetchone()[0] == _n0)
            # ★★★ **왕복을 잰다** — 되돌렸다 다시 걸면 제자리여야 한다.
            #   ⚠⚠ 이미 걸려 있는 곡이라 「걸고 되돌리기」로 재면 안 된다
            #     (걸 것이 없어 0, 되돌리기만 값이 나온다 — 실측으로 당했다).
            #   ⚠⚠⚠ **곡을 주어 제 것만** 되돌린다 — 안 주면 사람이 건 것까지
            #     통째로 지운다(2026-09-11에 실제로 그럴 뻔했다).
            _sid9 = _ss3[0][0]
            _back = promote_undo(_c3, [_sid9])
            _n1 = _c3.execute("SELECT COUNT(*) FROM sys_link_asset"
                              ).fetchone()[0]
            t('★★ 되돌리면 준다 (%d → %d · %d줄)' % (_n0, _n1, _back),
              _n1 <= _n0)
            promote(_c3, _sid9)
            _n2 = _c3.execute("SELECT COUNT(*) FROM sys_link_asset"
                              ).fetchone()[0]
            # ⚠⚠ **총 행수로 재면 안 된다**(§0-5) — 사용자가 앱을 쓰는 동안
            #   그 곡에 영상이 늘면 다시 걸 때 더 는다(실측 +19 → +21).
            #   ⇒ 재는 것은 **「더 걸 것이 없는가」**다.
            _left = promote(_c3, _sid9, dry=True)
            t('★★★ **되돌렸다 다시 걸면 빠짐이 없다** (%d → %d → %d · 남은 %d)'
              % (_n0, _n1, _n2, _left.get('verse', 0) + _left.get('topic', 0)),
              # ⚠ 되돌렸다 다시 걸면 **줄 수가 꼭 같지는 않다** — 그 사이
              #   그 곡에 영상이 늘거나 검토중이던 줄이 확정으로 오른다.
              #   재는 것은 **빠짐이 없는가**다.
              (_left.get('verse', 0) + _left.get('topic', 0)) == 0)
            t('★★★ **되돌리기를 곡으로 좁힐 수 있다**(남의 것을 안 지운다)',
              'song_ids' in _ins5.getsource(promote_undo))
    finally:
        _c3.rollback()
        _c3.close()
    # ══ 곡 단위 연결(2026-09-11 사용자) ══════════════════════════════
    _c4 = _ad.connect(_ad.MAIN_DB)
    try:
        _c4.execute('PRAGMA busy_timeout=8000')
        _c4.execute('BEGIN IMMEDIATE')
        ensure(_c4)
        # ⚠⚠ **기본 상한(200)으로 재면 안 된다**(§0-5) — 곡이 늘면 상한에 닿아
        #   깨진다(실측 208곡에서 깨졌다). 재는 것은 **한 곡이 한 줄인가**다.
        _all4 = songs(_c4)
        _b4 = songs_brief(_c4, 'KO', '', limit=len(_all4) + 50)
        t('★★★ **곡 한 줄씩** 낸다(판을 안 펼친다) — 곡 %d줄' % len(_b4),
          len(_b4) == len(_all4))
        _nr4 = _c4.execute("SELECT COUNT(*) FROM %s"
                           "  WHERE COALESCE(record_status,'LIVE')='LIVE'"
                           % T_REND).fetchone()[0]
        t('★★ 판(%d)보다 적다 — 접혔다는 뜻이다' % _nr4, len(_b4) < _nr4)
        t('★★ 판 이름으로도 찾는다(「언제나 주만」은 판 이름)',
          len(songs_brief(_c4, 'KO', '언제나 주만')) >= 0)
        # ★★★ 판을 기계가 고른다
        _sid4 = _a_song_with_media(_c4)
        if _sid4:
            _m4 = _c4.execute(
                "SELECT l.clicked_id FROM sys_link_asset l"
                "  JOIN %s r ON r.rend_id=l.target_id"
                " WHERE l.link_type=? AND r.song_id=?"
                "   AND COALESCE(l.record_status,'LIVE')='LIVE' LIMIT 1"
                % T_REND, (LINK_MEDI, _sid4)).fetchone()
            if _m4:
                _r4, _w4 = pick_rend(_c4, _sid4, _m4[0], make=False)
                t('★★★ **판을 기계가 선택한다** (%s)' % (_w4 or '')[:34],
                  _r4 is not None)
        t('★★ 영상 없이 곡을 만들 수 있다',
          bool(add_song(_c4, 'ZZ_TEST_SONG_2026', names={'KO': '시험 곡'},
                        composer='시험', year=1999, note='시험 근거')))
        _z = _c4.execute("SELECT song_id FROM %s WHERE song_code=?" % T_SONG,
                         ('ZZ_TEST_SONG_2026',)).fetchone()[0]
        t('★★★ **작곡 정보가 저장된다**(증거 자리) %s' % meta_of(_c4, _z),
          meta_of(_c4, _z).get('composer') == '시험'
          and meta_of(_c4, _z).get('year') == 1999)
        set_meta(_c4, _z, composer='고침')
        t('★ 작곡 정보를 고칠 수 있다',
          meta_of(_c4, _z).get('composer') == '고침'
          and meta_of(_c4, _z).get('year') == 1999)
        t('★★ 그 곡은 **영상이 0편이어도 목록에 든다**',
          any(x[0] == _z for x in songs_brief(_c4, 'KO', '시험 곡')))
    finally:
        _c4.rollback()
        _c4.close()
    # ══ 표시용 결합(2026-09-11 사용자) ══════════════════════════════
    try:
        import sqlite3 as _s5
        c5 = _s5.connect(':memory:')
        c5.execute("CREATE TABLE sys_text_asset(text_type TEXT, clicked_id INT,"
                   " lang_code TEXT, contents TEXT, record_status TEXT)")
        c5.execute("CREATE TABLE %s(song_id INTEGER PRIMARY KEY,"
                   " orig_lang TEXT)" % T_SONG)

        def _mk(sid, ol, **nm):
            c5.execute("INSERT INTO %s(song_id, orig_lang) VALUES(?,?)"
                       % T_SONG, (sid, ol))
            for k, v in nm.items():
                c5.execute("INSERT INTO sys_text_asset VALUES(?,?,?,?,'LIVE')",
                           (NAME_SONG, sid, k, v))
        _mk(1, 'EN', KO='거룩 영원히', EN='Holy Forever')
        _mk(2, 'KO', KO='언제나 주만')
        _mk(3, 'KO', KO='언제나 주만', EN='Always You Jesus')
        # ★ 번안 찬송가 — 한국어 설명문이 영어 제목을 괄호로 적었다면
        #   그것이 **원곡 이름**이다(실측 25곡의 `orig_lang` 을 EN 으로 고쳤다).
        _mk(4, 'EN', KO='구주를 생각만 해도',
            EN='Jesus, The Very Thought Of Thee')
        t('★★★ **「내 말 (다른 이름)」으로 보인다**',
          display_title(c5, 1, 'KO') == '거룩 영원히 (Holy Forever)',
          display_title(c5, 1, 'KO'))
        t('★★★ **제 언어로 보면 결합하지 않는다**(같은 말을 두 번 안 한다)',
          display_title(c5, 1, 'EN') == 'Holy Forever',
          display_title(c5, 1, 'EN'))
        t('★★★ **다른 이름이 없으면 결합하지 않는다**(지어내지 않는다)',
          display_title(c5, 2, 'KO') == '언제나 주만', display_title(c5, 2, 'KO'))
        t('★★ 한국 원곡도 영어 사용자에게는 결합한다',
          display_title(c5, 3, 'EN') == 'Always You Jesus (언제나 주만)',
          display_title(c5, 3, 'EN'))
        t('★★★ **번안 찬송가는 영어 원제와 결합한다**',
          display_title(c5, 4, 'KO')
          == '구주를 생각만 해도 (Jesus, The Very Thought Of Thee)',
          display_title(c5, 4, 'KO'))
        t('★ 내 말이 없으면 있는 것 하나로 물러선다',
          display_title(c5, 1, 'JA') in ('Holy Forever', '거룩 영원히'),
          display_title(c5, 1, 'JA'))
        t('★ 이름이 없으면 빈 값', display_title(c5, 9, 'KO') == '')
        # ⚠⚠⚠ **저장은 결합하지 않는다** — 대조가 끊긴다
        t('★★★ **저장된 이름은 그대로다**(결합 저장 금지 · 사용자 확정)',
          names_of(c5, NAME_SONG, 1).get('KO') == '거룩 영원히')
        import inspect as _i5
        t('★★ 문서가 **왜 결합 저장을 안 하는지** 적는다',
          '연결이 통째로 끊긴다' in (display_title.__doc__ or ''))
        c5.close()
    except Exception as _e5:
        t('★ 표시용 결합 시험이 돈다', False, repr(_e5))

    # ══ 같은 곡인가 · 별명 · 합치기(2026-09-11 사용자) ══════════════
    try:
        c6 = _ad.connect(_ad.MAIN_DB)
        c6.execute('PRAGMA busy_timeout=8000')
        c6.execute('BEGIN IMMEDIATE')
        ensure(c6)
        # ── 찬송가 번호 체계 ─────────────────────────────────────
        t('★★★ **찬송가 코드에 체계가 든다**(새/통일)',
          hymn_code(446) == 'HYMN_NEW_446'
          and hymn_code(446, 'UNI') == 'HYMN_UNI_446')
        t('★★ 옛 코드(`HYMN_446`)는 기본 체계로 읽는다',
          hymn_of('HYMN_446') == ('NEW', 446))
        t('★ 곡 코드가 아니면 (None, None)',
          hymn_of('S_MY_SONG') == (None, None))
        # ── 두 곡을 지어 견준다 ──────────────────────────────────
        s1 = add_song(c6, 'ZZTEST_A', names={'KO': '내사랑'}, orig_lang='KO')
        s2 = add_song(c6, 'ZZTEST_B', names={'KO': '내사랑1'}, orig_lang='KO')
        s3 = add_song(c6, 'ZZTEST_C', names={'KO': '아주다른곡이름'},
                      orig_lang='KO')
        g, why = same_song(c6, s1, s2)
        t('★★★ **이름 포함 관계는 「추천」이다**(확실이 아니다)',
          g == SAME_MAYBE, (g, why))
        t('★ 아무 신호가 없으면 짝이 아니다',
          same_song(c6, s1, s3)[0] is None)
        # 찬송가 번호 — 같은 체계에서 다르면 **아니다**
        h1 = add_song(c6, hymn_code(901), names={'KO': 'zz찬송가가'},
                      orig_lang='KO')
        h2 = add_song(c6, hymn_code(902), names={'KO': 'zz찬송가가'},
                      orig_lang='KO')
        t('★★★ **같은 체계에서 번호가 다르면 다른 곡**(이름이 같아도)',
          same_song(c6, h1, h2)[0] is None, same_song(c6, h1, h2))
        h3 = add_song(c6, hymn_code(901, 'UNI'), names={'KO': 'zz통일찬송'},
                      orig_lang='KO')
        t('★★ **체계가 다르면 번호로 아무 말도 안 한다**(대응표가 없다)',
          same_song(c6, h1, h3)[0] is None, same_song(c6, h1, h3))
        # 작곡자 — 다르면 음의 신호
        set_meta(c6, s1, composer='가작곡')
        set_meta(c6, s2, composer='나작곡')
        t('★★★ **작곡자가 다르면 추천에도 안 올린다**',
          same_song(c6, s1, s2)[0] is None, same_song(c6, s1, s2))
        set_meta(c6, s2, composer=None)
        c6.execute("UPDATE %s SET composer=NULL WHERE song_id=?" % T_SONG,
                   (s2,))
        # ── 별명 ─────────────────────────────────────────────────
        t('★★ 별명을 담는다', add_alias(c6, s1, '나의 사랑', 'KO') is True)
        t('★ 두 번 담아도 안 는다', add_alias(c6, s1, '나의 사랑', 'KO') is False)
        t('★★ **정식 이름과 같으면 안 담는다**',
          add_alias(c6, s1, '내 사랑', 'KO') is False)
        t('★★★ **별명으로도 같은 곡이 걸린다**',
          match_name(c6, '나의 사랑')[0] == SAME_SURE,
          match_name(c6, '나의 사랑'))
        # ── 만들기 전에 묻는 문 ──────────────────────────────────
        t('★★★ **정확히 같으면 확실**', match_name(c6, '내사랑')[1] == s1)
        t('★★ **포함 관계는 추천**(자동으로 안 붙인다)',
          match_name(c6, '내사랑123')[0] == SAME_MAYBE)
        t('★ 아주 다르면 없음', match_name(c6, 'zz아무이름zz')[0] is None)
        import inspect as _i6
        t('★★★ **만드는 문이 먼저 묻는다**',
          'match_name(conn, nm, lg)' in _i6.getsource(new_song_from_media))
        # ── 합치기 ───────────────────────────────────────────────
        r1 = add_rend(c6, s1, 'KO', names={'KO': '내사랑'}, title='내사랑')
        r2 = add_rend(c6, s2, 'KO', names={'KO': '내사랑'}, title='내사랑')
        r3 = add_rend(c6, s2, 'EN', names={'EN': 'My Love'}, title='My Love')
        link_verse(c6, s2, 1, 3)
        got = merge(c6, s1, s2, why='시험')
        t('★★★ **판이 겹치면 접는다**(같은 제목이 둘이 되지 않는다)',
          got.get('folded') == 1, got)
        t('★★ 안 겹치는 판은 옮긴다', got.get('rend') == 1, got)
        t('★★ 곡-구절도 옮긴다', got.get('verse') == 1, got)
        t('★★★ **버린 곡 이름이 별명으로 남는다**',
          any(v == '내사랑1' for _l, v in aliases_of(c6, s1)),
          aliases_of(c6, s1))
        t('★★★ **버린 곡은 지우지 않고 가린다**(되돌릴 자리)',
          c6.execute("SELECT record_status, note FROM %s WHERE song_id=?"
                     % T_SONG, (s2,)).fetchone()[0] == 'HIDE')
        t('★★ 자국에 **어느 곡으로 갔는지** 적는다',
          ('%s:%d' % (MERGE_NOTE, s1)) in (c6.execute(
              "SELECT COALESCE(note,'') FROM %s WHERE song_id=?" % T_SONG,
              (s2,)).fetchone()[0]))
        t('★★★ **합친 뒤 그 이름으로 들어와도 새 곡이 안 생긴다**',
          match_name(c6, '내사랑1')[0] == SAME_SURE
          and match_name(c6, '내사랑1')[1] == s1)
        # 양쪽 다 원곡이면 멈춘다
        s4 = add_song(c6, 'ZZTEST_D', names={'KO': 'zz넷'}, orig_lang='KO')
        r4 = add_rend(c6, s4, 'KO', names={'KO': 'zz넷'}, title='zz넷')
        set_anchor(c6, s1, r1, ANCHOR_ORIG, why='시험')
        set_anchor(c6, s4, r4, ANCHOR_ORIG, why='시험')
        t('★★★ **양쪽 다 원곡(확정)이면 멈춘다**',
          bool(merge(c6, s1, s4).get('why')), merge(c6, s1, s4))
        # ── 아니라고 정한 짝 ─────────────────────────────────────
        _ns0 = _not_same_set(c6)      # 시험 **전**의 것 — 사람이 적어 둔 값
        t('★★ 「다른 곡이다」를 적는다', mark_not_same(c6, s1, s3) is True)
        t('★ 두 번 적어도 안 는다', mark_not_same(c6, s1, s3) is False)
        t('★★★ **적은 짝은 다시 안 낸다**',
          not any({a3, b3} == {s1, s3} for _g, a3, b3, _w in find_same(c6)))
        c6.rollback()
        c6.close()
        # ⚠ **자국이 없어야 한다** — `sys_config` 는 `rollback` 밖일 수 있다
        c7 = _ad.connect(_ad.MAIN_DB)
        # ⚠⚠ **`_` 는 LIKE 의 자리표다**(§235차 그 자리) — `HYMN_%_90%` 로
        #   재니 **진짜 찬송가** `HYMN_NEW_090`·`HYMN_NEW_490` 이 걸렸다.
        #   ⇒ 시험이 지은 코드를 **그대로** 견준다.
        _zz = ('ZZTEST_A', 'ZZTEST_B', 'ZZTEST_C', 'ZZTEST_D',
               hymn_code(901), hymn_code(902), hymn_code(901, 'UNI'))
        t('★★★ **시험 자국이 안 남는다**(곡)',
          c7.execute("SELECT COUNT(*) FROM %s WHERE song_code IN (%s)"
                     % (T_SONG, ','.join('?' * len(_zz))), _zz
                     ).fetchone()[0] == 0)
        import json as _j7
        _r7 = c7.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (NOT_SAME_KEY,)).fetchone()
        _now7 = {tuple(x) for x in _j7.loads(_r7[0])} if _r7 and _r7[0] else set()
        _mine7 = _now7 - _ns0
        if _mine7:      # ★ 제 자국만 걷는다 — 남의 것은 안 건드린다
            c7.execute(
                "INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
                " ON CONFLICT(config_key) DO UPDATE SET"
                " config_val=excluded.config_val",
                (NOT_SAME_KEY, _j7.dumps(sorted(_ns0))))
            c7.commit()
        _r8 = c7.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (NOT_SAME_KEY,)).fetchone()
        _left7 = {tuple(x) for x in _j7.loads(_r8[0])} if _r8 and _r8[0] else set()
        t('★★★ **시험 자국이 안 남는다**(「다른 곡」 표식 — 남의 것 %d 은 그대로)'
          % len(_ns0), _left7 == _ns0)
        c7.close()
    except Exception as _e6:
        t('★ 동일성 시험이 돈다', False, repr(_e6))

    # ── 대표 영상 차례(2026-09-17) — **실 DB 로 잰다**(값을 안 바꾼다) ──────
    try:
        import appdb as _ad
        import json as _j9
        c9 = _ad.connect()
        _ids = [r[0] for r in c9.execute("SELECT song_id FROM %s" % T_SONG)]
        _withm = {r[0] for r in c9.execute(
            "SELECT DISTINCT r.song_id FROM %s r"
            " JOIN sys_link_asset l ON l.link_type=? AND l.target_id=r.rend_id"
            "  AND COALESCE(l.record_status,'LIVE')='LIVE'"
            " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
            "  AND m.is_active=1 AND COALESCE(m.record_status,'LIVE')='LIVE'"
            % T_REND, (LINK_MEDI,))}
        _rep = {s: rep_order(c9, s, 'KO') for s in _ids}
        _got = {s for s, v in _rep.items() if v}
        t('★★★ **영상이 붙은 곡은 전부 대표가 정해진다**(닻이 없어도)',
          _got == _withm, (len(_got), len(_withm)))
        t('  영상이 0편인 곡은 대표가 없다(억지로 안 정한다)',
          all(not _rep[s] for s in _ids if s not in _withm))
        _bad = []
        for s, v in _rep.items():
            for mid, _u, _ti, _w in v:
                r = c9.execute("SELECT COALESCE(description,'') FROM sys_media_asset"
                               " WHERE media_id=?", (mid,)).fetchone()
                d = (r[0] if r else '') or ''
                ks = []
                if d.startswith('{'):
                    try:
                        ks = _j9.loads(d).get('rend_kind') or []
                    except Exception:
                        ks = []
                if set(ks) & set(REP_SKIP_KINDS):
                    _bad.append((s, mid, ks))
        t('★ 대표 후보에 묶음·반주·악보·연주커버·워십댄스가 **0건**',
          not _bad, _bad[:2])
        _sh = [x for s, v in _rep.items() for x, _u, _t2, _w in v
               if c9.execute("SELECT 1 FROM sys_media_check WHERE media_id=?"
                             "  AND duration IS NOT NULL AND duration<=120",
                             (x,)).fetchone()]
        t('★ 대표 후보에 쇼츠가 0건', not _sh, _sh[:3])
        _blk = [x for s, v in _rep.items() for x, _u, _t3, _w in v
                if c9.execute("SELECT 1 FROM sys_media_check WHERE media_id=?"
                              "  AND status='EMBED_BLOCKED'", (x,)).fetchone()]
        t('★ 막힌 것으로 확인된 영상이 대표 후보에 0건', not _blk, _blk[:3])
        # ⚠ **재료로 되짚지 말고 이 문이 낸 답으로 잰다** — 한 영상이 판 둘에
        #   걸린 자리가 남아 있어(§243차) `song_of_media` 로 되짚으면 시험이
        #   거짓말한다(실측 9곡이 그렇게 어긋났는데 판정은 맞았다).
        _lang_bad = []
        for s, v in _rep.items():
            if not v or '확인된 원곡' in v[0][3]:
                continue        # 사람이 확정한 원곡은 언어보다 앞선다(규칙 ①)
            if any('내 언어' in x[3] for x in v) and '내 언어' not in v[0][3]:
                _lang_bad.append(s)
        t('★ 살아남은 후보에 내 언어가 있으면 **대표도 내 언어**',
          not _lang_bad, _lang_bad[:3])
        t('  확정된 원곡은 언어보다 앞선다(규칙 ①)',
          all('확인된 원곡' in v[0][3]
              for v in _rep.values()
              if v and any('확인된 원곡' in x[3] for x in v)))
        t('  같은 곡을 두 번 물어도 같은 답(멱등)',
          all(rep_order(c9, s, 'KO') == _rep[s] for s in _ids[:40]))
        c9.close()
    except Exception as _e9:
        t('★ 대표 영상 차례가 돈다', False, repr(_e9))

    # ── 1.txt 17번 3) 가사·메모·부제 · 곡↔구절 · 이름 찾기 ──────────
    # ⚠ **제 재료를 만든다** — 위에서 쓴 `s1` 은 뒤에서 다시 묶여
    #   있었다(실측 이 블록이 그 자리에서 셋을 거짓 실패로 냈다 §0-5).
    # ⚠ `_mem()` 의 `sys_link_asset` 에는 `sys_link_id` 가 없다 — 곡↔구절
    #   문은 그 번호를 쓰므로 여기서는 **제 표를 세운다**.
    import sqlite3 as _sq2
    c2 = _sq2.connect(':memory:')
    c2.executescript("""
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT,
        lang_code TEXT, contents TEXT, record_status TEXT);
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,
        link_type TEXT, clicked_id INT, target_id INT, end_id INT,
        record_status TEXT, confidence TEXT, note TEXT, source TEXT);
    """)
    ensure(c2)
    sx = add_song(c2, 'SUBJ_TEST',
                  {'EN': 'Always You Jesus', 'KO': '언제나 주만'},
                  orig_lang='KO')
    t('★ 가사·메모·부제를 담는다',
      set_meta(c2, sx, lyrics='주를 찬양', memo='2019년 집회에서',
               subtitle='하나님은 너를 만드신 분'))
    _m = meta_of(c2, sx)
    t('★ 그대로 돌아온다',
      _m.get('lyrics') == '주를 찬양' and _m.get('memo') == '2019년 집회에서'
      and _m.get('subtitle') == '하나님은 너를 만드신 분', _m)
    t('★ 증거(note)와 배경(memo)은 **다른 칸**이다',
      set_meta(c2, sx, note='마커스워십 소속') and
      meta_of(c2, sx).get('memo') == '2019년 집회에서', meta_of(c2, sx))

    t('★ 이름으로 곡을 찾는다(어느 언어로 쳐도)',
      [x[0] for x in find_songs(c2, 'Always')] == [sx]
      and [x[0] for x in find_songs(c2, '언제나')] == [sx],
      (find_songs(c2, 'Always'), find_songs(c2, '언제나')))
    t('★ 없는 이름이면 빈 목록', find_songs(c2, '없는곡이름zz') == [])
    t('★ 빈 검색어는 **전체를 쏟지 않는다**', find_songs(c2, '  ') == [])

    t('★★★ **내린 곡은 사용자 화면에 안 뜬다** — 곡↔구절 조회가 상태를 본다',
      _hidden_gone(c2, sx))

    t('★★ 곡 이름을 **언어별로 고친다** — 화면이 이 문으로 저장한다',
      set_names(c2, sx, {'KO': '언제나 주만 (고침)', 'EN': 'Always You'})
      and names_of(c2, NAME_SONG, sx).get('KO') == '언제나 주만 (고침)'
      and names_of(c2, NAME_SONG, sx).get('EN') == 'Always You',
      names_of(c2, NAME_SONG, sx))
    t('★★★ **빈 값은 안 덮는다** — 실수로 비우고 저장해 이름을 잃지 않는다',
      set_names(c2, sx, {'KO': '', 'EN': 'Always You'})
      and names_of(c2, NAME_SONG, sx).get('KO') == '언제나 주만 (고침)',
      names_of(c2, NAME_SONG, sx))

    _l1 = add_verse(c2, sx, 500)
    _l2 = add_verse(c2, sx, 600, 605)
    t('★★ 곡에 구절·구간을 **사람이 잇는다**', bool(_l1) and bool(_l2))
    t('★ 같은 것을 또 이으면 안 는다', add_verse(c2, sx, 500) is None)
    t('★ 거꾸로 된 구간은 거부한다', add_verse(c2, sx, 700, 690) is None)
    _vs = verses_of(c2, sx)
    t('★ 목록에 구간이 그대로 (%s)' % (_vs,),
      (500, 500) in [(a, b) for _i, a, b, _mn in _vs]
      and (600, 605) in [(a, b) for _i, a, b, _mn in _vs], _vs)
    t('★★★ 사람이 이은 것은 **MANUAL** — 규칙이 다시 지어도 안 걷힌다',
      all(mn for _i, _a, _b, mn in _vs), _vs)
    t('★ 떼면 목록에서 사라진다',
      drop_verse(c2, _l1) and len(verses_of(c2, sx)) == len(_vs) - 1)
    t('★★ **지우지 않고 가린다** — 되살아나면 뗀 뜻이 없다',
      c2.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=?",
                (_l1,)).fetchone()[0] == 'HIDE')
    t('★ 뗀 것을 다시 이으면 되살아난다', add_verse(c2, sx, 500) == _l1)
    c2.close()

    print('db_song selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if '--derive' in argv:
            r = derive(conn)
            print('곡 %d · 판 %d · 영상 %d편 이음 (건너뜀 %d)'
                  % (r['song'], r['rend'], r['media'], r['skip']))
        elif '--verses' in argv:
            r = derive_verses(conn)
            print('곡 %d개에 구절 %d건 (약한 후보 %d)'
                  % (r['song'], r['made'], r['weak']))
        elif '--list' in argv:
            for sid, nm, ol, oa, nr, nm_ in songs(conn):
                print('  %-30s %-4s %-16s 판 %2d · 영상 %3d'
                      % (nm[:30], ol or '—', (oa or '—')[:16], nr, nm_))
        elif '--show' in argv:
            code = argv[argv.index('--show') + 1]
            row = conn.execute("SELECT song_id FROM %s WHERE song_code=?" % T_SONG,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
                               (code.upper(),)).fetchone()
            if not row:
                print('그런 곡이 없습니다: %s' % code)
                return
            sid = row[0]
            print('★ %s' % label(conn, NAME_SONG, sid))
            for rid, ti, lg, an, iso, iof, n in rends_of(conn, sid):
                print('  ── [%s] %-24s %-16s %s%s (영상 %d)'
                      % (lg or '—', (ti or '')[:24], (an or '사역자 모름')[:16],
                         '★원곡 ' if iso else '', '공식' if iof else '', n))
                for mid, mt, ks, vw in media_of(conn, rid)[:6]:
                    import media_taxonomy as T
                    print('       %-52s %s %s'
                          % ((mt or '')[:52], T.rend_label(ks),
                             ('%d회' % vw) if vw else ''))
        else:
            print('사용법: --derive | --verses | --list | --show <코드> | --selftest')
    finally:
        conn.close()


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    main(sys.argv[1:])
