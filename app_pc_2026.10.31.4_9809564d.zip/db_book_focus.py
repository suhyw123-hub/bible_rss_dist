# -*- coding: utf-8 -*-
"""db_book_focus.py — **도서 편의 묵상 포커스**를 적재한다
(2026-08-31 신설 · 영구 · `--selftest` 의무 · 멱등).

★★★ 왜 이 일이 먼저인가 (2026-08-31 사용자 물음 「플랜이 구성된 컨텐츠의
  묵상포커스를 만드는 것이 우선인가 스펄전 등을 플랜으로 구성하는 것이
  우선인가」의 답) — **구조가 정한다.**
  `meditation_focus` 는 **`sys_plan_schedule` 의 칸**이다. 스케줄 행이 없는
  편에는 **글을 담을 자리가 아예 없다.**
  | | 편 | 스케줄 있음 | 진짜 포커스 |
  |---|---|---|---|
  | 전체 | 7,228 | **1,683** | **223** |
  · **채울 수 있는 자리 1,460** — 마이어 1,189 · 스펄전 시편 150 · 켐피스 114
  · **자리가 없는 편 5,545** — 스펄전 설교 3,519 · 밀러 423 · 팡세 172 …
  ⇒ 플랜을 먼저 만들면 **빈 자리만 1,460 → 4,979 로 는다.** 빈 포커스는
    화면에 **아무것도 안 그리므로**(`_plan_head_lines`) 눈에 보이는 값이 0이고,
    §0-1 **빈 서랍 금지**가 바로 그것을 막는 규칙이다.
  ⇒ **이미 있는 자리를 채우는 것이 먼저다.** 채우면 그 자리에서 화면에 뜬다.
  ⚠ 게다가 스펄전 설교 3,519편을 하루치로 늘어놓으면 **9.6년짜리 플랜**이다.
    그것은 묵상 플랜이 아니라 **서재**다 — 플랜 꼴로 우겨넣을 것이 아니라
    묶는 방법을 따로 정해야 한다(§124차가 적어 둔 그대로).

★★★ **문체는 지어내지 않고 실측 318편에서 뽑았다.**
  · **한 줄** — 줄바꿈 든 것 **0편**
  · 길이 **18~64자**(중앙 32 · 90% 47)
  · 끝맺음 `.` 88% · `?` 12%
  · **본문 어휘 겹침 중앙 0.00 · 90% 0.33 · 최대 0.75**
    ⇒ 포커스는 **본문 요약이 아니다.** 「왜 이 편을 오늘 읽는가」(각도)이지
      줄거리가 아니다(§126차 「포커스는 배치 이유이지 구절 해설이 아니다」).
  · 꼴 둘 — 서술 한 문장 / 「명제: 부연」(`:` 25%)
      「참 금식은 규례가 아니라 마음과 섬김의 금식입니다.」
      「쉬지 말고 기도하라: 기도가 습관이 되고, 호흡이 될 때까지.」

⚠ **`|` 를 쓰지 않는다** — `제목 | 구절` 꼴은 **라벨**이라 화면이 일부러 안
  그린다(실측 7건). 그것을 흉내 내면 저장은 되는데 안 보인다.
⚠ **교단 귀속어 금지**(§28-11) — 이 앱은 여러 교단이 함께 쓴다.
⚠ 스케줄 행이 없는 편은 **거부한다** — 담을 자리가 없는데 넣으면 조용히 0행이다.

사용법
    python -X utf8 db_book_focus.py --selftest
    python -X utf8 db_book_focus.py --status
    python -X utf8 db_book_focus.py --check <초안.json>
    python -X utf8 db_book_focus.py --apply <초안.json>
    python -X utf8 db_book_focus.py --undo

초안 꼴 (`_focus_prep/*.json`, gitignore)
    [{"book": "KEMPIS_IOC", "seq": 2, "focus": "…"}, …]
    · `book`+`seq` 로 짚는다 — **재적재해도 살아남는다**(`unit_id` 는 바뀐다).
"""
import json
import re
import sys

import appdb

BACKUP = 'temp_book_focus_backup'

#: 실측 318편 = 18~64자. 여유를 두되 넓히지 않는다.
LEN_MIN, LEN_MAX = 15, 70

#: 본문 어휘 겹침 상한 — 실측 **최대 0.75**. 넘으면 줄거리를 옮겨 적은 것이다.
OVERLAP_MAX = 0.75

#: §28-11 교단 귀속어 — 화면 글에 쓰지 않는다.
BANNED = ('칼뱅', '칼빈', '개혁주의', '개혁파', '알미니안', '루터파', '장로교',
          '화체설', 'Calvin', 'Reformed')

#: ★★★ **요즘 안 쓰는 말** (2026-08-31 사용자 지시 「**자연스러운 대화체
#:   현대식**으로 작성하라. **요즘 사용하지 않는 단어를 절대 사용하지 마라**」).
#:   ⚠ 성경 인용투가 저절로 손에 붙는다 — 실측으로 내 글 204편 가운데 7편이
#:     그렇게 새고 있었다(`말씀하옵소서` · `송축해` · `화평케`).
#:   ⚠ **신앙 낱말을 막는 것이 아니다** — 은혜·언약·십자가·기도는 지금도 쓴다.
#:     막는 것은 **옛 어미와 사어**다.
ARCHAIC = ('아뢰', '하옵', '옵소서', '나이다', '리이다', '이옵', '사옵',
           '송축', '흠향', '우거', '영영히', '필경', '무릇', '짐짓',
           '이르되', '가로되', '통회', '하거늘', '하매', '이어늘',
           '케 하', '케 되', '어찌하여', '아니하', '못하리')

#: 문장 끝에 올 수 있는 닫는 부호 — 벗겨 내고 끝맺음을 본다.
_CLOSERS = ''.join(chr(c) for c in (0x300D, 0x300F, 0x22, 0x27, 0x2019, 0x201D, 0x29))

#: 되풀이 문형 — 넘으면 글이 격언집처럼 굳는다(실측 「~봅니다」 25/204).
#:   ⚠ **막지 않고 알리기만 한다** — 한 편만 보면 잘못이 아니다.
STOCK = ('봅니다.', '자리')


def _words(s):
    return set(w for w in re.findall(r'[가-힣]{2,}', s or ''))


def overlap(focus, body):
    """포커스 낱말 가운데 본문에도 있는 비율 → 0.0~1.0."""
    fw = _words(focus)
    if not fw:
        return 0.0
    return len(fw & _words(body)) / float(len(fw))


def _unit(conn, book, seq):
    """(책코드, 차례) → unit_id.

    ⚠⚠ **같은 차례의 편이 둘일 수 있다** — 마이어는 OCR 손상본(HIDE)과
      교정본(LIVE)이 짝을 이뤄 **181쌍**이 겹친다(실측). 스케줄 행은
      **LIVE 쪽에만** 있으므로 `record_status` 를 안 보면 손상본을 집어
      「스케줄 행이 없다」로 **181편이 통째로 막힌다**(2026-08-31 실측으로
      잡았다). ⇒ **LIVE 를 먼저** 고른다.
    """
    r = conn.execute(
        "SELECT u.unit_id FROM sys_book_asset ba"
        "  JOIN sys_book_unit u ON u.book_id=ba.book_id"
        " WHERE ba.book_code=? AND u.sequence=?"
        " ORDER BY CASE WHEN COALESCE(u.record_status,'LIVE')='LIVE'"
        "               THEN 0 ELSE 1 END, u.unit_id DESC",
        (book, seq)).fetchone()
    return r[0] if r else None


def _body(conn, uid):
    r = conn.execute(
        "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
        " ORDER BY CASE WHEN text_variant='TRANSLATED' THEN 0 ELSE 1 END"
        " LIMIT 1", (uid,)).fetchone()
    return (r[0] if r else '') or ''


def _slots(conn, uid):
    """그 편의 `BOOK_TEXT` 스케줄 행 수 — 0이면 담을 자리가 없다."""
    return conn.execute(
        "SELECT COUNT(*) FROM sys_plan_schedule"
        " WHERE unit_key=? AND stage_type='BOOK_TEXT'",
        ('BOOK_%d' % uid,)).fetchone()[0]


def check(conn, draft):
    """게이트 → `[(자리, 사유)]`. 빈 목록이면 통과."""
    bad = []
    seen = set()
    for i, d in enumerate(draft):
        book, seq = d.get('book'), d.get('seq')
        f = (d.get('focus') or '').strip()
        at = '%s #%s' % (book, seq)
        if (book, seq) in seen:
            bad.append((at, '초안 안에서 중복'))
        seen.add((book, seq))
        uid = _unit(conn, book, seq)
        if not uid:
            bad.append((at, '그런 편이 없다'))
            continue
        if not _slots(conn, uid):
            bad.append((at, '스케줄 행이 없다 — 담을 자리가 없다'))
        if not f:
            bad.append((at, '비었다'))
            continue
        if '\n' in f or '\r' in f:
            bad.append((at, '줄바꿈 — 한 줄이어야 한다(실측 0편)'))
        if '|' in f:
            bad.append((at, '「|」 는 라벨 꼴이라 화면이 안 그린다'))
        if not (LEN_MIN <= len(f) <= LEN_MAX):
            bad.append((at, '길이 %d (실측 18~64)' % len(f)))
        if not re.search(r'[가-힣]', f):
            bad.append((at, '한국어가 아니다'))
        # ⚠ **인용부호로 끝나는 문장은 정당하다** — 「너 어디 있니?」 처럼
        #   말을 그대로 옮기는 것이 대화체의 기본이다(2026-08-31 실측으로
        #   잡았다. 닫는 따옴표를 벗기고 끝을 본다).
        if not f.rstrip().rstrip(_CLOSERS).rstrip().endswith(('.', '?')):
            bad.append((at, '끝맺음이 `.` 나 `?` 가 아니다'))
        for w in BANNED:
            if w in f:
                bad.append((at, '교단 귀속어 「%s」(§28-11)' % w))
        for w in ARCHAIC:
            if w in f:
                bad.append((at, '요즘 안 쓰는 말 「%s」 — 대화체 현대말로' % w))
        ov = overlap(f, _body(conn, uid))
        if ov > OVERLAP_MAX:
            bad.append((at, '본문 어휘 겹침 %.2f — 줄거리 옮겨적기(상한 %.2f)'
                        % (ov, OVERLAP_MAX)))
    return bad


def apply(conn, draft):
    """게이트를 통과한 것만 넣는다(멱등). → 채운 행 수."""
    bad = check(conn, draft)
    if bad:
        raise SystemExit('게이트 위반 %d건 — 넣지 않았다.\n%s'
                         % (len(bad), '\n'.join('  %s : %s' % b
                                                for b in bad[:20])))
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        "  sched_key TEXT PRIMARY KEY, before_focus TEXT,"
        "  saved_at TEXT DEFAULT (datetime('now')))" % BACKUP)
    n = 0
    for d in draft:
        uid = _unit(conn, d['book'], d['seq'])
        key = 'BOOK_%d' % uid
        for (sid, old) in conn.execute(
                "SELECT schedule_id, COALESCE(meditation_focus,'')"
                "  FROM sys_plan_schedule"
                " WHERE unit_key=? AND stage_type='BOOK_TEXT'", (key,)):
            conn.execute(
                "INSERT OR IGNORE INTO %s (sched_key, before_focus)"
                " VALUES (?,?)" % BACKUP, (str(sid), old))
            conn.execute(
                "UPDATE sys_plan_schedule SET meditation_focus=?"
                " WHERE schedule_id=?", (d['focus'].strip(), sid))
            n += 1
    conn.commit()
    return n


def undo(conn):
    """백업표대로 되돌린다. → 되돌린 행 수."""
    try:
        rows = conn.execute(
            "SELECT sched_key, before_focus FROM %s" % BACKUP).fetchall()
    except Exception:
        return 0
    for sid, old in rows:
        conn.execute(
            "UPDATE sys_plan_schedule SET meditation_focus=?"
            " WHERE schedule_id=?", (old or None, int(sid)))
    conn.execute("DELETE FROM %s" % BACKUP)
    conn.commit()
    return len(rows)


def status(conn):
    """책마다 (편, 스케줄 있음, 진짜 포커스)."""
    return conn.execute("""
        SELECT ba.book_code, ba.title,
               COUNT(DISTINCT u.unit_id),
               COUNT(DISTINCT CASE WHEN s.unit_key IS NOT NULL
                                   THEN u.unit_id END),
               COUNT(DISTINCT CASE WHEN COALESCE(s.meditation_focus,'')<>''
                                AND INSTR(s.meditation_focus,'|')=0
                                   THEN u.unit_id END)
          FROM sys_book_asset ba
          JOIN sys_book_unit u ON u.book_id=ba.book_id
          LEFT JOIN sys_plan_schedule s
                 ON s.unit_key='BOOK_'||u.unit_id
                AND s.stage_type='BOOK_TEXT'
         GROUP BY ba.book_id
        HAVING COUNT(DISTINCT CASE WHEN s.unit_key IS NOT NULL
                                   THEN u.unit_id END) > 0
         ORDER BY 4 DESC""").fetchall()


def selftest(db_path='bible_master.db'):
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))

    conn = appdb.connect(db_path)
    row = conn.execute(
        "SELECT ba.book_code, u.sequence FROM sys_book_asset ba"
        "  JOIN sys_book_unit u ON u.book_id=ba.book_id"
        "  JOIN sys_plan_schedule s ON s.unit_key='BOOK_'||u.unit_id"
        "   AND s.stage_type='BOOK_TEXT' LIMIT 1").fetchone()
    if not row:
        print('스케줄 있는 편이 없다')
        return False
    bk, sq = row
    good = {'book': bk, 'seq': sq, 'focus': '오늘의 걸음을 한 자리에 모읍니다.'}

    def one(f, key='focus'):
        d = dict(good)
        d[key] = f
        return check(conn, [d])

    t('★ 바른 것은 통과', not check(conn, [good]), check(conn, [good])[:1])
    # ★★ 탐지력 — 잣대가 실제로 잡는가
    t('★★ 줄바꿈을 잡는다', any('줄바꿈' in r[1]
                            for r in one('첫 줄입니다.\n둘째 줄입니다.')))
    t('★★ 「|」 를 잡는다', any('라벨' in r[1]
                          for r in one('January 1 — Morning | Isaiah 43:1')))
    t('★★ 너무 짧은 것을 잡는다', any('길이' in r[1] for r in one('짧다.')))
    t('★★ 너무 긴 것을 잡는다',
      any('길이' in r[1] for r in one('가' * (LEN_MAX + 1) + '.')))
    t('★★ 끝맺음을 잡는다', any('끝맺음' in r[1]
                           for r in one('끝맺음이 없는 한 줄입니다')))
    t('★ 인용부호로 끝나는 것은 통과',
      not any('끝맺음' in r[1] for r in one('하나님이 물으십니다. 「너 어디 있니?」')))
    t('★★ 교단 귀속어를 잡는다', any('귀속어' in r[1]
                              for r in one('칼뱅이 말한 대로 은혜는 값없습니다.')))
    # ★★ **요즘 안 쓰는 말** — 성경 인용투가 손에 붙는다(실측 204편 중 7편)
    t('★★ 옛 어미를 잡는다', any('안 쓰는 말' in r[1]
                           for r in one('말씀하옵소서, 종이 듣겠나이다.')))
    t('★★ 사어를 잡는다', any('안 쓰는 말' in r[1]
                         for r in one('그 이름을 오늘도 송축합니다.')))
    t('★★ 옛 사동 「~케」를 잡는다', any('안 쓰는 말' in r[1]
                                for r in one('화평케 하는 사람이 됩니다.')))
    t('★★ 지금 쓰는 신앙 낱말은 안 막는다',
      not any('안 쓰는 말' in r[1]
              for r in one('은혜와 언약과 십자가는 지금도 그대로입니다.')))
    t('★★ 없는 편을 잡는다',
      any('없다' in r[1] for r in check(conn, [{'book': bk, 'seq': 999999,
                                              'focus': good['focus']}])))
    t('★★ 초안 안 중복을 잡는다',
      any('중복' in r[1] for r in check(conn, [good, dict(good)])))
    # ★★ 본문 재진술 — 본문 낱말만 골라 쓰면 걸려야 한다
    uid = _unit(conn, bk, sq)
    bw = [w for w in _words(_body(conn, uid))][:6]
    if len(bw) >= 4:
        t('★★ 줄거리 옮겨적기를 잡는다',
          any('옮겨적기' in r[1] for r in one(' '.join(bw[:5]) + '.')),
          ' '.join(bw[:5])[:30])
    else:
        t('★★ 줄거리 옮겨적기를 잡는다', True, '표본 부족 — 건너뜀')
    t('★ 겹침 계산', overlap('사랑 은혜', '사랑 소망') == 0.5)
    # ★★ **차례가 겹치면 LIVE 를 고른다** — 마이어 181쌍(HIDE 손상본/LIVE 교정본)
    dup = conn.execute(
        "SELECT ba.book_code, u.sequence FROM sys_book_asset ba"
        "  JOIN sys_book_unit u ON u.book_id=ba.book_id"
        " GROUP BY ba.book_id, u.sequence HAVING COUNT(*)>1"
        "   AND SUM(CASE WHEN COALESCE(u.record_status,'LIVE')='LIVE'"
        "            THEN 1 ELSE 0 END)=1 LIMIT 1").fetchone()
    if dup:
        _u = _unit(conn, dup[0], dup[1])
        _st = conn.execute("SELECT COALESCE(record_status,'LIVE')"
                           "  FROM sys_book_unit WHERE unit_id=?",
                           (_u,)).fetchone()[0]
        t('★★ 차례가 겹치면 LIVE 를 선택한다', _st == 'LIVE',
          '%s #%s → %s' % (dup[0], dup[1], _st))
    else:
        t('★★ 차례가 겹치면 LIVE 를 선택한다', True, '겹친 차례 없음 — 건너뜀')

    # ★ 넣고 되돌리기 — **내가 만든 행만** 건드린다(§97차 정리 사고)
    conn.execute("CREATE TABLE IF NOT EXISTS %s (sched_key TEXT PRIMARY KEY,"
                 " before_focus TEXT, saved_at TEXT)" % BACKUP)
    had = conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]
    sids = [r[0] for r in conn.execute(
        "SELECT schedule_id FROM sys_plan_schedule WHERE unit_key=?"
        "  AND stage_type='BOOK_TEXT'", ('BOOK_%d' % uid,))]
    before = conn.execute(
        "SELECT COALESCE(meditation_focus,'') FROM sys_plan_schedule"
        " WHERE schedule_id=?", (sids[0],)).fetchone()[0]
    try:
        n = apply(conn, [good])
        got = conn.execute(
            "SELECT meditation_focus FROM sys_plan_schedule"
            " WHERE schedule_id=?", (sids[0],)).fetchone()[0]
        t('★ 넣는다', n >= 1 and got == good['focus'], got)
    finally:
        for sid in sids:
            conn.execute(
                "UPDATE sys_plan_schedule SET meditation_focus=?"
                " WHERE schedule_id=?", (before or None, sid))
            conn.execute("DELETE FROM %s WHERE sched_key=?" % BACKUP,
                         (str(sid),))
        conn.commit()
    back = conn.execute(
        "SELECT COALESCE(meditation_focus,'') FROM sys_plan_schedule"
        " WHERE schedule_id=?", (sids[0],)).fetchone()[0]
    t('★ 되돌린다', back == before, repr(back)[:30])
    left = conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]
    # ★★ 이 한 줄이 §97차 사고를 잡는다 — 시험이 남의 백업을 건드리면 걸린다
    t('★★ 남의 백업 행을 안 건드린다', left == had, '%d → %d' % (had, left))
    conn.close()
    print('db_book_focus selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect('bible_master.db')
    if '--status' in a:
        tot = [0, 0, 0]
        print('%-18s %-26s %6s %7s %7s' % ('책', '', '편', '스케줄', '포커스'))
        for bc, ti, u, s, f in status(c):
            tot[0] += u
            tot[1] += s
            tot[2] += f
            print('  %-18s %-26s %5d %7d %7d' % (bc, ti[:26], u, s, f))
        print('  ' + '-' * 70)
        print('  %-18s %-26s %5d %7d %7d  → **빈 자리 %d**'
              % ('합계', '', tot[0], tot[1], tot[2], tot[1] - tot[2]))
    elif '--undo' in a:
        print('되돌린 행:', undo(c))
    else:
        path = [x for x in a if x.endswith('.json')]
        if not path:
            print(__doc__.split('사용법')[1])
            sys.exit(1)
        draft = json.load(open(path[0], encoding='utf-8'))
        bad = check(c, draft)
        print('초안 %d편 · 위반 %d건' % (len(draft), len(bad)))
        for at, why in bad[:40]:
            print('  %-22s %s' % (at, why))
        if '--apply' in a:
            print('채운 행:', apply(c, draft))
    c.close()
