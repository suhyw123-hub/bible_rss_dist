"""PC 와 폰이 함께 쓰는 규칙 표를 폰 Dart 파일로 옮긴다 — 단일 소스는 PC 파이썬 표.

① 화면색 — ui_theme._SPEC · PALETTE → mobile/lib/ui/themes_gen.dart
   (2026-10-22 사용자 「화면색 : 폰도 PC 와 일치시키자. 그러나 세팅은 각자」 — 같은 열여섯 벌 · 고른 값은 기기마다)
② 통합검색 갈래 — search.GROUPS → mobile/lib/ui/search_gen.dart
   (2026-10-22 사용자 「가장 포괄적인 방식으로 · 두 가지 모두 합해서 · 서로 달라야 할 이유는 없다」)

PC 의 표를 고치면 이것을 다시 돌린다.  python make_shared_dart.py [--check]
"""
import os
import sys

APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP)
import ui_theme as U  # noqa: E402
import search as S  # noqa: E402

OUT = os.path.join(APP, 'mobile', 'lib', 'ui', 'themes_gen.dart')
OUT_S = os.path.join(APP, 'mobile', 'lib', 'ui', 'search_gen.dart')
ROLES = ('bg', 'panel', 'panel_alt', 'fg', 'fg_dim', 'border', 'accent', 'select_bg', 'edit_bg')
NL = chr(10)


def _c(h):
    return 'Color(0xFF%s)' % h.lstrip('#').upper()


def _camel(r):
    a = r.split('_')
    return a[0] + ''.join(x.capitalize() for x in a[1:])


def render():
    out = ['// ★ 자동 생성 — make_shared_dart.py ← PC ui_theme._SPEC · PALETTE. 손으로 고치지 말 것(PC 를 고치고 다시 돌린다).',
           "import 'package:flutter/material.dart';", '',
           'class HagahTheme {',
           '  final String key, family, labelKey, labelKo;',
           '  final bool dark;',
           '  final Color ' + ', '.join(_camel(r) for r in ROLES) + ';',
           '  const HagahTheme(this.key, this.family, this.labelKey, this.labelKo, this.dark, '
           + ', '.join('this.' + _camel(r) for r in ROLES) + ');',
           '}', '',
           '/// 계열(차례) · 이름 열쇠 · 한국어',
           'const themeFamilies = <(String, String, String)>[']
    for f in U.FAMILIES:
        k, ko = U.FAMILY_LABELS[f]
        out.append("  ('%s', '%s', '%s')," % (f, k, ko))
    out += ['];', '', 'const hagahThemes = <HagahTheme>[']
    for k, fam, name, *_r, dark in U._SPEC:
        p = U.PALETTE[k]
        out.append("  HagahTheme('%s', '%s', 'THEME_%s', '%s', %s, %s)," % (
            k, fam, k, name, 'true' if dark else 'false', ', '.join(_c(p[r]) for r in ROLES)))
    out += ['];', '', '/// 걷은 테마 → 옮겨 갈 테마(PC RETIRED 와 같다)', 'const retiredThemes = <String, String>{']
    for a, b in U.RETIRED.items():
        out.append("  '%s': '%s'," % (a, b))
    out += ['};', '']
    return NL.join(out)


def render_search():
    out = ['// ★ 자동 생성 — make_shared_dart.py ← PC search.GROUPS. 손으로 고치지 말 것(PC 를 고치고 다시 돌린다).',
           '/// 통합검색 갈래 — (열쇠, 이름 열쇠, 한국어) · PC 와 같은 차례',
           'const searchKinds = <(String, String, String)>[']
    for k, _b, ik, ko in S.GROUPS:
        out.append("  ('%s', '%s', '%s')," % (k, ik, ko))
    out += ['];', '']
    return NL.join(out)


def main():
    pairs = [(OUT, render()), (OUT_S, render_search())]
    if '--check' in sys.argv:
        bad = 0
        for path, s in pairs:
            cur = open(path, encoding='utf-8').read() if os.path.exists(path) else ''
            print(os.path.basename(path), 'OK' if cur == s else '다르다 — 다시 만드세요')
            bad += cur != s
        sys.exit(1 if bad else 0)
    for path, s in pairs:
        open(path, 'w', encoding='utf-8', newline=NL).write(s)
        print('wrote', path)


if __name__ == '__main__':
    main()
