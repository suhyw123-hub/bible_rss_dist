# -*- coding: utf-8 -*-
"""히브리 절 번호 **병기** — 우리 영어축 옆에 마소라 번호를 함께 적는다.

사용자 「**히브리 절 번호 병기 진행하라**」(279차).

★★★ **무엇이 문제인가** — 우리 좌표축은 영어 성경 번호다(§18-8). 그런데
  히브리어 성경은 번호가 다르다:

      우리(영어)        히브리(마소라)
      시 3:1      =     시 3:1 + 3:2   ← 표제가 한 절을 먹는다
      욜 2:28     =     욜 3:1         ← 장이 통째로 밀린다
      말 4:1      =     말 3:19        ← 4장이 아예 없다

  히브리어 성경을 나란히 펴 놓은 사람은 **같은 절을 못 찾는다.**
  ⇒ 다른 번호를 쓰는 자리에 **그 번호를 함께 적는다.**

★★★ **근거를 지어내지 않는다 — 이미 가진 원문이 답을 갖고 있다.**
  `_wlc_raw/*.xml`(OSHB)은 **히브리 번호 그대로** 적혀 있고(`osisID="Ps.3.2"`),
  §18-10 의 `db_wlc_verify.align_book` 이 그것을 우리 절에 이미 맞춰 두었다.
  ⇒ **그 정렬을 그대로 쓴다.** 손으로 표를 적으면 한 곳이 틀려도 모른다.

  ⚠ `align_book` 은 `(verse_id, 히브리본문, Strong)` 만 낸다 — 번호를 버린다.
    그렇다고 그 함수를 고치지 않는다(§18-10 이 쓰는 계약이다). 대신 낸 본문을
    원문 차례와 **맞춰 되짚어** 번호를 되살린다. 본문이 곧 열쇠다.

★★★ **검사가 이 도구의 반이다** — 「그럴듯한 번호」와 「맞는 번호」를 가르는
  것은 `cover()` 다: 원문의 모든 히브리 절이 **꼭 한 번씩** 쓰였고 차례가
  거꾸로 가지 않는가. 한 자리만 밀려도 겹치거나 구멍이 난다.
  ⚠ 알려진 자리 25 곳(`KNOWN`)은 **지도를 만드는 재료가 아니라 잣대**다.

★ **다른 자리만 담는다** — 번호가 같은 절은 담지 않는다. 그래야 표가 작고,
  화면은 「행이 있으면 적는다」 한 줄로 끝난다(§0-1 — 없는 것을 그리지 않는다).

쓰는 법
    python db_heb_versemap.py --selftest      # 의무
    python db_heb_versemap.py --check         # 안 건드리고 무엇이 달라지나
    python db_heb_versemap.py --apply         # 적재(멱등)
    python db_heb_versemap.py --show 19 3     # 그 장을 나란히 본다
"""
import argparse
import collections
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

TABLE = 'sys_heb_verse_ref'

DDL = ("CREATE TABLE IF NOT EXISTS %s ("
       " verse_id INTEGER PRIMARY KEY,"
       " heb_chapter INTEGER NOT NULL,"
       " heb_verse INTEGER NOT NULL,"
       " heb_chapter_end INTEGER,"
       " heb_verse_end INTEGER)" % TABLE)

#: ★ 알려진 자리 — **도구가 스스로 맞았는지 재는 잣대**(selftest).
#  표준 대조표에서 널리 인용되는 자리만 골랐다. 이 표로 지도를 만드는 것이
#  아니라 **만든 지도를 검사**한다 — 방향이 반대라는 점이 중요하다.
KNOWN = [
    # (bcode, 장, 절, 히브리 장, 히브리 첫절)
    (1, 32, 1, 32, 2),      # 창 32:1 = 히 32:2 (31:55 이 히 32:1)
    (2, 8, 1, 7, 26),       # 출 8:1 = 히 7:26
    (2, 22, 1, 21, 37),     # 출 22:1 = 히 21:37
    (3, 6, 1, 5, 20),       # 레 6:1 = 히 5:20
    (4, 17, 1, 17, 16),     # 민 17:1 = 히 17:16
    (5, 29, 1, 28, 69),     # 신 29:1 = 히 28:69
    (9, 21, 1, 21, 2),      # 삼상 21:1 = 히 21:2
    (10, 19, 1, 19, 2),     # 삼하 19:1 = 히 19:2
    (11, 4, 21, 5, 1),      # 왕상 4:21 = 히 5:1
    (13, 6, 1, 5, 27),      # 대상 6:1 = 히 5:27
    (16, 4, 1, 3, 33),      # 느 4:1 = 히 3:33
    (18, 41, 1, 40, 25),    # 욥 41:1 = 히 40:25
    (19, 3, 1, 3, 1),       # 시 3:1 = 히 3:1~2 (표제)
    (21, 5, 1, 4, 17),      # 전 5:1 = 히 4:17
    (22, 7, 1, 7, 2),       # 아 7:1 = 히 7:2
    (23, 9, 1, 8, 23),      # 사 9:1 = 히 8:23
    (26, 21, 1, 21, 6),     # 겔 21:1 = 히 21:6
    (27, 4, 1, 3, 31),      # 단 4:1 = 히 3:31
    (27, 6, 1, 6, 2),       # 단 6:1 = 히 6:2
    (28, 2, 1, 2, 3),       # 호 2:1 = 히 2:3
    (29, 2, 28, 3, 1),      # 욜 2:28 = 히 3:1
    (33, 5, 1, 4, 14),      # 미 5:1 = 히 4:14
    (34, 2, 1, 2, 2),       # 나 2:1 = 히 2:2
    (38, 2, 1, 2, 5),       # 슥 2:1 = 히 2:5
    (39, 4, 1, 3, 19),      # 말 4:1 = 히 3:19
]


# ── 되짚기 ───────────────────────────────────────────────────────────
def _refs_for_book(wlc, mapped):
    """`align_book` 이 낸 본문을 원문 차례와 맞춰 **번호를 되살린다**.

    `wlc`    = `[(장, 절, 본문, Strong)]` 원문 차례 그대로
    `mapped` = `[(verse_id, 본문, Strong)]` 같은 차례(건너뛴 절이 있을 수 있다)
    → `[(verse_id, 첫장, 첫절, 끝장, 끝절)]`

    ⚠ 시편은 표제와 첫 절이 **한 칸에 합쳐져** 있다(`align_book`) — 그래서
      한 절이 아니라 **구간**으로 돌려준다. 「히브리 1-2절」이라 적을 자리다.
    ⚠⚠ **구간이 장을 넘어가는 자리가 있다 — 실측으로 당했다.**
      민 26:1 = 히 25:19 + 26:1 · 삼상 20:42 = 히 20:42 + 21:1.
      끝 장을 따로 안 들면 「25:19~1」 같은 뒤집힌 구간이 나오고, 그러면
      히브리 26장의 1절이 통째로 사라진다(덮음 검사가 그 자리에서 잡았다).
    ⚠ 맞춰 갈 수 없으면 **그 절을 버린다** — 억지로 번호를 붙이면 화면이
      거짓말한다(§0-1).
    """
    out = []
    i = 0
    for vid, heb, _st in mapped:
        heb = (heb or '').strip()
        if not heb:
            continue
        # 이 본문이 어느 원문 절에서 시작하나 — 차례를 지키며 앞으로만 간다
        j = i
        while j < len(wlc) and not (
                wlc[j][2] and heb.startswith(wlc[j][2].strip())):
            j += 1
        if j >= len(wlc):
            continue                       # 못 맞췄다 — 버린다
        k, acc = j, (wlc[j][2] or '').strip()
        while acc != heb and k + 1 < len(wlc):
            k += 1
            acc = (acc + ' ' + (wlc[k][2] or '').strip()).strip()
        if acc != heb:
            continue                       # 이어 붙여도 안 맞는다 — 버린다
        out.append((vid, wlc[j][0], wlc[j][1], wlc[k][0], wlc[k][1]))
        i = k + 1
    return out


def build(conn, want=None):
    """원문에서 지도를 만든다.

    → `(rows, src)` — `rows` = `[(verse_id, 첫장, 첫절, 끝장, 끝절)]` ·
      `src` = `{bcode: [(장, 절)]}` 원문이 실제로 가진 절(덮음 검사용).
    """
    import db_wlc_verify as W
    ours = W.our_index(conn)
    kjv = dict(conn.execute("SELECT verse_id, verse_text FROM bible_content"
                            " WHERE version_code='KJV'"))
    rows, src = [], {}
    for i, name in enumerate(W.OSIS):
        b = i + 1
        if want and b not in want:
            continue
        wlc = W.read_book(name)
        mapped, _un = W.align_book(b, wlc, ours[b], kjv)
        src[b] = [(x[0], x[1]) for x in wlc]
        rows.extend(_refs_for_book(wlc, mapped))
    return rows, src


def spans(row):
    """한 줄이 덮는 히브리 절들 → `[(장, 절)]`.

    ⚠ 장을 넘는 구간은 **원문 차례를 모르면 못 편다** — 그래서 여기서는
      두 끝만 내고, 사이는 `cover()` 가 원문 차례로 채운다.
    """
    _vid, c1, v1, c2, v2 = row
    return (c1, v1), (c2, v2)


def cover(rows, src):
    """★★★ **원문의 모든 히브리 절이 꼭 한 번씩 쓰였는가** → 흠 목록.

    셋을 함께 본다:
      ⓐ **겹침** — 한 히브리 절이 우리 두 절에 붙었다(밀림의 표식)
      ⓑ **거꾸로** — 뒤 절이 앞 절보다 작은 번호를 받았다
      ⓒ **빠짐** — 원문에 있는데 아무 데도 안 쓰였다(맞추지 못해 버린 것)
    ⚠ ⓒ 는 **수만 센다** — 우리가 일부러 버린 자리가 있으므로 흠이 아니라
      「덮지 못한 정도」다. ⓐⓑ 는 곧바로 흠이다.
    """
    bad, miss = [], {}
    for b, order in sorted(src.items()):
        pos = {rv: i for i, rv in enumerate(order)}
        used = collections.Counter()
        last = -1
        for row in [r for r in rows if r[0] in _BOOK_OF.get(b, ())]:
            (c1, v1), (c2, v2) = spans(row)
            i1, i2 = pos.get((c1, v1)), pos.get((c2, v2))
            if i1 is None or i2 is None:
                bad.append((b, '원문에 없는 번호', (c1, v1, c2, v2)))
                continue
            if i2 < i1:
                bad.append((b, '구간이 거꾸로', (c1, v1, c2, v2)))
                continue
            if i1 <= last:
                bad.append((b, '차례가 거꾸로', (c1, v1)))
            last = i2
            for i in range(i1, i2 + 1):
                used[order[i]] += 1
        dup = [k for k, n in used.items() if n > 1]
        if dup:
            bad.append((b, '한 히브리 절이 두 번 쓰였다', sorted(dup)[:5]))
        gone = [rv for rv in order if rv not in used]
        if gone:
            miss[b] = len(gone)
    return bad, miss


#: `cover()` 가 책마다 제 줄만 보게 하는 색인 — `differing`/`check` 가 채운다
_BOOK_OF = {}


def index_by_book(conn, rows):
    """`_BOOK_OF` 를 채운다 — `{bcode: set(verse_id)}`."""
    _BOOK_OF.clear()
    ids = {r[0] for r in rows}
    for vid, b in conn.execute('SELECT verse_id, bcode FROM bible_index'
                               ' WHERE bcode<=39'):
        if vid in ids:
            _BOOK_OF.setdefault(b, set()).add(vid)
    return _BOOK_OF


def differing(conn, rows):
    """번호가 **다른** 절만 → 같은 꼴의 목록."""
    ours = {vid: (ch, vs) for vid, ch, vs in conn.execute(
        'SELECT verse_id, chapter, verse FROM bible_index WHERE bcode<=39')}
    out = []
    for vid, c1, v1, c2, v2 in rows:
        cur = ours.get(vid)
        if not cur:
            continue
        if (c1, v1, c2, v2) != (cur[0], cur[1], cur[0], cur[1]):
            out.append((vid, c1, v1, c2, v2))
    return out


def apply_rows(conn, rows):
    conn.execute(DDL)
    conn.execute('DELETE FROM %s' % TABLE)
    conn.executemany(
        'INSERT INTO %s(verse_id, heb_chapter, heb_verse, heb_chapter_end,'
        ' heb_verse_end) VALUES(?,?,?,?,?)' % TABLE,
        [(v, c1, v1, (c2 if c2 != c1 else None),
          (v2 if (v2, c2) != (v1, c1) else None)) for v, c1, v1, c2, v2 in rows])
    conn.commit()
    return len(rows)


# ── 읽는 문 (화면이 쓴다) ────────────────────────────────────────────
def _tidy(r):
    c1, v1, c2, v2 = r[0], r[1], r[2], r[3]
    return (c1, v1, c2 if c2 else c1, v2 if v2 else v1)


def heb_ref(conn, verse_id):
    """그 절의 히브리 번호 → `(첫장, 첫절, 끝장, 끝절)` 또는 `None`(같으면)."""
    try:
        r = conn.execute(
            'SELECT heb_chapter, heb_verse, heb_chapter_end, heb_verse_end'
            ' FROM %s WHERE verse_id=?' % TABLE, (verse_id,)).fetchone()
    except Exception:                                         # noqa: BLE001
        return None
    return _tidy(r) if r else None


def heb_refs(conn, verse_ids):
    """여러 절 한 번에 → `{verse_id: (첫장, 첫절, 끝장, 끝절)}`.

    ⚠ 절마다 물으면 조회가 절 수만큼이다 — 목록·본문 화면은 이 문.
    """
    vids = [int(v) for v in (verse_ids or [])]
    if not vids:
        return {}
    ph = ','.join('?' * len(vids))
    try:
        rows = conn.execute(
            'SELECT verse_id, heb_chapter, heb_verse, heb_chapter_end,'
            ' heb_verse_end FROM %s WHERE verse_id IN (%s)' % (TABLE, ph),
            vids).fetchall()
    except Exception:                                         # noqa: BLE001
        return {}
    return {r[0]: _tidy(r[1:]) for r in rows}


def label(ref, cur_chapter=None):
    """`(c1, v1, c2, v2)` → 「2」 · 「1-2」 · 「3:19」 · 「25:19-26:1」.

    ★ **장이 우리와 같으면 절만 적는다** — 절마다 장을 적으면 줄이 지저분하다.
      `cur_chapter` 를 주면 그 판단을 한다(안 주면 언제나 장까지 적는다).
    """
    if not ref:
        return ''
    c1, v1, c2, v2 = ref
    if c1 != c2:                       # 장을 넘는 구간 — 두 끝을 다 적는다
        return '%d:%d-%d:%d' % (c1, v1, c2, v2)
    v = str(v1) if v1 == v2 else '%d-%d' % (v1, v2)
    return v if (cur_chapter is not None and cur_chapter == c1) \
        else '%d:%s' % (c1, v)


# ── 검사 ─────────────────────────────────────────────────────────────
def _selftest():
    ok, bad = [], []

    def chk(name, cond, got=''):
        (ok if cond else bad).append(name)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', name, str(got)[:72]))

    # ⓐ 되짚기 — 붙여 놓은 본문에서 번호를 되살리는가
    wlc = [(3, 1, 'aa', []), (3, 2, 'bb', []), (3, 3, 'cc', [])]
    got = _refs_for_book(wlc, [(101, 'aa bb', []), (102, 'cc', [])])
    chk('합쳐진 칸을 구간으로 되살린다', got[0] == (101, 3, 1, 3, 2), got)
    chk('그다음 칸은 그 뒤에서 잇는다', got[1] == (102, 3, 3, 3, 3), got)
    chk('못 맞추면 버린다 — 지어내지 않는다',
        _refs_for_book(wlc, [(103, 'zz', [])]) == [])
    w2 = [(2, 32, 'x', []), (3, 1, 'y', [])]
    chk('★ 장을 넘는 구간도 두 끝을 든다',
        _refs_for_book(w2, [(1, 'x y', [])]) == [(1, 2, 32, 3, 1)],
        _refs_for_book(w2, [(1, 'x y', [])]))

    # ⓑ 이름표
    chk('한 절이면 숫자 하나', label((3, 2, 3, 2), 3) == '2')
    chk('구간이면 붙임표', label((3, 1, 3, 2), 3) == '1-2')
    chk('장이 다르면 장도 적는다', label((3, 19, 3, 19), 4) == '3:19')
    chk('장을 넘으면 두 끝을 다 적는다',
        label((25, 19, 26, 1), 26) == '25:19-26:1')
    chk('없으면 빈 글자', label(None) == '')

    # ⓒ 덮음 검사 자체의 탐지력 — 흠을 심으면 잡는가
    src = {1: [(1, 1), (1, 2), (1, 3)]}
    _BOOK_OF.clear()
    _BOOK_OF[1] = {10, 11, 12}
    good = [(10, 1, 1, 1, 1), (11, 1, 2, 1, 2), (12, 1, 3, 1, 3)]
    b1, m1 = cover(good, src)
    chk('★ 깨끗하면 흠 0', not b1 and not m1, (b1, m1))
    b2, _ = cover([(10, 1, 1, 1, 1), (11, 1, 1, 1, 1), (12, 1, 3, 1, 3)], src)
    chk('   (탐지력) 겹치면 잡는다', bool(b2), b2[:2])
    b3, _ = cover([(10, 1, 2, 1, 2), (11, 1, 1, 1, 1), (12, 1, 3, 1, 3)], src)
    chk('   (탐지력) 차례가 거꾸로면 잡는다', bool(b3), b3[:2])
    b4, m4 = cover([(10, 1, 1, 1, 1), (11, 1, 2, 1, 2)], src)
    chk('   (탐지력) 빠진 절을 센다', m4.get(1) == 1, m4)
    _BOOK_OF.clear()

    # ⓓ 실 DB — 원문에서 만들어 알려진 자리·덮음으로 잰다
    try:
        import appdb
        c = appdb.connect()
        rows, src = build(c)
        chk('원문에서 지도를 만든다', len(rows) > 22000, len(rows))
        index_by_book(c, rows)
        d = {v: (c1, v1) for v, c1, v1, _c2, _v2 in rows}
        miss = []
        for bc, ch, vs, hch, hv in KNOWN:
            r = c.execute('SELECT verse_id FROM bible_index WHERE bcode=?'
                          ' AND chapter=? AND verse=?',
                          (bc, ch, vs)).fetchone()
            g = d.get(r[0]) if r else None
            if g != (hch, hv):
                miss.append('%d %d:%d → %s (%d:%d 이라야)'
                            % (bc, ch, vs, g, hch, hv))
        chk('★★★ 알려진 자리 %d 곳이 전부 맞는다' % len(KNOWN),
            not miss, miss[:3])
        full = {v: (c1, v1, c2, v2) for v, c1, v1, c2, v2 in rows}
        r3 = c.execute('SELECT verse_id FROM bible_index WHERE bcode=19'
                       ' AND chapter=3 AND verse=1').fetchone()[0]
        chk('시 3:1 이 히브리 1~2절 구간', full.get(r3) == (3, 1, 3, 2),
            full.get(r3))
        r4 = c.execute('SELECT verse_id FROM bible_index WHERE bcode=4'
                       ' AND chapter=26 AND verse=1').fetchone()[0]
        chk('★ 민 26:1 이 히브리 25:19~26:1', full.get(r4) == (25, 19, 26, 1),
            full.get(r4))
        bd, ms = cover(rows, src)
        chk('★★★ 원문 히브리 절이 겹치지도 거꾸로 가지도 않는다',
            not bd, bd[:3])
        chk('   덮지 못한 절이 적다 (책 %d권)' % len(ms),
            sum(ms.values()) < 60, '%d절' % sum(ms.values()))
        df = differing(c, rows)
        chk('번호가 다른 절만 담는다', 0 < len(df) < len(rows),
            '%d / %d' % (len(df), len(rows)))
        g11 = c.execute('SELECT verse_id FROM bible_index WHERE bcode=1 AND'
                        ' chapter=1 AND verse=1').fetchone()[0]
        chk('   창 1:1 은 안 담는다', g11 not in {x[0] for x in df})
        try:
            n = c.execute('SELECT COUNT(*) FROM %s' % TABLE).fetchone()[0]
        except Exception:                                     # noqa: BLE001
            n = 0
        if n:
            v0 = df[0][0]
            chk('읽는 문이 낱낱으로 낸다', heb_ref(c, v0) is not None)
            chk('읽는 문이 여러 절을 한 번에', len(heb_refs(c, [v0])) == 1)
            chk('   같은 번호인 절은 안 낸다', heb_ref(c, g11) is None)
            chk('   담긴 수가 만든 수와 같다',
                n == len(df), '%d / %d' % (n, len(df)))
        c.close()
    except Exception as e:                                    # noqa: BLE001
        chk('실 DB', False, repr(e)[:90])

    print('\ndb_heb_versemap selftest %d/%d' % (len(ok), len(ok) + len(bad)))
    return not bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--show', nargs=2, type=int, metavar=('BCODE', 'CH'))
    a = ap.parse_args()
    if a.selftest:
        return 0 if _selftest() else 1

    import appdb
    c = appdb.connect()
    if a.show:
        b, ch = a.show
        for vid, v in c.execute(
                'SELECT verse_id, verse FROM bible_index WHERE bcode=? AND'
                ' chapter=? ORDER BY verse', (b, ch)):
            r = heb_ref(c, vid)
            print('  %d:%-3d → 히브리 %s' % (ch, v, label(r) or '(같다)'))
        c.close()
        return 0

    rows, src = build(c)
    index_by_book(c, rows)
    bd, ms = cover(rows, src)
    df = differing(c, rows)
    print('원문에서 맞춘 절 %d · 번호가 **다른** 절 %d' % (len(rows), len(df)))
    print('겹침·거꾸로 흠 %d · 덮지 못한 절 %d (책 %d권)'
          % (len(bd), sum(ms.values()), len(ms)))
    for x in bd[:10]:
        print('   ⚠', x)
    byb = collections.Counter()
    bk = dict(c.execute('SELECT verse_id, bcode FROM bible_index'
                        ' WHERE bcode<=39'))
    for vid, *_ in df:
        byb[bk.get(vid)] += 1
    print('\n책마다 (많은 차례)')
    for b, n in byb.most_common(14):
        nm = c.execute("SELECT short_name FROM book_names WHERE book_code=?"
                       " AND UPPER(lang_code)='KO'", (b,)).fetchone()
        print('   %-8s %5d절' % (nm[0] if nm else b, n))
    if a.apply:
        if bd:
            print('\n⚠ 흠이 있어 적재하지 않는다 — 먼저 고친다')
            c.close()
            return 1
        print('\n적재 %d행' % apply_rows(c, df))
    c.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
