# -*- coding: utf-8 -*-
"""db_vers_run.py — 구약 절별자산 **책 단위 자동 운행** (영구 도구, §0-5 KEEP).

한 책의 장절 구조를 지도(`_run/map_<bcode>.tsv`)로 먼저 펼쳐 놓고, 그 지도를 따라
장 하나씩 걸어간다. **한 장 = 승인 1회**(`--apply` 하나)가 이 도구의 존재 이유다.

    python -X utf8 db_vers_run.py --map 4          지도 생성/갱신 (상태는 보존)
    python -X utf8 db_vers_run.py --status 4       진행 현황
    python -X utf8 db_vers_run.py --next 4         다음 장의 스텝카드 + 재료 (읽기 전용)
    python -X utf8 db_vers_run.py --apply <draft>  적재→커버리지→게이트→문체→상태갱신
    python -X utf8 db_vers_run.py --selftest

★ 왜 이렇게 짰나 (2026-08-10 사용자 설계)

① **걸음은 장, 절은 체크칸.** 절 단위로 걸으면 문맥이 끊긴다 — 민 11장의
   1절(진 끝) → 4절(가장자리) → 35절(한가운데)은 장 전체를 쥐고 있어야 나온다.
   게이트도 문체 편차도 장 통계다. 절은 `--apply` 의 **커버리지 대조**로 쓴다.

② **트리거는 파일이 아니라 출력의 꼬리에 심는다.** 정적 파일의 「다음은 2절」은
   한 번 읽고 잊힌다. 도구 출력은 그것이 필요한 순간에 읽히므로 매번 걸린다.
   그래서 `--next` 는 끝에 `--apply` 를, `--apply` 는 끝에 `--next` 를 찍는다.

③ **완료 도장은 게이트가 찍는다.** 사람이 지도의 state 를 손으로 고치지 않는다.
   집필자가 스스로 「완료」라고 적는 표시는 못 믿는다.

④ **게이트 FAIL 이면 DB 를 되돌린다.** 로더는 커밋한 뒤에 끝나므로, 적재 전에
   그 절 범위를 통째로 떠 놓았다가 실패하면 복원한다(data.md 스테이징 원칙).

⑤ **지침을 도구가 들이민다.** 민 8·10장이 같은 버릇으로 연속 11건씩 걸렸고,
   11장은 착수 직전에 `lay.md` §8 을 다시 읽어 0건이 됐다. 그 「다시 읽기」를
   사람의 기억에 맡기지 않고 `--next` 가 매번 찍는다.
"""
import argparse
import hashlib
import io
import json
import os
import sys

import appdb
import db_vers_gate as G
import db_vers_prep as P
import db_vers_style as S
import db_verse_text_loader as L

RUN_DIR = '_run'
COLS = ['bcode', 'ch', 'verses', 'vid_from', 'vid_to', 'state',
        'keystone', 'mode', 'stop', 'note']
ASSET_TYPES = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER')
SRCS = ['GILL', 'CLARKE', 'JFB', 'PULPIT_COM', 'BARNES_OT']
COMM_MAX = 1600

# 모드별 주의 — 되풀이 본문에서 없는 내용을 짜내지 않기 위한 것. 민 7장에서 정한 원칙.
MODE_NOTE = {
    'NARR': '서사. 사람과 장면에서 출발한다.',
    'LIST': ('되풀이/목록 본문. **없는 내용을 짜내지 않는다** — ① 마디의 첫 절에 그 단위의 '
             '이야기를 싣고 ② 첫 항목이 기준이 되며 ③ 나머지는 두 문장으로 짧게. '
             '묵상질문은 마디에만. 억지로 채우면 민 5장 반려 때와 같은 글이 된다.'),
    'LAW': ('율법. **조문이 아니라 그 조문이 다루는 상황을 쓴다**(lay.md 검사 ⑤). '
            '조건절은 「만일 ~라면」으로 편다. 민 5장이 31절 중 15절 여기 걸렸다.'),
}

# 문체 드리프트 문턱 — 앞 장들의 이동평균과 견준다. 판정이 아니라 **정지 신호**다.
# db_vers_style 은 판정을 안 한다(「문턱은 바닥값을 모은 뒤에 정한다」). 무인 운행에서는
# 아무도 안 보고 있으므로 여기서만 세운다. 넘으면 멈추고 사람을 부른다.
#
# ⚠ 2026-08-10 조정 — 첫 실전(민 12장)에서 **상대값만으로는 안 걸렸다.**
#   민 1~11장 명사화 바닥이 0.00~0.08(평균 0.03)인데 12장이 0.44 로 열 배 넘게 뛰었어도
#   「평균 +0.60」 문턱에는 못 미쳤다. 바닥이 0 에 가까우면 상대 문턱은 영원히 안 울린다.
#   ⇒ **절대 상한을 함께 건다.** 둘 중 하나만 넘어도 멈춘다.
DRIFT = dict(nominal=0.30, thing=0.60, sd_floor=10.0)
DRIFT_REL = dict(nominal=0.20, thing=0.30)
DRIFT_WINDOW = 5


def _out():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass


def _map_path(bcode):
    return os.path.join(RUN_DIR, 'map_%d.tsv' % bcode)


def _style_path(bcode):
    return os.path.join(RUN_DIR, 'style_%d.tsv' % bcode)


# ── 지도 ────────────────────────────────────────────────────────────────────
def read_map(bcode):
    p = _map_path(bcode)
    if not os.path.exists(p):
        return []
    rows = []
    with io.open(p, encoding='utf-8') as f:
        head = f.readline().rstrip('\n').split('\t')
        for line in f:
            if not line.strip():
                continue
            v = line.rstrip('\n').split('\t')
            v += [''] * (len(head) - len(v))
            rows.append(dict(zip(head, v)))
    return rows


def write_map(bcode, rows):
    os.makedirs(RUN_DIR, exist_ok=True)
    with io.open(_map_path(bcode), 'w', encoding='utf-8', newline='') as f:
        f.write('\t'.join(COLS) + '\n')
        for r in rows:
            f.write('\t'.join(str(r.get(c, '')) for c in COLS) + '\n')


def build_map(bcode):
    """bible_index 에서 장절 구조를 뽑아 지도를 만든다. **기존 state·주석은 보존한다.**"""
    c = appdb.connect()
    q = ("SELECT chapter, COUNT(*), MIN(verse_id), MAX(verse_id) FROM bible_index"
         " WHERE bcode=? GROUP BY chapter ORDER BY chapter")
    old = {int(r['ch']): r for r in read_map(bcode)}
    rows = []
    for ch, n, lo, hi in c.execute(q, (bcode,)):
        prev = old.get(ch, {})
        rows.append(dict(bcode=bcode, ch=ch, verses=n, vid_from=lo, vid_to=hi,
                         state=prev.get('state', 'TODO'),
                         keystone=prev.get('keystone', ''),
                         mode=prev.get('mode', 'NARR'),
                         stop=prev.get('stop', ''),
                         note=prev.get('note', '')))
    c.close()
    write_map(bcode, rows)
    return rows


def mark_done(bcode, ch, state):
    rows = read_map(bcode)
    for r in rows:
        if int(r['ch']) == ch:
            r['state'] = state
    write_map(bcode, rows)


# ── 지침 (단일 소스에서 뽑는다 — 복사하면 어긋난다) ──────────────────────────
def _lay_checks():
    """lay.md §2 의 검사 블록. 문서가 단일 소스이므로 하드코딩하지 않는다."""
    try:
        t = io.open('lay.md', encoding='utf-8').read()
    except Exception:
        return ['(lay.md 를 못 읽었다 — 직접 열 것)']
    body = t.split('## 2.')[1].split('### 쓴다')[0] if '## 2.' in t else ''
    return [ln for ln in body.splitlines() if ln.startswith('>')] or ['(§2 를 못 찾았다)']


def _lay_recent(n=3):
    """lay.md §8 표의 최근 n건. 민 11장이 0건으로 끊긴 방법이 이걸 먼저 읽는 것이었다."""
    try:
        t = io.open('lay.md', encoding='utf-8').read()
    except Exception:
        return []
    if '## 8.' not in t:
        return []
    body = t.split('## 8.')[1]
    hits = []
    for ln in body.splitlines():
        ln = ln.strip()
        if not ln.startswith('|') or ln.startswith('|---') or '무엇이' in ln:
            continue
        cells = [x.strip() for x in ln.strip('|').split('|')]
        if len(cells) >= 3 and cells[0]:
            hits.append(cells)
    return hits[-n:]


def _prev_tail(c, bcode, ch):
    """앞 장의 마지막 절. 장 사이가 끊기지 않게 하려고 싣는다."""
    if ch <= 1:
        return None
    r = c.execute("SELECT verse_id, verse FROM bible_index WHERE bcode=? AND chapter=?"
                  " ORDER BY verse DESC LIMIT 1", (bcode, ch - 1)).fetchone()
    if not r:
        return None
    t = c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='KRV'",
                  (r[0],)).fetchone()
    return '%d:%d %s' % (ch - 1, r[1], t[0] if t else '')


# ── --next ──────────────────────────────────────────────────────────────────
def cmd_next(bcode):
    rows = read_map(bcode)
    if not rows:
        print('지도가 없다. 먼저: python -X utf8 db_vers_run.py --map %d' % bcode)
        return 2
    todo = [r for r in rows if r['state'] != 'DONE']
    if not todo:
        print('%s 전권 완료.' % bcode)
        return 0
    r = todo[0]
    ch, lo, hi = int(r['ch']), int(r['vid_from']), int(r['vid_to'])
    done = sum(1 for x in rows if x['state'] == 'DONE')
    c = appdb.connect()
    bn = c.execute("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'",
                   (bcode,)).fetchone()
    name = bn[0] if bn else str(bcode)

    bar = '=' * 72
    print(bar)
    print(' %s %s장 · %s절 · vid %d~%d      [%d/%d 완료 · 남은 %d장]'
          % (name, r['ch'], r['verses'], lo, hi, done, len(rows), len(todo)))
    print(bar)
    mode = r['mode'] or 'NARR'
    print('[모드] %s — %s' % (mode, MODE_NOTE.get(mode, '')))
    if r['keystone']:
        print('[키스톤] %s — 분량 2배' % r['keystone'])
    if r['note']:
        print('[비고] %s' % r['note'])
    if r['stop']:
        print('[정지선] 이 장을 마치면 큐가 멈춘다. 사용자 검수 대상이다.')
    print()

    print('── 지침 · lay.md §2 (문단마다 스스로 건다) ' + '─' * 25)
    for ln in _lay_checks():
        print(ln)
    print()
    print('── 최근 걸린 것 · lay.md §8 ' + '─' * 40)
    for cells in _lay_recent():
        print('· %s | %s' % (cells[0], ' → '.join(cells[1:])[:240]))
    print()

    tail = _prev_tail(c, bcode, ch)
    if tail:
        print('── 앞 장 꼬리 ' + '─' * 53)
        print(tail)
        print()

    print('── 재료 ' + '─' * 59)
    seen = set()
    q = ("SELECT verse_id, verse FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse")
    for vid, vs in c.execute(q, (bcode, ch)):
        print()
        print('## %d:%d   vid %d' % (ch, vs, vid))
        for ver in ('KRV', 'BSB'):
            t = c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND"
                          " version_code=?", (vid, ver)).fetchone()
            print('**%s** %s' % (ver, t[0] if t else ''))
        for code, body in P.commentaries(c, vid, SRCS, COMM_MAX):
            # JFB 는 장 단위 항목이라 절마다 같은 덩어리가 붙는다. 한 번만 싣는다.
            h = hashlib.md5((code + body[:400]).encode('utf-8')).hexdigest()
            if h in seen:
                continue
            seen.add(h)
            print('--- %s (%d자) ---' % (code, len(body)))
            print(body)
    c.close()

    draft = '_vers_prep/draft_%s_%d.json' % (_slug(bcode), ch)
    print()
    print(bar)
    print(' 초안은 **장당 파일 하나**로 쓴다. 다 쓰면 순서는 둘.')
    print('   ① 통과할 때까지  python -X utf8 db_vers_run.py --check %s' % draft)
    print('   ② 통과하면       python -X utf8 db_vers_run.py --apply %s' % draft)
    print(' ①은 되돌리므로 DB 를 바꾸지 않는다. 승인이 드는 것은 ② 하나다.')
    print(bar)
    return 0


def _slug(bcode):
    return {1: 'gen', 2: 'exo', 3: 'lev', 4: 'num', 5: 'deu'}.get(bcode, 'b%d' % bcode)


# ── 스냅샷 / 복원 ───────────────────────────────────────────────────────────
def _cols(conn):
    return [r[1] for r in conn.execute("PRAGMA table_info(sys_text_asset)")]


def _snapshot(conn, lo, hi):
    cols = _cols(conn)
    ph = ','.join(['?'] * len(ASSET_TYPES))
    q = ("SELECT %s FROM sys_text_asset WHERE clicked_id BETWEEN ? AND ?"
         " AND text_type IN (%s)" % (','.join(cols), ph))
    return cols, conn.execute(q, (lo, hi) + ASSET_TYPES).fetchall()


def _restore(conn, lo, hi, cols, rows):
    """게이트가 막으면 적재 전 상태로 되돌린다.

    ⚠ clicked_id 만으로 지우면 안 된다 — VERS_VERS_DESC 의 clicked_id 는 sys_link_id 라
      절 vid 와 값이 겹칠 수 있다. text_type 을 반드시 함께 건다.
    """
    ph = ','.join(['?'] * len(ASSET_TYPES))
    conn.execute("DELETE FROM sys_text_asset WHERE clicked_id BETWEEN ? AND ?"
                 " AND text_type IN (%s)" % ph, (lo, hi) + ASSET_TYPES)
    if rows:
        conn.executemany("INSERT INTO sys_text_asset(%s) VALUES(%s)"
                         % (','.join(cols), ','.join(['?'] * len(cols))), rows)
    conn.commit()


# ── 커버리지 (절 단위 체크칸) ───────────────────────────────────────────────
def coverage(conn, bcode, ch):
    """그 장의 모든 절에 VERS_DESC KO·EN 이 있는지 대조. 빠진 절 목록을 돌려준다.

    게이트의 구조 검사는 있는 것을 세지 **없는 것을 찾지 않는다.** 자동 운행에서
    한 절이 통째로 빠지면 아무도 모른 채 DONE 이 찍힌다.
    """
    miss = []
    q = "SELECT verse_id, verse FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse"
    for vid, vs in conn.execute(q, (bcode, ch)).fetchall():
        for lang in ('KO', 'EN'):
            r = conn.execute(
                "SELECT 1 FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_DESC'"
                " AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (vid, lang)).fetchone()
            if not r:
                miss.append('%d:%d %s' % (ch, vs, lang))
    return miss


# ── 문체 드리프트 ───────────────────────────────────────────────────────────
def style_row(bcode, ch):
    buckets, _ = S.from_db(bcode, ch, ch)
    m = S._blend(buckets['LAY'])
    if not m:
        return None
    u = max(m.get('units', 1), 1)
    return dict(ch=ch, units=u, chars=m['chars'], sents=m['sents'], mean=m['mean'],
                sd=m['sd'], thing=m['thing'] / u, nominal=m['nominal'] / u,
                selfqa=m['selfqa'] / u, sino=m['sino'])


def style_history(bcode):
    p = _style_path(bcode)
    if not os.path.exists(p):
        return []
    out = []
    with io.open(p, encoding='utf-8') as f:
        head = f.readline().rstrip('\n').split('\t')
        for line in f:
            if line.strip():
                out.append(dict(zip(head, [float(x) for x in line.rstrip('\n').split('\t')])))
    return out


STYLE_KEYS = ['ch', 'units', 'chars', 'sents', 'mean', 'sd', 'thing', 'nominal',
              'selfqa', 'sino']


def style_append(bcode, row):
    """같은 장을 다시 적재하면 **덧붙이지 않고 갈아 끼운다.**

    ⚠ 처음엔 그냥 append 였다. 민 12장을 고쳐서 두 번 적재했더니 0.44 와 0.00 이
      둘 다 남아 이동평균이 오염됐다 — 드리프트 감시가 자기 실패의 기록으로 무뎌진다.
    """
    os.makedirs(RUN_DIR, exist_ok=True)
    rows = [h for h in style_history(bcode) if int(h['ch']) != int(row['ch'])]
    rows.append({k: row[k] for k in STYLE_KEYS})
    rows.sort(key=lambda h: int(h['ch']))
    with io.open(_style_path(bcode), 'w', encoding='utf-8', newline='') as f:
        f.write('\t'.join(STYLE_KEYS) + '\n')
        for h in rows:
            f.write('\t'.join('%g' % h[k] for k in STYLE_KEYS) + '\n')


def drift(bcode, row):
    """앞 장들과 견줘 튀는지 본다. 경고 문자열 리스트."""
    hist = [h for h in style_history(bcode) if int(h['ch']) != row['ch']][-DRIFT_WINDOW:]
    w = []
    if row['sd'] < DRIFT['sd_floor']:
        w.append('문장길이 편차 %.1f — 하한 %.1f. 선택하면 기계가 쓴 것처럼 읽힌다(lay.md §3)'
                 % (row['sd'], DRIFT['sd_floor']))
    for k in ('nominal', 'thing'):
        if row[k] > DRIFT[k]:
            w.append('%s %.2f/절 — 절대 상한 %.2f 초과' % (k, row[k], DRIFT[k]))
            continue
        if not hist:
            continue
        base = sum(h[k] for h in hist) / len(hist)
        if row[k] > base + DRIFT_REL[k]:
            w.append('%s %.2f/절 — 앞 %d장 평균 %.2f 대비 +%.2f (문턱 +%.2f)'
                     % (k, row[k], len(hist), base, row[k] - base, DRIFT_REL[k]))
    return w


# ── --apply ─────────────────────────────────────────────────────────────────
def cmd_apply(path, dry=False):
    """dry=True 면 **반드시 되돌린다** — 게이트가 통과해도 DB 를 그대로 둔다.

    ★ 왜 필요한가 (2026-08-10 민 13장에서 드러났다). 한 장 = 승인 1회가 이 도구의
      목적인데, 초안이 걸리면 고쳐서 다시 `--apply` 를 부르느라 승인이 3회가 됐다.
      **검사는 읽기 전용이어야 통과할 때까지 몇 번이든 돌릴 수 있다** — peri.md 가
      `db_peri_load.py --check` 로 이미 같은 결론에 이르렀다.
      적재해 보고 되돌리는 방식을 쓰는 까닭은, 본문 재진술 검사가 DB 를 읽기 때문이다.
      초안만 보고 흉내 내면 검사기와 어긋난다(§8-3 의 그 실패).
    """
    if not os.path.exists(path):
        print('초안이 없다: %s' % path)
        return 2
    rows = json.load(io.open(path, encoding='utf-8'))
    vids = sorted({int(r['clicked_id']) for r in rows})
    conn = appdb.connect()
    q = "SELECT bcode, chapter FROM bible_index WHERE verse_id IN (%s)" % \
        ','.join(['?'] * len(vids))
    got = {(b, ch) for b, ch in conn.execute(q, vids)}
    if len(got) != 1:
        print('초안이 한 장에 속하지 않는다: %s' % sorted(got))
        print('**장당 파일 하나**가 규칙이다. 나누어 다시 적재하라.')
        conn.close()
        return 2
    bcode, ch = got.pop()
    lo, hi = min(vids), max(vids)
    print('bcode %d · %d장 · 초안 %d행 · vid %d~%d' % (bcode, ch, len(rows), lo, hi))

    cols, snap = _snapshot(conn, lo, hi)
    print('스냅샷 %d행 확보 — 게이트가 막으면 되돌린다.' % len(snap))
    conn.close()

    # ① 적재 (로더가 절 단위 규격을 먼저 건다. 거부되면 DB 무변경)
    print('\n── 적재 %s' % ('(검사용 — 되돌린다) ' + '─' * 39 if dry else '─' * 59))
    if L.load(path) != 0:
        if not dry:
            mark_done(bcode, ch, 'FAIL')
        return 1

    conn = appdb.connect()
    fatal = []

    # ② 커버리지 — 절 단위 체크칸
    print('\n── 커버리지 ' + '─' * 55)
    miss = coverage(conn, bcode, ch)
    if miss:
        fatal.append('빠진 절 %d건: %s' % (len(miss), ', '.join(miss[:12])))
        print('  X 빠진 절 %d건 — %s' % (len(miss), ', '.join(miss[:12])))
    else:
        print('  전 절 KO·EN 있음')

    # ③ 게이트
    print('\n── 게이트 ' + '─' * 57)
    for name, fn in G.CHECKS:
        out = []
        res = fn(bcode, ch, ch, out)
        mark = {True: 'PASS', False: 'FAIL', None: 'SKIP'}[res]
        print('[%s] %s' % (name, mark))
        for ln in out:
            print(ln)
        if res is False:
            fatal.append('게이트 %s FAIL' % name)

    if fatal or dry:
        srow = style_row(bcode, ch)
        _restore(conn, lo, hi, cols, snap)
        conn.close()
        print('\n' + '=' * 72)
        if dry:
            if srow:
                print('문체(초안) 명사화 %.2f · 사물주어 %.2f · 편차 %.1f'
                      % (srow['nominal'], srow['thing'], srow['sd']))
                for m in drift(bcode, srow):
                    print(' ⚠ ' + m)
            print('검사만 했다 — %s. DB 는 손대지 않았다.'
                  % ('위반 %d건' % len(fatal) if fatal else '통과'))
            for m in fatal:
                print('  X ' + m)
            if not fatal:
                print(' 적재하려면: python -X utf8 db_vers_run.py --apply %s' % path)
            return 1 if fatal else 0
        print('되돌린다 — %s' % ' / '.join(fatal))
        mark_done(bcode, ch, 'FAIL')
        print('DB 는 적재 전 상태다. 초안을 고쳐 같은 명령을 다시 실행하라.')
        return 1
    conn.close()

    # ④ 문체
    print('\n── 문체 ' + '─' * 59)
    srow = style_row(bcode, ch)
    warns = []
    if srow:
        print('LAY %d절 %d자 · 문장 %d · 평균 %.1f · 편차 %.1f | 사물주어 %.2f 명사화 %.2f '
              '자문자답 %.2f 한자어 %.3f'
              % (srow['units'], srow['chars'], srow['sents'], srow['mean'], srow['sd'],
                 srow['thing'], srow['nominal'], srow['selfqa'], srow['sino']))
        warns = drift(bcode, srow)
        style_append(bcode, srow)

    mark_done(bcode, ch, 'DONE')

    # ⑤ 꼬리 — 다음 걸음을 여기 심는다
    mp = read_map(bcode)
    cur = next((r for r in mp if int(r['ch']) == ch), {})
    left = [r for r in mp if r['state'] != 'DONE']
    print('\n' + '=' * 72)
    print(' %d장 DONE · 남은 %d장' % (ch, len(left)))
    if warns:
        print(' ⚠ 문체 점검 필요 — 사람이 보고 나서 계속한다')
        for w in warns:
            print('   · ' + w)
    if cur.get('stop'):
        print(' ■ 정지선 — 사용자 검수 지점이다. 여기서 멈춘다.')
    elif warns:
        pass
    elif left:
        print(' 다음: python -X utf8 db_vers_run.py --next %d      # %s장'
              % (bcode, left[0]['ch']))
    else:
        print(' 전권 완료. 이제 페리코프·장 설명문 차례다(lay.md §6).')
    print('=' * 72)
    return 0


def cmd_status(bcode):
    rows = read_map(bcode)
    if not rows:
        print('지도가 없다.')
        return 2
    done = [r for r in rows if r['state'] == 'DONE']
    fail = [r for r in rows if r['state'] == 'FAIL']
    left = [r for r in rows if r['state'] not in ('DONE',)]
    nv = sum(int(r['verses']) for r in rows)
    dv = sum(int(r['verses']) for r in done)
    print('bcode %d · %d장 %d절 | 완료 %d장 %d절 (%.0f%%) · 남은 %d장 %d절'
          % (bcode, len(rows), nv, len(done), dv, 100.0 * dv / max(nv, 1),
             len(left), nv - dv))
    if fail:
        print('FAIL: %s' % ', '.join(r['ch'] for r in fail))
    stops = [r['ch'] for r in rows if r['stop'] and r['state'] != 'DONE']
    if stops:
        print('앞으로의 정지선: %s장' % ', '.join(stops))
    for h in style_history(bcode)[-6:]:
        print('  %2d장  편차 %.1f  사물주어 %.2f  명사화 %.2f'
              % (h['ch'], h['sd'], h['thing'], h['nominal']))
    return 0


def selftest():
    """★ 의무. 여기서 막아야 하는 것은 **되돌리기와 커버리지**다 — 자동 운행에서
    아무도 안 보고 있을 때 통째로 새는 두 구멍이다."""
    print('db_vers_run 자가 검증')
    bad = []
    conn = appdb.connect()

    # ① 스냅샷은 VERS_* 만 집는다 (VERS_VERS_DESC 의 link_id 충돌 방지)
    cols, snap = _snapshot(conn, 4026, 4060)
    tt = {r[cols.index('text_type')] for r in snap}
    if tt - set(ASSET_TYPES):
        bad.append('스냅샷이 대상 밖 text_type 을 집는다: %s' % (tt - set(ASSET_TYPES)))
    if not snap:
        bad.append('민 11장 스냅샷이 비었다 — 범위 질의가 틀렸다')

    # ② 커버리지가 빠진 절을 실제로 찾는가
    #    ⚠ 예전에는 「아직 안 쓴 장」으로 **민 36장을 좌표에 박아** 두었는데,
    #      2026-08-12 민수기 완간으로 그 장이 채워지자 검사가 통째로 FAIL 했다.
    #      **데이터 상태에 기대는 자가 검증은 데이터가 채워질 때마다 깨진다.**
    #      그래서 완료된 장에서 한 절을 지웠다 되돌리는 방식으로 바꿨다 —
    #      책을 쓸수록 오히려 더 튼튼해지고, 되돌리기까지 함께 검사한다.
    if coverage(conn, 4, 11):
        bad.append('완료된 민 11장을 미완으로 본다')
    else:
        vid = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=4 AND chapter=11'
                           ' ORDER BY verse LIMIT 1').fetchone()[0]
        try:
            conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND"
                         " text_type='VERS_DESC' AND lang_code='KO'", (vid,))
            if not coverage(conn, 4, 11):
                bad.append('절을 지웠는데도 빠진 절을 못 찾는다 — 커버리지가 죽었다')
        finally:
            conn.rollback()
        if coverage(conn, 4, 11):
            bad.append('되돌리기가 안 됐다 — 민 11장이 지운 채로 남았다')
    conn.close()

    # ③ 지침을 문서에서 실제로 뽑는가
    if len(_lay_checks()) < 3:
        bad.append('lay.md §2 를 못 뽑는다')
    if len(_lay_recent()) < 1:
        bad.append('lay.md §8 최근 사례를 못 뽑는다')

    # ④ 드리프트가 튀는 값을 잡는가
    base = dict(ch=99, units=10, chars=1, sents=1, mean=30, sd=15,
                thing=0.1, nominal=0.1, selfqa=0, sino=0.05)
    if drift(4, dict(base, sd=3.0)) == []:
        bad.append('선택한 문장길이를 통과시킨다')

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 8개 항목')
    return 0


def main():
    _out()
    ap = argparse.ArgumentParser()
    ap.add_argument('--map', type=int)
    ap.add_argument('--status', type=int)
    ap.add_argument('--next', type=int)
    ap.add_argument('--apply')
    ap.add_argument('--check', help='적재해 보고 반드시 되돌린다 — 읽기 전용. 통과할 때까지 돌린다')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.map:
        rows = build_map(a.map)
        print('지도 %d장 → %s' % (len(rows), _map_path(a.map)))
        return 0
    if a.status:
        return cmd_status(a.status)
    if a.next:
        return cmd_next(a.next)
    if a.check:
        return cmd_apply(a.check, dry=True)
    if a.apply:
        return cmd_apply(a.apply)
    ap.print_help()
    return 0


if __name__ == '__main__':
    sys.exit(main())
