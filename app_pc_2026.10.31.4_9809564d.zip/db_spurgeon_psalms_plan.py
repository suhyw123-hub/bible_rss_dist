# -*- coding: utf-8 -*-
"""「스펄전과 함께 시편」 도서 플랜 적재 (영구 도구, 2026-08-17 — 설계안 7부)

  python db_spurgeon_psalms_plan.py --selftest    # 의무 (트랜잭션 롤백 — 흔적 없음)
  python db_spurgeon_psalms_plan.py --apply       # 적재 (멱등)

구조 — 하루 = 시편 한 편, 150일 (§17 BOOK_BASED 표준 그대로, 화면 수정 0):
  sys_book_asset   SPURGEON_TOD 「스펄전과 함께 시편」
  sys_book_unit    150개 (sequence = 시편 번호, 기준 구절 = 그 편 전체)
  sys_book_unit_text  ORIGINAL/EN = **Treasury 편별 서론**(TREASURY CHAPTER)
  sys_plan_category   cat 4(도서기반) 아래 새 묶음 (플랜 하나 = 묶음 이름 규칙)
  sys_bible_plan   SPURGEON_TOD_150D (BOOK_BASED · 150일 · LIVE)
  sys_plan_schedule   day N = BOOK_TEXT(서론) + CORE(시편 N 통독) 두 행

★ **본문의 원본은 주석(TREASURY)이다** — 이 도구는 서론을 도서 본문으로
  **복사**한다(§17 렌더러가 sys_book_unit_text 를 읽으므로). 갈라짐은 멱등으로
  막는다: **Treasury 를 재적재했으면 이 도구의 --apply 를 다시 돌린다** —
  서론을 주석에서 다시 읽어 도서 본문을 덮는다.
⚠ 일별 묵상포커스(meditation_focus)는 비워 둔다 — 150편 콘텐츠 저작은 별도
  작업이다(컬럼 NULL 허용).
"""
import os
import sys
import sqlite3

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')

BOOK_CODE = 'SPURGEON_TOD'
PLAN_CODE = 'SPURGEON_TOD_150D'
PSA_BCODE = 19
ATTRIB = '— C. H. Spurgeon, The Treasury of David (1885)'

TITLES = {'KO': '스펄전과 함께 시편', 'EN': 'Psalms with Spurgeon'}
DESCS = {
    'KO': '하루에 시편 한 편. 스펄전 『Treasury of David』의 편별 서론을 읽고 '
          '그 시편 전체를 통독합니다. 절을 누르면 주석 탭에서 스펄전의 절별 '
          '강해(Treasury)와 인용 모음(T.Notes)으로 더 깊이 들어갈 수 있습니다.',
    'EN': 'One psalm a day. Read the psalm introduction from Spurgeon\'s '
          'Treasury of David, then the whole psalm. Tap any verse to go '
          'deeper with Spurgeon\'s verse-by-verse exposition in the '
          'commentary tab.',
}


def _psalm_ranges(conn):
    """{n: (first_vid, last_vid)} — 시편 150편의 절 범위."""
    out = {}
    for n, a, b in conn.execute(
            'SELECT chapter, MIN(verse_id), MAX(verse_id) FROM bible_index '
            'WHERE bcode=? GROUP BY chapter', (PSA_BCODE,)):
        out[n] = (a, b)
    return out


def _intros(conn):
    """{n: 서론 본문} — TREASURY CHAPTER 항목(원본)."""
    return {ch: body for ch, body in conn.execute("""
        SELECT e.chapter, t.body_text
        FROM sys_commentary_entry e
        JOIN sys_commentary_text t ON t.entry_id=e.entry_id
             AND t.text_variant='ORIGINAL' AND UPPER(t.lang_code)='EN'
             AND t.record_status='LIVE'
        JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
        WHERE s.commentary_code='TREASURY' AND e.entry_level='CHAPTER'
          AND e.record_status='LIVE'""")}


def _upsert_text_asset(c, ttype, cid, lang, val):
    ex = c.execute(
        "SELECT sys_text_id FROM sys_text_asset WHERE text_type=? AND "
        "clicked_id=? AND UPPER(lang_code)=UPPER(?) AND record_status='LIVE'",
        (ttype, cid, lang)).fetchone()
    if ex:
        c.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?",
                  (val, ex[0]))
    else:
        c.execute("INSERT INTO sys_text_asset (text_type, clicked_id, title, "
                  "contents, lang_code, record_status) VALUES (?,?,?,?,?,'LIVE')",
                  (ttype, cid, '%s_%s' % (ttype, cid), val, lang))


def apply(conn, verbose=True):
    """멱등 적재. commit 은 호출자가 한다(selftest 가 롤백으로 검증)."""
    c = conn.cursor()
    intros = _intros(conn)
    if len(intros) != 150:
        raise ValueError('TREASURY 서론이 150이 아니라 %d — 먼저 적재하라'
                         % len(intros))
    ranges = _psalm_ranges(conn)

    # ① 도서
    row = c.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                    (BOOK_CODE,)).fetchone()
    if row:
        book_id = row[0]
    else:
        c.execute(
            """INSERT INTO sys_book_asset (book_code, title, author, lang_code,
               copyright_type, source_url, pub_year, description,
               record_status, book_category)
               VALUES (?,?,?,?,?,?,?,?,'LIVE','DEVOTIONAL')""",
            (BOOK_CODE, 'The Treasury of David — Psalm Introductions',
             'Charles H. Spurgeon', 'EN', 'PUBLIC_DOMAIN',
             'https://archive.spurgeon.org/treasury/treasury.php', 1885,
             'Psalm-by-psalm introductions (Title/Subject/Division) from the '
             'Treasury of David. Body text is synced from the TREASURY '
             'commentary — re-run db_spurgeon_psalms_plan.py --apply after '
             're-importing the Treasury.'))
        book_id = c.lastrowid

    # ② 유닛 150 + 본문 (sequence = 시편 번호, 멱등 upsert — unit_id 보존)
    for n in range(1, 151):
        a, b = ranges[n]
        label = '시편 %d편 (Psalm %d)' % (n, n)
        row = c.execute('SELECT unit_id FROM sys_book_unit WHERE book_id=? '
                        'AND sequence=?', (book_id, n)).fetchone()
        if row:
            uid = row[0]
            c.execute("UPDATE sys_book_unit SET unit_label=?, session_type="
                      "'CHAPTER', key_verse_ref=?, start_vid=?, end_vid=?, "
                      "record_status='LIVE' WHERE unit_id=?",
                      (label, '시 %d편' % n, a, b, uid))
        else:
            c.execute(
                """INSERT INTO sys_book_unit (book_id, sequence, session_type,
                   unit_label, key_verse_ref, start_vid, end_vid, record_status)
                   VALUES (?,?,'CHAPTER',?,?,?,?,'LIVE')""",
                (book_id, n, label, '시 %d편' % n, a, b))
            uid = c.lastrowid
        body = intros[n].rstrip() + '\n' + ATTRIB
        c.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? AND "
                  "text_variant='ORIGINAL' AND UPPER(lang_code)='EN'", (uid,))
        c.execute("INSERT INTO sys_book_unit_text (unit_id, text_variant, "
                  "lang_code, body_text, record_status) "
                  "VALUES (?,'ORIGINAL','EN',?,'LIVE')", (uid, body))

    # ③ 카테고리 — cat 4(도서기반) 아래 새 묶음. 플랜 하나 = 묶음 이름 규칙.
    row = c.execute("""SELECT t.clicked_id FROM sys_text_asset t
        JOIN sys_plan_category pc ON pc.cat_id=t.clicked_id
        WHERE t.text_type='PLAN_CAT_NAME' AND t.contents=? AND t.lang_code='KO'
          AND pc.parent_id=4 LIMIT 1""", (TITLES['KO'],)).fetchone()
    if row:
        cat_id = row[0]
    else:
        cat_id = c.execute(
            'SELECT COALESCE(MAX(cat_id),0)+1 FROM sys_plan_category'
        ).fetchone()[0]
        so = c.execute('SELECT COALESCE(MAX(sort_order),0)+10 FROM '
                       'sys_plan_category WHERE parent_id=4').fetchone()[0]
        c.execute("INSERT INTO sys_plan_category (cat_id, parent_id, "
                  "sort_order, record_status, scope) VALUES (?,4,?,'LIVE','BOOK')",
                  (cat_id, so))
    for lg in ('KO', 'EN'):
        _upsert_text_asset(c, 'PLAN_CAT_NAME', cat_id, lg, TITLES[lg])

    # ④ 플랜
    row = c.execute('SELECT plan_id FROM sys_bible_plan WHERE plan_code=?',
                    (PLAN_CODE,)).fetchone()
    if row:
        plan_id = row[0]
        c.execute("UPDATE sys_bible_plan SET plan_type='BOOK_BASED', "
                  "plan_category='THEMATIC', duration_days=150, track_count=1, "
                  "cat_id=?, record_status='LIVE' WHERE plan_id=?",
                  (cat_id, plan_id))
    else:
        c.execute(
            """INSERT INTO sys_bible_plan (plan_code, plan_type, duration_days,
               track_count, record_status, plan_category, cat_id)
               VALUES (?,'BOOK_BASED',150,1,'LIVE','THEMATIC',?)""",
            (PLAN_CODE, cat_id))
        plan_id = c.lastrowid
    for lg in ('KO', 'EN'):
        _upsert_text_asset(c, 'PLAN_TITLE', plan_id, lg, TITLES[lg])
        _upsert_text_asset(c, 'PLAN_DESC', plan_id, lg, DESCS[lg])

    # ⑤ 스케줄 — day N = BOOK_TEXT + CORE (plan 47 과 같은 모양)
    c.execute('DELETE FROM sys_plan_schedule WHERE plan_id=?', (plan_id,))
    units = {seq: uid for uid, seq in c.execute(
        'SELECT unit_id, sequence FROM sys_book_unit WHERE book_id=? '
        "AND record_status='LIVE'", (book_id,))}
    for n in range(1, 151):
        a, b = ranges[n]
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order, unit_key) "
                  "VALUES (?,?,1,?,?,'BOOK_TEXT',1,?)",
                  (plan_id, n, a, b, 'BOOK_%d' % units[n]))
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order) "
                  "VALUES (?,?,1,?,?,'CORE',2)", (plan_id, n, a, b))

    if verbose:
        nu = c.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? '
                       "AND record_status='LIVE'", (book_id,)).fetchone()[0]
        ns = c.execute('SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?',
                       (plan_id,)).fetchone()[0]
        print('도서 %s(book_id %d) 유닛 %d · 플랜 %s(plan_id %d, cat %d) '
              '스케줄 %d행' % (BOOK_CODE, book_id, nu, PLAN_CODE, plan_id,
                             cat_id, ns))
    return book_id, plan_id, cat_id


def selftest():
    """실 DB 위 트랜잭션 롤백 검증 — 흔적을 남기지 않는다."""
    ok = True
    conn = appdb.connect(DB)
    try:
        conn.execute('BEGIN')
        book_id, plan_id, cat_id = apply(conn, verbose=False)
        nu = conn.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? '
                          "AND record_status='LIVE'", (book_id,)).fetchone()[0]
        if nu != 150:
            print('FAIL 유닛 %d' % nu); ok = False
        ns = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule '
                          'WHERE plan_id=?', (plan_id,)).fetchone()[0]
        if ns != 300:
            print('FAIL 스케줄 %d' % ns); ok = False
        # 본문이 Treasury 서론과 같은가 (시 23 표본)
        body = conn.execute("""SELECT t.body_text FROM sys_book_unit u
            JOIN sys_book_unit_text t ON t.unit_id=u.unit_id
            WHERE u.book_id=? AND u.sequence=23""", (book_id,)).fetchone()[0]
        intro = _intros(conn)[23]
        if not body.startswith(intro[:200]) or ATTRIB not in body:
            print('FAIL 본문 동기화/출처'); ok = False
        # 두 번 돌려도 수가 같은가 (멱등)
        apply(conn, verbose=False)
        nu2 = conn.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?',
                           (book_id,)).fetchone()[0]
        ns2 = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule '
                           'WHERE plan_id=?', (plan_id,)).fetchone()[0]
        if (nu2, ns2) != (150, 300):
            print('FAIL 멱등 %d/%d' % (nu2, ns2)); ok = False
        # 스케줄 범위 = 그 시편 범위인가 (시 119 표본)
        r = conn.execute("""SELECT s.start_vid, s.end_vid FROM sys_plan_schedule s
            WHERE s.plan_id=? AND s.day=119 AND s.stage_type='CORE'""",
            (plan_id,)).fetchone()
        rng = _psalm_ranges(conn)[119]
        if tuple(r) != rng:
            print('FAIL 119 범위 %s != %s' % (r, rng)); ok = False
        conn.rollback()
        # 롤백 뒤 흔적이 없는가
        left = conn.execute('SELECT COUNT(*) FROM sys_bible_plan '
                            'WHERE plan_code=?', (PLAN_CODE,)).fetchone()[0]
        pre = conn.execute('SELECT COUNT(*) FROM sys_book_asset '
                           'WHERE book_code=?', (BOOK_CODE,)).fetchone()[0]
        # (이미 실제 적재된 뒤라면 1 이 정상 — 존재 여부가 아니라 증식을 본다)
        if left > 1 or pre > 1:
            print('FAIL 롤백 잔재/증식'); ok = False
    finally:
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
    print('db_spurgeon_psalms_plan selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--apply', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.apply:
        conn = appdb.connect(DB)
        try:
            apply(conn)
            conn.commit()
        finally:
            conn.close()
        return
    ap.print_help()


if __name__ == '__main__':
    main()
