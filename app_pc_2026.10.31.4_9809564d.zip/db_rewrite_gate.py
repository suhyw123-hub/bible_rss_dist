# -*- coding: utf-8 -*-
"""db_rewrite_gate.py — 표현 다듬기(리라이트) 스테이징 게이트 (영구 도구)

**운영 테이블(`sys_text_asset`)은 승인 전까지 건드리지 않는다.** 리라이터 결과는
임시 테이블에 쌓이고, 검사를 통과하고 승인된 행만 반영된다(2026-08-03 사용자 설계).

    ① --export   대상 행을 JSONL 로 내보낸다            (리라이터 입력)
    ② (리라이터를 대량으로 돌린다)
    ③ --import   결과를 스테이지에 적재                  운영 무변경
    ④ --inspect  스테이지 전수 검사 -> OK / FLAG        운영 무변경
    ⑤ --report   FLAG 를 눈으로 본다
    ⑥ --approve  문제없는 것을 승인                      운영 무변경
    ⑦ --apply    APPROVED 만 운영에 반영
    ↻ FLAG 는 --export --status FLAG 로 다시 내보내 ②부터 되풀이(round 증가)

**왜 이 구조인가.** 이전 판은 리라이터가 운영 테이블에 직접 쓰고 사후에 스냅샷과
대조하는 방식이었다. 그러면 검사 전까지 **검증 안 된 글이 앱에 노출된다.** 그리고
`--snapshot` 을 두 번 돌리면 원본이 사라지는 결함도 그 구조에서 나왔다.
스테이징에는 그 구간이 없다 — 운영은 승인된 것만 본다.

**검사 넷** (앞의 둘이 이 도구의 존재 이유다)

  ① 내용 추가  원본에 없던 숫자·라틴문자·헬라어·구절참조가 새로 생겼나
  ② 내용 손실  원본에 있던 그것들이 사라졌나
  ③ 재작성 의심 한글 낱말 자카드가 낮으면 다듬은 게 아니라 새로 쓴 것
  ④ 규약 위반  db_peri_gate 재사용 — 헬라어 역순·교단 귀속어·경어체·동그라미 번호·번역투

사용자 계획은 리라이터를 **온라인 모드**로 돌리는 것이다(data.md §1-9). 목적은
"추가가 아니라 자연스러운 표현"인데 웹을 참고하면 없던 내용을 끌어온다 —
연도·인명 원어 표기·학자 이름·출처 구절이 전형이고, 79,580행을 사람이 읽을 수는 없다.

사용법:
  python -X utf8 db_rewrite_gate.py --export  --book 44 --out stage_44.jsonl
  python -X utf8 db_rewrite_gate.py --import  stage_44.out.jsonl
  python -X utf8 db_rewrite_gate.py --inspect
  python -X utf8 db_rewrite_gate.py --report --status FLAG
  python -X utf8 db_rewrite_gate.py --approve --status OK
  python -X utf8 db_rewrite_gate.py --apply
  python -X utf8 db_rewrite_gate.py --export --status FLAG --out redo.jsonl   # 재조정
  python -X utf8 db_rewrite_gate.py --rollback        # APPLIED 를 원본으로 되돌린다
  python -X utf8 db_rewrite_gate.py --selftest        # 탐지력 확인(의무)
"""
import argparse
import io
import json
import re
import sys

import appdb
import db_peri_gate as g

DB = 'bible_master.db'
STAGE = 'temp_rewrite_stage'

TYPES = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER', 'VERS_VERS_DESC',
         'PERI_DESC', 'CHAP_DESC')
# NEW      적재됐고 아직 검사 전
# OK/FLAG  검사 결과
# APPROVED 승인 — --apply 대상
# APPLIED  운영에 반영됨
STATUSES = ('NEW', 'OK', 'FLAG', 'APPROVED', 'APPLIED')

# ── 내용 표지 (한글 조사 문제를 피해 애매함 없는 것만 센다) ────────────────
NUM = re.compile(r'\d+')
LATIN = re.compile(r'[A-Za-z]{3,}')
GREEK = re.compile(r'[Ͱ-Ͽἀ-῿]{2,}')
REF = re.compile(r'(?:[가-힣]{1,4}\s?)?\d+\s*:\s*\d+')
KO_TOK = re.compile(r'[가-힣]{2,}')
EN_TOK = re.compile(r'[A-Za-z]{2,}')

JACCARD_MIN = 0.55    # 이보다 낮으면 '다듬기'가 아니라 '재작성'
LEN_DELTA_FLAG = 0.40  # 글자 수가 이 비율 넘게 변하면 확인 대상
FIND_MAX = 12          # 사유 문자열에 나열할 표지 개수 상한


def marks(t, lang):
    """그 글이 담은 **내용 표지**. 언어에 따라 무엇이 표지인지가 다르다.

    ⚠ 2026-08-03 수정. 처음엔 언어와 무관하게 라틴문자를 표지로 셌는데, 그러면
      **EN 행에서 모든 낱말이 표지가 되어** 출력이 쓸모없어진다(유다서 시험에서
      한 행에 70개가 찍혔다). 라틴문자는 한국어 글에서만 '들여온 것'이다.
    """
    t = t or ''
    out = {('수', m) for m in NUM.findall(t)} | \
          {('헬', m) for m in GREEK.findall(t)} | \
          {('참조', re.sub(r'\s+', '', m)) for m in REF.findall(t)}
    if (lang or '').upper() != 'EN':
        out |= {('라틴', m.lower()) for m in LATIN.findall(t)}
    return out


def jaccard(a, b, lang):
    """낱말 겹침. **EN 행은 영어 낱말로 잰다.**

    ⚠ 2026-08-03 수정. 한글 토큰으로만 재던 때는 영어 글에서 양쪽 집합이 비어
      늘 1.0 이 나왔고, 그래서 **EN 에서는 재작성 탐지가 통째로 먹통이었다.**
      EN 은 신약 자산의 절반이다.
    """
    tok = EN_TOK if (lang or '').upper() == 'EN' else KO_TOK
    sa = {w.lower() for w in tok.findall(a or '')}
    sb = {w.lower() for w in tok.findall(b or '')}
    if not (sa | sb):
        return 1.0
    return len(sa & sb) / len(sa | sb)


def _join(pairs):
    s = sorted(f'{k}:{v}' for k, v in pairs)
    return ' · '.join(s[:FIND_MAX]) + (f' … 외 {len(s) - FIND_MAX}개'
                                       if len(s) > FIND_MAX else '')


def findings_of(old, new, lang):
    """(FLAG 사유 리스트, 참고 note 리스트). 사유가 하나라도 있으면 FLAG."""
    bad, note = [], []
    mo, mn = marks(old, lang), marks(new, lang)
    if mn - mo:
        bad.append('내용추가: ' + _join(mn - mo))
    if mo - mn:
        bad.append('내용손실: ' + _join(mo - mn))
    j = jaccard(old, new, lang)
    if j < JACCARD_MIN:
        bad.append(f'재작성의심: 자카드 {j:.2f} < {JACCARD_MIN}')
    for label, pat in (('동그라미번호', g.CIRCLED), ('헬라어역순', g.GREEK_REV),
                       ('교단귀속어', g.SECT), ('번역투', g.TRANSLATIONESE)):
        m = pat.search(new or '')
        if m:
            bad.append(f'{label}: "{m.group(0)}"')
    if lang == 'KO':
        m = g.PLAIN_ENDING.search(new or '')
        if m:
            bad.append('평서체종결 — 경어체(~습니다)로')
    if old and abs(len(new or '') - len(old)) / len(old) > LEN_DELTA_FLAG:
        bad.append(f'분량이상: {len(old)}자 -> {len(new or "")}자')
    if not bad and j < 0.75:
        note.append(f'자카드 {j:.2f}')
    return bad, note


# ── 스테이지 ────────────────────────────────────────────────────────────────
def ensure(conn):
    conn.execute(f"""CREATE TABLE IF NOT EXISTS {STAGE} (
        sys_text_id INTEGER PRIMARY KEY, text_type TEXT, clicked_id INTEGER,
        lang_code TEXT, text_variant TEXT, ref TEXT,
        orig_contents TEXT, new_contents TEXT,
        status TEXT NOT NULL DEFAULT 'NEW', findings TEXT, round INTEGER DEFAULT 1)""")


def scope_sql(bcode, types):
    ph = ','.join('?' * len(types))
    if bcode is None:
        return f"t.text_type IN ({ph})", list(types)
    return (f"""t.text_type IN ({ph}) AND (
        EXISTS (SELECT 1 FROM bible_index bi WHERE bi.verse_id=t.clicked_id AND bi.bcode=?)
     OR (t.text_type='PERI_DESC' AND EXISTS (
            SELECT 1 FROM sys_pericope_asset p JOIN bible_index bi ON bi.verse_id=p.start_vid
             WHERE p.pericope_id=t.clicked_id AND bi.bcode=?))
     OR (t.text_type='CHAP_DESC' AND t.clicked_id/1000=?))""",
            list(types) + [bcode, bcode, bcode])


def ref_of(conn, tt, cid):
    """사람이 알아볼 위치 표기. 리라이터에게 문맥을 주는 용도이기도 하다."""
    try:
        if tt == 'CHAP_DESC':
            b, ch = divmod(int(cid), 1000)
            r = conn.execute("SELECT short_name FROM book_names WHERE book_code=? "
                             "AND lang_code='KO'", (b,)).fetchone()
            return f'{r[0] if r else b} {ch}장'
        if tt == 'PERI_DESC':
            r = conn.execute("""SELECT bi.bcode, bi.chapter, bi.verse FROM sys_pericope_asset p
                JOIN bible_index bi ON bi.verse_id=p.start_vid WHERE p.pericope_id=?""",
                             (cid,)).fetchone()
        else:
            r = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
                             (cid,)).fetchone()
        if not r:
            return str(cid)
        nm = conn.execute("SELECT short_name FROM book_names WHERE book_code=? "
                          "AND lang_code='KO'", (r[0],)).fetchone()
        return f'{nm[0] if nm else r[0]} {r[1]}:{r[2]}'
    except Exception:
        return str(cid)


def export(conn, bcode, types, status, out):
    ensure(conn)
    if status:
        rows = conn.execute(
            f"SELECT sys_text_id, text_type, clicked_id, lang_code, text_variant, ref, "
            f"orig_contents FROM {STAGE} WHERE status=?", (status,)).fetchall()
    else:
        where, params = scope_sql(bcode, types)
        rows = [(tid, tt, cid, lg, tv, ref_of(conn, tt, cid), txt) for tid, tt, cid, lg, tv, txt
                in conn.execute(
                    f"""SELECT t.sys_text_id, t.text_type, t.clicked_id, t.lang_code,
                               COALESCE(t.text_variant,''), t.contents
                          FROM sys_text_asset t
                         WHERE {where} AND COALESCE(t.record_status,'LIVE')='LIVE'
                           AND t.contents IS NOT NULL AND LENGTH(TRIM(t.contents))>0""",
                    params)]
        # 원본을 지금 스테이지에 박아 둔다 — 이후 운영이 바뀌어도 기준선은 이것이다.
        for tid, tt, cid, lg, tv, ref, txt in rows:
            if not conn.execute(f'SELECT 1 FROM {STAGE} WHERE sys_text_id=?', (tid,)).fetchone():
                conn.execute(f'INSERT INTO {STAGE}(sys_text_id,text_type,clicked_id,lang_code,'
                             f'text_variant,ref,orig_contents) VALUES (?,?,?,?,?,?,?)',
                             (tid, tt, cid, lg, tv, ref, txt))
        conn.commit()
    if not rows:
        print('내보낼 행이 없다.'); return
    with io.open(out, 'w', encoding='utf-8') as f:
        for tid, tt, cid, lg, tv, ref, txt in rows:
            f.write(json.dumps({'id': tid, 'type': tt, 'lang': lg, 'variant': tv,
                                'ref': ref, 'text': txt}, ensure_ascii=False) + '\n')
    print(f'내보냄 {len(rows)}행 -> {out}')
    print('  리라이터는 각 줄의 "text" 만 다듬어 {"id":…, "text":…} 형태로 돌려줄 것.')
    print(f'  그다음: --import <결과파일>')


def do_import(conn, path):
    ensure(conn)
    n = miss = same = 0
    for line in io.open(path, encoding='utf-8'):
        line = line.strip()
        if not line:
            continue
        d = json.loads(line)
        tid, new = d.get('id'), d.get('text')
        if tid is None or new is None:
            miss += 1
            continue
        cur = conn.execute(f'SELECT orig_contents, new_contents FROM {STAGE} '
                           f'WHERE sys_text_id=?', (tid,)).fetchone()
        if not cur:
            miss += 1
            continue
        if cur[1] is not None:
            # 재조정분 — 회차를 올리고 다시 검사 대기로
            conn.execute(f"UPDATE {STAGE} SET new_contents=?, status='NEW', findings=NULL, "
                         f"round=round+1 WHERE sys_text_id=?", (new, tid))
        else:
            conn.execute(f"UPDATE {STAGE} SET new_contents=?, status='NEW' "
                         f"WHERE sys_text_id=?", (new, tid))
        if (cur[0] or '') == (new or ''):
            same += 1
        n += 1
    conn.commit()
    print(f'적재 {n}행 (변경 없음 {same})' + (f' · 스테이지에 없는 id {miss}건' if miss else ''))
    print('  그다음: --inspect')


def inspect(conn):
    ensure(conn)
    rows = conn.execute(
        f"SELECT sys_text_id, lang_code, orig_contents, new_contents FROM {STAGE} "
        f"WHERE new_contents IS NOT NULL AND status IN ('NEW','OK','FLAG')").fetchall()
    if not rows:
        print('검사할 행이 없다 (--import 를 먼저).'); return
    n_ok = n_flag = 0
    for tid, lg, old, new in rows:
        bad, note = findings_of(old or '', new or '', lg)
        st = 'FLAG' if bad else 'OK'
        conn.execute(f'UPDATE {STAGE} SET status=?, findings=? WHERE sys_text_id=?',
                     (st, ' | '.join(bad + note) or None, tid))
        n_ok += st == 'OK'
        n_flag += st == 'FLAG'
    conn.commit()
    print(f'검사 {len(rows)}행 — OK {n_ok} · FLAG {n_flag}')
    if n_flag:
        print('  --report --status FLAG 로 확인하고, 고쳐서 다시 돌리려면')
        print('  --export --status FLAG --out redo.jsonl')


def report(conn, status, limit):
    ensure(conn)
    q = f'SELECT status, COUNT(*) FROM {STAGE} GROUP BY status ORDER BY 1'
    print('스테이지 현황: ' + ' · '.join(f'{s} {n}' for s, n in conn.execute(q)) or '(비어 있음)')
    if not status:
        return
    rows = conn.execute(
        f"SELECT sys_text_id, text_type, ref, lang_code, text_variant, round, findings, "
        f"orig_contents, new_contents FROM {STAGE} WHERE status=? LIMIT ?",
        (status, limit)).fetchall()
    for tid, tt, ref, lg, tv, rnd, fnd, old, new in rows:
        print(f'\n--- {tid} {tt} {ref} {lg}{("/" + tv) if tv else ""} (round {rnd})')
        if fnd:
            print(f'    {fnd}')
        if status == 'FLAG':
            print(f'    원본: {" ".join((old or "").split())[:150]}')
            print(f'    결과: {" ".join((new or "").split())[:150]}')


def approve(conn, status, ids):
    ensure(conn)
    if ids:
        ph = ','.join('?' * len(ids))
        cur = conn.execute(f"UPDATE {STAGE} SET status='APPROVED' WHERE sys_text_id IN ({ph}) "
                           f"AND status IN ('OK','FLAG')", ids)
    else:
        cur = conn.execute(f"UPDATE {STAGE} SET status='APPROVED' WHERE status=?",
                           (status or 'OK',))
    conn.commit()
    print(f'승인 {cur.rowcount}행 — 그다음: --apply')


def apply_(conn):
    """APPROVED 만 반영한다. **운영이 그사이 바뀌었으면 건너뛴다.**"""
    ensure(conn)
    rows = conn.execute(
        f"SELECT sys_text_id, orig_contents, new_contents FROM {STAGE} "
        f"WHERE status='APPROVED'").fetchall()
    if not rows:
        print('승인된 행이 없다.'); return
    n = skip = 0
    for tid, old, new in rows:
        cur = conn.execute('SELECT contents FROM sys_text_asset WHERE sys_text_id=?',
                           (tid,)).fetchone()
        if not cur or (cur[0] or '') != (old or ''):
            skip += 1     # 내보낸 뒤 운영이 바뀌었다 — 덮어쓰지 않는다
            continue
        conn.execute('UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?', (new, tid))
        conn.execute(f"UPDATE {STAGE} SET status='APPLIED' WHERE sys_text_id=?", (tid,))
        n += 1
    conn.commit()
    print(f'반영 {n}행' + (f' · 건너뜀 {skip}행(내보낸 뒤 운영이 바뀌었다)' if skip else ''))


def rollback(conn):
    ensure(conn)
    rows = conn.execute(f"SELECT sys_text_id, orig_contents, new_contents FROM {STAGE} "
                        f"WHERE status='APPLIED'").fetchall()
    n = skip = 0
    for tid, old, new in rows:
        cur = conn.execute('SELECT contents FROM sys_text_asset WHERE sys_text_id=?',
                           (tid,)).fetchone()
        if not cur or (cur[0] or '') != (new or ''):
            skip += 1
            continue
        conn.execute('UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?', (old, tid))
        conn.execute(f"UPDATE {STAGE} SET status='APPROVED' WHERE sys_text_id=?", (tid,))
        n += 1
    conn.commit()
    print(f'원복 {n}행' + (f' · 건너뜀 {skip}행' if skip else ''))


def selftest(conn):
    base = ('바울이 빌립보에 이르렀습니다. 그곳은 로마의 식민지였고 퇴역 군인들이 '
            '자리를 잡은 도시였습니다. 안식일에 일행은 성문 밖 강가로 나갔습니다.')
    cases = [
        ('내용 추가(연도)', base + ' 이 도시는 기원전 356년에 세워졌습니다.'),
        ('내용 추가(라틴 인명)', base.replace('빌립보', '빌립보(Philippi)')),
        ('내용 추가(구절 참조)', base + ' 빌 1:1 이 그 교회에 보낸 편지입니다.'),
        ('내용 손실', '바울이 어느 도시에 이르렀습니다. 일행은 물가로 나갔습니다.'),
        ('재작성 의심', '그는 낯선 고장에 발을 들였고 물가를 찾아 걸음을 옮겼습니다.'),
        ('평서체 종결', base.replace('나갔습니다.', '나갔다.')),
        ('헬라어 역순', base + ' κοινωνία(교제)가 그 낱말입니다.'),
        ('교단 귀속어', base + ' 개혁주의 관점에서 그렇습니다.'),
    ]
    ok = True
    for label, new in cases:
        bad, _ = findings_of(base, new, 'KO')
        print(f'  [{"PASS" if bad else "FAIL"}] {label} → {bad[0][:52] if bad else "못 잡음"}')
        ok = ok and bool(bad)
    polished = ('바울이 빌립보에 이르렀는데, 그곳은 로마의 식민지로 퇴역 군인들이 '
                '자리를 잡은 도시였습니다. 안식일이 되자 일행은 성문 밖 강가로 나갔습니다.')
    bad, _ = findings_of(base, polished, 'KO')
    print(f'  [{"PASS" if not bad else "FAIL"}] 정상 다듬기 오탐 없음(KO) '
          f'(자카드 {jaccard(base, polished, "KO"):.2f}) {bad or ""}')
    ok = ok and not bad

    # ── EN 행 (자산의 절반) ────────────────────────────────────────────────
    en = ('Paul came to Philippi. It was a Roman colony where discharged soldiers '
          'had settled. On the Sabbath they went outside the gate to a riverbank.')
    en_cases = [
        ('EN 재작성 의심', 'He arrived in a strange town and made his way to the water.'),
        ('EN 내용 추가(연도)', en + ' The city was founded in 356 BC.'),
        ('EN 내용 추가(헬라어)', en + ' The word is κοινωνία here.'),
        ('EN 내용 추가(구절 참조)', en + ' See Phil 1:1 for the letter.'),
    ]
    for label, new in en_cases:
        bad, _ = findings_of(en, new, 'EN')
        print(f'  [{"PASS" if bad else "FAIL"}] {label} → {bad[0][:52] if bad else "못 잡음"}')
        ok = ok and bool(bad)
    en_pol = ('Paul arrived at Philippi, a Roman colony where discharged soldiers had '
              'settled, and on the Sabbath the group went out beyond the gate to a riverbank.')
    bad, _ = findings_of(en, en_pol, 'EN')
    print(f'  [{"PASS" if not bad else "FAIL"}] 정상 다듬기 오탐 없음(EN) '
          f'(자카드 {jaccard(en, en_pol, "EN"):.2f}) {bad or ""}')
    return ok and not bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--export', action='store_true')
    ap.add_argument('--import', dest='imp', metavar='FILE')
    ap.add_argument('--inspect', action='store_true')
    ap.add_argument('--report', action='store_true')
    ap.add_argument('--approve', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--rollback', action='store_true')
    ap.add_argument('--drop', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--book', type=int)
    ap.add_argument('--type', help=f'쉼표 구분. 기본 {",".join(TYPES)}')
    ap.add_argument('--status', choices=STATUSES)
    ap.add_argument('--id', type=int, nargs='*')
    ap.add_argument('--out', default='rewrite_stage.jsonl')
    ap.add_argument('--limit', type=int, default=20)
    a = ap.parse_args()
    conn = appdb.connect(DB)
    types = tuple(s.strip() for s in a.type.split(',')) if a.type else TYPES

    if a.selftest:
        print('=== 자가 탐지력 ===')
        sys.exit(0 if selftest(conn) else 1)
    if a.export:
        export(conn, a.book, types, a.status, a.out)
    elif a.imp:
        do_import(conn, a.imp)
    elif a.inspect:
        inspect(conn)
    elif a.report:
        report(conn, a.status, a.limit)
    elif a.approve:
        approve(conn, a.status, a.id)
    elif a.apply:
        apply_(conn)
    elif a.rollback:
        rollback(conn)
    elif a.drop:
        conn.execute(f'DROP TABLE IF EXISTS {STAGE}'); conn.commit()
        print(f'{STAGE} 삭제')
    else:
        ap.error('동작 하나를 지정할 것 (--export/--import/--inspect/--report/'
                 '--approve/--apply/--rollback/--drop/--selftest)')


if __name__ == '__main__':
    main()
