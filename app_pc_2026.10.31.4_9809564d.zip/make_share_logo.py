"""공유 표준 로고 — 방패 아이콘 + 「Hagah Dabar」 → mobile/assets/share_icon.png (2026-10-15 사용자
「앱이 있거나 없는 사람들에게 보낼 때 아이콘 + Hagah Dabar 로고를 필수적으로 상단에 · 스팸이 아니라고 안심」).

방패는 옛 share_icon.png 왼쪽 192px 를 그대로 쓴다(그림을 새로 짓지 않는다 — 앱 아이콘과 같은 모양).
다시 만들기: python make_share_logo.py
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'mobile', 'assets', 'share_icon.png')
SHIELD = os.path.join(HERE, 'icons', 'share_shield.png')   # 방패만 떠 둔 원본(처음 한 번)
TEXT = 'Hagah Dabar'


def main():
    if not os.path.exists(SHIELD):
        Image.open(OUT).convert('RGB').crop((0, 0, 192, 192)).save(SHIELD)
    shield = Image.open(SHIELD).convert('RGB')
    # ★ 크기는 옛 그림과 똑같이 576×192(3:1) — 2026-10-15 사용자 「이번 수정하기 전에 … 표시하던 방식이 정상」.
    #   911×192(약 5:1)로 넓히자 메신저가 미리보기를 잘라 로고가 제대로 안 보였다. 글자를 줄여 그 안에 넣는다.
    # ★ 2026-10-21 사용자 「아이콘의 좌우 폭과 높이를 절반으로」 — 방패·글자 높이 96
    # ★★ 2026-10-22 사용자 「메시지 표시 박스와 규격이 안 맞아 더 크게 나온다」 — 그림을 576×96(6:1)으로 만들었더니
    #   메신저가 제 박스 비율로 키우고 잘랐다(10-15 의 5:1 과 같은 일). ⇒ **판은 576×192(3:1) 그대로** 두고
    #   내용(방패 + 글자)만 절반 높이로 가운데에 놓는다(위아래는 흰 여백).
    W, CH, H, GAP, RIGHT = 576, 192, 96, 16, 20
    path = None
    for f in ('segoeuib.ttf', 'arialbd.ttf', 'malgunbd.ttf'):
        p = os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts', f)
        if os.path.exists(p):
            path = p
            break
    if path is None:
        sys.exit('글꼴을 찾지 못했습니다')
    d0 = ImageDraw.Draw(Image.new('RGB', (10, 10)))
    size = 60
    while True:
        font = ImageFont.truetype(path, size)
        x0, y0, x1, y1 = d0.textbbox((0, 0), TEXT, font=font)
        if (x1 - x0 <= W - H - GAP - RIGHT and y1 - y0 <= H * 0.6) or size <= 20:
            break
        size -= 2
    im = Image.new('RGB', (W, CH), 'white')
    tw = H + GAP + (x1 - x0)
    left = max(0, (W - tw) // 2)
    top = (CH - H) // 2
    im.paste(shield.resize((H, H), Image.LANCZOS), (left, top))
    d = ImageDraw.Draw(im)
    d.text((left + H + GAP - x0, top + (H - (y1 - y0)) // 2 - y0), TEXT, font=font, fill=(51, 51, 51))
    im.save(OUT)
    print(OUT, im.size)


if __name__ == '__main__':
    main()
