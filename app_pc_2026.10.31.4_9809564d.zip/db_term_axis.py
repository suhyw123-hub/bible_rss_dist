# -*- coding: utf-8 -*-
"""주요용어 축 — 속성 / 행동 / 상태 / 개념 / 이름 (영구 도구)

2026-09-07 신설. 사용자 지시(1.txt 뒤 물음):
  「이렇게 활용하면 용어사전에서 어떻게 분류할 것인가? **속성/성품 ·
   행동/반응** ... 이런식으로 형용사 동사를 분류할 필요가 있다. 이렇게
   분류하고 나서도 **남는 것들은 어떻게 활용할 수 있을지도 고민**해야 한다.
   필요 없으면 제거해야 한다. 어쩌면 **자체 설명 만으로도 의미있는 단어**도
   있을 것이다.」

★★★ **품사로는 못 가른다 — 실측이 그것을 말한다.**
  「수치 · 보쉬」가 동사(v)이고 「긍휼 · 라함」도 동사다. 우리 이름은 명사인데
  원어는 동사인 자리가 흔하다. 품사는 **원어의 문법**이고 우리가 필요한 것은
  **읽는 사람의 축**이다. ⇒ 사용자 제안이 맞다.

★ **새 유형을 만들지 않는다**(§12-0) — 유형은 「다른 데이터·다른 화면」을 뜻하고
  축은 꼬리표다. ⇒ **`json_detail.axis`** 에 담는다. 새 표 0.

⚠ **「남는 것」이 곧 버릴 것은 아니다**(사용자 물음의 답) — 축이 없어도
  **자체 설명만으로 서는 낱말**이 있다(부활·보혜사). 축은 **훑어보기의 도구**이지
  자격 심사가 아니다. 그래서 `axis` 가 없어도 목록에서 안 사라진다.
"""
from __future__ import annotations

import json
import sys

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

#: 축 — 코드와 우리말 이름. **여기가 단일 소스**다.
#: ⚠ 축을 늘리면 이 표에 한 줄. 화면은 이것을 읽는다.
#: ⚠⚠ **화면 이름은 `i18n` 을 탄다**(§0-3 — 주요용어는 사용자 화면이다).
#:   여기 적은 우리말은 **폴백**이고, 열쇠는 `TERM_AXIS_<코드>` 다.
#:   `axis_name(code, lang)` 을 쓸 것 — 화면이 이 표의 글자를 직접 쓰면
#:   다른 언어 사용자가 한국어를 본다(2026-09-07 실측으로 잡았다).
AXES = (
    ('ATTR',  '속성·성품',  '하나님과 사람이 「어떠하신가·어떠한가」를 말하는 낱말'),
    ('ACT',   '행동·반응',  '「무엇을 하는가」를 말하는 낱말 — 하나님의 일과 사람의 응답'),
    ('STATE', '상태·처지',  '「어떤 자리에 있는가」를 말하는 낱말 — 죄·정결·죽음'),
    # ★★★ **그림·상징**(2026-09-07 신설 · 사용자 「그림상징 축이 필요하면
    #   진행하라」). 실측이 필요를 말했다 — 「제도·개념」의 정의가 「성경이 세운
    #   틀」인데 그 안에 **틀은 5개뿐**이었고(19 중) 물·산·옷 같은 그림이
    #   섞여 들어와 축이 흐려지고 있었다.
    #   ⚠ 「그 밖」 통을 하나 더 만드는 것이 아니다 — **잣대가 뚜렷하다**:
    #     일상에서 손으로 만질 수 있는 것으로 하나님과 우리를 그리는 낱말.
    ('IMAGE', '그림·상징',  '길·목자·물처럼 일상의 것으로 하나님과 우리를 그리는 낱말'),
    ('IDEA',  '제도·개념',  '언약·율법·나라처럼 성경이 세운 틀'),
    ('NAME',  '하나님의 이름', '여호와·엘로힘처럼 부르는 이름'),
    # ★★★ **사람·마음**(2026-09-07 신설 · 사용자 확정 「1」).
    #   ★ **「하나님의 이름」과 대칭이다** — 성경이 가장 많이 말하는 두 주어에
    #     각각 축이 선다.
    #   ★★ 실측이 필요를 말했다 — 이 여덟이 「제도·개념」에 있어 그 축이
    #     18 중 8이 정의 밖이었다. 빼고 나니 남는 열이 **정확히 「성경이 세운
    #     틀」**이다(세대·나라·말씀·복음·홍수·공의·계명·비밀·이름·율법).
    #   ⚠ 여덟은 두 갈래인데 **한 축이 맞다**:
    #     ⓐ 사람을 부르는 이름(아담·이쉬·에노쉬·게베르) — 같은 것의 네 이름
    #     ⓑ 사람을 이루는 것(네페쉬·루아흐·레브·바사르) — 서로 다른 네 가지
    #     ⓑ 는 「같은 뜻의 여러 낱말」이 아니라 **가족(의미장)으로 묶으면 안
    #     되고 축이 맞다**. ⓐ 는 `F_MAN` 가족이 이미 묶지만 **겹쳐도 된다** —
    #     죄 3형제가 `F_SIN` 가족에 있으면서 축은 STATE 인 선례가 있다.
    #     **가족은 「같은 뜻의 낱말 모음」이고 축은 「훑어보기 꼬리표」다.**
    #   ⚠ 축 코드 `MAN` 은 낱말 가족 엔티티 `F_MAN` 과 **다른 것**이다
    #     (전자는 축 코드, 후자는 엔티티 코드 — 이름만 닮았다).
    ('MAN',   '사람·마음',  '사람이 무엇이며 무엇으로 이루어졌는가를 말하는 낱말'),
    ('FIELD', '낱말 가족',  '여러 낱말을 한 자리에 모은 의미장'),
)
AXIS_NAME = {c: n for c, n, _d in AXES}
AXIS_DESC = {c: d for c, _n, d in AXES}

#: 화면 이름의 i18n 열쇠 — 축을 늘리면 **11언어를 함께 채운다**(§0-3).
AXIS_KEY = {c: 'TERM_AXIS_' + c for c, _n, _d in AXES}


def axis_name(code, lang=None):
    """축 이름 — 사용자 언어로. 못 읽으면 우리말 폴백.

    ⚠ 화면은 `AXIS_NAME` 을 직접 쓰지 말고 이 문을 부른다.
    """
    fb = AXIS_NAME.get(code, code or '')
    if not code:
        return fb
    try:
        import i18n
        return i18n.t(AXIS_KEY.get(code, ''), fb, lang) if lang else \
            i18n.t(AXIS_KEY.get(code, ''), fb)
    except Exception:
        return fb

#: 배정 초안 — **실측 91개를 하나씩 읽고 정했다.**
#: ⚠ 애매한 것은 **안 적는다**(빈 축 = 「자체 설명으로 선다」).
DRAFT = {
    # ── 하나님의 이름·속성 (2026-09-07 관문 작업으로 신설) ─────────────
    #   ⚠ 자존·불변·편재·전지는 **하나님께만 있는 것**이라 「하나님의 이름」
    #     축에 둔다. 「속성·성품」은 사람에게도 비치는 것들의 자리다
    #     (거룩·사랑·공의는 사람도 닮는다 — 설명문이 공유/비공유로 갈랐다).
    'T_ASEITY': 'NAME', 'T_IMMUTABILITY': 'NAME',
    'T_OMNIPRESENCE': 'NAME', 'T_OMNISCIENCE': 'NAME',
    # ── 그림·상징 명사 (2026-09-07 0.txt 1-1 「바벨탑 같은 명사조차
    #   등록되지 않았다」의 답 — 열둘 신설) ────────────────────────────
    #   ⚠ **피는 그림이 아니라 제도**다 — 레17:11 이 「피가 죄를 속하느니라」로
    #     그 몫을 못 박아 성경이 세운 틀에 든다.
    'T_DAM': 'IDEA', 'T_QETORET': 'IDEA',
    'T_LECHEM': 'IMAGE', 'T_YAYIN': 'IMAGE', 'T_SHEMEN': 'IMAGE',
    'T_TSUR': 'IMAGE', 'T_NER': 'IMAGE', 'T_PETACH': 'IMAGE',
    'T_KISSE': 'IMAGE', 'T_OL': 'IMAGE', 'T_RESHET': 'IMAGE',
    'T_KOS': 'IMAGE',
    # ── 성령의 은사 낱말 (2026-09-07) ─────────────────────────────────
    #   ⚠ 지혜·지식은 **속성·성품**이 아니라 **행동·반응** 쪽에 가깝다 —
    #     성경의 지혜는 「살아 내는 솜씨」이고 지식은 「겪어서 아는 앎」이라
    #     둘 다 사람이 하는 일이다(설명문이 그렇게 적었다).
    'T_CHOKMAH': 'ACT', 'T_DAAT': 'ACT',
    'T_PROPHETEIA': 'ACT', 'T_GLOSSA': 'ACT', 'T_DIDASKALIA': 'ACT',
    # ── 속성·성품 ────────────────────────────────────────────────
    'T_KADOSH': 'ATTR', 'T_HESED': 'ATTR', 'T_TSEDEQ': 'ATTR',
    'T_EMET': 'ATTR', 'T_KAVOD': 'ATTR', 'T_TAMIM': 'ATTR',
    'T_YASHAR': 'ATTR', 'T_TOV': 'ATTR', 'T_RACHAM': 'ATTR',
    'T_SHALOM': 'ATTR', 'T_DYNAMIS': 'ATTR', 'T_HYPOMONE': 'ATTR',
    'T_SPLANCHNA': 'ATTR', 'T_HEMAH': 'ATTR', 'T_EMUNAH': 'ATTR',
    'T_AHAV': 'ATTR', 'T_SIMCHAH': 'ATTR', 'T_AVEL': 'ATTR',
    # ── 행동·반응 ────────────────────────────────────────────────
    'T_HALAK': 'ACT', 'T_SHAMA': 'ACT', 'T_SHUV': 'ACT', 'T_YADA': 'ACT',
    'T_ZAKAR': 'ACT', 'T_YARE': 'ACT', 'T_BATACH': 'ACT', 'T_BARA': 'ACT',
    'T_BARAK': 'ACT', 'T_GAAL': 'ACT', 'T_PADAH': 'ACT', 'T_SALACH': 'ACT',
    'T_SHABA': 'ACT', 'T_NACHAM': 'ACT', 'T_TODAH': 'ACT', 'T_QABAR': 'ACT',
    'T_TEFILLAH': 'ACT', 'T_KOINONIA': 'ACT', 'T_MASHACH': 'ACT',
    'T_TAHER': 'ACT',
    # ── 상태·처지 ────────────────────────────────────────────────
    'T_CHATAT': 'STATE', 'T_AVON': 'STATE', 'T_PESHA': 'STATE',
    'T_RAAH': 'STATE', 'T_RASHA': 'STATE', 'T_AVEN': 'STATE',
    'T_AMAL': 'STATE', 'T_MAAL': 'STATE', 'T_ASEBEIA': 'STATE',
    'T_ANOMIA': 'STATE', 'T_PARABASIS': 'STATE', 'T_PARAPTOMA': 'STATE',
    'T_TAME': 'STATE', 'T_BOSH': 'STATE', 'T_MAVET': 'STATE',
    'T_SHEOL': 'STATE', 'T_QEBER': 'STATE', 'T_ABADDON': 'STATE',
    'T_CHAY': 'STATE',
    # ── 제도·개념 ────────────────────────────────────────────────
    'T_TORAH': 'IDEA', 'T_BERIT': 'IDEA', 'T_DAVAR': 'IDEA',
    'T_MISHPAT': 'IDEA', 'T_MITSVAH': 'IDEA', 'T_BASILEIA': 'IDEA',
    'T_MYSTERION': 'IDEA', 'T_EUANGELION': 'IDEA', 'T_SHEM': 'IDEA',
    'T_AION': 'IDEA', 'T_MABBUL': 'IDEA',
    # ── 그림·상징 (2026-09-07) ───────────────────────────────────
    #   ★ 흐름이 이미 구절을 모아 둔 그 그림들이다(0.txt 1번 A단계).
    #   ⚠ **빛은 「제도·개념」에서 옮겨 왔다** — 틀이 아니라 그림이다.
    'T_OR': 'IMAGE', 'T_DEREK': 'IMAGE', 'T_ROEH': 'IMAGE',
    'T_MAYIM': 'IMAGE', 'T_HAR': 'IMAGE', 'T_EVED': 'IMAGE',
    'T_ZERA': 'IMAGE', 'T_GEPHEN': 'IMAGE', 'T_BEGED': 'IMAGE',
    'T_KALLAH': 'IMAGE',
    # ── 하나님의 이름 ────────────────────────────────────────────
    'T_YHWH': 'NAME', 'T_ELOHIM': 'NAME', 'T_ADONAI': 'NAME',
    'T_EL': 'NAME', 'T_ELYON': 'NAME', 'T_TSEVAOT': 'NAME',
    'T_SHADDAI': 'NAME',
    # ── 사람·마음 (2026-09-07 — 「제도·개념」에서 옮겨 왔다) ─────────
    #   ⚠ 어제 여기에 「상태와 개념 사이」라고 적어 두고 넘어갔는데
    #     **적어 두고 넘어간 것이 곧 축의 흐려짐이었다.** 축을 주었다.
    #   ⓐ 사람을 부르는 이름 — 같은 것의 네 이름(`F_MAN` 가족이 함께 묶는다)
    'T_ADAM': 'MAN', 'T_ISH': 'MAN', 'T_ENOSH': 'MAN', 'T_GEBER': 'MAN',
    #   ⓑ 사람을 이루는 것 — 서로 다른 네 가지(가족으로 묶으면 안 된다)
    'T_NEPHESH': 'MAN', 'T_RUACH': 'MAN', 'T_LEV': 'MAN', 'T_BASAR': 'MAN',
    # ── 낱말 가족(의미장) — 코드 접두가 `F_` 다 ──────────────────
    'F_SIN': 'FIELD', 'F_LOVE': 'FIELD', 'F_EVIL': 'FIELD',
    'F_DEATH': 'FIELD', 'F_MAN': 'FIELD', 'F_PURITY': 'FIELD',
    'F_RIGHTEOUS': 'FIELD', 'F_WORD': 'FIELD', 'F_DIVINE_NAMES': 'FIELD',
    # ⚠ **일부러 안 적는 것** — 축으로 접기보다 제 설명이 본체인 낱말:
    #   T_ANASTASIS(부활) · T_PARAKLETOS(보혜사) — 사건과 인격이라
    #   「속성」도 「행동」도 아니다. 사용자 「자체 설명 만으로도 의미있는 단어」.
}


def axis_of(conn, eid):
    """그 용어의 축 코드 — 없으면 None."""
    r = conn.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
                     (eid,)).fetchone()
    if not r or not r[0]:
        return None
    try:
        d = json.loads(r[0]) or {}
    except Exception:
        return None
    a = d.get('axis')
    return a if a in AXIS_NAME else None


def set_axis(conn, eid, axis):
    """축을 담는다. `None`/빈 값이면 **지운다**(축을 뗄 수 있어야 한다).

    ⚠ **다른 열쇠를 안 지운다** — `json_detail` 에 원어 앵커·이름의 뜻이 함께 산다.
    """
    if axis and axis not in AXIS_NAME:
        raise ValueError('모르는 축: %r' % (axis,))
    r = conn.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
                     (eid,)).fetchone()
    d = {}
    if r and r[0]:
        try:
            d = json.loads(r[0]) or {}
        except Exception:
            d = {}
    if axis:
        d['axis'] = axis
    else:
        d.pop('axis', None)
    conn.execute("UPDATE sys_entity_master SET json_detail=? WHERE entity_id=?",
                 (json.dumps(d, ensure_ascii=False), eid))
    conn.commit()


def counts(conn):
    """축별 개수 — 화면 콤보가 쓴다. 축 없는 것은 `''` 열쇠로."""
    out = {c: 0 for c, _n, _d in AXES}
    out[''] = 0
    q = ("SELECT entity_id, json_detail FROM sys_entity_master "
         "WHERE entity_type='TERM' AND record_status='LIVE' "
         "  AND COALESCE(json_extract(json_detail,'$.subtype'),'')<>'LEX'")
    for _eid, jd in conn.execute(q):
        a = ''
        try:
            a = (json.loads(jd or '{}') or {}).get('axis') or ''
        except Exception:
            a = ''
        if a not in out:
            a = ''
        out[a] += 1
    return out


def check(conn):
    """초안 점검 → `(담을 것, 없는 코드, 이미 같은 것)`."""
    todo, miss, same = [], [], []
    for code, ax in DRAFT.items():
        r = conn.execute(
            "SELECT entity_id FROM sys_entity_master WHERE entity_code=? "
            "AND record_status='LIVE'", (code,)).fetchone()
        if not r:
            miss.append(code)
            continue
        cur = axis_of(conn, r[0])
        (same if cur == ax else todo).append((code, r[0], ax, cur))
    return todo, miss, same


def apply_draft(conn):
    """초안을 담는다(멱등) → 바꾼 수."""
    todo, _miss, _same = check(conn)
    for _code, eid, ax, _cur in todo:
        set_axis(conn, eid, ax)
    return len(todo)


# ── selftest ───────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [], []

    def chk(name, cond, extra=''):
        (ok if cond else bad).append(name + (('  ' + str(extra)) if extra else ''))

    chk('축 표 — 코드가 겹치지 않는다',
        len({c for c, _n, _d in AXES}) == len(AXES))
    chk('축마다 이름과 설명이 있다',
        all(n and d for _c, n, d in AXES))
    chk('★ 초안의 축이 전부 표에 있다',
        all(a in AXIS_NAME for a in DRAFT.values()),
        sorted({a for a in DRAFT.values() if a not in AXIS_NAME}))
    # ── 축 이름은 사용자 화면에 나간다 → 11언어(§0-3) ────────────────
    #   ⚠ **축을 늘리고 언어를 안 채우면 그 자리에서 걸린다.**
    chk('축마다 i18n 열쇠가 있다',
        all(AXIS_KEY.get(c) == 'TERM_AXIS_' + c for c, _n, _d in AXES))
    chk('  i18n 을 못 읽어도 우리말로 물러선다',
        axis_name('ATTR') and axis_name('IMAGE'))
    chk('  모르는 축은 코드를 그대로 낸다', axis_name('ZZZ') == 'ZZZ')
    chk('  빈 축은 빈 이름', axis_name(None) == '')
    try:
        import appdb as _ad
        _c9 = _ad.connect('bible_master.db')
        _ui = set()
        try:
            import lang_config as _lc
            _ui = set(_lc.ui_langs())
        except Exception:
            pass
        _miss9 = []
        for _c8, _n8, _d8 in AXES:
            _got = {r[0] for r in _c9.execute(
                "SELECT lang_code FROM ui_strings WHERE string_id=?",
                (AXIS_KEY[_c8],))}
            if _ui - _got:
                _miss9.append('%s:%s' % (_c8, sorted(_ui - _got)))
        chk('★ 축 이름이 UI 언어 전부에 있다', not _miss9, _miss9)
        _c9.close()
    except Exception as _e9:
        chk('★ 축 이름이 UI 언어 전부에 있다', False, _e9)

    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
              " entity_code TEXT, entity_type TEXT, json_detail TEXT,"
              " record_status TEXT DEFAULT 'LIVE')")
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type,"
              "json_detail) VALUES (1,'T_HESED','TERM','{\"name_strong\":\"H2617\"}')")
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type) "
              "VALUES (2,'T_ANASTASIS','TERM')")
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type,"
              "json_detail) VALUES (3,'W_H1','TERM','{\"subtype\":\"LEX\"}')")
    c.commit()

    chk('처음엔 축이 없다', axis_of(c, 1) is None)
    set_axis(c, 1, 'ATTR')
    chk('★ 축을 담는다', axis_of(c, 1) == 'ATTR')
    chk('★ 다른 열쇠를 안 지운다',
        json.loads(c.execute("SELECT json_detail FROM sys_entity_master "
                             "WHERE entity_id=1").fetchone()[0]).get('name_strong')
        == 'H2617')
    set_axis(c, 1, None)
    chk('★ 축을 뗄 수 있다', axis_of(c, 1) is None)
    set_axis(c, 1, 'ATTR')
    try:
        set_axis(c, 1, 'NOPE')
        chk('모르는 축 거부', False)
    except ValueError:
        chk('모르는 축 거부', True)

    cnt = counts(c)
    chk('★ 기계 낱말은 안 센다', sum(cnt.values()) == 2, cnt)
    chk('  축 없는 것도 센다(사라지지 않는다)', cnt[''] == 1, cnt)
    chk('  축 있는 것을 센다', cnt['ATTR'] == 1)

    todo, miss, same = check(c)
    chk('★ 이미 같으면 안 바꾼다',
        ('T_HESED', 1, 'ATTR', 'ATTR') in same, same)
    chk('  없는 코드를 알린다', 'T_YHWH' in miss)
    chk('★ 부활은 초안에 없다(자체 설명으로 선다)',
        'T_ANASTASIS' not in DRAFT)

    n = apply_draft(c)
    chk('  담을 것이 없으면 0', n == 0, n)
    set_axis(c, 1, None)
    chk('★ 초안 적용', apply_draft(c) == 1 and axis_of(c, 1) == 'ATTR')
    chk('★ 멱등', apply_draft(c) == 0)

    print('db_term_axis selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    for b in bad:
        print('  FAIL:', b)
    return 0 if not bad else 1


def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = appdb.connect('bible_master.db') if appdb else None
    if c is None:
        print('appdb 없음')
        return 1
    if '--check' in argv:
        todo, miss, same = check(c)
        print('담을 것 %d · 이미 같음 %d · 없는 코드 %d'
              % (len(todo), len(same), len(miss)))
        if miss:
            print('  없는 코드: %s' % ', '.join(sorted(miss)))
        return 0
    if '--apply' in argv:
        print('담음 %d' % apply_draft(c))
        return 0
    cnt = counts(c)
    for code, name, _d in AXES:
        print('  %-6s %-12s %d' % (code, name, cnt.get(code, 0)))
    print('  %-6s %-12s %d' % ('', '(축 없음)', cnt.get('', 0)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
