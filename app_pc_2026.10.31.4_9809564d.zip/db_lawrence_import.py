# -*- coding: utf-8 -*-
"""db_lawrence_import.py — 로렌스 형제 『하나님의 임재 연습』 진본 적재
================================================================================
`python db_lawrence_import.py --selftest`  — 의무
`python db_lawrence_import.py --links`     — **받기 전에** 주소를 보인다(의무)
`python db_lawrence_import.py --fetch --links-confirmed`  — 확인 뒤 내려받는다
`python db_lawrence_import.py --check`     — 파싱·게이트만 (DB 안 건드림)
`python db_lawrence_import.py --spots`     — 손질할 자리를 사람이 보게 늘어놓는다
`python db_lawrence_import.py --apply`     — 적재 (멱등 · `unit_id` 보존)

━━ 왜 다시 넣는가 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2026-08-22 검증에서 **그전 본문이 발췌·재서술본**임이 드러났다. 공개 도메인
영역본 다섯 종과 대조해 문장 56%만 그대로 있었고, 「스물여섯 살에 회심」처럼
**어느 원문에도 없고 그 본문 자체(첫 대화의 「열여덟」)와도 어긋나는** 대목이
있었다. 분량도 9,046자로 원문의 8분의 1이었다.

★ **왜 구텐베르크가 아니라 스캔본인가** (사용자 물음에 대한 답)
  구텐베르크 #5657 은 파일이 스스로 이렇게 밝힌다 —
  `** This is a COPYRIGHTED Project Gutenberg eBook **`
  `Copyright (C) 2002 by Lightheart.`
  **저작권이 살아 있는 2002년 편집본**이다. 구텐베르크가 허락받아 올려 둔
  것이지 퍼블릭 도메인이 아니다. 담고서 「퍼블릭 도메인」이라 적으면 거짓이
  되고, 그 위에 현대어 번역을 쌓으면 2차 저작물 문제가 된다.
  ⇒ **1895년 Fleming H. Revell 판**을 쓴다. 판권장에 `Copyright, 1895, by
    FLEMING H. REVELL COMPANY` · `Translated from the French` 가 찍혀 있고,
    서문은 한나 위톨 스미스가 썼다. 미국 기준 저작권 만료가 확실하다.

★ **두 원문은 같은 1895년 Revell 판을 각각 스캔한 것**이다(실측 84% 일치).
  ⇒ 두 곳 대조 규칙(§0-1b 규칙 ②)을 그대로 지킨다.

⚠ **이 판에 「영적 잠언」은 없다** — 목차 실측: 서문·머리말 뒤에 대화 4편과
  편지 15편뿐이다. 그전 유닛 이름 「Letters XI-XV & Maxims」는 틀린 것이었다.

⚠ **7편 구성을 그대로 둔다** — 7일 묵상 플랜(plan 48)이 `unit_id` 8~14 를
  가리킨다. 편지를 다섯씩 묶는 그 구성을 지키면 플랜을 손대지 않아도 된다.
"""
import io
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
import db_book_verify as V
import db_book_source_match as SM

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_lawrence_raw')
BOOK_CODE = 'LAWRENCE_PPG'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/125.0 Safari/537.36')

# 같은 1895 Revell 판을 각각 스캔한 두 곳.
SRC = [
    ('IA Revell 스캔', os.path.join(RAW, 'revell.txt'),
     'https://ia801009.us.archive.org/32/items/practiceofpresen00lawriala/'
     'practiceofpresen00lawriala_djvu.txt'),
    ('IA dli 스캔', os.path.join(RAW, 'dli.txt'),
     'https://ia601406.us.archive.org/11/items/in.ernet.dli.2015.209844/'
     '2015.209844.The-Practice_djvu.txt'),
]
MAIN = SRC[0][1]        # 본문은 상태가 더 나은 Revell 쪽에서 뽑는다

# ⚠ 출처 줄에 `H.` 같은 약자를 넣지 말 것 — 문장 나누기가 거기서 끊겨 검증기가
#   이 줄을 「원문에 없는 문장」으로 잡는다(실측). 출판사 정식 이름은 소개문의
#   ▸ 출처 블록이 싣는다.
EDITION = 'Revell, 1895'
ATTRIB = ('— Brother Lawrence, "The Practice of the Presence of God" (%s). '
          'Translated from the French. Public domain.' % EDITION)

ORD = ['FIRST', 'SECOND', 'THIRD', 'FOURTH', 'FIFTH', 'SIXTH', 'SEVENTH',
       'EIGHTH', 'NINTH', 'TENTH', 'ELEVENTH', 'TWELFTH', 'THIRTEENTH',
       'FOURTEENTH', 'FIFTEENTH']
ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X',
         'XI', 'XII', 'XIII', 'XIV', 'XV']

# 7편 구성 — 플랜 48 이 가리키는 그 구성 그대로.
UNITS = [
    (1, 'First Conversation', [('CONVERSATION', 0)]),
    (2, 'Second Conversation', [('CONVERSATION', 1)]),
    (3, 'Third Conversation', [('CONVERSATION', 2)]),
    (4, 'Fourth Conversation', [('CONVERSATION', 3)]),
    (5, 'Letters I-V', [('LETTER', i) for i in range(0, 5)]),
    (6, 'Letters VI-X', [('LETTER', i) for i in range(5, 10)]),
    (7, 'Letters XI-XV', [('LETTER', i) for i in range(10, 15)]),
]

# 스캔이 남기는 것들 — 규칙으로 걷는다.
# ⚠ 쪽번호가 **흩어져 찍힌다** — `1 6 Conversations` · `3O Conversations` ·
#   `io Conversations`. 숫자가 O·o·i·l·j·S 로 잘못 읽히고 자릿수 사이가
#   벌어지므로 「숫자처럼 생긴 토막 + 머리글」을 통째로 본다.
_DIGITISH = r'[\dIlijJoOSsB£\s]{0,6}'
# ⚠ 머리글 앞에 잡티가 붙기도 한다 — `^Conversations 27` (실측).
_RUNHEAD = re.compile(
    r'^[\s^«».*\'"·|]*' + _DIGITISH +
    r'(Conversations?|Letters?|The\s+Practice\s+of\s+the\s+Presence'
    r'(\s+of\s+GOD)?)' + _DIGITISH + r'$', re.I)
_PAGENUM = re.compile(r'^\s*[\dIlji£OoSsB]{1,4}\s*$')
# 그 자리에서만 쓰는 글자 교정 — **문장을 고치지 않는다.** 실측으로 확인한 것만.
FIXES = [
    (r'\bupon\s+the\s+\}d\s+of\s+August\b', 'upon the 3d of August'),
    # 괄호로 열고 `}` 로 닫힌 소제목 — `(… in Prayer}` (실측)
    (r'^\((.{3,80}?)\}$', r'(\1)'),
]


def fetch():
    # ★ 받기 **전에** 링크를 보인다 (사용자 지침 2026-08-22) — 문서가 아니라
    #   코드가 막는다. `--links-confirmed` 없이는 한 바이트도 받지 않는다.
    SM.require_ack(BOOK_CODE, [(n, u) for n, _, u in SRC],
                   note='판: Fleming H. Revell Company, 1895 '
                        '(판권장에 Copyright, 1895 가 찍혀 있다)')
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    for name, path, url in SRC:
        for _ in (1, 2):
            subprocess.run(['curl', '-sL', '--max-time', '240', '-A', UA,
                            '-o', path, url], capture_output=True)
            if os.path.exists(path) and os.path.getsize(path) > 20000:
                break
            time.sleep(5)
        sz = os.path.getsize(path) if os.path.exists(path) else 0
        print('  %-4s %-16s %10s  %s' % ('O' if sz > 20000 else 'x', name,
                                         format(sz, ','), url))


def clean(block):
    """쪽번호·머리글을 걷고 줄끝 하이픈을 붙여 문단으로 만든다.

    ⚠ 하이픈이 **쪽 넘김을 사이에 두고** 갈리는 일이 잦다 —
      `de-` / (빈 줄 · 쪽번호 · 머리글) / `termined`. 빈 줄에서 문단을 끊되
      **하이픈으로 끝났으면 끊지 않는다.**
    ⚠ 줄 **안쪽**의 `sixty- four` 는 다른 경우다 — 원래 붙임표가 있는 낱말이니
      하이픈을 지우지 말고 **빈칸만** 없앤다.
    """
    out, buf = [], []

    def flush():
        if buf:
            out.append(' '.join(buf))
            del buf[:]

    for line in block.splitlines():
        s = line.rstrip()
        if not s.strip():
            # 하이픈으로 끝났으면 쪽이 넘어간 것 — 문단을 끊지 않는다
            if not (buf and re.search(r'[A-Za-z]-$', buf[-1])):
                flush()
            continue
        if _RUNHEAD.match(s) or _PAGENUM.match(s):
            continue
        s = re.sub(r'\s+', ' ', s).strip()
        if buf and re.search(r'[A-Za-z]-$', buf[-1]):
            buf[-1] = buf[-1][:-1] + s          # con- + version → conversion
        else:
            buf.append(s)
    flush()
    paras = []
    for p in out:
        p = re.sub(r'\s+', ' ', p).strip()
        p = re.sub(r'([A-Za-z])-\s+([a-z])', r'\1-\2', p)   # sixty- four
        for pat, rep in FIXES:
            p = re.sub(pat, rep, p)
        if len(p) > 2:
            paras.append(p)
    return paras


def _heads(text, kind):
    """본문 표제 위치 — 목차의 것(뒤에 쪽번호가 붙는다)은 뺀다."""
    pat = re.compile(r'^\s*(%s)\s+%sS?\s*$' % ('|'.join(ORD), kind),
                     re.I | re.M)
    return [(m.start(), m.end(), m.group(1).upper()) for m in pat.finditer(text)]


# ⚠ 스캔 끝에 **도서관 대출 카드**가 붙어 온다 — UCSD 반납 안내·청구기호.
#   책은 마지막 편지의 「Yours, etc.」와 각주로 끝난다(실측).
_BACKMATTER = re.compile(
    r'^\s*(University\s+of\s+California|SOUTHERN\s+REGIONAL\s+LIBRARY|'
    r'Return\s+this\s+material|Date\s+Due|Social\s+Sciences|UCSD|'
    r'Please\s+Note:|THE\s+LIBRARY|A\s*\d{6,}|Univers[:;]|South\s*$|Libr[,.]?\s*$)',
    re.I | re.M)


def _cut_tail(text, after):
    """마지막 표제 뒤에서 **책이 끝나는 자리**를 찾아 자른다."""
    m = _BACKMATTER.search(text, after)
    return m.start() if m else len(text)


def _sections(text):
    """대화 4 + 편지 15 를 **한 줄로 세워** 다음 표제에서 끊는다.

    ⚠ 종류마다 따로 끊으면 **마지막 대화가 편지 전체를 삼킨다**(실측 44,389자).
    """
    all_h = []
    for kind in ('CONVERSATION', 'LETTER'):
        want = 4 if kind == 'CONVERSATION' else 15
        hs = _heads(text, kind)
        if len(hs) > want:          # 목차에도 같은 표제가 있다 — 뒤쪽이 본문
            hs = hs[-want:]
        all_h += [(s, e, kind, w) for s, e, w in hs]
    all_h.sort()
    tail = _cut_tail(text, all_h[-1][1]) if all_h else len(text)
    got = {'CONVERSATION': [], 'LETTER': []}
    for i, (s, e, kind, w) in enumerate(all_h):
        end = all_h[i + 1][0] if i + 1 < len(all_h) else tail
        got[kind].append((w, text[e:end]))
    return got


def parse(raw=None):
    text = raw if raw is not None else io.open(
        MAIN, encoding='utf-8', errors='replace').read()
    got = _sections(text)
    items = []
    for seq, label, parts in UNITS:
        chunks = []
        for kind, idx in parts:
            lst = got.get(kind) or []
            if idx >= len(lst):
                continue
            word, blk = lst[idx]
            paras = clean(blk)
            if kind == 'LETTER':
                # ★ **원문이 쓰는 그 말로** 머리를 단다 — 「ELEVENTH LETTER」.
                #   `LETTER XI` 처럼 우리가 지어낸 표기를 본문에 넣지 않는다.
                chunks.append('%s LETTER' % word)
            chunks += paras
        items.append(dict(seq=seq, label=label, paras=chunks))
    # 편지 묶음 끝에는 다음 표제까지 딸려 오지 않게 마지막 편지만 꼬리를 자른다
    return items


def body_text(e):
    return '\n'.join(e['paras']) + '\n\n' + ATTRIB


def check(items):
    """파싱이 성했는가 — 문제 목록(빈 목록 = 통과)."""
    bad = []
    if len(items) != 7:
        bad.append('편이 %d개 (7이라야 한다)' % len(items))
    for e in items:
        n = sum(len(p) for p in e['paras'])
        if n < 1500:
            bad.append('%d편 「%s」 가 %d자 (너무 짧다)' % (e['seq'], e['label'], n))
        body = '\n'.join(e['paras'])
        if re.search(r'[A-Za-z]-\s', body):
            bad.append('%d편에 줄끝 하이픈이 남았다' % e['seq'])
        if _BACKMATTER.search(body):
            bad.append('%d편에 도서관 대출 카드가 남았다' % e['seq'])
        if re.search(r'\bConversations?\s*$|\bLetters?\s*$', body, re.M):
            bad.append('%d편에 머리글이 남았다' % e['seq'])
    tot = sum(sum(len(p) for p in e['paras']) for e in items)
    if tot < 55000:
        bad.append('전체 %s자 — 전문이라기에 적다' % format(tot, ','))
    return bad


def spots(items):
    """**사람이 봐야 할 자리** — 기계가 못 고치는 글자 손상."""
    out = []
    for e in items:
        for p in e['paras']:
            for m in re.finditer(r'\S*[|~^{}\\«»£¥]\S*|'
                                 r'(?<![\w\'])[b-hj-np-zB-HJ-NP-Z](?![\w\'])|'
                                 r'\S*\d\S*[A-Za-z]\S*|[A-Za-z]\S*\d\S*', p):
                s = m.group(0)
                if s in ('1666', '1667', '1682', '1691'):
                    continue
                i = m.start()
                out.append((e['seq'], s, p[max(0, i - 45):i + 45]))
    return out


def purge(conn, dry=True):
    """옛 발췌본을 백업표로 옮긴다 — 되돌릴 수 있어야 한다."""
    conn.execute("CREATE TABLE IF NOT EXISTS temp_lawrence_old ("
                 " unit_id INTEGER, sequence INTEGER, unit_label TEXT,"
                 " text_variant TEXT, lang_code TEXT, body_text TEXT)")
    rows = conn.execute("""
        SELECT u.unit_id, u.sequence, u.unit_label, x.text_variant,
               x.lang_code, x.body_text
          FROM sys_book_unit u JOIN sys_book_asset b ON b.book_id=u.book_id
          JOIN sys_book_unit_text x ON x.unit_id=u.unit_id
         WHERE b.book_code=?""", (BOOK_CODE,)).fetchall()
    have = conn.execute("SELECT COUNT(*) FROM temp_lawrence_old").fetchone()[0]
    if not dry and not have:
        conn.executemany("INSERT INTO temp_lawrence_old VALUES (?,?,?,?,?,?)",
                         rows)
    return len(rows), have


def apply(conn, items, dry=False):
    """적재 — `(book_id, sequence)` 로 덮어써 `unit_id` 를 지킨다."""
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()[0]
    n_upd = n_new = 0
    for e in items:
        row = conn.execute("SELECT unit_id FROM sys_book_unit "
                           " WHERE book_id=? AND sequence=?",
                           (bid, e['seq'])).fetchone()
        if row:
            uid = row[0]
            n_upd += 1
            if not dry:
                conn.execute("UPDATE sys_book_unit SET unit_label=?, "
                             " record_status='LIVE' WHERE unit_id=?",
                             (e['label'], uid))
        else:
            n_new += 1
            if dry:
                continue
            uid = conn.execute(
                "INSERT INTO sys_book_unit(book_id,sequence,session_type,"
                "unit_label,record_status) VALUES(?,?,'CHAPTER',?,'LIVE')",
                (bid, e['seq'], e['label'])).lastrowid
        if dry:
            continue
        conn.execute("DELETE FROM sys_book_unit_text "
                     " WHERE unit_id=? AND text_variant='ORIGINAL'", (uid,))
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id,text_variant,lang_code,"
            "body_text,record_status) VALUES(?,'ORIGINAL','EN',?,'LIVE')",
            (uid, body_text(e)))
    if not dry:
        conn.execute("UPDATE sys_book_asset SET source_url=?, "
                     " copyright_type='PUBLIC_DOMAIN' WHERE book_id=?",
                     ('https://archive.org/details/practiceofpresen00lawriala',
                      bid))
    return n_new, n_upd


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    # ① 청소 규칙
    blk = ('THE  first  time  I  saw  Brother  Lawrence  was\n'
           'upon  the  }d  of  August,  1666.  He  told  me  that\n'
           'GOD  had  done  him  a  singular  favor  in  his  con-\n'
           'version at  the  age  of  eighteen.\n'
           '\n'
           '13\n'
           '14  Conversations\n'
           '\n'
           'That  he  had  been  footman.\n')
    ps = clean(blk)
    ck('겹공백을 눌렀다', all('  ' not in p for p in ps), ps[:1])
    ck('줄끝 하이픈을 붙였다', 'conversion at the age' in ps[0], ps[0][-40:])
    ck('쪽번호를 걷었다', not any(p.strip() == '13' for p in ps))
    ck('머리글을 걷었다', not any('Conversations' in p for p in ps))
    ck('}d 를 3d 로', '3d of August' in ps[0])
    ck('문단이 갈렸다', len(ps) == 2, len(ps))

    # ② 표제 찾기 — 목차의 것과 본문의 것을 가른다
    fake = ('Contents\nFIRST CONVERSATION 1 3\nSECOND CONVERSATION 1 6\n'
            'FIRST CONVERSATION\naaa\nSECOND CONVERSATION\nbbb\n')
    hs = _heads(fake, 'CONVERSATION')
    ck('목차 표제는 안 잡는다 (쪽번호가 붙었다)', len(hs) == 2, len(hs))

    # ③ 실제 원문
    if os.path.exists(MAIN):
        items = parse()
        ck('7편으로 갈렸다', len(items) == 7, len(items))
        bad = check(items)
        ck('파싱 게이트 통과', bad == [], bad[:4])
        tot = sum(sum(len(p) for p in e['paras']) for e in items)
        ck('옛 발췌본(9,046자)보다 훨씬 크다', tot > 55000, format(tot, ','))
        one = '\n'.join(items[0]['paras'])
        ck('첫 대화 첫 문장', 'first time I saw Brother Lawrence' in one)
        ck('열여덟에 회심', 'age of eighteen' in one)
        ck('없는 「스물여섯」이 안 들어왔다',
           'twenty-six' not in ' '.join(
               '\n'.join(e['paras']) for e in items).lower())
        ck('편지 머리가 원문 표기 그대로',
           'ELEVENTH LETTER' in '\n'.join(items[6]['paras'])
           and 'LETTER XI' not in '\n'.join(items[6]['paras']))
        last = '\n'.join(items[6]['paras'])
        ck('마지막 편이 「Yours, etc.」로 끝난다',
           last.rstrip().endswith('Yours, etc.')
           or 'died within the week' in last[-200:], last[-60:])
        ck('도서관 대출 카드를 잘랐다', 'Return this material' not in last)
        # 두 곳 대조
        have = [(n, p) for n, p, _ in SRC if os.path.exists(p)
                and os.path.getsize(p) > 20000]
        if len(have) >= 2:
            try:
                SM.gate(BOOK_CODE, have, verbose=False)
                ck('두 곳 대조 문지기 통과', True)
            except SystemExit as e:
                ck('두 곳 대조 문지기 통과', False, e)
        else:
            ck('원문 두 곳 보유', False, len(have))
    else:
        ck('원문 파일 있음 (--fetch 먼저)', False, MAIN)

    # ④ 실 DB 왕복 — 되돌린다
    try:
        conn = appdb.connect('bible_master.db')
        before = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text").fetchone()[0]
        conn.execute('BEGIN')
        if os.path.exists(MAIN):
            apply(conn, parse())
        conn.rollback()
        after = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text").fetchone()[0]
        ck('되돌린 뒤 행수 그대로', before == after, '%d → %d' % (before, after))
        conn.close()
    except Exception as e:
        ck('실 DB 왕복', False, e)

    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    if '--links' in a:
        SM.show_links(BOOK_CODE, [(n, u) for n, _, u in SRC],
                      note='판: Fleming H. Revell Company, 1895')
        return
    if '--fetch' in a:
        fetch()
        return
    if '--check' in a:
        items = parse()
        for e in items:
            n = sum(len(p) for p in e['paras'])
            print('  %d  %-22s %6s자  %d문단' % (e['seq'], e['label'],
                                               format(n, ','), len(e['paras'])))
        bad = check(items)
        for m in bad:
            print('  ✗ ' + m)
        have = [(n, p) for n, p, _ in SRC if os.path.exists(p)]
        SM.gate(BOOK_CODE, have)
        print('전체 %s자 · 문제 %d건'
              % (format(sum(sum(len(p) for p in e['paras']) for e in items),
                        ','), len(bad)))
        return
    if '--spots' in a:
        sp = spots(parse())
        print('사람이 봐야 할 자리 %d곳' % len(sp))
        for seq, s, ctx in sp:
            print('  [%d] %-14s … %s …' % (seq, s, ' '.join(ctx.split())))
        return
    if '--apply' in a:
        items = parse()
        bad = check(items)
        if bad:
            for m in bad:
                print('  ✗ ' + m)
            raise SystemExit('게이트에 걸렸다 — 적재하지 않는다.')
        have = [(n, p) for n, p, _ in SRC if os.path.exists(p)]
        SM.gate(BOOK_CODE, have)          # ⚠ 이 문을 우회하지 말 것
        conn = appdb.connect('bible_master.db')
        conn.execute('BEGIN')
        n_rows, had = purge(conn, dry=False)
        n_new, n_upd = apply(conn, items)
        conn.commit()
        conn.close()
        print('옛 본문 %d행 백업(temp_lawrence_old%s) · 새로 %d · 덮음 %d'
              % (n_rows, ', 이미 있었다' if had else '', n_new, n_upd))
        return
    print(__doc__)


if __name__ == '__main__':
    main()
