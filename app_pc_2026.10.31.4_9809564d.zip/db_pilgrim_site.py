# -*- coding: utf-8 -*-
"""db_pilgrim_site.py — **순례 장소 층**(2026-10-28 신설 · 영구 · docs/1.txt 9 성지순례 2단계).

성경 장소(용어 PLACE · 「예루살렘」)는 순례자가 실제로 찾아가는 **자리**(성묘교회 · 통곡의 벽 · 베데스다 연못)가 아니다.
그 자리를 따로 담는다 — 표 `sys_pilgrim_site` 하나:
    qid(위키데이터) · place_id(가장 가까운 우리 성경 장소) · 좌표 · 갈래(교회·유적·수도원·무덤·성소·산·박물관) ·
    links(위키 문서 수 = 알려진 정도) · names {언어: 이름} · wiki {언어: 위키백과 문서 제목} · status PEND|LIVE|HIDE.
★ 받는 것은 **후보**다 — 관리자가 승인(LIVE)한 것만 폰 공통팩에 실린다(사용자 「위키데이터 + 관리자 검수」).
★ 사용자 정보는 어디로도 안 나간다 — 이 PC 가 위키데이터에 묻고 결과만 담는다(폰은 망을 쓰지 않는다).
⚠ 위키데이터 내용은 CC0 · 이름·좌표·**한 줄 설명**(descs)만 담는다. 위키백과 본문(CC BY-SA)은 담지 않는다 —
  관리자 화면이 그때 불러와 읽기만 한다.
★ 2026-10-29 이름 세 칸 — `names_wd`(위키데이터가 준 것 · 다시 받으면 새로) · `names_mine`(사람이 고친 것 · 다시 받아도
  안 덮는다) · `names`(둘을 합친 것 = 화면·폰이 읽는 것 · 사람이 고친 값이 이긴다). 폰·팩은 `names` 만 읽으므로 손댈 것이 없다.
  ⚠ 합치는 문은 `merge_names` 하나 — 받을 때도 고칠 때도 그것으로 `names` 를 다시 짓는다.

  python db_pilgrim_site.py --selftest | --fetch [--limit N] | --descs(있는 후보의 설명만) | --status | --approve N(위키 문서 수 N 이상 일괄 승인)
"""
import json
import os
import sys
import time
import urllib.parse
import urllib.request

import appdb
import db_place_road as PR

SPARQL = 'https://query.wikidata.org/sparql'
API = 'https://www.wikidata.org/w/api.php'
UA = 'HagahDabar/1.0 (pilgrimage sites precompute; suhyw123@gmail.com)'
RADIUS_KM = 4          # 성경 장소 둘레 — 도시 안의 순례지를 담는다
MIN_LINKS = 6          # 위키 문서가 이보다 적으면 후보에도 안 넣는다(동네 교회)
#: 위키데이터 갈래(P31) → 우리 갈래 — 앞이 먼저(한 항목에 여럿이면 앞 갈래)
CLASSES = (
    ('Q2977', 'CHURCH'), ('Q163687', 'CHURCH'), ('Q16970', 'CHURCH'), ('Q108325', 'CHURCH'),
    ('Q44613', 'MONASTERY'), ('Q697295', 'SHRINE'), ('Q15135589', 'SHRINE'),
    ('Q381885', 'TOMB'), ('Q839954', 'ARCH'), ('Q15661340', 'ARCH'),
    ('Q8502', 'MOUNT'), ('Q33506', 'MUSEUM'),
)
KINDS = {'CHURCH': '교회', 'MONASTERY': '수도원', 'SHRINE': '성소', 'TOMB': '무덤', 'ARCH': '유적',
         'MOUNT': '산', 'MUSEUM': '박물관'}
#: 우리 언어 → 위키데이터 언어(앞이 먼저)
LANGS = {'KO': ('ko',), 'EN': ('en',), 'JA': ('ja',), 'ZH': ('zh-hans', 'zh-cn', 'zh'), 'ZHT': ('zh-hant', 'zh-tw', 'zh'),
         'DE': ('de',), 'FR': ('fr',), 'ES': ('es',), 'AR': ('ar',), 'RU': ('ru',), 'PT': ('pt',)}

DDL = """CREATE TABLE IF NOT EXISTS sys_pilgrim_site (
    site_id INTEGER PRIMARY KEY AUTOINCREMENT,
    qid TEXT UNIQUE NOT NULL, place_id INTEGER, lat REAL NOT NULL, lng REAL NOT NULL,
    kind TEXT, links INTEGER DEFAULT 0, names TEXT, wiki TEXT,
    status TEXT NOT NULL DEFAULT 'PEND', note TEXT, made_at TEXT)"""


def ensure(conn):
    conn.execute(DDL)
    have = {r[1] for r in conn.execute('PRAGMA table_info(sys_pilgrim_site)')}
    for col in ('names_wd', 'names_mine', 'descs', 'coord_fix', 'same_place', 'descs_wd', 'descs_mine'):
        if col not in have:
            conn.execute('ALTER TABLE sys_pilgrim_site ADD COLUMN %s TEXT' % col)
    if 'names_wd' not in have:                     # 옛 행 — 지금 names 가 곧 위키데이터 이름이다
        conn.execute('UPDATE sys_pilgrim_site SET names_wd=names WHERE names_wd IS NULL')
    if 'descs_wd' not in have:                     # ★ 2026-10-29 설명도 이름과 같은 세 칸 — 지금 descs 가 곧 위키데이터 한 줄
        conn.execute('UPDATE sys_pilgrim_site SET descs_wd=descs WHERE descs_wd IS NULL')
    conn.execute("CREATE INDEX IF NOT EXISTS ix_pilgrim_site_place ON sys_pilgrim_site(place_id)")


def _get(url, timeout=90):
    r = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
    with urllib.request.urlopen(r, timeout=timeout) as f:
        return json.load(f)


def query(lat, lng, radius=RADIUS_KM, min_links=MIN_LINKS):
    vals = ' '.join('wd:' + q for q, _k in CLASSES)
    return """SELECT ?item ?cls ?coord ?links WHERE {
  SERVICE wikibase:around { ?item wdt:P625 ?coord . bd:serviceParam wikibase:center "Point(%.6f %.6f)"^^geo:wktLiteral .
    bd:serviceParam wikibase:radius "%s" . }
  ?item wdt:P31 ?cls . VALUES ?cls { %s }
  ?item wikibase:sitelinks ?links . FILTER(?links >= %d)
}""" % (lng, lat, radius, vals, min_links)


def parse_point(s):
    """'Point(35.23 31.77)' → (위도, 경도)"""
    a = s[s.index('(') + 1:s.index(')')].split()
    return float(a[1]), float(a[0])


def parse_rows(bindings):
    """SPARQL 줄 → {qid: (위도, 경도, 갈래, 문서 수)} — 한 항목의 갈래가 여럿이면 앞 갈래"""
    rank = {q: (i, k) for i, (q, k) in enumerate(CLASSES)}
    out = {}
    for b in bindings:
        q = b['item']['value'].rsplit('/', 1)[-1]
        c = b['cls']['value'].rsplit('/', 1)[-1]
        if c not in rank:
            continue
        try:
            la, ln = parse_point(b['coord']['value'])
        except (ValueError, KeyError):
            continue
        n = int(b['links']['value'])
        cur = out.get(q)
        if cur is None or rank[c][0] < rank[cur[2]][0]:
            out[q] = (la, ln, c, n)
    return {q: (v[0], v[1], rank[v[2]][1], v[3]) for q, v in out.items()}


def pick_names(ent):
    """wbgetentities 한 항목 → ({언어: 이름}, {언어: 위키백과 문서})"""
    links = ent.get('sitelinks') or {}
    names, wiki = _pick(ent.get('labels')), {}
    for L, codes in LANGS.items():
        for cd in codes:
            k = cd.split('-')[0] + 'wiki'
            if k in links and links[k].get('title'):
                wiki[L] = links[k]['title']
                break
    return names, wiki


def _pick(d):
    """위키데이터 labels/descriptions → {우리 언어: 글}"""
    d, out = d or {}, {}
    for L, codes in LANGS.items():
        for cd in codes:
            if cd in d and d[cd].get('value'):
                out[L] = d[cd]['value']
                break
    return out


def pick_descs(ent):
    """wbgetentities 한 항목 → {언어: 한 줄 설명}(위키데이터 descriptions · CC0)"""
    return _pick(ent.get('descriptions'))


def merge_names(wd, mine):
    """보일 이름 — 사람이 고친 값이 이긴다(빈 값은 안 친다)"""
    out = dict(wd or {})
    for k, v in (mine or {}).items():
        if v and v.strip():
            out[k] = v.strip()
    return out


def _j(d):
    return json.dumps(d or {}, ensure_ascii=False)


def _entities(qs, pause=1.2, say=print):
    langs = '|'.join(sorted({c for cs in LANGS.values() for c in cs}))
    ents = {}
    for i in range(0, len(qs), 50):
        try:
            d = _get(API + '?action=wbgetentities&format=json&props=labels|descriptions|sitelinks&ids=%s&languages=%s'
                     % ('|'.join(qs[i:i + 50]), urllib.parse.quote(langs)))
            ents.update(d.get('entities') or {})
        except Exception as e:                            # noqa: BLE001
            say('  이름 실패 %s' % str(e)[:80])
        time.sleep(pause)
    return ents


def nearest(ps, la, ln):
    best, bd = None, 1e9
    for p in ps:
        d = PR.km(p, (None, la, ln))
        if d < bd:
            best, bd = p[0], d
    return best, bd


def fetch(conn, limit=None, pause=1.2, say=print):
    """성경 장소마다 둘레의 후보를 받는다 — 이미 있는 qid 는 좌표·문서 수만 새로(상태·사람 메모는 그대로)."""
    ensure(conn)
    ps = PR.places(conn)
    todo = ps[:limit] if limit else ps
    found = {}
    for n, p in enumerate(todo, 1):
        try:
            d = _get(SPARQL + '?format=json&query=' + urllib.parse.quote(query(p[1], p[2])))
            found.update(parse_rows(d['results']['bindings']))
        except Exception as e:                            # noqa: BLE001
            say('  실패 %s %s' % (p[0], str(e)[:80]))
            time.sleep(5)
        if n % 10 == 0:
            say('  장소 %d/%d · 후보 %d' % (n, len(todo), len(found)))
        time.sleep(pause)
    ents = _entities(list(found), pause, say)
    new = upd = 0
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    for q, (la, ln, kind, links) in found.items():
        ent = ents.get(q) or {}
        names, wiki = pick_names(ent)
        if not names:
            continue
        descs = pick_descs(ent)
        pid, _d = nearest(ps, la, ln)
        row = conn.execute('SELECT site_id, names_mine FROM sys_pilgrim_site WHERE qid=?', (q,)).fetchone()
        if row:
            # ⚠ 사람이 고친 이름(names_mine)은 안 건드린다 — 보일 이름만 다시 합친다
            mine = json.loads(row[1] or '{}')
            dm = json.loads(conn.execute('SELECT descs_mine FROM sys_pilgrim_site WHERE qid=?', (q,)).fetchone()[0] or '{}')
            fx = conn.execute('SELECT lat, lng, coord_fix FROM sys_pilgrim_site WHERE qid=?', (q,)).fetchone()
            if fx[2]:                                   # ⚠ 바로잡은 좌표는 다시 받아도 안 덮는다
                la, ln = fx[0], fx[1]
            conn.execute('UPDATE sys_pilgrim_site SET lat=?, lng=?, kind=?, links=?, names_wd=?, names=?, wiki=?, descs_wd=?, descs=?,'
                         ' place_id=? WHERE qid=?',
                         (la, ln, kind, links, _j(names), _j(merge_names(names, mine)), _j(wiki), _j(descs),
                          _j(merge_names(descs, dm)), pid, q))
            upd += 1
        else:
            conn.execute('INSERT INTO sys_pilgrim_site(qid, place_id, lat, lng, kind, links, names, names_wd, wiki, descs, descs_wd, made_at)'
                         ' VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
                         (q, pid, la, ln, kind, links, _j(names), _j(names), _j(wiki), _j(descs), _j(descs), now))
            new += 1
    conn.commit()
    return len(found), new, upd


def fetch_descs(conn, pause=1.2, say=print):
    """이미 있는 후보의 한 줄 설명(·위키데이터 이름)만 다시 받는다 — 둘레 검색은 안 한다(빠르다).
    ⚠ 사람이 고친 이름은 그대로 · 보일 이름만 다시 합친다."""
    ensure(conn)
    rs = conn.execute('SELECT qid, names_mine, descs_mine FROM sys_pilgrim_site').fetchall()
    ents = _entities([r[0] for r in rs], pause, say)
    n = 0
    for q, mine, dm in rs:
        ent = ents.get(q)
        if not ent:
            continue
        names, wiki = pick_names(ent)
        if not names:
            continue
        dw = pick_descs(ent)
        conn.execute('UPDATE sys_pilgrim_site SET names_wd=?, names=?, wiki=?, descs_wd=?, descs=? WHERE qid=?',
                     (_j(names), _j(merge_names(names, json.loads(mine or '{}'))), _j(wiki), _j(dw),
                      _j(merge_names(dw, json.loads(dm or '{}'))), q))
        n += 1
    conn.commit()
    return n


#: ★ 2026-10-29 바로잡은 좌표 — 위키데이터 좌표가 거칠거나 틀린 곳(사용자가 우리 앱 지도로 찾아 알려 준다).
#:   (qid, 위도, 경도, 까닭). `--fix-coords` 가 담고, 다시 받아도(fetch) 안 덮는다.
COORD_FIX = (
    ('Q215471', 33.4164, 35.8575, '헤르몬산 — 위키데이터 33.4, 35.85(소수 둘째 자리 · 약 1km 어긋남) → 정상'),
    ('Q1001370', 37.7880, 29.2583, '골로새 — 위키데이터 좌표가 라오디게아와 똑같았다(37.8358, 29.1075) → 골로새 언덕(호나즈 북쪽)'),
)


#: ★ 2026-10-29 성경 장소 **그 자체**인 순례 장소(사용자 「헤르몬산이 둘 — 하나만 표시되도록」).
#:   같은 곳이 두 표(성경 장소 · 순례 장소)에 있으면 지도에 이름이 두 번, 좌표가 두 개 뜬다.
#:   ⇒ ① 순례 장소는 `same_place=1` — 폰 공통팩에 안 싣는다(성경 장소 하나만 보인다)
#:      ② 성경 장소 좌표는 이 순례 장소의 좌표로(우리 것은 소수 둘째 자리로 어림한 것이 많다 — 헤르몬산은 정상 아래 계곡이었다).
#:   ⚠ 어느 유적이 그 성경 장소인지 학설이 갈리는 곳(아이 = 엣 텔 · 라암셋 = 칸티르)은 넣지 않는다 — 다른 자리로 남는다.
#:   (qid, 성경 장소 좌표의 원천이면 True) — 한 성경 장소에 둘이면 True 인 것 하나가 좌표를 준다(세겜).
SAME_PLACE = (
    ('Q215471', True), ('Q1757438', True), ('Q7697383', False), ('Q7951237', True), ('Q889398', True),
    ('Q680161', True), ('Q985542', True), ('Q2916407', True), ('Q606295', True), ('Q1346856', True),
    ('Q2914898', True), ('Q218016', True), ('Q2916736', True), ('Q2002121', True), ('Q1549278', True),
)


def apply_same(conn):
    """→ (같은 곳으로 표시한 수, 성경 장소 좌표를 옮긴 수)"""
    ensure(conn)
    n = m = 0
    for q, src in SAME_PLACE:
        n += conn.execute('UPDATE sys_pilgrim_site SET same_place=1 WHERE qid=?', (q,)).rowcount
        if not src:
            continue
        r = conn.execute('SELECT place_id, lat, lng FROM sys_pilgrim_site WHERE qid=?', (q,)).fetchone()
        if r and r[0]:
            m += conn.execute("UPDATE sys_entity_master SET geo_lat=?, geo_lng=? WHERE entity_id=? AND entity_type='PLACE'"
                              " AND (ABS(geo_lat-?)>1e-6 OR ABS(geo_lng-?)>1e-6)", (r[1], r[2], r[0], r[1], r[2])).rowcount
    conn.commit()
    return n, m


#: ★ 2026-10-29 손으로 더한 대표 순례지 — 성경 장소 둘레 4km 안만 받아서 빠진 곳(마사다·쿰란·페트라·기자 …).
#:   구간(db_pilgrim_leg)의 재료다. (qid, 갈래, 한국어 이름 — 위키데이터에 한국어 이름이 없을 때 쓴다)
EXTRA = (
    ('Q186312', 'ARCH', '마사다'), ('Q223399', 'ARCH', '쿰란'), ('Q5788', 'ARCH', '페트라'),
    ('Q31565', 'ARCH', '제라시'), ('Q152368', 'ARCH', '벧산(벳 셰안)'), ('Q12508', 'ARCH', '기자 피라미드'),
    ('Q522862', 'ARCH', '카르나크 신전'), ('Q319841', 'ARCH', '룩소르 신전'), ('Q133423', 'TOMB', '왕가의 계곡'),
    ('Q2422298', 'CHURCH', '공중 교회(알 무알라카)'), ('Q2474653', 'SHRINE', '벤 에즈라 회당'), ('Q40729', 'MOUNT', '와디 럼'),
    ('Q131955', 'ARCH', '움 카이스(가다라)'), ('Q844694', 'ARCH', '케락 성(길하레셋)'), ('Q2063578', 'ARCH', '텔 아랏'),
    ('Q1973199', 'ARCH', '팀나 골짜기'), ('Q4880851', 'ARCH', '막달라'), ('Q991404', 'SHRINE', '야르데닛 세례터'),
    ('Q130815', 'CHURCH', '수태고지 교회'), ('Q1606585', 'MONASTERY', '스텔라 마리스 수도원'), ('Q1494672', 'TOMB', '정원 무덤'),
    ('Q1238436', 'CHURCH', '눈물 교회(도미누스 플레빗)'), ('Q847246', 'ARCH', '엠마오 니코폴리스'), ('Q913099', 'ARCH', '헤로디움'),
    ('Q12412084', 'ARCH', '텔 벧세메스'), ('Q3157009', 'ARCH', '암만 성채'), ('Q1346870', 'CHURCH', '마다바 지도(성 게오르기우스 교회)'),
    ('Q201219', 'MUSEUM', '이집트 박물관'), ('Q2109794', 'CHURCH', '베드로 수위권 교회'), ('Q2602652', 'MOUNT', '낭떠러지 산'),
    ('Q740138', 'ARCH', '텔 하솔'), ('Q7440096', 'MUSEUM', '갈릴리 고대 배'), ('Q750209', 'ARCH', '멤논의 거상'),
    ('Q501773', 'ARCH', '벳새다'), ('Q1493165', 'ARCH', '감라'), ('Q848509', 'ARCH', '텔 라기스'),
    ('Q1019166', 'ARCH', '디본'), ('Q660692', 'ARCH', '하트셉수트 장제전'), ('Q819281', 'MOUNT', '아르벨산'),
    # ★ 2026-10-29 튀르키예·그리스 권역 — 넷째 칸 True = 개역한글 지명을 늘 한국어 이름으로(위키데이터 한국어 이름이 있어도)
    ('Q2827071', 'ARCH', '서머나 아고라', True), ('Q18986', 'ARCH', '버가모', True), ('Q1135603', 'ARCH', '두아디라', True),
    ('Q232615', 'ARCH', '사데', True), ('Q138280', 'ARCH', '빌라델비아(알라셰히르)', True),
    ('Q849709', 'ARCH', '라오디게아', True), ('Q7428276', 'ARCH', '히에라볼리', True), ('Q1001370', 'ARCH', '골로새', True),
    ('Q135779', 'SHRINE', '성모 마리아의 집'), ('Q744406', 'ARCH', '켈수스 도서관(에베소)'),
    ('Q516472', 'CHURCH', '성 베드로 동굴 교회(안디옥)'), ('Q1605894', 'ARCH', '실루기아(셀레우키아 피에리아)', True),
    ('Q105944717', 'SHRINE', '바울의 우물(다소)'), ('Q12506', 'CHURCH', '아야 소피아'), ('Q736676', 'CHURCH', '아야 이리니'),
    ('Q4430013', 'CHURCH', '니케아 아야 소피아(이즈니크)'), ('Q744631', 'ARCH', '앗소', True), ('Q6710593', 'ARCH', '괴레메(갑바도기아 동굴 교회)'),
    ('Q5994531', 'ARCH', '앗달리아 옛 도시(칼레이치)'),
    ('Q217414', 'ARCH', '암비볼리', True), ('Q730019', 'CHURCH', '성 데메트리오스 성당(데살로니가)'), ('Q3125051', 'MONASTERY', '메테오라'),
    ('Q202487', 'ARCH', '아레오바고', True), ('Q131013', 'ARCH', '아크로폴리스'), ('Q395367', 'ARCH', '아덴 아고라(시장)'),
    ('Q1363688', 'ARCH', '고린도 유적', True), ('Q1982506', 'MONASTERY', '사도 요한 수도원(밧모)'), ('Q1978886', 'SHRINE', '계시 동굴(밧모)'),
    # ★ 2026-10-30 예루살렘 도보 구역(비아 돌로로사 · 성전산 남쪽 · 시온산)에 빠졌던 곳 — 위키데이터 둘레 검색으로 고름
    ('Q129278', 'ARCH', '사자문(스데반 문)'), ('Q1551966', 'CHURCH', '성 안나 교회'), ('Q1499131', 'CHURCH', '채찍질 교회'),
    ('Q999100', 'CHURCH', '고통의 성모 교회(비아 돌로로사 4처)'), ('Q92147990', 'SHRINE', '비아 돌로로사 3처'),
    ('Q92153349', 'SHRINE', '비아 돌로로사 6처(베로니카)'), ('Q92147999', 'SHRINE', '비아 돌로로사 7처'),
    ('Q92147996', 'SHRINE', '비아 돌로로사 9처'), ('Q16715750', 'CHURCH', '성 알렉산드르 넵스키 교회(심판의 문)'),
    ('Q1483483', 'ARCH', '실로암 못'), ('Q204601', 'ARCH', '기혼 샘'), ('Q1245538', 'CHURCH', '마리아 영면 교회'),
    ('Q947597', 'ARCH', '다마스쿠스 문'), ('Q312812', 'ARCH', '욥바 문'), ('Q205416', 'ARCH', '시온 문'),
    ('Q204719', 'ARCH', '분문(쓰레기 문)'), ('Q1367167', 'ARCH', '황금문'), ('Q172077', 'SHRINE', '바위 사원'),
    ('Q8022908', 'ARCH', '윌슨 아치'),
    # ★ 2026-10-30 도보 구역 넓히기 — 베들레헴 · 나사렛 · 에베소 · 셀추크
    ('Q2557689', 'ARCH', '구유 광장'), ('Q4362268', 'SHRINE', '탄생 동굴'), ('Q1698008', 'CHURCH', '성탄 교회(루터교)'),
    ('Q7600915', 'ARCH', '별의 길'),
    ('Q1606462', 'ARCH', '마리아의 우물'), ('Q5293153', 'CHURCH', '성 가브리엘 교회(정교회 수태고지 교회)'),
    ('Q6983327', 'MUSEUM', '나사렛 마을'), ('Q2887142', 'CHURCH', '소년 예수 성당'),
    ('Q15723477', 'ARCH', '에베소 대극장'), ('Q1575495', 'ARCH', '에베소 언덕 위 집들'), ('Q2581040', 'ARCH', '하드리아누스 신전(에베소)'),
    ('Q77071353', 'ARCH', '에베소 상업 아고라'), ('Q77071662', 'ARCH', '에베소 국가 아고라'), ('Q2450228', 'CHURCH', '마리아 교회(에베소 공의회)'),
    ('Q930613', 'CHURCH', '사도 요한 교회(셀추크)'), ('Q43018', 'ARCH', '아데미 신전'), ('Q1346784', 'MUSEUM', '에베소 고고학 박물관'),
)


def add_extra(conn, pause=1.0, say=print):
    """EXTRA 를 위키데이터에서 받아 승인(LIVE)으로 담는다 — 이미 있는 qid 는 건너뛴다(멱등)."""
    ensure(conn)
    have = {r[0] for r in conn.execute('SELECT qid FROM sys_pilgrim_site')}
    todo = [x for x in EXTRA if x[0] not in have]
    # (aegean 은 둘레 4km 받기를 안 한다 — 이스탄불·아테네는 박물관·교회가 수백이라 손으로 고른 이것만)
    if not todo:
        return 0
    langs = '|'.join(sorted({c for cs in LANGS.values() for c in cs}))
    d = _get(API + '?action=wbgetentities&format=json&props=labels|descriptions|sitelinks|claims&ids=%s&languages=%s'
             % ('|'.join(x[0] for x in todo), urllib.parse.quote(langs)))
    ents = d.get('entities') or {}
    ps = PR.places(conn, 'ALL')   # 튀르키예·그리스 곳도 가장 가까운 성경 장소에
    now = time.strftime('%Y-%m-%d %H:%M:%S')
    n = 0
    for q, kind, ko, *force in todo:
        ent = ents.get(q) or {}
        try:
            v = ent['claims']['P625'][0]['mainsnak']['datavalue']['value']
            la, ln = round(v['latitude'], 6), round(v['longitude'], 6)
        except (KeyError, IndexError, TypeError):
            say('  좌표 없음 %s' % q)
            continue
        names, wiki = pick_names(ent)
        mine = {'KO': ko} if (force and force[0]) or not names.get('KO') else {}
        pid, _d = nearest(ps, la, ln)
        conn.execute('INSERT INTO sys_pilgrim_site(qid, place_id, lat, lng, kind, links, names, names_wd, names_mine, wiki, descs,'
                     " descs_wd, status, note, made_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'LIVE','EXTRA',?)",
                     (q, pid, la, ln, kind, len(ent.get('sitelinks') or {}), _j(merge_names(names, mine)), _j(names),
                      _j(mine) if mine else None, _j(wiki), _j(pick_descs(ent)), _j(pick_descs(ent)), now))
        n += 1
    conn.commit()
    time.sleep(pause)
    return n


def fix_coords(conn):
    ensure(conn)
    n = 0
    for q, la, ln, why in COORD_FIX:
        n += conn.execute('UPDATE sys_pilgrim_site SET lat=?, lng=?, coord_fix=? WHERE qid=?', (la, ln, why, q)).rowcount
    conn.commit()
    return n


def set_name(conn, site_id, lang, val, commit=True):
    """사람이 그 언어 이름을 고친다 — 비우거나 위키데이터 이름과 같으면 「내가 고친 것」에서 뺀다(되돌리기)."""
    ensure(conn)
    r = conn.execute('SELECT names_wd, names_mine FROM sys_pilgrim_site WHERE site_id=?', (int(site_id),)).fetchone()
    if not r:
        return None
    wd, mine = json.loads(r[0] or '{}'), json.loads(r[1] or '{}')
    v = (val or '').strip()
    if not v or v == wd.get(lang, ''):
        mine.pop(lang, None)
    else:
        mine[lang] = v
    shown = merge_names(wd, mine)
    conn.execute('UPDATE sys_pilgrim_site SET names_mine=?, names=? WHERE site_id=?',
                 (_j(mine) if mine else None, _j(shown), int(site_id)))
    if commit:
        conn.commit()
    return shown


def set_desc(conn, site_id, lang, val, commit=True):
    """★ 2026-10-29 우리가 쓴 설명 — 비우면 위키데이터 한 줄로 돌아간다 · 다시 받아도 안 덮는다(이름과 같은 규칙)."""
    ensure(conn)
    r = conn.execute('SELECT descs_wd, descs_mine FROM sys_pilgrim_site WHERE site_id=?', (int(site_id),)).fetchone()
    if not r:
        return None
    wd, mine = json.loads(r[0] or '{}'), json.loads(r[1] or '{}')
    v = (val or '').strip()
    if v:
        mine[lang] = v
    else:
        mine.pop(lang, None)
    shown = merge_names(wd, mine)
    conn.execute('UPDATE sys_pilgrim_site SET descs_mine=?, descs=? WHERE site_id=?',
                 (_j(mine) if mine else None, _j(shown), int(site_id)))
    if commit:
        conn.commit()
    return shown


def name_src(site, lang):
    """그 언어 이름의 출처 — 'MINE' 내가 고침 · 'WD' 위키데이터 · '' 없음"""
    if (site.get('mine') or {}).get(lang):
        return 'MINE'
    if (site.get('wd') or {}).get(lang):
        return 'WD'
    return ''


def site(conn, site_id):
    """한 곳 → dict(이름 셋 · 설명 · 위키 · 좌표 · 상태)"""
    ensure(conn)
    r = conn.execute('SELECT site_id, qid, place_id, lat, lng, kind, links, names, names_wd, names_mine, wiki, descs,'
                     ' status, note, same_place, coord_fix, descs_mine FROM sys_pilgrim_site WHERE site_id=?', (int(site_id),)).fetchone()
    if not r:
        return None
    js = [json.loads(x or '{}') for x in r[7:12]]
    return dict(id=r[0], qid=r[1], place_id=r[2], lat=r[3], lng=r[4], kind=r[5], links=r[6], names=js[0], wd=js[1],
                mine=js[2], wiki=js[3], descs=js[4], status=r[12], note=r[13], same=str(r[14] or '0') == '1', fix=r[15] or '',
                descs_mine=json.loads(r[16] or '{}'))


def approve(conn, min_links):
    """위키 문서 수 N 이상인 후보를 일괄 승인 — 사람이 숨긴 것(HIDE)은 안 건드린다."""
    ensure(conn)
    n = conn.execute("UPDATE sys_pilgrim_site SET status='LIVE' WHERE status='PEND' AND links>=?", (int(min_links),)).rowcount
    conn.commit()
    return n


def set_status(conn, site_id, st):
    assert st in ('PEND', 'LIVE', 'HIDE')
    conn.execute('UPDATE sys_pilgrim_site SET status=? WHERE site_id=?', (st, int(site_id)))
    conn.commit()


def rows(conn, status=None):
    """→ [(site_id, qid, place_id, lat, lng, kind, links, names{}, wiki{}, status, note)] 문서 수 차례"""
    ensure(conn)
    q = 'SELECT site_id, qid, place_id, lat, lng, kind, links, names, wiki, status, note FROM sys_pilgrim_site'
    a = ()
    if status:
        q += ' WHERE status=?'
        a = (status,)
    out = []
    for r in conn.execute(q + ' ORDER BY links DESC, site_id', a):
        out.append(r[:7] + (json.loads(r[7] or '{}'), json.loads(r[8] or '{}')) + r[9:])
    return out


def name_of(names, lang='KO'):
    return names.get(lang) or names.get('EN') or next(iter(names.values()), '')


def status(conn):
    ensure(conn)
    return dict(conn.execute('SELECT status, COUNT(*) FROM sys_pilgrim_site GROUP BY status').fetchall())


def selftest():
    ok, fails = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            fails.append(m)
    ck(parse_point('Point(35.2316 31.7767)') == (31.7767, 35.2316), '좌표 읽기(경도 위도 차례)')
    b = [{'item': {'value': 'http://www.wikidata.org/entity/Q1'}, 'cls': {'value': 'x/Q839954'},
          'coord': {'value': 'Point(35 31)'}, 'links': {'value': '20'}},
         {'item': {'value': 'http://www.wikidata.org/entity/Q1'}, 'cls': {'value': 'x/Q2977'},
          'coord': {'value': 'Point(35 31)'}, 'links': {'value': '20'}},
         {'item': {'value': 'http://www.wikidata.org/entity/Q2'}, 'cls': {'value': 'x/Q999'},
          'coord': {'value': 'Point(35 31)'}, 'links': {'value': '9'}}]
    r = parse_rows(b)
    ck(r.get('Q1', (0, 0, ''))[2] == 'CHURCH', '갈래가 여럿이면 앞 갈래(교회)')
    ck('Q2' not in r, '모르는 갈래는 뺀다')
    n, w = pick_names({'labels': {'ko': {'value': '성묘교회'}, 'en': {'value': 'Holy Sepulchre'},
                                  'zh-hant': {'value': '聖墓教堂'}},
                       'sitelinks': {'kowiki': {'title': '성묘 교회'}}})
    ck(n.get('KO') == '성묘교회' and n.get('ZHT') == '聖墓教堂' and 'JA' not in n, '이름 — 그 언어만 · 없으면 비움')
    ck(w.get('KO') == '성묘 교회', '위키백과 문서 제목')
    ck(name_of({'EN': 'A'}, 'KO') == 'A', '이름 없으면 영어')
    ck(pick_descs({'descriptions': {'ko': {'value': '예루살렘의 교회'}, 'en': {'value': 'church'}}}) ==
       {'KO': '예루살렘의 교회', 'EN': 'church'}, '한 줄 설명 — 그 언어만')
    ck(merge_names({'KO': 'A', 'EN': 'B'}, {'KO': '가', 'JA': ' '}) == {'KO': '가', 'EN': 'B'}, '사람 이름이 이긴다 · 빈 값은 안 친다')
    ck(name_src({'mine': {'KO': '가'}, 'wd': {'KO': 'A', 'EN': 'B'}}, 'KO') == 'MINE'
       and name_src({'mine': {}, 'wd': {'EN': 'B'}}, 'EN') == 'WD' and name_src({'wd': {}}, 'JA') == '', '이름 출처')
    ck('wikibase:around' in query(31.7, 35.2) and 'FILTER(?links >= 6)' in query(31.7, 35.2), '묻는 글')
    c = appdb.connect()
    ensure(c)
    c.execute('SAVEPOINT t')
    c.execute("INSERT INTO sys_pilgrim_site(qid, lat, lng, links, names, status) VALUES('QTEST1', 31, 35, 30, '{}', 'PEND')")
    c.execute("INSERT INTO sys_pilgrim_site(qid, lat, lng, links, names, status) VALUES('QTEST2', 31, 35, 3, '{}', 'PEND')")
    c.execute("INSERT INTO sys_pilgrim_site(qid, lat, lng, links, names, status) VALUES('QTEST3', 31, 35, 99, '{}', 'HIDE')")
    c.execute("UPDATE sys_pilgrim_site SET status='LIVE' WHERE status='PEND' AND links>=20 AND qid LIKE 'QTEST%'")
    st = dict(c.execute("SELECT qid, status FROM sys_pilgrim_site WHERE qid LIKE 'QTEST%'").fetchall())
    ck(st == {'QTEST1': 'LIVE', 'QTEST2': 'PEND', 'QTEST3': 'HIDE'}, '일괄 승인 — 문서 수 · 숨긴 것은 그대로')
    c.execute("""UPDATE sys_pilgrim_site SET names_wd='{"KO": "옛", "EN": "Old"}', names='{"KO": "옛", "EN": "Old"}'
                 WHERE qid='QTEST1'""")
    sid = c.execute("SELECT site_id FROM sys_pilgrim_site WHERE qid='QTEST1'").fetchone()[0]
    set_name(c, sid, 'KO', '새 이름', commit=False)
    set_name(c, sid, 'JA', '日本名', commit=False)
    x = site(c, sid)
    ck(x['names'] == {'KO': '새 이름', 'EN': 'Old', 'JA': '日本名'} and x['wd'] == {'KO': '옛', 'EN': 'Old'},
       '이름 고치기 — 보일 이름은 합친 것 · 위키데이터 이름은 그대로')
    set_name(c, sid, 'KO', '옛', commit=False)       # 위키데이터와 같게 = 되돌리기
    set_name(c, sid, 'JA', '', commit=False)
    x = site(c, sid)
    ck(x['mine'] == {} and x['names'] == {'KO': '옛', 'EN': 'Old'}, '되돌리기 — 내가 고친 것이 비면 위키데이터 이름')
    c.execute("""UPDATE sys_pilgrim_site SET descs_wd='{"EN": "church"}', descs='{"EN": "church"}' WHERE qid='QTEST1'""")
    set_desc(c, sid, 'KO', '우리 설명', commit=False)
    x = site(c, sid)
    ck(x['descs'] == {'EN': 'church', 'KO': '우리 설명'} and x['descs_mine'] == {'KO': '우리 설명'}, '우리 설명 — 위키데이터 한 줄과 합쳐 보인다')
    c.execute('ROLLBACK TO t')
    c.execute('RELEASE t')
    ck(not c.execute("SELECT 1 FROM sys_pilgrim_site WHERE qid LIKE 'QTEST%'").fetchone(), '시험 자국 0')
    print('db_pilgrim_site selftest %d/%d' % (ok, ok + len(fails)))
    for f in fails:
        print('  FAIL', f)
    return not fails


DESC_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'source_texts', 'pilgrim_site_desc.json')


def load_descs(conn, path=DESC_FILE):
    """★ 2026-10-29 우리가 쓴 설명(KO·EN · 위키백과 요약을 읽고 다시 씀 · 열쇠 = 위키데이터 qid) → descs_mine.
    멱등 · 파일에 없는 언어는 위키데이터 한 줄 그대로."""
    ensure(conn)
    data = json.load(open(path, encoding='utf-8'))
    n = 0
    for q, langs in data.items():
        r = conn.execute('SELECT site_id FROM sys_pilgrim_site WHERE qid=?', (q,)).fetchone()
        if not r:
            continue
        for L, v in langs.items():
            set_desc(conn, r[0], L, v, commit=False)
        n += 1
    conn.commit()
    return n


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    if '--extra' in a:
        print('더한 대표 순례지 %d' % add_extra(c))
    elif '--same' in a:
        print('성경 장소와 같은 곳 %d · 성경 장소 좌표 옮김 %d' % apply_same(c))
    elif '--fix-coords' in a:
        print('좌표 바로잡음 %d' % fix_coords(c))
    elif '--load-descs' in a:
        print('우리 설명 담음 %d' % load_descs(c))
    elif '--descs' in a:
        print('설명·이름 다시 받음 %d' % fetch_descs(c))
    elif '--fetch' in a:
        lim = int(a[a.index('--limit') + 1]) if '--limit' in a else None
        print('후보 %d · 새로 %d · 고침 %d' % fetch(c, limit=lim))
    elif '--approve' in a:
        print('승인 %d' % approve(c, int(a[a.index('--approve') + 1])))
    elif '--status' in a:
        print(status(c))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
