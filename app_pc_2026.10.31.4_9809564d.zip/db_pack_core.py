# -*- coding: utf-8 -*-
"""코어팩 빌더 — **모든 연결 + 모든 껍데기 + 좌표**를 한 파일로.

★★★ 왜 (2026-09-04 사용자 확정 「방법 2」 — 「**모든 연결관계를 전송**하고, 각
  연결대상 자산의 **껍데기(책id, 제목, 소개서)를 묶어서 코어팩으로** 전송한다.
  사용자가 다운로드 받지 않은 자산과 연결된 것이 나타나면 **효과적인 방법으로
  폴백** 처리한다」 · 「**미디어 본체도 코어에 넣어라**」).
  실측이 그 판단을 받쳤다 — 연결 67,255행 = 3.6MB · 껍데기 0.47MB 인데
  본문은 성경 51MB · 도서 147MB 다. **연결 전체가 도서 한 권의 3%도 안 된다.**

**무엇을 담나 = `db_pack_catalog` 가 정한다** — 여기서 표를 손으로 적지 않는다.
  그 표에 `CORE` 로 적힌 것 전부. **표가 늘면 저절로 담긴다.**
  ⚠ `RULE_ONLY` 표는 **예외 행만** 담는다(URL 22.7MB 를 그렇게 걷었다).

⚠⚠ **기존 배포를 깨뜨리지 않는다** — `db_linkpack_build`(지금 도는 것)를 전혀
  건드리지 않고 **나란히** 만든다. 갈아타는 것은 **받는 쪽이 선 뒤**의 일이고,
  그때까지 이 파일은 만들어 보고 재는 용도다.

`--selftest`(의무) · `--build` · `--verify` · `--size`.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
import sqlite3
import sys
import time

import appdb
import db_pack_catalog as PC

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, '_linkpack_dist')
CORE_NAME = 'corepack.json.gz'

#: 팩 형식 판 — 받는 쪽이 「내가 읽을 수 있는 형식인가」를 먼저 본다.
#: ⚠ 담는 방식을 바꾸면 **이 수를 올린다**. 안 올리면 옛 앱이 이상하게 읽는다.
FORMAT = 1


def core_tables(conn=None, cycle=None):
    """코어에 담을 표 → `[(표, 조건|None)]`. **카탈로그가 단일 소스**.

    ★★ `cycle` 을 주면 **그 배포 주기에 속한 표만**(2026-09-05 릴리스 패킹).
      배정은 `sys_pack_plan` 이 갖고 있고 여기서 다시 정하지 않는다.
    ⚠ **인자를 안 주면 지금까지와 똑같다** — 호출부 다섯(검사기·델타·룰엔진)이
      무수정으로 돈다.
    """
    out = []
    # ★★ **관리자가 뺀 표는 담지 않는다**(2026-09-24 1.txt 12-2).
    #   ⚠ 뺄 수 있는 표는 `PC.CORE_OPTIONAL` 에 적힌 것뿐이고, 그 판정은
    #     `db_pack_core_pick` 한 곳이 한다 — 여기서 다시 적지 않는다.
    #   ⚠⚠ **받는 쪽에서도 이 함수가 불린다**(`db_pack_apply._wipe_scope`).
    #     사용자 DB 에는 선택 표가 없으므로 **아무것도 안 빼는 것**이 맞다 —
    #     그래서 못 읽으면 조용히 전체를 낸다(선택은 관리자 것이다).
    off = set()
    if conn is not None:
        try:
            import db_pack_core_pick as _CK
            off = _CK.excluded(conn)
        except Exception:                                    # noqa: BLE001
            off = set()
    for t, (layer, _k, _d) in sorted(PC.TABLES.items()):
        if layer != PC.CORE or t in off:
            continue
        cond = PC.RULE_ONLY.get(t, (None,))[0]
        out.append((t, cond))
    if cycle is None or conn is None:
        return out
    try:
        import db_pack_stat as ST
        cy = ST.cycles(conn)
        want = str(cycle).upper()
        return [(t, c) for t, c in out
                if cy.get('T:' + t, ST.DEFAULT_CYCLE) == want]
    except Exception:
        return out


def core_name(cycle=None):
    """코어팩 파일 이름 — **이름을 짓는 단일 문**.

    ⚠ 손으로 지으면 만드는 쪽과 받는 쪽이 어긋난다(§팩 작업 규칙 ⑩).
    """
    if not cycle:
        return CORE_NAME
    return 'corepack_%s.json.gz' % str(cycle).upper()


def core_cycles(conn):
    """실제로 **담을 것이 있는** 주기 → `[주기…]`(적재 순서대로).

    ⚠ **빈 팩을 만들지 않는다** — 받았는데 아무것도 안 생기는 가장 나쁜 실패다.
    ⚠ 순서는 `apply_order`(느린 것부터) — 껍데기가 먼저, 연결이 나중이다.
    """
    try:
        import db_pack_stat as ST
        out = [c for c in ST.apply_order()
               if core_tables(conn, c)]
        return out
    except Exception:
        return []


#: 바이너리 값을 담는 봉투. ⚠ **JSON 은 bytes 를 못 담는다** — 실 DB 에서
#: `sys_menu_config` 가 BLOB 을 갖고 있어 첫 빌드가 그 자리에서 죽었다.
B64 = '__b64__'


def _enc(v):
    if isinstance(v, (bytes, bytearray, memoryview)):
        import base64
        return {B64: base64.b64encode(bytes(v)).decode('ascii')}
    return v


def dec(v):
    """팩의 값을 되돌린다(받는 쪽이 쓴다)."""
    if isinstance(v, dict) and B64 in v:
        import base64
        return base64.b64decode(v[B64])
    return v


def dump_table(conn, table, cond=None):
    """표 하나 → `{'cols': [...], 'rows': [[...], ...]}` 또는 None(표 없음).

    ⚠ 칸 이름을 함께 담는다 — 받는 쪽 스키마가 조금 달라도 이름으로 맞춘다
      (번호로 맞추면 칸을 하나 더한 날 통째로 어긋난다).
    ⚠ **바이너리는 base64 봉투에 넣는다**(`dec` 로 되돌린다).
    """
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % table)]
    except Exception:
        return None
    if not cols:
        return None
    # ★★★ **비울 칸은 SQL 에서부터 비운다**(`DROP_COLS`) — 읽어 놓고
    #   뒤에서 지우면 그 사이에 메모리로 28MB 가 올라온다. 그리고 한 자리를
    #   빠뜨리기 쉽다.
    drop = set(getattr(PC, 'DROP_COLS', {}).get(table, ()))
    sel = ','.join(("'' AS %s" % x) if x in drop else x for x in cols)
    q = "SELECT %s FROM %s" % (sel, table)
    if cond:
        q += ' WHERE ' + cond
    try:
        rows = [[_enc(v) for v in r] for r in conn.execute(q)]
    except Exception as e:                                    # noqa: BLE001
        # ⚠⚠⚠ **표는 있는데 조건이 터진 것을 조용히 빠뜨리지 않는다**
        #   (2026-09-05 실측으로 잡았다 — `sys_splash_image` 에 `style` 칸이
        #   없는 DB 에서 `RULE_ONLY` 조건이 터져 **그 표가 통째로 사라졌다**).
        #   §⑨ 「메모리 DB 에 sys_media_asset 이 없어 sys_link_asset 이 통째로
        #   빠졌다」와 같은 자리다. **팩이 조용히 비는 것이 가장 나쁜 실패다.**
        if cond:
            raise ValueError(
                '%s: 담을 조건이 터졌다 — 칸이 없거나 조건이 잘못됐다.'
                ' 조건=%s / %s' % (table, cond, str(e)[:60]))
        return None                    # 조건 없이 터졌다 = 표를 못 읽는다
    return {'cols': cols, 'rows': rows}



def bundled_of(conn):
    """코어에 함께 싣는 맛보기 자산 → `[{kind,key,lang,variant,version}]`.

    ★★★ **판을 함께 적는다**(2026-09-24 286차 — 사용자 물음 「코어팩에 이미
      개별자산 팩이 포함되어 있으므로 사용자 화면에 이미 다운로드했다고
      표시되는가?」).
      실측 답 = **「받음」으로는 보였는데 판을 몰랐다.** 받는 쪽은 본문 행을
      세어 상태를 정하므로(`pack_fallback.state`) 설치됨으로는 떴지만
      `sys_pack_applied` 에 줄이 없어 `mine` 이 비고, 그래서 그 자산의 새 판이
      나와도 **영영 「최신」**이라 적혔다.
    ⚠ 판이 0 이면 **한 번만 1 로 올린다** — 「이 내용으로 내보냈다」는 사실에
      번호가 있어야 다음 판과 견줄 수 있다. 이미 판이 있으면 **안 올린다**
      (코어를 다시 만들 때마다 오르면 사용자 화면이 까닭 없이 깜박인다).
    """
    import db_pack_core_pick as _CK
    import db_pack_item as _PI
    out = []
    for x in _CK.extras(conn):
        r = conn.execute(
            "SELECT COALESCE(version,0) FROM sys_pack_item"
            " WHERE kind=? AND key=? AND lang=? AND variant=?",
            (x['kind'], x['key'], x['lang'], x['variant'])).fetchone()
        ver = int(r[0]) if r else 0
        if not ver:
            try:
                ver = _PI.bump(conn, x['kind'], x['key'], x['lang'],
                               x['variant'], note='코어팩에 맛보기로 실림')
            except Exception:                                # noqa: BLE001
                ver = 0
        out.append({'kind': x['kind'], 'key': x['key'], 'lang': x['lang'],
                    'variant': x['variant'], 'version': ver})
    return out


def build(conn, out_dir=None, name=None, cycle=None):
    """코어팩을 만든다 → `{'file','bytes','tables','rows','sha1','version'}`.

    ⚠ **gzip 으로 쓴다** — 원본 14.7MB 가 압축하면 3~4MB 다. 사용자가 앱을
      켤 때마다 받는 것이 아니라 판이 오를 때만 받지만, 첫 설치에는 늘 든다.
    ★★ `cycle` 을 주면 **그 주기의 표만** 담고 이름도 그 주기의 것이 된다
      (2026-09-05 릴리스 패킹). 합치지 않는 이유 = 합치면 매일 받는 사람이
      **연 2회 것을 매일 다시** 받는다.
    """
    out_dir = out_dir or DIST
    os.makedirs(out_dir, exist_ok=True)
    # ★★ **코어가 릴리스의 기준이다** — 본문팩은 이 숫자를 넘을 수 없다
    rel = 0
    try:
        import db_pack_release as RL
        rel = RL.item_release(conn, 'CORE')
    except Exception:
        rel = 0
    body = {'format': FORMAT, 'release': rel,
            'made_at': time.strftime('%Y-%m-%d %H:%M'),
            'tables': {}}
    if cycle:
        body['cycle'] = str(cycle).upper()
    n_rows = 0
    skipped = []
    for t, cond in core_tables(conn, cycle):
        d = dump_table(conn, t, cond)
        if d is None:
            # ⚠ **조용히 빠뜨리지 않는다** — 무엇이 안 담겼는지 남긴다
            skipped.append(t)
            continue
        body['tables'][t] = d
        n_rows += len(d['rows'])
    body['skipped'] = skipped
    # ★★ **뺀 것을 적어 보낸다**(2026-09-24) — 받는 쪽이 「원래 없는 것」과
    #   「이번에 안 보낸 것」을 가를 수 있어야 한다(§0-1).
    #   ⚠ 뺀 표는 `_wipe_scope` 가 **비우지도 않는다**(body 에 없으므로) —
    #     사용자가 이미 가진 것을 지우지 않는다. 그것이 옳다.
    excluded, bundled = [], []
    try:
        import db_pack_core_pick as _CK
        excluded = sorted(_CK.excluded(conn))
        # ★★★ **맛보기 자산을 함께 싣는다**(사용자 「코어팩에 필수적으로
        #   추가하는 텍스트 자산 … 관리자가 매년 수정」). 본문팩과 **같은
        #   조회**를 쓰므로(`db_pack_body.parts_for`) 담기는 것이 갈리지 않고,
        #   형식도 같아서 **받는 쪽 적재기를 한 줄도 안 고친다**.
        #   ⚠ 이 표들은 코어 표가 아니라 `_wipe_scope` 가 안 건드린다 —
        #     맛보기는 **더하기만** 한다(남의 본문을 지우지 않는다).
        # ★★★ **맛보기는 규칙이 만든다**(2026-09-25 사용자 「관리자가
        #   설정하는 방식을 포기 … 정형화」) — `db_pack_taste` 가 구간·상한을
        #   정하고 여기서는 받아 담기만 한다. **BSB 전권도 그 문이 낸다**
        #   (사용자 「BSB 성경버전을 코어팩에 필수로 추가 … 코어에 포함」).
        #   ⚠ 옛 `_CK.extra_tables`(자산 하나를 통째로)는 안 쓴다.
        import db_pack_taste as _TA
        for tb, d2 in (_TA.taste_tables(conn) or {}).items():
            if tb in body['tables'] and body['tables'][tb]['cols'] == d2['cols']:
                body['tables'][tb]['rows'].extend(d2['rows'])
            else:
                body['tables'][tb] = d2
            n_rows += len(d2['rows'])
        # ★★★ **판을 함께 적는다**(2026-09-24 286차 — 사용자 물음
        #   「코어팩에 이미 개별자산 팩이 포함되어 있으므로 사용자 화면에
        #    이미 다운로드했다고 표시되는가?」).
        #   실측 답 = **「받음」으로는 보였는데 판을 몰랐다.** 받는 쪽은 본문
        #   행을 세어 상태를 정하므로(`pack_fallback.state`) 설치됨으로는
        #   떴지만 `sys_pack_applied` 에 줄이 없어 **`mine` 이 비고**, 그래서
        #   나중에 그 자산의 새 판이 나와도 **영영 「최신」**이라 적혔다.
        #   ⇒ 판을 실어 보내고 받는 쪽이 `sys_pack_applied` 에 적는다.
        #   ⚠ 판이 0 이면 **한 번만 1 로 올린다** — 「이 내용으로 내보냈다」는
        #     사실에 번호가 있어야 다음 판과 견줄 수 있다. 이미 판이 있으면
        #     **안 올린다**(코어를 다시 만들 때마다 오르면 사용자 화면이
        #     까닭 없이 「받을 것이 있다」로 깜박인다).
        bundled = bundled_of(conn)
    except Exception as _e:                                  # noqa: BLE001
        # ⚠ **조용히 넘어가지 않는다** — 고른 것이 안 실렸으면 그 사실이 보여야
        #   한다(관리자는 실렸다고 믿고 배포한다).
        print('  ⚠ 코어 선택을 못 읽었다(전부 담고 맛보기는 뺀다): %s'
              % str(_e)[:70])
    body['excluded'] = excluded
    body['bundled'] = bundled
    # ⚠⚠ **빈 팩을 만들지 않는다** — 받았는데 아무것도 안 생기는 가장 나쁜
    #   실패다(§db_pack_body). 주기에 배정된 표가 없으면 거부한다.
    if not body['tables']:
        raise ValueError('담을 표가 없다: cycle=%s' % (cycle or '(전체)'))
    path = os.path.join(out_dir, name or core_name(cycle))
    raw = json.dumps(body, ensure_ascii=False).encode('utf-8')
    import secret_store as _SS          # ★ 2026-10-11 — 열쇠가 섞였으면 내보내지 않는다(③)
    _SS.assert_clean(raw, os.path.basename(path))
    with gzip.open(path, 'wb', compresslevel=6) as f:
        f.write(raw)
    sha = hashlib.sha1(raw).hexdigest()
    # ★★★ **도장** — 「이 상태로 팩을 만들었다」를 남긴다(2026-09-18).
    #   ⚠ 반드시 **만든 뒤**다. 앞에서 찍으면 그 사이 변경을 영영 못 본다.
    #   ⚠ 실패해도 팩 만들기를 죽이지 않는다 — 다만 조용히 넘기지 않는다.
    try:
        import db_pack_fresh as _FR
        _FR.stamp(conn)
    except Exception as _e:                                   # noqa: BLE001
        print('  ⚠ 팩 도장을 못 찍었다(다음 배포에서 「낡음」으로 뜬다): %s'
              % str(_e)[:60])

    return {'file': path, 'bytes': os.path.getsize(path), 'raw': len(raw),
            'tables': len(body['tables']), 'rows': n_rows, 'sha1': sha,
            'content_sha1': content_sha1(body),
            'cycle': body.get('cycle'), 'release': rel, 'skipped': skipped,
            'excluded': body.get('excluded') or [],
            'bundled': body.get('bundled') or []}


def content_sha1(body):
    """**담긴 것만**의 해시 — 만든 시각을 뺀다.

    ⚠⚠ `sha1` 은 파일 해시라 **다시 만들 때마다 바뀐다**(`made_at` 에 분까지
      들어간다). 그것으로 「내용이 그대로인가」를 판정하면 **판이 오를 때마다
      주기 파일 셋이 전부 다시 올라간다** — gzip 은 git 히스토리에 그대로
      쌓이므로(§팩 작업 규칙 ①) 저장소가 배로 는다. 실측으로 잡았다.
    ⚠ `release` 도 뺀다 — 판이 올랐다고 담긴 것이 바뀐 것은 아니다.
    """
    d = {k: v for k, v in (body or {}).items()
         if k not in ('made_at', 'release')}
    return hashlib.sha1(
        json.dumps(d, ensure_ascii=False, sort_keys=True).encode('utf-8')
    ).hexdigest()


def read(path):
    """만든 코어팩을 읽는다(검증·적재 공용)."""
    with gzip.open(path, 'rb') as f:
        return json.loads(f.read().decode('utf-8'))


def verify(conn, path):
    """만든 것이 DB 와 맞는가 → `[문제…]`. 빈 목록이면 온전하다.

    ★ **행수를 표마다 다시 센다** — 만들 때와 잴 때가 같은 코드를 쓰면 시험이
      헛돈다. 여기서는 **DB 를 직접 세어** 견준다.
    """
    bad = []
    try:
        body = read(path)
    except Exception as e:
        return ['팩을 읽을 수 없다: %s' % e]
    if int(body.get('format') or 0) != FORMAT:
        bad.append('형식 판이 다르다: %s' % body.get('format'))
    # ★★ **팩이 자기 주기를 말한다** — 그 주기의 표만 들어 있어야 한다.
    #   ⚠ 주기별 팩을 전체 목록과 견주면 「빠진 표」가 수십 개로 나온다
    #     (실측으로 잡을 자리다). 팩이 적어 둔 주기로 기대값을 좁힌다.
    want = dict(core_tables(conn, body.get('cycle')))
    got = body.get('tables') or {}
    for t in want:
        if t not in got and t not in (body.get('skipped') or []):
            bad.append('빠진 표: %s' % t)
    for t in got:
        if t not in want:
            bad.append('담기면 안 되는 표: %s' % t)
    for t, d in got.items():
        cond = want.get(t)
        q = "SELECT COUNT(*) FROM %s" % t
        if cond:
            q += ' WHERE ' + cond
        try:
            n = conn.execute(q).fetchone()[0]
        except Exception:
            continue
        if n != len(d.get('rows') or []):
            bad.append('행수가 다르다 %s: 팩 %d ≠ DB %d'
                       % (t, len(d.get('rows') or []), n))
    return bad


def size_report(conn):
    """어느 표가 얼마를 차지하나 → `(합계, [(표, 바이트)])`."""
    # ⚠ 만들기 전에는 **기억을 버리고 다시 센다** — 화면이 쓰는 60초
    #   기억을 그대로 믿으면 세는 쪽과 담는 쪽이 갈린다(286차).
    return PC.core_bytes(conn, fresh=True)


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _ck_no_desc(conn, ck):
    """★ **팩에 유튜브 설명문이 안 실린다** — 양방향으로 잠근다.

    ⚠ DB 에는 설명문이 **있어야** 한다(판정 재료). 팩에만 없어야 한다.
    """
    d = dump_table(conn, 'sys_media_asset',
                   PC.RULE_ONLY.get('sys_media_asset', (None,))[0])
    if not d or not d['rows']:
        ck(False, '영상 목록을 못 담았다')
        return
    i = d['cols'].index('description') if 'description' in d['cols'] else -1
    ck(i >= 0, '설명문 칸 자체는 남아 있다(받는 쪽 스키마)')
    if i >= 0:
        bad = sum(1 for r in d['rows'] if (r[i] or '') != '')
        ck(bad == 0, '★ 팩에 설명문이 안 실린다 (%d행에 남아 있다)' % bad)
    n_db = conn.execute(
        "SELECT COUNT(*) FROM sys_media_asset "
        "WHERE TRIM(COALESCE(description,''))<>''").fetchone()[0]
    ck(n_db > 0, 'DB 에는 설명문이 그대로 있다(판정 재료)')


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import tempfile
    d = tempfile.mkdtemp()
    _later = []

    # ── 작은 가짜 DB 로 왕복 ─────────────────────────────────────────────
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER);
      -- ⚠ **`record_status` 를 빠뜨리지 않는다** — `RULE_ONLY` 의 승인 조건이
      --   그 칸을 본다(§220차 후보(PEND) 링크). 없으면 조건이 터져 이 표가
      --   **팩에서 통째로 빠진다**(2026-09-10 selftest 가 그 자리에서 잡았다).
      CREATE TABLE sys_link_asset(sys_link_id INTEGER, link_type TEXT,
                                  clicked_id INTEGER, target_id INTEGER,
                                  record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_ref_verse_map(map_id INTEGER, map_status TEXT,
                                     is_alive INTEGER);
      -- ⚠ **승인 조건이 이 표를 참조한다**(`db_pack_catalog.RULE_ONLY`) —
      --   없으면 조회가 터져 `sys_link_asset` 이 통째로 빠진다(실측).
      -- ⚠ `description` 을 **일부러 넣는다** — 팩에서 비워지는지 재려면
      --   DB 에는 있어야 한다(저작권 규칙의 양방향 검사).
      CREATE TABLE sys_media_asset(media_id INTEGER, url TEXT,
                                   is_active INTEGER, record_status TEXT,
                                   description TEXT);
      CREATE TABLE bible_content(verse_id INTEGER, verse_text TEXT);
      INSERT INTO bible_index VALUES(1,1),(2,1);
      INSERT INTO sys_link_asset VALUES(1,'ENTI_VERS',9,1,'LIVE');
      -- ★ 영상 연결을 **일부러 넣는다** — 코어에서 빠지는지 재려면 있어야 한다
      INSERT INTO sys_link_asset VALUES(2,'MEDI_VERS',9,1,'LIVE');
      INSERT INTO sys_media_asset VALUES(9,'u1',1,'LIVE','남이 올린 설명문입니다'),(8,'u2',0,'LIVE','이것도 남의 글');
      INSERT INTO sys_ref_verse_map VALUES(1,'AUTO',1),(2,'MANUAL',1),(3,'AUTO',0);
      INSERT INTO bible_content VALUES(1,'태초에');
    """)
    c.commit()
    r = build(c, d, 'test_core.json.gz')
    body = read(r['file'])
    t('팩이 만들어진다', os.path.exists(r['file']) and r['bytes'] > 0,
      '%d bytes' % r['bytes'])
    t('★ 담을 표는 카탈로그가 정한다',
      'sys_link_asset' in body['tables'] and 'bible_index' in body['tables'])
    t('★★ **본문은 안 담긴다**', 'bible_content' not in body['tables'])
    # ★★★ 2026-09-29 293차 — **영상 주소는 코어에 안 담긴다**(영상 연결 팩이
    #   나른다). 옛 검사 「팩에 유튜브 설명문이 안 실린다」는 그 표가 코어에
    #   없으므로 뜻을 잃었다 — 설명문을 비우는 일은 `db_linkpack_build.snapshot`
    #   selftest 가 잰다.
    t('★★★ **영상 주소는 코어에 안 담긴다**(영상 연결 팩)',
      'sys_media_asset' not in body['tables'])
    _lk = body['tables'].get('sys_link_asset') or {}
    _li = (_lk.get('cols') or []).index('link_type')
    _types = {r[_li] for r in (_lk.get('rows') or [])}
    t('★★★ **영상 연결(MEDI_*)은 코어에 안 담긴다**',
      'ENTI_VERS' in _types and not [x for x in _types if x.startswith('MEDI')],
      str(sorted(_types)))
    t('  DB 에는 영상 연결이 그대로 있다(팩에만 없다)',
      c.execute("SELECT COUNT(*) FROM sys_link_asset"
                " WHERE link_type LIKE 'MEDI%'").fetchone()[0] == 1)
    # ★★★ **심사용 칸은 하나도 안 실린다** — 실 DB 로 전수(2026-09-23 사용자
    #   「기사본문 등은 모두 심사용이다 … 절대로 포함하면 안된다」).
    try:
        _rc = appdb.connect()
        _bad = []
        for _tb, _cs in PC.DROP_COLS.items():
            _d = dump_table(_rc, _tb, PC.RULE_ONLY.get(_tb, (None,))[0])
            if not _d:
                continue
            for _col in _cs:
                if _col not in _d['cols']:
                    _bad.append('%s.%s 칸이 사라졌다' % (_tb, _col))
                    continue
                _ix = _d['cols'].index(_col)
                _nn = sum(1 for r in _d['rows'] if (r[_ix] or '') != '')
                if _nn:
                    _bad.append('%s.%s 에 %d행' % (_tb, _col, _nn))
        _rc.close()
        t('★★★ **심사용 칸이 팩에 하나도 안 실린다**(실 DB 전수)',
          not _bad, ' / '.join(_bad[:3]))
    except Exception as _e:                               # noqa: BLE001
        t('심사용 칸 전수 검사가 돌았다', False, str(_e)[:60])
    t('  칸 이름을 함께 담는다',
      body['tables']['sys_link_asset']['cols'][:2] == ['sys_link_id', 'link_type'])
    t('★★★ **규칙으로 만들 수 있는 것은 예외만**',
      len(body['tables']['sys_ref_verse_map']['rows']) == 2,
      '3행 중 %d행(AUTO+살아있음 1행 제외)'
      % len(body['tables']['sys_ref_verse_map']['rows']))
    t('형식 판이 담긴다', body.get('format') == FORMAT)
    # ★★ **바이너리 왕복** — 실 DB 의 `sys_menu_config` 가 BLOB 을 갖고 있어
    #   첫 빌드가 「Object of type bytes is not JSON serializable」로 죽었다.
    # ⚠ `style` 칸이 있어야 한다 — `RULE_ONLY` 조건이 그것을 본다. 없으면
    #   조건이 터지고, 이제 그것은 **오류로 알린다**(아래 탐지력 항목).
    # ⚠ 2026-10-11 — 조건이 `basic`·`photo_pack` 을 본다(사진팩) · 기본 사진 1 · 팩 없음이라야 담긴다
    c.execute("CREATE TABLE sys_splash_image(id INTEGER, blob_data BLOB,"
              " scene TEXT, basic INTEGER DEFAULT 1, photo_pack INTEGER)")
    c.execute("INSERT INTO sys_splash_image(id, blob_data, scene) VALUES(1, ?, NULL)",
              (b'\x89PNG\x00\xff',))
    c.commit()
    r_b = build(c, d, 'test_blob.json.gz')
    bb = read(r_b['file'])['tables']['sys_splash_image']['rows'][0][1]
    t('★★ **바이너리도 담기고 되돌아온다**', dec(bb) == b'\x89PNG\x00\xff',
      str(bb)[:40])
    # ★★★ **조건이 터진 표를 조용히 빠뜨리지 않는다**(2026-09-05 실측으로 잡음)
    c.execute("CREATE TABLE _t_nostyle(id INTEGER)")
    boom = False
    try:
        dump_table(c, '_t_nostyle', "COALESCE(style,'')=''")
    except ValueError:
        boom = True
    t('★★★ **조건이 터진 표를 조용히 빠뜨리지 않는다**(팩이 조용히 빈다)', boom)
    t('  표가 아예 없으면 지금까지와 같다(None)',
      dump_table(c, '_nope') is None)
    os.remove(r_b['file'])
    bad = verify(c, r['file'])
    t('★ 검증이 통과한다', not bad, str(bad[:3]))

    # 깨뜨리면 잡는가 — 탐지력
    c.execute("INSERT INTO sys_link_asset VALUES(2,'X',1,1,'LIVE')")
    c.commit()
    bad2 = verify(c, r['file'])
    t('★★ **DB 가 바뀌면 검증이 잡는다**',
      any('sys_link_asset' in x for x in bad2), str(bad2[:2]))
    c.close()

    # 없는 표가 있어도 죽지 않는다
    c2 = sqlite3.connect(':memory:')
    c2.execute("CREATE TABLE bible_index(verse_id INTEGER)")
    c2.commit()
    r2 = build(c2, d, 'test_core2.json.gz')
    t('★ 표가 없어도 안 죽는다(빠진 것을 적는다)',
      r2['tables'] >= 1 and len(r2['skipped']) > 10,
      '담김 %d · 빠짐 %d' % (r2['tables'], len(r2['skipped'])))
    c2.close()

    # ── 주기별 파일(2026-09-05 릴리스 패킹) ────────────────────────
    import db_pack_stat as _ST
    c = sqlite3.connect(':memory:')          # ⚠ 앞의 것은 이미 닫혔다
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER);
      -- ⚠ **`record_status` 를 빠뜨리지 않는다** — `RULE_ONLY` 의 승인 조건이
      --   그 칸을 본다(§220차 후보(PEND) 링크). 없으면 조건이 터져 이 표가
      --   **팩에서 통째로 빠진다**(2026-09-10 selftest 가 그 자리에서 잡았다).
      CREATE TABLE sys_link_asset(sys_link_id INTEGER, link_type TEXT,
                                  clicked_id INTEGER, target_id INTEGER,
                                  record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_media_asset(media_id INTEGER, url TEXT,
                                   is_active INTEGER, record_status TEXT);
      CREATE TABLE bible_content(verse_id INTEGER, verse_text TEXT);
      INSERT INTO bible_index VALUES(1,1);
      INSERT INTO sys_media_asset VALUES(9,'u1',1,'LIVE');
      INSERT INTO sys_link_asset VALUES(1,'ENTI_VERS',9,1,'LIVE');
      INSERT INTO bible_content VALUES(1,'태초에');
    """)
    c.commit()
    _ST.ensure(c)
    _ST.set_cycle(c, 'T:sys_link_asset', 'DAILY', '')
    _ST.set_cycle(c, 'T:bible_index', 'BIANNUAL', '')
    _ST.set_cycle(c, 'T:bible_content', 'BIANNUAL', '')
    t('★★ **이름을 짓는 단일 문**',
      core_name('DAILY') == 'corepack_DAILY.json.gz'
      and core_name() == CORE_NAME, core_name('DAILY'))
    d_all = dict(core_tables())
    d_day = dict(core_tables(c, 'DAILY'))
    d_bi = dict(core_tables(c, 'BIANNUAL'))
    t('★★★ **주기가 표를 가른다**',
      'sys_link_asset' in d_day and 'sys_link_asset' not in d_bi,
      '매일 %d표 · 연2회 %d표' % (len(d_day), len(d_bi)))
    t('★★★ **잃는 표가 없다**(주기들의 합 = 전체)',
      set().union(*[set(dict(core_tables(c, x)))
                    for x in ('DAILY', 'WEEKLY', 'BIANNUAL')]) == set(d_all),
      '%d개' % len(d_all))
    t('★★ **인자를 안 주면 지금까지와 똑같다**(호출부 무수정)',
      len(d_all) == len([1 for _t, (_l, _k, _dd) in PC.TABLES.items()
                         if _l == PC.CORE]))
    rc = build(c, d, cycle='DAILY')
    bc = read(rc['file'])
    t('★★ **팩이 자기 주기를 적는다**', bc.get('cycle') == 'DAILY',
      str(bc.get('cycle')))
    t('  그 주기의 표만 들어 있다',
      set(bc.get('tables') or {}) <= set(d_day))
    t('★★★ **주기별 팩도 검증이 통과한다**(전체 목록과 견주면 안 된다)',
      verify(c, rc['file']) == [], str(verify(c, rc['file'])[:1]))
    empty = False
    try:
        build(c, d, cycle='WEEKLY')
    except ValueError:
        empty = True
    t('★★★ **빈 팩을 만들지 않는다**(받았는데 아무것도 안 생기는 실패)', empty)
    t('★★ **담을 것이 있는 주기만 낸다**(적재 순서로)',
      core_cycles(c) == ['BIANNUAL', 'DAILY'], str(core_cycles(c)))
    c.close()

    for f in ('test_core.json.gz', 'test_core2.json.gz'):
        p = os.path.join(d, f)
        if os.path.exists(p):
            os.remove(p)
    try:
        os.rmdir(d)
    except Exception:
        pass

    # ── 실 DB — 읽기만 한다 ──────────────────────────────────────────────
    c3 = appdb.connect(DB)
    try:
        tabs = core_tables()
        t('★ 코어 표가 카탈로그와 같다',
          len(tabs) == len([1 for v in PC.TABLES.values() if v[0] == PC.CORE]),
          '%d개' % len(tabs))

        # ── 관리자 선택이 **실제로 팩을 바꾸는가**(282차 ②) ────────────
        #   ⚠ 실 DB 에 자국을 남기지 않는다 — 메모리 DB 에 선택 표만 세운다.
        import sqlite3 as _sq
        _pk = _sq.connect(':memory:')
        import db_pack_core_pick as _CK
        _CK.init(_pk)
        # ★★★ **이제 뺄 수 있는 표가 없다**(2026-09-25 사용자 확정) —
        #   옛 검사는 「관리자가 뺀 표가 안 담긴다」였다. 지금은 **아무것도
        #   못 뺀다**는 것을 재야 한다(§238차 재는 쪽이 옛 모델).
        t('  이제 뺄 수 있는 표가 없다', not PC.CORE_OPTIONAL)
        _bad = False
        try:
            _CK.set_table(_pk, 'sys_media_asset', False)
        except ValueError:
            _bad = True
        t('★★★ 어떤 표도 빼려 하면 **거부한다**', _bad)
        _got = [x for x, _c in core_tables(_pk)]
        t('★★ 코어 표가 그대로 다 담긴다',
          len(_got) == len(tabs) and 'bible_index' in _got
          and 'sys_link_asset' in _got, '%d개' % len(_got))
        t('  거부한 뒤에도 자국이 없다', not _CK.excluded(_pk))
        _pk.close()
        tot, _rows = size_report(c3)
        t('  코어 크기가 재어진다', tot > 0, '%.1f MB' % (tot / 1048576))
        # ⚠ **실 팩 파일을 안 건드린다**(§193차 사고) — 이름을 갈아 끼운다
        had = os.path.exists(os.path.join(DIST, CORE_NAME))
        t('★ 시험이 실 코어팩을 안 만진다', True,
          '실 파일 %s' % ('있음' if had else '없음'))
    finally:
        c3.close()
    # ── 맛보기에 판이 붙는가 (286차 · 1.txt 12-1) ────────────────────
    #   ⚠ **실 DB 를 안 건드린다** — 흉내 표를 만들어 잰다.
    import sqlite3 as _sq4
    mc = _sq4.connect(':memory:')
    mc.executescript(
        "CREATE TABLE sys_pack_core_extra(kind TEXT, key TEXT, lang TEXT,"
        " variant TEXT, note TEXT, sort_order INTEGER DEFAULT 0,"
        " updated_at TEXT, PRIMARY KEY(kind,key,lang,variant));"
        "CREATE TABLE sys_pack_core_pick(table_name TEXT PRIMARY KEY,"
        " included INTEGER, updated_at TEXT);"
        "CREATE TABLE sys_pack_item(item_id INTEGER PRIMARY KEY, kind TEXT,"
        " key TEXT, lang TEXT, variant TEXT, title TEXT,"
        " version INTEGER DEFAULT 0, made_at TEXT, n_items INTEGER,"
        " n_bytes INTEGER, sha1 TEXT, file_name TEXT, note TEXT,"
        " record_status TEXT DEFAULT 'LIVE');")
    mc.execute("INSERT INTO sys_pack_core_extra(kind,key,lang,variant)"
               " VALUES('COMM','JFB','EN','-')")
    mc.execute("INSERT INTO sys_pack_core_extra(kind,key,lang,variant)"
               " VALUES('BOOK','NEW','KO','ORIGINAL')")
    mc.execute("INSERT INTO sys_pack_item(kind,key,lang,variant,version)"
               " VALUES('COMM','JFB','EN','-',4)")
    mc.commit()
    b = {(x['kind'], x['key']): x['version'] for x in bundled_of(mc)}
    t('★★★ 맛보기에 **판이 붙는다**', b.get(('COMM', 'JFB')) == 4, str(b))
    t('★★ 판이 없던 자산은 **1 로 올린다**(번호가 있어야 견준다)',
      b.get(('BOOK', 'NEW')) == 1, str(b))
    b2 = {(x['kind'], x['key']): x['version'] for x in bundled_of(mc)}
    t('★★ 다시 만들어도 **판이 안 오른다**(까닭 없이 깜박이지 않는다)',
      b2 == b, str(b2))
    mc.close()

    print('db_pack_core selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--build', action='store_true')
    ap.add_argument('--verify', action='store_true')
    ap.add_argument('--size', action='store_true')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.size:
            tot, rows = size_report(c)
            print('코어팩 크기 %.1f MB (원본 글자)' % (tot / 1048576))
            for t_, b in rows[:12]:
                print('   %-30s %6.2f MB' % (t_, b / 1048576))
        if a.build:
            r = build(c)
            print('만듦: %s' % r['file'])
            print('  표 %d개 · %s행 · 원본 %.1f MB → gzip %.1f MB'
                  % (r['tables'], f"{r['rows']:,}", r['raw'] / 1048576,
                     r['bytes'] / 1048576))
            if r['skipped']:
                print('  ⚠ 안 담긴 표 %d개: %s'
                      % (len(r['skipped']), r['skipped'][:6]))
        if a.verify:
            p = os.path.join(DIST, CORE_NAME)
            bad = verify(c, p)
            print('검증: %s' % ('문제 없음' if not bad else '문제 %d건' % len(bad)))
            for x in bad[:10]:
                print('   %s' % x)
    finally:
        c.close()


if __name__ == '__main__':
    main()
