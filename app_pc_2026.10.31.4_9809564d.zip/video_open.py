# -*- coding: utf-8 -*-
"""video_open.py — 「영상을 어떻게 여나」 단일 소스 (2026-09-17 신설·영구).

사용자 지시(2026-09-17): 「1)임베드 재생(제목/설명문 안보임) 2)스크롤 재생(찬양수집기
심사탭 처럼 스크롤하면 설명문 댓글까지 볼 수 있도록 좌우 폭만 맞추어주는 방법)
3)브라우저로 실행 … 사용자가 설정값을 한번 저장하면 매번 그대로 적용하면 될 것 같다」.

★★★ **갈래 셋이 하는 일이 다르다**
    EMBED   `player.play(id)`        유튜브 임베드 재생기만. 제목·설명문 없음(지금까지의 동작)
    PAGE    `player.open_url(watch)` **유튜브 쪽 그대로** — 제목·좋아요·설명문·댓글까지 굴려 본다
    BROWSER `webbrowser.open(url)`   바깥 브라우저

★★★ **PAGE 는 우리가 담은 설명문을 꺼내는 것이 아니다.** 유튜브가 제 서버에서 그린 쪽을
  그대로 보인다 — 저장도 재배포도 아니다. 관리자 찬양수집기가 쓰던 바로 그 문이다.
  ⚠⚠⚠ **수집한 `yt_desc` 를 사용자 화면에 그리지 말 것**(2026-09-17 사용자 반려 —
    「유투브에서 수집한 설명문 자료는 **관리자 전용**으로 이용한다고 했다. 수집해서 우리
    앱에서 표시하는 것은 **저작권 문제**가 있을 것이다」). 그 글은 올린 사람의 것이고
    우리가 담아 둔 것은 **판정 재료**(거르기·용어 연결)다.
  ⚠ **남의 쪽을 고치지 않는다** — 댓글을 CSS 로 지우거나 잘라 내지 않는다. 실측 댓글은
    맨 위에서 658 CSS px 아래라 **안 내리면 안 보인다**. 그것으로 충분하다.

★ **설정은 하나다** — `user_config['VIDEO_OPEN_MODE']`. 화면마다 따로 기억하지 않는다
  (사용자 「한번 저장하면 매번 그대로」). 옛 열쇠 `LP_OPEN_MODE`(TAB/YT)를 읽어 옮긴다.
"""

import sqlite3
import sys
import webbrowser

#: (코드, i18n 열쇠, 한국어 폴백) — **이 표가 단일 소스다.** 갈래를 늘리면 여기만 고친다.
#: ⚠ 이름은 「무엇이 보이나」로 짓는다 — 「임베드·스크롤」은 만든 사람의 말이다(§237차 ⑱).
MODES = (
    ('EMBED',   'VO_EMBED',   '영상만'),
    ('PAGE',    'VO_PAGE',    '영상+설명'),
    ('BROWSER', 'VO_BROWSER', '브라우저'),
)
CODES = tuple(c for c, _k, _ko in MODES)
DEFAULT = 'EMBED'
KEY = 'VIDEO_OPEN_MODE'
OLD_KEY = 'LP_OPEN_MODE'            # 옛 두 갈래 — TAB → EMBED · YT → BROWSER
_OLD = {'TAB': 'EMBED', 'YT': 'BROWSER'}
WATCH = 'https://www.youtube.com/watch?v=%s'


def watch_url(vid):
    """영상 id → 유튜브 쪽 주소."""
    return WATCH % vid


def label(code, ko_only=False):
    """갈래 이름 — 화면이 글자를 적지 않는다."""
    for c, key, ko in MODES:
        if c == code:
            if ko_only:
                return ko
            try:
                import i18n
                return i18n.t(key, ko)
            except Exception:
                return ko
    return code


def labels(ko_only=False):
    return [label(c, ko_only) for c in CODES]


def code_of(text, ko_only=False):
    """콤보 글자 → 코드. 못 찾으면 기본값(조용히 딴 갈래로 가지 않는다)."""
    for c in CODES:
        if label(c, ko_only) == text:
            return c
    return DEFAULT


def _conn(db_path):
    import appdb
    return appdb.connect(db_path) if db_path else appdb.connect()


def get_mode(db_path=None, conn=None):
    """저장된 갈래. 없으면 옛 열쇠를 옮겨 읽고, 그것도 없으면 기본값."""
    c = conn
    close = False
    try:
        if c is None:
            c = _conn(db_path)
            close = True
        r = c.execute("SELECT config_val FROM userdb.user_config"
                      " WHERE config_key=?", (KEY,)).fetchone()
        if r and r[0] in CODES:
            return r[0]
        r = c.execute("SELECT config_val FROM userdb.user_config"
                      " WHERE config_key=?", (OLD_KEY,)).fetchone()
        if r and r[0] in _OLD:
            return _OLD[r[0]]
    except Exception:
        pass
    finally:
        if close and c is not None:
            try:
                c.close()
            except Exception:
                pass
    return DEFAULT


def set_mode(code, db_path=None, conn=None):
    """갈래를 저장한다 → 실제로 저장된 코드."""
    if code not in CODES:
        code = DEFAULT
    c = conn
    close = False
    try:
        if c is None:
            c = _conn(db_path)
            close = True
        c.execute("INSERT INTO userdb.user_config(config_key, config_val)"
                  " VALUES(?,?) ON CONFLICT(config_key) DO UPDATE SET config_val=?",
                  (KEY, code, code))
        c.commit()
    except Exception:
        pass
    finally:
        if close and c is not None:
            try:
                c.close()
            except Exception:
                pass
    return code


#: ★★★ **임베드가 막혔을 때 대신 여는 갈래**(2026-09-24 1.txt 14번).
#: 「영상+설명」은 **임베드가 아니라 유튜브 watch 쪽**이라 크리에이터의 임베드
#: 차단과 무관하다. 앱 안에 머물러 창이 튀어나가지 않으므로 먼저 고른다.
#: ⚠ 그래도 안 되면(연령 제한·로그인 필요) 사람이 [브라우저에서 열기]를 누른다.
BLOCKED_FALLBACK = 'PAGE'

#: 그 자리에서 배운 것을 담는 **개인 표** — 사용자 앱은 배포 DB 에 못 쓴다(§C-2).
USER_TBL = 'user_media_block'
_USER_DDL = (
    "CREATE TABLE IF NOT EXISTS userdb.%s ("
    " yt_id TEXT PRIMARY KEY, at TEXT, why TEXT)" % USER_TBL)

_BLOCK_CACHE = {'set': None}


def _init_user(conn):
    conn.execute(_USER_DDL)
    return True


def blocked_ids(db_path=None, conn=None, fresh=False):
    """임베드가 막힌 것으로 **아는** 유튜브 id → `set`.

    ★ 배포된 사실(`sys_media_asset.embed_ok=0`) + 그 자리에서 배운 것(개인 표).
    ⚠ 한 번 읽어 캐시한다 — 영상을 누를 때마다 273행을 다시 읽을 까닭이 없다.
      `mark_blocked` 가 캐시를 함께 갱신하므로 갈리지 않는다.
    ⚠ 표·칸이 없어도 죽지 않는다(옛 DB · 시험 DB) — 그때는 빈 집합이다.
    """
    if not fresh and _BLOCK_CACHE['set'] is not None:
        return _BLOCK_CACHE['set']
    out = set()
    c, own = (conn, False) if conn is not None else (_conn(db_path), True)
    try:
        for who, q in (
                ('sys', "SELECT url FROM sys_media_asset WHERE embed_ok=0"),
                ('usr', "SELECT yt_id FROM userdb.%s" % USER_TBL)):
            try:
                for (v,) in c.execute(q):
                    x = _vid_of(v) if who == 'sys' else (v or '')
                    if x:
                        out.add(x)
            except Exception:                                # noqa: BLE001
                pass
    finally:
        if own:
            try:
                c.close()
            except Exception:                                # noqa: BLE001
                pass
    _BLOCK_CACHE['set'] = out
    return out


def is_blocked(vid, db_path=None, conn=None):
    return bool(vid) and vid in blocked_ids(db_path, conn)


def mark_blocked(vid, why='onError', db_path=None, conn=None):
    """**그 자리에서 배운 것을 적는다** → 적었나.

    ⚠⚠ 배포 DB(`sys_media_asset`)를 **안 건드린다** — 사용자 동작이 배포용
      자료를 고치면 안 된다(§C-2). 개인 표에만 적고, 관리자 쪽 사실은
      링크 점검이 따로 채운다.
    """
    if not vid:
        return False
    c, own = (conn, False) if conn is not None else (_conn(db_path), True)
    try:
        _init_user(c)
        c.execute("INSERT OR REPLACE INTO userdb.%s (yt_id, at, why)"
                  " VALUES (?, datetime('now'), ?)" % USER_TBL,
                  (vid, (why or '')[:60]))
        c.commit()
    except Exception:                                        # noqa: BLE001
        return False
    finally:
        if own:
            try:
                c.close()
            except Exception:                                # noqa: BLE001
                pass
    if _BLOCK_CACHE['set'] is not None:
        _BLOCK_CACHE['set'].add(vid)
    return True


def mode_for(vid, mode=None, db_path=None, conn=None):
    """그 영상을 **실제로 열 갈래** → `(갈래, 바꿨나)`.

    ★ 사용자가 고른 갈래를 바꾸지 않는다 — **그 영상 하나에만** 다른 길을 쓴다.
    ⚠ 브라우저 갈래는 그대로다(이미 임베드가 아니다).
    """
    m = mode or get_mode(db_path)
    if m == 'EMBED' and is_blocked(vid, db_path, conn):
        return BLOCKED_FALLBACK, True
    return m, False


def on_blocked(player, vid, db_path=None):
    """재생기가 **그 자리에서** 임베드 차단을 만났을 때 → 실제로 쓴 갈래.

    ⚠ 배운 것을 먼저 적고 나서 연다 — 적기 전에 화면이 바뀌면 다음번에 또 막힌다.
    ⚠ 브라우저 갈래에서는 애초에 임베드를 안 쓰므로 여기 올 일이 없다.
    """
    mark_blocked(vid, 'player onError', db_path)
    if BLOCKED_FALLBACK == 'PAGE' and player is not None:
        try:
            player.open_url(watch_url(vid))
            return 'PAGE'
        except Exception:                                    # noqa: BLE001
            pass
    webbrowser.open(watch_url(vid))
    return 'BROWSER'


def open_video(player, vid, url='', mode=None, db_path=None):
    """선택한 갈래대로 연다 → 실제로 쓴 갈래.

    ⚠ **유튜브가 아니면 언제나 브라우저다** — 임베드 재생기가 못 연다(조용히 아무 일도
      안 하지 않는다). ⚠ 재생기가 없는 환경(PyQt 미설치)도 브라우저로 떨어진다.
    """
    # ★ **막힌 영상은 처음부터 다른 길로**(283차 ②) — 검은 화면을 안 본다.
    m, _sw = mode_for(vid, mode, db_path)
    if not vid:
        if url:
            webbrowser.open(url)
            return 'BROWSER'
        return 'NONE'
    if m == 'BROWSER' or player is None:
        webbrowser.open(url or watch_url(vid))
        return 'BROWSER'
    if m == 'PAGE':
        player.open_url(watch_url(vid))
        return 'PAGE'
    player.play(vid)
    return 'EMBED'


def open_rep(player, cands, mode=None, db_path=None, autoplay=True):
    """대표 후보 줄을 튼다 → 실제로 쓴 갈래 ('EMBED'|'PAGE'|'BROWSER'|'HOLD'|'NONE').

    `cands` = `db_song.rep_order()` 가 낸 [(media_id, url, title, 까닭)] · 앞이 대표다.

    ⚠⚠⚠ **브라우저 갈래에서는 저절로 안 튼다**(`HOLD`) — 곡을 눌렀을 뿐인데 바깥
      브라우저 창이 솟으면 놀란다. 목록만 보이고 **사용자가 누를 때** 연다.
    ★ 임베드 갈래는 후보를 **통째로** 넘긴다 — 첫 후보가 막히면 재생기가 다음으로
      건너뛴다(`play_try`). 실측 임베드 차단 점검이 91/2,826편뿐이라 필요하다.
    ⚠ 「영상+설명」은 쪽을 여는 것이라 **건너뛰기가 없다** — 첫 후보 하나만 연다.
    """
    cands = list(cands or [])
    if not cands:
        return 'NONE'
    m = mode or get_mode(db_path)
    if not autoplay or m == 'BROWSER':
        return 'HOLD'
    vid0 = _vid_of(cands[0][1])
    if player is None:
        return 'HOLD'
    if m == 'PAGE':
        if not vid0:
            return 'HOLD'
        player.open_url(watch_url(vid0))
        return 'PAGE'
    ids = [x for x in (_vid_of(u) for _m, u, *_r in cands) if x]
    if not ids:
        return 'HOLD'
    # ★ **막힌 것으로 아는 후보는 뒤로 민다**(283차 ②) — 버리지는 않는다.
    #   전부 막혔으면 그래도 틀어야 하고(재생기가 쪽으로 넘긴다), 앞엣것이
    #   성한 것이면 검은 화면을 한 번도 안 본다.
    _off = blocked_ids(db_path)
    if _off:
        ids = ([x for x in ids if x not in _off]
               + [x for x in ids if x in _off])
    if hasattr(player, 'play_try'):
        player.play_try(ids)
    else:
        player.play(ids[0])
    return 'EMBED'


def _vid_of(url):
    """주소에서 유튜브 영상 id — 못 읽으면 빈 글자."""
    import re
    m = re.search(r'(?:v=|youtu\.be/|embed/|shorts/)([\w-]{6,20})', url or '')
    return m.group(1) if m else ''


def make_combo(parent, db_path=None, on_change=None):
    """갈래 콤보 한 벌 — 선택하면 **그 자리에서 저장**한다(따로 저장 단추가 없다).

    ⚠ 화면마다 목록을 다시 적지 않는다. 갈래를 늘리면 `MODES` 한 곳만 고친다.
    """
    import tkinter as tk
    from tkinter import ttk
    vals = labels()
    var = tk.StringVar(value=label(get_mode(db_path)))
    cb = ttk.Combobox(parent, textvariable=var, values=vals, state='readonly',
                      width=max(6, max(len(v) for v in vals) + 2))

    def _sel(_e=None):
        code = code_of(var.get())
        set_mode(code, db_path)
        if on_change:
            try:
                on_change(code)
            except Exception:
                pass
    cb.bind('<<ComboboxSelected>>', _sel)
    cb._vo_var = var
    return cb


def sync_combo(cb, db_path=None):
    """다른 화면에서 값이 바뀌었을 수 있다 — 콤보를 저장값에 맞춘다."""
    try:
        cb._vo_var.set(label(get_mode(db_path)))
    except Exception:
        pass


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    import io
    import os
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                                  errors='replace', line_buffering=True)
    n = [0, 0]

    def t(name, ok, got=''):
        n[1] += 1
        if ok:
            n[0] += 1
        print(('  OK  ' if ok else '  실패 ') + name + ('' if ok else '  ' + str(got)))

    t('① 갈래 셋', CODES == ('EMBED', 'PAGE', 'BROWSER'), CODES)
    t('① 이름을 화면이 안 적는다(열쇠가 있다)', all(k for _c, k, _ko in MODES))
    t('① 이름 왕복', all(code_of(label(c, True), True) == c for c in CODES))
    t('① 모르는 글자는 기본값', code_of('없는 것', True) == DEFAULT)
    t('① 쪽 주소', watch_url('abc') == 'https://www.youtube.com/watch?v=abc')

    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    c.execute("CREATE TABLE userdb.user_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    t('② 아무것도 없으면 기본값', get_mode(conn=c) == DEFAULT)
    c.execute("INSERT INTO userdb.user_config VALUES('LP_OPEN_MODE','YT')")
    t('★ 옛 열쇠를 옮겨 읽는다(YT → 브라우저)', get_mode(conn=c) == 'BROWSER')
    c.execute("UPDATE userdb.user_config SET config_val='TAB'"
              " WHERE config_key='LP_OPEN_MODE'")
    t('★ 옛 열쇠 TAB → 영상만', get_mode(conn=c) == 'EMBED')
    set_mode('PAGE', conn=c)
    t('② 저장하면 그 값이 나온다', get_mode(conn=c) == 'PAGE')
    t('★ 새 열쇠가 옛 열쇠를 이긴다', get_mode(conn=c) == 'PAGE')
    set_mode('없는코드', conn=c)
    t('② 모르는 코드는 저장 안 된다(기본값)', get_mode(conn=c) == DEFAULT)
    c.close()

    class _P:
        def __init__(self):
            self.said = []

        def play(self, v):
            self.said.append(('play', v))

        def open_url(self, u):
            self.said.append(('open_url', u))

    opened = []
    real = webbrowser.open
    webbrowser.open = lambda u, *a, **k: opened.append(u)
    try:
        p = _P()
        t('③ 영상만 → play',
          open_video(p, 'V1', mode='EMBED') == 'EMBED'
          and p.said[-1] == ('play', 'V1'), p.said)
        t('③ 영상+설명 → 유튜브 쪽',
          open_video(p, 'V1', mode='PAGE') == 'PAGE'
          and p.said[-1] == ('open_url', watch_url('V1')), p.said)
        t('③ 브라우저 → 바깥으로',
          open_video(p, 'V1', mode='BROWSER') == 'BROWSER'
          and opened[-1] == watch_url('V1'), opened)
        t('★ 재생기가 없으면 브라우저로 떨어진다',
          open_video(None, 'V1', mode='PAGE') == 'BROWSER')
        t('★ 유튜브가 아니면 언제나 브라우저',
          open_video(p, '', url='https://x.test/a', mode='EMBED') == 'BROWSER'
          and opened[-1] == 'https://x.test/a')
        before = len(p.said)
        t('③ 아무것도 없으면 아무 일도 안 한다',
          open_video(p, '', url='', mode='EMBED') == 'NONE'
          and len(p.said) == before)
    finally:
        webbrowser.open = real

    # ③-2 대표 후보 줄
    class _P2(_P):
        def play_try(self, ids):
            self.said.append(('try', list(ids)))

    opened2 = []
    real2 = webbrowser.open
    webbrowser.open = lambda u, *a, **k: opened2.append(u)
    try:
        q = _P2()
        # ⚠ 유튜브 영상 id 는 11글자다 — 시험에도 **진짜 꼴**을 쓴다
        #   (짧은 가짜를 쓰면 주소에서 못 읽어 시험이 거짓말한다 · 실측으로 잡았다)
        cands = [(1, watch_url('aaaaaaaaaaa'), 'a', ''),
                 (2, watch_url('bbbbbbbbbbb'), 'b', ''),
                 (3, 'https://x.test/none', 'c', '')]
        t('★ 영상만 — 후보를 통째로 넘긴다(막히면 건너뛰게)',
          open_rep(q, cands, mode='EMBED') == 'EMBED'
          and q.said[-1] == ('try', ['aaaaaaaaaaa', 'bbbbbbbbbbb']), q.said)
        t('③ 영상+설명 — 첫 후보 쪽만 연다(건너뛰기 없음)',
          open_rep(q, cands, mode='PAGE') == 'PAGE'
          and q.said[-1] == ('open_url', watch_url('aaaaaaaaaaa')), q.said)
        before = len(q.said), len(opened2)
        t('★★★ 브라우저 갈래에서는 **저절로 안 튼다**',
          open_rep(q, cands, mode='BROWSER') == 'HOLD'
          and (len(q.said), len(opened2)) == before)
        t('③ 자동재생을 끄면 안 튼다',
          open_rep(q, cands, mode='EMBED', autoplay=False) == 'HOLD')
        t('③ 후보가 없으면 아무 일도 안 한다', open_rep(q, [], mode='EMBED') == 'NONE')
        t('③ 재생기가 없으면 안 튼다', open_rep(None, cands, mode='EMBED') == 'HOLD')
        t('③ 유튜브 주소를 못 읽으면 뺀다',
          open_rep(q, [(9, 'https://x.test/none', 'c', '')], mode='EMBED') == 'HOLD')
    finally:
        webbrowser.open = real2
    for u, want in (('https://www.youtube.com/watch?v=dQw4w9WgXcQ', 'dQw4w9WgXcQ'),
                    ('https://youtu.be/aqz-KE-bpKQ', 'aqz-KE-bpKQ'),
                    ('https://x.test/a', '')):
        t('③ 주소에서 영상 id 를 읽는다 %s' % want, _vid_of(u) == want, _vid_of(u))

    # ④ 부르는 자리 — 재생기를 가진 둘은 `open_video`, P2 는 갈래만 읽는다
    # ⚠ 옛 「맞춤 화면」(`pick_video_view`)은 2026-09-17 에 걷었다 — 썸네일
    #   바둑판을 목록으로 바꾸며 그 화면 자체가 사라졌다(사용자 승인).
    for f, why in (('kids_view.py', '목록 화면'),
                   ('entity_browser.py', '주요용어 화면')):
        src = io.open(f, encoding='utf-8').read() if os.path.exists(f) else ''
        t('④ %s 가 재생기를 갖는다' % why,
          'media_player' in src and 'EmbeddedPlayer' in src)
    src = io.open('links_panel.py', encoding='utf-8').read()
    t('④ P2 영상링크가 이 갈래를 읽는다',
      'video_open' in src and 'get_mode(' in src)
    t('④ P2 가 앱 안 갈래 둘을 P4 로 넘긴다', "mode in ('EMBED', 'PAGE')" in src)
    src = io.open('links_panel.py', encoding='utf-8').read()
    t('④ P2 가 옛 두 갈래 표를 안 쓴다', ("('TAB', " + "'LP_OPEN_TAB'") not in src)

    # ── ⑤ 임베드 차단 (283차 ② · 1.txt 14번) ────────────────────────
    import sqlite3 as _sq
    _c = _sq.connect(':memory:')
    _c.executescript(
        "ATTACH ':memory:' AS userdb;"
        "CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
        " url TEXT, embed_ok INTEGER);"
        "INSERT INTO sys_media_asset VALUES"
        " (1,'https://www.youtube.com/watch?v=BLOCKEDaaa',0),"
        " (2,'https://www.youtube.com/watch?v=FINEbbbccc',1);")
    _BLOCK_CACHE['set'] = None
    got = blocked_ids(conn=_c)
    t('⑤ 배포된 사실을 읽는다(embed_ok=0)',
      got == {'BLOCKEDaaa'}, str(got))
    t('  된다고 적힌 것은 안 든다', 'FINEbbbccc' not in got)
    t('★★★ 막힌 영상은 **갈래가 바뀐다**(EMBED → %s)' % BLOCKED_FALLBACK,
      mode_for('BLOCKEDaaa', 'EMBED', conn=_c) == (BLOCKED_FALLBACK, True))
    t('  성한 영상은 그대로', mode_for('FINEbbbccc', 'EMBED', conn=_c)
      == ('EMBED', False))
    t('★★ **사용자가 선택한 갈래를 안 바꾼다** — 그 영상 하나만 다르게 연다',
      get_mode.__doc__ is not None
      and mode_for('FINEbbbccc', 'PAGE', conn=_c)[0] == 'PAGE')
    t('  브라우저 갈래는 건드리지 않는다(이미 임베드가 아니다)',
      mode_for('BLOCKEDaaa', 'BROWSER', conn=_c) == ('BROWSER', False))
    # 그 자리에서 배우기 — **개인 표에만** 적는다(§C-2)
    _BLOCK_CACHE['set'] = None
    blocked_ids(conn=_c)
    t('★★★ 배운 것을 적는다', mark_blocked('LEARNEDxyz', 'test', conn=_c)
      and 'LEARNEDxyz' in blocked_ids(conn=_c))
    t('★★ **배포 DB 를 안 건드린다**(§C-2 — 사용자 동작이 sys 를 못 고친다)',
      _c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE embed_ok=0"
                 ).fetchone()[0] == 1)
    t('  개인 표에 적혔다',
      _c.execute("SELECT COUNT(*) FROM userdb.%s" % USER_TBL).fetchone()[0] == 1)
    t('  배운 뒤에는 갈래가 바뀐다',
      mode_for('LEARNEDxyz', 'EMBED', conn=_c)[1] is True)
    # 대표 후보 — 막힌 것이 뒤로 간다
    class _P:
        def __init__(self):
            self.tried = None
            self.url = None

        def play_try(self, ids):
            self.tried = list(ids)

        def open_url(self, u):
            self.url = u

        def play(self, v):
            self.tried = [v]
    _BLOCK_CACHE['set'] = {'BLOCKEDaaa'}
    p = _P()
    open_rep(p, [(1, 'https://youtu.be/BLOCKEDaaa', 't', ''),
                 (2, 'https://youtu.be/FINEbbbccc', 't', '')],
             mode='EMBED')
    t('★★ 대표 후보에서 **막힌 것이 뒤로 간다**',
      p.tried == ['FINEbbbccc', 'BLOCKEDaaa'], str(p.tried))
    t('  버리지는 않는다(전부 막혀도 틀 것이 남는다)', len(p.tried) == 2)
    # 그 자리에서 막혔을 때
    p2 = _P()
    _BLOCK_CACHE['set'] = set()
    r = on_blocked(p2, 'NOWBLOCKED', db_path=':memory:')
    t('★★★ 그 자리에서 막히면 **저절로 유튜브 쪽으로** 넘어간다',
      r == BLOCKED_FALLBACK and (p2.url or '').endswith('NOWBLOCKED'),
      '%s / %s' % (r, p2.url))
    t('★ **우회가 아니다** — 임베드를 포기하고 유튜브가 직접 서비스하는 쪽으로',
      'youtube.com/watch' in (p2.url or ''))
    _BLOCK_CACHE['set'] = None
    _c.close()

    print('video_open selftest: %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('video_open — 영상을 어떻게 여나. --selftest 로 자가검증.')
