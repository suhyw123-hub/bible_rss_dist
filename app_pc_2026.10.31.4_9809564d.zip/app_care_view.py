"""설정 ▸ 앱 관리 (2026-10-13 신설 · docs/1.txt 73 · `--selftest`).

사용자 지시 — 「사용자가 스스로 앱을 효과적으로 사용할 수 있도록 돕는 도구 · 불필요한 데이터 삭제 ·
비활성화 링크를 사용자의 동의 하에 물리적으로 삭제 · 로그 관리」.

★ 2026-10-13 다시 배치(사용자 「백업 만들기가 아래에 있어 눈에 안 띈다 · 단추를 위로 · 관리자 PC 라벨 필요 없다 ·
  관리자 PC 라도 수동 수집한 유튜브는 관리 대상 · 오류인지 목록이 없는지 명확하게」):
위 띠 — 단추 전부(백업 만들기·되살리기 · 압축 · 오류 기록 폴더 … 새로 고치기 · 「지금 정리하기」는 걷었다 — 하루 한 번 자동과 같은 일이었다) + 결과 한 줄
왼쪽 — 저장 공간 · 자동 정리(무엇을 언제) · 백업 · 공간 되찾기 · 오류 기록 (설명과 결과만)
오른쪽 — 볼 수 없는 영상: 관리자가 내린 영상 중 내 자료가 가리키는 것 + **내가 담은 영상**([확인하기]로 유튜브에 묻는다)
· 엔진은 `app_housekeep` — 여기서 SQL 을 다시 짜지 않는다.
· 팝업 없음(지우기·압축은 **한 번 더 눌러야** 돈다) · 색은 역할 · 무거운 일은 일꾼 스레드 + after.
"""
import datetime
import os
import queue
import threading
import tkinter as tk
from tkinter import filedialog, ttk

import appdb
import app_housekeep as HK

try:
    import i18n
    _t = i18n.t
except Exception:          # pragma: no cover
    def _t(k, d=''):
        return d

try:
    import ui_theme
except Exception:          # pragma: no cover
    ui_theme = None


def _C(role, fb):
    try:
        v = ui_theme.C(role) if ui_theme else ''
        return v or fb
    except Exception:
        return fb


STORE_NAMES = {
    'MAIN': ('CARE_S_MAIN', '배포 자료 (성경·설명문·도서)'),
    'USER': ('CARE_S_USER', '내 자료 (노트·연결·즐겨찾기)'),
    'LINKPACK': ('CARE_S_LINK', '영상 연결'),
    'MOBILE': ('CARE_S_MOBILE', '폰으로 보낼 자료 캐시'),
    'SPLASH': ('CARE_S_SPLASH', '시작 화면 사진'),
    'ERRLOG': ('CARE_S_ERR', '오류 기록'),
    'SYS_AUDIT': ('CARE_S_SYSAUD', '배포 자료 변경 이력'),
    'USER_AUDIT': ('CARE_S_USERAUD', '내 자료 변경 이력'),
}
REF_NAMES = {'FAV': ('CARE_R_FAV', '즐겨찾기'), 'LIST': ('CARE_R_LIST', '재생목록'),
             'HIDE': ('CARE_R_HIDE', '숨김'), 'LINK': ('CARE_R_LINK', '연결')}


def _bold():
    """표준 글꼴의 굵은 꼴 — 크기를 박지 않는다(§0)."""
    try:
        from tkinter import font as tkfont
        f = tkfont.nametofont('TkDefaultFont').actual()
        return (f['family'], f['size'], 'bold')
    except Exception:
        return None


def _mb(n):
    if n is None:
        return ''
    if n >= 1024 * 1024:
        return '%.1f MB' % (n / 1024 / 1024)
    return '%d KB' % max(0, n // 1024)


class AppCareView(ttk.Frame):
    def __init__(self, master, db_path=None, **kw):
        super().__init__(master, **kw)
        self.db_path = db_path or appdb.MAIN_DB
        self._q = queue.Queue()
        self._armed = {}                       # 한 번 더 눌러야 도는 단추 — {열쇠: 원래 글}
        self._used = []                        # 내려간 영상 중 내 자료가 가리키는 것
        self._mine = None                      # 내가 담은 영상 확인 결과 [(dict, 상태)] — 누르기 전 None
        self._nmine = 0
        self._build_top()
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=(0, 6))
        left = ttk.Frame(pw)
        right = ttk.Frame(pw)
        pw.add(left, weight=3)
        pw.add(right, weight=2)
        self._build_left(left)
        self._build_right(right)
        self.after(150, self._pump)
        self.reload()

    # ── 위 띠 — 단추는 전부 여기(§0) ───────────────────────────────────
    def _build_top(self):
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        ttk.Button(bar, text=_t('CARE_BK_MAKE', '백업 파일 만들기'), command=self._backup).pack(side='left')
        self._b_restore = ttk.Button(bar, text=_t('CARE_BK_RESTORE', '백업에서 되살리기'), command=self._restore)
        self._b_restore.pack(side='left', padx=(6, 0))
        self._b_cancel = ttk.Button(bar, text=_t('CARE_BK_CANCEL', '되살리기 취소'), command=self._cancel_restore)
        self._b_compact = ttk.Button(bar, text=_t('CARE_COMPACT', '자료 파일 최적화'), command=self._compact)
        self._b_compact.pack(side='left', padx=(18, 0))
        ttk.Button(bar, text=_t('CARE_RELOAD', '새로 고침'), command=self.reload).pack(side='right')
        # ★ 2026-10-25 앱 새 판 — 알림을 놓쳤을 때 여기서 직접 확인 · 바로 앞 판으로 되돌리기(다음 시작 때)
        self._b_upd = ttk.Button(bar, text=_t('UPD_CHECK', '새 판 확인'), command=self._upd_check)
        self._b_upd.pack(side='left', padx=(18, 0))
        self._b_back = ttk.Button(bar, text=_t('UPD_ROLLBACK', '이전 판으로 되돌리기'), command=self._upd_rollback)
        self._b_back.pack(side='left', padx=(6, 0))
        self._status = tk.Label(self, text='', anchor='w', justify='left', wraplength=900,
                                fg=_C('accent', '#2471A3'), bg=_C('bg', '#FFFFFF'))
        self._status.pack(fill='x', padx=8, pady=(0, 4))

    # ── 왼쪽 — 설명과 결과 ────────────────────────────────────────────
    def _head(self, p, key, text):
        tk.Label(p, text=_t(key, text), font=_bold(), anchor='w',
                 fg=_C('fg_title', '#1F3A5F'), bg=_C('bg', '#FFFFFF')).pack(fill='x', pady=(8, 2))

    def _note(self, p, text):
        lb = tk.Label(p, text=text, anchor='w', justify='left', wraplength=520,
                      fg=_C('fg_dim', '#7F8C8D'), bg=_C('bg', '#FFFFFF'))
        lb.pack(fill='x')
        return lb

    def _build_left(self, p):
        self._head(p, 'UPD_H', '앱 판')
        self._upd = self._note(p, '')
        self._head(p, 'CARE_H_STORE', '저장 공간')
        self._tv = ttk.Treeview(p, columns=('n', 'v'), show='headings', height=8, selectmode='none')
        self._tv.heading('n', text=_t('CARE_COL_WHAT', '무엇'))
        self._tv.heading('v', text=_t('CARE_COL_SIZE', '크기'))
        self._tv.column('n', width=300, anchor='w')
        self._tv.column('v', width=120, anchor='e')
        self._tv.pack(fill='x')

        self._head(p, 'CARE_H_AUTO', '자동 정리 — 하루 한 번, 앱을 켤 때 뒤에서')
        self._note(p, _t('CARE_AUTO_TEXT3',
                         '· 내 자료 변경 이력: 180일 지난 것\n'
                         '· 폰에서 받아 처리를 끝낸 초안: 90일 뒤\n'
                         '· 관리자가 내린 영상: 내 자료가 가리키지 않는 것만 — 가리키는 것은 오른쪽에서 직접 선택합니다\n'
                         '· 오류 기록·최신 콘텐츠 캐시: 90일 뒤\n'
                         '· 지운 글(휴지통)은 자동으로 지우지 않습니다 — 「내 수정」 ▸ 휴지통에서 직접 비웁니다'))
        self._last = self._note(p, '')

        self._head(p, 'CARE_H_BACKUP', '내 자료 백업')
        self._note(p, _t('CARE_BK_TEXT', '묵상노트·연결·즐겨찾기·플랜 진행 등 이 PC 에서 쓴 것 전부를 파일 하나로 남깁니다. '
                                         'PC 를 바꾸거나 고장 났을 때 그 파일로 되살립니다. 되살리기는 앱을 다시 켤 때 적용되고, '
                                         '지금 자료는 지우지 않고 옆에 남겨 둡니다.'))
        self._bk = self._note(p, '')

        self._head(p, 'CARE_H_COMPACT', '자료 파일 최적화')
        self._cp = self._note(p, _t('CARE_COMPACT_TEXT', 'Windows 의 「드라이브 최적화」와 같은 일을 앱의 자료 파일 하나에 합니다. 성경 본문·설명문·도서가 담긴 자료 파일은 자료를 받거나 지운 뒤에도 크기가 저절로 줄지 않고 안에 빈자리가 남습니다. 최적화는 그 파일을 처음부터 다시 정돈해 빈자리를 없애고 파일 크기를 줄입니다. 내용은 하나도 바뀌지 않습니다.\n몇 분 걸리고 그동안 앱이 느릴 수 있어 단추를 한 번 더 눌러야 시작합니다. 자주 할 필요는 없고, 큰 자료를 지운 뒤에 한 번이면 됩니다.'))

        self._head(p, 'CARE_H_ERR', '오류 기록')
        self._note(p, _t('CARE_ERR_TEXT2', '앱에 문제가 생기면 그 내용이 이 PC 에만 기록됩니다(개인정보 제외 · 90일 뒤 저절로 지워짐). 「공지/소통」 ▸ 「내 문의」로 문제를 알리면 최근 기록이 자동으로 함께 보내집니다.'))

    # ── 오른쪽 — 볼 수 없는 영상 ──────────────────────────────────────
    def _build_right(self, p):
        bar = ttk.Frame(p)
        bar.pack(fill='x')
        self._b_chk = ttk.Button(bar, text=_t('CARE_MINE_CHECK', '내가 담은 영상 확인하기'), command=self._check_mine)
        self._b_chk.pack(side='left')
        self._b_del = ttk.Button(bar, text=_t('CARE_DEAD_DEL', '선택한 영상 지우기'), command=self._del_media)
        self._b_del.pack(side='left', padx=(6, 0))
        ttk.Button(bar, text=_t('CARE_DEAD_ALL', '모두 선택'), command=self._select_all).pack(side='left', padx=6)
        self._head(p, 'CARE_H_DEAD2', '볼 수 없는 영상')
        self._note(p, _t('CARE_DEAD_TEXT2',
                         '· 내려간 영상 — 관리자가 내렸는데 내 즐겨찾기·재생목록·연결이 아직 가리키는 것\n'
                         '· 내 영상 — 유튜브 간편 저장으로 담은 영상. [내가 담은 영상 확인하기]를 누르면 '
                         '유튜브에 하나씩 물어 볼 수 없게 된 것을 찾습니다\n'
                         '선택해서 지우면 그 영상을 가리키던 내 즐겨찾기·재생목록·연결도 함께 빠집니다.'))
        fr = ttk.Frame(p)
        fr.pack(fill='both', expand=True, pady=(4, 0))
        self._dv = ttk.Treeview(fr, columns=('k', 't', 'r'), show='headings', selectmode='extended')
        self._dv.heading('k', text=_t('CARE_COL_KIND', '구분'))
        self._dv.heading('t', text=_t('CARE_COL_TITLE', '제목'))
        self._dv.heading('r', text=_t('CARE_COL_REF', '쓰는 곳'))
        self._dv.column('k', width=120, anchor='w')
        self._dv.column('t', width=240, anchor='w')
        self._dv.column('r', width=100, anchor='w')
        sb = ttk.Scrollbar(fr, orient='vertical', command=self._dv.yview)
        self._dv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._dv.pack(fill='both', expand=True)

    def _select_all(self):
        self._dv.selection_set([i for i in self._dv.get_children() if i[:2] in ('S:', 'U:')])

    # ── 채우기 ────────────────────────────────────────────────────────
    def reload(self):
        def work():
            c = appdb.connect(self.db_path)
            try:
                st = HK.storage(c)
                _free, used = HK.dead_media(c)
                last = HK.last_report(c)
                nmine = len(HK.my_videos(c))
            finally:
                c.close()
            return st, used, last, nmine
        self._bg('LOAD', work)

    # ── 앱 판(2026-10-25) ─────────────────────────────────────────────
    def _upd_text(self, extra=''):
        import app_update as AU
        lines = [_t('UPD_NOW', '지금 판 %s') % AU.current()]
        ap = AU.last_applied()
        if ap:
            lines.append(_t('UPD_APPLIED', '%s 에 %s → %s 로 바뀌었습니다') % (ap.get('at', ''), ap.get('from', ''), ap.get('to', '')))
        pd = AU.pending()
        if pd:
            lines.append(_t('UPD_PENDING', '새 판 %s 을 받아 두었습니다 — 앱을 다시 켜면 바뀝니다(내 자료는 그대로).') % pd.get('version', ''))
        bk = AU.can_rollback()
        if bk:
            lines.append(_t('UPD_CAN_BACK', '문제가 있으면 바로 앞 판(%s)으로 되돌릴 수 있습니다 — 다음 시작 때 적용됩니다.') % bk)
        if AU.is_dev():
            lines.append(_t('UPD_DEV', '이 PC 는 앱을 만드는 PC 라 새 판을 받지 않습니다.'))
        if extra:
            lines.append(extra)
        self._upd.config(text='\n'.join(lines))
        try:
            self._b_back.state(['!disabled'] if bk else ['disabled'])
        except Exception:                                 # noqa: BLE001
            pass

    def _upd_check(self):
        self._b_upd.state(['disabled'])
        self._status.config(text=_t('UPD_CHECKING', '새 판을 확인하는 중…'))

        def work():
            import app_update as AU
            return AU.check()
        self._bg('UPD', work)

    def _upd_rollback(self):
        import app_update as AU
        if not self._arm('UPD_BACK', self._b_back):
            return
        ok = AU.request_rollback()
        msg = _t('UPD_BACK_SET', '다음에 앱을 켤 때 바로 앞 판으로 되돌립니다.') if ok else _t('UPD_BACK_NONE', '되돌릴 판이 없습니다.')
        self._status.config(text=msg)
        self._upd_text()

    def _fill(self, st, used, last, nmine):
        self._tv.delete(*self._tv.get_children())
        for key, b, extra in st:
            k, d = STORE_NAMES.get(key, (key, key))
            v = _mb(b) if b is not None else (_t('CARE_ROWS', '%d줄').replace('%d', '%s') % '{:,}'.format(extra or 0))
            self._tv.insert('', 'end', values=(_t(k, d), v))
        self._used, self._nmine = used, nmine
        self._fill_videos()
        try:
            self._upd_text()
        except Exception:                                 # noqa: BLE001
            pass
        d, rep = last
        if d:
            self._last.config(text=_t('CARE_LAST2', '마지막 정리 %s — 내 변경 이력 %d줄 · 폰 초안 %d개 · 내려간 영상 %d개를 지웠습니다')
                              % (d, rep.get('user_audit', 0), rep.get('inbox', 0), rep.get('media', 0)))
        else:
            self._last.config(text=_t('CARE_LAST_NONE', '아직 정리한 적이 없습니다.'))
        if HK.pending_restore():
            self._bk.config(text=_t('CARE_BK_PENDING', '되살릴 백업이 올라가 있습니다 — 앱을 다시 켜면 적용됩니다.'))
            self._b_cancel.pack(side='left', padx=(6, 0), after=self._b_restore)
        else:
            self._b_cancel.pack_forget()

    def _fill_videos(self, err=None):
        """「없음」과 「못 불러옴」을 가른다(2026-10-13 사용자 「오류인지 목록이 없는지 명확하게」)."""
        tv = self._dv
        tv.delete(*tv.get_children())
        if err is not None:
            tv.insert('', 'end', iid='!', values=('', _t('CARE_DEAD_ERR', '목록을 불러오지 못했습니다: %s') % err, ''))
            return
        for u in self._used:
            refs = ' · '.join(_t(*REF_NAMES.get(r, (r, r))) for r in u['refs'])
            tv.insert('', 'end', iid='S:%d' % u['id'],
                      values=(_t('CARE_K_DOWN', '내려간 영상'), u['title'], refs))
        for v, st in (self._mine or ()):
            if st == 'OK':
                continue
            kind = {'GONE': _t('CARE_K_GONE', '내 영상 · 지워짐'),
                    'PRIVATE': _t('CARE_K_PRIV', '내 영상 · 비공개'),
                    'NET': _t('CARE_K_NET', '내 영상 · 확인 못함')}.get(st, st)
            tv.insert('', 'end', iid='U:%d' % v['id'], values=(kind, v['title'], _t('CARE_R_MINE', '내가 담음')))
        if tv.get_children():
            return
        if self._mine is None:
            msg = _t('CARE_DEAD_NONE2', '내려간 영상 가운데 내가 쓰던 것은 없습니다. '
                                        '내가 담은 영상 %d편은 아직 확인하지 않았습니다.') % self._nmine
        else:
            msg = _t('CARE_DEAD_NONE3', '볼 수 없는 영상이 없습니다 — 내려간 영상 0 · '
                                        '내가 담은 영상 %d편 모두 볼 수 있습니다.') % len(self._mine)
        tv.insert('', 'end', iid='-', values=('', msg, ''))

    # ── 한 번 더 눌러야 도는 단추 ──────────────────────────────────────
    def _arm(self, key, btn):
        """처음 누르면 글자만 바꾸고 False · 다시 누르면 True."""
        if key in self._armed:
            btn.config(text=self._armed.pop(key))
            return True
        self._armed[key] = btn.cget('text')
        btn.config(text=_t('CARE_AGAIN', '한 번 더 누르면 실행합니다'))
        self.after(5000, lambda: (btn.config(text=self._armed.pop(key)) if key in self._armed else None))
        return False

    # ── 일 ───────────────────────────────────────────────────────────

    def _check_mine(self):
        self._status.config(text=_t('CARE_MINE_RUNNING', '내가 담은 영상을 유튜브에 하나씩 묻는 중…'))
        self._b_chk.state(['disabled'])

        def work():
            c = appdb.connect(self.db_path)
            try:
                vids = HK.my_videos(c)
            finally:
                c.close()
            return [(v, HK.check_video(v['url'])) for v in vids]
        self._bg('MINE', work)

    def _del_media(self):
        sel = [i for i in self._dv.selection() if i[:2] in ('S:', 'U:')]
        if not sel:
            self._status.config(text=_t('CARE_DEAD_PICK', '지울 영상을 목록에서 선택하세요.'))
            return
        if not self._arm('DEL', self._b_del):
            return
        sys_ids = [int(i[2:]) for i in sel if i.startswith('S:')]
        my_ids = [int(i[2:]) for i in sel if i.startswith('U:')]
        if self._mine is not None:
            gone = set(my_ids)
            self._mine = [(v, st) for v, st in self._mine if v['id'] not in gone]

        def work():
            c = appdb.connect(self.db_path)
            try:
                n = HK.purge_media(c, sys_ids, with_refs=True) if sys_ids else 0
                return n + HK.purge_my_videos(c, my_ids)
            finally:
                c.close()
        self._bg('DEL', work)

    def _backup(self):
        p = filedialog.asksaveasfilename(parent=self, defaultextension='.db',
                                         initialfile='hagah_my_data_%s.db' % datetime.datetime.now().strftime('%Y%m%d'),
                                         filetypes=[('DB', '*.db')])
        if p:
            self._bk.config(text=_t('CARE_WORKING', '하는 중…'))
            self._status.config(text=_t('CARE_WORKING', '하는 중…'))
            self._bg('BK', lambda: HK.backup(p))

    def _restore(self):
        p = filedialog.askopenfilename(parent=self, filetypes=[('DB', '*.db')])
        if p:
            self._bg('RS', lambda: HK.stage_restore(p))

    def _cancel_restore(self):
        HK.cancel_restore()
        self._bk.config(text='')
        self.reload()

    def _compact(self):
        if not self._arm('CP', self._b_compact):
            return
        self._cp.config(text=_t('CARE_WORKING', '하는 중…'))
        self._status.config(text=_t('CARE_WORKING', '하는 중…'))
        self._bg('CP', HK.compact_main)

    # ── 일꾼 스레드 + after ───────────────────────────────────────────
    def _bg(self, tag, fn):
        def run():
            try:
                self._q.put((tag, True, fn()))
            except Exception as e:                       # noqa: BLE001
                self._q.put((tag, False, e))
        threading.Thread(target=run, daemon=True).start()

    def _pump(self):
        try:
            while True:
                tag, ok, val = self._q.get_nowait()
                self._done(tag, ok, val)
        except queue.Empty:
            pass
        except tk.TclError:
            return
        try:
            self.after(150, self._pump)
        except tk.TclError:
            pass

    def _done(self, tag, ok, val):
        if not ok:
            self._status.config(text=_t('CARE_FAIL', '하지 못했습니다: %s') % val)
            if tag == 'LOAD':
                self._fill_videos(err=val)
            elif tag == 'MINE':
                self._b_chk.state(['!disabled'])
            return
        if tag == 'UPD':
            self._b_upd.state(['!disabled'])
            st = val.get('status')
            msg = {'READY': _t('UPD_R_READY', '새 판 %s 을 받아 두었습니다 — 앱을 다시 켜면 바뀝니다.') % val.get('version', ''),
                   'SAME': _t('UPD_R_SAME', '지금이 가장 새 판입니다.'),
                   'NONE': _t('UPD_R_NONE', '판 목록을 읽지 못했습니다(망을 확인하세요).'),
                   'DEV': _t('UPD_R_DEV', '새 판 %s 이 있지만 이 PC 는 앱을 만드는 PC 라 받지 않습니다.') % val.get('version', ''),
                   }.get(st, val.get('message') or st)
            self._status.config(text=msg)
            self._upd_text()
            try:
                if st == 'READY':
                    self.winfo_toplevel()._show_update_bar(val)
            except Exception:                             # noqa: BLE001
                pass
            return
        if tag == 'LOAD':
            self._fill(*val)
        elif tag == 'MINE':
            self._b_chk.state(['!disabled'])
            self._mine = val
            cnt = {}
            for _v, st in val:
                cnt[st] = cnt.get(st, 0) + 1
            self._status.config(text=_t('CARE_MINE_DONE', '내가 담은 영상 %d편 — 볼 수 있음 %d · 지워짐 %d · 비공개 %d · 확인 못함 %d')
                                % (len(val), cnt.get('OK', 0), cnt.get('GONE', 0), cnt.get('PRIVATE', 0), cnt.get('NET', 0)))
            self._fill_videos()
        elif tag == 'DEL':
            self._status.config(text=_t('CARE_DEAD_DONE', '영상 %d개를 지웠습니다.') % (val or 0))
            self.reload()
        elif tag == 'BK':
            good, why = val
            msg = _t('CARE_BK_OK', '백업을 만들었습니다.') if good else _t('CARE_FAIL', '하지 못했습니다: %s') % why
            self._bk.config(text=msg)
            self._status.config(text=msg)
        elif tag == 'RS':
            good, why = val
            msg = {'NOT_USER': _t('CARE_BK_NOTUSER', '내 자료 백업 파일이 아닙니다.'),
                   'BROKEN': _t('CARE_BK_BROKEN', '파일이 손상되어 쓸 수 없습니다.')}.get(why, why)
            msg = _t('CARE_BK_PENDING', '되살릴 백업이 올라가 있습니다 — 앱을 다시 켜면 적용됩니다.') if good else msg
            self._bk.config(text=msg)
            self._status.config(text=msg)
            self.reload()
        elif tag == 'CP':
            msg = _t('CARE_COMPACT_OK', '최적화를 마쳤습니다 — 파일이 %s 줄었습니다.') % _mb(max(0, val or 0))
            self._cp.config(text=msg)
            self._status.config(text=msg)
            self.reload()


def selftest():
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)
    r = tk.Tk()
    v = AppCareView(r)
    v.pack(fill='both', expand=True)
    for _ in range(80):
        r.update()
        if v._tv.get_children():
            break
        r.after(50)
    ck(len(v._tv.get_children()) >= 6, '저장 공간 줄 %d' % len(v._tv.get_children()))
    ck(bool(v._last.cget('text')), '자동 정리 마지막 결과 줄')
    ck(bool(v._dv.get_children()), '영상 목록이 비지 않는다(없으면 「없습니다」 한 줄)')
    # 위 띠에 백업 단추가 있다(본문보다 위)
    r.update()
    ck(v._b_compact.winfo_rooty() < v._tv.winfo_rooty(), '단추가 본문보다 위')
    # 못 불러오면 그렇다고 말한다
    v._fill_videos(err='시험')
    ck(v._dv.get_children() == ('!',), '못 불러오면 「불러오지 못했습니다」')
    # 확인 결과 — 볼 수 있는 것만이면 「없습니다」 · 지워진 것은 줄로
    v._used = []
    v._mine = [({'id': 1, 'title': 'a', 'url': ''}, 'OK')]
    v._fill_videos()
    ck(v._dv.get_children() == ('-',), '모두 볼 수 있으면 「없습니다」 한 줄')
    v._mine = [({'id': 1, 'title': 'a', 'url': ''}, 'GONE')]
    v._fill_videos()
    ck(v._dv.get_children() == ('U:1',), '지워진 내 영상은 줄로')
    ck(not v._arm('X', v._b_compact) and v._arm('X', v._b_compact), '한 번 더 눌러야 돈다')
    r.destroy()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
