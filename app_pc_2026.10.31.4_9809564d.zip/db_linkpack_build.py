# -*- coding: utf-8 -*-
"""db_linkpack_build.py — **영상 연결 팩** 보내는 쪽 (2026-09-03 192차 신설·영구).

★★★ 2026-09-29 293차 — **「옛 경로」가 아니라 영상 연결의 정식 경로다.**
  코어팩이 영상을 통째로 나르리라던 계획(2026-09-04)을 걷었다 — 영상 주소는
  코어 표가 아니고(`db_pack_catalog` PACK·LINK), 영상 연결(`MEDI_*`)은 코어
  조건에서 빠진다. 까닭 셋(사용자 확정 「독립된 자산팩으로 취급」):
  · **주기** — 30일 변경이 주소 149,461 · 연결 739,243 건. 코어는 연 2회다.
  · **변경 방식** — 바뀐 것만(델타) + 지운 것은 묘비. 코어는 통째로 갈아 끼운다.
  · **받는 쪽** — 트레이가 자동으로 받는다. 코어·본문팩은 사용자가 고른다.
  관리자 화면 = 배포 센터 ▸ **배포 관리 ▸ 영상 연결**(옛 「링크 팩 (옛 경로)」
  탭은 걷었다). 매일 자동 = `collect_channels` 끝에서 `publish()`(자동 업로드
  스위치가 켜져 있을 때).

★★★ 왜 (사용자 지시 — 배포 센터): 190차에 만든 것은 **받는 쪽**(트레이·적재기)
  이었고 **보내는 쪽**이 비어 있었다. 관리자가 「승인된 것만 골라 델타를
  만들고 올리는」 자리가 이것이다.

**배포 대상 = 승인된 것만**
  실측 — `sys_media_asset` 12,916 중 **is_active=1 은 2,080**뿐이고 나머지
  10,836 은 검토 대기다(사용자 「검토승인이 안끝난 URL 약 2만개」). 그래서
  **`is_active=1 AND record_status='LIVE'` 만 싣는다** — 검토 안 끝난 링크가
  나가면 죽은 URL 이 사용자에게 간다.

**델타는 이전 배포본과 견주어 만든다**
  마지막으로 내보낸 전체본을 `_linkpack_dist/last_full.json` 에 두고, 지금
  DB 와 견주어 **추가·수정·삭제(묘비)** 를 낸다. 그 폴더가 곧 정적 서버에
  올릴 것이다(`linkpack_00007.json` · `linkpack_full.json`).

**참조는 자연 열쇠로 싣는다**
  엔티티는 `target_code`(entity_code) · 단락은 `target_peri`(peri_code) ·
  구절은 번호(verse_id 는 배포마다 안 바뀐다). 받는 쪽이 해석하고 **모르면
  보류**한다 — 본체 주기와 팩 주기가 어긋나도 안전(§190차).

    python db_linkpack_build.py --selftest   (의무)
    python db_linkpack_build.py --status
    python db_linkpack_build.py --full       (전체본 새로 — 첫 배포·풀싱크)
    python db_linkpack_build.py --delta      (이전 대비 델타)
"""
import io
import json
import os
import sys

# ★ 2026-10-24 창이 있을 때만 감싼다 — pythonw(작업 스케줄러)에서는 1번 핸들이 없어 첫 출력에서
#   [WinError 6] 핸들이 잘못되었습니다로 자동 배포가 막혔다(부르는 쪽이 이미 기록 파일로 바꿔 두었다).
if sys.stdout is not None and sys.stdout is sys.__stdout__:
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, '_linkpack_dist')
LAST = 'last_full.json'          # 마지막으로 내보낸 것(견줌 기준 · 업로드 안 함)
STATE = 'state.json'             # 시퀀스 등 관리자 로컬 상태
#: ★ 받는 쪽이 「얼마나 밀렸나」를 먼저 아는 작은 파일(수백 바이트) — 업로드한다.
MANIFEST = 'linkpack_manifest.json'

#: 팩에 싣는 링크 갈래 — 미디어가 어디에 걸리는가
LINK_TYPES = ('MEDI_ENTI', 'MEDI_PERI', 'MEDI_VERS')


def _dist(name):
    os.makedirs(DIST, exist_ok=True)
    return os.path.join(DIST, name)


def _load(name, dflt=None):
    p = _dist(name)
    if not os.path.exists(p):
        return dflt
    try:
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return dflt


def _save(name, obj):
    with open(_dist(name), 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    return _dist(name)


def snapshot(conn):
    """지금 DB 의 **배포 대상** → {'media': {id: {...}}, 'links': {키: {...}}}.

    ⚠ 승인된 것만(`is_active=1`). 그 미디어에 걸린 링크만 싣는다 —
      주인 없는 연결을 보내면 받는 쪽에서 보류로 쌓인다."""
    media, links = {}, {}
    # ★★★ **설명문은 배포하지 않는다** (2026-09-04 사용자 지시 — 「사용자를
    #   위해 설명문을 수집하여 배포할 필요는 전혀 없다. **팩에서 무조건
    #   제거하라**」).
    #   ⚠⚠ 실측으로 잡았다 — 승인 2,080건 중 **692건의 유튜브 설명문이
    #     사용자 PC 로 나가고 있었는데**, 사용자 앱 폐포 135파일 어디에서도
    #     그것을 읽지 않는다. **이득 0 · 위험만 있었다.**
    #   ★ 위험이 둘이다 ⓐ 남의 글(채널이 쓴 제작 크레딧·라이선스 고지)을
    #     재배포한다 ⓑ **YouTube API 약관** — 식별자(video ID·URL)를 뺀
    #     메타데이터는 30일 안에 갱신하거나 지워야 한다. 무기한 보관 + 제3자
    #     재배포는 그 원칙에서 가장 먼 자리다.
    #   ⚠ **칸은 남기고 빈 값으로 싣는다** — 받는 쪽(`db_linkpack_sync`)의
    #     스키마를 건드리지 않는다. 옛 팩을 받은 사용자는 다음 델타에서
    #     description 이 ''로 덮여 **저절로 지워진다**(묘비를 따로 안 만든다).
    for (mid, mtype, ftype, title, url, lang, sort) in conn.execute(
            "SELECT media_id, media_type, COALESCE(format_type,'VIDEO'),"
            " COALESCE(title,''), url,"
            " COALESCE(lang_code,''), COALESCE(sort_order,0)"
            " FROM sys_media_asset"
            " WHERE is_active=1 AND record_status='LIVE'"
            "   AND url IS NOT NULL AND TRIM(url)<>''"):
        media[str(mid)] = {
            'media_id': mid, 'media_type': mtype, 'format_type': ftype,
            'title': title, 'description': '', 'url': url,
            'lang_code': (lang or '').upper(), 'sort_order': sort}
    if not media:
        return {'media': media, 'links': links}
    ph = ','.join('?' * len(LINK_TYPES))
    for (lt, cid, tid, rel, end) in conn.execute(
            "SELECT link_type, clicked_id, target_id, rel_code, end_id"
            " FROM sys_link_asset"
            " WHERE link_type IN (%s)"
            "   AND COALESCE(record_status,'LIVE')='LIVE'" % ph, LINK_TYPES):
        if str(cid) not in media:
            continue                      # 승인 안 된 미디어의 연결은 안 보낸다
        row = {'link_type': lt, 'clicked': cid, 'rel': rel, 'end': end}
        # ★ 자연 열쇠 — 받는 쪽이 해석한다(모르면 보류)
        if lt == 'MEDI_ENTI':
            r = conn.execute("SELECT entity_code FROM sys_entity_master"
                             " WHERE entity_id=?", (tid,)).fetchone()
            if not r:
                continue
            row['target_code'] = r[0]
        elif lt == 'MEDI_PERI':
            r = conn.execute("SELECT peri_code FROM sys_pericope_asset"
                             " WHERE pericope_id=?", (tid,)).fetchone()
            if not r or not r[0]:
                continue
            row['target_peri'] = r[0]
        else:                              # MEDI_VERS — 구절 번호는 안정적
            row['target'] = tid
        links['%s|%s|%s' % (lt, cid, tid)] = row
    return {'media': media, 'links': links}


def diff(old, new):
    """이전 배포본 → 지금 = (미디어 델타, 링크 델타, 통계).

    삭제는 **묘비**(`record_status='DELETED'`)로 낸다 — 받는 쪽이 그 행과
    딸린 연결을 함께 걷는다."""
    om, nm = (old or {}).get('media', {}), new['media']
    ol, nl = (old or {}).get('links', {}), new['links']
    m_out, l_out = [], []
    add = mod = dele = 0
    for k, v in nm.items():
        if k not in om:
            m_out.append(v)
            add += 1
        elif om[k] != v:
            m_out.append(v)
            mod += 1
    for k in om:
        if k not in nm:
            m_out.append({'media_id': om[k]['media_id'],
                          'record_status': 'DELETED'})
            dele += 1
    l_add = l_del = 0
    for k, v in nl.items():
        if k not in ol or ol[k] != v:
            l_out.append(v)
            l_add += 1
    for k, v in ol.items():
        if k not in nl:
            d = dict(v)
            d['record_status'] = 'DELETED'
            l_out.append(d)
            l_del += 1
    return m_out, l_out, {'add': add, 'mod': mod, 'del': dele,
                          'link_add': l_add, 'link_del': l_del}


def build(conn, full=False):
    """델타(또는 전체본) 파일을 만든다 → dict(file, seq, stats).

    ⚠ **만들기만 하고 올리지 않는다** — 올리는 것은 배포 센터의 몫이고,
      그래야 「미리보기 → 확인 → 업로드」 순서가 지켜진다."""
    st = _load(STATE, {'seq': 0}) or {'seq': 0}
    new = snapshot(conn)
    old = None if full else _load(LAST)
    m_out, l_out, stats = diff(old, new)
    # ⚠⚠ **전체본은 시퀀스를 먹지 않는다**(2026-09-03 검거) — 전체본이 새
    #   번호를 차지하면 그 번호의 **델타 파일이 없어** 체인에 구멍이 난다.
    #   커서가 그 앞에 있는 사용자는 없는 `linkpack_000NN.json` 을 영영 찾고
    #   커서가 안 올라 **최신이 되지 못한다**. 전체본은 「지금 시퀀스의
    #   스냅샷」이다.
    seq = int(st.get('seq', 0)) + (0 if full else 1)
    if full:
        body = {'seq': seq, 'full': True,
                'media': list(new['media'].values()),
                'links': list(new['links'].values())}
        name = 'linkpack_full.json'
        stats = {'add': len(body['media']), 'mod': 0, 'del': 0,
                 'link_add': len(body['links']), 'link_del': 0}
    else:
        if not m_out and not l_out:
            # ⚠ 델타는 안 만들어도 **manifest 는 갱신한다** — 「최신은 여기까지」
            #   를 알리는 표지라 없거나 낡으면 받는 쪽이 옛 방식으로 물러선다.
            _save(MANIFEST, manifest_body(conn, int(st.get('seq', 0))))
            return {'file': None, 'seq': st.get('seq', 0), 'stats': stats,
                    'msg': '바뀐 것이 없다 — 델타를 만들지 않았다(manifest 갱신)'}
        body = {'seq': seq, 'media': m_out, 'links': l_out}
        name = 'linkpack_%05d.json' % seq
    path = _save(name, body)
    _save(LAST, new)
    st['seq'] = seq
    st['last_file'] = name
    if full:
        # ★★ **전체본에 도장을 찍는다**(2026-09-29 293차) — 「이 전체본을
        #   올렸나」는 시퀀스가 아니라 **이 도장**으로 판정한다(`pending_files`).
        #   그전에는 `uploaded_full != seq` 로 재어 **델타를 만들 때마다 낡은
        #   전체본을 다시 올렸다**(하네스가 잡았다 — 매일 3.7MB 헛 업로드).
        import time as _t
        st['full_stamp'] = '%d' % int(_t.time() * 1000)
    _save(STATE, st)
    # ★★ **manifest 를 함께 낸다**(2026-09-03) — 받는 쪽이 「내가 얼마나
    #   밀렸나」를 **수백 바이트로** 먼저 안다. 그전에는 델타를 하나씩 받아
    #   보며 404 가 날 때까지 두드렸고, 오래 안 켠 사용자는 **델타 30개를
    #   받아 적용한 뒤 전체본까지 또 받아 31회**를 내려받았다.
    #   ⇒ 이제 manifest 한 번으로 「델타 n개」냐 「전체본 하나」냐가 갈린다.
    _save(MANIFEST, manifest_body(conn, seq))
    return {'file': path, 'seq': seq, 'stats': stats, 'msg': ''}


#: 자산 목록(`items`)을 manifest 에 실을까 — **정비가 끝나면 켠다**.
#: ⚠ 켜기 전에 반드시 **팩을 먼저 올린다**(목록이 팩보다 먼저 가면 안 된다).
PUBLISH_ITEMS = False          # ⚠ 기본값일 뿐 — 실제 판정은 `publish_items_on(conn)`
PUBLISH_ITEMS_KEY = 'PACK_PUBLISH_ITEMS'


def publish_items_on(conn):
    """자산 목록(`items`)을 manifest 에 실을까 — **관리자 스위치**(2026-09-29 293차).

    배포 센터 ▸ 배포 대기 탭의 체크가 `sys_config[PACK_PUBLISH_ITEMS]` 에 적는다.
    없으면 옛 상수(`PUBLISH_ITEMS`)를 따른다.
    """
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (PUBLISH_ITEMS_KEY,)).fetchone()
        if r is not None:
            return str(r[0]).strip() in ('1', 'true', 'True', 'ON', 'on')
    except Exception:
        pass
    return bool(PUBLISH_ITEMS)


def set_publish_items(conn, on):
    conn.execute("INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
                 " ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                 (PUBLISH_ITEMS_KEY, '1' if on else '0'))
    conn.commit()


def manifest_body(conn, seq):
    """manifest 내용 → `{latest, full, releases:[…]}`.

    ★★★ **사용자가 「무엇이 달라졌나」를 볼 수 있게 릴리스 노트를 함께 싣는다**
      (2026-09-04 사용자 지시 「다운로드 받을 때 **버전, 게시일, 달라진 내용**
      등을 알 수 있게 표시하는 기능이 필요하다」).
      ⚠⚠ 그전 manifest 는 `{latest, full}` **34바이트**뿐이라 받는 쪽이 「몇
        번까지 있다」만 알았다. 사용자 PC 에는 `sys_pack_history` 가 **없으므로**
        (관리자 DB 다) 이력을 볼 길이 아예 없었다.
      ⇒ 이력에서 최근 것을 실어 보낸다. 수백 바이트 → 수 KB 로 늘 뿐이다.
    ⚠ **받는 쪽 규약을 안 깬다** — `latest`·`full` 은 그대로 두고 칸만 더한다.
      옛 앱은 `releases` 를 모른 채 그냥 지나간다.
    ⚠ 이력이 없거나 못 읽어도 **manifest 는 나가야 한다** — 그것이 없으면 받는
      쪽이 옛 방식으로 물러선다(§191차).
    """
    body = {'latest': int(seq),
            'full': os.path.exists(_dist('linkpack_full.json'))}
    try:
        import db_pack_history as PH
        rel = []
        # ★ **게시판 글까지 함께 싣는다** — 사용자 PC 에는 관리자 DB 가 없어
        #   여기 안 실으면 「자세한 내용·주의사항」을 볼 길이 아예 없다.
        for r in PH.catalog(conn, limit=40):
            # ⚠ **전체본(CORE)은 사용자 목록에 안 낸다** — 그것은 새 설치자가
            #   한 번에 받는 스냅샷이지 「이번에 무엇이 바뀌었나」가 아니다.
            #   목록에 섞이면 같은 내용이 두 번 보인다.
            if r['kind'] != 'DELTA':
                continue
            e = {'seq': r['seq'], 'kind': r['kind'],
                 'made_at': r['made_at'], 'n_items': r['n_items'],
                 'bytes': r['bytes'], 'note': r['note'],
                 'title': r['title'], 'detail': r['detail'],
                 'caution': r['caution']}
            # ★★ **다른 언어 글도 함께**(282차 ①) — 사용자 PC 에는 관리자
            #   DB 가 없어 여기 안 실으면 그 언어로 읽을 길이 아예 없다.
            #   ⚠ 옛 앱은 `i18n` 을 모른 채 지나가고 위 세 칸을 읽는다
            #     (규약을 안 깬다 — 칸만 더한다).
            if r.get('i18n'):
                e['i18n'] = r['i18n']
            rel.append(e)
        if rel:
            body['releases'] = rel
    except Exception:
        pass
    # ★★★ **받을 수 있는 자산 목록을 함께 싣는다**(2026-09-04 ⑩) — 사용자
    #   PC 에는 `sys_pack_item` 이 없다(관리자 DB). 이것이 없으면 사용자
    #   화면은 **「내가 이미 가진 것」밖에 못 보인다** — 무엇을 더 받을 수
    #   있는지 알 길이 없다.
    #   ⚠ 항목당 ~90바이트라 175개면 16KB. manifest 가 그만큼 커진다.
    #   ⚠ **판이 0인 것(아직 안 만든 것)은 뺀다** — 받을 수 없는 것을 목록에
    #     내면 눌러도 아무 일이 없다(§0-1).
    # ★★★ **정비 중에는 자산 목록을 안 싣는다**(2026-09-04 사용자 결정
    #   「지금은 사용자, 관리자 앱 모두 **총체적 정비**를 해야 할 시점이다.
    #   정비 중에 올리는 것도 **나중에 한번만** 하면 된다」).
    #   ⚠⚠ 목록만 싣고 팩을 안 올리면 사용자가 눌러도 **「서버에 없다」**만
    #     나온다 — 있지도 않은 것을 목록에 내지 않는다(§0-1).
    #   ⇒ 정비가 끝나 팩을 올리는 날 `PUBLISH_ITEMS=True` 로 켠다.
    if not publish_items_on(conn):
        return body
    try:
        import db_pack_item as PI
        items = []
        for x in PI.items(conn):
            if not x['version']:
                continue
            # ★ 자산 안내문(`note`)도 싣는다(2026-09-29 · 1.txt 22-4) — 그전에는
            #   관리자 메모로만 남고 사용자에게 한 자도 안 갔다.
            items.append({'kind': x['kind'], 'key': x['key'],
                          'lang': x['lang'], 'variant': x['variant'],
                          'note': x.get('note') or '',
                          'title': x['title'], 'version': x['version'],
                          'bytes': x['n_bytes'], 'made_at': x['made_at']})
        if items:
            body['items'] = items
    except Exception:
        pass
    # ★★★ **코어를 주기별 파일로 싣는다**(2026-09-05 릴리스 패킹).
    #   ⚠⚠ 이것이 없으면 받는 쪽이 **파일 이름을 짐작**해야 한다 — 주기 배정을
    #     바꾸면 그 순간 어긋난다(§팩 작업 규칙 ⑩ 「이름은 목록이 짓는다」).
    #   ★ **순서를 함께 싣는다**(`db_pack_stat.apply_order` = 느린 것부터) —
    #     연결이 껍데기를 가리키므로 거꾸로 넣으면 가리킬 것이 없는 연결이 난다.
    #     받는 쪽이 이 차례대로 넣으면 된다.
    try:
        import db_pack_core as PK
        import db_pack_release as RL
        core = []
        rel = RL.item_release(conn, 'CORE')
        for cy in PK.core_cycles(conn):
            fn = PK.core_name(cy)
            p = _dist(fn)
            if not os.path.exists(p):
                continue          # ⚠ 없는 파일을 목록에 내지 않는다(§0-1)
            core.append({'cycle': cy, 'file': fn, 'release': rel,
                         'bytes': os.path.getsize(p)})
        if core:
            body['core'] = core
    except Exception:
        pass
    return body


def _full_pending(st):
    """전체본을 올려야 하나 — 도장(`full_stamp`)이 올린 도장과 다를 때만.

    ⚠ 옛 상태(도장이 없는 state.json)는 옛 잣대(`uploaded_full != seq`)로 —
      실 상태가 그렇다(9/9 에 만든 전체본이 아직 안 올라갔다).
    """
    if 'full_stamp' in st:
        return st.get('uploaded_full_stamp') != st.get('full_stamp')
    return st.get('uploaded_full') != st.get('seq')


def pending_files():
    """아직 안 올린 파일 → [이름…]. 상태의 `uploaded` 이후 것.

    ⚠ 올린 것을 다시 올리지 않는다 — 델타는 시퀀스가 곧 신원이라 같은 것을
      또 올리면 받는 쪽이 ALREADY 로 넘길 뿐이지만, 이력이 지저분해진다."""
    st = _load(STATE, {}) or {}
    up = int(st.get('uploaded', 0))
    seq = int(st.get('seq', 0))
    out = []
    for i in range(up + 1, seq + 1):
        n = 'linkpack_%05d.json' % i
        if os.path.exists(_dist(n)):
            out.append(n)
    # 전체본은 시퀀스와 별개로 늘 최신이 하나 — **새로 만든 것만** 올린다
    if os.path.exists(_dist('linkpack_full.json')) and _full_pending(st):
        out.append('linkpack_full.json')
    # ★ manifest 는 **늘 마지막에 올린다** — 이것이 「최신은 여기까지」를
    #   알리는 표지라, 델타보다 먼저 올라가면 아직 없는 파일을 받으러 간다.
    if out and os.path.exists(_dist(MANIFEST)):
        out.append(MANIFEST)
    return out


def upload(servers, names=None, published_at=None):
    """만든 파일을 서버에 올린다 → (결과 목록, 올린 파일).

    ★ **rss_publish._upload 를 그대로 쓴다** — 서버 어댑터(GIT/HTTP/LOCAL)·
      이력 기록·flush 가 거기 있다. 여기서 다시 만들면 두 벌이 된다.
    ⚠ **만들기와 올리기를 갈라 둔다** — 미리 보고 확인한 뒤에 올린다.
    """
    import rss_publish as RP
    from datetime import datetime
    names = names or pending_files()
    if not names:
        return [], []
    files = {}
    for n in names:
        with open(_dist(n), encoding='utf-8') as f:
            files[n] = f.read()
    pub = published_at or datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    stats = {'row_count': sum(len(json.loads(t).get('media') or [])
                              for t in files.values()),
             'sha1': ''}
    res = RP._upload(servers, files, pub, stats)
    st = _load(STATE, {}) or {}
    seqs = [int(n[9:14]) for n in names if n.startswith('linkpack_0')]
    if seqs:
        st['uploaded'] = max(int(st.get('uploaded', 0)), max(seqs))
    if 'linkpack_full.json' in names:
        st['uploaded_full'] = st.get('seq')
        st['uploaded_full_stamp'] = st.get('full_stamp')
    st['uploaded_at'] = pub
    _save(STATE, st)
    # jsDelivr 캐시 무효화 — 안 하면 최대 12시간 옛 파일이 나간다
    try:
        import rss_transport as RT
        RT.purge_jsdelivr(names)
    except Exception:
        pass
    return res, names


def publish(conn, servers=None, full=False, log=None):
    """★★★ **델타를 만들고 안 올린 것을 올린다 — 한 문**(2026-09-29 293차).

    매일 자동 전송(`collect_channels._auto_publish`)과 CLI(`db_rss_upload
    --links`)가 이것을 부른다. 화면의 [델타 만들기]·[올리기]는 두 걸음을 따로
    두지만 하는 일은 같다.
    ⚠ **바뀐 것이 없으면 만들지 않고, 안 올린 것이 없으면 올리지 않는다** —
      같은 것을 또 올리면 사용자가 헛것을 받는다.
    ⚠ 서버가 없으면 **그렇다고 말한다**(조용히 0건으로 끝내지 않는다 §0-1).
    → {'built','seq','stats','uploaded','results','msg'}
    """
    import rss_publish as RP
    servers = servers if servers is not None else RP.get_servers()
    live = [x for x in servers if x.get('enabled', True)]
    out = {'built': False, 'seq': None, 'stats': None,
           'uploaded': [], 'results': [], 'msg': ''}
    if not live:
        out['msg'] = '등록된(사용) 서버가 없다 — 배포 센터 ▸ 서버 관리'
        return out
    r = build(conn, full=full)
    if r.get('file'):
        out.update(built=True, seq=r['seq'], stats=r['stats'])
    else:
        out['msg'] = r.get('msg') or ''
    names = pending_files()
    if not names:
        if log:
            log('  영상 연결 — 올릴 것이 없다 (%s)' % (out['msg'] or '바뀐 것 없음'))
        return out
    res, up = upload(live, names)
    out['uploaded'] = list(up)
    out['results'] = res
    if log:
        for x in res:
            log('  영상 연결 %s [%s] %s · %s bytes'
                % (x['status'], x['server'], x['message'],
                   format(x['bytes'], ',d')))
    return out


def status(conn):
    new = snapshot(conn)
    old = _load(LAST)
    _m, _l, stats = diff(old, new)
    st = _load(STATE, {'seq': 0}) or {'seq': 0}
    return {'media': len(new['media']), 'links': len(new['links']),
            'seq': int(st.get('seq', 0)), 'stats': stats,
            'first': old is None,
            'uploaded': int(st.get('uploaded', 0)),
            'uploaded_at': st.get('uploaded_at', ''),
            'pending': pending_files()}


def selftest():
    import sqlite3
    import shutil
    import tempfile
    global DIST
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    tmp = tempfile.mkdtemp()
    keep, DIST = DIST, tmp                     # ⚠ 실 배포 폴더를 안 건드린다
    try:
        conn = sqlite3.connect(':memory:')
        conn.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
                     " media_type TEXT, format_type TEXT, title TEXT,"
                     " description TEXT, url TEXT, lang_code TEXT,"
                     " sort_order INT, is_active INT, record_status TEXT)")
        conn.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
                     " link_type TEXT, clicked_id INT, target_id INT,"
                     " rel_code TEXT, end_id INT, record_status TEXT)")
        conn.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
                     " entity_code TEXT)")
        conn.execute("CREATE TABLE sys_pericope_asset(pericope_id INTEGER"
                     " PRIMARY KEY, peri_code TEXT)")
        conn.execute("INSERT INTO sys_entity_master VALUES(7,'P_DAVID')")
        conn.execute("INSERT INTO sys_pericope_asset VALUES(50,'GEN_01_BODY_1')")
        # ⚠ 설명문을 **일부러 채워 둔다** — 팩에 안 실리는지 재기 위해서다.
        conn.execute("INSERT INTO sys_media_asset VALUES(1,'SERMON','VIDEO',"
                     "'승인됨','{\"yt_desc\": \"남의 글\", \"channel\": \"C\"}',"
                     "'https://a','ko',0,1,'LIVE')")
        conn.execute("INSERT INTO sys_media_asset VALUES(2,'SERMON','VIDEO',"
                     "'검토중','','https://b','KO',0,0,'LIVE')")
        conn.execute("INSERT INTO sys_link_asset VALUES(1,'MEDI_ENTI',1,7,"
                     "NULL,NULL,'LIVE')")
        conn.execute("INSERT INTO sys_link_asset VALUES(2,'MEDI_PERI',1,50,"
                     "NULL,NULL,'LIVE')")
        conn.execute("INSERT INTO sys_link_asset VALUES(3,'MEDI_ENTI',2,7,"
                     "NULL,NULL,'LIVE')")
        snap = snapshot(conn)
        t('★ 승인된 것만 싣는다(is_active=1)', list(snap['media']) == ['1'],
          list(snap['media']))
        t('승인 안 된 미디어의 연결은 안 나간다', len(snap['links']) == 2,
          len(snap['links']))
        t('lang_code 대문자', snap['media']['1']['lang_code'] == 'KO')
        # ★★★ **설명문은 배포하지 않는다**(2026-09-04 사용자 지시).
        #   DB 에는 있는데 팩에는 없어야 한다 — 되돌아가지 못하게 잠근다.
        t('★ 팩에 설명문이 안 실린다', snap['media']['1']['description'] == '',
          repr(snap['media']['1']['description'])[:40])
        t('★ 원본 DB 는 그대로다(판정 재료는 남긴다)',
          'yt_desc' in (conn.execute("SELECT description FROM sys_media_asset"
                                     " WHERE media_id=1").fetchone()[0] or ''))
        vals = list(snap['links'].values())
        t('엔티티는 자연 열쇠(code)',
          any(v.get('target_code') == 'P_DAVID' for v in vals))
        t('단락도 자연 열쇠(peri_code)',
          any(v.get('target_peri') == 'GEN_01_BODY_1' for v in vals))
        r = build(conn, full=True)
        t('전체본 생성', r['file'] and os.path.exists(r['file']))
        t('전체본은 full 표식', _load('linkpack_full.json').get('full') is True)
        r2 = build(conn)
        t('바뀐 것 없으면 델타 안 만든다', r2['file'] is None, r2['msg'])
        # 수정 + 추가 + 삭제
        conn.execute("UPDATE sys_media_asset SET title='고침' WHERE media_id=1")
        conn.execute("INSERT INTO sys_media_asset VALUES(3,'SERMON','VIDEO',"
                     "'새것','','https://c','KO',0,1,'LIVE')")
        conn.execute("INSERT INTO sys_link_asset VALUES(4,'MEDI_ENTI',3,7,"
                     "NULL,NULL,'LIVE')")
        r3 = build(conn)
        d3 = _load(os.path.basename(r3['file']))
        t('델타 — 수정 1 · 추가 1', r3['stats']['mod'] == 1
          and r3['stats']['add'] == 1, r3['stats'])
        # ⚠ **전체본은 시퀀스를 안 먹는다**(체인에 구멍이 나므로) —
        #   전체본이 seq 0, 첫 델타가 seq 1 이다.
        t('★ 전체본은 시퀀스를 안 먹는다', r['seq'] == 0, r['seq'])
        t('델타 시퀀스가 오른다', d3['seq'] == 1, d3['seq'])
        t('바뀐 것만 담긴다(전체 아님)', len(d3['media']) == 2, len(d3['media']))
        # 삭제 — 승인을 내리면 묘비
        conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id=3")
        r4 = build(conn)
        d4 = _load(os.path.basename(r4['file']))
        tomb = [m for m in d4['media']
                if m.get('record_status') == 'DELETED']
        t('★ 승인 내리면 묘비로 나간다', len(tomb) == 1
          and tomb[0]['media_id'] == 3, tomb)
        t('딸린 링크도 묘비',
          any(l.get('record_status') == 'DELETED' for l in d4['links']))
        # 만든 델타를 실제로 받는 쪽에 먹여 본다 — 왕복이 맞아야 뜻이 있다
        import db_linkpack_sync as SYNC
        import link_pack
        pk_path = os.path.join(tmp, 'link_pack.db')
        link_pack.ensure(pk_path)
        pk = sqlite3.connect(pk_path)
        SYNC.apply_full(pk, _load('linkpack_full.json'), conn)
        n0 = pk.execute('SELECT COUNT(*) FROM pack_media').fetchone()[0]
        t('★ 받는 쪽이 전체본을 먹는다', n0 == 1, n0)
        nl0 = pk.execute('SELECT COUNT(*) FROM pack_link').fetchone()[0]
        t('★ 자연 열쇠가 번호로 풀린다', nl0 == 2, nl0)
        SYNC.apply_delta(pk, d3, conn)
        ttl = pk.execute("SELECT title FROM pack_media WHERE media_id=1"
                         ).fetchone()[0]
        t('델타 적용 — 수정 반영', ttl == '고침', ttl)
        SYNC.apply_delta(pk, d4, conn)
        n1 = pk.execute("SELECT COUNT(*) FROM pack_media WHERE media_id=3"
                        ).fetchone()[0]
        t('델타 적용 — 묘비로 사라짐', n1 == 0)
        pk.close()
        # ★★★ publish — 델타 만들기 + 안 올린 것 올리기, 한 문(2026-09-29 293차).
        #   ⚠ 실 서버·admin_state 를 안 건드린다 — LOCAL_DIR 서버 + 기록 문을
        #     잠깐 막는다(purge 는 망으로 나가니 함께 막는다).
        import rss_publish as _RP
        import rss_transport as _RT
        from admin import admin_state as _A
        srvdir = os.path.join(tmp, 'srv')
        srv = [{'label': 't', 'role': 'PRIMARY', 'transport': 'LOCAL_DIR',
                'location': srvdir, 'enabled': True}]
        _keep = (_RP._append_log, _A.set_, _RT.purge_jsdelivr)
        _RP._append_log = lambda *a, **k: None
        _A.set_ = lambda *a, **k: None
        _RT.purge_jsdelivr = lambda *a, **k: {}
        try:
            conn.execute("INSERT INTO sys_media_asset VALUES(4,'SERMON','VIDEO',"
                         "'넷','','https://d','KO',0,1,'LIVE')")
            conn.execute("INSERT INTO sys_link_asset VALUES(5,'MEDI_ENTI',4,7,"
                         "NULL,NULL,'LIVE')")
            r5 = publish(conn, srv)
            t('★★★ publish — 델타를 만들고', r5['built'] and r5['seq'] == 3,
              str(r5.get('seq')))
            t('  안 올린 것을 전부 올린다(manifest 가 마지막)',
              r5['uploaded'] and r5['uploaded'][-1] == MANIFEST
              and 'linkpack_00001.json' in r5['uploaded'], str(r5['uploaded']))
            t('  서버 폴더에 파일이 실제로 있다',
              os.path.exists(os.path.join(srvdir, MANIFEST))
              and os.path.exists(os.path.join(srvdir, 'linkpack_00003.json')))
            st5 = _load(STATE) or {}
            t('  올린 시퀀스가 기록된다', int(st5.get('uploaded', 0)) == 3, str(st5))
            r6 = publish(conn, srv)
            t('★★ 바뀐 것 없으면 만들지도 올리지도 않는다',
              not r6['built'] and not r6['uploaded'], str(r6.get('msg'))[:40])
            r7 = publish(conn, [dict(srv[0], enabled=False)])
            t('★ 서버가 없으면 그렇다고 말한다', '서버' in r7['msg'], r7['msg'])
        finally:
            _RP._append_log, _A.set_, _RT.purge_jsdelivr = _keep
        conn.close()
    finally:
        DIST = keep
        shutil.rmtree(tmp, ignore_errors=True)
    print('db_linkpack_build selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--full' in sys.argv or '--delta' in sys.argv:
            r = build(conn, full=('--full' in sys.argv))
            if r['file']:
                print('만듦: %s (seq %d)' % (r['file'], r['seq']))
                print('  추가 %(add)d · 수정 %(mod)d · 삭제 %(del)d'
                      ' · 링크 %(link_add)d/%(link_del)d' % r['stats'])
            else:
                print(r['msg'])
        elif '--upload' in sys.argv:
            import rss_transport as RT
            from admin import admin_state as A
            srv = A.get('rss_transfer', 'servers', None) or RT.client_servers()
            names = pending_files()
            if not names:
                print('올릴 것이 없다 — 먼저 --full 또는 --delta')
            else:
                print('올릴 파일: %s' % ', '.join(names))
                res, up = upload(srv, names)
                for r in res:
                    print('  %s [%s] %s · %s bytes'
                          % (r['status'], r['server'], r['message'],
                             format(r['bytes'], ',d')))
        else:
            s = status(conn)
            print('배포 대상 — 미디어 %s · 링크 %s'
                  % (format(s['media'], ',d'), format(s['links'], ',d')))
            print('마지막 시퀀스 %d%s' % (s['seq'],
                                      ' (아직 배포한 적 없음)' if s['first']
                                      else ''))
            st = s['stats']
            print('이전 배포본 대비 — 추가 %d · 수정 %d · 삭제 %d'
                  ' · 링크 %d/%d' % (st['add'], st['mod'], st['del'],
                                    st['link_add'], st['link_del']))
    finally:
        conn.close()
