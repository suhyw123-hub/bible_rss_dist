# -*- coding: utf-8 -*-
"""db_alias_head.py — 영어 이름의 「괄호 앞 낱말」을 별명으로 올린다 (영구 도구).

2026-09-09 신설. 사용자 지시 「영어이름 괄호는 진행하라」 · 0.txt 13번.

★★★ **왜 필요한가** — 우리 EN 이름은 `Resurrection (anastasis)` 꼴로 괄호에 원어
  음역을 넣는다. 그런데 연결기는 이름표를 **가운뎃점(`·`)으로만 쪼개고 괄호는 안
  쪼갠다**. 그래서 제목이 「Resurrection Power」여도 통째 문자열을 찾다 못 찾는다.
  실측(연결기를 직접 돌려서):
      The Second Coming of Christ  →  없음   (이름 `Second Coming (Parousia)`)
      Resurrection Power           →  없음   (이름 `Resurrection (anastasis)`)
      The Garden of Eden           →  걸린다 (괄호가 없다)
  정성 엔티티 EN 이름 461개 중 **120개(26%)가 괄호를 갖고 있다.**

⚠⚠⚠ **그런데 괄호 앞을 통째로 열면 안 된다 — 실측이 막았다.**
  113개 머리를 다 열고 연결기를 4,307편 EN 제목에 돌리니 **878편(20%)이 더 걸렸는데**
  무작위 20편을 읽어 보니 **정당한 것이 5편뿐**이었다:
      Holy   105편 ← 「The Holy Bible」 낭독 채널
      Joshua 119편 ← 여호수아**서** · 「Apostle Joshua Selman」
      Gospel  48편 ← 「Daily Gospel 689」 채널 시리즈
      Know    40편 ← 「6 Things You Didn't Know About Peter」
      Blameless 5편 ← **호러 게임 walkthrough · 음악 비디오**
  §195차 「엘」(EN `Er`)이 chapter·Never 에 걸려 2,716줄을 오연결한 그 자리와 같다.
  사용자도 같은 것을 짚었다 — 「God (el) 이것 오류 많이 나온 것이다 · 엘 너무 흔하게
  연결되었었다」.

★★★ **그래서 잣대는 낱말 길이도 낱말 수도 아니다 — 「성경 문맥 밖에서 거의 안 쓰이는
  말인가」다.** 머리마다 실제로 걸리는 제목을 읽어 채택/기각했다(§165차 「제목 신호와
  대표겹침을 겹친다」와 같은 방식 — 기계가 후보를 내고 사람이 고른다).

⚠ 기각한 것을 **근거와 함께 남긴다**(`REJECT`) — 안 적어 두면 다음에 또 열려 한다.
⚠ 머리가 겹치면 자동으로 뺀다(`God` ← 엘로힘·엘 · `James` ← 주의 형제·알패오의
  아들 · `Sea Crossing` ← 홍해 남·북). 어느 쪽인지 못 가르기 때문이다.
⚠ **W_ 기계 낱말은 대상이 아니다** — §181차가 「분류 단추의 일은 훑어보기」로 목록에서
  뺐고 낱말연결도 일부러 안 만든다. 여기에 별명을 달면 티커가 음역으로 뒤덮인다.

사용법:
    python db_alias_head.py --selftest
    python db_alias_head.py --list      # 채택·기각 목록과 근거
    python db_alias_head.py --check     # 무엇이 바뀌는지만
    python db_alias_head.py --apply     # 별명 등록(멱등)
    python db_alias_head.py --undo      # 이 도구가 넣은 별명만 걷는다
"""
from __future__ import annotations

import sys

import appdb
import entity_aliases as EA

#: 채택 — 그 낱말이 성경 문맥 밖에서 거의 안 쓰인다(표본을 읽고 정했다).
#:   (머리, 엔티티 코드, 표본에서 본 것)
ADOPT = [
    ('Resurrection',   'T_ANASTASIS',  '전부 예수 부활 · 21편'),
    ('Incense',        'T_QETORET',    '전부 분향단(출30) · 13편'),
    ('Flood',          'T_MABBUL',     '전부 노아 홍수 · 13편'),
    ('Clean',          'T_TAHER',      '전부 레11 정결·부정 · 12편'),
    ('Forgiveness',    'T_SALACH',     '속건제·나단과 다윗 · 10편'),
    ('Unclean',        'T_TAME',       '전부 레11 · 8편'),
    ('Second Coming',  'D_PAROUSIA',   '전부 재림·파루시아 · 7편'),
    ('Transgression',  'T_PESHA',      '전부 페샤 낱말 공부 · 6편'),
    ('Trespass',       'T_PARAPTOMA',  '전부 속건제(레5~6) · 5편'),
    ('Compassion',     'T_RACHAM',     '출21~22 긍휼 · 5편'),
    ('Hosts',          'T_TSEVAOT',    '전부 만군(체바오트) · 5편'),
    ('Iniquity',       'T_AVON',       '전부 아온 · 4편'),
    ('Burial',         'T_QABAR',      '전부 사라의 장사(창23) · 4편'),
    ('Thanksgiving',   'T_TODAH',      '토다 감사제 · 4편'),
    ('Create',         'T_BARA',       '전부 바라 낱말 공부 · 4편'),
    ('Steadfast love', 'T_HESED',      '전부 헤세드 낱말 공부 · 3편'),
    ('Lawlessness',    'T_ANOMIA',     '전부 아노미아 · 3편'),
]

#: 기각 — 열면 안 되는 머리와 **왜**(실측한 오탐). 다시 열려 하지 말 것.
REJECT = [
    ('Joshua',  '여호수아**서**와 「Apostle Joshua Selman」이 대부분 · 119편'),
    ('Holy',    '「The Holy Bible」 낭독 채널 · 성령 · 성지 · 105편'),
    ('Lord',    '「주」 일반 · 70편'),
    ('Death',   '사라의 죽음·사형제도 같은 일반 죽음 · 60편'),
    ('Man',     '「Mysterious Man」 같은 사람 일반 · 53편'),
    ('Gospel',  '「Daily Gospel 689」 채널 시리즈 · 복음서 이름 · 48편'),
    ('Know',    '「Things You Didn\'t Know About Peter」 · 40편'),
    ('Love',    '「Faith, Love and Redemption」 꼴의 관용구 · 27편'),
    ('Prayer',  '기도 일반 · 26편'),
    ('Prophecy', '종말 예언 채널 · 25편'),
    ('Good',    '「GOOD ENOUGH」 · 「Good provides」(God 오타) · 24편'),
    ('Name',    '「change Abram\'s name」 같은 일반 용법 · 22편'),
    ('Mary',    '베다니 마리아·가톨릭 마리아와 겹친다(동명이인) · 22편'),
    ('Glory',   '관용구 · 21편'),
    ('Mystery', '「The Mystery Of Genesis」 제목투 · 20편'),
    ('Bread',   '「Bread of His Presence」 채널 이름 · 18편'),
    ('Heart',   '「God\'s Own Heart」 관용구 · 16편'),
    ('Wisdom',  '「Business Lessons … Wisdom For Dominion」 · 15편'),
    ('Power',   '「Power, Miracles & Authority」 · 14편'),
    ('Way',     '「go their own way」 · 13편'),
    ('Blood',   '애굽 재앙의 피와 제의의 피가 섞인다 · 12편'),
    ('Water',   '물 일반 · 12편'),
    ('Wrath',   '진노 일반 · 12편'),
    ('Trust',   '「Trust God\'s Timing」 일반 권면 · 11편'),
    ('Bless',   '축복 일반 · 10편'),
    ('Light',   '빛 일반 · 8편'),
    ('Fear',    '「365 days of no fear journey」 · 8편'),
    ('Oil',     '기름 일반 · 8편'),
    ('Flesh',   '살 일반 · 7편'),
    ('Remember', '「3 Reasons to Remember」 일반 권면 · 7편'),
    ('Shame',   '수치 일반 · 6편'),
    ('Evil',    '악 일반 · 6편'),
    ('Teaching', '「Biblical Teaching Library」 채널 · 6편'),
    ('Walk',    '「WALK ANCIENT ROME」 · 「Walking Through the Bible」 시리즈 · 6편'),
    ('Joy',     '기쁨 일반 · 5편'),
    ('Rock',    '반석과 바위가 안 갈린다 · 5편'),
    ('Servant', '「his servant Bilhah」 · 5편'),
    ('Blameless', '**호러 게임 walkthrough · 음악 비디오** · 5편'),
    ('Sin',     '죄 일반 · 「Sinai」 · 50편'),
    ('Door',    '문 일반 · 4편'),
    ('Throne',  '왕좌 일반 · 4편'),
    ('Cup',     '「Cup-Bearer」 술 맡은 관원 · 요셉의 은잔 · 3편'),
    ('Knowledge', '「medical knowledge」 · 3편'),
]

#: 겹치는 머리는 규칙으로 뺀다 — 어느 엔티티인지 못 가른다.
COLLIDE = ('God', 'James', 'Sea Crossing')

_LANG = 'EN'


def _rows(conn):
    """{코드: (entity_id, EN 이름)} — 정성 엔티티만."""
    out = {}
    for eid, code, nm in conn.execute(
            "SELECT em.entity_id, em.entity_code, t.contents "
            "FROM sys_text_asset t JOIN sys_entity_master em ON em.entity_id=t.clicked_id "
            "WHERE t.text_type='ENTITY_NAME' AND UPPER(t.lang_code)=? "
            "  AND em.record_status='LIVE' AND substr(em.entity_code,1,2) <> 'W_'",
            (_LANG,)):
        out[code] = (eid, nm or '')
    return out


def heads(conn) -> dict:
    """지금 DB 의 괄호 이름에서 머리를 뽑는다 → {머리: [코드…]}.

    ⚠ 채택 목록을 **DB 와 맞춰 보는 데** 쓴다 — 이름이 바뀌면 그 자리에서 드러난다.
    """
    out = {}
    for code, (eid, nm) in _rows(conn).items():
        if '(' not in nm:
            continue
        h = nm.split('(')[0].strip().rstrip(',').strip()
        if len(h) >= 3:
            out.setdefault(h, []).append(code)
    return out


def check(conn) -> tuple:
    """(넣을 것, 문제) — 넣을 것 = [(코드, 머리)]."""
    todo, bad = [], []
    have = _rows(conn)
    now = heads(conn)
    for h, code, _why in ADOPT:
        if h in COLLIDE:
            bad.append('%s — 머리가 겹친다(COLLIDE)' % h)
            continue
        if code not in have:
            bad.append('%s — 없는 엔티티 %s' % (h, code))
            continue
        if len(now.get(h, [])) > 1:
            bad.append('%s — DB 에서 머리가 겹친다: %s' % (h, now[h]))
            continue
        if now.get(h, [None])[0] != code:
            bad.append('%s — 이름이 바뀌었다(지금 %s)' % (h, now.get(h)))
            continue
        # ⚠⚠ 머리가 **다른 엔티티의 맨 이름**과 같으면 안 된다 — 괄호 이름끼리만
        #   보면 못 잡는다(실측: `Joshua (High Priest)` 의 머리가 눈의 아들
        #   여호수아의 이름 `Joshua` 와 겹쳤다). 어느 쪽인지 못 가른다.
        clash = [k for k, (_e, n2) in have.items()
                 if k != code and n2.strip().lower() == h.lower()]
        if clash:
            bad.append('%s — 다른 엔티티의 이름과 같다: %s' % (h, clash))
            continue
        eid = have[code][0]
        cur = EA.aliases_for_lang(
            conn.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
                         (eid,)).fetchone()[0], _LANG)
        if h not in cur:
            todo.append((code, h))
    return todo, bad


def apply(conn) -> int:
    """별명을 넣는다(멱등) → 넣은 수. ⚠ 문제가 있으면 아무것도 안 넣는다."""
    todo, bad = check(conn)
    if bad:
        raise SystemExit('문제 %d건 — 넣지 않았다:\n  %s' % (len(bad), '\n  '.join(bad)))
    have = _rows(conn)
    n = 0
    for code, h in todo:
        eid = have[code][0]
        raw = conn.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
                           (eid,)).fetchone()[0]
        cur = list(EA.aliases_for_lang(raw, _LANG))
        cur.append(h)
        EA.update_aliases(conn, eid, _LANG, cur)
        n += 1
    conn.commit()
    return n


def undo(conn) -> int:
    """이 도구가 넣은 별명만 걷는다 → 걷은 수. 사람이 손으로 넣은 별명은 안 건드린다."""
    have = _rows(conn)
    n = 0
    for h, code, _why in ADOPT:
        if code not in have:
            continue
        eid = have[code][0]
        raw = conn.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
                           (eid,)).fetchone()[0]
        cur = list(EA.aliases_for_lang(raw, _LANG))
        if h in cur:
            cur = [x for x in cur if x != h]
            EA.update_aliases(conn, eid, _LANG, cur)
            n += 1
    conn.commit()
    return n


def _say(s):
    try:
        print(s)
    except Exception:
        sys.stderr.write(str(s) + '\n')


def _selftest() -> int:
    import sqlite3
    ok = [0, 0]

    def chk(name, cond):
        ok[0 if cond else 1] += 1
        _say('  %s %s' % ('PASS' if cond else 'FAIL', name))

    # ① 표가 스스로 어긋나지 않는다
    ad = [h for h, _c, _w in ADOPT]
    chk('채택 머리에 겹침 없다', len(ad) == len(set(ad)))
    chk('채택과 기각이 안 겹친다', not (set(ad) & {h for h, _ in REJECT}))
    chk('겹치는 머리는 채택에 없다', not (set(ad) & set(COLLIDE)))
    chk('기각에 근거가 다 있다', all(w.strip() for _h, w in REJECT))
    chk('채택에 근거가 다 있다', all(w.strip() for _h, _c, w in ADOPT))
    chk('★ 흔한 낱말을 안 열었다',
        not ({'God', 'Holy', 'Lord', 'Sin', 'Man', 'Good', 'Know', 'Way'} & set(ad)))

    # ② 시험 DB 로 왕복
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY, "
              "entity_code TEXT, entity_type TEXT, json_detail TEXT, record_status TEXT)")
    c.execute("CREATE TABLE sys_text_asset (clicked_id INTEGER, text_type TEXT, "
              "lang_code TEXT, contents TEXT)")
    c.execute("INSERT INTO sys_entity_master VALUES (1,'T_ANASTASIS','TERM',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (1,'ENTITY_NAME','EN','Resurrection (anastasis)')")
    # 겹치는 머리 — 넣으면 안 된다
    c.execute("INSERT INTO sys_entity_master VALUES (2,'T_ELOHIM','TERM',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (2,'ENTITY_NAME','EN','God (elohim)')")
    c.execute("INSERT INTO sys_entity_master VALUES (3,'T_EL','TERM',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (3,'ENTITY_NAME','EN','God (el)')")
    # W_ 낱말 — 대상이 아니다
    c.execute("INSERT INTO sys_entity_master VALUES (4,'W_H2416','TERM',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (4,'ENTITY_NAME','EN','chay (alive)')")

    h = heads(c)
    chk('머리를 뽑는다', h.get('Resurrection') == ['T_ANASTASIS'])
    chk('★ W_ 기계 낱말은 대상이 아니다', 'chay' not in h)
    chk('겹치는 머리를 그대로 보인다', sorted(h.get('God', [])) == ['T_EL', 'T_ELOHIM'])

    # 맨 이름과 겹치는 경우 — 넣으면 안 된다
    c.execute("INSERT INTO sys_entity_master VALUES (5,'P_JOSHUA','PERSON',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (5,'ENTITY_NAME','EN','Joshua')")
    c.execute("INSERT INTO sys_entity_master VALUES (6,'P_JOSHUA_PRIEST','PERSON',NULL,'LIVE')")
    c.execute("INSERT INTO sys_text_asset VALUES (6,'ENTITY_NAME','EN','Joshua (High Priest)')")

    todo, bad = check(c)
    chk('넣을 것을 선택한다', ('T_ANASTASIS', 'Resurrection') in todo)
    chk('★ 겹치는 God 은 안 선택한다', not any(x[1] == 'God' for x in todo))
    chk('없는 엔티티는 문제로 낸다', any('없는 엔티티' in b for b in bad))
    saved0 = list(ADOPT)
    try:
        globals()['ADOPT'] = [('Joshua', 'P_JOSHUA_PRIEST', '시험')]
        _t2, _b2 = check(c)
        chk('★ 머리가 다른 엔티티의 맨 이름과 같으면 막는다',
            not _t2 and any('다른 엔티티의 이름' in b for b in _b2))
    finally:
        globals()['ADOPT'] = saved0

    # 채택 목록을 이 시험 DB 로 좁혀 왕복
    saved = list(ADOPT)
    try:
        globals()['ADOPT'] = [('Resurrection', 'T_ANASTASIS', '시험')]
        n = apply(c)
        chk('넣는다', n == 1)
        raw = c.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=1").fetchone()[0]
        chk('별명으로 들어갔다', 'Resurrection' in EA.aliases_for_lang(raw, 'EN'))
        chk('★ 두 번 넣어도 안 는다', apply(c) == 0)
        chk('되돌린다', undo(c) == 1)
        raw = c.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=1").fetchone()[0]
        chk('★ 되돌리면 별명이 없다', 'Resurrection' not in EA.aliases_for_lang(raw, 'EN'))
        # 사람이 넣은 별명은 안 건드린다
        EA.update_aliases(c, 1, 'EN', ['Anastasis'])
        apply(c)
        undo(c)
        raw = c.execute("SELECT json_detail FROM sys_entity_master WHERE entity_id=1").fetchone()[0]
        chk('★ 사람이 넣은 별명은 안 걷는다',
            EA.aliases_for_lang(raw, 'EN') == ['Anastasis'])
    finally:
        globals()['ADOPT'] = saved
    c.close()
    _say('db_alias_head selftest %d/%d' % (ok[0], sum(ok)))
    return 0 if ok[1] == 0 else 1


def main(argv):
    if '--selftest' in argv:
        return _selftest()
    if '--list' in argv:
        _say('채택 %d개 — 성경 문맥 밖에서 거의 안 쓰이는 말' % len(ADOPT))
        for h, code, why in ADOPT:
            _say('  %-16s %-16s %s' % (h, code, why))
        _say('')
        _say('기각 %d개 — 열면 오탐이 난다' % len(REJECT))
        for h, why in REJECT:
            _say('  %-16s %s' % (h, why))
        _say('')
        _say('머리 겹침(규칙으로 제외): %s' % ', '.join(COLLIDE))
        return 0
    with appdb.connect('bible_master.db') as conn:
        if '--apply' in argv:
            _say('별명 %d개를 넣었다' % apply(conn))
        elif '--undo' in argv:
            _say('별명 %d개를 걷었다' % undo(conn))
        else:
            todo, bad = check(conn)
            _say('넣을 것 %d개' % len(todo))
            for code, h in todo:
                _say('  %-16s ← %s' % (h, code))
            if bad:
                _say('문제 %d건:' % len(bad))
                for b in bad:
                    _say('  ' + b)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
