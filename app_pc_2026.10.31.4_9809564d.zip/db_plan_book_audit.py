# -*- coding: utf-8 -*-
"""db_plan_book_audit.py — 도서 ↔ 플랜 정합성 점검 (영구 도구 · `--selftest` 의무)
================================================================================

**왜 만들었나** (2026-08-24 사용자 지시):
  「지난 번에 **책 자체를 잘못 다운로드 한 것**이 있었다. 이런 것은 **플랜
    데이터까지 모두 오류**다. 점검해야 한다」

실제로 그런 일이 세 번 있었다 — 바운즈가 **위작**이었고(구텐베르크 #16905 는
『The Great Red Frog』였다), 로렌스는 **발췌본 9,046자 → 전문 57,338자**로
갈아 끼웠고, 마이어는 **301편 → 1,189편**으로 재적재했다.

★★★ **위험한 것은 구조가 아니라 내용이다.** 책을 갈아 끼워도 `unit_id` 는
  살아남으므로 고아·일수 검사는 전부 통과한다. 그런데 **그 안의 글이 바뀌면
  플랜의 CORE 구절은 옛 글에 맞춰진 채 남는다.** 실제로 그 상태를 찾았다 —
  「아침과 저녁」 1편 본문은 `"They did eat…" Joshua 5:12` 인데
  `start_vid` 와 plan 47 의 CORE 는 **사43:1** 이다.

⇒ **본문이 스스로 밝히는 구절**을 뽑아 세 값과 삼각 대조한다:

      본문 인용  ↔  key_verse_ref  ↔  start_vid  ↔  플랜 CORE

  넷이 다 있으면서 갈리면 **글이 바뀐 것**이다. 다른 검사로는 안 잡힌다.

⚠ **마이어는 어긋나는 것이 정상이다**(§0-1b) — 유닛 `start_vid~end_vid` 가
  **장 전체**이고 정확한 절은 `key_verse_ref`·CORE 에 있다. 그래서 이 도구는
  「start_vid 가 그 장 안에 드는가」로 느슨하게 본다. **수치만 보고 결론짓지
  말 것** — 처음 쟀을 때 1,954일(69%)이 어긋난 것으로 나왔는데 대부분 정상이었다.

사용:
    python db_plan_book_audit.py --selftest      (의무)
    python db_plan_book_audit.py --check
    python db_plan_book_audit.py --book SPURGEON_ME
"""
import os
import re
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb
import scripture_ref_kr
import book_footnote

DB = 'bible_master.db'
HEAD_CHARS = 400        # 본문 머리에서 이만큼만 본다(인용은 맨 앞에 있다)

# ★★ **책 단위 게이트** — 그 책이 「본문에 구절을 밝히는 관행」이 있을 때만 잰다.
#   ⚠ 없으면 **오탐뿐이다**: 마이어는 1,189편 중 20편에서만 뽑히는데(1.7%) 그
#     20편은 앞 편의 각주 꼬리가 흘러든 OCR 잔재라 **전부 그 편의 구절이 아니다**.
#   ⚠ 마이어만 예외로 박지 않는다 — **비율로 판정**해야 책이 늘어도 따라온다.
#   실측 비율: 에더샤임 성전 100% · 아침과저녁 94% · 휫필드 87% · 피니 83% ·
#     웨슬리 75% · 천로역정 50% ↔ 머레이 45% · 밀러 16% · 마이어 2% · 켐피스 0%.
CITE_MIN = 0.50


# ─────────────────────────────────────────────────────────────
# 본문이 스스로 밝히는 구절
# ─────────────────────────────────────────────────────────────
# 장이 하나뿐인 책 — 「Jude 20」 「Philemon 2」 처럼 **장 없이 절만** 적는다.
#   ⚠ 실측으로 넣었다: 스펄전 『아침과 저녁』이 유다서·빌레몬서·요이·요삼을
#     그렇게 인용한다. 장을 요구하면 그 편들이 통째로 안 잡힌다.
ONE_CHAPTER = ('obadiah', 'philemon', 'jude', '2 john', '3 john',
               '옵', '몬', '유', '요이', '요삼')


def _name_re(em, bm):
    """책 이름 정규식 — **긴 이름부터** 넣는다.

    ⚠ 짧은 것부터 넣으면 `John` 이 `1 John` 을 먼저 먹는다.
    ⚠ 장이 하나인 책은 `장:절` 이 아니라 **절만** 붙는다 — 따로 받는다.
    """
    names = sorted(set(list(em) + list(bm)), key=len, reverse=True)
    alt = '|'.join(re.escape(n) for n in names if n)
    one = '|'.join(re.escape(n) for n in
                   sorted((n for n in names if n and n.lower() in ONE_CHAPTER),
                          key=len, reverse=True))
    full = re.compile(r'(' + alt + r')\.?\s*([0-9ivxlcIVXLC]+)\s*[:.]\s*(\d+)', re.I)
    solo = re.compile(r'(' + one + r')\.?\s+(\d+)(?!\s*[:.]\s*\d)', re.I) if one else None
    return (full, solo)


def cite_of(conn, body, em=None, bm=None, rx=None):
    """본문 머리에서 성구 참조 하나를 뽑아 `verse_id` 로. 못 찾으면 None.

    ⚠ **로마 숫자를 먼저 아라비아로**(`John i. 7` — 마이어 원문 표기).
    ⚠ 해석은 `scripture_ref_kr` 한 곳에 맡긴다 — 해석기를 두 벌 만들면 갈라진다
      (`book_footnote` 가 같은 이유로 영어를 한국어 약명으로 바꿔 넘긴다).
    """
    if not body:
        return None
    em = em if em is not None else book_footnote.en_to_ko(conn)
    bm = bm if bm is not None else book_footnote.book_map(conn)
    rx = rx if rx is not None else _name_re(em, bm)
    head = ' '.join(str(body).split())[:HEAD_CHARS]
    head = book_footnote.arabize(head)
    full, solo = rx
    # ⚠⚠ **둘 중 먼저 나오는 것**을 골라야 한다. 「장:절」을 먼저 보면 뒤쪽 인용에
    #   끌려간다 — 실측: `"Sanctified by God the Father." Jude 1 "Sanctified in
    #   Christ Jesus." 1 Corinthians 1:2 …` 에서 **고전1:2** 를 물었다(정답 유1:1).
    #   본문이 여럿을 인용할 때 **첫 번째가 그 편의 구절**이다.
    cands = []
    m1 = full.search(head)
    if m1:
        cands.append((m1.start(), m1.group(1), m1.group(2), m1.group(3)))
    if solo is not None:
        m2 = solo.search(head)
        if m2:
            cands.append((m2.start(), m2.group(1), '1', m2.group(2)))
    if not cands:
        return None
    _pos, raw, ch, vs = min(cands)
    nm = raw.strip().lower()

    class _M:                      # 아래 `m.group(1)` 호환
        pass
    m = _M()
    m.group = lambda i, _r=raw: _r
    ko = em.get(nm) or (m.group(1) if m.group(1) in bm else None)
    if not ko:
        return None
    try:
        s, _e = scripture_ref_kr.resolve(conn, '%s %s:%s' % (ko, ch, vs), bm)
    except Exception:
        return None
    return s


def ref_of(conn, kv, em=None, bm=None, rx=None):
    """`key_verse_ref` 글자를 `verse_id` 로. 같은 해석기를 쓴다."""
    return cite_of(conn, kv, em, bm, rx)


def _chapter_of(conn, vid):
    r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                     (vid,)).fetchone()
    return (r[0], r[1]) if r else None


# ─────────────────────────────────────────────────────────────
# 검사
# ─────────────────────────────────────────────────────────────
def structure(conn):
    """구조 — 고아·일수·본문·사용자 기록. `{이름: [문제…]}`."""
    out = {}

    orphan = []
    for code, day, uk in conn.execute(
            "SELECT p.plan_code, s.day, s.unit_key FROM sys_plan_schedule s "
            "  JOIN sys_bible_plan p ON p.plan_id=s.plan_id "
            " WHERE s.unit_key LIKE 'BOOK\\_%' ESCAPE '\\'"):
        try:
            uid = int(str(uk)[5:])
        except Exception:
            orphan.append((code, day, uk, '유닛 번호가 아니다'))
            continue
        r = conn.execute("SELECT COALESCE(record_status,'LIVE') "
                         "  FROM sys_book_unit WHERE unit_id=?", (uid,)).fetchone()
        if r is None:
            orphan.append((code, day, uid, '없는 유닛'))
        elif r[0] != 'LIVE':
            orphan.append((code, day, uid, '숨긴 유닛'))
    out['플랜이 가리키는 유닛이 없거나 숨겨졌다'] = orphan

    days = []
    for pid, code, dur in conn.execute(
            "SELECT plan_id, plan_code, duration_days FROM sys_bible_plan "
            " WHERE plan_type='BOOK_BASED' AND COALESCE(record_status,'LIVE')='LIVE'"):
        d = [r[0] for r in conn.execute(
            "SELECT DISTINCT day FROM sys_plan_schedule WHERE plan_id=? ORDER BY day",
            (pid,))]
        if not d:
            days.append((code, '스케줄이 없다', dur, 0))
        elif len(d) != dur or d[0] != 1 or d[-1] != len(d):
            days.append((code, '일수가 어긋난다', dur, len(d)))
    out['플랜 일수'] = days

    notext = [r for r in conn.execute(
        "SELECT p.plan_code, s.day, s.unit_key FROM sys_plan_schedule s "
        "  JOIN sys_bible_plan p ON p.plan_id=s.plan_id "
        " WHERE s.unit_key LIKE 'BOOK\\_%' ESCAPE '\\' "
        "   AND NOT EXISTS (SELECT 1 FROM sys_book_unit_text x "
        "                    WHERE x.unit_id = CAST(SUBSTR(s.unit_key,6) AS INTEGER))")]
    out['플랜이 본문 없는 유닛을 가리킨다'] = notext

    dup = [r for r in conn.execute(
        "SELECT a.book_code, u.sequence, COUNT(*) FROM sys_book_unit u "
        "  JOIN sys_book_asset a ON a.book_id=u.book_id "
        " WHERE COALESCE(u.record_status,'LIVE')='LIVE' "
        " GROUP BY u.book_id, u.sequence HAVING COUNT(*)>1")]
    out['한 책에 같은 순번이 둘'] = dup

    empty = [r for r in conn.execute(
        "SELECT a.book_code, COUNT(*) FROM sys_book_unit u "
        "  JOIN sys_book_asset a ON a.book_id=u.book_id "
        " WHERE COALESCE(u.record_status,'LIVE')='LIVE' "
        "   AND NOT EXISTS (SELECT 1 FROM sys_book_unit_text x WHERE x.unit_id=u.unit_id) "
        " GROUP BY 1")]
    out['본문이 없는 유닛'] = empty

    # 사용자 기록이 없어진 것을 가리키나 (userdb — 표가 없을 수 있다)
    user = []
    def _cnt(sql, label):
        try:
            n = conn.execute(sql).fetchone()[0]
            if n:
                user.append((label, n))
        except Exception:
            pass
    _cnt("SELECT COUNT(*) FROM user_plan_progress g "
         " WHERE g.schedule_id NOT IN (SELECT schedule_id FROM sys_plan_schedule) "
         "   AND g.schedule_id NOT IN (SELECT sched_id FROM user_plan_schedule)",
         '없어진 스케줄을 가리키는 진행')
    _cnt("SELECT COUNT(*) FROM user_book_read r WHERE r.kind='BOOK' "
         "  AND r.unit_id NOT IN (SELECT unit_id FROM sys_book_unit)",
         '없어진 유닛의 읽음')
    _cnt("SELECT COUNT(*) FROM user_book_pos o "
         " WHERE o.unit_id NOT IN (SELECT unit_id FROM sys_book_unit)",
         '없어진 유닛의 읽는 자리')
    _cnt("SELECT COUNT(*) FROM user_plan_enrollment e WHERE e.plan_id IS NOT NULL "
         "  AND e.plan_id NOT IN (SELECT plan_id FROM sys_bible_plan)",
         '없어진 플랜의 등록')
    out['사용자 기록이 없어진 것을 가리킨다'] = user
    return out


def verses(conn, book_code=None):
    """★ 삼각 대조 — 본문 인용 ↔ key_verse_ref ↔ start_vid ↔ 플랜 CORE.

    `{book_code: {'n':검사수, 'cite':본문인용 있는 수, 'bad':[…], 'core':[…]}}`
    """
    em = book_footnote.en_to_ko(conn)
    bm = book_footnote.book_map(conn)
    rx = _name_re(em, bm)

    # 플랜 CORE — (unit_id) → 그 날의 CORE start_vid
    core = {}
    for uk, cs in conn.execute(
            "WITH bt AS (SELECT plan_id, day, unit_key FROM sys_plan_schedule "
            "             WHERE stage_type='BOOK_TEXT' AND unit_key LIKE 'BOOK\\_%' ESCAPE '\\'), "
            "     co AS (SELECT plan_id, day, start_vid FROM sys_plan_schedule "
            "             WHERE stage_type IN ('CORE','QUOTED')) "
            "SELECT bt.unit_key, co.start_vid FROM bt "
            "  JOIN co ON co.plan_id=bt.plan_id AND co.day=bt.day "
            "  JOIN sys_bible_plan p ON p.plan_id=bt.plan_id "
            "       AND COALESCE(p.record_status,'LIVE')='LIVE'"):
        try:
            core.setdefault(int(str(uk)[5:]), set()).add(cs)
        except Exception:
            pass

    q = ("SELECT a.book_code, u.unit_id, u.sequence, u.unit_label, u.key_verse_ref, "
         "       u.start_vid, u.end_vid, x.body_text "
         "  FROM sys_book_asset a "
         "  JOIN sys_book_unit u ON u.book_id=a.book_id "
         "                      AND COALESCE(u.record_status,'LIVE')='LIVE' "
         "  JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
         "                           AND x.text_variant='ORIGINAL' "
         " WHERE COALESCE(a.record_status,'LIVE')='LIVE'")
    args = []
    if book_code:
        q += ' AND a.book_code=?'
        args.append(book_code)

    out = {}
    for code, uid, seq, lbl, kv, sv, ev, body in conn.execute(q, args):
        d = out.setdefault(code, {'n': 0, 'cite': 0, 'bad': [], 'core': []})
        d['n'] += 1
        cited = cite_of(conn, body, em, bm, rx)
        if cited is None:
            continue
        d['cite'] += 1
        kvv = ref_of(conn, kv, em, bm, rx) if kv else None

        # ① 본문 인용 ↔ start_vid — **범위 안이면 통과**(마이어는 장 전체다)
        if sv is not None:
            lo, hi = sv, (ev if ev is not None else sv)
            if not (min(lo, hi) <= cited <= max(lo, hi)):
                # 그 장 안이면 봐준다(장 단위로 잡은 책)
                a1, b1 = (_chapter_of(conn, cited) or (None, None))
                a2, b2 = (_chapter_of(conn, sv) or (None, None))
                if not (a1 == a2 and b1 == b2):
                    d['bad'].append((seq, (lbl or '')[:28], cited, sv, kvv))
        # ② 본문 인용 ↔ 플랜 CORE
        for cs in core.get(uid, ()):
            if cs is None:
                continue
            lo, hi = cited, cited
            if cs != cited:
                a1, b1 = (_chapter_of(conn, cited) or (None, None))
                a2, b2 = (_chapter_of(conn, cs) or (None, None))
                if not (a1 == a2 and b1 == b2):
                    d['core'].append((seq, (lbl or '')[:28], cited, cs))

    # ★ 게이트 — 인용 비율이 낮은 책은 **판정하지 않는다**(오탐뿐이다).
    #   ⚠ 조용히 버리지 않는다(§0 no silent caps) — `skip` 으로 표시해 알린다.
    for code, d in out.items():
        d['rate'] = (d['cite'] / d['n']) if d['n'] else 0.0
        d['skip'] = d['rate'] < CITE_MIN
        if d['skip']:
            d['bad'], d['core'] = [], []
    return out


def label(conn, vid):
    if vid is None:
        return '(없음)'
    r = conn.execute(
        "SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi "
        "  JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code='KO' "
        " WHERE bi.verse_id=?", (vid,)).fetchone()
    return ('%s%s:%s' % r) if r else str(vid)


def report(conn, book_code=None):
    bad = 0
    print('── 구조 ─────────────────────────────────────────────')
    for name, rows in structure(conn).items():
        print('  %-36s %s' % (name, ('%d건' % len(rows)) if rows else '없음'))
        for r in rows[:10]:
            print('      ', r)
        bad += len(rows)
    print('\n── 본문이 밝힌 구절 ↔ 기준 구절 ↔ 플랜 CORE ──────────')
    v = verses(conn, book_code)
    for code in sorted(v, key=lambda k: -(len(v[k]['bad']) + len(v[k]['core']))):
        d = v[code]
        if not (d['bad'] or d['core']):
            continue
        bad += len(d['bad']) + len(d['core'])
        print('  ★ %-18s 검사 %4d · 인용 있는 편 %4d · **start_vid 어긋남 %d · '
              'CORE 어긋남 %d**' % (code, d['n'], d['cite'], len(d['bad']), len(d['core'])))
        for seq, lbl, cited, sv, kvv in d['bad'][:8]:
            print('      seq %-4s %-28s 본문 %s ↔ start_vid %s (kv %s)'
                  % (seq, lbl, label(conn, cited), label(conn, sv), label(conn, kvv)))
        for seq, lbl, cited, cs in d['core'][:8]:
            print('      seq %-4s %-28s 본문 %s ↔ 플랜 CORE %s'
                  % (seq, lbl, label(conn, cited), label(conn, cs)))
    checked = [c for c in v if not v[c]['skip']]
    clean = [c for c in checked if not (v[c]['bad'] or v[c]['core'])]
    print('  잰 책 %d권 — 깨끗 %d · 문제 %d'
          % (len(checked), len(clean), len(checked) - len(clean)))
    skipped = sorted((c for c in v if v[c]['skip']), key=lambda c: -v[c]['rate'])
    if skipped:
        # ⚠ 조용히 넘어가지 않는다(§0 no silent caps) — 못 잰 책과 그 까닭을 밝힌다
        print('  ⚠ 본문이 구절을 안 밝혀 **대조하지 못한 책** %d권 '
              '(인용 비율 < %d%%):' % (len(skipped), int(CITE_MIN * 100)))
        print('      ' + ' · '.join('%s %.0f%%' % (c, v[c]['rate'] * 100)
                                    for c in skipped))
    print('\n총 문제 %d건' % bad)
    return bad


# ─────────────────────────────────────────────────────────────

def rule_count(conn):
    """룰엔진이 부르는 한 문 → `(어긋난 수, 짧은 설명)`.

    ★ **여기서 다시 세지 않는다** — 이 도구가 이미 하는 일을 그대로 받는다.
      두 벌로 세면 한쪽만 고쳐진다(§db_rules 머리말).
    """
    # ⚠⚠ `report` 는 **화면에 찍는다** — 룰엔진이 부르면 콘솔이 더러워진다.
    #   ⇒ 출력은 삼키고 **돌려주는 숫자**만 받는다(글자를 파싱하지 않는다 —
    #     화면 글자를 상태로 쓰면 문구를 고칠 때 조용히 틀어진다 §112차).
    import contextlib
    import io as _io
    try:
        with contextlib.redirect_stdout(_io.StringIO()):
            n = report(conn)
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]
    n = int(n or 0)
    return n, ('플랜·도서 문제 %d건 — db_plan_book_audit 로 본다' % n) if n else ''


def selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  PASS  %s' % name)
        else:
            fail += 1
            print('  FAIL  %s  %s' % (name, extra))

    try:
        conn = appdb.connect(DB)
    except Exception as e:
        print('  DB 없음: %s' % e)
        return 1
    try:
        em = book_footnote.en_to_ko(conn)
        bm = book_footnote.book_map(conn)
        rx = _name_re(em, bm)

        # ★ 뽑아내기 — 실제로 쓰이는 표기 전부
        cases = [
            ('"They did eat of the fruit." Joshua 5:12 Israel\'s weary', '수5:12'),
            ('John i. 7). The Saviour keepeth', '요1:7'),              # 로마 숫자
            ('"Continue in prayer." Colossians 4:2 It is interesting', '골4:2'),
            ('"We will be glad." Song of Solomon 1:4 We will not', '아1:4'),
            ('그가 이르시되 (창 1:5) 저녁이 되며', '창1:5'),               # 한국어
        ]
        for body, want in cases:
            got = cite_of(conn, body, em, bm, rx)
            t('본문에서 %s 를 뽑는다' % want, label(conn, got) == want,
              label(conn, got))
        # ★ **여럿을 인용하면 첫 번째** — 실측으로 잡은 함정(§cite_of ⚠⚠)
        t('여러 인용 중 첫 번째를 선택한다 (단일 장 표기라도)',
          label(conn, cite_of(conn,
                '"Sanctified by God the Father." Jude 1 "Sanctified in Christ '
                'Jesus." 1 Corinthians 1:2 "Through sanctification of the Spirit."',
                em, bm, rx)) == '유1:1',
          label(conn, cite_of(conn, '"x" Jude 1 "y" 1 Corinthians 1:2', em, bm, rx)))
        t('로마 숫자 서수 접두를 읽는다 (I John ii.15)',
          label(conn, cite_of(conn, 'I John ii.15. --Love not the world', em, bm, rx))
          == '요일2:15',
          label(conn, cite_of(conn, 'I John ii.15. --Love not the world', em, bm, rx)))
        t('1 John 을 John 으로 오인하지 않는다',
          label(conn, cite_of(conn, '"God is love." 1 John 4:16 He that', em, bm, rx))
          == '요일4:16',
          label(conn, cite_of(conn, '"God is love." 1 John 4:16 He', em, bm, rx)))
        t('구절이 없으면 None',
          cite_of(conn, 'THE first time I saw Brother Lawrence was upon the 3d',
                  em, bm, rx) is None)
        t('빈 글도 죽지 않는다', cite_of(conn, '', em, bm, rx) is None
          and cite_of(conn, None, em, bm, rx) is None)
        # 머리만 본다 — 뒤쪽 인용에 끌려가지 않는다
        t('본문 머리만 본다',
          cite_of(conn, 'x' * (HEAD_CHARS + 50) + ' Joshua 5:12', em, bm, rx) is None)

        # ★ **탐지력은 지어낸 본문으로 잰다**(위 `cite_of` 케이스들) — DB 상태에
        #   걸지 않는다.
        #   ⚠⚠ 처음에는 「아침과 저녁의 어긋남 7건을 잡는가」로 쟀는데, 그 7건을
        #     고치자 **selftest 가 통째로 깨졌다**(2026-08-24). **결함을 고치는 것이
        #     본업인 저장소에서 「결함이 있음」을 전제한 검사는 반드시 깨진다**
        #     (§0-5 — `db_vers_run` 이 「아직 안 쓴 장」을 박아 두었다가 겪은 그것).
        #   ⇒ 여기서는 **판정 논리**만 잰다.
        v = verses(conn, 'SPURGEON_ME')
        d = v.get('SPURGEON_ME', {})
        t('그 책의 본문이 구절을 밝힌다', d.get('cite', 0) > 700, d.get('cite'))
        t('아침과 저녁은 게이트를 지난다', not d.get('skip'), d.get('rate'))
        t('판정 결과가 목록으로 나온다',
          isinstance(d.get('bad'), list) and isinstance(d.get('core'), list))
        t('잡힌 것은 실제로 값이 다른 것뿐 (오탐 아님)',
          all(cited != sv for _s, _l, cited, sv, _k in d.get('bad', [])),
          d.get('bad', [])[:2])

        # ★ **오탐 없음** — 본문이 구절을 안 밝히는 책은 **판정하지 않는다**.
        #   마이어를 이름으로 예외 처리하면 책이 늘 때 또 손대야 한다 — 비율로 건다.
        vm = verses(conn, 'MEYER_ODH')
        dm = vm.get('MEYER_ODH', {})
        t('마이어는 게이트에 걸려 판정하지 않는다',
          dm.get('skip') and not dm.get('bad') and not dm.get('core'),
          '비율 %.3f · bad %d' % (dm.get('rate', -1), len(dm.get('bad', []))))
        t('게이트가 비율을 낸다', 0 <= dm.get('rate', -1) < CITE_MIN, dm.get('rate'))
        vk = verses(conn, 'KEMPIS_IOC')
        t('본문 인용 0인 책도 죽지 않는다',
          vk.get('KEMPIS_IOC', {}).get('skip') is True)

        st = structure(conn)
        t('구조 검사가 항목을 다 낸다', len(st) == 6, list(st))
        t('구조 검사가 읽기만 한다',
          conn.execute("SELECT COUNT(*) FROM user_book_read").fetchone()[0] >= 0)
    finally:
        conn.close()
    print('\n%d PASS · %d FAIL' % (ok, fail))
    return 0 if fail == 0 else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--db', default=DB)
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--book')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    conn = appdb.connect(a.db)
    try:
        if a.check or a.book:
            sys.exit(1 if report(conn, a.book) else 0)
        ap.print_help()
    finally:
        conn.close()


if __name__ == '__main__':
    main()
