# -*- coding: utf-8 -*-
"""db_book_desc.py — 도서 소개문 **단일 소스** (영구 · `--selftest` 의무)

사용자 확정 서식 (2026-08-22):
  · **2~3 문단** — 개요 / 체계 / 주요내용. 읽고 어떤 책인지 짐작할 수 있게.
  · 문단 아래 **▸ 출처** 블록 — 어디서 왔는지·판본·저작권만.
  · **작업 진행과정을 절대로 적지 않는다** — 「재적재」·「OCR 교정 완료」·
    「파서로 재추출」·「미적재」·「번역본은 두지 않습니다」 따위. 사용자에게
    필요 없는 정보다. 게이트가 낱말로 막는다.
  · 기관이 요구하는 **고지 전문은 여기 적지 않는다** — 소개문 끝의
    「출처·라이선스 보기 ▸」가 `license_info` 한 곳으로 데려간다. 책마다
    베껴 두면 갈라진다.

★★ **소개문은 실제로 적재된 것만 말한다.** 웨슬리는 제목이 「44편」이지만
   앱에는 4편이 있고, 마이어는 다섯 권 가운데 한 권만 있다. 지어내지 않는다
   (2026-08-22 사용자 지적 「도서소개문은 네가 임의로 만든 것이다」).

⚠ **문단 사이는 개행 하나** — `\\n\\n` 금지(§28-11). 문단 간격은 화면
  (`theme_font` 「book」 구역)이 준다. 빈 줄을 넣으면 간격이 두 배가 된다.

저장 자리
  · `sys_book_asset_text(lang_code, description)` — 언어별 소개문
  · `sys_book_asset.description` — 그 언어가 없을 때의 폴백(영어)

명령
  --selftest   자가 검증 (의무)
  --check      게이트만 돌린다 (DB 안 건드림)
  --apply      적재 (멱등)
  --list       지금 DB 의 소개문 현황
"""
import io
import os
import re
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

DB = 'bible_master.db'
LANGS = ('KO', 'EN')

# ── 게이트 ────────────────────────────────────────────────────────────────
# 작업 진행과정·내부 사정을 가리키는 낱말. 하나라도 있으면 적재를 막는다.
BAN = (
    '적재', '재추출', '파서', '스크립트', 'OCR', '멱등', '백업', '유닛',
    'unit_id', 'book_id', 'db_', '--apply', 'phase', 'Phase',
    '교정 완료', '정규화', '문장 일치', '대조함', '내장', '미완',
    '작업', '추출', '임포트', 'import', 'delete', 'insert',
)
BAN_EN = (
    're-run', 'rerun', 're-import', 'reimport', 'parser', 'importer',
    'OCR', 'idempotent', 'backfill', 'unit_id', 'book_id', 'db_',
    '--apply', 'phase 2', 'not yet loaded', 'to be extracted',
)
# ⚠ 'script' 를 넣지 말 것 — **Scripture 에 그대로 들어 있다**(위양성).
#   'import' 도 안 된다 — important 가 걸린다. 그래서 'importer' 로 좁혔다.
MIN_PARA = 2
MAX_PARA = 3
MIN_LEN = 40          # 문단 하나의 최소 길이 (한 줄짜리 요약 방지)

SRC_HEAD = {'KO': '▸ 출처', 'EN': '▸ Source'}
PD_LINE = {'KO': '퍼블릭 도메인 (저작권 만료)',
           'EN': 'Public domain (copyright expired)'}

# ── 구텐베르크 자료: 고지 전문이 어디 있는지 **글로** 알린다 ────────────────
# 사용자 지시(2026-08-22): 「구텐베르크 관련 자료에 대해서는 저작권 라이센스
# 고지문을 참고하라고 **링크가 아닌 경로 이름**을 다국어 모드로 설명하라.
# 화면/메뉴 이름, 접근방법 등」.
# ★ 링크(「출처·라이선스 보기 ▸」)는 그대로 둔다 — 실제로 눌린다(실측). 다만
#   글로 적힌 경로는 링크를 못 보거나 인쇄해도 찾아갈 수 있고, PG §1.E.1 이
#   요구하는 「눈에 띄게」에 더 맞는다.
# ⚠ 화면 이름을 **여기 박지 않는다** — 적재할 때 `ui_strings` 에서 읽는다.
#   이름이 바뀌면 다음 적재에서 저절로 따라온다(옛 「나의 길」 사고와 같은 계열).
PG_PATH_KEYS = ('TAB_P1_ANNOUNCE', 'SET_TAB_ABOUT')
PG_PATH_DEFAULT = {
    'KO': ('공지/소통', '라이선스정보'),
    'EN': ('Notices & Contact', 'License Info'),
}
PG_NOTE = {
    'KO': '구텐베르크 라이선스 전문은 앱의 「%s」 화면에서 「%s」 탭을 열면'
          ' 볼 수 있습니다',
    'EN': 'The full Project Gutenberg licence is in this app under'
          ' "%s" ▸ "%s"',
    'ZH': '古腾堡完整许可条款见本应用「%s」画面的「%s」标签',
    'ZHT': '古騰堡完整授權條款見本應用「%s」畫面的「%s」分頁',
    'JA': 'プロジェクト・グーテンベルクのライセンス全文は、本アプリの'
          '「%s」画面の「%s」タブにあります',
    'DE': 'Der vollständige Project-Gutenberg-Lizenztext steht in dieser App'
          ' unter „%s“ ▸ „%s“',
    'FR': 'La licence complète du Projet Gutenberg se trouve dans'
          ' l’application sous « %s » ▸ « %s »',
    'ES': 'La licencia completa de Project Gutenberg está en esta aplicación'
          ' en «%s» ▸ «%s»',
    'PT': 'A licença completa do Project Gutenberg está neste aplicativo em'
          ' “%s” ▸ “%s”',
    'RU': 'Полный текст лицензии Project Gutenberg — в приложении:'
          ' «%s» ▸ «%s»',
    'AR': 'نص ترخيص مشروع غوتنبرغ كاملاً موجود في التطبيق ضمن «%s» ◂ «%s»',
}


def is_pg(entry):
    """구텐베르크에서 온 자료인가 — 출처 줄과 주소를 함께 본다."""
    hay = ' '.join(list(entry.get('src') or []) +
                   list(entry.get('src_en') or []) + [entry.get('url') or ''])
    return 'Gutenberg' in hay or 'gutenberg.org' in hay


def path_names(conn=None, lang='KO'):
    """화면·탭 이름을 **지금 값으로** 읽는다. 못 읽으면 기본값."""
    lang = (lang or 'KO').upper()
    out = []
    for key in PG_PATH_KEYS:
        v = None
        if conn is not None:
            try:
                r = conn.execute(
                    "SELECT string_value FROM ui_strings "
                    " WHERE string_id=? AND UPPER(lang_code)=?",
                    (key, lang)).fetchone()
                v = r[0] if r and r[0] else None
            except Exception:
                v = None
        out.append(v)
    dflt = PG_PATH_DEFAULT.get(lang) or PG_PATH_DEFAULT['EN']
    return tuple(out[i] or dflt[i] for i in (0, 1))

# 소개문 끝 링크 문구 — 화면(`p1_reading_view`)이 i18n 으로 읽는다.
LINK_KEY = 'PR_LICENSE_LINK'
LINK_TEXT = {
    'KO': '출처·라이선스 보기 ▸',
    'EN': 'Source & licence ▸',
    'ZH': '查看来源与许可 ▸',
    'ZHT': '檢視來源與授權 ▸',
    'JA': '出典・ライセンスを見る ▸',
    'DE': 'Quelle & Lizenz anzeigen ▸',
    'FR': 'Source et licence ▸',
    'ES': 'Fuente y licencia ▸',
    'PT': 'Fonte e licença ▸',
    'RU': 'Источник и лицензия ▸',
    'AR': 'المصدر والترخيص ▸',
}


def _paras(entry, lang):
    return [p.strip() for p in entry[lang.lower()] if p and p.strip()]


def render(entry, lang, path=None):
    """소개문 한 편을 글자로 — 문단들 + ▸ 출처 블록.

    `path` = (화면 이름, 탭 이름). 구텐베르크 자료면 고지 전문이 있는 자리를
    **글로** 한 줄 덧붙인다.
    """
    lang = lang.upper()
    out = list(_paras(entry, lang))
    src = entry.get('src' if lang == 'KO' else 'src_en') or entry.get('src') or []
    lines = [SRC_HEAD.get(lang, SRC_HEAD['EN'])]
    for s in src:
        lines.append('  · ' + s)
    lines.append('  · ' + PD_LINE.get(lang, PD_LINE['EN']))
    if is_pg(entry):
        tpl = PG_NOTE.get(lang) or PG_NOTE['EN']
        scr, tab = path or PG_PATH_DEFAULT.get(lang) or PG_PATH_DEFAULT['EN']
        lines.append('  · ' + (tpl % (scr, tab)))
    out.append('\n'.join(lines))
    return '\n'.join(out)


# ══════════════════════════════════════════════════════════════════
#  번역 게이트 — **원본과 같은 모양인가** (2026-09-25 · 1.txt 16-3 ⑤)
# ══════════════════════════════════════════════════════════════════
#
#  ★★★ 소개문은 **문단 둘셋 + 「▸ 출처」 블록**이라는 꼴이 있다. 그 꼴이
#    깨지면 화면이 무너지고, 출처가 바뀌면 **저작권 고지가 다른 자료를
#    가리킨다**. ⇒ 「잘 옮겼나」는 사람이 보고, **「같은 모양인가」는 기계가
#    잰다**(`booktrans.md` 게이트와 같은 문법).
#  ⚠ 언어마다 길이가 크게 다르다(실측 KO→EN **1.82배**) — 길이는 **알림**
#    으로만 적고 막지 않는다.

NL_ = chr(10)

SRC_MARK = '\u25b8'           # ▸ — 출처 블록 머리
DOT_MARK = '\u00b7'           # · — 출처 줄머리
LEN_LO, LEN_HI = 0.5, 3.2     # 원본 대비 길이비 — 벗어나면 **알림**


def _split_intro(text):
    """`(문단들, 출처 줄들)` — 「▸」 줄부터가 출처 블록이다."""
    head, src = [], []
    for ln in (text or '').replace(chr(13), '').split(chr(10)):
        ln = ln.rstrip()
        if src or ln.lstrip().startswith(SRC_MARK):
            src.append(ln)
        else:
            head.append(ln)
    return [p for p in head if p.strip()], src


def _keep_tokens(src_lines):
    """출처에서 **글자 그대로 남아야 하는 것** — 주소·연도.

    ⚠ 문단(본문)에서는 안 잰다 — 사람·땅 이름은 그 언어로 옮겨 적는 것이
      옳다(「메트로폴리탄」). 출처는 **기관 이름과 판본**이라 다르다.
    """
    t = ' '.join(src_lines)
    out = set(re.findall(r'[A-Za-z0-9][A-Za-z0-9._-]*[.][A-Za-z]{2,}', t))
    out |= set(re.findall(r'(?<![0-9])(1[0-9]{3}|20[0-9]{2})(?![0-9])', t))
    return out


def check_text(src, out, lang='EN'):
    """옮긴 소개문 한 편을 **원본과 견준다** — 흠 목록(빈 목록 = 통과).

    ⚠ 괄호로 여는 줄은 **알림**이지 흠이 아니다(`db_ai_run._is_note` 규약).
    """
    if not (out or '').strip():
        return ['빈 글입니다.']
    bad = []
    sp, ss = _split_intro(src)
    op, so = _split_intro(out)
    if (chr(10) * 2) in (out or ''):
        bad.append('빈 줄이 있습니다 — 문단 사이는 개행 하나입니다.')
    if len(op) != len(sp):
        bad.append('문단 %d개 — 원본은 %d개입니다(합치거나 나누지 않습니다).'
                   % (len(op), len(sp)))
    for i, p in enumerate(op, 1):
        if '  ' in p:
            bad.append('%d번 문단에 겹공백이 있습니다.' % i)
    if ss and not so:
        bad.append('「%s 출처」 블록이 통째로 빠졌습니다.' % SRC_MARK)
    elif ss:
        n1 = len([l for l in ss if l.strip().startswith(DOT_MARK)])
        n2 = len([l for l in so if l.strip().startswith(DOT_MARK)])
        if n1 != n2:
            bad.append('출처 줄이 %d개 — 원본은 %d개입니다.' % (n2, n1))
        miss = sorted(t for t in _keep_tokens(ss) if t not in ' '.join(so))
        if miss:
            # ⚠⚠ **기관 이름·판본 연도는 옮기지 않는다** — 바꾸면 그 순간
            #   저작권 고지가 다른 자료를 가리킨다.
            bad.append('출처에서 사라진 것: %s' % ' · '.join(miss[:6]))
    words = list(BAN_EN) + (list(BAN) if (lang or '').upper() == 'KO' else [])
    for w in words:
        if w in (out or ''):
            bad.append('작업과정 낱말 「%s」' % w)
    a, b = len((src or '').strip()), len((out or '').strip())
    if a and not (LEN_LO <= b / float(a) <= LEN_HI):
        bad.append('(길이비 %.2f — 원본 %d자 · 옮긴 글 %d자. 사람이 봅니다)'
                   % (b / float(a), a, b))
    return bad


def _expand(name):
    n = (name or '').strip()
    if n.startswith('IA '):
        n = 'Internet Archive — ' + n[3:]
    return n


def src_block(conn, book_code, lang='KO'):
    """`sys_book_source` 로 **▸ 출처 블록**을 짓는다 — 손으로 안 적는다.

    ★★★ 신규 작성에는 옮길 원본이 없으므로 **출처를 댈 데가 DB 뿐**이다.
      AI 에게 이 글자를 주고 「그대로 붙이라」 하고, 게이트가 **글자 그대로
      있는가**를 잰다. 지어내게 두면 저작권 고지가 거짓이 된다.
    ⚠ `note` 는 **안 싣는다** — 작업 기록이라(「80% 게이트 비적용」) 화면에
      나갈 글이 아니고 `BAN` 낱말에도 걸린다.
    ⚠ 못 대면 **빈 글**을 낸다 — 없는 출처를 지어 붙이지 않는다.
    """
    lang = (lang or 'KO').upper()
    try:
        rows = conn.execute(
            "SELECT role, name FROM sys_book_source "
            " WHERE book_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
            "   AND UPPER(COALESCE(role,'')) IN ('PRIMARY','CROSS') "
            " ORDER BY CASE WHEN UPPER(role)='PRIMARY' THEN 0 ELSE 1 END,"
            "          src_id", (book_code,)).fetchall()
        a = conn.execute(
            "SELECT UPPER(COALESCE(copyright_type,'')), "
            "       LOWER(COALESCE(source_url,'')) "
            "  FROM sys_book_asset WHERE book_code=?", (book_code,)).fetchone()
    except Exception:                                     # noqa: BLE001
        return ''
    # ⚠ 약자는 풀어 적는다 — 화면에 나갈 글이다(지어내는 것이 아니라
    #   `IA` 가 무엇의 줄임인지 적는 것뿐이다).
    names = [_expand(r[1]) for r in rows if (r[1] or '').strip()]
    if not names:
        return ''
    out = [SRC_HEAD.get(lang, SRC_HEAD['EN'])]
    out += ['  ' + DOT_MARK + ' ' + n for n in names]
    if a and a[0] == 'PUBLIC_DOMAIN':
        out.append('  ' + DOT_MARK + ' ' + PD_LINE.get(lang, PD_LINE['EN']))
    if a and 'gutenberg' in (a[1] or ''):
        tpl = PG_NOTE.get(lang) or PG_NOTE['EN']
        out.append('  ' + DOT_MARK + ' ' + (tpl % path_names(conn, lang)))
    return NL_.join(out)


def check_new(text, src, lang='KO'):
    """**새로 쓴** 소개문을 잰다 — 흠 목록(빈 목록 = 통과).

    ⚠ `check_text` 는 「원본과 같은 모양인가」를 묻는다 — 신규에는 원본이
      없어 **문단 수가 늘 0 개로 나와** 무조건 흠이 된다. 물음이 다르다:
      **「서식대로 썼고 출처를 안 건드렸나」**.
    ★ 출처는 `src`(도구가 지은 블록)와 **글자 그대로** 같아야 한다.
    """
    if not (text or '').strip():
        return ['빈 글입니다.']
    bad = []
    op, so = _split_intro(text)
    if (chr(10) * 2) in (text or ''):
        bad.append('빈 줄이 있습니다 — 문단 사이는 개행 하나입니다.')
    if not (MIN_PARA <= len(op) <= MAX_PARA):
        bad.append('문단 %d개 — %d~%d개로 씁니다.'
                   % (len(op), MIN_PARA, MAX_PARA))
    for i, p in enumerate(op, 1):
        if '  ' in p:
            bad.append('%d번 문단에 겹공백이 있습니다.' % i)
        if len(p.strip()) < MIN_LEN:
            bad.append('%d번 문단이 %d자로 너무 짧습니다.' % (i, len(p.strip())))
    want = [l.rstrip() for l in (src or '').split(NL_) if l.strip()]
    got = [l.rstrip() for l in so if l.strip()]
    if want and got != want:
        # ⚠⚠ 기관 이름·판본 연도가 바뀌면 저작권 고지가 다른 자료를 가리킨다.
        bad.append('「%s 출처」 블록이 준 글자와 다릅니다 — 그대로 붙입니다.'
                   % SRC_MARK)
    elif not want and got:
        bad.append('(출처를 댈 자료가 DB 에 없는데 출처 블록을 적었습니다)')
    words = list(BAN_EN) + (list(BAN) if (lang or '').upper() == 'KO' else [])
    for w in words:
        if w in (text or ''):
            bad.append('작업과정 낱말 「%s」' % w)
    return bad


def check_entry(code, entry):
    """한 책의 소개문을 잰다 — 문제 목록을 돌려준다(빈 목록 = 통과)."""
    bad = []
    for lang in LANGS:
        key = lang.lower()
        if key not in entry:
            bad.append('%s %s 소개문 없음' % (code, lang))
            continue
        ps = _paras(entry, lang)
        if not (MIN_PARA <= len(ps) <= MAX_PARA):
            bad.append('%s %s 문단 %d개 (2~3이라야 한다)' % (code, lang, len(ps)))
        for i, p in enumerate(ps, 1):
            if len(p) < MIN_LEN:
                bad.append('%s %s %d번 문단이 %d자 (너무 짧다)'
                           % (code, lang, i, len(p)))
            # ⚠ 줄을 이어 붙일 때 생기는 겹공백 — 화면에 그대로 벌어져 보인다.
            #   출처 블록은 「  · 」로 들여쓰므로 문단만 잰다.
            if '  ' in p:
                bad.append('%s %s %d번 문단에 겹공백' % (code, lang, i))
        body = render(entry, lang)
        if '\n\n' in body:
            bad.append('%s %s 빈 줄 (문단 사이는 개행 하나)' % (code, lang))
        words = BAN if lang == 'KO' else BAN_EN
        for w in words:
            if w in body:
                bad.append('%s %s 작업과정 낱말 「%s」' % (code, lang, w))
    if not (entry.get('src') or entry.get('src_en')):
        bad.append('%s 출처 줄 없음' % code)
    return bad


def check_all(books=None):
    books = books if books is not None else BOOKS
    bad = []
    for code in sorted(books):
        bad += check_entry(code, books[code])
    return bad


# ── 적재 ──────────────────────────────────────────────────────────────────
BACKUP = 'temp_bookdesc_backup'


def backup_once(conn):
    """덮기 **전** 상태를 한 번만 떠 둔다 — 되돌릴 길이 없으면 적재하지 않는다.

    ⚠ 두 번째 실행에서 다시 뜨면 내가 쓴 소개문이 백업이 되어 원본이 사라진다.
      그래서 표가 이미 있으면 손대지 않는다.
    """
    got = conn.execute("SELECT name FROM sqlite_master "
                       " WHERE type='table' AND name=?", (BACKUP,)).fetchone()
    if got:
        return 0
    conn.execute("CREATE TABLE %s ("
                 " book_code TEXT, lang_code TEXT, description TEXT)" % BACKUP)
    n = 0
    for code, bid, d in conn.execute(
            "SELECT book_code, book_id, description FROM sys_book_asset"):
        conn.execute("INSERT INTO %s VALUES (?,?,?)" % BACKUP,
                     (code, '(base)', d))
        n += 1
        for lang, dd in conn.execute(
                "SELECT lang_code, description FROM sys_book_asset_text "
                " WHERE book_id=?", (bid,)):
            conn.execute("INSERT INTO %s VALUES (?,?,?)" % BACKUP,
                         (code, lang, dd))
            n += 1
    return n


def apply_all(conn, books=None, dry=False):
    books = books if books is not None else BOOKS
    n_txt = n_base = n_skip = 0
    for code in sorted(books):
        entry = books[code]
        row = conn.execute("SELECT book_id FROM sys_book_asset "
                           " WHERE book_code=?", (code,)).fetchone()
        if not row:
            print('   건너뜀 (그런 책이 없다): %s' % code)
            n_skip += 1
            continue
        bid = row[0]
        for lang in LANGS:
            body = render(entry, lang, path_names(conn, lang))
            if dry:
                n_txt += 1
                continue
            hit = conn.execute(
                "SELECT text_id FROM sys_book_asset_text "
                " WHERE book_id=? AND UPPER(lang_code)=?", (bid, lang)).fetchone()
            if hit:
                conn.execute("UPDATE sys_book_asset_text "
                             "   SET description=?, record_status='LIVE' "
                             " WHERE text_id=?", (body, hit[0]))
            else:
                conn.execute(
                    "INSERT INTO sys_book_asset_text"
                    "  (book_id, lang_code, description, record_status)"
                    " VALUES (?,?,?,'LIVE')", (bid, lang, body))
            n_txt += 1
        # 폴백(그 언어 행이 없는 사용자)은 영어로
        if not dry:
            conn.execute("UPDATE sys_book_asset SET description=? "
                         " WHERE book_id=?",
                         (render(entry, 'EN', path_names(conn, 'EN')), bid))
            # ★ 출처 주소도 여기서 바로잡는다 — 라이선스 화면의 「이 앱에 담긴
            #   자료」 목록이 그 칸을 읽는다. 기록이 틀리면 고지가 틀린다
            #   (아침과 저녁은 CCEL 에서 받았는데 구텐베르크로 적혀 있었다).
            if entry.get('url'):
                conn.execute("UPDATE sys_book_asset SET source_url=? "
                             " WHERE book_id=?", (entry['url'], bid))
        n_base += 1
    return n_txt, n_base, n_skip


def seed_link_label(conn, dry=False):
    """소개문 끝 링크 문구를 11개 언어로 (§0-3)."""
    n = 0
    for lang, val in LINK_TEXT.items():
        if dry:
            n += 1
            continue
        hit = conn.execute("SELECT 1 FROM ui_strings "
                           " WHERE string_id=? AND lang_code=?",
                           (LINK_KEY, lang)).fetchone()
        if hit:
            conn.execute("UPDATE ui_strings SET string_value=? "
                         " WHERE string_id=? AND lang_code=?",
                         (val, LINK_KEY, lang))
        else:
            conn.execute("INSERT INTO ui_strings"
                         " (string_id, lang_code, string_value) VALUES (?,?,?)",
                         (LINK_KEY, lang, val))
        n += 1
    return n


def list_state(conn):
    print('%-18s %-5s %-5s %s' % ('code', 'KO', 'EN', 'base'))
    for code, bid in conn.execute(
            "SELECT book_code, book_id FROM sys_book_asset "
            " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_code"):
        got = {}
        for lang, d in conn.execute(
                "SELECT UPPER(lang_code), description FROM sys_book_asset_text "
                " WHERE book_id=?", (bid,)):
            got[lang] = len(d or '')
        base = conn.execute("SELECT LENGTH(COALESCE(description,'')) "
                            "  FROM sys_book_asset WHERE book_id=?",
                            (bid,)).fetchone()[0]
        print('%-18s %-5s %-5s %s' % (code, got.get('KO', '-'),
                                      got.get('EN', '-'), base))


# ── 자가 검증 ─────────────────────────────────────────────────────────────
def selftest():
    NL = chr(10)
    fails = []

    def ck(name, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + name +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(name)

    good = {'X': {'ko': ['가' * 60, '나' * 60, '다' * 60],
                  'en': ['a' * 60, 'b' * 60, 'c' * 60],
                  'src': ['Project Gutenberg 전자책 #1'],
                  'src_en': ['Project Gutenberg eBook #1']}}
    ck('바른 소개문은 통과', check_all(good) == [], check_all(good))

    # ⓪ **번역 게이트** — 양방향(깨끗하면 0 · 심으면 잡는다)
    _S = ('가' * 60 + NL + '나' * 60 + NL +
          '▸ 출처' + NL + '  · Internet Archive (archive.org)' + NL +
          '  · 1898년판')
    _O = ('a' * 70 + NL + 'b' * 70 + NL +
          '▸ Source' + NL + '  · Internet Archive (archive.org)' + NL +
          '  · 1898 printing')
    ck('바른 번역은 통과', check_text(_S, _O) == [], check_text(_S, _O))
    ck('문단을 합치면 걸린다',
       any('문단' in m for m in check_text(_S, _O.replace('a' * 70 + NL, ''))))
    ck('출처 블록이 빠지면 걸린다',
       any('출처' in m for m in check_text(_S, 'a' * 70 + NL + 'b' * 70)))
    ck('출처 줄이 줄면 걸린다',
       any('출처 줄' in m for m in
           check_text(_S, _O.replace(NL + '  · 1898 printing', ''))))
    ck('주소가 사라지면 걸린다',
       any('archive.org' in m for m in
           check_text(_S, _O.replace('archive.org', 'somewhere'))))
    ck('판본 연도가 바뀌면 걸린다',
       any('1898' in m for m in check_text(_S, _O.replace('1898', '1901'))))
    ck('빈 줄은 걸린다',
       any('빈 줄' in m for m in
           check_text(_S, _O.replace(NL + '▸', NL + NL + '▸'))))
    ck('작업과정 낱말은 걸린다',
       any('OCR' in m for m in check_text(_S, _O.replace('printing', 'OCR run'))))
    ck('빈 글은 걸린다', check_text(_S, '  ') == ['빈 글입니다.'])
    ck('겹공백은 걸린다',
       any('겹공백' in m for m in check_text(_S, _O.replace('aa', 'a  a', 1))))
    ck('길이비는 **알림**이지 흠이 아니다',
       all(m.startswith('(') for m in
           check_text(_S, 'a' + NL + 'b' + NL + '▸ Source' + NL +
                      '  · Internet Archive (archive.org)' + NL + '  · 1898')))

    # ① 문단 수
    bad = {'X': dict(good['X'], ko=['가' * 60])}
    ck('문단 1개는 걸린다', any('문단 1개' in m for m in check_all(bad)))
    bad = {'X': dict(good['X'], ko=['가' * 60] * 4)}
    ck('문단 4개는 걸린다', any('문단 4개' in m for m in check_all(bad)))

    # ② 짧은 문단
    bad = {'X': dict(good['X'], ko=['짧다', '나' * 60])}
    ck('짧은 문단은 걸린다', any('너무 짧다' in m for m in check_all(bad)))

    # ③ 작업과정 낱말 — 실제로 있던 문장으로 잰다
    for w, txt in (('OCR', 'DJVU OCR 로 뽑았습니다 ' + '가' * 40),
                   ('적재', '색인은 미적재 상태입니다 ' + '가' * 40),
                   ('유닛', '423개 유닛 전문입니다 ' + '가' * 40)):
        bad = {'X': dict(good['X'], ko=[txt, '나' * 60])}
        ck('작업과정 낱말 「%s」 를 잡는다' % w,
           any('작업과정' in m for m in check_all(bad)))
    bad = {'X': dict(good['X'],
                     en=['re-run the importer after loading ' + 'a' * 40,
                         'b' * 60])}
    ck('영문 「re-run」 을 잡는다', any('re-run' in m for m in check_all(bad)))

    # ④ 빈 줄
    # ⚠ 문단 **안쪽**의 빈 줄로 재야 한다 — 앞뒤 개행은 `_paras` 가 이미 턴다.
    bad = {'X': dict(good['X'], ko=['가' * 30 + '\n\n' + '가' * 30, '나' * 60])}
    ck('빈 줄을 잡는다', any('빈 줄' in m for m in check_all(bad)))

    bad = {'X': dict(good['X'], ko=['가' * 30 + '  ' + '가' * 30, '나' * 60])}
    ck('겹공백을 잡는다', any('겹공백' in m for m in check_all(bad)))

    # ⑤ 출처 없음
    bad = {'X': {k: v for k, v in good['X'].items()
                 if k not in ('src', 'src_en')}}
    ck('출처 줄이 없으면 걸린다', any('출처 줄 없음' in m for m in check_all(bad)))

    # ⑥ 렌더 모양
    body = render(good['X'], 'KO')
    # ⚠ 구텐베르크 자료는 퍼블릭 도메인 줄 **뒤에** 경로 안내가 한 줄 더 붙는다
    tail = body.rstrip().splitlines()[-1]
    ck('▸ 출처 블록이 맨 끝',
       PD_LINE['KO'] in body and (tail.strip().startswith('·')), tail)
    ck('빈 줄 0', '\n\n' not in body)
    ck('출처 머리글', SRC_HEAD['KO'] in body)

    # ⑥-2 구텐베르크 자료에는 고지 자리를 **글로** 알린다
    pg = {'X': dict(good['X'], src=['Project Gutenberg 전자책 #1'],
                    src_en=['Project Gutenberg eBook #1'])}
    ko = render(pg['X'], 'KO', ('공지/소통', '라이선스정보'))
    ck('구텐베르크 자료에 경로 안내', '「공지/소통」' in ko and '라이선스정보' in ko,
       ko.splitlines()[-1])
    ck('링크가 아니라 경로 이름', 'http' not in ko.splitlines()[-1])
    cc = {'X': dict(good['X'], src=['Christian Classics Ethereal Library'],
                    src_en=['Christian Classics Ethereal Library'])}
    ck('구텐베르크가 아니면 안 붙는다',
       '라이선스정보' not in render(cc['X'], 'KO'))
    ck('경로 안내 11개 언어', len(PG_NOTE) == 11, len(PG_NOTE))
    ck('안내에 자리표 둘', all(t.count('%s') == 2 for t in PG_NOTE.values()))
    # 이름은 ui_strings 에서 읽어 온다 — 박아 두지 않는다
    try:
        import appdb as _a
        _c = _a.connect(DB)
        ck('화면 이름을 DB 에서 읽는다',
           path_names(_c, 'KO') == ('공지/소통', '라이선스정보'),
           path_names(_c, 'KO'))
        ck('EN 도 DB 에서', path_names(_c, 'EN')[1] == 'License Info',
           path_names(_c, 'EN'))
        _c.close()
    except Exception as e:
        ck('화면 이름을 DB 에서 읽는다', False, e)

    # ⑦ 실제 데이터 전량 게이트
    bad = check_all()
    ck('실제 %d권 전부 통과' % len(BOOKS), bad == [], bad[:6])

    # ⑧ 링크 문구 11개 언어
    ck('링크 문구 11개 언어', len(LINK_TEXT) == 11, len(LINK_TEXT))

    # ⑨ 실 DB 왕복 — 트랜잭션으로 되돌린다
    try:
        import appdb
        conn = appdb.connect(DB)
        before = conn.execute("SELECT COUNT(*) FROM sys_book_asset_text"
                              ).fetchone()[0]
        conn.execute('BEGIN')
        apply_all(conn, {k: BOOKS[k] for k in list(sorted(BOOKS))[:1]})
        seed_link_label(conn)
        conn.rollback()
        after = conn.execute("SELECT COUNT(*) FROM sys_book_asset_text"
                             ).fetchone()[0]
        ck('되돌린 뒤 행수 그대로', before == after, '%d → %d' % (before, after))
        conn.close()
    except Exception as e:
        ck('실 DB 왕복', False, e)

    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


# ── 소개문 본문 ───────────────────────────────────────────────────────────
# ★ 근거는 DB 에 실제로 적재된 장 제목·편 수·본문이다. 기억으로 쓰지 않는다.
from db_book_desc_data import BOOKS      # noqa: E402


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(selftest())
    if '--check' in a:
        bad = check_all()
        for m in bad:
            print('  ✗ ' + m)
        print('%d권 · 문제 %d건' % (len(BOOKS), len(bad)))
        sys.exit(1 if bad else 0)

    import appdb
    conn = appdb.connect(DB)
    if '--list' in a:
        list_state(conn)
        conn.close()
        return
    if '--apply' in a:
        bad = check_all()
        if bad:
            for m in bad:
                print('  ✗ ' + m)
            raise SystemExit('게이트에 걸렸다 — 적재하지 않는다.')
        conn.execute('BEGIN')
        n_bak = backup_once(conn)
        n_txt, n_base, n_skip = apply_all(conn)
        n_lbl = seed_link_label(conn)
        conn.commit()
        print('백업 %d행(%s) · 소개문 %d행 · 폴백 %d권 · 건너뜀 %d · 링크 문구 %d언어'
              % (n_bak, BACKUP, n_txt, n_base, n_skip, n_lbl))
        conn.close()
        return
    conn.close()
    print(__doc__)


if __name__ == '__main__':
    main()
