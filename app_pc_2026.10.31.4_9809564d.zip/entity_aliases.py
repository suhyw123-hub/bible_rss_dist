"""
entity_aliases.py
-----------------
엔티티 검색용 별명 (alias) 헬퍼.

저장 위치: sys_entity_master.json_detail.aliases
구조: {"EN": ["Remphan", "Chiun"], "KO": ["자캐오"]}

원칙:
  - ENTITY_NAME 은 정식이름(개신교 용어 기준)만 저장.
  - 같은 인물·사물의 다른 표기·동의어·번역 차이는 별명으로 등록.
  - 검색은 동일 언어 매칭 (사용자 lang='KO'면 KO 별명만 매칭).
  - 표시는 정식이름만. 별명은 사용자 화면에 노출하지 않음.
  - URL 생성에는 영향 없음 (build_url은 별도의 site_aliases 사용).
"""
import json
import sqlite3


def parse_aliases(json_detail_raw: str | None) -> dict:
    """json_detail 원본 → aliases dict.
    실패 시 {} 반환."""
    if not json_detail_raw:
        return {}
    try:
        jd = json.loads(json_detail_raw)
    except Exception:
        return {}
    if not isinstance(jd, dict):
        return {}
    a = jd.get('aliases')
    if not isinstance(a, dict):
        return {}
    # 값은 항상 list[str] — 비정상 값은 무시
    out = {}
    for lang, vals in a.items():
        if isinstance(vals, list):
            cleaned = [s.strip() for s in vals if isinstance(s, str) and s.strip()]
            if cleaned:
                out[lang.upper()] = cleaned
    return out


def aliases_for_lang(json_detail_raw: str | None, lang: str) -> list[str]:
    """특정 언어의 별명 list 반환."""
    return parse_aliases(json_detail_raw).get((lang or 'EN').upper(), [])


def update_aliases(conn: sqlite3.Connection, entity_id: int,
                    lang: str, new_aliases: list[str]) -> None:
    """sys_entity_master.json_detail.aliases[lang] 를 갱신.
    빈 list 면 해당 lang 키 제거. aliases 전체가 빈 dict 되면 키 자체 제거."""
    row = conn.execute(
        "SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
        (entity_id,)).fetchone()
    if not row:
        return
    jd_raw = row[0]
    jd = {}
    if jd_raw:
        try:
            parsed = json.loads(jd_raw)
            if isinstance(parsed, dict):
                jd = parsed
        except Exception:
            jd = {}
    aliases = jd.get('aliases') if isinstance(jd.get('aliases'), dict) else {}
    lang_u = (lang or 'EN').upper()
    cleaned = [s.strip() for s in (new_aliases or []) if s and s.strip()]
    if cleaned:
        aliases[lang_u] = cleaned
    else:
        aliases.pop(lang_u, None)
    if aliases:
        jd['aliases'] = aliases
    else:
        jd.pop('aliases', None)
    new_raw = json.dumps(jd, ensure_ascii=False) if jd else None
    conn.execute(
        "UPDATE sys_entity_master SET json_detail=? WHERE entity_id=?",
        (new_raw, entity_id))


def matches_query(name: str | None, aliases_list: list[str], q: str) -> bool:
    """이름 + 별명 중 하나라도 q (lowercase) 포함하면 True."""
    if not q:
        return True
    if name and q in name.lower():
        return True
    for a in aliases_list or []:
        if q in a.lower():
            return True
    return False


def format_csv(aliases_list: list[str]) -> str:
    """리스트 → 쉼표 구분 문자열 (UI 입력 표시용)."""
    return ', '.join(aliases_list or [])


def parse_csv(text: str) -> list[str]:
    """쉼표 구분 문자열 → 리스트 (UI 입력 저장용). 중복 제거."""
    if not text:
        return []
    seen = []
    for raw in text.split(','):
        s = raw.strip()
        if s and s not in seen:
            seen.append(s)
    return seen
