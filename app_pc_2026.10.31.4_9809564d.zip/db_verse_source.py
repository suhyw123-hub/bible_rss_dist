# -*- coding: utf-8 -*-
"""도서 편의 기준 구절이 **저자가 인용한 것인가, 우리가 선택한 것인가** (2026-08-25).

★ 왜 필요한가 (§78 사용자 물음) — 이그나티우스 7편에 구절이 붙어 있는데
  **원문에는 장:절 표기가 하나도 없다.** 그런데 화면에는
      이그나티우스  ·  Lightfoot 영역  ·  엡 4:3
  으로 떠서 **저자가 그 구절을 인용한 것처럼 읽힌다.** 본문은 안 건드렸으니
  §0-1b 는 지켰지만 **근거를 밝히지 않은 것**이 문제였다.

★★ **확실한 것만 표시한다** (사용자 확정, 2026-08-25 안 ①).
  「저자가 밝혔다」는 **기계로 못 가른다** — 실측으로 확인했다:
    · 스펄전 설교 3,475편은 `key_verse_ref` 가 100% 있는데 **본문 어디에도
      그 표기가 없다**(무작위 80편 중 4편). 적재할 때 본문 머리의 성구 줄이
      안 들어왔기 때문이고, 그러니 **우리 데이터가 증명하지 못한다.**
    · 마이어 1,189편은 구절이 **제목의 인용문**에서 왔다 — 참조 표기가 없다.
  ⇒ **틀린 출처를 붙이는 것은 안 붙이는 것보다 나쁘다.** 그래서 이 도구는
    `EDITORIAL` **하나만** 적고 나머지는 **비워 둔다**(모름).

★ **판정 기준 = 그 책 원문에 장:절 표기가 한 번이라도 있는가** (편 단위 아님).
  한 번도 없으면 그 책에 붙은 구절은 **전부 우리가 고른 것**이다.
  ⚠ **책 목록을 손으로 적지 않는다** — 그때그때 원문을 훑어 정한다.
    책을 더하면 저절로 따라온다(§db_plan_book_audit 의 비율 게이트와 같은 정신).

실측(2026-08-25 전 편·전 본문): 표기가 **전혀 없는 책 10권**, 그중 구절이 붙은
  8권 **150편** — 클레멘트 1서 66 · 헤르마스 27 · 바운즈 20 · 디다케 16 ·
  디오그네투스 12 · 이그나티우스 7 · 폴리캅 2.
  (파스칼·어거스틴 고백록·반다이크는 표기도 없고 붙은 구절도 없다.)

사용:
    python db_verse_source.py --selftest      (의무)
    python db_verse_source.py --scan          책마다 표기 비율
    python db_verse_source.py --check
    python db_verse_source.py --apply
    python db_verse_source.py --restore
"""
import re
import sys
import appdb

COL = 'verse_source'
EDITORIAL = 'EDITORIAL'          # 우리가 골랐다 (본문에 근거 없음)
BK = 'temp_versesource_backup'


def _names(conn):
    out = set()
    for (v,) in conn.execute("SELECT DISTINCT full_name FROM book_names "
                             "WHERE lang_code='EN'"):
        if v:
            out.add(v)
    for (v,) in conn.execute("SELECT DISTINCT short_name FROM book_names "
                             "WHERE lang_code='EN'"):
        if v:
            out.add(v)
    return out


def _rx(conn):
    """영어 책이름 + 장:절. 로마 숫자 꼴(`Psalm xciv. 12`)도 잡는다.

    ⚠ **콜론을 지우는 정규화를 앞에 두지 말 것** — 앞선 측정 네 판을 망친
      버그다(`malachi 3:6` → `malachi 36` 으로 만들어 놓고 콜론으로 찾았다).
    """
    # ⚠ 세 글자 접두 뒤에 **글자가 더 와도 된다** — 성경 표는 `Psalms` 인데
    #   저자는 `Psalm xciv. 12` 라 쓴다(§70 이 별칭 47건으로 겪은 그 자리).
    #   장:절이 뒤따라야 하므로 넓혀도 산문에 오탐이 안 난다(selftest 가 잰다).
    nm = _names(conn)
    alt = {re.escape(n) for n in nm} | {re.escape(n[:3]) + '[a-z]*'
                                        for n in nm if len(n) > 3}
    pat = '(?:%s)' % '|'.join(sorted(alt, key=len, reverse=True))
    return (re.compile(r'\b' + pat + r'\.?\s+(?:\d{1,3}\s*[:.]\s*\d{1,3}'
                       r'|[ivxlc]{1,6}\.\s*\d{1,3})', re.I),
            re.compile(r'[가-힣]{1,4}\s?\d{1,3}\s*:\s*\d{1,3}'))


def has_ref(text, rx=None, rk=None):
    """그 글에 장:절 표기가 있는가."""
    if not text:
        return False
    return bool((rx and rx.search(text)) or (rk and rk.search(text)))


def scan(conn):
    """책마다 `(book_id, code, 편, 표기있는편, 구절붙은편)`."""
    rx, rk = _rx(conn)
    out = []
    for bid, code in conn.execute(
            "SELECT book_id, book_code FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_id"):
        rows = conn.execute(
            "SELECT t.body_text FROM sys_book_unit bu "
            "JOIN sys_book_unit_text t ON t.unit_id=bu.unit_id "
            "  AND t.text_variant='ORIGINAL' "
            "WHERE bu.book_id=? AND COALESCE(bu.record_status,'LIVE')='LIVE'",
            (bid,)).fetchall()
        if not rows:
            continue
        hit = sum(1 for (b,) in rows if has_ref(b, rx, rk))
        nv = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? "
            "AND start_vid IS NOT NULL "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (bid,)).fetchone()[0]
        out.append((bid, code, len(rows), hit, nv))
    return out


def targets(conn):
    """구절을 표시해야 할 편 — 원문에 표기가 **한 번도 없는 책**의 편."""
    out = []
    for bid, code, n, hit, nv in scan(conn):
        if hit == 0 and nv:
            out.append((bid, code, nv))
    return out


def _ensure_col(conn):
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_book_unit)')]
    if COL not in cols:
        conn.execute('ALTER TABLE sys_book_unit ADD COLUMN %s TEXT' % COL)
        conn.commit()
        return True
    return False


def check(conn):
    _ensure_col(conn)
    tg = targets(conn)
    print('원문에 장:절 표기가 한 번도 없는 책 — 붙은 구절은 우리가 골랐다')
    tot = 0
    for bid, code, nv in tg:
        cur = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? AND %s=? "
            "AND start_vid IS NOT NULL" % COL, (bid, EDITORIAL)).fetchone()[0]
        print('  %-20s 구절 붙은 편 %4d · 이미 표시 %4d' % (code, nv, cur))
        tot += nv
    print('  ─ 합계 %d편' % tot)
    other = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit WHERE start_vid IS NOT NULL "
        "AND COALESCE(record_status,'LIVE')='LIVE' AND %s IS NULL" % COL
    ).fetchone()[0]
    print('  (표시 없음 = 아직 모름: %d편 — 짐작으로 채우지 않는다)' % other)
    return tg


def apply(conn):
    tg = check(conn)
    conn.execute('CREATE TABLE IF NOT EXISTS %s '
                 '(unit_id INTEGER, old_val TEXT, moved_at TEXT)' % BK)
    n = 0
    for bid, code, nv in tg:
        rows = conn.execute(
            "SELECT unit_id, %s FROM sys_book_unit WHERE book_id=? "
            "AND start_vid IS NOT NULL "
            "AND COALESCE(record_status,'LIVE')='LIVE' "
            "AND (%s IS NULL OR %s<>?)" % (COL, COL, COL),
            (bid, EDITORIAL)).fetchall()
        if not rows:
            continue
        conn.executemany('INSERT INTO %s VALUES (?,?,datetime("now"))' % BK,
                         rows)
        conn.execute(
            "UPDATE sys_book_unit SET %s=? WHERE book_id=? "
            "AND start_vid IS NOT NULL "
            "AND COALESCE(record_status,'LIVE')='LIVE'" % COL,
            (EDITORIAL, bid))
        n += len(rows)
        print('  %-20s %d편 표시' % (code, len(rows)))
    conn.commit()
    print('\n표시 %d편 (백업 %s)' % (n, BK))
    return n


def restore(conn):
    try:
        rows = conn.execute('SELECT unit_id, old_val FROM %s' % BK).fetchall()
    except Exception:
        print('백업 표가 없다.')
        return 0
    for uid, old in rows:
        conn.execute('UPDATE sys_book_unit SET %s=? WHERE unit_id=?' % COL,
                     (old, uid))
    conn.execute('DELETE FROM %s' % BK)
    conn.commit()
    print('되돌림 %d편' % len(rows))
    return len(rows)


def selftest():
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    conn = appdb.connect()
    rx, rk = _rx(conn)

    # ★ **탐지력을 먼저 잰다** — 못 잡는 검사기는 「표기 없음」을 남발한다
    t('영어 표기를 잡는다', has_ref('as in Malachi 3:6 we read', rx, rk))
    t('로마 숫자를 잡는다', has_ref('(1) Psalm xciv. 12', rx, rk))
    t('약자를 잡는다', has_ref('see Mal. 3:6', rx, rk))
    t('마침표 꼴을 잡는다', has_ref('John 14. 6 says', rx, rk))
    t('한국어 표기를 잡는다', has_ref('엡 4:3 을 보라', rx, rk))
    # ⚠ 콜론이 핵심 글자다 — 지우면 못 잡는다(앞선 측정을 망친 버그)
    t('콜론을 지우면 못 잡는다(그 버그를 재현)',
      not has_ref('Malachi 36', rx, rk))
    t('그냥 산문은 안 잡는다',
      not has_ref('The Lord is my shepherd and I shall not want.', rx, rk))
    t('숫자만 있는 글은 안 잡는다', not has_ref('in 1855 he preached', rx, rk))

    # 실제 데이터 — **개수를 박지 않는다**(§0-5). 성질만 잰다.
    tg = targets(conn)
    t('표기 없는 책이 하나라도 잡힌다 (%d권)' % len(tg), len(tg) > 0, len(tg))
    codes = {c for _, c, _ in tg}
    t('이그나티우스가 그 안에 있다 (§78 의 그 책)',
      'IGNATIUS_LETTERS' in codes, sorted(codes))
    # 반대쪽 — 본문이 밝히는 책이 잘못 걸리면 안 된다
    t('아침과 저녁은 안 걸린다(본문이 100% 밝힌다)',
      'SPURGEON_ME' not in codes, sorted(codes))
    t('켐피스는 안 걸린다(각주에 표기가 있다)',
      'KEMPIS_IOC' not in codes, sorted(codes))

    # 칸이 있고 값이 EDITORIAL 아니면 NULL 뿐인가
    _ensure_col(conn)
    vals = {r[0] for r in conn.execute(
        'SELECT DISTINCT %s FROM sys_book_unit' % COL)}
    t('값은 EDITORIAL 또는 비움뿐 (%s)' % sorted(str(v) for v in vals),
      vals <= {None, EDITORIAL}, vals)
    conn.close()

    print('\ndb_verse_source selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if a == '--selftest':
        return 0 if selftest() else 1
    conn = appdb.connect()
    if a == '--scan':
        print('  %-20s %6s %8s %7s %8s' % ('책', '편', '표기있음', '비율', '구절붙음'))
        for bid, code, n, hit, nv in scan(conn):
            print('  %-20s %6d %8d %6d%% %8d'
                  % (code, n, hit, round(hit * 100 / n), nv))
    elif a == '--apply':
        apply(conn)
    elif a == '--restore':
        restore(conn)
    else:
        check(conn)
    conn.close()
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    sys.exit(main())
