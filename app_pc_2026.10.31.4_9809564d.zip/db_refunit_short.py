# -*- coding: utf-8 -*-
"""자료집 글의 **목록 요약** — 한두 단어 꼬리표 (2026-08-27 신설·영구).

★ 왜 (사용자 제안·승인): 「문답 목록이 길거나 **숫자만 있다.** 질문의 핵심을
  한두 단어로 요약하는 필드를 만드는 것은 어떤가?」
  실측 — 하이델베르크 문답의 표시가 「Q.1 — Lord's Day 1」 같은 번호뿐이라
  목록·연결 팝업·태그 어디서든 **내용을 모르고 골라야** 했다.

저장 — **칼럼이 아니라 `sys_text_asset` 행**(§0-3 규칙 1):
    text_type='REF_UNIT_SHORT' · clicked_id=ref_unit_id · lang_code 별 행 ·
    값은 title 칸 (PERI_TITLE 과 같은 문법 — 짧은 제목류는 title 에 산다)

표시 — 요약이 있으면 「믿음의 유일한 위로 · Q.1」, 없으면 종전 그대로(폴백).

⚠ 이것은 **목록용 꼬리표**다 — 본문 요약(SUMMARY 변형·10줄 요약형 구상)과
  층이 다르다. 섞지 않는다.

쓰기
    python db_refunit_short.py --selftest        (의무)
    python db_refunit_short.py --sample          샘플 3편 적재 (§0-1 검수용)
    python db_refunit_short.py --check <초안>    게이트만
    python db_refunit_short.py --apply <초안>    멱등 적재
    python db_refunit_short.py --status          보유 현황

초안 = UTF-8 텍스트, 한 줄이 한 행:  <ref_unit_id>|<KO|EN>|<요약>
"""
import io
import sys

import appdb

TT = 'REF_UNIT_SHORT'
MAX_LEN = 24          # 「한두 단어」 — 목록 칸을 넘지 않게 못 박는다

#: §0-1 샘플 검수용 — 유형별 2~3개. 승인 뒤 전량 저작한다.
#  ⚠ 하이델베르크는 그 문답을 부르는 **관용 표현**이 이미 있다(제1문 = 「유일한
#    위로」). 지어내지 않고 그것을 쓴다.
SAMPLES = [
    # HC Q.1 — What is thy only comfort in life and death?
    (1, 'KO', '유일한 위로'),
    (1, 'EN', 'Only Comfort'),
    # HC Q.4 — What does the law of God require of us?
    (4, 'KO', '율법의 요구'),
    (4, 'EN', "Law's Demand"),
    # WSC Q.1 — What is the chief end of man? (ref_unit_id 는 실행 때 찾는다)
    ('WSC1', 'KO', '사람의 제일 목적'),
    ('WSC1', 'EN', "Man's Chief End"),
]


def _wsc1(conn):
    r = conn.execute(
        "SELECT u.ref_unit_id FROM sys_ref_unit u "
        " JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
        " WHERE s.src_code LIKE 'WSC%' AND u.sequence=1 "
        " ORDER BY u.ref_unit_id LIMIT 1").fetchone()
    if not r:
        r = conn.execute(
            "SELECT ref_unit_id FROM sys_ref_unit "
            " WHERE LOWER(COALESCE(unit_question,'')) LIKE '%chief end of man%' "
            " ORDER BY ref_unit_id LIMIT 1").fetchone()
    return r and r[0]


def short_of(conn, ref_unit_id, lang='KO'):
    """그 글의 요약 → str 또는 ''. 요청 언어 → EN 폴백."""
    r = conn.execute(
        "SELECT title FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
        "  AND TRIM(COALESCE(title,''))<>'' "
        "  AND COALESCE(record_status,'LIVE')='LIVE' "
        " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
        "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (TT, int(ref_unit_id), lang)).fetchone()
    return (r and r[0]) or ''


def label_with_short(conn, ref_unit_id, base_label, lang='KO'):
    """목록 표시 — 요약이 있으면 「요약 · 원래이름」, 없으면 원래 그대로."""
    s = short_of(conn, ref_unit_id, lang)
    return ('%s · %s' % (s, base_label)) if s else base_label


def save_short(conn, ref_unit_id, lang, text):
    """한 건 저장(멱등 UPSERT). 빈 값이면 HIDE(§10 — 거짓 배지 방지)."""
    text = (text or '').strip()
    lang = (lang or 'KO').upper()
    if text and len(text) > MAX_LEN:
        raise ValueError('요약이 %d자를 넘는다(한두 단어): %r' % (MAX_LEN, text))
    cur = conn.execute(
        "UPDATE sys_text_asset SET title=?, record_status=? "
        " WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=?",
        (text, 'LIVE' if text else 'HIDE', TT, int(ref_unit_id), lang))
    if cur.rowcount == 0 and text:
        conn.execute(
            "INSERT INTO sys_text_asset(text_type, clicked_id, title, "
            " lang_code, record_status) VALUES(?,?,?,?,'LIVE')",
            (TT, int(ref_unit_id), text, lang))
    conn.commit()


def check(rows, conn):
    """게이트 → [문제]. 길이·언어·실재하는 글인가."""
    bad = []
    for uid, lang, text in rows:
        if lang.upper() not in ('KO', 'EN', 'ZH', 'JA', 'DE', 'FR', 'ES',
                                'AR', 'RU', 'PT', 'ZHT'):
            bad.append('%s: 모르는 언어 %s' % (uid, lang))
        if not (text or '').strip():
            bad.append('%s/%s: 빈 요약' % (uid, lang))
        elif len(text.strip()) > MAX_LEN:
            bad.append('%s/%s: %d자 — 한두 단어가 아니다' %
                       (uid, lang, len(text.strip())))
        if not conn.execute('SELECT 1 FROM sys_ref_unit WHERE ref_unit_id=?',
                            (int(uid),)).fetchone():
            bad.append('%s: 없는 글 번호' % uid)
    return bad


def load_draft(path):
    rows = []
    for ln in io.open(path, encoding='utf-8'):
        ln = ln.strip()
        if not ln or ln.startswith('#'):
            continue
        uid, lang, text = ln.split('|', 2)
        rows.append((int(uid), lang.strip(), text.strip()))
    return rows


def status(conn):
    for lang, n in conn.execute(
            "SELECT UPPER(lang_code), COUNT(*) FROM sys_text_asset "
            " WHERE text_type=? AND COALESCE(record_status,'LIVE')='LIVE' "
            "   AND TRIM(COALESCE(title,''))<>'' GROUP BY 1 ORDER BY 2 DESC",
            (TT,)):
        print('  %-4s %d' % (lang, n))


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    conn = appdb.connect()
    UID = 1                              # HC Q.1 — 실재 확인 후 스냅샷·원복
    snap = conn.execute(
        "SELECT lang_code, title, record_status FROM sys_text_asset "
        " WHERE text_type=? AND clicked_id=?", (TT, UID)).fetchall()
    try:
        save_short(conn, UID, 'KO', '시험 요약')
        t('저장 → 조회 왕복', short_of(conn, UID, 'KO') == '시험 요약')
        t('★ 표시 = 「요약 · 원래이름」',
          label_with_short(conn, UID, 'Q.1', 'KO') == '시험 요약 · Q.1')
        save_short(conn, UID, 'KO', '고친 요약')
        n = conn.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type=?"
                         " AND clicked_id=? AND UPPER(lang_code)='KO'",
                         (TT, UID)).fetchone()[0]
        t('★ 같은 언어 다시 저장 = 행이 안 는다', n == 1, n)
        t('   값이 바뀐다', short_of(conn, UID, 'KO') == '고친 요약')
        save_short(conn, UID, 'EN', 'Test')
        t('★ EN 폴백', short_of(conn, UID, 'JA') == 'Test')
        save_short(conn, UID, 'KO', '')
        t('★ 빈 값 = HIDE(거짓 표시 방지)', short_of(conn, UID, 'KO') == 'Test')
        t('   없으면 원래 이름 그대로(폴백)',
          label_with_short(conn, UID, 'Q.9x', 'DE')
          in ('Test · Q.9x', 'Q.9x'))
        try:
            save_short(conn, UID, 'KO', '가' * 30)
            t('★ 긴 요약은 거부한다', False)
        except ValueError:
            t('★ 긴 요약은 거부한다', True)
        bad = check([(UID, 'KO', '좋음'), (999999, 'KO', '없음'),
                     (UID, 'XX', '?'), (UID, 'KO', '가' * 30)], conn)
        t('★ 게이트 탐지력(없는 글·언어·길이)', len(bad) == 3, bad)
    finally:
        conn.execute('DELETE FROM sys_text_asset WHERE text_type=? '
                     ' AND clicked_id=?', (TT, UID))
        for lc, ti, st in snap:
            conn.execute('INSERT INTO sys_text_asset(text_type, clicked_id, '
                         ' title, lang_code, record_status) VALUES(?,?,?,?,?)',
                         (TT, UID, ti, lc, st))
        conn.commit()
        left = conn.execute(
            'SELECT COUNT(*) FROM sys_text_asset WHERE text_type=? '
            ' AND clicked_id=?', (TT, UID)).fetchone()[0]
        t('전 칼럼 스냅샷 원복', left == len(snap), (left, len(snap)))
        conn.close()
    print('db_refunit_short selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--sample' in a:
        rows = []
        for uid, lang, text in SAMPLES:
            if uid == 'WSC1':
                uid = _wsc1(conn)
                if not uid:
                    print('  ⚠ WSC 1문을 못 찾았다 — 건너뜀')
                    continue
            rows.append((uid, lang, text))
        bad = check(rows, conn)
        if bad:
            print('게이트 위반:', bad)
            sys.exit(1)
        for uid, lang, text in rows:
            save_short(conn, uid, lang, text)
            print('  적재 %s/%s = %s' % (uid, lang, text))
    elif '--status' in a:
        status(conn)
    elif '--check' in a or '--apply' in a:
        path = a[a.index('--check' if '--check' in a else '--apply') + 1]
        rows = load_draft(path)
        bad = check(rows, conn)
        if bad:
            print('위반 %d:' % len(bad))
            for x in bad:
                print(' ', x)
            sys.exit(1)
        print('게이트 통과 %d행' % len(rows))
        if '--apply' in a:
            for uid, lang, text in rows:
                save_short(conn, uid, lang, text)
            print('적재 완료')
    else:
        print(__doc__)
    conn.close()


if __name__ == '__main__':
    main()
