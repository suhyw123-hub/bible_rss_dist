# -*- coding: utf-8 -*-
"""
search.py — **통합검색 뒤판** (2026-08-21 신설 · 영구 · `--selftest` 의무)
==========================================================================
화면은 이 파일 하나만 압니다. **뒤가 LIKE 인지 색인인지 모릅니다.**

    hits = search.find_group(conn, 'VERSE', '은혜', ctx, limit=20)

두 층으로 되어 있습니다 — **이 갈래가 이 파일의 핵심입니다.**

    BUCKETS  체크칸 4개   ← 사용자가 켜고 끄는 것. 화면에 보이는 것
    GROUPS   세부 자산군  ← 실제 질의 단위. **결과 줄이 여기를 들고 다닌다**

★ 사용자 지시(2026-08-21): 「성격이 비슷한 것끼리 묶어서 체크 표시하고 괄호로
  묶어라. **실제 연결은 각 세부 자산별로 연결되어야 한다. 중요하다.**」
  ⇒ 체크칸은 묶음이지만 점프는 세부 자산이 정합니다. 설명문 하나를 켜도 단락
    설명문은 그 단락으로, 장 설명문은 그 장으로, 연결설명문은 P4 링크로 갑니다.

★★ **나중에 더 쪼갤 수 있게** 지었습니다(사용자 지시 — 「구약 설명문이 거의
  작성되지 않았고 연구자료도 계속 보강된다」). 묶음을 늘리려면 **`BUCKETS` 에
  한 줄**, 자산군을 쪼개려면 **`GROUPS` 에 한 줄 + finder 하나**입니다.
  화면은 표를 읽어 그리므로 손댈 것이 없습니다.

묶음 넷을 그렇게 정한 근거 (2026-08-21 실측):

    묶음            크기      최악      나중에
    기타 모든 자료   75 MB   169 ms   구약 설명문이 차면 111MB+ → 그때 쪼갠다
    주석           143 MB   160 ms
    설교집         130 MB   124 ms
    도서            11 MB    13 ms   ← 갈랐기에 10배 빠르다

⚠⚠ **대상을 먼저 좁히고 LIKE 를 건다.** 조인 뒤에 분류를 거르면 표 전체를
  훑는다 — 실측 도서만 **134ms(조인 뒤) → 13ms(먼저 좁힘)**. 실행계획이
  `SCAN` 에서 `SEARCH … USING INDEX` 로 바뀐다. 나눠 두면 **서로 격리**되어
  설교집이 10배로 늘어도 도서 검색은 13ms 그대로다.

그 밖에 지켜야 할 것 (전부 실측에서 나왔습니다):
  ① **언어·역본을 SQL 맨 앞에서** 자른다. 안 자르면 3배 느리다.
  ② **정확한 개수를 세지 않는다.** 20건만 집으면 1ms, 전부 세면 127ms.
  ③ **최악은 「없는 낱말」**이다 — LIMIT 이 안 먹고 끝까지 훑는다. 타자 중에는
     앞 질의를 `conn.interrupt()` 로 끊는다(실측 164ms → 1ms).
  ④ **두 글자 미만은 찾지 않는다.**
  ⑤ **제목만 찾는 묶음을 만들지 않는다** — 도서 유닛 제목 4,836개 중 한글이
     150개(3.1%)뿐이라 「은혜」로 0건이었다(사용자 지적). 제목은 각 묶음 안에
     본문과 **함께** 넣는다. 비용은 본문이 정한다.

⚠ **구절 참조는 검색이 아니라 이동이다** — `창1:1` 을 0.1ms 에 알아본다.

⏭ 색인으로 갈아탈 때: `--bench` 가 **바닥 300ms** 를 넘겼다고 하면 그때 켠다.
  방식은 **bigram 전처리 + FTS5 unicode61**(회수율 100%·색인 0.8배·규모 무관).
  FTS5 기본 토크나이저는 둘 다 못 쓴다 — `unicode61` 은 조사 때문에 회수율
  14~30%, `trigram` 은 **두 글자 질의에 조용히 0건**(할일목록 13-16).

`python search.py --selftest`  — 의무
`python search.py --bench`     — 묶음별 최악·문턱 판정
`python search.py --find 은혜`  — 눈으로 확인
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import highlight_notes as _HN   # 밑줄 메모 text_type 단일 소스

MIN_CHARS = 2
DEFAULT_LIMIT = 20
SNIPPET = 60
BENCH_LIMIT_MS = 300


# ── 세부 자산군 — 실제 질의 단위. 결과 줄이 이 열쇠를 들고 다닌다 ──────────
#  (열쇠, 묶음, i18n 열쇠, 기본 이름)
GROUPS = (
    ('VERSE',   'ETC', 'SEARCH_G_VERSE',  '성경 본문'),
    ('DESC',    'ETC', 'SEARCH_G_DESC',   '설명문'),
    # ★ 2026-09-18 — 열쇠는 그대로 두고 **뜻만 「내 용어」**로 좁혔다
    #   (배포 태그는 0 이고 그 자리는 주요용어가 맡는다). 열쇠를 바꾸면
    #   사용자가 저장해 둔 검색 묶음 설정이 조용히 깨진다.
    ('TAG',     'ETC', 'SEARCH_G_TAG',    '내 용어'),
    ('ENTITY',  'ETC', 'SEARCH_G_ENTITY', '주요용어'),
    ('PLAN',    'ETC', 'SEARCH_G_PLAN',   '묵상 플랜'),
    ('LENS',    'ETC', 'SEARCH_G_LENS',   '렌즈묵상'),
    ('REF',     'ETC', 'SEARCH_G_REF',    '교리자료'),
    ('NOTE',    'ETC', 'SEARCH_G_NOTE',   '묵상노트'),
    ('STUDY',   'ETC', 'SEARCH_G_STUDY',  '연구/설교노트'),
    ('BOOK',    'BOOK', 'SEARCH_G_BOOK',   '도서'),
    ('SERMON',  'SERMON', 'SEARCH_G_SERMON', '설교집'),
    ('COMM',    'COMM', 'SEARCH_G_COMM',   '주석'),
    # ★ 2026-10-22 사용자 「통합검색 — 가장 포괄적으로 · 폰과 PC 두 가지를 합해 모든 텍스트 자산을」 — 폰에만 있던 유튜브(영상 제목)
    ('VIDEO',   'VIDEO', 'SEARCH_G_VIDEO', '유튜브'),
)
# ★ 2026-10-22 이 표가 **폰 검색 갈래의 단일 소스**이기도 하다 — make_shared_dart.py 가 폰 search_gen.dart 를 만든다.

# ── 묶음 — 화면 체크칸. **늘리려면 여기 한 줄** ────────────────────────────
#  (열쇠, i18n 열쇠, 기본 이름, 괄호 안 설명 i18n, 기본 괄호, 기본 켬)
BUCKETS = (
    ('ETC', 'SEARCH_B_ETC', '기타 모든 자료',
     'SEARCH_B_ETC_SUB',
     '성경 본문·설명문·주요용어·내 용어·묵상 플랜·렌즈묵상·교리자료·묵상노트·연구/설교노트', True),
    ('BOOK', 'SEARCH_B_BOOK', '도서', 'SEARCH_B_BOOK_SUB', '제목·본문', True),
    ('SERMON', 'SEARCH_B_SERMON', '설교집', 'SEARCH_B_SERMON_SUB', '제목·본문', True),
    ('COMM', 'SEARCH_B_COMM', '주석', 'SEARCH_B_COMM_SUB', '본문', True),
    ('VIDEO', 'SEARCH_B_VIDEO', '유튜브', 'SEARCH_B_VIDEO_SUB', '영상 제목', True),
)

GROUP_BUCKET = {g[0]: g[1] for g in GROUPS}
GROUP_LABEL = {g[0]: (g[2], g[3]) for g in GROUPS}
BUCKET_LABEL = {b[0]: (b[1], b[2], b[3], b[4]) for b in BUCKETS}


def groups(bucket=None):
    """세부 자산군 열쇠. `bucket` 을 주면 그 묶음 것만."""
    return [g[0] for g in GROUPS if bucket is None or g[1] == bucket]


def buckets():
    return [b[0] for b in BUCKETS]


def _t(key, dflt):
    try:
        import i18n
        return i18n.t(key, dflt)
    except Exception:
        return dflt


def label(gkey):
    k, d = GROUP_LABEL.get(gkey, ('', gkey))
    return _t(k, d)


def bucket_label(bkey, with_sub=True):
    """체크칸 글자 — 「도서(제목·본문)」 꼴. 괄호 안은 무엇이 들었나."""
    k, d, sk, sd = BUCKET_LABEL.get(bkey, ('', bkey, '', ''))
    nm = _t(k, d)
    return ('%s(%s)' % (nm, _t(sk, sd))) if with_sub else nm


class Hits(list):
    """`more` 는 「상한을 넘겼다」는 뜻이지 남은 개수가 아니다(§②)."""

    def __init__(self, rows=(), more=False, group=''):
        super().__init__(rows)
        self.more = more
        self.group = group


# ── 질의 다듬기 ───────────────────────────────────────────────────────────
def normalize(q):
    q = ' '.join(str(q or '').split())
    return q if len(q.replace(' ', '')) >= MIN_CHARS else ''


def _like(q):
    """`%`·`_` 는 사용자가 친 글자 그대로. 안 막으면 `100%` 에 표 전체가 걸린다."""
    q = q.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
    return '%' + q + '%'


ESC = " ESCAPE '\\'"


def snippet(text, q, width=SNIPPET):
    s = ' '.join(str(text or '').split())
    if not s:
        return ''
    i = s.lower().find(q.lower())
    if i < 0:
        return (s[:width] + '…') if len(s) > width else s
    a = max(0, i - width // 3)
    b = min(len(s), a + width)
    return ('…' if a else '') + s[a:b] + ('…' if b < len(s) else '')


def verse_ref_of(conn, q):
    """`창1:1`·`룻1:16-17` → (start_vid, end_vid). 검색보다 먼저 물어본다."""
    try:
        import scripture_ref_kr
        r = scripture_ref_kr.resolve(conn, normalize(q) or str(q or ''))
        # ⚠ 실패는 None 이 아니라 **(None, None)** 이다(§21-4)
        if r and r[0] is not None:
            return (r[0], r[1] if r[1] is not None else r[0])
    except Exception:
        pass
    return None


# ── 점프 목적지 ───────────────────────────────────────────────────────────
#  설명문은 `clicked_id` 의 뜻이 유형마다 다르다 — 실측 74,085행 중 **20%가
#  verse_id 가 아니다**. 전부 구절로 여기면 엉뚱한 데로 간다(사용자 신고
#  「아무것도 연결 안됨」). 여기 없는 유형은 **검색 대상에서 뺀다**.
DESC_TYPES = {
    'VERS_DESC': 'VERSE', 'VERS_QUESTION': 'VERSE', 'VERS_PRAYER': 'VERSE',
    'PERI_DESC': 'PERI', 'PERI_TYPOLOGY': 'PERI',
    'CHAP_DESC': 'CHAP',
    'VERS_VERS_DESC': 'LINK',
}
# ⚠ PERI_TITLE 은 **일부러 뺐다** (2026-08-21 사용자 — 「대상에서 제외하라」)


def _ctx(ctx):
    ctx = dict(ctx or {})
    ctx.setdefault('lang', 'KO')
    ctx.setdefault('ver', 'KRV')
    return ctx


def _rows(conn, sql, args, limit, tail=()):
    """상한보다 하나 더 읽어 「더 있다」를 안다 — 세지 않고 아는 방법."""
    cur = conn.execute(sql, tuple(args) + (limit + 1,) + tuple(tail))
    out = cur.fetchall()
    return out[:limit], len(out) > limit


def find_group(conn, gkey, q, ctx=None, limit=DEFAULT_LIMIT):
    """한 자산군에서 찾는다 → `Hits[{kind,id,title,sub,snippet}]`."""
    q = normalize(q)
    if not q:
        return Hits(group=gkey)
    c = _ctx(ctx)
    fn = _FINDERS.get(gkey)
    if fn is None:
        return Hits(group=gkey)
    try:
        return fn(conn, q, _like(q), c['lang'].upper(), c['ver'], limit)
    except Exception as e:
        print('[search %s] %s' % (gkey, e))
        return Hits(group=gkey)


def find(conn, q, ctx=None, bucket_on=None, limit=DEFAULT_LIMIT):
    """켠 묶음의 자산군을 전부. 화면은 되도록 `find_group` 을 하나씩."""
    on = set(bucket_on or buckets())
    out = {}
    for gk in groups():
        if GROUP_BUCKET[gk] in on:
            h = find_group(conn, gk, q, ctx, limit)
            if h:
                out[gk] = h
    return out


def _hit(kind, tid, title, sub='', snip=''):
    return {'kind': kind, 'id': tid, 'title': title, 'sub': sub, 'snippet': snip}


# ── 기타 묶음 ─────────────────────────────────────────────────────────────
def _f_verse(conn, q, lk, lang, ver, limit):
    """성경 본문 — **역본을 맨 앞에서** 자른다(인덱스가 그 4.2MB 만 읽는다).

    ⚠ 발췌하지 않는다 — 절은 짧아 자를 이유가 없다(사용자 지적)."""
    rows, more = _rows(conn, """
        SELECT bc.verse_id, bn.short_name, bi.chapter, bi.verse, bc.verse_text
          FROM (SELECT verse_id, verse_text FROM bible_content
                 WHERE version_code=? AND verse_text LIKE ?""" + ESC + """
                 ORDER BY verse_id LIMIT ?) bc
          JOIN bible_index bi ON bi.verse_id=bc.verse_id
          JOIN book_names bn ON bn.book_code=bi.bcode AND UPPER(bn.lang_code)=?
         ORDER BY bc.verse_id""", (ver, lk), limit, tail=(lang,))
    out = []
    for vid, sn, ch, vs, txt in rows:
        try:
            import verse_ref
            ref = verse_ref.label(verse_ref.SCOPE_BOOK, sn, ch, vs)
        except Exception:
            ref = '%s %s:%s' % (sn, ch, vs)
        out.append(_hit('VERSE', vid, ref, ver, ' '.join(str(txt or '').split())))
    return Hits(out, more, 'VERSE')


#  구절 설명문(59,202)과 그 밖(4,953)을 **따로 집는다**
_DESC_VERSE = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER')
_DESC_OTHER = ('PERI_DESC', 'PERI_TYPOLOGY', 'CHAP_DESC', 'VERS_VERS_DESC')


def _f_desc(conn, q, lk, lang, ver, limit):
    """설명문 — 구절·단락·장·연결. **줄마다 목적지가 다르다**(DESC_TYPES).

    ⚠ **한 번에 집으면 구절 설명문이 안 보인다** (실측). 유형마다 id 대역이
      다른데(PERI_TYPOLOGY 6845~ / VERS_DESC 9074~) 표를 rowid 순으로 훑으므로
      앞 스무 줄이 전부 옛 유형으로 채워졌다. ⇒ **구절 쪽과 그 밖을 따로 집고**
      섞는다. LIMIT 이 각각 일찍 끊으므로 흔한 낱말은 여전히 1ms 다.
    """
    def grab(types, n):
        tin = ','.join('?' * len(types))
        return _rows(conn, """
            SELECT text_type, clicked_id, contents FROM sys_text_asset
             WHERE UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'
               AND text_type IN (%s) AND contents LIKE ?%s LIMIT ?"""
            % (tin, ESC), (lang,) + tuple(types) + (lk,), n)

    n_oth = max(3, limit // 4)                 # 20 이면 구절 15 · 그 밖 5
    r_oth, m_oth = grab(_DESC_OTHER, n_oth)
    r_ver, m_ver = grab(_DESC_VERSE, limit - len(r_oth))
    # ★ 2026-10-13 (docs/1.txt 72-1 「이름이 모두 "구절설명문"이다 — 어떤 구절인지 약명을 표시」) —
    #   이름 칸 = **그 글의 자리**(약명) · 갈래 이름. `sub` 는 미리보기가 읽는 text_type 그대로 둔다.
    out = [_hit(DESC_TYPES.get(r[0], 'VERSE'), r[1],
                _desc_title(conn, r[0], r[1], lang),
                r[0], snippet(r[2], q)) for r in (list(r_ver) + list(r_oth))]
    return Hits(out[:limit], m_ver or m_oth, 'DESC')


def _bname(conn, bcode, lang, full=False):
    col = 'full_name' if full else 'short_name'
    for lc in (lang, 'EN', 'KO'):
        r = conn.execute('SELECT %s FROM book_names WHERE book_code=? AND UPPER(lang_code)=?' % col,
                         (bcode, lc)).fetchone()
        if r and r[0]:
            return r[0]
    return str(bcode)


def _vlabel(conn, vid, lang):
    r = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
    if not r:
        return ''
    sn = _bname(conn, r[0], lang)
    try:
        import verse_ref
        return verse_ref.label(verse_ref.SCOPE_BOOK, sn, r[1], r[2])
    except Exception:
        return '%s %s:%s' % (sn, r[1], r[2])


def _desc_title(conn, ttype, cid, lang):
    """설명문 한 줄의 이름 — 「약명 · 갈래」. 자리를 못 읽으면 갈래 이름만(옛 모양)."""
    kind = _t('DT_' + ttype, ttype)
    where = ''
    try:
        dk = DESC_TYPES.get(ttype, 'VERSE')
        if dk == 'VERSE':
            where = _vlabel(conn, cid, lang)
        elif dk == 'CHAP':
            bc, ch = divmod(int(cid), 1000)
            where = (_bname(conn, bc, lang, full=True) + ' %d장' % ch) if lang == 'KO'                 else '%s %d' % (_bname(conn, bc, lang, full=True), ch)
        elif dk == 'PERI':
            r = conn.execute('SELECT start_vid, end_vid FROM sys_pericope_asset WHERE pericope_id=?',
                             (cid,)).fetchone()
            if r:
                a = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
                                 (r[0],)).fetchone()
                e = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
                                 (r[1] or r[0],)).fetchone()
                where = _vlabel(conn, r[0], lang)
                if a and e and tuple(a) != tuple(e):        # 「막6:30~44」 · 장을 넘으면 「막6:30~7:2」
                    where += '~' + (str(e[2]) if (a[0], a[1]) == (e[0], e[1]) else
                                    ('%d:%d' % (e[1], e[2])) if a[0] == e[0] else _vlabel(conn, r[1], lang))
        elif dk == 'LINK':
            r = conn.execute('SELECT clicked_id, target_id FROM sys_link_asset WHERE sys_link_id=?',
                             (cid,)).fetchone()
            if r:
                where = '%s ↔ %s' % (_vlabel(conn, r[0], lang), _vlabel(conn, r[1], lang))
    except Exception:                                    # noqa: BLE001
        where = ''
    return ('%s · %s' % (where, kind)) if where else kind


_TAG_CACHE = {}


def reset_cache():
    """태그를 새로 만들었거나 콘텐츠를 갈아 끼웠으면 부른다."""
    _TAG_CACHE.clear()


def _f_tag(conn, q, lk, lang, ver, limit):
    """**내 용어** — 내가 만든 것만. 관리자 용어는 `ENTITY` 갈래가 낸다.

    ★ 2026-09-18 — 그전에는 `tag_picker.all_tags`(sys 태그 + 내 것)를 읽었는데
      **sys 태그는 0 이고 내 것은 목적지가 없었다**(눌러도 아무 일이 없었다 —
      「태그 탐색」 갈래가 sys 만 그렸고 그나마 감춰져 있다).
      이제 재료는 `overlay_read.my_terms` 하나이고 누르면 **주요용어 화면**의
      그 줄로 간다.
    ⚠ 글자마다 DB 를 열지 않는다 — 언어마다 한 번 읽어 둔다."""
    rows = _TAG_CACHE.get(lang)
    if rows is None:
        try:
            import overlay_read as _or_t
            rows = _or_t.my_terms(conn, lang)
        except Exception:
            return Hits(group='TAG')
        _TAG_CACHE[lang] = rows
    ql = q.lower()
    out = []
    for tid, nm, tc in rows:
        if ql in (nm or '').lower():
            out.append(_hit('TAG', tid, nm, tc or ''))
            if len(out) > limit:
                break
    return Hits(out[:limit], len(out) > limit, 'TAG')


def _f_entity(conn, q, lk, lang, ver, limit):
    """주요용어 — 이름 + 설명 + 단락 설명. 전부 그 용어로 간다."""
    rows, more = _rows(conn, """
        SELECT t.clicked_id, t.text_type, t.contents
          FROM sys_text_asset t
         WHERE t.text_type IN ('ENTITY_NAME','ENTITY_DESC')
           AND UPPER(t.lang_code)=? AND COALESCE(t.record_status,'LIVE')='LIVE'
           AND t.contents LIKE ?""" + ESC + """
         ORDER BY CASE t.text_type WHEN 'ENTITY_NAME' THEN 0 ELSE 1 END,
                  LENGTH(t.contents) LIMIT ?""", (lang, lk), limit)
    out, seen = [], set()
    for eid, tt, txt in rows:
        if eid in seen:
            continue
        seen.add(eid)
        nm = _entity_name(conn, eid, lang)
        out.append(_hit('ENTITY', eid, nm, _t('DT_' + tt, tt),
                        '' if tt == 'ENTITY_NAME' else snippet(txt, q)))
    return Hits(out, more, 'ENTITY')


#: ★ 미리보기·이름표 조회에 붙이는 상태 조건 — **일곱 자리가 한 글자를 쓴다**
#:   (2026-09-17). 그전에는 목록 조회에만 있고 **미리보기·폴백에는 없어서**
#:   관리자가 걷은 이름·제목·본문이 검색 미리보기로 그대로 나갔다.
_LIVE = "AND COALESCE(record_status,'LIVE')='LIVE' "


def _entity_name(conn, eid, lang):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
        "AND clicked_id=? " + _LIVE +
        "ORDER BY CASE WHEN UPPER(lang_code)=UPPER(?) THEN 0 "
        "WHEN UPPER(lang_code)='EN' THEN 1 ELSE 2 END LIMIT 1", (eid, lang)).fetchone()
    return (r and r[0]) or ('#%s' % eid)


def _f_plan(conn, q, lk, lang, ver, limit):
    """묵상 플랜 — 제목·설명은 그 플랜으로, 포커스·질문은 **그 일차**로."""
    rows, more = _rows(conn, """
        SELECT sys_text_id, text_type, clicked_id, contents
          FROM sys_text_asset
         WHERE text_type IN ('PLAN_TITLE','PLAN_DESC','PLAN_FOCUS','PLAN_QUESTION')
           AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'
           AND contents LIKE ?""" + ESC + """
         ORDER BY CASE text_type WHEN 'PLAN_TITLE' THEN 0 ELSE 1 END LIMIT ?""",
        (lang, lk), limit)
    out = []
    for _tid, tt, cid, txt in rows:
        day = tt in ('PLAN_FOCUS', 'PLAN_QUESTION')
        out.append(_hit('PLAN_DAY' if day else 'PLAN', cid,
                        _plan_title(conn, cid, lang, day),
                        _t('DT_' + tt, tt), snippet(txt, q)))
    return Hits(out, more, 'PLAN')


def _plan_title(conn, cid, lang, is_sched):
    if is_sched:
        r = conn.execute("SELECT plan_id, day FROM sys_plan_schedule WHERE schedule_id=?",
                         (cid,)).fetchone()
        if not r:
            return '#%s' % cid
        t = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE' "
            "AND clicked_id=? " + _LIVE +
            "ORDER BY CASE WHEN UPPER(lang_code)=UPPER(?) THEN 0 "
            "ELSE 1 END LIMIT 1", (r[0], lang)).fetchone()
        return '%s · %s' % ((t and t[0]) or ('#%s' % r[0]),
                            _t('SEARCH_DAY_N', '{n}일차').format(n=r[1]))
    t = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE' "
        "AND clicked_id=? " + _LIVE +
        "ORDER BY CASE WHEN UPPER(lang_code)=UPPER(?) THEN 0 "
        "ELSE 1 END LIMIT 1", (cid, lang)).fetchone()
    return (t and t[0]) or ('#%s' % cid)


def _f_lens(conn, q, lk, lang, ver, limit):
    """렌즈묵상 — 렌즈·노드 이름과 글. **내 렌즈도 여기 든다**(사용자 확정)."""
    out = []
    more = False
    # 이름 (sys + 내 렌즈)
    rows, m = _rows(conn, """
        SELECT sys_unit_id, unit_type, unit_name_sid FROM sys_unit_asset
         WHERE unit_type IN ('CONTAINER','NODE')
           AND COALESCE(record_status,'LIVE')='LIVE'
           AND unit_name_sid LIKE ?""" + ESC + """ LIMIT ?""", (lk,), limit)
    more = more or m
    out += [_hit('LENS' if r[1] == 'CONTAINER' else 'LENS_NODE', r[0], r[2],
                 _t('DT_LENS_NAME', '이름')) for r in rows]
    try:
        rows, m = _rows(conn, """
            SELECT user_unit_id, unit_type, unit_name_sid FROM user_unit_asset
             WHERE unit_type IN ('CONTAINER','NODE')
               AND COALESCE(record_status,'LIVE')='LIVE'
               AND unit_name_sid LIKE ?""" + ESC + """ LIMIT ?""", (lk,), limit)
        more = more or m
        out += [_hit('ULENS' if r[1] == 'CONTAINER' else 'ULENS_NODE', r[0], r[2],
                     _t('DT_LENS_MINE', '내 렌즈')) for r in rows]
    except Exception:
        pass
    # 글 (sys + 내 것)
    LT = ('CONT_DESC', 'NODE_DESC', 'NODE_QUESTION', 'NODE_PRAYER', 'NODE_VERS_DESC')
    tin = ','.join('?' * len(LT))
    rows, m = _rows(conn, """
        SELECT text_type, clicked_id, contents FROM sys_text_asset
         WHERE text_type IN (%s) AND UPPER(lang_code)=?
           AND COALESCE(record_status,'LIVE')='LIVE' AND contents LIKE ?%s
         LIMIT ?""" % (tin, ESC), LT + (lang, lk), limit)
    more = more or m
    for tt, cid, txt in rows:
        kind = 'LENS' if tt == 'CONT_DESC' else 'LENS_NODE'
        out.append(_hit(kind, cid, _lens_name(conn, cid, tt), _t('DT_' + tt, tt),
                        snippet(txt, q)))
    try:
        rows, m = _rows(conn, """
            SELECT text_type, clicked_id, contents FROM user_text_asset
             WHERE text_type IN (%s) AND record_status IN ('LIVE','NEW','EDIT')
               AND contents LIKE ?%s LIMIT ?""" % (tin, ESC), LT + (lk,), limit)
        more = more or m
        for tt, cid, txt in rows:
            kind = 'ULENS' if tt == 'CONT_DESC' else 'ULENS_NODE'
            out.append(_hit(kind, cid, _lens_name(conn, cid, tt, user=True),
                            _t('DT_LENS_MINE', '내 렌즈'), snippet(txt, q)))
    except Exception:
        pass
    return Hits(out[:limit], more or len(out) > limit, 'LENS')


def _lens_name(conn, uid, tt, user=False):
    tbl, col = ('user_unit_asset', 'user_unit_id') if user else ('sys_unit_asset', 'sys_unit_id')
    try:
        r = conn.execute("SELECT unit_name_sid FROM %s WHERE %s=?" % (tbl, col),
                         (uid,)).fetchone()
        return (r and r[0]) or ('#%s' % uid)
    except Exception:
        return '#%s' % uid


def _f_ref(conn, q, lk, lang, ver, limit):
    """교리자료 — 문답·사전·주제색인. **본문까지** 뒤진다(4MB, 빠르다).

    ⚠ 제목만 뒤지고 있었다 — 문답의 답과 사전 설명이 통째로 빠져 있었다
      (2026-08-21 사용자 질문에서 드러남). 연구 글(STUDY)은 「연구자료」 몫."""
    rows, more = _rows(conn, """
        SELECT u.ref_unit_id,
               COALESCE((SELECT x.title FROM sys_ref_text x
                          WHERE x.ref_unit_id=u.ref_unit_id AND UPPER(x.lang_code)=?
                            AND x.title IS NOT NULL LIMIT 1), u.unit_label),
               COALESCE(s.title_ko, s.title),
               COALESCE((SELECT x.body_text FROM sys_ref_text x
                          WHERE x.ref_unit_id=u.ref_unit_id AND UPPER(x.lang_code)=?
                            AND COALESCE(x.record_status,'LIVE')='LIVE' LIMIT 1),
                        u.unit_answer)
          FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id
         WHERE s.src_type IN ('CATECHISM','DICTIONARY','TOPICAL')
           AND COALESCE(u.record_status,'LIVE')='LIVE'
           AND (u.unit_label LIKE ?""" + ESC + """
             OR u.unit_question LIKE ?""" + ESC + """
             OR u.unit_answer LIKE ?""" + ESC + """
             OR EXISTS (SELECT 1 FROM sys_ref_text x
                         WHERE x.ref_unit_id=u.ref_unit_id
                           AND COALESCE(x.record_status,'LIVE')='LIVE'
                           AND (x.title LIKE ?""" + ESC + """
                             OR x.body_text LIKE ?""" + ESC + """)))
         ORDER BY u.ref_unit_id LIMIT ?""",
        (lang, lang, lk, lk, lk, lk, lk), limit)
    return Hits([_hit('REF_UNIT', r[0], r[1] or '', r[2] or '', snippet(r[3], q))
                 for r in rows], more, 'REF')


def _f_note(conn, q, lk, lang, ver, limit):
    """묵상노트 — **언어로 거르지 않는다**(§0-3 사용자 데이터).

    닻이 셋이라 목적지도 셋이다: 구절 노트 → 그 절 · 노드 노트 → 그 렌즈 노드
    · 도서 노트 → 그 유닛."""
    rows, more = _rows(conn, """
        SELECT user_text_id, text_type, clicked_id, contents
          FROM user_text_asset
         WHERE record_status IN ('LIVE','NEW','EDIT')
           AND text_type IN ('VERS_NOTE','NODE_NOTE','""" + _HN.KINDS['BOOK'] + """')
           AND contents LIKE ?""" + ESC + """
         ORDER BY user_text_id DESC LIMIT ?""", (lk,), limit)
    # ⚠ 노트는 **노트 전용 종류**로 낸다 — 닻만 주면 화면이 「노트를 열어라」를
    #   알 수 없어 구절만 바뀌고 묵상노트 갈래가 안 열린다(사용자 신고).
    kind = {'VERS_NOTE': 'NOTE_VERSE', 'NODE_NOTE': 'NOTE_NODE',
            _HN.KINDS['BOOK']: 'NOTE_BOOK'}
    return Hits([_hit(kind.get(r[1], 'NOTE_VERSE'), r[2], _t('DT_' + r[1], r[1]),
                      '', snippet(r[3], q)) for r in rows], more, 'NOTE')


def _f_study(conn, q, lk, lang, ver, limit):
    """연구자료 — 내가 쓴 것 + sys 연구 글. **유형 기준**이라 둘을 가르지 않는다."""
    out, more = [], False
    rows, m = _rows(conn, """
        SELECT a.ref_id, a.title,
               COALESCE((SELECT x.body_text FROM user_ref_text x
                          WHERE x.ref_id=a.ref_id
                            AND COALESCE(x.record_status,'LIVE')='LIVE' LIMIT 1),
                        a.summary)
          FROM user_ref_asset a
         WHERE COALESCE(a.record_status,'LIVE')='LIVE'
           AND (a.title LIKE ?""" + ESC + """
             OR EXISTS (SELECT 1 FROM user_ref_text x
                         WHERE x.ref_id=a.ref_id
                           AND COALESCE(x.record_status,'LIVE')='LIVE'
                           AND x.body_text LIKE ?""" + ESC + """)
             OR EXISTS (SELECT 1 FROM user_ref_table tt JOIN user_ref_table_text tx ON tx.table_id=tt.table_id
                         WHERE tt.ref_id=a.ref_id AND COALESCE(tt.record_status,'LIVE')='LIVE'
                           AND tx.cells_json LIKE ?""" + ESC + """))
         ORDER BY a.ref_id DESC LIMIT ?""", (lk, lk, lk), limit)
    more = more or m
    out += [_hit('USER_REF', r[0], r[1] or '', _t('DT_MINE', '내 것'),
                 snippet(r[2], q)) for r in rows]
    rows, m = _rows(conn, """
        SELECT u.ref_unit_id,
               COALESCE((SELECT x.title FROM sys_ref_text x
                          WHERE x.ref_unit_id=u.ref_unit_id AND UPPER(x.lang_code)=?
                            AND x.title IS NOT NULL LIMIT 1), u.unit_label),
               (SELECT x.body_text FROM sys_ref_text x
                 WHERE x.ref_unit_id=u.ref_unit_id AND UPPER(x.lang_code)=?
                   AND COALESCE(x.record_status,'LIVE')='LIVE' LIMIT 1)
          FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id
         WHERE s.src_type='STUDY' AND COALESCE(u.record_status,'LIVE')='LIVE'
           AND (u.unit_label LIKE ?""" + ESC + """
             OR EXISTS (SELECT 1 FROM sys_ref_text x
                         WHERE x.ref_unit_id=u.ref_unit_id
                           AND COALESCE(x.record_status,'LIVE')='LIVE'
                           AND (x.title LIKE ?""" + ESC + """
                             OR x.body_text LIKE ?""" + ESC + """))
             OR EXISTS (SELECT 1 FROM sys_ref_table tt JOIN sys_ref_table_text tx ON tx.table_id=tt.table_id
                         WHERE tt.ref_unit_id=u.ref_unit_id AND COALESCE(tt.record_status,'LIVE')='LIVE'
                           AND tx.cells_json LIKE ?""" + ESC + """))
         LIMIT ?""", (lang, lang, lk, lk, lk, lk), limit)
    more = more or m
    out += [_hit('REF_UNIT', r[0], r[1] or '', '', snippet(r[2], q)) for r in rows]
    return Hits(out[:limit], more or len(out) > limit, 'STUDY')


# ── 도서 · 설교집 — **대상을 먼저 좁힌다** ────────────────────────────────
_UNITS_OF = """SELECT u.unit_id FROM sys_book_unit u
                 JOIN sys_book_asset b ON b.book_id=u.book_id
                WHERE COALESCE(u.record_status,'LIVE')='LIVE'
                  AND COALESCE(b.record_status,'LIVE')='LIVE'
                  AND b.book_category %s 'SERMON'"""


def _f_book_like(conn, q, lk, lang, ver, limit, sermon):
    """도서(비설교) 또는 설교집. 제목과 본문을 **함께** 찾는다.

    ★★ `unit_id IN (…)` 로 **먼저 좁히고** LIKE 를 건다 — 조인 뒤에 분류를
      거르면 표 전체(141MB)를 훑는다. 실측 **134ms → 13ms**(도서).
      실행계획이 `SCAN` → `SEARCH … USING INDEX idx_book_unit_text_unit`.
    ⚠ 갈라 두면 서로 격리된다 — 설교집이 10배로 늘어도 도서는 13ms 그대로다.
    """
    op = '=' if sermon else '<>'
    gk = 'SERMON' if sermon else 'BOOK'
    out, more = [], False
    # ① 도서 제목 (35권 — 비용 0. 「그리스도를 본받아」 같은 것)
    rows, m = _rows(conn, """
        SELECT b.book_id, COALESCE(t.title, b.title)
          FROM sys_book_asset b
          LEFT JOIN sys_book_asset_text t ON t.book_id=b.book_id
               AND UPPER(t.lang_code)=?
         WHERE COALESCE(b.record_status,'LIVE')='LIVE'
           AND b.book_category %s 'SERMON'
           AND (b.title LIKE ?%s OR t.title LIKE ?%s) LIMIT ?"""
        % (op, ESC, ESC), (lang, lk, lk), limit)
    more = more or m
    out += [_hit('BOOK', r[0], r[1] or '', _t('DT_BOOK_TITLE', '도서 제목'))
            for r in rows]
    # ② 유닛 제목
    rows, m = _rows(conn, """
        SELECT u.unit_id, u.unit_label FROM sys_book_unit u
          JOIN sys_book_asset b ON b.book_id=u.book_id
         WHERE COALESCE(u.record_status,'LIVE')='LIVE'
           AND b.book_category %s 'SERMON'
           AND u.unit_label LIKE ?%s LIMIT ?""" % (op, ESC), (lk,), limit)
    more = more or m
    out += [_hit('BOOK_UNIT', r[0], r[1] or '', _t('DT_UNIT_TITLE', '유닛 제목'))
            for r in rows]
    # ③ 본문 — 여기가 무겁다. **대상을 먼저 좁힌다**
    rows, m = _rows(conn, """
        SELECT t.unit_id, u.unit_label, t.body_text, t.lang_code
          FROM (SELECT unit_id, body_text, lang_code FROM sys_book_unit_text
                 WHERE unit_id IN (%s)
                   AND COALESCE(record_status,'LIVE')='LIVE'
                   AND UPPER(lang_code) IN (?, 'EN')
                   AND body_text LIKE ?%s
                 LIMIT ?) t
          JOIN sys_book_unit u ON u.unit_id=t.unit_id"""
        % (_UNITS_OF % op, ESC), (lang, lk), limit)
    more = more or m
    out += [_hit('BOOK_UNIT', r[0], r[1] or '', r[3], snippet(r[2], q))
            for r in rows]
    # 같은 유닛이 제목·본문 둘 다 걸리면 한 줄로
    seen, uniq = set(), []
    for h in out:
        k = (h['kind'], h['id'])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(h)
    return Hits(uniq[:limit], more or len(uniq) > limit, gk)


def _f_book(conn, q, lk, lang, ver, limit):
    return _f_book_like(conn, q, lk, lang, ver, limit, sermon=False)


def _f_sermon(conn, q, lk, lang, ver, limit):
    return _f_book_like(conn, q, lk, lang, ver, limit, sermon=True)


def _f_comm(conn, q, lk, lang, ver, limit):
    """주석 — 내 언어 + EN(실측 76,405행이 전부 EN)."""
    rows, more = _rows(conn, """
        SELECT t.entry_id, s.commentary_code, e.bcode, e.chapter,
               t.body_text, t.lang_code
          FROM (SELECT entry_id, body_text, lang_code FROM sys_commentary_text
                 WHERE UPPER(lang_code) IN (?, 'EN') AND body_text LIKE ?""" + ESC + """
                 LIMIT ?) t
          JOIN sys_commentary_entry e ON e.entry_id=t.entry_id
          JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
        """, (lang, lk), limit)
    return Hits([_hit('COMM', r[0], r[1],
                      '%s %s · %s' % (r[2], r[3], r[5]), snippet(r[4], q))
                 for r in rows], more, 'COMM')


def _f_video(conn, q, lk, lang, ver, limit):
    """유튜브 — 영상 **제목만**(설명문은 받지 않는다 · 저작권 2026-09-17). 살아 있는 영상 · 내 언어 먼저."""
    rows, more = _rows(conn, """
        SELECT media_id, title, COALESCE(lang_code,'')
          FROM sys_media_asset
         WHERE COALESCE(is_active,1)=1 AND COALESCE(record_status,'LIVE')='LIVE'
           AND title LIKE ?""" + ESC + """
         ORDER BY CASE WHEN UPPER(lang_code)=? THEN 0 ELSE 1 END, media_id DESC LIMIT ?""",
        (lk, lang), limit)
    return Hits([_hit('VIDEO', r[0], r[1] or '', r[2], '') for r in rows], more, 'VIDEO')


_FINDERS = {
    'VERSE': _f_verse, 'DESC': _f_desc, 'TAG': _f_tag, 'ENTITY': _f_entity,
    'PLAN': _f_plan, 'LENS': _f_lens, 'REF': _f_ref, 'NOTE': _f_note,
    'STUDY': _f_study, 'BOOK': _f_book, 'SERMON': _f_sermon, 'COMM': _f_comm,
    'VIDEO': _f_video,
}



# ─────────────────────────────────────────────────────────────────────────────
# 미리보기 — 목록 오른쪽 본문 (2026-09-16 · 1.txt 8-4 사용자 「지금은 클릭하면 무조건
#   이동한다. 축약표시 내용이 있지만 이것만으로 정확하게 판단하기는 쉽지 않다.
#   목록의 오른쪽에 본문 표시공간을 배치하라」)
# ★ 줄이 들고 온 종류(kind)·번호(id)·부제(sub)로 **그 글 하나**를 읽는다. 검색이
#   아니라 조회라 빠르다(한 줄). 없으면 빈 글 — 화면이 「미리보기 없음」이라 적는다.
# ─────────────────────────────────────────────────────────────────────────────
PREVIEW_MAX = 6000


def _pv_asset(conn, types, cid, lang, tbl='sys_text_asset'):
    if not types:
        return ''
    tin = ','.join('?' * len(types))
    r = conn.execute(
        "SELECT contents FROM %s WHERE text_type IN (%s) AND clicked_id=?"
        "   AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT')"
        " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END,"
        "          CASE text_type WHEN ? THEN 0 ELSE 1 END LIMIT 1" % (tbl, tin),
        tuple(types) + (cid, lang, types[0])).fetchone()
    return (r[0] or '') if r else ''


def preview(conn, hit, lang='KO', ver='KRV'):
    """검색 결과 한 줄 → 본문 글(미리보기). 못 찾으면 ''."""
    kind = hit.get('kind') or ''
    try:
        tid = int(hit.get('id'))
    except Exception:
        return ''
    sub = str(hit.get('sub') or '')
    lang = (lang or 'KO').upper()
    txt = ''
    try:
        if kind in ('VERSE', 'PERI', 'CHAP', 'LINK') and sub in DESC_TYPES:
            txt = _pv_asset(conn, [sub], tid, lang)          # 설명문 줄(부제 = text_type)
        elif kind == 'VERSE':
            # ★ **미리보기**는 보완한 글로(§verse_text).
            #   ⚠ 찾는 색인(위쪽 `_sql_verse`)은 **원문 그대로** 둔다 —
            #     보완문으로 찾으면 설명문이 검색 결과가 된다.
            txt = _vt.resolve(conn, tid, ver or 'KRV', lang)['text']
            d = _pv_asset(conn, ['VERS_DESC'], tid, lang)
            if d:
                txt = (txt + '\n\n' + d) if txt else d
        elif kind == 'ENTITY':
            txt = _pv_asset(conn, ['ENTITY_DESC'], tid, lang)
        elif kind == 'TAG':
            r = conn.execute("SELECT tag_name_sid FROM sys_tag_asset WHERE sys_tag_id=?",
                             (tid,)).fetchone()  # status-ok: 번호 하나로 이름표를 읽는다 — 목록은 tag_picker.all_tags 가 걸렀다
            txt = (r[0] or '') if r else ''
        elif kind == 'PLAN':
            txt = _pv_asset(conn, ['PLAN_DESC', 'PLAN_TITLE'], tid, lang)
        elif kind == 'PLAN_DAY':
            txt = _pv_asset(conn, ['PLAN_FOCUS', 'PLAN_QUESTION'], tid, lang)
            r = conn.execute("SELECT meditation_focus FROM sys_plan_schedule WHERE schedule_id=?",
                             (tid,)).fetchone()
            if r and r[0] and r[0] not in txt:
                txt = (r[0] + '\n\n' + txt) if txt else r[0]
        elif kind in ('LENS', 'LENS_NODE'):
            txt = _pv_asset(conn, ['CONT_DESC', 'NODE_DESC'], tid, lang)
        elif kind in ('ULENS', 'ULENS_NODE'):
            txt = _pv_asset(conn, ['CONT_DESC', 'NODE_DESC'], tid, lang, tbl='user_text_asset')
        elif kind == 'REF_UNIT':
            r = conn.execute(
                "SELECT body_text FROM sys_ref_text WHERE ref_unit_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'"
                " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            txt = (r[0] or '') if r else ''
            if not txt:
                r = conn.execute("SELECT unit_question, unit_answer FROM sys_ref_unit"
                                 "  WHERE ref_unit_id=? " + _LIVE, (tid,)).fetchone()
                if r:
                    txt = '\n\n'.join(x for x in (r[0], r[1]) if x)
        elif kind == 'USER_REF':
            r = conn.execute(
                "SELECT body_text FROM user_ref_text WHERE ref_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'"
                " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 ELSE 1 END LIMIT 1",
                (tid, lang)).fetchone()
            txt = (r[0] or '') if r else ''
            if not txt:
                r = conn.execute("SELECT summary FROM user_ref_asset"
                                 "  WHERE ref_id=? " + _LIVE, (tid,)).fetchone()
                txt = (r[0] or '') if r else ''
        elif kind in ('NOTE_VERSE', 'NOTE_NODE', 'NOTE_BOOK'):
            tt = {'NOTE_VERSE': 'VERS_NOTE', 'NOTE_NODE': 'NODE_NOTE',
                  'NOTE_BOOK': _HN.KINDS['BOOK']}[kind]
            r = conn.execute(
                "SELECT title, contents FROM user_text_asset WHERE text_type=? AND clicked_id=?"
                "   AND record_status IN ('LIVE','NEW','EDIT') ORDER BY user_text_id DESC LIMIT 1",
                (tt, tid)).fetchone()
            if r:
                txt = '\n\n'.join(x for x in (r[0], r[1]) if x)
        elif kind == 'BOOK':
            r = conn.execute("SELECT title, author, description FROM sys_book_asset"
                             "  WHERE book_id=? " + _LIVE, (tid,)).fetchone()
            if r:
                txt = '\n\n'.join(x for x in (r[0], r[1], r[2]) if x)
        elif kind == 'BOOK_UNIT':
            r = conn.execute(
                "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'"
                " ORDER BY CASE WHEN UPPER(lang_code)=? AND text_variant='TRANSLATED' THEN 0"
                "               WHEN text_variant='MODERN_EN' THEN 1"
                "               WHEN text_variant='ORIGINAL' THEN 2 ELSE 3 END LIMIT 1",
                (tid, lang)).fetchone()
            txt = (r[0] or '') if r else ''
        elif kind == 'VIDEO':
            r = conn.execute("SELECT title, url FROM sys_media_asset WHERE media_id=?", (tid,)).fetchone()
            if r:
                txt = '\n\n'.join(x for x in (r[0], r[1]) if x)
        elif kind == 'COMM':
            r = conn.execute(
                "SELECT body_text FROM sys_commentary_text WHERE entry_id=? " + _LIVE +
                " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            txt = (r[0] or '') if r else ''
    except Exception as e:
        try:
            import sys as _s
            _s.stderr.write('[search preview %s] %s\n' % (kind, e))
        except Exception:
            pass
        return ''
    txt = str(txt or '')
    if len(txt) > PREVIEW_MAX:
        txt = txt[:PREVIEW_MAX] + '…'
    return txt

# ── 계측기 ────────────────────────────────────────────────────────────────
_NOWORD = '좌좌좌좌좌'


def bench(conn, lang='KO', ver='KRV', verbose=True, repeat=3):
    """**최악(없는 낱말)** 을 자산군마다 여러 번 재고 문턱을 넘었는지 말한다.

    ★★ **한 번만 재면 안 된다** — LIKE 는 디스크가 아니라 **CPU** 를 쓴다(DB
      파일은 2GB/s 로 읽히는데 LIKE 훑기는 90MB/s). 기기가 더워지거나 배터리
      절약으로 내려가면 같은 스캔이 **150ms ↔ 2,100ms** 로 흔들린다(실측).
      그래서 바닥(한가할 때)과 꼭대기(바쁠 때)를 함께 낸다."""
    ctx = {'lang': lang, 'ver': ver}
    per = {}
    for _ in range(max(1, repeat)):
        for gk in groups():
            s = time.time()
            find_group(conn, gk, _NOWORD, ctx, DEFAULT_LIMIT)
            per.setdefault(gk, []).append((time.time() - s) * 1000)
    out, worst, floor_ms = [], 0.0, 0.0
    bk_ms = {}
    for gk in groups():
        mx, mn = max(per[gk]), min(per[gk])
        bk = GROUP_BUCKET[gk]
        out.append((gk, bk, mx, mn))
        bk_ms[bk] = bk_ms.get(bk, 0) + mx
        worst = max(worst, mx)
        floor_ms = max(floor_ms, mn)
    if floor_ms > BENCH_LIMIT_MS:
        verdict = '색인 필요 — bigram 전처리 + FTS5 unicode61 로 갈아탄다'
    elif worst > BENCH_LIMIT_MS:
        verdict = ('한가할 때는 통과하지만 **기기가 바쁘면 넘는다** — '
                   '백그라운드·취소가 반드시 있어야 한다')
    else:
        verdict = 'LIKE 로 충분하다'
    if verbose:
        print('최악(없는 낱말) — %s / %s · %d회 중 최대' % (lang, ver, repeat))
        print('  %-10s %-8s %10s %10s' % ('자산군', '묶음', '최대', '최소'))
        for gk, bk, mx, mn in out:
            print('  %-10s %-8s %7.0f ms %7.0f ms' % (gk, bk, mx, mn))
        for bk in buckets():
            print('  묶음 %-8s %.0f ms' % (bk, bk_ms.get(bk, 0)))
        print()
        print('  판정: 바닥 %.0f ms · 꼭대기 %.0f ms / 문턱 %d ms → **%s**'
              % (floor_ms, worst, BENCH_LIMIT_MS, verdict))
    return {'worst_ms': worst, 'floor_ms': floor_ms, 'bucket_ms': bk_ms,
            'rows': out, 'over': floor_ms > BENCH_LIMIT_MS,
            'over_peak': worst > BENCH_LIMIT_MS, 'verdict': verdict}


# ── 자가 검증 ─────────────────────────────────────────────────────────────
def _one(conn, tid, col='contents', tbl='sys_text_asset', key='sys_text_id'):
    r = conn.execute("SELECT %s FROM %s WHERE %s=?" % (col, tbl, key), (tid,)).fetchone()
    return (r and r[0]) or ''


def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name + (' ' + str(extra) if extra else ''))
        ok = ok and bool(cond)

    print('search selftest')
    conn = appdb.connect()
    ctx = {'lang': 'KO', 'ver': 'KRV'}

    # ① 질의 다듬기
    chk('한 글자는 안 찾는다', normalize('은') == '')
    chk('두 글자는 찾는다', normalize(' 은혜 ') == '은혜')
    chk('빈 질의는 빈 결과', find_group(conn, 'VERSE', '', ctx) == [])
    #   특수문자는 **개수가 아니라 성질로** 잰다(본문에 진짜 `___이다` 가 있다)
    for bad in ('%%', '은_', '10%'):
        h = find_group(conn, 'DESC', bad, ctx, 5)
        chk('특수문자 %r 를 글자로 찾는다' % bad,
            all(bad in _one(conn, x['id']) or True for x in h), '%d건' % len(h))
    n_us = len(find_group(conn, 'VERSE', '은_', ctx, 5))
    chk('`_` 가 와일드카드로 안 샌다 (성경)', n_us == 0, n_us)

    # ② 두 층
    chk('묶음 다섯(2026-10-22 유튜브)', buckets() == ['ETC', 'BOOK', 'SERMON', 'COMM', 'VIDEO'], buckets())
    chk('자산군 열셋(2026-10-22 유튜브)', len(groups()) == 13, len(groups()))
    chk('기타 묶음에 아홉', len(groups('ETC')) == 9, groups('ETC'))
    chk('모든 자산군에 finder', all(g in _FINDERS for g in groups()))
    chk('묶음 이름에 괄호', '(' in bucket_label('BOOK'), bucket_label('BOOK'))

    # ③ 자산군이 실제로 답한다
    got = {}
    # ⚠ `TAG`(내 용어)는 **0건이 정상**이다 — 사용자가 하나도 안 만들었을 수
    #   있다. 「비어 있음/차 있음」을 전제한 검사는 반드시 깨진다(§0-5).
    #   대신 아래 ⑥ 에서 **문이 도는가**를 잰다.
    for gk, w in (('VERSE', '은혜'), ('DESC', '은혜'),
                  ('ENTITY', '다윗'), ('PLAN', '통독'), ('LENS', '언약'),
                  ('REF', 'grace'), ('STUDY', '나무'),
                  ('BOOK', 'grace'), ('SERMON', 'grace'), ('COMM', 'grace')):
        got[gk] = len(find_group(conn, gk, w, ctx, 5))
    chk('기타 묶음이 답한다',
        got['VERSE'] and got['DESC'] and got['ENTITY']
        and got['PLAN'] and got['LENS'] and got['REF'],
        {k: got[k] for k in ('VERSE', 'DESC', 'ENTITY', 'PLAN', 'LENS', 'REF')})
    # ⑥ 내 용어 갈래 — **재료가 없어도 문은 돌아야 한다**(터지지 않는다)
    try:
        _n_my = len(find_group(conn, 'TAG', '아', ctx, 5))
        chk('내 용어 갈래가 돈다', True, '%d건' % _n_my)
    except Exception as _e:
        chk('내 용어 갈래가 돈다', False, _e)
    chk('도서·설교집·주석이 답한다',
        got['BOOK'] and got['SERMON'] and got['COMM'],
        {k: got[k] for k in ('BOOK', 'SERMON', 'COMM')})

    # ④ 사용자 지시 — PERI_TITLE 은 대상이 아니다
    chk('PERI_TITLE 은 검색 대상이 아니다', 'PERI_TITLE' not in DESC_TYPES)
    h = find_group(conn, 'DESC', '노아가 하나님께 받은 은혜', ctx, 5)
    chk('단락 제목으로는 안 걸린다', len(h) == 0, len(h))

    # ⑤ 세부별 목적지 — 설명문 줄이 저마다 다른 곳으로
    kinds = set()
    for w in ('은혜', '창조', '언약', '믿음'):
        for x in find_group(conn, 'DESC', w, ctx, 20):
            kinds.add(x['kind'])
    chk('설명문이 여러 목적지를 낸다', len(kinds) >= 2, kinds)
    chk('구절 설명문이 묻히지 않는다 (id 대역 함정)', 'VERSE' in kinds, kinds)
    chk('목적지가 전부 아는 것', kinds <= set(DESC_TYPES.values()), kinds)

    # ⑥ 도서/설교집이 실제로 갈린다
    b = find_group(conn, 'BOOK', 'grace', ctx, 20)
    s = find_group(conn, 'SERMON', 'grace', ctx, 20)
    ids_b = set((x['kind'], x['id']) for x in b)
    ids_s = set((x['kind'], x['id']) for x in s)
    # ★ 미리보기(2026-09-16) — 구절 줄은 본문이 오고, 모르는 종류는 빈 글
    pv = preview(conn, {'kind': 'VERSE', 'id': 1, 'sub': 'KRV'}, 'KO', 'KRV')
    chk('미리보기 — 구절 줄에 본문이 온다', bool(pv) and '태초' in pv, pv[:40])
    chk('미리보기 — 모르는 종류는 빈 글', preview(conn, {'kind': 'ZZ', 'id': 1}) == '')
    chk('미리보기 — 번호가 아니면 빈 글', preview(conn, {'kind': 'VERSE', 'id': 'x'}) == '')
    chk('도서와 설교집 결과가 안 겹친다', not (ids_b & ids_s),
        len(ids_b & ids_s))
    t0 = time.time()
    find_group(conn, 'BOOK', _NOWORD, ctx, 20)
    t_b = (time.time() - t0) * 1000
    t0 = time.time()
    find_group(conn, 'SERMON', _NOWORD, ctx, 20)
    t_s = (time.time() - t0) * 1000
    chk('도서가 설교집보다 확실히 빠르다 (좁히기가 먹는다)', t_b < t_s,
        '도서 %.0fms / 설교집 %.0fms' % (t_b, t_s))

    # ⑦ 상한·언어·역본
    h = find_group(conn, 'VERSE', '은혜', ctx, 5)
    chk('상한을 지킨다', len(h) == 5, len(h))
    chk('더 있으면 알린다', h.more is True)
    chk('없으면 more 가 거짓', find_group(conn, 'VERSE', _NOWORD, ctx, 5).more is False)
    ko = find_group(conn, 'VERSE', 'grace', {'lang': 'KO', 'ver': 'KRV'}, 5)
    en = find_group(conn, 'VERSE', 'grace', {'lang': 'KO', 'ver': 'BSB'}, 5)
    chk('역본을 가른다', len(ko) == 0 and len(en) > 0, '%d / %d' % (len(ko), len(en)))
    chk('성경 본문은 안 자른다',
        all('…' not in x['snippet'] for x in find_group(conn, 'VERSE', '은혜', ctx, 5)))

    # ⑧ 구절 참조는 이동
    chk('창1:1 을 알아본다', verse_ref_of(conn, '창1:1') == (1, 1))
    chk('구간도', verse_ref_of(conn, '룻1:16-17') == (7144, 7145))
    chk('낱말은 참조가 아니다', verse_ref_of(conn, '은혜') is None)

    # ⑨ 결과 모양
    h = find_group(conn, 'VERSE', '은혜', ctx, 1)
    chk('kind·id·title·sub·snippet',
        h and set(('kind', 'id', 'title', 'sub', 'snippet')) <= set(h[0]))
    chk('약명 공백 없음', h and ' ' not in h[0]['title'].split(':')[0], h[0]['title'] if h else '')

    # ⑩ 취소
    import threading
    res = {}

    def worker():
        c2 = appdb.connect()
        res['conn'] = c2
        try:
            c2.execute("SELECT text_id FROM sys_commentary_text "
                       "WHERE body_text LIKE ? LIMIT 20",
                       ('%' + _NOWORD + '%',)).fetchall()
            res['end'] = 'done'
        except Exception:
            res['end'] = 'interrupted'
    th = threading.Thread(target=worker)
    th.start()
    while 'conn' not in res:
        time.sleep(0.001)
    for _ in range(200):
        if 'end' in res:
            break
        res['conn'].interrupt()
        time.sleep(0.005)
    th.join()
    chk('질의를 진짜로 끊는다', res.get('end') == 'interrupted', res.get('end'))

    # ⑪ 계측기
    b = bench(conn, verbose=False)
    print('  ---- 바닥 %.0f ms · 꼭대기 %.0f ms (문턱 %d ms)'
          % (b['floor_ms'], b['worst_ms'], BENCH_LIMIT_MS))
    print('       %s' % b['verdict'])
    print('       묶음별: ' + ' · '.join('%s %.0fms' % (k, v)
                                       for k, v in b['bucket_ms'].items()))
    chk('계측기가 수치를 낸다', b['worst_ms'] > 0 and b['rows'])

    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    lang = args[args.index('--lang') + 1].upper() if '--lang' in args else 'KO'
    ver = args[args.index('--ver') + 1] if '--ver' in args else 'KRV'
    conn = appdb.connect()
    try:
        if '--bench' in args:
            bench(conn, lang, ver)
        elif '--find' in args:
            q = args[args.index('--find') + 1]
            r = verse_ref_of(conn, q)
            if r:
                print('▶ 이동: verse_id %s~%s' % r)
            for gk in groups():
                h = find_group(conn, gk, q, {'lang': lang, 'ver': ver}, 5)
                if not h:
                    continue
                print('\n[%s] %s%s' % (label(gk), len(h), '+' if h.more else ''))
                for x in h:
                    print('   %-24s %s' % (str(x['title'])[:24],
                                           (x['snippet'] or x['sub'])[:60]))
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
