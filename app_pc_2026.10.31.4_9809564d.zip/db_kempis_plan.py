# -*- coding: utf-8 -*-
"""db_kempis_plan.py — 켐피스 『그리스도를 본받아』 도서묵상 스케줄 (영구 · `--selftest` 의무)
================================================================================

껍데기 플랜 넷이 **이미 등록돼 있었다**(cat 11 「켐피스 그리스도를 본받아」).
`record_status='HIDE'` · **스케줄 0행** — 이름만 있고 속이 비어 있었다.

    KEMPIS_IOC_B1  25일   2~ 26편   제1권 영적 권면
    KEMPIS_IOC_B2  12일  28~ 39편   제2권 내면의 삶
    KEMPIS_IOC_B3  59일  41~ 99편   제3권 속의 위로
    KEMPIS_IOC_B4  18일 101~118편   제4권 성찬
                  ─────
                   114일  = 118편 − 나눔 4편

하루 = `BOOK_TEXT`(그 장) + `CORE`(그 장의 구절) 두 행 — §17-5 표준 그대로라
**화면 수정이 없다**(SPURGEON_TOD 와 같은 꼴).

★★ **CORE 구절을 어디서 얻었는가 — 두 갈래이고 섞지 않는다.**
  ① **각주 74편** — 켐피스가 그 장에서 **직접 인용한** 성구. `book_footnote` 로
     읽어 첫 참조를 쓴다. 저자 자신의 인용이라 짐작이 아니다.
  ② **저자 선택 40편** — 각주가 아예 없는 장. 본문을 읽고 골랐다(`PICKED`).
     ⚠ **짐작으로 절을 찍지 않는다**(마이어에서 세운 원칙) — 고른 근거를 옆에
       한 줄로 적어 두었고, `--check` 가 두 갈래를 나눠 센다.
  ⚠ 옛 `sys_book_unit.start_vid` 70편은 **각주 첫 참조에서 온 것**이라(실측 69/70
    일치) 따로 쓰지 않는다. 두 출처를 섞으면 어느 쪽이 맞는지 알 수 없어진다.

⚠ **`meditation_focus` 는 비운다** — 114일에 한 줄씩 지어 넣으면 반드시
  형식화된다(마이어 1,189일·스펄전 시편 150일과 같은 판단). 이제 **유닛 제목이
  한국어**라(`db_book_title`) 그 자리를 대신한다.

⚠ **플랜 제목을 고친다** — 넷 다 이름 규칙 위반이었다(엠대시 + 제목에 기간).
  그리고 **B4 가 「성체성사」였다** — 사용자 지시(「카톨릭 용어는 사용하지 마라」)와
  번역 어휘표(Sacrament → 성찬)에 어긋난다. 묶음 이름이 이미 책을 말하므로
  제목에는 **구별값만** 남긴다(§plan_label 이름 규칙).

사용법
    python db_kempis_plan.py --selftest     (의무)
    python db_kempis_plan.py --check
    python db_kempis_plan.py --apply        (멱등)
"""
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb
import book_footnote
import scripture_ref_kr

BOOK_CODE = 'KEMPIS_IOC'
DIVIDERS = (1, 27, 40, 100)          # 권 나눔 — 읽을 날이 아니다
MAX_SPAN = 12                        # 하루 중심 구절의 최대 절 수

# (plan_code, 첫 편, 끝 편, KO 제목, EN 제목)
BOOKS = (
    ('KEMPIS_IOC_B1',   2,  26, '1권 영적 권면',  'Book I: Spiritual Admonitions'),
    ('KEMPIS_IOC_B2',  28,  39, '2권 내면의 삶',  'Book II: The Inner Life'),
    ('KEMPIS_IOC_B3',  41,  99, '3권 속의 위로',  'Book III: Inward Consolation'),
    ('KEMPIS_IOC_B4', 101, 118, '4권 성찬',       'Book IV: The Lord’s Supper'),
)

# ── 각주가 없는 40편 — 본문을 읽고 고른 구절 (편: (참조, 고른 까닭)) ────────────
PICKED = {
    3:   ('고전 8:1',  '지식은 교만하게 하며 사랑은 덕을 세운다 — 이 장의 논지 그대로'),
    5:   ('살전 5:21', '모든 것을 시험하여 좋은 것을 취하라'),
    6:   ('롬 15:4',   '전에 기록된 바는 우리의 교훈을 위하여'),
    7:   ('골 3:5',   '땅에 있는 지체를 죽이라 곧 탐심이니 우상 숭배니라'),
    8:   ('렘 17:5',   '사람을 믿으며 육신으로 그 힘을 삼는 자는 저주를 받으리라'),
    9:   ('잠 13:20',  '지혜로운 자와 동행하면 지혜를 얻는다'),
    10:  ('히 13:17',  '너희를 인도하는 자들에게 순종하고 복종하라'),
    11:  ('잠 10:19',  '말이 많으면 허물을 면하기 어렵다'),
    12:  ('잠 4:23',   '모든 지킬 만한 것 중에 더욱 네 마음을 지키라'),
    13:  ('시 119:71', '고난당한 것이 내게 유익이라'),
    15:  ('마 7:1',    '비판을 받지 아니하려거든 비판하지 말라'),
    16:  ('갈 6:2',    '너희가 짐을 서로 지라'),
    17:  ('골 3:13',   '서로 용납하여 피차 용서하라'),
    18:  ('딤전 4:8',  '몸의 연습은 약간의 유익이 있으나 경건은 범사에 유익하다'),
    19:  ('히 13:7',   '그들의 행실의 결말을 주의하여 보고 그 믿음을 본받으라'),
    25:  ('고후 5:10', '우리가 다 반드시 그리스도의 심판대 앞에 드러나야 한다'),
    29:  ('벧전 5:5',  '하나님이 교만한 자를 대적하시고 겸손한 자에게 은혜를 주신다'),
    30:  ('마 5:9',    '화평하게 하는 자는 복이 있다'),
    31:  ('마 5:8',    '마음이 청결한 자는 복이 있다'),
    32:  ('롬 12:3',   '마땅히 생각할 그 이상의 생각을 품지 말라'),
    44:  ('미 6:8',    '겸손히 네 하나님과 함께 행하는 것'),
    51:  ('시 139:23', '나를 살피사 내 마음을 아시며 내 뜻을 아옵소서'),
    53:  ('빌 2:8',    '자기를 낮추시고 죽기까지 복종하셨다 — 이 장의 본보기'),
    57:  ('벧전 5:7',  '너희 염려를 다 주께 맡기라'),
    58:  ('벧전 2:21', '그리스도도 너희를 위하여 고난을 받으사 본을 끼치셨다'),
    61:  ('시 73:25',  '하늘에서는 주 외에 누가 내게 있으리요'),
    66:  ('고후 3:17', '주의 영이 계신 곳에는 자유가 있다'),
    68:  ('마 5:11',   '거짓으로 너희를 거슬러 모든 악한 말을 할 때에 복이 있다'),
    71:  ('빌 3:8',    '그리스도를 얻으려고 모든 것을 해로 여긴다'),
    77:  ('롬 12:1',   '너희 몸을 거룩한 산 제물로 드리라'),
    81:  ('요 12:43',  '사람의 영광을 하나님의 영광보다 더 사랑하였더라'),
    82:  ('시 146:3',  '방백들을 의지하지 말며 도울 힘이 없는 인생도 의지하지 말라'),
    84:  ('눅 10:42',  '한 가지만이라도 족하니라 — 마리아가 좋은 편을 택하였다'),
    94:  ('갈 5:17',   '육체의 소욕은 성령을 거스르고 성령의 소욕은 육체를 거스른다'),
    97:  ('잠 24:16',  '의인은 일곱 번 넘어질지라도 다시 일어난다'),
    104: ('요 6:54',   '내 살을 먹고 내 피를 마시는 자는 영생을 가졌다'),
    105: ('고전 4:1',  '그리스도의 일꾼이요 하나님의 비밀을 맡은 자'),
    106: ('고전 11:28', '사람이 자기를 살피고 그 후에야 이 떡을 먹고 이 잔을 마시라'),
    110: ('고전 11:26', '이 떡을 먹으며 이 잔을 마실 때마다 주의 죽으심을 전한다'),
    116: ('빌 4:6',    '모든 일에 기도와 간구로 너희 구할 것을 하나님께 아뢰라'),
}

# ── 각주가 여럿일 때 첫 참조 대신 쓸 것 (편: (참조, 까닭)) ──────────────────────
#    ⚠ 여기 적는 것도 **그 편의 각주 안에 실제로 있는 참조**여야 한다(게이트가 잰다).
#      저자가 인용하지 않은 절을 이 자리에 끼워 넣으면 「각주 74편」이 거짓말이 된다.
FN_PICK = {
    115: ('사 60:5', '첫 각주가 「열왕기하 4장」이라 44절을 통째로 끌고 온다 — '
                     '하루의 중심 구절로 쓸 수 없어 둘째 각주를 쓴다'),
}


# ───────────────────────────── 조회

def book_id(conn):
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (BOOK_CODE,)).fetchone()
    if not r:
        raise SystemExit('도서 %s 가 없습니다.' % BOOK_CODE)
    return r[0]


def build(conn):
    """→ {plan_code: [(day, unit_id, vid_s, vid_e, 출처)]} · 그리고 문제 목록."""
    bid = book_id(conn)
    bm = book_footnote.book_map(conn)
    em = book_footnote.en_to_ko(conn)
    rows = conn.execute("""
        SELECT u.sequence, u.unit_id, t.body_text
          FROM sys_book_unit u
          JOIN sys_book_unit_text t ON t.unit_id = u.unit_id
         WHERE u.book_id=? AND t.text_variant='TRANSLATED'
           AND COALESCE(u.record_status,'LIVE')='LIVE'
         ORDER BY u.sequence
    """, (bid,)).fetchall()
    by_seq = {r[0]: (r[1], r[2]) for r in rows}
    out, bad = {}, []
    for code, first, last, _ko, _en in BOOKS:
        days = []
        for seq in range(first, last + 1):
            if seq in DIVIDERS or seq not in by_seq:
                continue
            uid, body = by_seq[seq]
            hits = [h for l in body.split('\n')
                    for h in book_footnote.find(conn, l, bm, em)]
            if hits:
                pick = hits[0]
                if seq in FN_PICK:
                    # ⚠ 글자로 맞추지 않는다 — 각주는 정식명(「이사야 60:5」),
                    #   우리가 적는 것은 약명(「사 60:5」)이라 절대 안 맞는다.
                    #   해석한 절 번호로 맞춘다.
                    want = FN_PICK[seq][0]
                    wv, _we = scripture_ref_kr.resolve(conn, want, bm)
                    got = [h for h in hits if h['vid_s'] == wv]
                    if not got:
                        bad.append((seq, '선택한 각주가 그 편에 없다: %s' % want))
                        continue
                    pick = got[0]
                vs, ve, src = pick['vid_s'], pick['vid_e'], 'FOOTNOTE'
            elif seq in PICKED:
                ref = PICKED[seq][0]
                vs, ve = scripture_ref_kr.resolve(conn, ref, bm)
                src = 'PICKED'
                if not vs:
                    bad.append((seq, '선택한 구절을 해석 못 함: %s' % ref))
                    continue
            else:
                bad.append((seq, '구절이 없다 — 각주도 없고 선택한 것도 없다'))
                continue
            days.append((len(days) + 1, uid, vs, ve, src))
        out[code] = days
    return out, bad


# ───────────────────────────── 게이트

def check(conn, verbose=True):
    plans, bad = build(conn)
    for code, first, last, _ko, _en in BOOKS:
        r = conn.execute("SELECT plan_id, duration_days FROM sys_bible_plan "
                         "WHERE plan_code=?", (code,)).fetchone()
        if not r:
            bad.append((0, '플랜 %s 가 없다' % code))
            continue
        want = len(plans.get(code, []))
        if r[1] != want:
            bad.append((0, '%s duration %d ≠ 만든 날 %d' % (code, r[1], want)))
    # 고른 구절이 실제로 존재하는지 (해석 실패는 위에서 잡히지만 오타 방지)
    extra = [s for s in PICKED if s in DIVIDERS]
    if extra:
        bad.append((0, '나눔 편에 구절을 골랐다: %s' % extra))
    # ⚠ 장 단위 참조가 그대로 들어오면 하루의 「중심 구절」이 44절이 된다
    for code, days in plans.items():
        for day, _uid, vs, ve, _src in days:
            if ve - vs + 1 > MAX_SPAN:
                bad.append((0, '%s %d일: 구절이 %d절짜리 — FN_PICK 로 좁힐 것'
                            % (code, day, ve - vs + 1)))
    if verbose:
        tot = sum(len(v) for v in plans.values())
        fn = sum(1 for v in plans.values() for d in v if d[4] == 'FOOTNOTE')
        pk = sum(1 for v in plans.values() for d in v if d[4] == 'PICKED')
        print('%s — 만든 날 %d일 (각주 %d · 선택한 것 %d)' % (BOOK_CODE, tot, fn, pk))
        for code, first, last, ko, _en in BOOKS:
            print('  %-16s %3d일  %s' % (code, len(plans.get(code, [])), ko))
        print('  게이트 위반 %d건' % len(bad))
        for s, m in bad[:20]:
            print('   #%-4s %s' % (s or '-', m))
    return plans, bad


# ───────────────────────────── 적재

def _set_title(conn, plan_id, lang, text, dry):
    row = conn.execute(
        "SELECT sys_text_id, contents FROM sys_text_asset "
        "WHERE text_type='PLAN_TITLE' AND clicked_id=? AND lang_code=?",
        (plan_id, lang)).fetchone()
    if row is None:
        if not dry:
            conn.execute(
                "INSERT INTO sys_text_asset (clicked_id, text_type, title, "
                " contents, lang_code, record_status) VALUES (?,?,?,?,?,'LIVE')",
                (plan_id, 'PLAN_TITLE', text, text, lang))
        return 'new'
    if (row[1] or '') != text:
        if not dry:
            # ⚠ 화면 여섯 곳 중 하나가 `title` 칸을 읽는다 — **두 칸을 함께** 쓴다
            #   (§plan_label — 이 어긋남이 옛 제목 혼란의 뿌리였다)
            conn.execute("UPDATE sys_text_asset SET title=?, contents=?, "
                         "record_status='LIVE' WHERE sys_text_id=?",
                         (text, text, row[0]))
        return 'upd'
    return 'same'


def apply(conn, dry=False):
    plans, bad = check(conn, verbose=False)
    if bad:
        raise SystemExit('게이트를 통과하지 못했습니다 — 적재하지 않습니다. %s' % bad[:5])
    ins = tdone = 0
    for code, first, last, ko, en in BOOKS:
        pid = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                           (code,)).fetchone()[0]
        days = plans[code]
        if not dry:
            # 멱등 — 이 플랜의 스케줄을 통째로 다시 쓴다
            conn.execute("DELETE FROM sys_plan_schedule WHERE plan_id=?", (pid,))
        for day, uid, vs, ve, _src in days:
            for stage, order, ukey in (('BOOK_TEXT', 1, 'BOOK_%d' % uid),
                                       ('CORE', 2, None)):
                if not dry:
                    conn.execute("""
                        INSERT INTO sys_plan_schedule
                          (plan_id, day, track, start_vid, end_vid, stage_type,
                           sort_order, meditation_focus, unit_key)
                        VALUES (?,?,1,?,?,?,?,NULL,?)
                    """, (pid, day, vs, ve, stage, order, ukey))
                ins += 1
        for lang, txt in (('KO', ko), ('EN', en)):
            if _set_title(conn, pid, lang, txt, dry) != 'same':
                tdone += 1
        if not dry:
            conn.execute("UPDATE sys_bible_plan SET duration_days=?, "
                         "record_status='LIVE' WHERE plan_id=?", (len(days), pid))
    if not dry:
        conn.commit()
    print('%s 스케줄 %d행 · 제목 고침 %d · 플랜 4개 LIVE'
          % ('[모의]' if dry else '[적재]', ins, tdone))
    return ins, tdone


# ───────────────────────────── 자가 검증

def _selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    t('권 넷', len(BOOKS) == 4)
    t('나눔 넷', len(DIVIDERS) == 4)
    t('선택한 편이 나눔과 겹치지 않는다', not (set(PICKED) & set(DIVIDERS)))
    # ★ 제목이 이름 규칙을 지키는가 (§plan_label) — 옛 제목이 넷 다 어겼다
    for _c, _f, _l, ko, en in BOOKS:
        t('제목에 엠대시 없음 %s' % ko, '—' not in ko and '—' not in en)
        t('제목에 기간 없음 %s' % ko, '일)' not in ko and 'Day' not in en)
    t('가톨릭 용어 없음', not any('성체' in b[3] or '성사' in b[3] for b in BOOKS))

    conn = appdb.connect('bible_master.db')
    try:
        plans, bad = check(conn, verbose=False)
        t('게이트 0건', not bad)
        t('합계 114일', sum(len(v) for v in plans.values()) == 114)
        t('1권 25일', len(plans['KEMPIS_IOC_B1']) == 25)
        t('2권 12일', len(plans['KEMPIS_IOC_B2']) == 12)
        t('3권 59일', len(plans['KEMPIS_IOC_B3']) == 59)
        t('4권 18일', len(plans['KEMPIS_IOC_B4']) == 18)
        t('모든 날에 구절이 있다',
          all(d[2] for v in plans.values() for d in v))
        t('각주 74 · 선택한 것 40',
          sum(1 for v in plans.values() for d in v if d[4] == 'FOOTNOTE') == 74
          and sum(1 for v in plans.values() for d in v if d[4] == 'PICKED') == 40)
        t('날이 1부터 이어진다',
          all([d[0] for d in v] == list(range(1, len(v) + 1))
              for v in plans.values()))
        # 고른 구절이 전부 해석되는가 (오타 방지 — 하나라도 못 읽으면 위에서 걸린다)
        bm = book_footnote.book_map(conn)
        t('선택한 구절 40개 전부 해석',
          all(scripture_ref_kr.resolve(conn, r, bm)[0] for r, _w in PICKED.values()))
        t('선택한 편 40', len(PICKED) == 40)
        # ★ FN_PICK 은 그 편 각주 안에 있는 참조여야 한다 — build 가 잡는다
        t('FN_PICK 이 각주 안에 있다',
          not [m for _s, m in bad if '선택한 각주가' in m])
        t('구절이 %d절을 넘지 않는다' % MAX_SPAN,
          all(d[3] - d[2] + 1 <= MAX_SPAN for v in plans.values() for d in v))
        # 고른 구절이 그 편 각주와 겹치지 않는가(같은 절이 이틀 연속 뜨는 것을 막는다)
        bad_ref = []
        for _code, days in plans.items():
            seen = {}
            for day, _uid, vs, _ve, src in days:
                if vs in seen and abs(seen[vs] - day) <= 1:
                    bad_ref.append((_code, day))
                seen[vs] = day
        t('같은 구절이 이틀 연속 오지 않는다', not bad_ref)
        # 4편은 각주(시 94:12)에서 와야 한다
        d4 = [d for d in plans['KEMPIS_IOC_B1'] if d[0] == 3]
        t('모의는 안 쓴다', apply(conn, dry=True) and conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule s JOIN sys_bible_plan p "
            "ON p.plan_id=s.plan_id WHERE p.plan_code LIKE 'KEMPIS%'"
        ).fetchone()[0] in (0, 228))
    finally:
        conn.close()
    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if _selftest() else 1)
    conn = appdb.connect('bible_master.db')
    try:
        if a[0] == '--check':
            _p, bad = check(conn)
            sys.exit(1 if bad else 0)
        elif a[0] == '--apply':
            check(conn)
            apply(conn)
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
