"""
db_ai_audit.py — AI 작성·번역 **예제 · 프롬프트 층 · 게이트 · 틀 문구** 전수조사 (2026-10-13 신설·영구).

사용자 지시(docs/1.txt 71) — 「예제를 채택하지도 않았는데 예제가 적용되는 것 같다 · 예제 / 게이트 전수조사하라」
→ 「아직도 매우 부족하다 · 품질수준이 너무 낮다 · 철저하게 검증하라」.

무엇을 재나(전부 읽기만 — DB 를 안 바꾼다):
  ① 층 줄 출처 — 프롬프트 층(sys_ai_prompt LIVE)의 줄마다 「사람이 쓴 줄인가 · 코드(예제·씨앗)를
     글자 그대로 옮긴 줄인가」. 코드 글자 그대로면 **사람이 고르지 않았는데 실린 줄**이다.
  ② 틀 문구 — 자산마다 AI 가 쓴 글(한국어)에서 **문서 빈도가 높은 낱말**을 사람이 쓴 같은 자산 글과 견준다
     (AI 글에만 몰린 낱말 = 틀). 그 낱말의 어간이 든 층 줄을 짝지어 「어디서 왔나」를 적는다.
  ③ 부딪히는 층 — 같은 자산·업무에 함께 실리는 층에서 「반드시」류 줄과 「하지 말 것」 줄이 같은 말을 품었나.
  ④ 게이트 줄 — 지금까지 나온 게이트 줄을 규칙(`db_ai_run.gate_rule_of`)으로 묶어 갈래별 · 그 줄이 걸린
     채로 승인·적재된 수(= 사람이 그 흠을 받아들였거나 헛걸림).
  ⑤ 게이트가 못 돈 건 — 「검사가 터졌다」로 남은 건(적재된 것 포함).
  ⑥ 다시 재기 — 적재·승인된 글을 **지금 게이트**로 다시 재 본다(쓰지 않는다 · 다듬기는 앞글 없이).

명령: --selftest · --report [파일](기본 docs/ai_audit_report.md) · --no-regate(⑥ 건너뜀)
"""
import json
import os
import re
import sys
from collections import Counter, defaultdict

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT = os.path.join(HERE, 'docs', 'ai_audit_report.md')
PUSH_PARTS = ('role', 'task', 'must', 'style', 'cite', 'length', 'example', 'output')   # 「하라」 칸
NEVER_PARTS = ('never',)
_HANGUL_WORD = re.compile(r'[가-힣]{2,}')
#: 어디에나 흔한 끝말 — 틀로 세지 않는다
GENERIC = set('있습니다 합니다 입니다 됩니다 줍니다 않습니다 없습니다 했습니다 됩니다 하나님 하나님의 하나님께서 '
              '그리고 그러나 이것은 이는 우리 우리의 우리는 것은 것을 것이 것입니다 수 있는 있다 하는 한다 '
              '말씀 말씀을 말씀이 본문 구절 구절은 구절이 이 그 저 두 한 더'.split())


def _norm(s):
    return re.sub(r'\s+', '', s or '')


def code_texts():
    """db_ai_job.py 안의 글자(예제·씨앗) — 줄 단위 집합(공백 걷음)."""
    src = open(os.path.join(HERE, 'db_ai_job.py'), encoding='utf-8').read()
    out = set()
    for m in re.finditer(r"'((?:[^'\\]|\\.)*)'", src):
        s = m.group(1).encode('utf-8').decode('unicode_escape').encode('latin-1', 'ignore').decode('utf-8', 'ignore') \
            if '\\u' in m.group(1) else m.group(1)
        for line in s.replace('\\n', '\n').split('\n'):
            line = line.strip()
            if len(line) >= 6:
                out.add(_norm(line))
    return out


def layer_lines(conn):
    rows = conn.execute("SELECT prompt_id, COALESCE(kind,''), COALESCE(task,''), COALESCE(lang,''), part, body"
                        " FROM sys_ai_prompt WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchall()
    out = []
    for pid, k, t, l, p, b in rows:
        for line in (b or '').split('\n'):
            if line.strip():
                out.append({'pid': pid, 'kind': k, 'task': t, 'lang': l, 'part': p, 'line': line.strip()})
    return out


def origin_audit(conn):
    code = code_texts()
    out = []
    for r in layer_lines(conn):
        r = dict(r)
        r['from_code'] = _norm(r['line']) in code
        r['quotes'] = re.findall(r'[「“"\']([^」”"\']{2,30})[」”"\']', r['line'])
        out.append(r)
    return out


def ai_texts(conn, kind):
    return [t for (t,) in conn.execute(
        "SELECT i.out_text FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id"
        " WHERE j.asset_kind=? AND UPPER(j.lang)='KO' AND i.state IN ('LOADED','OK','DONE')"
        " AND COALESCE(i.out_text,'')<>''", (kind,)).fetchall()]


#: 자산 → 사람이 쓴 같은 갈래 글(비교 바탕). 없으면 비교 없이 빈도만.
HUMAN_TT = {'VERS_VERS_DESC': 'VERS_VERS_DESC', 'VERS_DESC_LAY': 'VERS_DESC', 'PERI_DESC': 'PERI_DESC',
            'CHAP_DESC': 'CHAP_DESC', 'ENTITY_DESC': 'ENTITY_DESC'}


def human_texts(conn, kind, limit=3000):
    tt = HUMAN_TT.get(kind)
    if not tt:
        return []
    ai_slots = {r[0] for r in conn.execute(
        "SELECT i.slot_id FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id"
        " WHERE j.asset_kind=? AND i.state='LOADED'", (kind,))}
    rows = conn.execute("SELECT clicked_id, contents FROM sys_text_asset WHERE text_type=? AND lang_code='KO'"
                        " AND COALESCE(contents,'')<>'' LIMIT ?", (tt, limit * 3)).fetchall()
    return [c for sid, c in rows if sid not in ai_slots][:limit]


def doc_freq(texts):
    df = Counter()
    for t in texts:
        df.update(set(_HANGUL_WORD.findall(t or '')))
    return df


#: 묶음 칸 → 사람이 쓴 같은 칸(비교 바탕)
BUNDLE_HUMAN = {'설명문': 'VERS_DESC', '묵상질문': 'VERS_QUESTION', '묵상기도': 'VERS_PRAYER',
                '연구질문': 'VERS_QUESTION', '연구자료': None}


def _rejoin(texts, name):
    out = []
    for t in texts:
        cur, buf = None, []
        for line in (t or '').split(chr(10)):
            m = re.match(r'^\s*\[(설명문|묵상질문|묵상기도|연구질문|연구자료)\]\s*(.*)$', line)
            if m:
                cur = m.group(1)
                line = m.group(2)
            if cur == name:
                buf.append(line)
        if buf and ''.join(buf).strip():
            out.append(chr(10).join(buf))
    return out


def human_tt(conn, tt, limit=3000):
    if not tt:
        return []
    ai = {r[0] for r in conn.execute(
        "SELECT i.slot_id FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id WHERE i.state='LOADED'")}
    rows = conn.execute("SELECT clicked_id, contents FROM sys_text_asset WHERE text_type=? AND lang_code='KO'"
                        " AND COALESCE(contents,'')<>'' LIMIT ?", (tt, limit * 2)).fetchall()
    return [c for sid, c in rows if sid not in ai][:limit]


def pooled_human(conn, limit=4000):
    """사람이 쓴 한국어 설명문(비교 바탕) — AI 가 적재한 자리는 뺀다."""
    ai = {r[0] for r in conn.execute(
        "SELECT i.slot_id FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id WHERE i.state='LOADED'")}
    rows = conn.execute("SELECT clicked_id, contents FROM sys_text_asset WHERE text_type IN ('VERS_DESC','PERI_DESC','CHAP_DESC')"
                        " AND lang_code='KO' AND COALESCE(contents,'')<>'' LIMIT ?", (limit * 2,)).fetchall()
    return [c for sid, c in rows if sid not in ai][:limit]


def stamp_audit(conn, kinds=None, min_share=0.10, min_n=8, lift=3.0):
    """★ 틀 문구 = **끝맺음·첫머리가 몰린 것**(2026-10-13 다시 씀 — 낱말 빈도로 재면 「모든」·「그분의」 같은
    평범한 낱말까지 잡혀 판정할 수 없었다). 같은 자산 사람 글(없으면 사람이 쓴 한국어 설명문 전체)과 견준다.
    → [{kind, what('끝'|'첫'), phrase, n, n_ai, ai_share, base_share, base_name, src}]"""
    import db_ai_run as R
    kinds = kinds or [k for (k,) in conn.execute(
        "SELECT DISTINCT asset_kind FROM sys_ai_job WHERE UPPER(lang)='KO'")]
    layers = layer_lines(conn)
    pooled = None
    out = []
    jobs = []
    for k in kinds:
        if k == 'VERS_BUNDLE':
            # ★ 묶음은 칸마다 따로 — 설명문·질문·기도를 한 글로 보면 질문·기도의 끝맺음이 틀로 잡힌다
            parts = defaultdict(list)
            for t in ai_texts(conn, k):
                cur = None
                for line in (t or '').split(chr(10)):
                    m = re.match(r'^\s*\[(설명문|묵상질문|묵상기도|연구질문|연구자료)\]\s*(.*)$', line)
                    if m:
                        cur = m.group(1)
                        line = m.group(2)
                    if cur:
                        parts[cur].append(line)
            # 칸 하나 = 묶음 한 건(줄을 다시 합친다)
            for nm, tt in BUNDLE_HUMAN.items():
                jobs.append(('VERS_BUNDLE·' + nm, _rejoin(ai_texts(conn, k), nm), tt))
        else:
            jobs.append((k, ai_texts(conn, k), None))
    for k, ai, tt in jobs:
        if len(ai) < 20:
            continue
        hu = human_texts(conn, k) if tt is None else human_tt(conn, tt)
        base_name = '같은 자산 사람 글'
        if len(hu) < 50:
            if pooled is None:
                pooled = pooled_human(conn)
            hu, base_name = pooled, '사람이 쓴 설명문 전체'
        ea, ha = R.formula_counts(ai)
        eh, hh = R.formula_counts(hu)
        for what, ca, ch in (('끝', ea, eh), ('첫', ha, hh)):
            for ph, n in ca.most_common(60):
                sa = n / len(ai)
                if n < min_n or sa < min_share:
                    continue
                sh = ch.get(ph, 0) / max(1, len(hu))
                if sh * lift >= sa and sh >= 0.005:
                    continue
                stem = ph[:2] if what == '끝' else ph.split()[0]
                kk = k.split('·')[0]
                src = [L for L in layers if stem and stem in L['line'] and L['kind'] in ('', kk)
                       and L['part'] in PUSH_PARTS]
                out.append({'kind': k, 'what': what, 'phrase': ph, 'n': n, 'n_ai': len(ai), 'ai_share': sa,
                            'base_share': sh, 'base_name': base_name, 'src': src[:4]})
    return out


def conflict_audit(conn):
    """같이 실리는 층끼리 부딪히는 줄 — **화면과 같은 문**(`db_ai_job.layer_conflicts`)을 쓴다."""
    import db_ai_job as AJ
    out, seen = [], set()
    for k in AJ.ASSET:
        for task in ('NEW', 'EDIT', 'TRANS'):
            for pk, pp, pl, nk, nl, seg in AJ.layer_conflicts(conn, k, '', task, 'KO'):
                if (pl, nl) in seen:
                    continue
                seen.add((pl, nl))
                out.append({'kind': k, 'task': task, 'pos': {'pid': pk, 'part': pp, 'line': pl},
                            'neg': {'pid': nk, 'line': nl}, 'seg': seg, 'hit': seg})
    return out


def gate_line_audit(conn):
    import db_ai_run as R
    by = defaultdict(Counter)       # rule → state counter
    sample = {}
    crash = Counter()
    crash_state = Counter()
    for jid, kind, task, g, st in conn.execute(
            "SELECT i.job_id, j.asset_kind, j.task, i.gate_json, i.state FROM sys_ai_item i"
            " JOIN sys_ai_job j ON j.job_id=i.job_id WHERE COALESCE(i.gate_json,'')<>''"):
        try:
            d = json.loads(g)
        except Exception:                                 # noqa: BLE001
            continue
        crashed = False
        for line in d.get('lines') or []:
            if '검사가 터졌다' in line or '못 돌렸습니다' in line:
                crashed = True
            if R._is_note(line):
                continue
            rule = R.gate_rule_of(line)
            by[rule][st] += 1
            sample.setdefault(rule, line.strip()[:90])
        if crashed:
            crash[(jid, kind)] += 1
            crash_state[st] += 1
    return by, sample, crash, crash_state


def regate_loaded(conn, limit=0):
    """적재·승인된 글을 지금 게이트로 다시 잰다(쓰지 않는다) — **처음 판정과 견준다**.

    갈래: 못 돈 검사였다(crash) · 처음 통과→지금 걸림(게이트가 새로 잡는 것) ·
         처음부터 걸렸는데 사람이 적재 · 둘 다 통과 · 처음 걸림→지금 통과.
    """
    import db_ai_run as R
    rows = conn.execute("SELECT i.item_id, i.job_id, i.slot_id, i.out_text, i.gate_json FROM sys_ai_item i"
                        " WHERE i.state IN ('LOADED','OK') AND COALESCE(i.out_text,'')<>''"
                        " ORDER BY i.job_id, i.item_id" + (' LIMIT %d' % limit if limit else '')).fetchall()
    jobs, heads = {}, {}
    res = defaultdict(Counter)
    newly = Counter()
    kept = Counter()
    n = 0
    for iid, jid, sid, txt, gj in rows:
        j = jobs.get(jid) or jobs.setdefault(jid, R.job(conn, jid))
        try:
            g0 = json.loads(gj or '{}')
        except Exception:                                 # noqa: BLE001
            g0 = {}
        try:
            g = R.gate_for_job(conn, j, sid, (txt or '').strip(), heads.setdefault(jid, set()), before=None)
        except Exception as e:                            # noqa: BLE001
            g = {'ok': False, 'lines': ['다시 재다 터짐: %s' % e]}
        heads[jid].add(R.head_of((txt or '').strip()))
        n += 1
        k = '%s/%s' % (j['asset_kind'], j['task'])
        crashed = any('터졌다' in l or '못 돌렸습니다' in l for l in g0.get('lines') or [])
        ok0 = bool(g0.get('ok')) and not crashed
        ok1 = bool(g.get('ok'))
        cat = ('crash' if crashed else 'pass→flag' if ok0 and not ok1 else 'flag→flag' if not ok0 and not ok1
               else 'flag→pass' if not ok0 else 'pass→pass')
        res[k][cat] += 1
        res[k]['all'] += 1
        rules = {R.gate_rule_of(l) for l in g.get('lines') or [] if not R._is_note(l)}
        for r in rules:
            if cat in ('pass→flag', 'crash'):
                newly[(k, r)] += 1
            elif cat == 'flag→flag':
                kept[(k, r)] += 1
    return n, res, newly, kept


def R_NAME(rule):
    import db_ai_run as R
    return R.GATE_RULE_NAME.get(rule, '모름')


def report(path=REPORT, do_regate=True):
    conn = appdb.connect()
    L = []
    w = L.append
    w('# AI 작성·번역 전수조사 (docs/1.txt 71)\n')
    w('읽기만 했다 — DB 는 바꾸지 않았다. 도구 `db_ai_audit.py --report`.\n')
    # ① 출처
    o = origin_audit(conn)
    fc = [r for r in o if r['from_code']]
    w('## ① 프롬프트 층 줄의 출처\n')
    w('- 층 줄 %d 가운데 **코드(예제·씨앗)를 글자 그대로 옮긴 줄 %d** — 사람이 고르지 않았는데 실리는 줄이다.'
      % (len(o), len(fc)))
    risky = [r for r in fc if r['part'] in PUSH_PARTS and r['quotes']]
    w('- 그 가운데 「하라」 칸에 **따옴표로 구체 문구를 든 줄 %d** — AI 가 그 문구를 그대로 베낄 위험이 가장 크다.\n' % len(risky))
    w('| 번호 | 자산 | 업무 | 칸 | 줄 |\n|---|---|---|---|---|')
    for r in sorted(fc, key=lambda x: (x['kind'], x['task'], x['part'])):
        flag = ' ⚠' if r in risky else ''
        w('| %d | %s | %s | %s | %s%s |' % (r['pid'], r['kind'] or '(공통)', r['task'] or '(전 업무)', r['part'],
                                         r['line'][:80].replace('|', '/'), flag))
    # ② 틀 문구
    st = stamp_audit(conn)
    w('\n## ② 틀 문구 — AI 글에 몰린 끝맺음·첫머리\n')
    w('AI 글(한국어 · 적재·승인·검수 대기)의 10% 이상에 나오고, 사람이 쓴 글보다 3배 넘게 흔한 끝맺음(문장 끝 낱말)·첫머리(첫 세 어절).\n')
    w('| 자산 | 자리 | 문구 | AI 글 | 비교 바탕 | 의심 출처(층 번호·칸·줄) |\n|---|---|---|---|---|---|')
    for x in sorted(st, key=lambda x: (x['kind'], -x['ai_share'])):
        src = '<br>'.join('%d·%s·%s' % (y['pid'], y['part'], y['line'][:50].replace('|', '/')) for y in x['src']) or '—'
        w('| %s | %s | %s | %d/%d (%.0f%%) | %s %.1f%% | %s |' % (
            x['kind'], x['what'], x['phrase'], x['n'], x['n_ai'], 100 * x['ai_share'], x['base_name'],
            100 * x['base_share'], src))
    # ⑦ 프롬프트 ↔ 게이트 일관성 (2026-10-13 사용자 「느닷없이 게이트를 들이대면 당연히 걸릴 수 밖에 없다」)
    import db_ai_run as _R
    import db_ai_job as _AJ
    w('\n## ⑦ 프롬프트 ↔ 게이트 일관성 — 게이트가 재는 것을 프롬프트가 말했나\n')
    w('「층에 없음」= 사람·씨앗이 쓴 층에는 없던 기준. 이제 보낼 때 「게이트 기준」 줄로 저절로 붙는다(조회 화면에도 보인다).\n')
    w('| 자산 | 업무 | 게이트 규칙 | 층에 없던 것(지금은 「게이트 기준」으로 붙음) | 보내는 프롬프트에 없는 것 |\n|---|---|---|---|---|')
    for k, t in sorted(conn.execute('SELECT DISTINCT asset_kind, task FROM sys_ai_job')):
        if k not in _AJ.ASSET:
            continue
        raw = _AJ.render_prompt(_AJ.compose_trace(conn, k, '', t, 'KO', gate_lines=False)[0], {})
        full = _AJ.render_prompt(_AJ.compose_prompt(conn, k, '', t, 'KO'), {})
        r0 = _R.prompt_gate_check(conn, k, t, 'KO', text=raw)
        r1 = _R.prompt_gate_check(conn, k, t, 'KO', text=full)
        miss0 = [_R.GATE_RULE_NAME.get(r, r) for r, said, _m, _l in r0 if not said]
        miss1 = [_R.GATE_RULE_NAME.get(r, r) for r, said, _m, _l in r1 if not said]
        w('| %s | %s | %d | %s | %s |' % (k, t, len(r0), ' · '.join(miss0) or '—', ' · '.join(miss1) or '없음'))
    # ③ 부딪힘
    cf = conflict_audit(conn)
    w('\n## ③ 서로 부딪히는 층\n')
    w('| 자산 | 업무 | 「하라」(번호·칸) | 「하지 말 것」(번호) | 겹친 말 |\n|---|---|---|---|---|')
    _ln = lambda k: '/'.join(x for x in k if x) or '공통'     # noqa: E731
    for c in cf:
        w('| %s | %s | %s·%s: %s | %s: %s | %s |' % (c['kind'], c['task'], _ln(c['pos']['pid']), c['pos']['part'],
                                                 c['pos']['line'][:60].replace('|', '/'), _ln(c['neg']['pid']),
                                                 c['neg']['line'][:60].replace('|', '/'), c['hit']))
    if not cf:
        w('| — | — | 없음 | | |')
    # ④⑤ 게이트
    by, sample, crash, crash_state = gate_line_audit(conn)
    w('\n## ④ 게이트 줄 — 규칙별 · 그 줄이 걸린 채 어떻게 처리됐나\n')
    w('| 규칙 | 걸린 수 | 적재(LOADED) | 승인(OK) | 검수 대기(DONE) | 반려(REJ) | 보기 |\n|---|---|---|---|---|---|---|')
    for rule, c in sorted(by.items(), key=lambda x: -sum(x[1].values())):
        w('| %s | %d | %d | %d | %d | %d | %s |' % (rule, sum(c.values()), c['LOADED'], c['OK'], c['DONE'], c['REJ'],
                                                 sample.get(rule, '').replace('|', '/')))
    w('\n## ⑤ 게이트가 돌지 못한 건(「검사가 터졌다」)\n')
    w('- 건수 %d · 상태 %s' % (sum(crash.values()), dict(crash_state)))
    for (jid, kind), n in sorted(crash.items()):
        w('  - 작업 %d · %s · %d건' % (jid, kind, n))
    if do_regate:
        n, res, newly, kept = regate_loaded(conn)
        w('\n## ⑥ 적재·승인된 글을 지금 게이트로 다시 재면\n')
        w('다듬기 건은 앞글이 없어 「다듬기 손실」은 안 쟀다. 총 %d건. 처음 판정과 견준다.\n' % n)
        w('| 자산/업무 | 건수 | 못 돈 검사였다 | 처음 통과→지금 걸림 | 처음부터 걸렸는데 적재 | 처음 걸림→지금 통과 | 둘 다 통과 |'
          '\n|---|---|---|---|---|---|---|')
        for k, c in sorted(res.items(), key=lambda x: -x[1]['all']):
            w('| %s | %d | %d | %d | %d | %d | %d |' % (k, c['all'], c['crash'], c['pass→flag'], c['flag→flag'],
                                                     c['flag→pass'], c['pass→pass']))
        w('\n**지금 게이트가 새로 잡는 것**(처음 통과했거나 검사가 못 돌았던 글) — 규칙별:\n')
        for (k, rule), c in newly.most_common(40):
            w('- %s · %s(%s) · %d' % (k, rule, R_NAME(rule), c))
        w('\n**처음부터 걸렸는데 사람이 적재한 것** — 규칙별(헛걸림이거나 사람이 받아들인 흠):\n')
        for (k, rule), c in kept.most_common(40):
            w('- %s · %s(%s) · %d' % (k, rule, R_NAME(rule), c))
    conn.close()
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(L) + '\n')
    return path


def selftest():
    ok = []
    ck = lambda c, m: (ok.append(bool(c)), print(('PASS ' if c else 'FAIL ') + m))   # noqa: E731
    conn = appdb.connect()
    try:
        ct = code_texts()
        ck(_norm('흐르는 산문 · 합니다체') in ct, '코드 글자 집합이 예제를 읽는다')
        ck(len(layer_lines(conn)) > 0, '층 줄을 읽는다')
        df = doc_freq(['자라납니다 하나님', '자라납니다'])
        ck(df['자라납니다'] == 2 and df['하나님'] == 1, '문서 빈도')
        import db_ai_run as R
        ck(R.gate_rule_of('인용 표시가 3군데 사라졌다 — 성경 인용과 설명이 섞인다') == 'edit_quote', '게이트 줄 → 규칙')
        ck(R.gate_rule_of('아무 말도 아닌 줄') == 'other', '모르는 줄은 other')
    finally:
        conn.close()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--report' in a:
        print(report(do_regate='--no-regate' not in a))
