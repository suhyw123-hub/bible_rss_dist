# -*- coding: utf-8 -*-
"""admin/latest_feed_tab.py — **사용자에게 나가는 목록** 탭 (2026-09-06 신설).

★★★ 왜 (사용자 지시): 「**실제로 사용자들에게 표시되는 목록이 어떤 것인지
  관리자가 알 수 있어야 한다**」 · 「제거해야 할 **필터링 로직**을 도입해서
  필요없는 링크를 보내지 않을 방법」.

★ **한 부품이 유튜브·텍스트 둘 다 맡는다**(`kind='yt'|'items'`) — 둘로 지으면
  「보이는 규칙」이 갈린다.

★★ **세 가지를 나란히 보인다** — 이 셋이 다르면 그것이 곧 할 일이다:
  ① **지금 서버에 있는 것** — 사용자가 **실제로 받는** 목록(그 파일을 읽는다)
  ② **지금 만들면 나갈 것** — 발행 문(`rss_publish`)을 **그대로** 불러 미리보기
  ③ **걸러진 것** — 무엇이 **왜** 빠졌는지(§0-1 조용히 버리지 않는다)

⚠ **화면이 자기 SQL 을 쓰지 않는다** — 발행 문을 그대로 부른다. 따로 짜면
  「보이는 것과 나가는 것」이 갈리고, 그것이 이 앱에서 가장 자주 난 사고다.

⚠ 텍스트(items)는 **피드를 실시간으로 긁는다**(DB 에 없다) — 느리므로 실에서
  돌리고 진행을 보인다. 유튜브는 DB 라 빠르다.
"""
import os
import queue
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import latest_rules as LR
import lang_ui as _lu   # 언어 콤보 = 영어 이름(값은 코드)

try:
    from admin.panel_help_box import help_row
except ImportError:
    from panel_help_box import help_row

DB = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'bible_master.db')

#: 원본 언어 필터의 「안 거른다」 값 — 목록에 언어 코드와 섞이므로 글자로 둔다.
ALL_LANG = '전체'

#: 갈래별 이름·서버 파일. **여기가 단일 소스** — 갈래가 늘면 한 줄.
KINDS = {
    'yt':    {'name': '유튜브', 'file': 'youtube_%s.tsv', 'limit': 200},
    'items': {'name': '텍스트', 'file': 'items_%s.tsv',   'limit': 0},
}


def server_rows(kind, lang='KO', timeout=15):
    """**지금 서버에 있는 것** → (rows, 메모).

    ⚠ 사용자가 실제로 받는 파일을 그대로 읽는다 — 우리가 다시 계산하면
      「올렸다고 믿는 것」을 보이게 되고 그것은 확인이 아니다.
    """
    import urllib.request
    import rss_transport as RT
    fname = KINDS[kind]['file'] % (lang or 'KO').upper()
    last = ''
    for s in (RT.client_servers() or []):
        base = s.get('location') or s.get('base') or s.get('url')
        if not base:
            continue
        url = base.rstrip('/') + '/' + fname
        try:
            with urllib.request.urlopen(url, timeout=timeout) as r:
                txt = r.read().decode('utf-8', 'replace')
        except Exception as e:
            last = '%s — %s' % (s.get('label', '?'), str(e)[:50])
            continue
        lines = txt.splitlines()
        if not lines:
            return [], '%s: 파일이 비었습니다' % fname
        head = lines[0].split('\t')
        out = []
        for ln in lines[1:]:
            v = ln.split('\t')
            out.append({head[i]: (v[i] if i < len(v) else '')
                        for i in range(len(head))})
        return out, '%s · %s · %d행' % (s.get('label', '?'), fname, len(out))
    return [], '서버에서 못 읽었습니다 (%s)' % (last or fname)


class LatestFeedTab(ttk.Frame):
    def __init__(self, master, kind='yt'):
        super().__init__(master)
        self.kind = kind if kind in KINDS else 'yt'
        self._q = queue.Queue()
        self._busy = False
        self._drop = []
        self._build()
        self.after_idle(self._load_server)

    # ── UI ──────────────────────────────────────────────────────────
    def _build(self):
        nm = KINDS[self.kind]['name']
        help_row(self, '사용자에게 나가는 %s 목록' % nm, [
            ('이 탭의 기능',
             '사용자 앱의 「최신 콘텐츠」에 **실제로 표시되는 목록**을 봅니다. '
             '화면이 따로 계산하지 않고 **발행하는 문을 그대로** 부르므로 '
             '여기 보이는 것이 곧 나가는 것입니다.'),
            ('세 가지를 견줍니다',
             '[서버에 있는 것] 지금 사용자가 받는 목록 — 그 파일을 직접 읽습니다\n'
             '[지금 만들면] 이 순간 발행하면 나갈 목록 (쿼터 0)\n'
             '[걸러진 것] 규칙에 걸려 빠진 것과 **그 이유**'),
            ('필터 규칙',
             '오래된 것 · 게시일 모름 · 똑같은 제목 · 채널당 상한 · 손으로 지정.\n'
             '⚠ 거르는 것은 **「최신 목록에 안 싣는다」**일 뿐입니다 — 자산은 '
             '그대로 남고 구절·용어 연결로는 계속 보입니다.'),
            ('수집기 필터와 겹치지 않습니다',
             '수집기는 「이 영상을 **DB 에 담을까**」(성경 본문과 관계있나)를, '
             '승인은 「**사용자에게 보일까**」를, 여기는 「**「최신」에 실을까**」'
             '(지금 볼 만한가)를 정합니다. 셋은 차례로 서는 다른 문입니다.'),
        ], height=10)

        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        # ★★ **콤보가 둘이다 — 축이 다르다**(2026-09-06 사용자 지적 「미리보기
        #   언어」). 그전에는 「언어」 하나였는데 **[서버에 있는 것] 에만 걸리고
        #   [지금 만들면] 은 그 값을 아예 안 읽었다** — 같은 콤보가 단추에 따라
        #   다른 뜻이 되니 「골랐는데 안 먹는다」로 보였다(§0-1).
        #     · **서버 파일** = 어느 `youtube_<LANG>.tsv` 를 받아 볼까.
        #       파일 열한 개가 **같은 200행**이고 제목만 그 언어로 번역돼 있다
        #       (§198차 ⑱) — 그러니 이것은 「목록의 언어」가 아니라 **번역본 고르기**다.
        #     · **원본 언어** = 그 영상이 무슨 언어인가(`lang` 칸). 두 목록에
        #       **함께** 걸린다.
        ttk.Label(bar, text='서버 파일').pack(side='left')
        try:
            import lang_config
            langs = list(lang_config.ui_langs())
        except Exception:
            langs = ['KO', 'EN']
        self._lang = _lu.name_combo(bar, codes_=langs, width=16)
        self._lang._set_code('KO')
        self._lang.pack(side='left', padx=(2, 10))
        self._lang.bind('<<ComboboxSelected>>', lambda _e: self._load_server())

        ttk.Label(bar, text='원본 언어').pack(side='left')
        self._src_lang = _lu.name_combo(bar, codes_=langs, width=16,
                                        extra=[(ALL_LANG, ALL_LANG)])
        self._src_lang._set_code(ALL_LANG)
        self._src_lang.pack(side='left', padx=(2, 10))
        self._src_lang.bind('<<ComboboxSelected>>', lambda _e: self._refill())

        self._b_srv = ttk.Button(bar, text='서버에 있는 것',
                                 command=self._load_server)
        self._b_srv.pack(side='left', padx=2)
        self._b_new = ttk.Button(bar, text='지금 만들면 (미리보기)',
                                 command=self._load_preview)
        self._b_new.pack(side='left', padx=2)
        self._b_drop = ttk.Button(bar, text='걸러진 것', state='disabled',
                                  command=self._show_drop)
        self._b_drop.pack(side='left', padx=2)
        ttk.Button(bar, text='필터 규칙…',
                   command=self._edit_rules).pack(side='left', padx=(12, 2))

        self._stat = tk.Label(self, text='', anchor='w', fg='#444')
        self._stat.pack(fill='x', padx=10, pady=(2, 4))

        wrap = ttk.Frame(self)
        wrap.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        cols = (('d', '게시일', 92, 'center'), ('site', '채널·사이트', 190, 'w'),
                ('lang', '언어', 52, 'center'), ('title', '제목', 520, 'w'),
                ('why', '메모', 230, 'w'))
        tv = ttk.Treeview(wrap, columns=[c[0] for c in cols],
                          show='headings', selectmode='browse')
        for k, t, w, anc in cols:
            tv.heading(k, text=t)
            tv.column(k, width=w, anchor=anc, stretch=(k == 'title'))
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(side='left', fill='both', expand=True)
        tv.tag_configure('drop', foreground='#C0392B')
        tv.tag_configure('old', foreground='#E67E22')
        tv.bind('<Double-1>', self._open)
        self._tv = tv
        self._urls = {}

    # ── 목록 ────────────────────────────────────────────────────────
    def _src(self):
        """선택한 원본 언어 — 「전체」면 None(안 거른다)."""
        v = (self._src_lang._get_code() or ALL_LANG).strip()
        return None if v == ALL_LANG else v.upper()

    def _fill(self, rows, tag=None, why_key=None, _keep=True):
        """목록을 그린다. **원본 언어 필터가 여기 한 곳에서 걸린다** —
        세 단추(서버·미리보기·걸러진 것)가 전부 이 문을 지나므로 갈리지 않는다."""
        if _keep:
            self._shown = (list(rows), tag, why_key)
        want = self._src()
        tv = self._tv
        tv.delete(*tv.get_children())
        self._urls = {}
        n = 0
        for i, r in enumerate(rows):
            if isinstance(r, tuple):
                r, why = r
            else:
                why = (r.get(why_key) or '') if why_key else ''
            if want and (r.get('lang') or '').upper() != want:
                continue
            iid = 'r%d' % i
            self._urls[iid] = r.get('item_url') or ''
            tv.insert('', 'end', iid=iid,
                      values=(LR._date_of(r), r.get('site_name') or '',
                              r.get('lang') or '', r.get('title') or '', why),
                      tags=((tag,) if tag else ()))
            n += 1
        self._shown_n = n
        return n

    def _lang_note(self, total):
        """필터가 걸렸으면 **몇 개를 감췄는지 말한다** — 안 말하면
        「목록이 줄었다」가 고장으로 읽힌다."""
        want = self._src()
        if not want:
            return ''
        return ('   · 원본 언어 %s 만 보입니다 (%d / %d — 나머지 %d개는 감춤)'
                % (want, self._shown_n, total, total - self._shown_n))

    def _refill(self):
        """원본 언어를 바꿨을 때 — **다시 받지 않고 그 자리에서 다시 그린다.**"""
        rows, tag, why_key = getattr(self, '_shown', ([], None, None))
        if not rows:
            return
        self._fill(rows, tag, why_key, _keep=False)
        base = getattr(self, '_stat_base', '')
        self._stat.config(text=base + self._lang_note(len(rows)))

    def _load_server(self):
        if self._busy:
            return
        self._busy = True
        self._stat.config(text='서버에서 읽는 중…')
        lang = self._lang._get_code() or 'KO'
        threading.Thread(target=self._srv_worker, args=(lang,),
                         daemon=True).start()
        self.after(150, self._drain)

    def _srv_worker(self, lang):
        try:
            rows, note = server_rows(self.kind, lang)
        except Exception as e:
            rows, note = [], str(e)[:80]
        self._q.put(('srv', rows, note))

    def _load_preview(self):
        if self._busy:
            return
        self._busy = True
        slow = (self.kind == 'items')
        self._stat.config(
            text='지금 만들면 나갈 목록을 계산 중…'
                 + (' (피드를 실시간으로 읽습니다 — 조금 걸립니다)'
                    if slow else ''))
        threading.Thread(target=self._prev_worker, daemon=True).start()
        self.after(150, self._drain)

    def _prev_worker(self):
        try:
            conn = appdb.connect(DB)
            try:
                keep, drop, note = LR.preview(
                    conn, self.kind, KINDS[self.kind]['limit'] or 200)
            finally:
                conn.close()
        except Exception as e:
            keep, drop, note = [], [], str(e)[:90]
        self._q.put(('new', keep, note, drop))

    def _drain(self):
        try:
            m = self._q.get_nowait()
        except queue.Empty:
            self.after(150, self._drain)
            return
        self._busy = False
        if m[0] == 'srv':
            _k, rows, note = m
            self._fill(rows)
            self._b_drop.config(state='disabled')
            self._stat_base = ('**서버에 있는 것** — %s   (사용자가 지금 받는 목록)'
                               % note)
        else:
            _k, rows, note, drop = m
            self._drop = drop
            self._fill(rows)
            self._b_drop.config(state=('normal' if drop else 'disabled'))
            self._stat_base = ('**지금 만들면** — %d행 나갑니다 · 걸러진 것 %d개  %s'
                               % (len(rows), len(drop), note))
        self._stat.config(text=self._stat_base
                          + self._lang_note(len(self._shown[0])))

    def _show_drop(self):
        if not self._drop:
            return
        self._fill(self._drop, tag='drop')
        self._stat_base = ('**걸러진 것** %d개 — 「최신」에만 안 싣습니다. '
                           '자산은 그대로 남고 구절·용어 연결로는 계속 보입니다.'
                           % len(self._drop))
        self._stat.config(text=self._stat_base + self._lang_note(len(self._drop)))

    def _open(self, _e=None):
        sel = self._tv.selection()
        if sel and self._urls.get(sel[0]):
            webbrowser.open(self._urls[sel[0]])

    # ── 규칙 ────────────────────────────────────────────────────────
    def _edit_rules(self):
        """필터 규칙 — **왼쪽 스위치 · 오른쪽 거르는 말**(언어 버킷).

        ★★★ **다국어로 적는다** (2026-09-06 사용자 0.txt 9번 「필터 규칙 :
          **전혀 수정된 것 없다.** 제외대상 키워드 입력공간에 다국어 모드로
          입력하려면 **별도 탭화면처럼 크게 구성**해야 한다」).
          그전에는 한 줄 Entry 에 쉼표로 적었다 — 열한 언어를 담을 수 없고,
          담아도 한 낱말이 **모든 언어에 걸려** 오탐이 났다(§203차).
        ★ **분류관리 「거르는 말」 탭과 같은 문법**이다 — 왼쪽에서 언어를
          고르고 오른쪽에 한 줄씩. 두 화면이 다른 문법을 쓰면 헷갈린다.
        ⚠ **분류관리의 제외후보와 축이 다르다** — 그쪽은 「**담을까**」를
          수집할 때 한 번 보고, 여기는 「**최신에 실을까**」를 나갈 때마다
          본다. 그래서 그 낱말을 함께 쓸지 스위치로 고른다(기본 켬).
        """
        conn = appdb.connect(DB)
        try:
            cur = LR.get_rules(conn)
        finally:
            conn.close()
        w = tk.Toplevel(self)
        w.title('최신 콘텐츠 필터 규칙')
        w.transient(self.winfo_toplevel())
        w.geometry('980x600')
        try:
            import ui_theme
            ui_theme.adopt(w)
        except Exception:
            pass

        top = ttk.Frame(w)
        top.pack(fill='x', padx=12, pady=(10, 4))
        tk.Label(top, anchor='w', justify='left', fg='#555',
                 text='규칙은 유튜브·텍스트에 함께 걸립니다. '
                      '거르는 것은 「최신 목록에 안 싣는다」일 뿐이고, '
                      '자산도 구절·용어 연결도 그대로 남습니다.'
                 ).pack(anchor='w')

        pw = ttk.Panedwindow(w, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=12, pady=(4, 4))
        left = ttk.Frame(pw)
        right = ttk.Frame(pw)
        pw.add(left, weight=0)
        pw.add(right, weight=1)

        # ── 왼쪽: 스위치 ────────────────────────────────────────
        vs = {}
        rows = [
            ('max_age_days', '이보다 오래된 것은 뺀다 (일 · 0=안 씀)', 'int'),
            ('max_per_channel', '한 채널 상한 (0=안 씀)', 'int'),
            ('max_per_lang', '언어마다 몇 개까지 (0=안 씀)', 'int'),
            ('drop_no_date', '게시일을 모르는 것을 뺀다', 'bool'),
            ('dedupe_title', '똑같은 제목은 하나만 (1·2·3부 실황)', 'bool'),
            ('registered_only', '등록한 채널의 것만 싣는다', 'bool'),
            ('use_exclude_kw', '분류관리의 「제외후보」 낱말도 함께 쓴다', 'bool'),
            ('exclude_channels', '뺄 채널 (쉼표로)', 'list'),
        ]
        for i, (k, lab, ty) in enumerate(rows):
            ttk.Label(left, text=lab, wraplength=250, justify='left').grid(
                row=i, column=0, sticky='w', pady=3, padx=(0, 6))
            if ty == 'bool':
                v = tk.BooleanVar(value=bool(cur.get(k, True) if k in
                                             ('registered_only', 'use_exclude_kw')
                                             else cur.get(k)))
                ttk.Checkbutton(left, variable=v).grid(row=i, column=1, sticky='w')
            else:
                v = tk.StringVar(
                    value=(', '.join(cur.get(k) or []) if ty == 'list'
                           else str(cur.get(k) or 0)))
                ttk.Entry(left, textvariable=v,
                          width=(26 if ty == 'list' else 8)).grid(
                    row=i, column=1, sticky='w')
            vs[k] = (v, ty)
        # ⚠ **그 스위치가 무엇을 함께 쓰는지 말한다** — 이름만으로는
        #   「제외후보」가 어디 있는 무엇인지 모른다(§0-1).
        tk.Label(left, anchor='w', justify='left', fg='#7F8C8D',
                 wraplength=270,
                 text='※ 제외후보 = [수집 ▸ ① 채널 ▸ 낱말 관리 ▸ '
                      '거르는 낱말] 의 낱말입니다. 거기는 「담을까」를 수집할 때 '
                      '한 번 보고, 여기는 「최신에 실을까」를 나갈 때마다 봅니다.'
                 ).grid(row=len(rows), column=0, columnspan=2,
                        sticky='w', pady=(10, 0))

        # ── 오른쪽: 거르는 말(언어 버킷) ─────────────────────────
        kwm = LR.title_kw_map(cur)
        try:
            import lang_config
            langs = ['*'] + [str(x).upper() for x in lang_config.ui_langs()]
        except Exception:
            langs = ['*', 'KO', 'EN']
        for k in kwm:
            if k not in langs:
                langs.append(k)

        ttk.Label(right, text='제목에 이 말이 있으면 뺀다 — 한 줄에 하나'
                  ).pack(anchor='w')
        box = ttk.Frame(right)
        box.pack(fill='both', expand=True, pady=(4, 0))
        lb = tk.Listbox(box, exportselection=False, width=14)
        lb.pack(side='left', fill='y')
        txt = tk.Text(box, wrap='none', undo=True)
        txt.pack(side='left', fill='both', expand=True, padx=(8, 0))
        sb = ttk.Scrollbar(box, orient='vertical', command=txt.yview)
        sb.pack(side='left', fill='y')
        txt.configure(yscrollcommand=sb.set)

        cache = {lg: list(kwm.get(lg) or []) for lg in langs}
        state = {'cur': None}

        def _label(lg):
            n = len(cache.get(lg) or [])
            return ('%s  (%d)' % ('공통' if lg == '*' else lg, n))

        def _refill_list(keep=None):
            lb.delete(0, 'end')
            for lg in langs:
                lb.insert('end', _label(lg))
            if keep in langs:
                lb.selection_set(langs.index(keep))

        def _stash():
            lg = state['cur']
            if lg is None:
                return
            cache[lg] = [x.strip() for x in txt.get('1.0', 'end').split('\n')
                         if x.strip()]

        def _pick(_e=None):
            sel = lb.curselection()
            if not sel:
                return
            lg = langs[sel[0]]
            if lg == state['cur']:
                return
            _stash()
            state['cur'] = lg
            txt.delete('1.0', 'end')
            txt.insert('1.0', '\n'.join(cache.get(lg) or []))
            # ⚠ 개수가 그 자리에서 따라와야 한다 — 안 그러면 저장했는지 모른다
            _refill_list(lg)

        lb.bind('<<ListboxSelect>>', _pick)
        _refill_list('*')
        lb.selection_set(0)
        _pick()

        def save():
            _stash()
            d = {}
            for k, (v, ty) in vs.items():
                if ty == 'bool':
                    d[k] = bool(v.get())
                elif ty == 'int':
                    try:
                        d[k] = int(str(v.get()).strip() or 0)
                    except ValueError:
                        messagebox.showerror('규칙', '%s 는 숫자여야 합니다.' % k,
                                             parent=w)
                        return
                else:
                    d[k] = [x.strip() for x in str(v.get()).split(',')
                            if x.strip()]
            # ⚠ **빈 버킷은 안 담는다** — 언어를 늘릴 때마다 빈 칸이 쌓인다
            d['title_kw'] = {lg: v for lg, v in cache.items() if v}
            c2 = appdb.connect(DB)
            try:
                LR.set_rules(c2, d)
            finally:
                c2.close()
            w.destroy()
            # ⚠ 고치면 **그 자리에서** 결과를 보인다 — 안 그러면 먹었는지 모른다.
            self._load_preview()

        b = ttk.Frame(w)
        b.pack(fill='x', padx=12, pady=(4, 10))
        ttk.Button(b, text='저장하고 미리보기', command=save).pack(side='right')
        ttk.Button(b, text='취소', command=w.destroy).pack(side='right', padx=6)


class ContribTab(ttk.Frame):
    """**어느 채널이 나가는 목록을 채우고 있나** (2026-09-06 사용자 지시
    「채널목록 중복표시 … **다른 의미있는 기능으로 교체**해야 한다」).

    ★★ **자동크롤러의 채널 목록과 축이 다르다** — 그쪽은 「등록·주기·설정」,
      여기는 **「나가는 200행에 이 채널이 몇 개나 들어갔나」**다. 겹치지 않는다.
    ★ 그리고 **그 자리에서 뺀다** — 쏠린 채널을 보고 바로 [최신에서 빼기].
      보기만 하고 손댈 수 없으면 필터 규칙이 쓰이지 않는다.
    ⚠ 빼는 것은 「**최신 목록에만** 안 싣는다」다 — 자산도, 구절·용어 연결도
      그대로다.
    """

    def __init__(self, master, kind='yt'):
        super().__init__(master)
        self.kind = kind if kind in KINDS else 'yt'
        self._q = queue.Queue()
        self._busy = False
        self._build()
        self.after_idle(self.refresh)

    def _build(self):
        what = '채널' if self.kind == 'yt' else '사이트'
        help_row(self, '%s 기여도 — 나가는 목록을 누가 채우나' % what, [
            ('이 탭의 기능',
             '지금 발행하면 나갈 목록에서 **%s별 몫**을 셉니다. '
             '한 곳이 목록을 독차지하면 다른 곳이 밀려납니다.' % what),
            ('자동크롤러의 채널 목록과 다릅니다',
             '그 화면은 「등록·주기·설정」을 다루고, 여기는 '
             '**「나가는 목록에 몇 개나 들어갔나」**를 봅니다. 축이 다릅니다.'),
            ('주요 버튼',
             '[최신에서 빼기] 선택한 %s를 최신 목록에서 뺍니다\n'
             '[다시 넣기] 뺀 것을 되돌립니다\n'
             '⚠ 빼도 **자산과 구절·용어 연결은 그대로**입니다 — '
             '「최신」에만 안 실립니다.' % what),
        ], height=8)

        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Button(bar, text='🔄 다시 세기',
                   command=self.refresh).pack(side='left', padx=2)
        self._b_off = ttk.Button(bar, text='최신에서 빼기', state='disabled',
                                 command=lambda: self._toggle(True))
        self._b_off.pack(side='left', padx=2)
        self._b_on = ttk.Button(bar, text='다시 넣기', state='disabled',
                                command=lambda: self._toggle(False))
        self._b_on.pack(side='left', padx=2)
        self._stat = tk.Label(bar, text='', anchor='e', fg='#444')
        self._stat.pack(side='right')

        wrap = ttk.Frame(self)
        wrap.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        cols = (('name', '채널·사이트', 260, 'w'), ('n', '나가는 몫', 90, 'e'),
                ('pct', '비율', 70, 'e'), ('last', '가장 새 글', 100, 'center'),
                ('state', '상태', 110, 'center'))
        tv = ttk.Treeview(wrap, columns=[c[0] for c in cols],
                          show='headings', selectmode='extended')
        for k, t, w, anc in cols:
            tv.heading(k, text=t)
            tv.column(k, width=w, anchor=anc, stretch=(k == 'name'))
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(side='left', fill='both', expand=True)
        tv.tag_configure('off', foreground='#C0392B')
        tv.tag_configure('hot', foreground='#E67E22')
        tv.bind('<<TreeviewSelect>>', lambda _e: self._sync())
        self._tv = tv

    def refresh(self):
        if self._busy:
            return
        self._busy = True
        self._stat.config(text='세는 중…')
        threading.Thread(target=self._worker, daemon=True).start()
        self.after(150, self._drain)

    def _worker(self):
        try:
            conn = appdb.connect(DB)
            try:
                keep, drop, _n = LR.preview(
                    conn, self.kind, KINDS[self.kind]['limit'] or 200)
                rules = LR.get_rules(conn)
            finally:
                conn.close()
        except Exception as e:
            self._q.put(([], set(), 0, str(e)[:80]))
            return
        agg = {}
        for r in keep:
            s = (r.get('site_name') or '(이름 없음)').strip()
            d = LR._date_of(r)
            a = agg.setdefault(s, [0, ''])
            a[0] += 1
            if d > a[1]:
                a[1] = d
        # ⚠ 빠진 채널도 보인다 — 안 보이면 되돌릴 자리를 못 찾는다.
        for r, _w in drop:
            s = (r.get('site_name') or '(이름 없음)').strip()
            agg.setdefault(s, [0, LR._date_of(r)])
        self._q.put((agg, set(rules.get('exclude_channels') or []),
                     len(keep), ''))

    def _drain(self):
        try:
            agg, off, tot, err = self._q.get_nowait()
        except queue.Empty:
            self.after(150, self._drain)
            return
        self._busy = False
        tv = self._tv
        tv.delete(*tv.get_children())
        for i, (name, (n, last)) in enumerate(
                sorted(agg.items(), key=lambda x: (-x[1][0], x[0]))):
            pct = (n * 100.0 / tot) if tot else 0
            tag = 'off' if name in off else ('hot' if pct >= 10 else '')
            tv.insert('', 'end', iid='c%d' % i,
                      values=(name, n, '%.0f%%' % pct, last,
                              '뺐음' if name in off else ''),
                      tags=((tag,) if tag else ()))
        self._stat.config(
            text=(err or '나가는 %d행 · %s %d곳 · 뺀 것 %d곳'
                  % (tot, '채널' if self.kind == 'yt' else '사이트',
                     len(agg), len(off))))
        self._sync()

    def _sync(self):
        st = 'normal' if self._tv.selection() else 'disabled'
        self._b_off.config(state=st)
        self._b_on.config(state=st)

    def _toggle(self, off):
        names = [self._tv.item(i, 'values')[0] for i in self._tv.selection()]
        if not names:
            return
        if off and not messagebox.askyesno(
                '최신에서 빼기',
                '%d곳을 **최신 목록에서만** 뺍니다.\n'
                '자산과 구절·용어 연결은 그대로 남습니다.\n\n%s'
                % (len(names), ' · '.join(names[:6]))):
            return
        conn = appdb.connect(DB)
        try:
            r = LR.get_rules(conn)
            cur = set(r.get('exclude_channels') or [])
            cur = (cur | set(names)) if off else (cur - set(names))
            r['exclude_channels'] = sorted(cur)
            LR.set_rules(conn, r)
        finally:
            conn.close()
        self.refresh()


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[1] += 1
        ok[0] += 1 if c else 0
        print('  %s %-48s %s' % ('OK  ' if c else 'FAIL', n, e))

    print('=== latest_feed_tab selftest')
    t('★ 갈래 표가 단일 소스', set(KINDS) == {'yt', 'items'})
    t('  파일 이름을 갈래가 정한다',
      KINDS['yt']['file'] % 'KO' == 'youtube_KO.tsv'
      and KINDS['items']['file'] % 'JA' == 'items_JA.tsv')
    # ★★ 화면이 자기 SQL 을 쓰지 않는가 — 발행 문을 부르는지 소스로 잰다.
    #   ⚠ **낱말을 세면 검사 코드 자신이 걸린다**(§196차 `TRAY_CLASS` 함정) —
    #     잣대를 「DB 에 질의를 보내는가」로 못 박는다.
    src = open(__file__, encoding='utf-8').read()
    #   ⚠⚠ **찾는 글자를 검사 코드에 그대로 적으면 자기가 걸린다** — 두 번
    #     밟았다. 조립해서 만든다.
    needle = '.' + 'execute' + '('
    t('★★★ **화면이 DB 에 직접 질의하지 않는다**(발행 문을 그대로 부른다)',
      needle not in src, '%s 발견' % needle)
    t('★★ 미리보기는 `latest_rules.preview` 를 쓴다', 'LR.preview(' in src)
    t('★★ 서버 목록은 **파일을 직접 읽는다**',
      'client_servers' in src and 'urlopen' in src)
    t('★ 걸러진 것에 **이유가 함께 온다**', "tag='drop'" in src)

    # ★★ 원본 언어 필터 — **콤보 둘의 축이 갈려 있는가**(2026-09-06).
    t('★★ 콤보가 둘이다(서버 파일 · 원본 언어)',
      "text='서버 파일'" in src and "text='원본 언어'" in src)
    t('★ 「전체」는 안 거른다', ALL_LANG == '전체')
    #   ⚠ 거르는 자리가 **`_fill` 한 곳**이어야 세 단추가 안 갈린다.
    #   ⚠ **찾는 글자를 그대로 적으면 검사 코드 자신이 걸린다** — 조립한다.
    fneedle = ".upper() != " + "want"
    t('★★★ 필터가 `_fill` 한 곳에만 있다', src.count(fneedle) == 1,
      '%d곳' % src.count(fneedle))
    t('★ 서버 파일 콤보는 다시 받고, 원본 언어는 그 자리에서 다시 그린다',
      'self._load_server()' in src and 'self._refill()' in src)

    # 실제로 걸러지는가 — 위젯 없이 순수 계산만 흉내 낸다(가짜 self).
    class _S:
        _src = LatestFeedTab._src
        _lang_note = LatestFeedTab._lang_note
    s = _S()
    s._src_lang = type('C', (), {'get': lambda self: 'EN'})()
    got = s._src()
    t('★ 언어를 선택하면 대문자 코드로 온다', got == 'EN', str(got))
    s._src_lang = type('C', (), {'get': lambda self: ALL_LANG})()
    t('★ 전체면 None(안 거른다)', s._src() is None)
    #   감춘 개수를 말하는가 — 안 말하면 「목록이 줄었다」가 고장으로 읽힌다
    s._src_lang = type('C', (), {'get': lambda self: 'EN'})()
    s._shown_n = 22
    note = s._lang_note(200)
    t('★★ 감춘 개수를 화면이 말한다',
      '22' in note and '200' in note and '178' in note, note.strip()[:44])

    print('  %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    import sys
    import io
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    sys.exit(0 if selftest() else 1)
