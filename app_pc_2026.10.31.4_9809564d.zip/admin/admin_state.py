"""
admin/admin_state.py
--------------------
관리자 패널 전용 직전값(state) 저장 헬퍼.

저장 위치: 프로젝트 루트의 `app_state_admin.json`
  (사용자 화면용 `app_state.json` 와 별도 — 사용자/관리자 직전값 혼합 방지)

JSON 구조:
{
  "verse_link": {
    "sash_main": [200, 400],
    "sash_p1":   [300, 600],
    "side_A":    {"bcode": 1, "chapter": 1, "verse_idx": 0},
    "side_B":    {...},
    "lang_L":    "KO",
    "lang_R":    "ZH"
  },
  "<other_panel>": {...}
}

API:
  get(panel_key, key, default=None)
  set(panel_key, key, value)  -- 즉시 flush
  save_sash(panel_key, sash_key, paned_window)
  restore_sash(panel_key, sash_key, paned_window)
"""

import os
import json
import tkinter as tk

ADMIN_STATE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)),
    'app_state_admin.json'
)


_cache: dict | None = None


def _load() -> dict:
    global _cache
    if _cache is not None:
        return _cache
    if os.path.exists(ADMIN_STATE_PATH):
        try:
            with open(ADMIN_STATE_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                _cache = data
                return _cache
        except Exception:
            pass
    _cache = {}
    return _cache


def _flush():
    try:
        with open(ADMIN_STATE_PATH, 'w', encoding='utf-8') as f:
            json.dump(_cache or {}, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'[admin_state] flush error: {e}')


def get(panel_key: str, key: str, default=None):
    data = _load()
    panel = data.get(panel_key)
    if not isinstance(panel, dict):
        return default
    return panel.get(key, default)


def set_(panel_key: str, key: str, value):
    """`set` 은 파이썬 빌트인이므로 함수명은 `set_`. 호출 시 즉시 flush."""
    data = _load()
    panel = data.get(panel_key)
    if not isinstance(panel, dict):
        panel = {}
        data[panel_key] = panel
    panel[key] = value
    _flush()


def set_panel(panel_key: str, values: dict):
    """패널 전체를 한꺼번에 갱신 + flush."""
    data = _load()
    panel = data.get(panel_key)
    if not isinstance(panel, dict):
        panel = {}
        data[panel_key] = panel
    panel.update(values)
    _flush()


# ── PanedWindow sash 위치 저장/복원 헬퍼 ────────────────────────────

def save_sash(panel_key: str, sash_key: str, pw: tk.PanedWindow | object):
    """PanedWindow 의 모든 sash 좌표 저장. ttk.PanedWindow 도 지원."""
    try:
        positions = []
        # ttk.PanedWindow 는 sashpos(index) 만 제공
        # 자식 개수 - 1 = sash 개수
        try:
            kids = pw.panes() if hasattr(pw, 'panes') else pw.winfo_children()
        except Exception:
            kids = []
        n_sashes = max(0, len(kids) - 1)
        for i in range(n_sashes):
            try:
                p = pw.sashpos(i)
            except Exception:
                # tk.PanedWindow 는 sash_coord(i) → (x, y)
                try:
                    coord = pw.sash_coord(i)
                    p = coord[0] if pw.cget('orient') == 'horizontal' else coord[1]
                except Exception:
                    p = None
            if p is not None:
                positions.append(p)
        if positions:
            set_(panel_key, sash_key, positions)
    except Exception as e:
        print(f'[admin_state] save_sash error: {e}')


#: 한 칸이 가질 최소 픽셀 — 이보다 좁으면 「칸이 사라졌다」로 보인다
_SASH_MIN = 90


def restore_sash(panel_key: str, sash_key: str, pw, _retry=6):
    """저장된 sash 좌표 복원 — **검증하고 꽂는다.**

    ⚠⚠ 그전에는 절대 좌표를 검증 없이 꽂았다 (2026-08-27 사용자 신고
      「연결 탭에 접속할 때마다 **화면이 바뀐다.** 연결설명문 입력화면만
      보이는 상황도 발생한다」). 원인 둘:
      ① 복원이 `after(200)` 인데 그때 창이 아직 제 크기가 아니면 좌표가
        엉뚱한 비율로 박힌다 — 열 때마다 경주 결과가 달라 화면이 달랐다.
      ② 저장값이 0 근처거나 창보다 크면 **한 칸이 통째로 사라진다.**
    ⇒ ① 창이 채 안 그려졌으면(길이 < 최소 요구) 잠시 뒤 다시 시도
      ② 각 칸이 최소 `_SASH_MIN` px 를 갖도록 좌표를 **묶어서** 꽂는다.
    """
    positions = get(panel_key, sash_key)
    if not isinstance(positions, list) or not positions:
        return
    try:
        vertical = str(pw.cget('orient')).startswith('vert')
        total = pw.winfo_height() if vertical else pw.winfo_width()
        n_pane = len(pw.panes())
    except Exception:
        return
    need = _SASH_MIN * max(n_pane, len(positions) + 1)
    if total < need:
        # 아직 안 그려졌다 — 좌표를 꽂으면 엉뚱한 비율로 굳는다. 잠시 뒤에.
        if _retry > 0:
            try:
                pw.after(250, lambda: restore_sash(panel_key, sash_key, pw,
                                                   _retry - 1))
            except Exception:
                pass
        return
    lo = _SASH_MIN
    for i, p in enumerate(positions):
        hi = total - _SASH_MIN * (len(positions) - i)
        v = max(lo, min(int(p), hi))
        try:
            pw.sashpos(i, v)
        except Exception:
            try:
                pw.sash_place(i, v, v)
            except Exception:
                pass
        lo = v + _SASH_MIN


def bind_sash_save(panel_key: str, sash_key: str, pw):
    """ButtonRelease-1 시점에 sash 위치 자동 저장 (드래그 종료 직후)."""
    def _on_release(_e=None):
        save_sash(panel_key, sash_key, pw)
    try:
        pw.bind('<ButtonRelease-1>', _on_release, add='+')
    except Exception:
        pass
