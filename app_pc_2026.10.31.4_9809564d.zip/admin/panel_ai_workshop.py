# -*- coding: utf-8 -*-
"""AI 작성·번역 — **무엇을 할지 선택하고, 무엇으로 시킬지 적는다** (2026-09-23 277차).

사용자 지시(2026-09-22):
  「작업순서는 의미 없다. 네가 만든 앱을 이용해서 **상황에 따라 선택**하면 된다.
   오늘은 창세기 구절 설명문 JP 번역작업을 1절에서 20절까지, 내일은 연결설명문을
   레위기 3절에서 24절까지 러시아어 번역, 등등..
   그런데 주로 **자료가 없는 것을 신규 작성하는 것이 우선**이라고 생각한다.
   **프롬프트는 json 형식**으로 … **자산에 따라 달라져야** 한다. 구절설명문의
   경우에도 **창세기와 시편이 서로 달라져야** … **스펄전 설교와 마이어 책은
   번역스타일을 다르게** … 이전에 시편 설명문 번역할 때 사용한 프롬프트를
   **계속 참고용으로 보관** … **관리자화면의 어디에 배치할 것인지도 정해라** …
   **작업대상/범위를 선택하면 그 내부에 이미 작성된 것, 언어별 상태를 표시**」

★★★ **자리 = 운영 ▸ AI 작성·번역** (번역 대시보드 바로 다음)
  · 「운영」은 이미 **전 자산을 가로지르는** 두 화면을 담고 있다(언어 관리 ·
    번역 대시보드). 이 화면도 자산 한 종류에 매이지 않으므로 같은 축이다.
  · 번역 대시보드가 **「무엇이 비었나」**를 보이고 이 화면이 **「그 빈자리를
    채운다」** — 차례가 곧 업무흐름이다(배포 묶음을 「점검 → 배포」로 세운
    것과 같은 문법).
  ⚠ 자산 묶음(성경·서고·묵상·연구) 아래에 두지 않았다 — **한 묶음에 넣으면
    나머지 자산에서는 이 화면이 없는 것처럼 보인다.**

★★★ 탭 둘 — 사용자 요구가 정확히 둘이었다
  | 탭 | 답하는 물음 |
  |---|---|
  | **작업 고르기** | 「범위 안에 **이미 작성된 것 · 언어별 상태**」 · 「무엇부터 할까」 |
  | **프롬프트 프로필** | 「자산·책·저자마다 **다른 프롬프트**」 · 「**옛 판 보관**」 |

⚠⚠⚠ **여기서 API 를 부르지 않는다.** 고르고 적는 데까지다 — 실제 호출·게이트·
  적재는 다음 단계다. 그래서 [실행] 단추를 **만들지 않았다**: 눌러도 아무 일이
  안 나는 단추는 서랍이 아니다(§0-1).

⚠ 잣대·조회는 전부 **`db_ai_job` 한 곳**이다. 화면이 제 SQL 을 쓰면 현황과
  작업 목록이 갈린다.
"""
import json

import tkinter as tk
from tkinter import ttk, messagebox

import ai_client as AC
import db_ai_job as AJ
import db_ai_run as AR
from panel_help_box import build_help_button

try:
    from lang_status import LangStatusTable
except Exception:                                         # noqa: BLE001
    from admin.lang_status import LangStatusTable         # noqa: F401

import ui_theme as UT
import appdb


HELP_SECTIONS = [
    ('이 화면의 몫',
     'AI 로 글을 새로 쓰거나 옮기거나 다듬는 일을 한 화면에서 합니다 — '
     '① 작업 만들기 → ② 검수와 승인 → 적재. 프롬프트 탭이 무엇으로 시킬지를, '
     'AI 연결 탭이 어느 모델·키로 보낼지를 정합니다.'),
    ('① 작업 만들기',
     '자산 → 범위 → 자리 세 단으로 좁힙니다. 업무는 셋 — 신규 작성은 기준 언어에도 '
     '없는 자리, 번역은 기준 언어에는 있는데 그 언어에 없는 자리, 다듬기는 그 언어에 '
     '이미 있는 자리입니다. 「이미 완료된 것도 포함」을 켜면 다시 쓰거나 다시 옮길 '
     '자리도 목록에 오릅니다(적재하면 덮어씁니다 — 목록의 (AI) 표식이 누구 글인지 말합니다). '
     '「기준 글 N자」는 할 일로 남은 자리의 기준 언어 글을 목록을 채울 때 센 것입니다. '
     '[프롬프트 보기]는 실제로 보낼 글(층을 합친 프롬프트 + 선택한 첫 줄의 재료)을 그대로 보입니다.'),
    ('② 검수와 승인',
     '[전송하기]는 아직 안 한 것만 보냅니다 — 몇 번을 나눠 눌러도 이어지고 [중지]로 '
     '번역이면 「함께 만들 언어」 줄에서 언어를 여럿 체크해 작업을 한꺼번에 만들 수 있고, '
     '그 자리에서 자리마다 언어 차례로 보낼 수 있습니다. '
     '건 사이에서 멈춥니다. 받은 글은 배포 DB 가 아니라 작업 표에만 담기고, 게이트는 '
     '배포 DB 를 건드리지 않고 잽니다. 오른쪽 글을 고친 뒤 [승인]하면 고친 글로 담깁니다. '
     '[반려]할 때는 옆 칸에 사유를 적어 두세요 — 그 사유가 프롬프트 예제와 새 게이트의 '
     '재료가 됩니다. [승인분 적재]는 승인한 것만 담고, 영어로 낸 도서 글은 현대 영어 칸에 담깁니다.'),
    ('프롬프트 탭 — 수정',
     '프롬프트는 층으로 적고 보낼 때 합칩니다. [수정]에서 세 계층(자산·업무·언어) 단추 '
     '가운데 하나를 선택하면 그 단추의 프롬프트가 열립니다 — 셋 가운데 하나만 선택할 수 있고 '
     '다른 계층의 단추는 저절로 꺼집니다. 「공통」은 모든 작업에 실리는 층입니다. '
     '고친 칸은 저절로 저장됩니다(저장 단추가 없습니다). 칸을 비우면 그 칸이 지워집니다. '
     '자산 단추를 선택하면 「범위」에서 책·저자별로 따로 적을 수 있습니다(범위 옆 글자가 '
     '따로 적힌 범위가 몇 개인지 말합니다). 어느 단추에 무엇이 적혔는지는 [예제] 칸의 '
     '「이미 등록된 프롬프트」가 보입니다.'),
    ('프롬프트 탭 — 조회',
     '[조회]에서 계층마다 하나씩 선택하면 실제로 나가는 결합 프롬프트를 보입니다. '
     '줄 끝 회색 글자가 어느 단추에서 온 줄인지 말합니다. 문체·반드시·금지·용어 고정은 '
     '층이 쌓이고, 역할·할 일·성경 인용·분량·예시·출력서식은 좁은 층(자산·범위)이 '
     '넓은 층(공통)을 이깁니다. 조회에서는 고칠 수 없습니다 — 「수정 버튼을 누르고 '
     '수정하세요」가 뜹니다. 복사는 됩니다.'),
    ('프롬프트 탭 — 성격 열 칸',
     '역할(누구로서) · 할 일 · 문체 · 반드시 · 금지 · 용어 고정 · 성경 인용(언어별 역본) · '
     '분량 · 예시(본보기 글) · 출력서식(본문만 · 제목 없이 …). 여러 줄 칸은 한 줄에 규칙 '
     '하나입니다. 칸 사이 경계를 끌어 크기를 바꿀 수 있습니다.'),
    ('구절 연결기 — 자산 「구절 연결 (연결기)」',
     '자산에서 「구절 연결 (연결기)」를 선택하면 이 화면이 그대로 구절 연결기가 됩니다. '
     '신규 작성만 있습니다(연결은 옮기거나 다듬는 글이 아닙니다). 재료에 본문·앞뒤 절·'
     '이미 이어진 구절·연결 갈래 열둘의 정의와 잣대와 우리 자료의 예가 실립니다. '
     '받는 글은 줄마다 「약명 장:절 · 갈래코드 · 왜 잇는가 한 문장」이고, 게이트가 줄 꼴·'
     '절 표기·갈래 코드·같은 장·이미 이어진 절을 잽니다. 검수 칸에서 줄을 지우거나 고쳐 '
     '승인하면 그 줄만 담깁니다. [승인분 적재]는 sys_link_asset 에 담고(source=AILINK · '
     'confidence=AI · note=왜), 새 링크만 모아 **연결설명문 작업**을 저절로 만듭니다 — '
     '그 작업을 「승인 및 검수」에서 [돌리기] 하면 설명문이 채워집니다. 프롬프트는 '
     '「프롬프트」 탭의 「구절 연결」 단추에서, 게이트는 [게이트] 갈래에서 봅니다.'),
    ('위 띠 오른쪽 — 예제 · 게이트',
     '[예제]는 지금 선택한 단추(자산·업무·언어·공통) 하나의 본보기 프롬프트를 성격별로 보입니다 — '
     '보이는 갈래를 다시 누르면 왼쪽 칸이 접혀 오른쪽 프롬프트 칸이 넓어집니다. '
     '복사해 오른쪽 칸에 붙여 넣으세요. 이미 등록된 그 자산의 층과 사람이 적은 반려 '
     '사유도 함께 보입니다. [게이트]는 받은 글을 재는 검사 목록입니다 — 필수(걸리면 '
     '검수를 부른다)와 참고(알림)를 가르고, 놓치면 무슨 위험이 있는지 적었습니다. '
     '자산 단추를 선택하면 그 자산에 걸리는 것에 ✓ 가 붙습니다.'),
    ('영어 도서 글의 정체',
     '서재의 원문(ORIGINAL)은 저자의 옛 영어 그대로 보관합니다. 다른 언어로 옮길 때는 '
     '현대 영어(MODERN_EN)가 있으면 그것을 원본으로 줍니다. 영어를 영어로 내는 작업은 '
     '번역이 아니라 현대어화이고, 그 글은 현대 영어 칸에 담깁니다.'),
    ('AI 연결 탭',
     'Gemini 키를 여기에 넣습니다. 한도는 키가 아니라 프로젝트 단위라 같은 프로젝트의 '
     '키를 여러 개 넣어도 한도가 늘지 않습니다. [연결 시험]은 실제로 한 번 불러 봅니다 — '
     '그 한 번도 한도를 씁니다.'),
]


def _db():
    return appdb.connect()


class AiWorkshopPanel(ttk.Frame):
    """AI 작성·번역 작업대."""

    def __init__(self, parent, lang_getter=None, **kw):
        super().__init__(parent, **kw)
        self.lang_getter = lang_getter or (lambda: 'KO')
        # ⚠ **지연 빌드 전에 불려도 안 터진다** — 아래 `after(120)` 이
        #   돌기 전에 밖에서 새로고침을 부르면 이 칸들이 없어 `AttributeError`
        #   가 난다(점검기가 그 자리에서 잡았다). 처음부터 값을 갖는다.
        self._scope_vals = [('', '(전체)')]
        self._p_scope_vals = [('', '(전체)')]
        self._status = {}
        self._cur_prompt = (False, '')
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill='both', expand=True, padx=4, pady=4)

        # ★★★ **업무흐름 차례로**(2026-09-25 사용자 「탭 순서 조정 : 업무흐름에
        #   따라서」) — 앞 둘이 날마다 쓰는 흐름(만들고 → 보내고 검수하고),
        #   뒤 둘은 가끔 손대는 설정이다.
        #   ⚠ 탭 번호를 코드에 흩지 말 것 — `self.TAB` 한 표를 본다.
        self.TAB = {'pick': 0, 'review': 1, 'prompt': 2, 'conn': 3, 'sent': 4}
        t0 = ttk.Frame(self._nb)
        self._nb.add(t0, text='① 작업 만들기')
        self._build_pick(t0)

        t1 = ttk.Frame(self._nb)
        self._nb.add(t1, text='② 검수와 승인')
        self._build_review(t1)

        t2 = ttk.Frame(self._nb)
        self._nb.add(t2, text='프롬프트')
        self._build_prof(t2)

        t3 = ttk.Frame(self._nb)
        self._nb.add(t3, text='AI 연결')
        # ★ 2026-10-13 — AI 에게 보낸 글 전부(작업실 · 용어 이름 제안 · 찬양·용어 심사 · 문의 답변 · Claude)
        t4 = ttk.Frame(self._nb)
        self._nb.add(t4, text='AI 에게 보낸 글')
        try:
            import ai_sent_view
            self._sent_view = ai_sent_view.SentView(t4)
            self._sent_view.pack(fill='both', expand=True)
        except Exception as e:                            # noqa: BLE001
            ttk.Label(t4, text='보낸 글 화면을 못 열었습니다: %s' % e, foreground='#C0392B').pack(anchor='w')
        self._build_conn(t3)

        # ★★★ **탭으로 돌아오면 다시 센다** — 배포 DB 는 이 화면의
        #   적재 말고도 다른 화면·다른 앱에서 바뀐다. 한 번 그린
        #   목록을 그대로 두면 **이미 채운 자리가 할 일로 남는다**
        #   (실측 todo 17,650건 0.13초 · 사람이 탭을 옮길 때만 돈다).
        self._nb.bind('<<NotebookTabChanged>>', self._on_tab, add='+')
        # ★ 첫 자산을 고르면 `_on_asset` 이 2·3단을 채운다(3단 구조).
        self.after(120, self._fill_units)
        self.after(260, self._conn_refresh)
        self.after(320, self._rv_reload)

    def _on_tab(self, _e=None):
        """탭을 옮기면 그 탭이 보는 것을 다시 읽는다.

        ⚠ **처음 지을 때도 이 이벤트가 온다** — 칸이 아직 없을 수
          있으므로 통째로 감싼다(§29 지연 빌드).
        """
        try:
            i = self._nb.index(self._nb.select())
        except Exception:                                 # noqa: BLE001
            return
        try:
            if i == self.TAB['pick']:
                self._refresh_status()
            elif i == self.TAB['review']:
                self._rv_reload()
            elif i == self.TAB['sent'] and getattr(self, '_sent_view', None):
                self._sent_view.reload()
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop tab] %s' % e)

    # ══════════════════════════════════════════════════════════════
    #  탭 1 — 작업 고르기
    # ══════════════════════════════════════════════════════════════
    def _build_pick(self, root):
        """자산 → 세부 → 유닛 **3단**, 업무·언어·단추는 그 **위** 띠.

        ⚠⚠⚠ **주 단추를 보조에 섞지 않는다**(2026-09-25 사용자 「**엄청
          중요한 버튼조차 숨기듯이 배치**해서 너무 싫다」). 옛 배치에서
          [이 선택으로 작업 만들기] 는 「모두 고르기·고른 것 풀기·처음 N개」
          **뒤 네 번째**였고 크기도 같았다. 이제 띠 맨 왼쪽에 혼자 선다.
        """
        # ★★★ **단추 줄이 먼저, 목록은 나중**(2026-09-25 사용자
        #   「하단의 모든 버튼들을 상단으로. 절대로 버튼을 하단에
        #   배치하지 마라」 · §0). `pack` 은 붙인 차례로 자리를 주므로
        #   **`pw.pack()` 을 함수 끝으로 미루는 것**이 곧 재배치다 —
        #   위젯을 옮기면 콜백·참조가 흔들린다.
        pw = ttk.PanedWindow(root, orient='horizontal')

        # ── ① 자산 종류 — **콤보가 아니라 목록**(사용자 지시) ────────
        f1 = ttk.Frame(pw)
        pw.add(f1, weight=1)
        ttk.Label(f1, text='① 무엇을 쓰거나 옮길까',
                  font=('', 10, 'bold')).pack(anchor='w', padx=4, pady=(2, 0))
        self._asset_tv = ttk.Treeview(f1, columns=('n',), show='tree',
                                      selectmode='browse')
        self._asset_tv.column('#0', width=190, stretch=True)
        self._asset_tv.pack(fill='both', expand=True, padx=(4, 0))
        for code, name, *_ in AJ.ASSETS_UI:
            self._asset_tv.insert('', 'end', iid=code, text=name)
        self._asset_tv.bind('<<TreeviewSelect>>',
                            lambda _e: self._on_asset())

        # ── ② 세부 ────────────────────────────────────────────────
        f2 = ttk.Frame(pw)
        pw.add(f2, weight=1)
        self._scope_lbl = ttk.Label(f2, text='② 어느 것을',
                                    font=('', 10, 'bold'))
        self._scope_lbl.pack(anchor='w', padx=4, pady=(2, 0))
        self._scope_tv = ttk.Treeview(f2, show='tree', selectmode='browse')
        self._scope_tv.column('#0', width=230, stretch=True)
        self._scope_tv.pack(fill='both', expand=True, padx=(4, 0))
        self._scope_tv.bind('<<TreeviewSelect>>',
                            lambda _e: self._on_scope())

        # ── ③ 유닛 — **있는 언어를 이 줄에서 말한다** ───────────────
        f3 = ttk.Frame(pw)
        pw.add(f3, weight=3)
        hd = ttk.Frame(f3)
        hd.pack(fill='x', padx=4, pady=(2, 0))
        self._todo_lbl = ttk.Label(hd, text='③ 어디를',
                                   font=('', 10, 'bold'))
        self._todo_lbl.pack(side='left')
        # ★★★ **통합작업 칸을 사용자가 고른다**(2026-09-25 · 1.txt 16-2 · 2)
        #   「지금은 **네가** 구절설명문+묵상기도+연구자료 등을 지정한다 →
        #    **내가 선택할 수 있도록** 하라」. 묶음 자산일 때만 뜬다(§0-1 —
        #   다른 자산에서는 고를 것이 없으므로 줄 자체가 없다).
        self._pt_row = ttk.Frame(f3)
        self._pt_var = {}
        ttk.Label(self._pt_row, text='함께 쓸 칸:').pack(side='left')
        for _k, _n, *_r in AJ.BUNDLE_PARTS:
            v = tk.BooleanVar(value=True)
            self._pt_var[_k] = v
            ttk.Checkbutton(self._pt_row, text=_n, variable=v,
                            command=self._fill_units   # ★ 317차-19 — 칸이 「할 일」 기준을 바꾼다
                            ).pack(side='left', padx=(2, 6))
        # ★ 317차-5 (docs/1.txt 4-2)) — 연구질문·연구자료는 구절당 여럿이어도 된다 ⇒ **덧붙이기**
        self._add_var = {'STUDY': tk.BooleanVar(value=False), 'NOTE': tk.BooleanVar(value=False)}
        ttk.Label(self._pt_row, text='  기존 유지하고 덧붙이기:').pack(side='left')
        ttk.Checkbutton(self._pt_row, text='연구질문', variable=self._add_var['STUDY'],
                        command=self._fill_units).pack(side='left', padx=(2, 4))
        ttk.Checkbutton(self._pt_row, text='연구자료', variable=self._add_var['NOTE'],
                        command=self._fill_units).pack(side='left', padx=(2, 4))
        # ★ 구절연결기 — 연결설명문을 **함께** 쓴다(docs/1.txt 4 구절연결기 1))
        self._lk_row = ttk.Frame(f3)
        self._lk_desc = tk.BooleanVar(value=True)
        ttk.Checkbutton(self._lk_row, text='연결설명문 함께 작성', variable=self._lk_desc).pack(side='left')
        self._todo = ttk.Treeview(
            f3, columns=('label', 'gist', 'langs', 'sz'),
            show='headings', selectmode='extended')
        for k, t, w, an, st in (('label', '자리', 150, 'w', False),
                                ('gist', '내용', 330, 'w', True),
                                ('langs', '있는 언어', 120, 'w', False),
                                ('sz', '기준 글자', 80, 'e', False)):
            self._todo.heading(k, text=t)
            self._todo.column(k, width=w, anchor=an, stretch=st)
        sb = ttk.Scrollbar(f3, orient='vertical', command=self._todo.yview)
        self._todo.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._todo.pack(fill='both', expand=True, padx=(4, 0))
        self._todo.bind('<<TreeviewSelect>>', lambda _e: self._sum_sel())
        # ★ 할 일인 줄을 **굵게** — 목록을 안 걸러도 눈에 든다
        self._todo.tag_configure('todo', font=('', 9, 'bold'))

        # ── 위 띠 — 업무·언어·**주 단추**(§0 단추는 위) ──────────────
        bar = ttk.Frame(root)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        self._mk_btn = tk.Button(bar, text='작업 만들기', width=14,
                                 command=self._make_job,
                                 **UT.focus_kw())
        self._mk_btn.pack(side='left', padx=(0, 10))
        ttk.Separator(bar, orient='vertical').pack(side='left', fill='y',
                                                   padx=(0, 10))
        ttk.Label(bar, text='④ 업무:').pack(side='left')
        self._task = tk.StringVar(value='NEW')
        # ★ docs/2.txt 8번(2026-10-23) — 외부 자료(도서·설교·주석·문답·사전)는 **신규 작성·원문 다듬기 라디오를
        #   아예 못 누른다**(`_sync_tasks` — 잣대는 엔진의 `edit_blocked` 하나 · 화면이 따로 정하지 않는다).
        self._task_rb = {}
        for code, name, _why in AJ.TASKS:
            self._task_rb[code] = ttk.Radiobutton(bar, text=name, value=code, variable=self._task,
                                                  command=self._on_task)
            self._task_rb[code].pack(side='left', padx=(2, 6))
        ttk.Label(bar, text='  기준:').pack(side='left')
        self._base = ttk.Combobox(bar, state='readonly', width=6)
        self._base.pack(side='left', padx=2)
        self._base.bind('<<ComboboxSelected>>', lambda _e: self._fill_units())
        ttk.Label(bar, text='→ 대상:').pack(side='left')
        self._lang = ttk.Combobox(bar, state='readonly', width=6,
                                  values=AJ.ui_langs())
        self._lang.set('KO')
        self._lang.pack(side='left', padx=2)
        self._lang.bind('<<ComboboxSelected>>', lambda _e: self._fill_units())
        # ★★★ **다시 쓰기·다시 번역은 이 체크 하나**(2026-09-25 사용자 지시
        #   「있는지도 몰랐다 … "이미 완료된 것을 대상으로 포함"」).
        #   ⚠ 옛 「할 일만 보기」와 **뜻이 반대**다 — 켜면 **이미 찬 자리까지**
        #     목록에 올라온다. 끄면 아직 안 한 자리만(지금까지의 기본).
        #   ⚠ 자리도 옮겼다 — 목록 머리 오른쪽 끝에 있어 아무도 못 봤다.
        self._incl_done = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text='이미 완료된 것도 포함',
                        variable=self._incl_done,
                        command=self._fill_units).pack(side='left', padx=(10, 0))
        # ★ 「보낼 글 보기」가 아니라 **[프롬프트 보기]**(사용자 지시) —
        #   화면에 늘 펴 두지 않고 누를 때만 팝업으로 연다.
        build_help_button(bar, 'AI 작성·번역 — 사용방법',
                          HELP_SECTIONS).pack(side='right', padx=4)
        ttk.Button(bar, text='프롬프트 보기',
                   command=self._show_prompt).pack(side='right', padx=4)

        # ── 보조 줄 — 고르기·한도 ──────────────────────────────────
        pk = ttk.Frame(root)
        pk.pack(fill='x', padx=6, pady=(0, 2))
        ttk.Button(pk, text='모두 선택하기',
                   command=self._pick_all).pack(side='left')
        ttk.Button(pk, text='선택한 것 풀기',
                   command=self._pick_none).pack(side='left', padx=(4, 12))
        ttk.Label(pk, text='처음').pack(side='left')
        self._pick_n = tk.StringVar(value='20')
        ttk.Spinbox(pk, from_=1, to=9999, width=6,
                    textvariable=self._pick_n).pack(side='left', padx=2)
        ttk.Button(pk, text='개 선택하기',
                   command=self._pick_first).pack(side='left')
        # ★ **묶음 한도** — 참값은 모델이 정한다(출력 토큰 상한). 칸을 둔다.
        ttk.Label(pk, text='   한 번에 보낼 글자').pack(side='left')
        self._cap = tk.StringVar(value='6000')
        sp = ttk.Spinbox(pk, from_=500, to=200000, increment=500, width=8,
                         textvariable=self._cap)
        sp.pack(side='left', padx=2)
        sp.bind('<KeyRelease>', lambda _e: self._sum_sel())

        # ★★★ 296차(1.txt 2번 3)) — **여러 언어로 함께 만들기**(번역만). 체크한 언어마다
        #   작업을 하나씩 만든다(한 작업 = 한 언어라는 전제를 안 깨뜨린다). 만든 뒤
        #   원하면 **자리마다 모든 언어를 차례로** 보낸다(`_rv_start_multi`).
        self._ml_row = ttk.Frame(root)
        ttk.Label(self._ml_row, text='함께 만들 언어(번역):',
                  foreground='#1A5276').pack(side='left', padx=(2, 6))
        self._ml_vars = {}
        for _lg in AJ.ui_langs():
            _v = tk.BooleanVar(value=False)
            ttk.Checkbutton(self._ml_row, text=_lg, variable=_v).pack(side='left', padx=(0, 4))
            self._ml_vars[_lg] = _v
        ttk.Label(self._ml_row, text='— 언어마다 작업이 하나씩 생깁니다',
                  foreground='#7F8C8D').pack(side='left', padx=8)
        self._ml_row.pack(fill='x', padx=6, pady=(0, 2))
        self._ml_sync()

        self._why = ttk.Label(root, text='', foreground='#7F8C8D')
        self._why.pack(fill='x', padx=8)
        self._sel_lbl = ttk.Label(root, text='', foreground='#1A5276')
        self._sel_lbl.pack(fill='x', padx=8, pady=(0, 4))
        # ★ 목록은 **맨 나중** — 남은 높이를 통째로 쓴다.
        pw.pack(fill='both', expand=True, padx=6, pady=(2, 6))

        self._scope_vals = [('', '(전체)')]
        self.after(150, lambda: self._asset_tv.selection_set(
            AJ.ASSETS[0][0]))

    # ── 3단이 서로를 채운다 ─────────────────────────────────────────
    def _kind(self):
        sel = self._asset_tv.selection()
        return sel[0] if sel else AJ.ASSETS[0][0]

    def _scope_val(self):
        sel = self._scope_tv.selection()
        if not sel:
            return ''
        return '' if sel[0] == '_all' else sel[0]

    def _on_asset(self):
        """자산을 선택하면 **세부 목록**이 찬다 — 유닛은 세부를 선택한 뒤."""
        kind = self._kind()
        axis = AJ.ASSET[kind]['axis']
        try:
            with _db() as conn:
                self._scope_vals = AJ.axis_values(conn, axis,
                                                  self.lang_getter())
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop scope] %s' % e)
            self._scope_vals = [('', '(전체)')]
        self._scope_tv.delete(*self._scope_tv.get_children())
        for v, n in self._scope_vals:
            self._scope_tv.insert('', 'end', iid=(v or '_all'), text=n)
        self._scope_lbl.config(text='② 어느 것을 — %s'
                                    % AJ.ASSET[kind]['name'])
        # ⚠ **묶음이 아니면 줄 자체를 감춘다** — 고를 것이 없는 자리에
        #   체크를 두면 화면이 거짓말한다(§0-1 빈 서랍 금지).
        try:
            if AJ.ASSET[kind].get('store') == 'BUNDLE':
                self._pt_row.pack(fill='x', padx=4, pady=(2, 0),
                                  before=self._todo)
            else:
                self._pt_row.pack_forget()
            if kind == 'VERS_LINK':           # ★ 317차-20 — 해제분석에는 「연결설명문 함께」가 없다
                self._lk_row.pack(fill='x', padx=4, pady=(2, 0), before=self._todo)
            else:
                self._lk_row.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass
        # ⚠ **유닛 목록을 비운다** — 앞 자산의 줄이 남아 있으면 무엇을 보는지
        #   알 수 없다. 세부를 고르면 그때 찬다.
        self._todo.delete(*self._todo.get_children())
        self._sel_lbl.config(text='')
        kids = self._scope_tv.get_children()
        if kids:
            self._scope_tv.selection_set(kids[0])
        else:
            self._on_scope()

    def _on_scope(self):
        """세부를 선택하면 **기준 언어 후보**를 맞추고 유닛을 채운다."""
        kind, sc = self._kind(), self._scope_val()
        try:
            with _db() as conn:
                opts = [lg for lg, _n in AJ.base_options(conn, kind, sc)]
                if not opts:
                    opts = [AJ.base_lang(kind, sc, conn)]
                cur = (self._base.get() or '').upper()
                base = cur if cur in opts else opts[0]
                self._base['values'] = opts
                self._base.set(base)
                self._mine = AJ.is_mine(kind, sc, conn)
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop base] %s' % e)
        self._fill_units()

    def _ml_sync(self):
        """여러 언어 줄은 **번역일 때만** 보인다 — 신규·다듬기에는 뜻이 없다(§0-1)."""
        row = getattr(self, '_ml_row', None)
        if row is None:
            return
        if self._task.get() == 'TRANS':
            if not row.winfo_manager():          # ⚠ `winfo_manageable` 은 없는 이름이다
                if hasattr(self, '_why'):
                    row.pack(fill='x', padx=6, pady=(0, 2), before=self._why)
                else:
                    row.pack(fill='x', padx=6, pady=(0, 2))
        else:
            row.pack_forget()

    def extra_langs(self):
        """체크한 언어(대상 콤보 언어는 뺀다) — 번역이 아니면 빈 목록."""
        if self._task.get() != 'TRANS':
            return []
        cur = (self._lang.get() or 'KO').upper()
        return [lg for lg, v in getattr(self, '_ml_vars', {}).items()
                if v.get() and lg != cur]

    def _on_task(self):
        self._ml_sync()
        return self._on_task_orig()

    def _on_task_orig(self):
        self._fill_units()

    # ⚠ 상한 = **한 화면에서 훑고 고를 만한 크기**. 넘으면 세부를 먼저
    #   고르게 한다(자리가 3만 개인 자산이 있다).
    SMALL_ASSET = 300

    def _small_asset(self, kind):
        """**전체를 선택해도 보여 줄 만큼 작은가** — 자리 수로 잰다.

        ⚠ 세려고 전부 끌어오면 3만 개짜리에서 화면이 멎는다 —
          **상한+1 까지만** 읽는다.
        """
        cache = getattr(self, '_small_cache', None)
        if cache is None:
            cache = self._small_cache = {}
        if kind in cache:
            return cache[kind]
        try:
            with _db() as conn:
                n = len(AJ.slots(conn, kind, '', limit=self.SMALL_ASSET + 1))
        except Exception:                                 # noqa: BLE001
            n = self.SMALL_ASSET + 1
        cache[kind] = (n <= self.SMALL_ASSET)
        return cache[kind]

    def _fill_units(self):
        """③ 유닛 목록 — **줄마다 있는 언어**를 함께 적는다.

        ★★★ 옛 화면은 언어 현황을 **왼쪽에 표로 따로** 두었다. 사용자 지적
          「대상을 선택하지도 않았는데 언어별 상태를 보여주면 무엇하라는
          것인가」 그대로라 걷고, 이 줄의 한 칸으로 옮겼다.
        ⚠ 「할 일만 보기」는 **거르개일 뿐** — 재료(`slot_rows`)는 거르지
          않는다. 체크를 풀면 그 자리에 무엇이 있는지 다 보인다.
        """
        kind, sc = self._kind(), self._scope_val()
        lang = (self._lang.get() or 'KO').upper()
        base = (self._base.get() or '').upper() or None
        self._sync_tasks(kind, sc, lang)
        task = self._task.get()
        self._todo.delete(*self._todo.get_children())
        self._sizes = {}
        rows, pok = [], (False, '')
        if not sc and AJ.ASSET[kind]['axis'] != 'NONE' and \
                len(self._scope_vals) > 1 and not self._small_asset(kind):
            # ⚠ 전체를 고르면 자리가 3만 개다 — **세부를 먼저** 고르게 한다.
            # ★★★ 다만 **작은 자산은 그냥 보인다**(2026-09-25 사용자 「SHIFT
            #   복수선택이 안 된다」). 잣대는 축 종류가 아니라 **실제 자리
            #   수**다 — 도서 맛보기 조각은 전체가 40개인데 책마다 자리가
            #   하나라, 세부를 고르면 **고를 줄이 하나**여서 Shift 로 잡을
            #   범위 자체가 없었다(실측).
            _bw = getattr(self, '_blocked_why', {}) or {}
            self._why.config(text='② 에서 하나를 선택하면 그 안의 자리가 '
                                  '여기에 보입니다.' + ((' · 못 고르는 업무: ' + ' / '.join(
                                      '%s — %s' % (AJ.TASK_NAME.get(k, k), v) for k, v in _bw.items())) if _bw else ''))
            self._todo_lbl.config(text='③ 어디를')
            self._sel_lbl.config(text='')
            return
        try:
            with _db() as conn:
                rows = AJ.slot_rows(conn, kind, sc, lang=lang, task=task,
                                    base=base, parts=self._picked_parts(kind),
                                    add=[x for x in self._add_mode(kind).split(',') if x])
                self._sizes = AJ.sizes(conn, kind, sc,
                                       base or AJ.base_lang(kind, sc, conn))
                # ★ 프로필이 아니라 **층을 합쳐 보낼 것이 있나**(294차 · 1번 7))
                pok = AJ.has_prompt(conn, kind, sc, task,
                                    (lang or 'KO').upper())
                self._base_cur = base or AJ.base_lang(kind, sc, conn)
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop units] %s' % e)
        only = not bool(self._incl_done.get())
        shown = [r for r in rows if (not only) or r[4] is not False]
        CAP = 500
        for sid, label, gis, langs, td in shown[:CAP]:
            n = self._sizes.get(sid)
            self._todo.insert('', 'end', iid=str(sid),
                              values=(label, gis, langs or '—',
                                      format(n, ',') if n else ''),
                              tags=('todo',) if td else ())
        if len(shown) > CAP:
            self._todo.insert('', 'end', iid='_more',
                              values=('', '… 여기까지만 보입니다 (%s개 더 '
                                          '있습니다)'
                                      % format(len(shown) - CAP, ','), '', ''))
        ntodo = sum(1 for r in rows if r[4])
        _sum = sum(self._sizes.get(r[0], 0) for r in rows if r[4])
        # ★ 「기준 글 N자」 = **할 일로 남은 자리의 기준 언어 글**을 목록을
        #   채우는 이 순간 `sizes` 로 센 것이다(1.txt 1번 9) 물음의 답을 라벨이
        #   스스로 말한다). 보내는 양의 어림이지 받는 글의 길이가 아니다.
        self._todo_lbl.config(
            text='③ 어디를 — 자리 %s개 · 할 일 %s개%s'
                 % (format(len(rows), ','), format(ntodo, ','),
                    (' · 기준 글(%s) %s자 — 목록을 채울 때 잼'
                     % (self._base_cur or base or '?', format(_sum, ',')))
                    if _sum else ''))
        self._why.config(text=self._why_line(kind, sc, task))
        self._cur_prompt = pok
        self._sum_sel()

    def _sync_tasks(self, kind, sc, lang):
        """막힌 업무의 라디오를 끈다 — 외부 자료는 번역만(docs/2.txt 8번).

        ★ 잣대 = `AJ.edit_blocked` 하나(엔진·`create_job`·`todo` 와 같은 문). 여기서 「외부 자료면
          신규 금지」를 다시 적지 않는다 — 두 벌이면 한쪽만 고쳐지는 날이 온다.
        · 고른 업무가 막히면 되는 것 가운데 첫째(번역이 먼저)로 옮긴다 · 까닭은 `_blocked_why` 에 모아
          ③ 아래 설명 줄이 말한다(§0-1 — 눌리지 않는 단추는 왜 그런지 말해야 한다).
        """
        rbs = getattr(self, '_task_rb', None)
        if not rbs:
            return
        why = {}
        try:
            with _db() as conn:
                for code in rbs:
                    w = AJ.edit_blocked(kind, code, lang, sc, conn)
                    if w:
                        why[code] = w.replace('**', '')
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop tasks] %s' % e)
        for code, rb in rbs.items():
            rb.state(['disabled'] if code in why else ['!disabled'])
        self._blocked_why = why
        if self._task.get() in why:
            for code, _n, _w in AJ.TASKS:
                if code not in why:
                    self._task.set(code)
                    self._ml_sync()
                    break

    def _add_mode(self, kind):
        """적재 방식 낱말 — 묶음은 덧붙일 칸 · 연결기는 연결설명문 함께."""
        st = AJ.ASSET.get(kind, {}).get('store')
        out = []
        if st == 'BUNDLE':
            out = [k for k, v in getattr(self, '_add_var', {}).items() if v.get()]
        elif kind == 'VERS_LINK' and getattr(self, '_lk_desc', None) is not None and self._lk_desc.get():
            out = ['LINKDESC']
        return ','.join(out)

    def _picked_parts(self, kind):
        """묶음이면 **체크한 칸**, 아니면 `None`.

        ⚠ 하나도 안 골랐으면 `None` 을 낸다 — `bundle_keys` 가 표 그대로로
          돌아간다(빈 묶음을 보내지 않는다).
        """
        if AJ.ASSET.get(kind, {}).get('store') != 'BUNDLE':
            return None
        ks = [k for k, v in self._pt_var.items() if bool(v.get())]
        return ks or None

    def _why_line(self, kind, sc, task):
        """업무 설명 + 기준 언어에 얽힌 주의 — 화면이 까닭을 말한다(§0-1)."""
        why = dict((t[0], t[2]) for t in AJ.TASKS).get(task, '')
        b = getattr(self, '_base_cur', 'KO')
        tail = ''
        if not getattr(self, '_mine', True):
            tail += '  · 밖에서 들여온 글이라 새로 쓸 일은 없고 옮기는 일만 있습니다'
        try:
            with _db() as conn:
                orig = AJ.base_lang(kind, sc, conn)
        except Exception:                                 # noqa: BLE001
            orig = b
        # ⚠⚠ **중역 경고** — 막지는 않고 말은 한다(§0-1).
        if task == 'TRANS' and b != orig:
            tail += ('  ⚠ %s 는 원본이 아닙니다 — %s 에서 옮긴 글을 다시 '
                     '옮기면 뜻이 두 번 흔들립니다(원본은 %s).' % (b, orig, orig))
        _bw = getattr(self, '_blocked_why', {}) or {}
        if _bw:
            tail += '  · 못 고르는 업무: ' + ' / '.join(
                '%s — %s' % (AJ.TASK_NAME.get(k, k), v) for k, v in _bw.items())
        return '%s%s' % (why.replace('**', ''), tail)

    def _show_prompt(self):
        """[프롬프트 보기] — **누를 때만** 연다(화면이 좁다 · 사용자 지시)."""
        win = tk.Toplevel(self)   # popup-ok: 읽기 전용 보기 창이다
        win.title('프롬프트 보기 — 실제로 보낼 글')
        win.geometry('900x620')
        try:
            UT.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        self._prev = tk.Text(win, wrap='word')
        self._prev.pack(fill='both', expand=True, padx=8, pady=8)
        sel = [i for i in self._todo.selection() if i != '_more']
        first = None
        for i in sel:
            if i.lstrip('-').isdigit():
                first = int(i)
                break
        self._paint_prev(first)
        self._prev.config(state='disabled')

    # ── 고르기 (복수·구간) ──────────────────────────────────────────
    def _rows(self):
        return [i for i in self._todo.get_children() if i != '_more']

    def _pick_all(self):
        rows = self._rows()
        self._todo.selection_set(rows)
        if rows:
            self._todo.see(rows[0])

    def _pick_none(self):
        self._todo.selection_remove(*self._todo.selection())
        self._sum_sel()

    def _pick_first(self):
        try:
            n = max(1, int(self._pick_n.get()))
        except Exception:                                 # noqa: BLE001
            n = 20
        rows = self._rows()[:n]
        self._todo.selection_set(rows)
        if rows:
            self._todo.see(rows[-1])

    def _sum_sel(self):
        """선택한 것의 **합계와 호출 수**를 한 줄로.

        ★ 사용자 물음 「하나의 자료가 너무 크면 인위적으로 분할하는 원칙은
          앱이 자동으로 알아서 하는지」의 답을 화면이 보인다 — **한 자리가
          한도를 넘으면 그 자리는 혼자서도 여러 번**이고, 그 수를 여기 적는다.
        """
        sel = [i for i in self._todo.selection() if i != '_more']
        try:
            cap = max(100, int(self._cap.get()))
        except Exception:                                 # noqa: BLE001
            cap = 6000
        szs = getattr(self, '_sizes', {}) or {}
        tot = sum(szs.get(int(i), 0) for i in sel if i.lstrip('-').isdigit())
        big = [i for i in sel
               if i.lstrip('-').isdigit() and szs.get(int(i), 0) > cap]
        # 묶음 셈 — 한도를 넘는 자리는 **혼자서 나뉜다**, 나머지는 채워 담는다
        calls, cur = 0, 0
        for i in sel:
            n = szs.get(int(i), 0) if i.lstrip('-').isdigit() else 0
            if n > cap:
                calls += -(-n // cap)                     # 올림
                continue
            if cur + n > cap and cur:
                calls += 1
                cur = 0
            cur += n
        if cur:
            calls += 1
        if not sel:
            self._sel_lbl.config(text='선택한 것이 없습니다 — 줄을 누르거나 '
                                      'Shift 를 누른 채 눌러 구간을 선택하세요.')
            return
        # ⚠ **미리보기는 여기서 안 그린다**(2026-09-25 사용자 「프롬프트 :
        #   표시하지 마라. 화면이 좁다」) — [프롬프트 보기] 가 누를 때만 편다.
        msg = ('선택한 것 %s개 · 기준 글 %s자 · 이 한도로 약 %s번 보냅니다'
               % (format(len(sel), ','), format(tot, ','), format(calls, ',')))
        if big:
            msg += '   ⚠ 한도를 넘는 자리 %s개는 나눠 보냅니다' % format(len(big), ',')
        if tot == 0:
            msg = ('선택한 것 %s개 — 기준 글이 아직 없습니다(신규 작성)'
                   % format(len(sel), ','))
        self._sel_lbl.config(text=msg)

    def _make_job(self):
        """선택한 줄로 작업을 만든다 — **건별 줄이 미리 깔린다**."""
        sel = [int(i) for i in self._todo.selection()
               if i != '_more' and i.lstrip('-').isdigit()]
        if not sel:
            messagebox.showinfo('작업 만들기', '먼저 목록에서 줄을 선택하세요.')
            return
        kind, sc = self._kind(), self._scope_val()
        task, lang = self._task.get(), (self._lang.get() or 'KO').upper()
        base = getattr(self, '_base_cur', None)
        # ★ 317차-5 — 자리 이름은 **자리 칸**(values[0])에서 — 옛 판은 내용 칸을 적어
        #   검수 화면 「자리」에 본문 앞 40자가 떴다(docs/1.txt 4-6))
        lbl = {int(i): self._todo.item(i, 'values')[0]
               for i in self._todo.selection() if i != '_more'}
        try:
            cap = max(100, int(self._cap.get()))
        except Exception:                                 # noqa: BLE001
            cap = 6000
        if not messagebox.askyesno(
                '작업 만들기',
                '선택한 %s개로 작업을 만듭니다.\n\n%s · %s · %s → %s\n\n'
                '만들기만 하고 아직 보내지는 않습니다.'
                % (format(len(sel), ','), AJ.ASSET[kind]['name'],
                   AJ.TASK_NAME[task], base, lang)):
            return
        langs = [lang] + self.extra_langs()
        jids, n = [], 0
        try:
            with _db() as conn:
                for _lg in langs:
                    jid, n = AR.create_job(
                        conn, kind, sc, task, _lg,
                        [(s, lbl.get(s, '')) for s in sel], base=base, cap=cap,
                        parts=self._picked_parts(kind), add_mode=self._add_mode(kind))
                    jids.append(jid)
        except Exception as e:                            # noqa: BLE001
            messagebox.showerror('작업 만들기', '못 만들었습니다: %s%s' % (
                e, ('\n(먼저 만든 작업 %s 은 남아 있습니다)' % jids) if jids else ''))
            if not jids:
                return
        jid = jids[0]
        self._nb.select(self.TAB['review'])
        self._rv_reload(select=jid)
        if len(jids) > 1:
            # ★★★ 여러 언어 — 자리마다 모든 언어를 차례로(사용자가 적은 차례).
            if messagebox.askyesno(
                    '작업 만들기',
                    '작업 %d개를 만들었습니다 (%s · 자리 %d개 · %d건).\n\n'
                    '지금 바로 **자리마다 언어를 차례로** 보낼까요?\n'
                    '(아니오 = 「승인 및 검수」에서 작업마다 따로 보냅니다)'
                    % (len(jids), '·'.join(langs), n, n * len(jids))):
                self.after(200, lambda: self._rv_start_multi(jids))
            return
        messagebox.showinfo('작업 만들기',
                            '작업 #%d 을 만들었습니다 (%d건).\n'
                            '「승인 및 검수」 탭에서 [돌리기] 를 누르세요.' % (jid, n))

    # ══════════════════════════════════════════════════════════════
    #  탭 3 — 검수
    # ══════════════════════════════════════════════════════════════
    def _build_review(self, root):
        """작업 목록 | 건별 목록 | 글 — **주 단추는 제 자리에**.

        ⚠⚠⚠ 옛 띠는 `작업 콤보(54칸) · 한 번에 [5] · 건 돌리기 · 중지 ·
          승인 · 고쳐서 승인 · 반려 · 승인분 적재` 여덟이 한 줄에 있었고,
          **API 를 부르는 [건 돌리기] 가 세 번째**, **마지막 목적지인
          [승인분 적재] 가 여섯 번째**였다(사용자 「엄청 중요한 버튼조차
          숨기듯이 배치해서 너무 싫다」).
        """
        self._rv_th = None          # 도는 일꾼(없으면 None)
        self._rv_stop_flag = False
        bar = ttk.Frame(root)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        # ── 주 단추 셋 — 흐름 차례대로 · 각자 눈에 띄게 ─────────────
        self._rv_go = tk.Button(bar, text='전송하기', width=12,
                                command=self._rv_run, **UT.focus_kw())
        self._rv_go.pack(side='left')
        # ★★ 2026-10-30 **맡기기(Batch · 반값)** — 사용자 결정 「Pro low + Batch」. 결과는 몇 분~24시간 뒤 · 하루 한도와 따로
        self._bt_go = tk.Button(bar, text='Batch 전송', width=12, command=self._bt_submit, **UT.focus_kw())
        self._bt_go.pack(side='left', padx=(4, 0))
        # ★ **중지** — 무료 등급은 하루 한도가 있어 **중단이 기본 상정**이다
        #   (§257차 ⑬). 돌 때만 눌린다.
        self._rv_stop_btn = ttk.Button(bar, text='중지',
                                       command=self._rv_stop, state='disabled')
        self._rv_stop_btn.pack(side='left', padx=(4, 12))
        ttk.Separator(bar, orient='vertical').pack(side='left', fill='y',
                                                   padx=(0, 12))
        self._rv_ok = tk.Button(bar, text='승인', width=10,
                                command=lambda: self._rv_judge('OK'),
                                **UT.focus_kw(restore=True))
        self._rv_ok.pack(side='left')
        ttk.Button(bar, text='반려',
                   command=lambda: self._rv_judge('REJ')).pack(side='left',
                                                               padx=4)
        # ★★★ **반려 사유**(2026-09-29 294차 · 1.txt 1번 3)·4)) — 예제 프롬프트와
        #   새 게이트의 재료가 여기서 쌓인다. 실측 반려 16건 전부 사유가 비어
        #   「무엇이 싫었나」를 되짚을 길이 없었다. ⚠ 팝업이 아니라 띠의 칸이다.
        ttk.Label(bar, text='반려 사유').pack(side='left', padx=(2, 2))
        self._rv_why = ttk.Entry(bar, width=26)
        self._rv_why.pack(side='left')
        ttk.Separator(bar, orient='vertical').pack(side='left', fill='y',
                                                   padx=12)
        self._rv_load_btn = tk.Button(bar, text='승인분 적재', width=12,
                                      command=self._rv_load, **UT.focus_kw())
        self._rv_load_btn.pack(side='left')
        build_help_button(bar, 'AI 작성·번역 — 사용방법',
                          HELP_SECTIONS).pack(side='right', padx=4)
        # ⚠ **[다시 읽기] 를 걷었다**(사용자 물음 「다시 : 무엇인가?」) —
        #   DB 를 다시 읽어 목록을 새로 그리는 것뿐이고, 탭을 옮길 때·
        #   판정할 때·적재할 때 **이미 저절로** 다시 읽는다.

        # ★★ 2026-10-30 맡긴 일 한 줄 — 상태 · [지금 확인] · [맡김 취소] · 열려 있는 동안 5분마다 저절로 확인
        btb = ttk.Frame(root)
        btb.pack(fill='x', padx=8, pady=(0, 2))
        ttk.Button(btb, text='지금 확인', command=lambda: self._bt_poll(manual=True)).pack(side='left')
        ttk.Button(btb, text='Batch 취소', command=self._bt_cancel).pack(side='left', padx=(4, 8))
        self._bt_lbl = ttk.Label(btb, text='Batch 작업 —', foreground=UT.C('accent') or '#1A5276')
        self._bt_lbl.pack(side='left')
        self._bt_th = None
        self.after(3000, self._bt_tick)

        self._rv_sum = ttk.Label(root, text='', foreground='#1A5276')
        self._rv_sum.pack(fill='x', padx=8, pady=(0, 2))

        pw = ttk.PanedWindow(root, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=(0, 6))

        # ── ① 작업 목록 — **콤보가 아니라 목록**(사용자 지시) ────────
        jf = ttk.Frame(pw)
        pw.add(jf, weight=1)
        ttk.Label(jf, text='작업', font=('', 10, 'bold')).pack(anchor='w',
                                                              padx=4)
        self._rv_job = ttk.Treeview(jf, columns=('name', 'n', 'left'),
                                    show='headings', selectmode='browse')
        for k, t, w, an in (('name', '작업', 200, 'w'), ('n', '건', 50, 'e'),
                            ('left', '남음', 60, 'e')):
            self._rv_job.heading(k, text=t)
            self._rv_job.column(k, width=w, anchor=an,
                                stretch=(k == 'name'))
        jsb = ttk.Scrollbar(jf, orient='vertical', command=self._rv_job.yview)
        self._rv_job.configure(yscrollcommand=jsb.set)
        jsb.pack(side='right', fill='y')
        self._rv_job.pack(fill='both', expand=True, padx=(4, 0))
        self._rv_job.bind('<<TreeviewSelect>>', lambda _e: self._rv_fill())

        # ── ② 건별 ────────────────────────────────────────────────
        left = ttk.Frame(pw)
        pw.add(left, weight=1)
        ttk.Label(left, text='건별 — 선택한 것만 보냅니다',
                  font=('', 10, 'bold')).pack(anchor='w', padx=4)
        # ★ 317차-5 — [전체/통과/걸림/오류] 거르개 · 걸린 것 따로 고르기 · 게이트 반영 다시 쓰기
        fr = ttk.Frame(left)
        fr.pack(fill='x', padx=4, pady=(0, 2))
        self._rv_filter = 'ALL'
        self._rv_fbtn = {}
        # ★ 2026-10-30 「원문 의심」 — 번역하며 AI 가 원문에서 본 흠이 있는 건만(고치지 않고 지적만 받았다)
        for k, t in (('ALL', '전체'), ('PASS', '통과'), ('FAIL_G', '걸림'), ('ERR', '오류'), ('SRC', '원문 의심')):
            b = tk.Button(fr, text=t, width=5 if k != 'SRC' else 9, command=lambda k=k: self._rv_set_filter(k),
                          **(UT.focus_kw() if k == 'ALL' else UT.flat_btn()))
            b.pack(side='left', padx=(0, 2))
            self._rv_fbtn[k] = b
        fa = ttk.Frame(left)
        fa.pack(fill='x', padx=4, pady=(0, 2))
        # ★ 2026-10-30 이름을 짧게(사용자) — 「모두 선택」 = 지금 보이는 줄 전부(걸린 것만은 [걸림] 거르개 뒤 [모두 선택])
        ttk.Button(fa, text='모두 선택', command=self._rv_pick_all).pack(side='left')
        ttk.Button(fa, text='다시 쓰기', command=self._rv_fix).pack(side='left', padx=4)
        ttk.Button(fa, text='번호 복사', command=self._rv_copy_ids).pack(side='left')
        # ★ 2026-10-30 오류 찾기(docs/1.txt 7-2) — 재료와 받은 글만 보내 **오류만** 찾게 한다(고치지 않는다)
        self._ck_btn = ttk.Button(fa, text='오류 찾기', command=self._ck_start)
        self._ck_btn.pack(side='left', padx=(12, 0))
        ttk.Button(fa, text='오류 찾기 Batch', command=self._ck_batch).pack(side='left', padx=(4, 0))
        # ★ 2026-10-30 사용자 「하나씩 눌러 살펴보고 타당하면 범위선택해서 한꺼번에」 — 줄 빼기는 건마다, 적용은 여기서 여러 건을
        self._fx_btn = ttk.Button(fa, text='오류 수정', command=self._fx_start)
        self._fx_btn.pack(side='left', padx=(4, 0))
        # ★ 2026-10-30 오류 찾기만의 진행 줄 — 전송이 함께 돌면 공용 줄(_rv_sum)을 덮어 「멈춘 것처럼」 보였다(사용자)
        self._ck_stat = ttk.Label(fa, text='', foreground=UT.C('accent') or '#1A5276')
        self._ck_stat.pack(side='left', padx=(6, 0))
        self._rv_tv = ttk.Treeview(left, columns=('slot', 'st', 'g', 'ck', 'ow'),
                                   show='headings', selectmode='extended')
        # ★ 317차-19 (42-2) — 「덮어씀」 = 적재하면 지금 글을 덮는 칸(눌러 보면 칸마다 비교 · 「지금 글 유지」)
        for k, t, w in (('slot', '자리', 130), ('st', '상태', 80),
                        ('g', '게이트', 70), ('ck', '오류', 60), ('ow', '덮어씀', 110)):
            self._rv_tv.heading(k, text=t)
            self._rv_tv.column(k, width=w, anchor='w')
        sb = ttk.Scrollbar(left, orient='vertical', command=self._rv_tv.yview)
        self._rv_tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._rv_tv.pack(fill='both', expand=True, padx=(4, 0))
        self._rv_tv.bind('<<TreeviewSelect>>', lambda _e: self._rv_on_sel())
        # ★ 2026-10-30 Shift 범위의 기준 = Tk 의 focus 줄인데 **Ctrl 누름은 focus 를 안 옮긴다**(ttk treeview.tcl) —
        #   Ctrl 로 고른 뒤 Shift 를 누르면 엉뚱한 줄부터 범위가 잡혔다. 윈도우 탐색기처럼 Ctrl 로 누른 줄이 기준이 된다.
        self._rv_tv.bind('<Control-Button-1>', self._rv_ctrl_focus, add='+')

        # ── ③ 글 ──────────────────────────────────────────────────
        # ★ 2026-10-30 사용자 「오른쪽 화면 중간 상하 리사이즈 안된다」 — ttk 사시는 가늘어 잡히지 않고 칸 요구 높이에 막혔다
        #   ⇒ tk 사시(굵게 · 최소 높이) · 칸 셋(재료 / 받은 글 / 게이트·오류 찾기)
        right = tk.PanedWindow(pw, orient='vertical', sashwidth=8, sashrelief='raised', bd=0,
                               bg=UT.C('border') or '#C8CDD3')
        pw.add(right, weight=2)
        a = ttk.Frame(right)
        right.add(a, minsize=70, stretch='always')
        self._rv_right = right
        # ★ **왼쪽이 참고, 오른쪽이 편집**(§275차 ⑥ 자리 규칙) — 여기서는
        #   위가 참고(재료·원본), 아래가 편집(받은 글)이다.
        # ★ 글자는 `_rv_show` 가 갈아 끼운다 — 이미 있는 자리면
        #   「지금 있는 글도 함께」라고 적어 **덮어쓴다는 사실**을 먼저 말한다.
        _hr = ttk.Frame(a)
        _hr.pack(fill='x')
        self._rv_src_lbl = ttk.Label(_hr, text='재료 · 원본 (참고)',
                                     font=('', 9, 'bold'))
        self._rv_src_lbl.pack(side='left', anchor='w')
        # ★ 2026-10-13 (사용자 「AI 에게 보내는 모든 자료가 관리자의 눈에 전부 다 보여지는지」) —
        #   이 칸은 재료만 보였다. **실제로 보낸 글 전부**(역할·반드시·금지·재료·다시 쓰기 · 글자 그대로)를 본다.
        self._rv_view = 'REF'
        self._rv_view_b = ttk.Button(_hr, text='보낸 글 전체', command=self._rv_toggle_view)
        self._rv_view_b.pack(side='right')
        self._rv_src = tk.Text(a, wrap='word', height=10)
        self._rv_src.pack(fill='both', expand=True)
        b = ttk.Frame(right)
        right.add(b, minsize=90, stretch='always')
        c = ttk.Frame(right)
        right.add(c, minsize=50, stretch='always')
        self._rv_lbl = ttk.Label(b, text='받은 글 — 고치고 [승인] 하면 '
                                         '고친 글로 담깁니다',
                                 font=('', 9, 'bold'))
        self._rv_lbl.pack(anchor='w')
        # ★ 317차-5 (docs/1.txt 4-2)) — 구절묶음: **지금 글을 남길 칸**을 고른다(덮어쓰기 전 비교)
        self._rv_keep_f = ttk.Frame(b)
        self._rv_keep = {}
        self._rv_out = tk.Text(b, wrap='word', height=6, undo=True)
        self._rv_out.pack(fill='both', expand=True)
        self._rv_gate = tk.Text(c, wrap='word', height=3)
        self._rv_gate.pack(fill='both', expand=True)
        # ★ 2026-10-30 오류 찾기 결과 — 줄을 선택해 [선택한 수정 적용](단추는 위) · 줄을 누르면 받은 글에서 그 자리를 밝힌다
        self._ck_f = ttk.Frame(c)
        _ch = ttk.Frame(self._ck_f)
        _ch.pack(fill='x')
        self._ck_lbl = ttk.Label(_ch, text='오류 찾기 결과', font=('', 9, 'bold'))
        self._ck_lbl.pack(side='left')
        # 고치지 않을 줄은 빼 둔다(두 번 눌러도 된다) — 고치는 것은 가운데 [오류 수정]이 선택한 건들을 한꺼번에
        ttk.Button(_ch, text='빼기 / 되살리기', command=self._ck_skip).pack(side='right')
        self._ck_tv = ttk.Treeview(self._ck_f, columns=('k', 'w', 'f', 'why'), show='headings',
                                   selectmode='extended', height=4)
        for k, t, w in (('k', '종류', 54), ('w', '틀린 글자', 180), ('f', '고칠 글', 180), ('why', '왜', 260)):
            self._ck_tv.heading(k, text=t)
            self._ck_tv.column(k, width=w, anchor='w', stretch=(k == 'why'))
        self._ck_tv.tag_configure('done', foreground=UT.C('fg_dim') or '#7F8C8D')
        self._ck_tv.tag_configure('skip', foreground=UT.C('fg_dim') or '#7F8C8D')
        self._ck_tv.bind('<Double-1>', lambda _e: self._ck_skip())
        self._ck_tv.pack(fill='x')
        # ★ 2026-10-30 사용자 「클릭해도 세부내용을 알길이 없다」 — 칸이 좁아 잘린 글 전부 · 받은 글의 앞뒤 문맥
        self._ck_det = tk.Text(self._ck_f, wrap='word', height=5, relief='flat',
                               bg=UT.C('bg') or '#F4F6F7')
        self._ck_det.pack(fill='both', expand=True, pady=(2, 0))
        self._ck_det.tag_configure('h', font=('', 9, 'bold'))
        self._ck_det.tag_configure('hit', background=UT.C('warning_bg') or '#FDEBD0')
        self._ck_tv.bind('<<TreeviewSelect>>', lambda _e: self._ck_mark())

    def _rv_reload(self, select=None):
        try:
            with _db() as conn:
                rows = AR.jobs(conn)
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop jobs] %s' % e)
            rows = []
        self._rv_jobs = rows
        self._rv_job.delete(*self._rv_job.get_children())
        for r in rows:
            self._rv_job.insert('', 'end', iid=str(r[0]),
                                values=('#%s  %s' % (r[0], r[1]), r[3], r[4]))
        if rows:
            want = str(select) if select is not None else str(rows[0][0])
            if not self._rv_job.exists(want):
                want = str(rows[0][0])
            self._rv_job.selection_set(want)
            self._rv_job.see(want)
        self._rv_fill()

    def _rv_jid(self):
        sel = self._rv_job.selection()
        if not sel:
            return None
        try:
            return int(sel[0])
        except Exception:                                 # noqa: BLE001
            return None

    def _rv_on_sel(self):
        if tuple(self._rv_tv.selection()) == getattr(self, '_rv_quiet', None):
            self._rv_quiet = None            # 다시 그린 뒤 되살린 선택 — 오른쪽을 또 읽지 않는다
            return
        self._rv_quiet = None
        self._rv_show()

    def _rv_ctrl_focus(self, e):
        row = self._rv_tv.identify_row(e.y)
        if row:
            self.after_idle(lambda: self._rv_tv.focus(row) if self._rv_tv.exists(row) else None)

    def _rv_pick_all(self):
        rows = list(self._rv_tv.get_children())
        self._rv_tv.selection_set(rows)
        if rows:
            self._rv_tv.focus(rows[0])
        self._rv_sum.config(text='보이는 %d건을 모두 선택했습니다 — 걸린 것만 고르려면 먼저 [걸림] 을 누르세요.' % len(rows))

    def _rv_fill(self):
        # ★ 2026-10-30 **선택과 기준 줄(focus)을 지킨다** — 보내는 동안 받은 건마다 목록을 다시 그려(_rv_pump)
        #   선택이 풀리고 Shift 의 기준 줄이 사라졌다(사용자 「범위선택 안되고 모두 전송」)
        _keep = [i for i in self._rv_tv.selection()]
        _kf = self._rv_tv.focus()
        _ky = self._rv_tv.yview()[0] if self._rv_tv.get_children() else 0.0
        self._rv_tv.delete(*self._rv_tv.get_children())
        jid = self._rv_jid()
        if jid is None:
            self._rv_sum.config(text='아직 작업이 없습니다 — '
                                     '「작업 선택하기」 탭에서 만드세요.')
            return
        import json as _j
        with _db() as conn:
            c = AR.counts(conn, jid)
            rows = AR.items(conn, jid)
            j = AR.job(conn, jid)
        self._rv_j = j
        _flt = getattr(self, '_rv_filter', 'ALL')
        with _db() as conn:
            _names = {sid: AR.slot_title(conn, j['asset_kind'], sid, label)
                      for _i, sid, label, *_r in rows} if j else {}
            try:
                _ow = AR.overwrite_map(conn, j, [r_[1] for r_ in rows]) if j else {}
            except Exception as e:                        # noqa: BLE001
                print('[ai_workshop ow] %s' % e)
                _ow = {}
        _ck = {}
        try:
            with _db() as conn:
                AR._ensure_check(conn)
                for _iid, _cj in conn.execute("SELECT item_id, check_json FROM sys_ai_item"
                                              " WHERE job_id=? AND check_json IS NOT NULL", (jid,)):
                    _ck[_iid] = self._ck_count(_j.loads(_cj))
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop ck] %s' % e)
        _src = set()
        try:
            with _db() as conn:
                AR.ensure(conn)
                _src = {x[0] for x in conn.execute("SELECT item_id FROM sys_ai_item WHERE job_id=?"
                                                   " AND COALESCE(src_note,'')<>''", (jid,))}
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop src] %s' % e)
        for iid, sid, label, st, _out, why, gj, _ni, _no, _at in rows:
            g = ''
            if gj:
                try:
                    g = {True: '통과', False: '걸림', None: '없음'}.get(
                        _j.loads(gj).get('ok'), '')
                except Exception:                         # noqa: BLE001
                    g = ''
            if (_flt == 'PASS' and g != '통과') or (_flt == 'FAIL_G' and g != '걸림') or \
                    (_flt == 'ERR' and st != 'FAIL') or (_flt == 'SRC' and iid not in _src):
                continue
            if iid in _src:
                g = (g + ' · 원문 의심') if g else '원문 의심'
            self._rv_tv.insert('', 'end', iid=str(iid),
                               values=(_names.get(sid) or label or sid,
                                       AR.STATE_NAME.get(st, st) +
                                       (' · ' + why[:24] if why else ''), g, _ck.get(iid, ''),
                                       '·'.join(_ow.get(int(sid), [])) if st != 'LOADED' else ''))
        self._rv_sum.config(
            text='  ·  '.join('%s %s' % (AR.STATE_NAME[s], c[s])
                              for s in AR.STATES if c[s]) or '건이 없습니다')
        _back = [i for i in _keep if self._rv_tv.exists(i)]
        if _back:
            self._rv_quiet = tuple(i for i in self._rv_tv.get_children() if i in set(_back))
            self._rv_tv.selection_set(_back)
        if _kf and self._rv_tv.exists(_kf):
            self._rv_tv.focus(_kf)
        if _keep:
            self._rv_tv.yview_moveto(_ky)

    def _rv_set_filter(self, k):
        self._rv_filter = k
        for kk, b in self._rv_fbtn.items():
            b.configure(**(UT.focus_kw() if kk == k else UT.flat_btn()))
        self._rv_fill()

    def _rv_pick_failed(self):
        """걸린 것(게이트 걸림)을 모두 선택한다 — 거르개도 「걸림」으로."""
        jid = self._rv_jid()
        if jid is None:
            return
        self._rv_set_filter('FAIL_G')
        with _db() as conn:
            ids = AR.gate_failed(conn, jid)
        have = set(self._rv_tv.get_children())
        sel = [str(i) for i in ids if str(i) in have]
        self._rv_tv.selection_set(sel)
        self._rv_sum.config(text='게이트에 걸린 %d건을 골랐습니다 — [게이트 반영 다시 쓰기(AI)] 로 AI 에게 맡기거나, '
                                 '[선택한 번호 복사] 로 번호를 넘겨 손으로 처리합니다.' % len(sel))

    def _rv_fix(self):
        """선택한 건을 게이트 반영 다시 쓰기로 — 앞 글 + 걸린 것을 주고 **그것만** 고쳐 오게 한다."""
        ids = self._rv_sel()
        jid = self._rv_jid()
        if not ids or jid is None:
            messagebox.showinfo('게이트 반영', '먼저 건을 선택하세요(「걸린 것 모두 선택하기」).')
            return
        with _db() as conn:
            sent, skip = AR.mark_fix(conn, ids)
        if not sent:
            messagebox.showinfo('게이트 반영', '맡길 건이 없습니다 — 받은 글이 없거나 이미 %d번 고쳤습니다(그 뒤는 사람이 봅니다).'
                                % AR.FIX_MAX)
            return
        self._rv_fill()
        if skip:
            self._rv_sum.config(text='%d건은 건너뜀(받은 글 없음 · %d번 넘게 고침)' % (len(skip), AR.FIX_MAX))
        self._rv_start(jid, len(sent), only=sent)

    def _rv_copy_ids(self):
        ids = self._rv_sel()
        jid = self._rv_jid()
        if not ids:
            return
        txt = '작업 %s · 건 %s' % (jid, ','.join(str(i) for i in ids))
        self.clipboard_clear()
        self.clipboard_append(txt)
        self._rv_sum.config(text='복사했습니다 — %s' % txt[:80])

    def _rv_sel_range(self, ids):
        """선택한 건이 목록의 몇 번째부터 몇 번째인가 — 보내기 전에 「모두」가 아닌지 눈으로 본다"""
        kids = list(self._rv_tv.get_children())
        pos = sorted(kids.index(str(i)) + 1 for i in ids if str(i) in kids)
        if not pos:
            return ''
        return '목록 %d~%d번째 · 전체 %d건 중' % (pos[0], pos[-1], len(kids)) if len(pos) > 1 else '목록 %d번째' % pos[0]

    def _rv_sel(self):
        return [int(i) for i in self._rv_tv.selection()]

    def _rv_toggle_view(self):
        self._rv_view = 'SENT' if self._rv_view == 'REF' else 'REF'
        self._rv_view_b.config(text='재료 · 지금 글' if self._rv_view == 'SENT' else '보낸 글 전체')
        self._rv_show()

    def _rv_sent_text(self, item_id):
        """그 건에 **실제로 보낸 글** — 기록이 있으면 그것(글자 그대로), 없으면 지금 보낸다면 나갈 글."""
        import ai_sent_log as SL
        jid = self._rv_jid()
        ids = SL.for_item(item_id)
        if ids:
            g = SL.get(ids[0])
            head = ('[실제로 보낸 글 — 기록 #%d · %s · %s · %d자 · 이 건에 보낸 횟수 %d · %s]'
                    % (g['sent_id'], g['ts'], g['model'], len(g['prompt'] or ''), len(ids),
                       '받음' if g['ok'] else '못 받음: %s' % (g['why'] or '')))
            return head + chr(10) + chr(10) + (g['prompt'] or '')
        with _db() as conn:
            txt, _ctx = AR.build_item_prompt(conn, jid, item_id)
        return ('[보낸 기록이 없습니다 — 기록을 시작하기(2026-10-13) 전에 보냈거나 아직 안 보낸 건입니다. '
                '아래는 지금 보낸다면 나갈 글입니다]' + chr(10) + chr(10) + txt)

    def _rv_show(self):
        ids = self._rv_sel()
        self._rv_src.config(state='normal')
        self._rv_out.config(state='normal')
        self._rv_gate.config(state='normal')
        for w in (self._rv_src, self._rv_out, self._rv_gate):
            w.delete('1.0', 'end')
        if not ids:
            self._rv_gate.config(state='disabled')
            return
        import json as _j
        jid = self._rv_jid()
        with _db() as conn:
            r = conn.execute(
                "SELECT slot_id, out_text, why, gate_json, COALESCE(src_note,'') FROM sys_ai_item "
                "WHERE item_id=?", (ids[0],)).fetchone()
            j = AR.job(conn, jid)
            ctx = {}
            if r:
                try:
                    ctx = AJ.material(conn, j['asset_kind'], r[0], j['task'],
                                      base=j['base_lang'], lang=j['lang'],
                                      scope=j['scope_value'])
                except Exception as e:                    # noqa: BLE001
                    ctx = {'⚠': str(e)}
        if not r:
            self._rv_gate.config(state='disabled')
            return
        if r[4]:
            # ★ 2026-10-30 원문 의심 — 번역 글은 원문 그대로이고, 원문의 흠은 여기 지적만 있다(고치는 것은 사람)
            self._rv_gate.insert('end', '원문 의심 (번역은 원문 그대로 · 원문을 볼 것):' + chr(10) +
                                 chr(10).join('  · ' + x for x in r[4].split(chr(10))) + chr(10) + chr(10))
        if getattr(self, '_rv_view', 'REF') == 'SENT':
            try:
                self._rv_src.insert('end', self._rv_sent_text(ids[0]))
            except Exception as e:                        # noqa: BLE001
                self._rv_src.insert('end', '보낸 글을 못 읽었습니다: %s' % e)
            self._rv_src_lbl.config(text='AI 에게 보낸 글 전체 (글자 그대로)')
            self._rv_out.insert('end', r[1] or '')
            self._rv_out_orig = r[1] or ''
            if r[3]:
                try:
                    g = _j.loads(r[3])
                    self._rv_gate.insert('end', '게이트: %s%s%s' % (
                        {True: '통과', False: '걸림', None: '없음'}.get(g.get('ok')), chr(10),
                        chr(10).join(g.get('lines') or [])))
                except Exception:                         # noqa: BLE001
                    pass
            self._rv_src.config(state='disabled')
            self._rv_gate.config(state='disabled')
            return
        # ★★★ **지금 있는 글을 맨 위에**(2026-09-25) — 다시 쓰기·다시 번역은
        #   옛 글과 견주어야 판단한다. 없으면 이 덩이를 아예 안 그린다(§0-1).
        _cur, _who = '', ''
        try:
            with _db() as _c2:
                _cur = AJ.current_text(_c2, j['asset_kind'], r[0], j['lang'])
                if _cur:
                    # ★ **누구 글을 덮는가** — 목록에서 봤더라도 누르는 자리에서
                    #   다시 말한다. 둘 다 적는다(빈칸이면 「모름」과 안 갈린다).
                    _al = AJ.ai_loaded(_c2, j['asset_kind'])
                    _who = ('AI 적재분'
                            if str(j['lang']).upper()
                            in _al.get(int(r[0]), set()) else '사람이 쓴 글')
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop cur] %s' % e)
        # ★★★ 317차-5 — 구절묶음은 **칸마다** 지금 글과 새 글을 나란히(docs/1.txt 4-2))
        for _w in self._rv_keep_f.winfo_children():
            _w.destroy()
        self._rv_keep = {}
        self._rv_keep_f.pack_forget()
        _cmp = []
        if AJ.ASSET.get(j['asset_kind'], {}).get('store') == 'BUNDLE':
            try:
                with _db() as _c3:
                    _cmp = AR.bundle_compare(_c3, j, r[0], r[1] or '')
                    _held = (_c3.execute("SELECT COALESCE(keep_parts,'') FROM sys_ai_item WHERE item_id=?",
                                         (ids[0],)).fetchone() or [''])[0].split(',')
            except Exception as e:                        # noqa: BLE001
                print('[ai_workshop cmp] %s' % e)
                _cmp, _held = [], []
        if _cmp:
            _cur = ''                    # 칸별 비교가 대신 보인다
            self._rv_src.tag_configure('cmph', font=('', 9, 'bold'))
            for k, nm, now, new, act in _cmp:
                self._rv_src.insert('end', '━━ %s — %s (%s)%s' % (nm, act, _who or '지금 글', chr(10)), 'cmph')
                self._rv_src.insert('end', '[지금 글]%s%s%s' % (chr(10), now.strip() or '(없음)', chr(10)))
                self._rv_src.insert('end', '[새 글]%s%s%s%s' % (chr(10), new.strip() or '(없음)', chr(10), chr(10)))
            _ow = [(k, nm) for k, nm, now, new, act in _cmp if act == '덮어씀']
            if _ow:
                ttk.Label(self._rv_keep_f, text='지금 글 유지(이 칸은 덮어쓰지 않음):').pack(side='left')
                for k, nm in _ow:
                    v = tk.BooleanVar(value=(k in _held))
                    self._rv_keep[k] = v
                    ttk.Checkbutton(self._rv_keep_f, text=nm, variable=v).pack(side='left', padx=(4, 0))
                self._rv_keep_f.pack(fill='x', before=self._rv_out)
        if _cur:
            self._rv_src.insert(
                'end', '[지금 있는 글 (%s) · %s — 적재하면 이 글을 '
                       '덮어씁니다]%s%s%s%s'
                       % (j['lang'], _who, chr(10), _cur, chr(10), chr(10)))
        self._rv_src_lbl.config(
            text='칸마다 지금 글 ↔ 새 글 · 재료 (참고)' if _cmp else
                 ('지금 있는 글 · 재료 · 원본 (참고)' if _cur else '재료 · 원본 (참고)'))
        # ★ 296차(1.txt 2번 4)) — 다듬기는 「지금 있는 글」과 재료의 「지금 글」이
        #   **같은 글**이라 두 번 떴다(사용자 「스펄전 KO 를 2번 복사해서 보내는 것
        #   같다」). AI 에게는 원래 한 번만 실린다 — 화면에서만 재료 쪽을 뺀다.
        self._rv_src.insert('end', chr(10).join(
            '[%s]%s%s' % (k, chr(10), v) for k, v in ctx.items()
            if not (_cur and str(k).startswith('지금 글'))))
        self._rv_out.insert('end', r[1] or '')
        # ★ **받은 글 그대로를 기억한다** — [승인] 이 「고친 글인가」를
        #   이것과 견주어 가른다(승인/고쳐서 승인을 하나로 합친 자리).
        self._rv_out_orig = r[1] or ''
        self._rv_lbl.config(text='받은 글 (고칠 수 있습니다)%s'
                                 % ('   ⚠ ' + r[2] if r[2] else ''))
        if r[3]:
            try:
                g = _j.loads(r[3])
                self._rv_gate.insert(
                    'end', '게이트: %s%s%s'
                    % ({True: '통과', False: '걸림', None: '없음'}.get(g.get('ok')),
                       chr(10), chr(10).join(g.get('lines') or [])))
            except Exception:                             # noqa: BLE001
                pass
        self._rv_src.config(state='disabled')
        self._rv_gate.config(state='disabled')
        self._ck_fill(ids[0])

    # ── 오류 찾기 (2026-10-30 · docs/1.txt 7-2) ───────────────────────
    #  찾는 AI(유료 Pro)는 **찾기만** 한다 · 고치는 것은 사람이 고른 줄만 — 한 번 나오는 글자는 기계가,
    #  여러 번 나오는 것은 다른 AI 가 그 자리만(`db_ai_run.apply_fixes`).
    def _ck_fill(self, item_id):
        self._ck_tv.delete(*self._ck_tv.get_children())
        self._ck_item = item_id
        try:
            with _db() as conn:
                chk = AR.check_of(conn, item_id)
        except Exception:                                 # noqa: BLE001
            chk = None
        if not chk:
            self._ck_f.pack_forget()
            return
        found = chk.get('found') or []
        for i, f in enumerate(found):
            tg = ('done',) if f.get('done') else (('skip',) if f.get('skip') else ())
            self._ck_tv.insert('', 'end', iid=str(i), tags=tg,
                               values=(f['kind'] + (' ✓고침' if f.get('done') else (' ✗뺌' if f.get('skip') else '')),
                                       f['wrong'], f['fix'], f['why']))
        self._ck_lbl.config(text='오류 찾기 결과 — %s · %s · %d건%s' % (
            chk.get('model', ''), (chk.get('at') or '')[5:16].replace('T', ' '), len(found),
            (' (받은 글에 없는 지적 %d건은 버림)' % chk['dropped']) if chk.get('dropped') else '')
            + ' · 고치지 않을 줄은 두 번 눌러 빼고, 가운데 [오류 수정]으로 고칩니다'
            if found else '오류 찾기 결과 — 0건 · 중요한 오류 없음 (%s · %s)' % (
                chk.get('model', ''), (chk.get('at') or '')[5:16].replace('T', ' ')))
        self._ck_f.pack(fill='both', expand=True, pady=(4, 0))
        self._ck_detail()

    def _ck_mark(self):
        self._ck_detail()
        self._rv_out.tag_remove('ckhit', '1.0', 'end')
        self._rv_out.tag_configure('ckhit', background=UT.C('warning_bg') or '#FDEBD0')
        first = None
        for i in self._ck_tv.selection():
            w = self._ck_tv.set(i, 'w')
            pos = '1.0'
            while w:
                pos = self._rv_out.search(w, pos, stopindex='end')
                if not pos:
                    break
                end = '%s+%dc' % (pos, len(w))
                self._rv_out.tag_add('ckhit', pos, end)
                first = first or pos
                pos = end
        if first:
            self._rv_out.see(first)

    def _ck_detail(self):
        d = self._ck_det
        d.config(state='normal')
        d.delete('1.0', 'end')
        body = self._rv_out.get('1.0', 'end-1c')
        for i in self._ck_tv.selection():
            k, w, f, why = (self._ck_tv.set(i, c_) for c_ in ('k', 'w', 'f', 'why'))
            d.insert('end', '%s  ' % k, 'h')
            d.insert('end', '「%s」 → 「%s」%s' % (w, f, chr(10)))
            d.insert('end', '왜: %s%s' % (why, chr(10)))
            p = body.find(w)
            if p >= 0:
                a_, b_ = max(0, p - 60), min(len(body), p + len(w) + 60)
                d.insert('end', '문맥: …' + body[a_:p].replace(chr(10), ' '))
                d.insert('end', w, 'hit')
                d.insert('end', body[p + len(w):b_].replace(chr(10), ' ') + '…' + chr(10))
            elif '✓' in k:
                d.insert('end', '문맥: (이미 고쳤습니다)' + chr(10))
            d.insert('end', chr(10))
        if not self._ck_tv.selection():
            d.insert('end', '줄을 누르면 여기에 틀린 글자 · 고칠 글 · 까닭 · 앞뒤 문맥이 나옵니다.')
        d.config(state='disabled')

    def _ck_start(self):
        import queue
        import threading
        ids = self._rv_sel()
        if not ids:
            messagebox.showinfo('오류 찾기', '먼저 건을 선택하세요.')
            return
        if getattr(self, '_ck_th', None) is not None:
            messagebox.showinfo('오류 찾기', '이미 찾고 있습니다.')
            return
        with _db() as conn:
            m = AR.check_model(conn)
        if not messagebox.askyesno('오류 찾기', '선택한 %d건(%s)을 %s 에게 보내 중요한 오류만 찾게 합니다(고치지 않습니다).\n'
                                              '3건씩 묶어 보냅니다 · 어림(Pro low 기준) 건당 약 15원 · %d건이면 약 %d원. 할까요?\n(모델은 「AI 연결」 탭의 일별 설정)'
                                              % (len(ids), self._rv_sel_range(ids), m, len(ids), len(ids) * 15)):
            return
        self._ck_q = queue.Queue()
        self._ck_btn.config(state='disabled')
        # ★ 2026-10-30 [중지]가 오류 찾기도 멈춘다(사용자 「오류찾기 기능에는 중지 기능이 없다」) — 묶음 사이에서만
        self._rv_stop_flag = False
        self._rv_stop_btn.config(state='normal')
        self._ck_stat.config(text='오류 찾는 중… 0/%d' % len(ids))

        def _work():
            # ★ 2026-10-30 3건씩 묶어 한 번에(db_ai_run.check_groups · check_many) — 결과는 건마다 목록에
            n_err = n_f = i = 0
            try:
                with _db() as conn:
                    groups, empty = AR.check_groups(conn, ids)
            except Exception as e:                        # noqa: BLE001
                groups, empty = [], list(ids)
            for iid in empty:
                i += 1
                n_err += 1
                self._ck_q.put(('tick', i, len(ids), n_f, n_err, '받은 글이 없습니다', iid, None))
            for g in groups:
                if self._rv_stop_flag:
                    break
                for u in g:
                    self._ck_q.put(('start', u['iid']))
                try:
                    with _db() as conn:
                        out = AR.check_many(conn, g)
                except Exception as e:                    # noqa: BLE001
                    out = {u['iid']: {'ok': False, 'why': str(e)} for u in g}
                for u in g:
                    i += 1
                    res = out.get(u['iid']) or {}
                    if res.get('ok'):
                        n_f += len(res.get('found') or [])
                    else:
                        n_err += 1
                    self._ck_q.put(('tick', i, len(ids), n_f, n_err, res.get('why', ''), u['iid'],
                                    len(res.get('found') or []) if res.get('ok') else None))
                if any((out.get(u['iid']) or {}).get('daily') for u in g):
                    break                      # ★ 하루 한도 — 남은 묶음을 보내지 않는다
            self._ck_q.put(('done', i, n_f, n_err))

        self._ck_th = threading.Thread(target=_work, daemon=True)
        self._ck_th.start()
        self._ck_pump()

    def _ck_cell(self, iid, txt):
        """그 건의 「오류」 칸만 그 자리에서 바꾼다(목록을 다시 그리지 않는다 — 선택이 안 흔들린다)"""
        try:
            if self._rv_tv.exists(str(iid)):
                self._rv_tv.set(str(iid), 'ck', txt)
        except Exception:                                 # noqa: BLE001
            pass

    def _ck_pump(self):
        """★ 2026-10-30 건마다 목록에 바로 보인다(사용자 「아무 반응이 없으니 오류인 것처럼 느껴진다」) —
        찾는 줄 = 「찾는 중…」 · 끝나면 「3건」·「0건」·「실패」 · 지금 보고 있는 건이면 아래 결과 칸도 그 자리에서."""
        import queue
        if not self.winfo_exists():
            return
        done = None
        try:
            while True:
                m = self._ck_q.get_nowait()
                if m[0] == 'start':
                    self._ck_cell(m[1], '찾는 중…')
                    if self._rv_tv.exists(str(m[1])):
                        self._rv_tv.see(str(m[1]))
                elif m[0] == 'tick':
                    _, i, n, nf, ne, why, iid, cnt = m
                    self._ck_cell(iid, '실패' if cnt is None else '%d건' % cnt)
                    if str(iid) in self._rv_tv.selection()[:1]:
                        self._ck_fill(iid)
                    self._ck_stat.config(text='오류 찾는 중… %d/%d · 찾은 오류 %d%s' % (
                        i, n, nf, (' · 실패 %d (%s)' % (ne, why[:60])) if ne else ''))
                elif m[0] == 'done':
                    done = m
                    break
        except queue.Empty:
            pass
        if done:
            _, n, nf, ne = done
            self._ck_th = None
            self._ck_btn.config(state='normal')
            if getattr(self, '_rv_th', None) is None:
                self._rv_stop_btn.config(state='disabled')
            self._ck_stat.config(text='오류 찾기 %s — %d건 · 찾은 오류 %d%s'
                                      % ('멈춤' if self._rv_stop_flag else '끝', n, nf, (' · 실패 %d' % ne) if ne else ''))
            if self._rv_stop_flag:
                # 멈춘 뒤 「찾는 중…」으로 남은 칸이 없게 다시 그린다
                self._rv_fill()
            return
        self.after(300, self._ck_pump)

    def _ck_skip(self):
        """선택한 오류 줄을 빼거나(고치지 않음) 되살린다 — 이미 고친 줄은 그대로"""
        item = getattr(self, '_ck_item', None)
        rows = [i for i in self._ck_tv.selection() if 'done' not in self._ck_tv.item(i, 'tags')]
        if item is None or not rows:
            return
        to_skip = any('skip' not in self._ck_tv.item(i, 'tags') for i in rows)
        with _db() as conn:
            AR.set_check_skip(conn, item, [int(i) for i in rows], skip=to_skip)
            chk = AR.check_of(conn, item)
        self._ck_fill(item)
        self._ck_cell(item, self._ck_count(chk))
        try:
            self._ck_tv.selection_set([i for i in rows if self._ck_tv.exists(i)])
        except Exception:                                 # noqa: BLE001
            pass

    @staticmethod
    def _ck_count(chk):
        f = (chk or {}).get('found') or []
        if not f:
            return '0건'
        left = AR.fix_picks(chk)
        return ('%d건' % len(left)) if left else ('고침' if any(x.get('done') for x in f) else '뺌')

    def _fx_start(self):
        """[오류 수정] — 목록에서 선택한 건마다 **안 뺀 · 안 고친** 오류 줄을 한꺼번에 고친다.

        한 번 나오는 글자는 기계가 그 자리만 · 여러 번이면 다른 AI 가 그 자리만(`db_ai_run.apply_fixes`) ·
        이미 적재한 건은 「승인」으로 되돌린다(다시 [적재]).
        """
        import queue
        import threading
        ids = self._rv_sel()
        if not ids:
            messagebox.showinfo('오류 수정', '고칠 건을 목록에서 선택하세요(Shift 로 범위 선택).')
            return
        if getattr(self, '_fx_th', None) is not None:
            messagebox.showinfo('오류 수정', '이미 고치고 있습니다.')
            return
        if self._rv_out.get('1.0', 'end-1c') != (getattr(self, '_rv_out_orig', '') or ''):
            messagebox.showinfo('오류 수정', '받은 글을 손으로 고친 것이 있습니다 — 먼저 승인하거나 그 건을 다시 누르세요.')
            return
        plan, n_lines, n_skip, n_none = [], 0, 0, 0
        with _db() as conn:
            for iid in ids:
                chk = AR.check_of(conn, iid)
                if not chk:
                    n_none += 1
                    continue
                pk = AR.fix_picks(chk)
                n_skip += sum(1 for f in chk.get('found') or [] if f.get('skip') and not f.get('done'))
                if pk:
                    plan.append((iid, pk))
                    n_lines += len(pk)
        if not plan:
            messagebox.showinfo('오류 수정', '고칠 줄이 없습니다(오류 찾기를 안 했거나, 0건이거나, 모두 빼거나 고쳤습니다).')
            return
        msg = '선택한 %d건(%s) 가운데 %d건의 오류 %d줄을 고칩니다.' % (len(ids), self._rv_sel_range(ids), len(plan), n_lines)
        if n_skip:
            msg += '\n뺀 줄 %d개는 고치지 않습니다.' % n_skip
        if n_none:
            msg += '\n오류 찾기를 안 한 %d건은 건너뜁니다.' % n_none
        if not messagebox.askyesno('오류 수정', msg + '\n\n할까요?'):
            return
        self._fx_q = queue.Queue()
        self._fx_btn.config(state='disabled')
        self._rv_stop_flag = False
        self._rv_stop_btn.config(state='normal')
        self._ck_stat.config(text='오류 고치는 중… 0/%d' % len(plan))

        def _work():
            tot = {'machine': 0, 'ai': 0, 'skip': 0, 'reload': 0, 'fail': 0}
            for i, (iid, pk) in enumerate(plan, 1):
                if self._rv_stop_flag:
                    break
                self._fx_q.put(('start', iid))
                try:
                    with _db() as conn:
                        res = AR.apply_fixes(conn, iid, pk)
                        cnt = self._ck_count(AR.check_of(conn, iid))
                except Exception as e:                    # noqa: BLE001
                    res, cnt = {'why': str(e)}, '실패'
                    tot['fail'] += 1
                tot['machine'] += len(res.get('machine') or [])
                tot['ai'] += len(res.get('ai') or [])
                tot['skip'] += len(res.get('skip') or [])
                tot['reload'] += 1 if res.get('reload') else 0
                self._fx_q.put(('tick', i, len(plan), iid, cnt))
            self._fx_q.put(('done', tot))

        self._fx_th = threading.Thread(target=_work, daemon=True)
        self._fx_th.start()
        self._fx_pump()

    def _fx_pump(self):
        import queue
        if not self.winfo_exists():
            return
        done = None
        try:
            while True:
                m = self._fx_q.get_nowait()
                if m[0] == 'start':
                    self._ck_cell(m[1], '고치는 중…')
                    if self._rv_tv.exists(str(m[1])):
                        self._rv_tv.see(str(m[1]))
                elif m[0] == 'tick':
                    _, i, n, iid, cnt = m
                    self._ck_cell(iid, cnt)
                    self._ck_stat.config(text='오류 고치는 중… %d/%d' % (i, n))
                elif m[0] == 'done':
                    done = m[1]
                    break
        except queue.Empty:
            pass
        if done is None:
            self.after(300, self._fx_pump)
            return
        self._fx_th = None
        self._fx_btn.config(state='normal')
        if getattr(self, '_rv_th', None) is None:
            self._rv_stop_btn.config(state='disabled')
        t = done
        msg = '오류 수정 %s — 그 자리만 바꿈 %d · 다른 AI 가 고침 %d' % (
            '멈춤' if self._rv_stop_flag else '끝', t['machine'], t['ai'])
        if t['skip']:
            msg += ' · 못 고침 %d' % t['skip']
        if t['fail']:
            msg += ' · 실패 %d건' % t['fail']
        self._ck_stat.config(text=msg)
        self._rv_fill()
        self._rv_show()
        note = ' · 게이트를 다시 쟀습니다'
        if t['reload']:
            note += ' · ⚠ 이미 적재한 %d건은 「승인」으로 되돌렸습니다 — [적재]를 다시 누르면 고친 글이 들어갑니다' % t['reload']
        self._rv_sum.config(text=msg + note)

    # ── 맡기기(Batch) — db_ai_batch ───────────────────────────────────
    def _bt_status(self):
        try:
            import db_ai_batch as BT
            with _db() as conn:
                sm = BT.summary(conn)
        except Exception as e:                            # noqa: BLE001
            self._bt_lbl.config(text='Batch 작업 — 상태를 못 읽었습니다: %s' % e)
            return {}
        if not sm:
            self._bt_lbl.config(text='Batch 작업 — 없음 · 많은 건은 [Batch 전송]: 값 절반 · 하루 한도와 따로 · 결과는 몇 분~24시간 뒤')
            return sm
        parts = ['%s %d(%d건)' % (BT.STATE_KO.get(k, k), n, it) for k, (n, it) in sorted(sm.items())]
        self._bt_lbl.config(text='Batch 작업 — ' + ' · '.join(parts) + ' · 열어 두면 5분마다 저절로 확인')
        return sm

    def _bt_tick(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:                                 # noqa: BLE001
            return
        sm = self._bt_status()
        if any(k in sm for k in ('WAITING', 'SUBMITTED', 'PENDING', 'RUNNING')):
            self._bt_poll()
        self.after(300000, self._bt_tick)

    def _bt_run(self, fn, done):
        """일꾼 스레드 한 번 — 끝나면 메인에서 done(결과)"""
        import queue
        import threading
        if self._bt_th is not None:
            return
        q = queue.Queue()

        def work():
            try:
                with _db() as conn:
                    q.put(fn(conn))
            except Exception as e:                        # noqa: BLE001
                q.put({'ok': False, 'why': str(e)})
        self._bt_th = threading.Thread(target=work, daemon=True)
        self._bt_th.start()

        def pump():
            try:
                res = q.get_nowait()
            except queue.Empty:
                self.after(400, pump)
                return
            self._bt_th = None
            done(res)
        pump()

    def _bt_submit(self):
        import db_ai_batch as BT
        jid = self._rv_jid()
        ids = self._rv_sel()
        if jid is None or not ids:
            messagebox.showinfo('Batch 전송', 'Batch 로 보낼 건을 목록에서 선택하세요(Shift 로 범위 선택).')
            return
        with _db() as conn:
            n = conn.execute("SELECT COUNT(*) FROM sys_ai_item WHERE job_id=? AND state IN ('PENDING','FAIL') AND item_id IN (%s)"
                             % ','.join('?' * len(ids)), [jid] + list(ids)).fetchone()[0]
            j = AR.job(conn, jid)
        if not n:
            messagebox.showinfo('Batch 전송', '선택한 건 가운데 보낼 것(대기·실패)이 없습니다.')
            return
        if not messagebox.askyesno('Batch 전송', '선택한 %d건(%s) 가운데 %d건을 Batch 로 보냅니다.\n'
                                   '모델 %s · 지금과 같은 묶음으로 · 값은 바로 받는 것의 절반(어림 건당 5~10원).\n'
                                   '결과는 몇 분~24시간 뒤에 옵니다 — 이 화면을 열어 두면 저절로 받습니다.\n\n보낼까요?'
                                   % (len(ids), self._rv_sel_range(ids), n, j['model'])):
            return
        self._bt_go.config(state='disabled')
        self._bt_lbl.config(text='Batch 로 보내는 중…')

        def done(res):
            self._bt_go.config(state='normal')
            self._rv_fill()
            self._bt_status()
            if res.get('ok'):
                self._rv_sum.config(text='Batch 로 보냈습니다 — %d건 · Batch 작업 %d개%s%s' % (
                    res.get('items', 0), res.get('batches', 0),
                    (' · 차례 기다림 %d(앞의 Batch 가 끝나면 저절로 보냅니다)' % res['waiting']) if res.get('waiting') else '',
                    (' · ⚠ %s' % res['why']) if res.get('why') else ''))
            else:
                self._rv_sum.config(text='Batch 로 보내지 못했습니다 — %s' % res.get('why'))
        self._bt_run(lambda conn: BT.submit(conn, jid, ids), done)

    def _ck_batch(self):
        import db_ai_batch as BT
        ids = self._rv_sel()
        if not ids:
            messagebox.showinfo('오류 찾기 Batch', '먼저 건을 선택하세요(Shift 로 범위 선택).')
            return
        if not messagebox.askyesno('오류 찾기 Batch', '선택한 %d건(%s)의 오류 찾기를 Batch 로 보냅니다(이미 찾은 건은 뺍니다).\n'
                                   '값은 바로 찾기의 절반 · 하루 한도와 따로 · 결과는 몇 분~24시간 뒤에 건마다 들어옵니다. 보낼까요?'
                                   % (len(ids), self._rv_sel_range(ids))):
            return

        def done(res):
            self._bt_status()
            self._rv_sum.config(text=('오류 찾기를 Batch 로 보냈습니다 — %d건%s' % (res.get('items', 0),
                                      (' · ⚠ %s' % res['why']) if res.get('why') else ''))
                                if res.get('ok') else '오류 찾기 Batch 를 보내지 못했습니다 — %s' % res.get('why'))
        self._bt_run(lambda conn: BT.submit_check(conn, ids), done)

    def _bt_poll(self, manual=False):
        import db_ai_batch as BT
        if manual:
            self._bt_lbl.config(text='Batch 작업 확인 중…')

        def done(res):
            self._bt_status()
            if res.get('items') or res.get('failed') or manual:
                self._rv_fill()
                msg = 'Batch 확인 — 끝난 Batch %d · 받은 건 %d%s%s' % (
                    res.get('got', 0), res.get('items', 0),
                    (' · 실패·만료 %d(그 건들은 「대기」로)' % res['failed']) if res.get('failed') else '',
                    (' · ⚠ %s' % res['why']) if res.get('why') else '')
                self._rv_sum.config(text=msg)
        self._bt_run(lambda conn: BT.poll(conn), done)

    def _bt_cancel(self):
        import db_ai_batch as BT
        ids = self._rv_sel()
        with _db() as conn:
            bs = BT.active_of_items(conn, ids) if ids else []
        if not bs:
            messagebox.showinfo('Batch 취소', '선택한 건이 든 Batch 작업이 없습니다 — 「Batch 중」인 건을 선택하세요.')
            return
        if not messagebox.askyesno('Batch 취소', 'Batch 작업 %d개를 취소합니다. 그 안의 건은 모두 「대기」로 돌아갑니다.\n'
                                   '(이미 처리된 몫도 받지 않습니다) 할까요?' % len(bs)):
            return
        with _db() as conn:
            for b in bs:
                BT.cancel(conn, b)
        self._rv_fill()
        self._bt_status()

    def _rv_run(self):
        """[전송하기] — **선택한 건만** 보낸다.

        ★★★ 옛 방식은 「목록에서 고른 것」과 「한 번에 N개」가 **따로 놀았다**
          (사용자 「복수선택 하고 전송하기 버튼 누르면 API 전송하라」) —
          고른 것과 무관하게 앞에서 N개를 보냈다. 혼란의 근원이다.
        ⚠ **아직 안 받은 건만** 보낸다 — 고른 줄에 끝난 것이 섞여 있어도
          한도를 두 번 먹지 않는다. 몇 건이 그래서 빠졌는지 말한다.
        ⚠ 아무것도 안 골랐으면 **보내지 않는다** — 「전부 보낼까요」를 묻지
          않는다. 수백 건이 한 번에 나가는 사고가 그렇게 난다.
        """
        jid = self._rv_jid()
        if jid is None:
            return
        ids = self._rv_sel()
        if not ids:
            messagebox.showinfo('전송하기',
                                '보낼 건을 목록에서 선택하세요.\n'
                                'Shift 를 누른 채 누르면 구간으로 선택합니다.')
            return
        with _db() as conn:
            keys_n = len(AC.keys(conn))
            rows = conn.execute(
                "SELECT COUNT(*) FROM sys_ai_item WHERE job_id=?"
                "  AND state IN ('PENDING','FAIL') AND item_id IN (%s)"
                % ','.join('?' * len(ids)), [jid] + list(ids)).fetchone()
        todo = int(rows[0]) if rows else 0
        if not keys_n:
            messagebox.showwarning('전송하기', 'Gemini 키가 없습니다 — '
                                              '「AI 연결」 탭에서 넣으세요.')
            return
        if not todo:
            messagebox.showinfo('전송하기',
                                '선택한 %d건은 이미 받았습니다 — 보낼 것이 '
                                '없습니다.' % len(ids))
            return
        skip = len(ids) - todo
        msg = '선택한 %d건을 보냅니다. (%s)' % (todo, self._rv_sel_range(ids))
        if skip:
            msg += '\n(이미 받은 %d건은 뺐습니다)' % skip
        if not messagebox.askyesno('전송하기', msg + '\n\n할까요?'):
            return
        self._rv_start(jid, todo, only=ids)

    # ── 돌리기 — **일꾼 스레드** (2026-09-24 사용자 「관리자앱이 작동하지
    #    않는다」) ──────────────────────────────────────────────
    #  ★★★ 그전에는 `run_job` 을 **이 자리에서** 불렀다. Tk 는 단일 스레드라
    #    그동안 mainloop 가 한 번도 안 돌아 **창이 통째로 얼어붙었다**.
    #    실측 — 한 건 5초면 8건에 40초, 느리면 4분, 최악 49분.
    #  ⚠ **연결을 스레드 사이로 넘기지 않는다** — 일꾼이 제 것을 새로 연다.
    #  ⚠ **화면은 메인 스레드에서만 만진다** — `after(0, …)` 로 넘긴다.
    def _rv_start(self, jid, want, only=None):
        import queue
        import threading
        if getattr(self, '_rv_th', None) is not None:
            messagebox.showinfo('돌리기', '이미 돌고 있습니다.')
            return
        self._rv_stop_flag = False
        self._rv_q = queue.Queue()
        self._rv_go.config(state='disabled')
        self._rv_stop_btn.config(state='normal')
        self._rv_sum.config(text='보내는 중… 0/%d' % want)

        def _tick(i, n, sid, res):
            # ⚠ 여기는 **일꾼 스레드**다 — 화면을 직접 만지지 않는다.
            self._rv_q.put(('tick', i, n, bool(res and res.get('ok'))))

        def _work():
            try:
                with _db() as conn:
                    r = AR.run_job(conn, jid, limit=want,
                                   on_progress=_tick, only=only,
                                   should_stop=lambda: self._rv_stop_flag)
            except Exception as e:                        # noqa: BLE001
                r = {'tried': 0, 'done': 0, 'fail': 0, 'stopped': 0,
                     'why': str(e)}
            self._rv_q.put(('done', r))

        self._rv_th = threading.Thread(target=_work, daemon=True)
        self._rv_th.start()
        self._rv_pump()

    def _rv_start_multi(self, jids):
        """여러 작업(= 여러 언어)을 **자리마다 언어 차례로** 보낸다(1.txt 2번 3)).

        차례 = 첫 작업의 자리 순서대로, 자리 하나에 모든 언어 → 다음 자리.
        `run_job(only=[건])` 을 건마다 부른다 — 게이트·적재 규칙이 그대로 걸린다.
        ⚠ 첫머리 겹침 검사(`seen_heads`)는 건마다 새로 시작한다 — 번역은 원문의
          첫머리를 따르므로 그 검사가 뜻이 적다.
        """
        import queue
        import threading
        if not hasattr(self, '_rv_go'):
            messagebox.showinfo('돌리기', '검수 탭이 아직 안 열렸습니다 — 다시 누르세요.')
            return
        if getattr(self, '_rv_th', None) is not None:
            messagebox.showinfo('돌리기', '이미 돌고 있습니다.')
            return
        with _db() as conn:
            plan = []
            first = conn.execute(
                "SELECT slot_id FROM sys_ai_item WHERE job_id=? ORDER BY item_id",
                (jids[0],)).fetchall()
            for (sid,) in first:
                for jid in jids:
                    r = conn.execute(
                        "SELECT item_id FROM sys_ai_item WHERE job_id=? AND slot_id=?"
                        "  AND state IN ('PENDING','FAIL')", (jid, sid)).fetchone()
                    if r:
                        plan.append((jid, int(r[0]), sid))
        want = len(plan)
        if not want:
            messagebox.showinfo('돌리기', '보낼 건이 없습니다.')
            return
        self._rv_stop_flag = False
        self._rv_q = queue.Queue()
        self._rv_go.config(state='disabled')
        self._rv_stop_btn.config(state='normal')
        self._rv_sum.config(text='보내는 중… 0/%d (작업 %d개 · 자리마다 언어 차례)'
                                 % (want, len(jids)))

        def _work():
            tot = {'tried': 0, 'done': 0, 'fail': 0, 'stopped': 0}
            try:
                # ★ 2026-10-30 자리 8개씩 끊어 그 덩어리를 **언어마다 한 번에**(묶어 보내기 · 생각 low) —
                #   한 건씩 보내면 호출마다 생각 토큰이 붙어 건당 4배 가까이 든다(실측). 차례는 덩어리 단위로 「자리 → 모든 언어」.
                order = []
                for (jid, iid, sid) in plan:
                    if sid not in order:
                        order.append(sid)
                chunks = [order[k:k + AR.BATCH_MAX] for k in range(0, len(order), AR.BATCH_MAX)]
                i = 0
                with _db() as conn:
                    for ch in chunks:
                        for jid in jids:
                            if self._rv_stop_flag:
                                break
                            ids_ = [iid for (jj, iid, sid) in plan if jj == jid and sid in ch]
                            if not ids_:
                                continue
                            r = AR.run_job(conn, jid, only=ids_,
                                           should_stop=lambda: self._rv_stop_flag)
                            for k in ('tried', 'done', 'fail'):
                                tot[k] += int(r.get(k, 0))
                            i += len(ids_)
                            self._rv_q.put(('tick', i, want, ch[-1], bool(r.get('done'))))
                        if self._rv_stop_flag:
                            tot['stopped'] = want - i
                            break
            except Exception as e:                        # noqa: BLE001
                tot['why'] = str(e)
            self._rv_q.put(('done', tot))

        self._rv_th = threading.Thread(target=_work, daemon=True)
        self._rv_th.start()
        self._rv_pump()

    def _rv_pump(self):
        """큐를 꺼내 화면에 옮긴다 — **메인 스레드에서만 돈다**.

        ⚠⚠⚠ **`after` 를 일꾼 스레드에서 부르면 안 된다** — 실측으로 당했다.
          Tcl 인터프리터는 스레드 안전하지 않아 다른 스레드의 예약을 **조용히
          잃는다**(진행이 `0/8` 에 멈추고 끝나도 단추가 안 풀렸다 · 오류 0).
          ⇒ 일꾼은 **큐에 넣기만** 하고 꺼내는 일은 여기서 한다.
        ⚠ 한 번에 **쌓인 것을 다 비우고 마지막만 그린다** — 건이 빨리 지나갈
          때 화면을 여러 번 다시 그릴 까닭이 없다.
        ⚠ 창이 닫혔으면 그만둔다 — 일꾼은 daemon 이라 알아서 죽는다.
        """
        import queue
        try:
            if not self.winfo_exists():
                return
        except Exception:                                 # noqa: BLE001
            return
        fin, last = None, None
        try:
            while True:
                m = self._rv_q.get_nowait()
                if m[0] == 'done':
                    fin = m[1]
                else:
                    last = m
        except queue.Empty:
            pass
        except Exception:                                 # noqa: BLE001
            pass
        if last is not None:
            _k, i, n, ok = last
            # ★ 받는 대로 목록도 채운다 — 빈 화면으로 기다리지 않게.
            # ⚠⚠ **목록을 먼저, 진행을 나중에.** `_rv_fill` 이 같은 라벨
            #   (`_rv_sum`)을 제 글로 덮는다 — 차례를 바꾸면 진행이 그 자리에서
            #   사라진다(§257차 ⑯ 과 똑같은 함정 · 실측으로 또 밟았다).
            try:
                self._rv_fill()
            except Exception:                             # noqa: BLE001
                pass
            self._rv_sum.config(text='보내는 중… %d/%d   (마지막 %s)'
                                     % (i, n, '받음' if ok else '실패'))
        if fin is not None:
            self._rv_done(fin)
            return
        self.after(120, self._rv_pump)

    def _rv_stop(self):
        self._rv_stop_flag = True
        self._rv_stop_btn.config(state='disabled')
        self._rv_sum.config(text='중지하는 중… (보낸 건은 끝까지 받습니다)')
        if getattr(self, '_ck_th', None) is not None or getattr(self, '_fx_th', None) is not None:
            self._ck_stat.config(text='멈추는 중… (보낸 묶음은 끝까지 받습니다)')

    def _rv_done(self, r):
        self._rv_th = None
        self._rv_go.config(state='normal')
        self._rv_stop_btn.config(state='disabled')
        self._rv_fill()
        if r.get('why'):
            messagebox.showerror('돌리기', '터졌습니다: %s' % r['why'])
            return
        msg = ('보낸 %d건 — 받음 %d · 실패 %d'
               % (r['tried'], r['done'], r['fail']))
        if r.get('stopped'):
            msg += ('%s중지했습니다 — 남은 %d건은 다시 누르면 이어집니다.'
                    % (chr(10), r['stopped']))
        messagebox.showinfo('돌리기', msg)

    def _rv_judge(self, state):
        """[승인]/[반려] — **고친 글이면 그 글로 승인**한다.

        ★★★ 사용자 지시 「승인 / 고쳐서 승인 : **통합**하라」. 규칙은 하나다 —
          **오른쪽 칸의 글이 바뀌었으면 그 글로, 아니면 받은 글 그대로.**
        ⚠ 한 줄만 골랐을 때만 글이 바뀔 수 있다(오른쪽에 한 건이 떠 있다).
          여러 줄을 고르면 화면의 글은 그중 하나일 뿐이라 **쓰지 않는다** —
          안 그러면 한 건의 글이 여러 건에 복사된다.
        """
        ids = self._rv_sel()
        if not ids:
            messagebox.showinfo('판정', '줄을 선택하세요.')
            return
        txt = None
        if state == 'OK' and len(ids) == 1:
            cur = self._rv_out.get('1.0', 'end').strip()
            if cur and cur != (getattr(self, '_rv_out_orig', '') or '').strip():
                txt = cur
        why = None
        if state == 'REJ':
            why = self._rv_why.get().strip()
        keep = None
        if state == 'OK' and len(ids) == 1 and self._rv_keep:
            keep = [k for k, v in self._rv_keep.items() if v.get()]
        with _db() as conn:
            n_ok = AR.judge(conn, ids, state, text=txt, why=why, keep=keep)
        if state == 'REJ':
            self._rv_why.delete(0, 'end')
        self._rv_fill()
        if state == 'OK' and n_ok < len(ids):
            # ★ 2026-10-22 빈 글은 승인하지 않는다 — 몇 건을 건너뛰었는지 말한다
            self._rv_sum.config(text='글이 비어 있는 %d건은 승인하지 않았습니다(다시 돌리거나 반려하세요).' % (len(ids) - n_ok))
        elif txt is not None:
            self._rv_sum.config(text='고친 글로 승인했습니다.')
        elif state == 'REJ' and not why:
            self._rv_sum.config(text='반려했습니다 — 사유를 적어 두면 예제·게이트 재료가 됩니다.')

    def _rv_load(self):
        jid = self._rv_jid()
        if jid is None:
            return
        with _db() as conn:
            d = AR.load_ok(conn, jid, dry=True)
        if not d['ok']:
            messagebox.showwarning('적재', d['why'])
            return
        if not d['n']:
            messagebox.showinfo('적재', '승인한 건이 없습니다.')
            return
        if not messagebox.askyesno(
                '적재', '승인한 %d건을 배포 DB 에 담습니다.\n'
                      '같은 자리에 글이 있으면 덮어씁니다. 할까요?' % d['n']):
            return
        with _db() as conn:
            got = AR.load_ok(conn, jid, dry=False)
        self._rv_fill()
        # ★ 적재하면 그 자리가 **채워진다** — 탭1 의 「할 일」도 그만큼
        #   줄어야 한다(사용자 신고 2026-09-23 「승인분 적재까지 했다.
        #   그래도 표시된다」).
        self._refresh_status()
        messagebox.showinfo('적재', '%d건 담았습니다.%s' % (
            got['n'], (chr(10) + got['why']) if got.get('why') else ''))

    # ── 값 ──────────────────────────────────────────────────────────
    # ⚠⚠⚠ 옛 `_kind`·`_scope_val`(콤보 기준)을 여기서 걷었다 — **나중 정의가
    #   이겨서** 3단 목록이 아니라 없어진 콤보를 보고 있었다(실측으로 당했다).
    #   지금 정의는 `_build_pick` 바로 아래에 있다.

    def _refresh_status(self):
        """밖에서 부르는 옛 이름 — 3단 채우기로 위임한다.

        ⚠ 탭을 옮길 때(`_on_tab`)와 적재 뒤에 불린다. 이름을 바꾸면 그 길이
          조용히 죽으므로 남긴다(§279차 「배선이 살아 있는가는 다른 물음」).
        """
        self._fill_units()

    def _say_prof(self, text):
        """지금 쓸 프로필 이름을 **열려 있는 자리**에 적는다.

        ⚠ 옛 화면은 미리보기 칸 머리에 라벨을 두었는데 그 칸을 팝업으로
          옮겼다(사용자 「프롬프트 : 표시하지 마라. 화면이 좁다」).
          팝업이 열려 있으면 **창 제목**이 그 몫을 한다.
        """
        self._prof_text = text
        w = getattr(self, '_prev', None)
        try:
            if w is not None and w.winfo_exists():
                w.winfo_toplevel().title(text)
        except Exception:                                 # noqa: BLE001
            pass

    def _paint_prev(self, slot_id=None):
        """미리보기 — **실제로 보낼 글 그대로**(프롬프트 + 재료).

        ★ 재료를 안 붙이면 화면과 실제가 달라지고, 재료가 틀린 것을 **돈을
          쓰기 전에** 알아챌 수 없다(2026-09-23 ②).
        ⚠ 재료는 자리마다 다르므로 **고른 첫 줄**을 보기로 쓴다.
        """
        pok = getattr(self, '_cur_prompt', None) or (False, '')
        if getattr(self, '_prev', None) is None:
            return          # 팝업이 안 열려 있으면 그릴 자리가 없다
        self._prev.config(state='normal')
        self._prev.delete('1.0', 'end')
        if not pok[0]:
            # ⚠ **왜 없는지 말한다**(§0-1) — 빈 칸만 두면 고장으로 읽힌다.
            self._say_prof('이 작업에 쓸 프롬프트 — 아직 없습니다')
            self._prev.insert('end', (pok[1] or '이 자산·업무에 쓸 프롬프트가 아직 '
                                      '없습니다.') + '\n「프롬프트」 탭 ▸ [수정] 에서 '
                                      '자산 단추나 업무 단추를 선택해 역할·할 일을 적어 두세요.')
            self._prev.config(state='disabled')
            return
        self._say_prof('이 작업에 쓸 프롬프트 — %s · %s · %s (층을 합친 글)'
                       % (AJ.ASSET[self._kind()]['name'],
                          AJ.TASK_NAME.get(self._task.get(), self._task.get()),
                          (self._lang.get() or 'KO').upper()))
        ctx, head = {}, ''
        # ★ 2026-10-13 — **실행기와 같은 함수**로 짓는다(`AR.job_prompt_obj` · `AR.item_ctx`) — 묶음 칸 거르기 ·
        #   칸 지시 · 연결설명문 함께 쓰기가 미리보기에서 빠져 「보인 것과 보낸 것」이 달랐다.
        _pj = {'asset_kind': self._kind(), 'scope_value': self._scope_val(), 'task': self._task.get(),
               'lang': (self._lang.get() or 'KO').upper(),
               'base_lang': (getattr(self, '_base_cur', None) or AJ.base_lang(self._kind(), self._scope_val())),
               'parts': ','.join(self._picked_parts(self._kind()) or []),   # ★ 작업에 저장되는 꼴(쉼표 글자열)과 같게
               'add_mode': self._add_mode(self._kind()) or ''}
        if slot_id is not None:
            try:
                with _db() as conn:
                    ctx = AR.item_ctx(conn, _pj, slot_id)
                head = ('— 선택한 것 가운데 첫 줄(%s)을 보기로 폈습니다 —\n\n'
                        % ctx.get('구절') or ctx.get('용어') or str(slot_id))
            except Exception as e:                        # noqa: BLE001
                head = '재료를 못 모았습니다: %s\n\n' % e
        else:
            head = '— 목록에서 줄을 선택하면 **실제로 보낼 글**을 그대로 보입니다 —\n\n'
        try:
            # ★★★ **층을 합친 글 그대로**(2026-09-25) — 실행기와 **같은 문**을
            #   쓴다. 미리보기가 제 손으로 다시 짜면 「보인 것과 보낸 것이
            #   다르다」가 된다(§277차 ⑤).
            with _db() as _c:
                obj = AR.job_prompt_obj(_c, _pj)
            self._prev.insert('end', head + AJ.render_prompt(obj, ctx)
                              + chr(10) + chr(10) + '— 보낼 때 더 붙는 것: 다시 쓰기(게이트 반영)면 앞 글과 걸린 줄 · '
                                'AI 가 이 작업에서 같은 끝맺음을 자주 쓰면 그 끝맺음 목록. 보낸 뒤에는 「AI 에게 보낸 글」 탭에 '
                                '글자 그대로 남습니다 —')
        except Exception as e:                            # noqa: BLE001
            self._prev.insert('end', '프롬프트를 읽지 못했습니다: %s' % e)
        self._prev.config(state='disabled')

    def _goto_profile(self):
        """프롬프트 탭으로 — **지금 자산·업무·언어의 결합 프롬프트**를 조회로 연다."""
        self._nb.select(self.TAB['prompt'])
        try:
            self._pt.show_for(self._kind(), self._task.get(),
                              (self._lang.get() or '').upper())
        except Exception as e:                            # noqa: BLE001
            print('[ai_workshop goto prompt] %s' % e)

    # ══════════════════════════════════════════════════════════════
    #  탭 2 — 프롬프트 프로필
    # ══════════════════════════════════════════════════════════════
    def _build_prof(self, root):
        """프롬프트 탭 — **개별 프롬프트를 적고 조립해 본다**(`admin/ai_prompt_tab.py`).

        ★★★ 2026-09-29 294차(`docs/1.txt` 1번) — 왼쪽 트리·[저장]·[이 층 지우기]·
          [새 층 추가]·[프롬프트 보기]를 걷고 **[수정]/[조회] + 세 계층 단추**로.
          층의 집(`sys_ai_prompt`)은 그대로다 — 고르는 방법만 바뀌었다.
        ⚠ 옛 `_lay_*` 메서드는 걷었다(되돌릴 자리 = git · `참고코드/` 아님 —
          부품이 통째로 갈렸다). 하네스는 `self._pt` 로 새 부품을 잰다.
        """
        try:
            from ai_prompt_tab import PromptTab
        except Exception:                                 # noqa: BLE001
            from admin.ai_prompt_tab import PromptTab     # noqa: F401
        self._pt = PromptTab(
            root, _db,
            help_factory=lambda parent: build_help_button(
                parent, 'AI 작성·번역 — 사용방법', HELP_SECTIONS),
            lang_getter=self.lang_getter)
        self._pt.pack(fill='both', expand=True)

    def _lay_reload(self, select=None):
        """옛 이름 — 새 부품의 `reload()` 로 넘긴다(부르는 자리가 남아 있다)."""
        pt = getattr(self, '_pt', None)
        if pt is not None:
            try:
                pt.reload()
            except Exception as e:                        # noqa: BLE001
                print('[ai_workshop prompt reload] %s' % e)

    # ══════════════════════════════════════════════════════════════
    #  탭 4 — AI 연결
    # ══════════════════════════════════════════════════════════════
    def _build_conn(self, root):
        bar = ttk.Frame(root)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        ttk.Button(bar, text='키 저장', command=self._conn_save).pack(side='left')
        ttk.Button(bar, text='연결 시험',
                   command=self._conn_ping).pack(side='left', padx=4)
        ttk.Button(bar, text='다시 읽기',
                   command=self._conn_refresh).pack(side='left', padx=4)
        build_help_button(bar, 'AI 작성·번역 — 사용방법',
                          HELP_SECTIONS).pack(side='right', padx=4)

        f = ttk.Frame(root)
        f.pack(fill='x', padx=8, pady=4)
        ttk.Label(f, text='Gemini 키 (여러 개면 쉼표로):').grid(
            row=0, column=0, sticky='w')
        self._k_var = tk.StringVar()
        ttk.Entry(f, textvariable=self._k_var, width=70).grid(
            row=0, column=1, sticky='we', padx=4)
        f.columnconfigure(1, weight=1)
        # ★★ 2026-10-30 일마다 모델 · 생각 정도(사용자 「모든 작업에 대해서 모델을 각각 선택」) — 고르는 순간 저장
        #   ⚠ 작업은 **만들 때의 모델**로 돈다(작업마다 적혀 있다) — 여기서 바꾸면 그 뒤에 만드는 작업부터
        tf = ttk.LabelFrame(root, text='일마다 쓸 모델 — 고르면 바로 저장 · 생각 = 출력 단가로 청구(low 가 싸다)')
        tf.pack(fill='x', padx=8, pady=(2, 4))
        _TH = {'': '기본', 'low': 'low', 'high': 'high'}
        self._tm = {}
        with _db() as conn:
            for r_, (tk_, nm, _key, _d, _t) in enumerate(AC.TASK_SETTINGS):
                ttk.Label(tf, text=nm).grid(row=r_, column=0, sticky='w', padx=(6, 8), pady=1)
                mc = ttk.Combobox(tf, state='readonly', width=26, values=AC.MODEL_NAMES)
                mc.set(AC.task_model(conn, tk_))
                mc.grid(row=r_, column=1, sticky='w', pady=1)
                ttk.Label(tf, text='생각').grid(row=r_, column=2, sticky='e', padx=(10, 4))
                thc = ttk.Combobox(tf, state='readonly', width=6, values=list(_TH.values()))
                thc.set(_TH.get(AC.task_think(conn, tk_) or '', '기본'))
                thc.grid(row=r_, column=3, sticky='w', pady=1)
                def _save(_e=None, tk_=tk_, mc=mc, thc=thc):
                    inv = {v: k for k, v in _TH.items()}
                    with _db() as c2:
                        AC.set_task(c2, tk_, model=mc.get(), think=inv.get(thc.get(), ''))
                    self._conn_refresh()
                mc.bind('<<ComboboxSelected>>', _save)
                thc.bind('<<ComboboxSelected>>', _save)
                self._tm[tk_] = (mc, thc)
        # 옛 칸 이름 — [키 저장] 이 앱 기본(「그 밖」) 모델을 함께 저장한다
        self._m_cb = self._tm['OTHER'][0]

        self._c_txt = tk.Text(root, height=18, wrap='word')
        self._c_txt.pack(fill='both', expand=True, padx=8, pady=(6, 8))

    def _conn_say(self, s):
        self._c_txt.config(state='normal')
        self._c_txt.delete('1.0', 'end')
        self._c_txt.insert('end', s)
        self._c_txt.config(state='disabled')

    def _conn_refresh(self):
        """지금 상태 — **키는 가려서** 보인다."""
        try:
            with _db() as conn:
                ks = AC.keys(conn)
                mdl = AC.model_of(conn)
                saved = AC._cfg(conn, AC.MODEL_CFG, '')
                rows = AC.usage(conn)
                try:
                    import gcloud_gate as _gg
                    paused = _gg.paused(conn)
                except Exception:                         # noqa: BLE001
                    paused = False
                left = {m: AC.left_today(conn, m) for m in AC.MODEL_NAMES}
        except Exception as e:                            # noqa: BLE001
            self._conn_say('상태를 못 읽었습니다: %s' % e)
            return
        # ★ **실제로 쓰이는 모델**을 콤보에 올린다. 옛 판은 목록 밖이면
        #   아무것도 안 올려 **콤보가 빈 채**로 남았다 — 무엇으로 나가는지
        #   알 수 없다(§0-1). `model_of` 가 이미 옮겨 준 값을 보인다.
        self._m_cb.set(mdl)
        if saved and saved != mdl:
            L0 = ('⚠ 저장된 모델 「%s」 는 지금 쓸 수 없어 「%s」 로 '
                  '보냅니다 — [키 저장]을 한 번 누르면 설정도 바뀝니다.'
                  % (saved, mdl))
        else:
            L0 = ''
        L = []
        if L0:
            L.append(L0)
            L.append('')
        L.append('키 %d개 — %s' % (len(ks), ', '.join(AC.mask(k) for k in ks)
                                  or '(아직 없습니다)'))
        if not ks:
            L.append('  → 키가 없으면 아무것도 보낼 수 없습니다. '
                     'Google AI Studio 에서 발급해 위 칸에 넣고 [키 저장].')
        if paused:
            L.append('⚠ 구글 클라우드가 일시 중단 상태입니다 — 재개해야 나갑니다.')
        L.append('')
        L.append('⚠ 무료 등급에서는 보낸 글이 구글의 제품 개선에 쓰입니다'
                 '(유료 등급은 안 쓰입니다). 이 앱이 보내는 것은 우리가 쓴 '
                 '글과 공개 역본(개역한글·BSB)뿐이고, 저작권 역본 본문은 '
                 '보낼 자산 목록에 아예 없습니다.')
        L.append('')
        L.append('오늘 쓴 양')
        if not rows:
            L.append('  (아직 없습니다)')
        for m, c, o, i, u in rows:
            L.append('  %-24s 부름 %s · 됨 %s · 입력 %s토큰 · 출력 %s토큰'
                     % (m, format(c, ','), format(o, ','),
                        format(i, ','), format(u, ',')))
        L.append('')
        L.append('모델 (모델 이름은 실제로 불러서 확인했습니다. '
                 '하루 한도는 Google AI Studio 의 Rate limits 화면에서 '
                 '봅니다 — 한도는 키가 아니라 프로젝트 단위이고 '
                 '태평양 시간 자정에 리셋됩니다)')
        for n, rpd, rpm, om, iu, ou, fr, note in AC.MODELS:
            l, _cap = left.get(n, (None, 0))
            # ⚠ **모르는 것을 숫자로 적지 않는다** — 한도를 안 쟀으면
            #   `left_today` 가 `None` 을 낸다(§0-1). 그대로 「모름」이라 적는다.
            lim = ('하루 %s · 분당 %s (오늘 %s 남음)'
                   % (rpd, rpm, format(l, ',')) if l is not None
                   else '하루 한도 모름 (아직 재지 않았습니다)')
            L.append('  %-24s %s · 출력 %s토큰' % (n, lim, format(om, ',')))
            L.append('      유료 단가 입력 $%.2f · 출력 $%.2f (100만 토큰) · '
                     '무료 등급 %s' % (iu, ou, '가능' if fr else '불가'))
            L.append('      %s' % note)
        self._conn_say(chr(10).join(L))

    def _conn_save(self):
        raw = (self._k_var.get() or '').strip()
        # ⚠⚠ **콤보값을 그대로 믿지 않는다** — 앱을 켜 둔 채 모델 표가
        #   바뀌면 옛 이름이 콤보에 남아 있고, 그것을 그대로 저장하면
        #   **없는 모델이 설정에 눌러앉는다**(2026-09-23 실제로 당했다).
        mdl = self._m_cb.get() or AC.DEFAULT_MODEL
        moved = ''
        if mdl not in AC.MODEL_NAMES:
            moved = mdl
            mdl = AC.DEFAULT_MODEL
        # ⚠ 칸이 비면 **지우는 것이 아니다** — 가린 값을 보고 지우려 했을 수
        #   있으니 묻는다(§0-1 조용한 삭제 금지).
        with _db() as conn:
            cur = AC.keys(conn)
            if not raw and cur:
                if not messagebox.askyesno(
                        '키 저장', '칸이 비었습니다. 저장하면 키 %d개가 '
                                 '**모두 지워집니다**. 지울까요?' % len(cur)):
                    return
            n = AC.set_keys(conn, raw.split(',')) if raw or cur else 0
            AC._set_cfg(conn, AC.MODEL_CFG, mdl)
        self._k_var.set('')       # ★ 평문을 칸에 남겨 두지 않는다
        self._conn_refresh()
        msg = '키 %d개 · 모델 %s 로 저장했습니다.' % (n, mdl)
        if moved:
            msg += ('\n\n⚠ 고르신 「%s」 는 지금 쓸 수 있는 모델 목록에 '
                    '없어 「%s」 로 바꿔 저장했습니다.\n'
                    '   (관리자 앱을 켜 둔 채 목록이 바뀌면 옛 이름이 '
                    '콤보에 남아 있습니다 — 앱을 다시 켜면 새 목록이 뜹니다.)'
                    % (moved, mdl))
        messagebox.showinfo('키 저장', msg)

    def _conn_ping(self):
        """실제로 한 번 불러 본다 — **이 한 번도 한도를 쓴다.**"""
        if not messagebox.askyesno(
                '연결 시험', '실제로 한 번 불러 봅니다. 이 한 번도 하루 한도를 '
                           '씁니다. 할까요?'):
            return
        self._conn_say('부르는 중…')
        self.update_idletasks()
        with _db() as conn:
            r = AC.call('한 단어로만 답하세요: 안녕', conn=conn, max_out=32)
        if r['ok']:
            self._conn_say('됐습니다.\n  모델 %s · 키 %s · 토큰 %s\n  받은 글: %r'
                           % (r['model'], r['key'], r['tokens'], r['text'][:120]))
        else:
            self._conn_say('안 됐습니다 — %s' % r['why'])
        self.after(200, self._conn_refresh)


# 관리자 등록부가 찾는 이름
Panel = AiWorkshopPanel
