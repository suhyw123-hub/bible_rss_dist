# -*- coding: utf-8 -*-
"""admin/panel_app_info.py — **앱 소개 관리** (2026-10-21 · docs/1.txt 3번).

★ 사용자 「관리자화면에서 관리하고 필요할 때 자동전송 · 단순한 텍스트 관리만」.
  · 왼쪽 = 칸(앱 소개 · 만든 사람 · 홈페이지 · 개인정보 요약 · 이용약관 요약 · 문제 신고 · 후원)
  · 위 = [저장] [발행하기] [사용방법] · 언어 표시(누르면 그 언어로)
  · 가운데 = 제목 · 링크(주소·mailto) · 본문
  · 발행 = `rss_publish.publish_kind('appinfo')` (날마다 자동 배포에도 실린다 · 바뀐 것 없으면 안 보냄)
⚠ 읽고 쓰는 문은 `app_info` 하나.
"""
import os
import sys
import tkinter as tk
from tkinter import ttk

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP)
import appdb                                                    # noqa: E402
import app_info as AI                                           # noqa: E402

NAMES = {'INTRO': '앱 소개', 'MAKER': '만든 사람·연락처', 'HOME': '홈페이지', 'PRIVACY': '개인정보 처리방침(요약)',
         'TERMS': '이용약관(요약)', 'REPORT': '문제 신고·제안', 'DONATE': '후원 안내'}

HELP = [
    ('이 화면', '폰 왼쪽 위 앱 아이콘을 누르면 열리는 **앱 소개** 화면의 글을 고칩니다. 칸마다 제목 · 링크 · 본문을 적습니다.'),
    ('링크', '홈페이지는 https:// 로 시작하는 주소, 문제 신고는 mailto:주소 를 적으면 폰에서 누를 때 열립니다. 비우면 단추가 안 보입니다.'),
    ('저장 · 발행', '[저장]은 이 PC 에 적습니다. 글이 바뀌었을 때만 판 번호가 오릅니다. [발행하기]를 누르면 서버에 올라가고, '
                '날마다 자동 배포에도 실립니다(바뀐 것이 없으면 보내지 않습니다). 폰은 앱 소개를 열 때 새 판을 받습니다.'),
    ('언어', '위 언어 표시를 누르면 그 언어로 적습니다. 그 언어 글이 없으면 폰은 한국어 → 영어 순으로 보입니다.'),
    ('앱이 그리는 것', '출처·라이선스 목록과 앱 판 번호는 앱이 저절로 보입니다. 여기서 적지 않습니다.'),
]


def _C(role, fb):
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:                                           # noqa: BLE001
        return fb


class AppInfoPanel(ttk.Frame):
    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.conn = appdb.connect()
        AI.init(self.conn)
        self._sec = AI.SECTIONS[0][0]
        self._lang = 'KO'
        self._build()
        self._fill_list()
        self._load()

    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill='x', padx=8, pady=(8, 2))
        ttk.Button(top, text='저장', command=self._save).pack(side='left')
        ttk.Button(top, text='발행하기', command=self._publish).pack(side='left', padx=(6, 0))
        self._ver = ttk.Label(top, text='')
        self._ver.pack(side='left', padx=12)
        try:
            from admin.panel_help_box import build_help_button
        except Exception:                                       # noqa: BLE001
            from panel_help_box import build_help_button
        build_help_button(top, '앱 소개 관리 — 사용방법', HELP).pack(side='right')
        r2 = ttk.Frame(self)
        r2.pack(fill='x', padx=8, pady=(0, 2))
        ttk.Label(r2, text='언어').pack(side='left', anchor='n', padx=(0, 6))
        try:
            from admin.lang_badge import LangBadgeRow
        except Exception:                                       # noqa: BLE001
            from lang_badge import LangBadgeRow
        self._badges = LangBadgeRow(r2, on_pick=self._set_lang, per_row=11)
        self._badges.pack(side='left')
        self._msg = ttk.Label(self, text='', foreground=_C('accent', '#1A5276'))
        self._msg.pack(fill='x', padx=10)

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=6)
        lf = ttk.Frame(pw)
        self._lb = tk.Listbox(lf, exportselection=False, activestyle='none')
        self._lb.pack(fill='both', expand=True)
        self._lb.bind('<<ListboxSelect>>', lambda _e: self._pick())
        pw.add(lf, weight=1)
        rf = ttk.Frame(pw)
        pw.add(rf, weight=4)
        g = ttk.Frame(rf)
        g.pack(fill='x')
        ttk.Label(g, text='제목').grid(row=0, column=0, sticky='w', pady=2)
        self._title = tk.StringVar()
        ttk.Entry(g, textvariable=self._title).grid(row=0, column=1, sticky='ew', padx=6, pady=2)
        ttk.Label(g, text='링크').grid(row=1, column=0, sticky='w', pady=2)
        self._link = tk.StringVar()
        ttk.Entry(g, textvariable=self._link).grid(row=1, column=1, sticky='ew', padx=6, pady=2)
        g.columnconfigure(1, weight=1)
        ttk.Label(rf, text='본문').pack(anchor='w', pady=(6, 2))
        self._body = tk.Text(rf, wrap='word', height=14, bg=_C('bg', '#FFFFFF'), fg=_C('fg', '#222222'))
        self._body.pack(fill='both', expand=True)

    def _fill_list(self):
        self._lb.delete(0, 'end')
        for k, _ in AI.SECTIONS:
            self._lb.insert('end', NAMES.get(k, k))
        i = [k for k, _ in AI.SECTIONS].index(self._sec)
        self._lb.selection_set(i)
        self._ver.config(text='판 %d' % AI.version(self.conn))

    def _have_langs(self):
        return {r[0] for r in self.conn.execute(
            "SELECT lang_code FROM sys_app_info WHERE sec_key=? AND (TRIM(COALESCE(title,''))<>'' OR TRIM(COALESCE(body,''))<>'')",
            (self._sec,))}

    def _load(self):
        t, b, l = AI.get(self.conn, self._sec, self._lang)
        self._title.set(t)
        self._link.set(l)
        self._body.delete('1.0', 'end')
        self._body.insert('1.0', b)
        try:
            self._badges.set_have(self._have_langs(), current=self._lang)
        except Exception:                                       # noqa: BLE001
            pass

    def _dirty(self):
        return (self._title.get().strip(), self._body.get('1.0', 'end').strip(), self._link.get().strip()) != \
            AI.get(self.conn, self._sec, self._lang)

    def _pick(self):
        sel = self._lb.curselection()
        if not sel:
            return
        if self._dirty():
            self._save()
        self._sec = AI.SECTIONS[sel[0]][0]
        self._load()

    def _set_lang(self, code):
        if self._dirty():
            self._save()
        self._lang = code
        self._load()

    def _save(self):
        ch = AI.save(self.conn, self._sec, self._lang, self._title.get(), self._body.get('1.0', 'end'), self._link.get())
        self._ver.config(text='판 %d' % AI.version(self.conn))
        self._msg.config(text=('저장했습니다 — %s (%s). 폰에 보내려면 [발행하기].' % (NAMES.get(self._sec), self._lang))
                         if ch else '바뀐 것이 없습니다.')
        self._load()

    def _publish(self):
        if self._dirty():
            self._save()
        try:
            import rss_publish as P
            import time
            r = P.publish_kind(self.conn, P.get_servers(), 'appinfo', time.strftime('%Y-%m-%dT%H:%M:%S'))
            st = r.get('status')
            self._msg.config(text={'OK': '발행했습니다(판 %d). 폰은 앱 소개를 열 때 받습니다.' % AI.version(self.conn),
                                   'SKIP': '바뀐 것이 없어 보내지 않았습니다.'}.get(st, '발행하지 못했습니다: %s' % r.get('message')))
        except Exception as e:                                  # noqa: BLE001
            self._msg.config(text='발행하지 못했습니다: %s' % str(e)[:80])


def selftest():
    ok = []
    root = tk.Tk()
    root.withdraw()
    try:
        p = AppInfoPanel(root)
        p.pack()
        root.update()
        ok.append(p._lb.size() == len(AI.SECTIONS))
        ok.append(p._title.get() != '')
        p._lb.selection_clear(0, 'end')
        p._lb.selection_set(1)
        p._pick()
        ok.append(p._sec == 'MAKER')
        p._set_lang('EN')
        ok.append(p._title.get() == 'Made by')
    finally:
        root.destroy()
    print('panel_app_info %d/%d' % (sum(ok), len(ok)), ok)
    return all(ok)


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
