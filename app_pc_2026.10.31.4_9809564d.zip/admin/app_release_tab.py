# -*- coding: utf-8 -*-
"""배포 센터 ▸ 「앱 판」 탭 — **앱만** 새 판으로 내보낸다(2026-10-25 · `app_update`).

★ 사용자 「테스트 단계에서부터 데이터 이외의 업그레이드 방식을 확인하고 싶다」 · 「폰은 차선책으로」.
  [판 올리고 배포] 한 번 = 판 번호 올림(PC·폰 함께) → PC 코드 꾸러미 → (고르면) 폰 APK 만들기 → 서버에 올림 → 판 목록 갈아 끼움.
  사용자 PC 는 하루 한 번 확인해 미리 받고 알림 한 줄 · 폰은 홈 띠 「새 판 [받기]」.
⚠ 데이터(DB·팩)는 안 나간다 — 그것은 「배포 관리」의 몫이다.
⚠ 망·빌드는 일꾼 스레드 · 화면은 `after` 로(Tk 스레드 규칙).
"""
import os
import queue
import subprocess
import time
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import app_update as AU
import rss_publish as P
from admin.panel_help_box import help_row


class AppReleaseTab(ttk.Frame):
    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self._q = queue.Queue()
        help_row(self, '앱 판 — 앱만 새 판으로 내보냅니다', [
            ('무엇이 나가나',
             'PC = 앱 코드(.py · admin · icons · docs · browser_ext — 배포 꾸러미 ③과 같은 규칙) · '
             '폰 = 릴리스 APK(arm64). **DB·팩·사용자 자료는 한 바이트도 안 나갑니다.**'),
            ('사용자에게는',
             'PC — 하루 한 번 확인해 미리 받아 두고 앱 위에 「새 판 … 다시 켜면 바뀝니다」 한 줄. '
             '다시 켤 때 DB 를 열기 전에 갈아 끼우고, 바로 앞 판은 남겨 설정 ▸ 앱 관리에서 되돌릴 수 있습니다.\n'
             '폰 — 홈에 「새 판이 있습니다 [받기]」 → APK 를 받아 안드로이드가 설치합니다(내 자료는 그대로).'),
            ('주요 버튼',
             '[판 올리고 배포] 판 번호를 올리고(PC·폰 함께) 고른 것을 만들어 서버에 올립니다\n'
             '[서버 판 다시 읽기] 서버의 판 목록을 다시 읽습니다'),
            ('주의',
             '폰 APK 만들기는 몇 분 걸립니다. 이 PC 처럼 저장소(.git)가 있는 PC 는 개발 PC 라 스스로는 새 판을 받지 않습니다.'),
        ]).pack(fill='x', padx=6, pady=(6, 2))
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=6, pady=4)
        self._b_go = ttk.Button(bar, text='판 올리고 배포', command=self._go)
        self._b_go.pack(side='left')
        self._v_pc = tk.BooleanVar(value=True)
        self._v_apk = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text='PC 코드', variable=self._v_pc).pack(side='left', padx=(14, 4))
        ttk.Checkbutton(bar, text='폰 APK(만들어서)', variable=self._v_apk).pack(side='left', padx=4)
        ttk.Button(bar, text='서버 판 다시 읽기', command=self._read).pack(side='right')
        self._info = tk.Label(self, text='', anchor='w', justify='left')
        self._info.pack(fill='x', padx=10, pady=(2, 4))
        ttk.Label(self, text='바뀐 점 — 사용자 알림의 [바뀐 점]에 그대로 보입니다(한 줄에 하나)').pack(anchor='w', padx=10)
        self._notes = tk.Text(self, height=6, wrap='word')
        self._notes.pack(fill='x', padx=10, pady=(2, 6))
        ttk.Label(self, text='진행').pack(anchor='w', padx=10)
        self._log = tk.Text(self, height=12, wrap='word', state='disabled')
        self._log.pack(fill='both', expand=True, padx=10, pady=(2, 8))
        self.after(150, self._pump)
        self._read()

    def _say(self, s):
        self._log.config(state='normal')
        self._log.insert('end', s + '\n')
        self._log.see('end')
        self._log.config(state='disabled')

    def _servers(self):
        return [s for s in P.get_servers() if s.get('enabled')]

    def _read(self):
        self._info.config(text='이 PC 의 판 %s · 서버 판을 읽는 중…' % AU.current())
        threading.Thread(target=lambda: self._q.put(('MAN', AU.fetch_manifest(self._servers()))), daemon=True).start()

    def _go(self):
        if not self._servers():
            messagebox.showwarning('앱 판', '사용 중인 서버가 없습니다([서버 관리]).', parent=self)
            return
        pc, apk = self._v_pc.get(), self._v_apk.get()
        if not (pc or apk):
            return
        nv = AU.next_version(AU.current())
        what = ' · '.join(x for x, on in (('PC 코드', pc), ('폰 APK', apk)) if on)
        if not messagebox.askyesno('판 올리고 배포', '판 %s 로 올리고 %s 를 서버에 올립니다.\n사용자는 하루 안에 알림을 받습니다. 계속할까요?'
                                   % (nv, what), parent=self):
            return
        notes = self._notes.get('1.0', 'end').strip()
        self._b_go.state(['disabled'])
        self._say('── 판 %s ──' % nv)

        def work():
            old_v = AU.current()
            t0 = time.time()

            def lap(msg):
                self._q.put(('LOG', '%s · %d초' % (msg, int(time.time() - t0))))
            try:
                AU.write_version(nv)
                self._q.put(('LOG', '판 번호를 적었습니다(PC·폰)'))
                apk_path = None
                if apk:
                    self._q.put(('LOG', '폰 APK 를 만드는 중(몇 분)…'))
                    fl = os.path.join(os.path.dirname(AU.APP_DIR), 'tools', 'flutter', 'bin', 'flutter.bat')
                    env = dict(os.environ)
                    env['PATH'] = os.pathsep.join([os.path.dirname(fl), os.path.join(os.path.dirname(AU.APP_DIR), 'tools', 'jdk', 'bin'),
                                                   env.get('PATH', '')])
                    r = subprocess.run([fl, 'build', 'apk', '--release', '--split-per-abi', '--target-platform', 'android-arm64'],
                                       cwd=os.path.join(AU.APP_DIR, 'mobile'), env=env, capture_output=True,
                                       creationflags=0x08000000 if os.name == 'nt' else 0)
                    if r.returncode != 0 or not os.path.exists(AU.APK_SRC):
                        raise RuntimeError('APK 를 만들지 못했습니다\n' + (r.stderr or b'')[-800:].decode('utf-8', 'replace'))
                    apk_path = AU.APK_SRC
                    lap('APK 만들기 끝')
                man = AU.release(self._servers(), notes, pc=pc, apk_path=apk_path, version=nv,
                                 log=lap)
                lap('모두 끝')
                self._q.put(('DONE', man))
            except Exception as e:                       # noqa: BLE001
                # ★ 2026-10-29 올리지 못했으면 판 번호를 되돌린다(번호만 올라가 비던 것)
                try:
                    if AU.current() != old_v:
                        AU.write_version(old_v)
                        self._q.put(('LOG', '판 번호를 %s 로 되돌렸습니다' % old_v))
                except Exception:                        # noqa: BLE001
                    pass
                self._q.put(('FAIL', str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _pump(self):
        try:
            while True:
                tag, val = self._q.get_nowait()
                if tag == 'LOG':
                    self._say(val)
                elif tag == 'MAN':
                    self._show_man(val)
                elif tag == 'DONE':
                    self._b_go.state(['!disabled'])
                    self._say('끝 — 사용자에게 알림이 갑니다. 코드 판 번호 파일(app_version.py · 폰 pubspec)이 바뀌었으니 커밋하세요.')
                    self._show_man(val)
                elif tag == 'FAIL':
                    self._b_go.state(['!disabled'])
                    self._say('실패: ' + val)
        except queue.Empty:
            pass
        except tk.TclError:
            return
        try:
            self.after(200, self._pump)
        except tk.TclError:
            pass

    def _show_man(self, man):
        if not man:
            self._info.config(text='이 PC 의 판 %s · 서버에 아직 판 목록이 없습니다(처음 배포 전).' % AU.current())
            return
        pc, an = man.get('pc') or {}, man.get('android') or {}
        self._info.config(text='이 PC 의 판 %s · 서버 판 %s(%s)\nPC 코드 %s · 폰 APK %s'
                          % (AU.current(), man.get('version', '?'), man.get('date', ''),
                             '%s (%.1f MB)' % (pc.get('version'), (pc.get('size') or 0) / 1e6) if pc else '없음',
                             '%s (%.1f MB)' % (an.get('version'), (an.get('size') or 0) / 1e6) if an else '없음'))
        if man.get('notes') and not self._notes.get('1.0', 'end').strip():
            self._notes.insert('1.0', man['notes'])
