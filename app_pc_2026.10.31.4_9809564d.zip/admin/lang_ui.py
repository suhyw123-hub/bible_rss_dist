# -*- coding: utf-8 -*-
"""관리자 화면의 **언어 이름·언어 칩 단일 소스** (2026-09-18 신설·영구)

  python admin/lang_ui.py --selftest     # 의무

사용자 지시(1.txt 2-2) — 「번역텍스트 **언어라벨** : 관리자화면에 등장하는
모든 언어라벨을 **도서관리 화면의 방식으로 통일**하라」 · 「번역텍스트
**언어콤보** : 관리자화면에 등장하는 모든 언어콤보를 **영어로 통일**하라.
중국어는 Chinese(Simplified), Chinese(Tradition) 이라고 수정」.

★★★ **이름은 `sys_language.lang_name_en` 에서 온다 — 여기서 짓지 않는다.**
  그 칸에 이미 `Chinese (Simplified)` · `Chinese (Traditional)` 이 들어 있다
  (실측). 그래서 사용자가 요청한 표기는 **DB 가 이미 갖고 있던 값**이고,
  화면이 그것을 안 읽고 있던 것이 문제였다.

⚠⚠ **고치기 전 실측 — 관리자 네 화면이 저마다 표를 베껴 갖고 있었다**
  (`panel_book_manager`·`panel_commentary_manager`·`panel_dict_manager`·
  `panel_entity_manager`). 게다가 베낀 표가 서로 달라서 **한 콤보 안에서
  언어 이름이 영어와 현지어로 갈렸다**:
    도서관리 콤보 = `English · Korean · Chinese · 中文(繁體) · 日本語 ·
                    German · French · Spanish · Arabic · Русский · Português`
  빠진 언어는 `lang_config.lang_name`(현지어 우선)으로 떨어졌기 때문이다.
  ⇒ **표를 한 곳에 두고 네 화면이 그것을 읽는다.** 언어가 늘면 따라온다.

★ **사용자 화면은 그대로 둔다** — 거기서는 그 사람의 말로 보여야 한다
  (`lang_combo.py` 가 그 자리의 단일 소스다). 이 모듈은 **관리자 전용**이다.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tkinter as tk

import lang_config

#: 원문·사멸 언어처럼 `sys_language` 밖에서 오는 코드의 이름(자료에만 등장).
#  ⚠ 여기 적는 것은 **DB 에 없는 것만**이다 — 있는 것을 또 적으면 갈라진다.
EXTRA_NAME = {'LA': 'Latin'}

#: 칩 바탕색 — 언어를 한눈에 가르는 자리(도서관리 방식).
#  ⚠ 모르는 코드는 회색으로 떨어진다(조용히 안 빠뜨린다).
CHIP_BG = {
    'EN': '#1A5276', 'KO': '#922B21', 'ZH': '#1E8449', 'ZHT': '#148F77',
    'JA': '#6C3483', 'DE': '#784212', 'FR': '#0E6655', 'ES': '#D35400',
    'AR': '#117A65', 'RU': '#1A237E', 'PT': '#4A235A',
    'LA': '#5D4037', 'HE': '#37474F', 'EL': '#4E342E', 'COP': '#424242',
}
CHIP_FALLBACK = '#555555'


def codes():
    """관리자 콤보에 세울 언어 코드 — `sys_language(is_ui=1)` 차례 그대로."""
    return list(lang_config.ui_langs())


def name_en(code):
    """그 언어의 **영어 이름**(`sys_language.lang_name_en`).

    ⚠ `lang_config.lang_name` 은 **현지어 우선**이라 관리자 콤보에 쓰면
      안 된다 — 그것이 이번에 갈라진 까닭이다.
    """
    c = (code or '').upper()
    if not c:
        return code
    try:
        nm = lang_config.lang_name_en(c)
    except Exception:
        nm = ''
    if nm and nm != c:
        return nm
    return EXTRA_NAME.get(c, _fallback_name(c))


def _fallback_name(code):
    """DB 가 영어 이름을 안 주면 — **지어내지 않고** 있는 값을 쓴다."""
    try:
        nm = lang_config.lang_name(code)
    except Exception:
        nm = ''
    return nm or code


def names():
    """콤보 `values` — `codes()` 와 **같은 차례**."""
    return [name_en(c) for c in codes()]


def code_of(name):
    """콤보에서 선택한 이름 → 코드. 못 찾으면 대문자 두 글자(옛 동작)."""
    for c in codes():
        if name_en(c) == name:
            return c
    for c, n in EXTRA_NAME.items():
        if n == name:
            return c
    return (name or '').upper()[:2]


def chip_bg(code):
    return CHIP_BG.get((code or '').upper(), CHIP_FALLBACK)


def render_chips(parent, items):
    """`items = [(글자, 언어코드), …]` 를 색 칩으로 — **도서관리 방식**.

    ⚠ 그릴 때마다 비우고 다시 담는다(남은 칩이 거짓말을 한다).
    """
    for w in parent.winfo_children():
        w.destroy()
    for text, lang in items:
        bg = chip_bg(lang)
        chip = tk.Frame(parent, bg=bg, padx=5, pady=1)
        chip.pack(side='left', padx=3)
        # ★ 2026-10-27 (docs/1.txt 14-1) 칩 색은 **언어를 가르는 색**이다 — 테마가 칠하면 흰 글자만 회색이 되어
        #   어두운 화면에서 안 읽혔다(실측 ES·ZHT 대비 2.x). 견본처럼 칠하지 않는다(흰 글자 그대로 · 대비 3.9 이상).
        try:
            import ui_theme as _ut
            setattr(chip, _ut.SAMPLE, True)
        except Exception:
            pass
        tk.Label(chip, text=text, bg=bg, fg='white',
                 font=('Malgun Gothic', 8)).pack()


def name_combo(parent, code_var=None, codes_=None, extra=(), **kw):
    """**보이는 것은 영어 이름, 값은 코드**인 언어 콤보.

    ★ 화면이 들고 있는 변수(`code_var`)에는 **코드**가 그대로 남는다 —
      SQL·`lang_provider` 를 쓰는 자리를 한 줄도 안 고쳐도 된다.
    ⚠ 양방향이다 — 밖에서 `code_var.set('EN')` 해도 글자가 따라온다.
    """
    import tkinter as _tk
    from tkinter import ttk as _ttk
    cs = list(codes_ or codes())
    # ★ `extra` = 언어가 아닌 자리표(「(전체)」·「(any)」·「없음」).
    #   ⚠ 이름 표에 밀어 넣으면 안 된다 — 되돌릴 때 코드가 엉킨다.
    ex = [(str(d), str(v)) for d, v in (extra or ())]
    ex_d2c = {d: v for d, v in ex}
    ex_c2d = {v: d for d, v in ex}
    disp = _tk.StringVar()
    cb = _ttk.Combobox(parent, textvariable=disp, state='readonly',
                       values=[d for d, _v in ex] + [name_en(c) for c in cs],
                       **kw)

    def _c2d(c):
        return ex_c2d.get(c) or (name_en(c) if c else '')

    def _d2c(d):
        return ex_d2c[d] if d in ex_d2c else code_of(d)

    def _to_disp(*_a):
        c = (code_var.get() if code_var is not None else '') or ''
        disp.set(_c2d(c))

    def _to_code(*_a):
        if code_var is not None:
            code_var.set(_d2c(disp.get()))

    # ⚠⚠⚠ **이벤트가 아니라 변수 추적으로 잇는다**(2026-09-22 · 1.txt 9-6).
    #   `<<ComboboxSelected>>` 에 걸어 두면 화면이 같은 이벤트를 `add='+'`
    #   없이 다시 걸 때 **통째로 걷힌다** — 실측 네 화면 여섯 자리가 그랬고
    #   그중 가계도 카드 편집은 언어를 바꿔도 **아무 일이 안 났다**.
    #   변수 추적은 밖에서 무엇을 걸든 살아남는다.
    #   ⚠ 두 변수가 서로를 쓰므로 **되돌이를 막는다**.
    _busy = {'on': False}

    def _sync_disp(*_a):
        if _busy['on']:
            return
        _busy['on'] = True
        try:
            _to_disp()
        finally:
            _busy['on'] = False

    def _sync_code(*_a):
        if _busy['on']:
            return
        _busy['on'] = True
        try:
            _to_code()
        finally:
            _busy['on'] = False

    if code_var is not None:
        _to_disp()
        code_var.trace_add('write', _sync_disp)
    disp.trace_add('write', _sync_code)
    cb.bind('<<ComboboxSelected>>', _sync_code, add='+')
    cb._lang_code_var = code_var          # 밖에서 찾아 쓸 수 있게
    # ★★ **`get()` 을 쓰던 자리는 `_get_code()` 로 바꾼다** — `get()` 은
    #   이제 **이름**을 낸다. 안 고치면 「Korean」으로 조회해 조용히 0건이다.
    cb._set_code = lambda c: (code_var.set(c) if code_var is not None
                              else disp.set(_c2d(c)))
    cb._get_code = lambda: (code_var.get() if code_var is not None
                            else _d2c(disp.get()))
    return cb


def is_code(v):
    """그 글자가 **언어 코드**인가. 자리표·역본 코드는 아니다."""
    v = (str(v) or '').strip()
    if not v or len(v) > 4 or not v.replace('-', '').isalpha():
        return False
    up = v.upper()
    if up in {c.upper() for c in codes()}:
        return True
    try:
        import lang_config
        return up in {c.upper() for c in lang_config.all_langs()}
    except Exception:
        return False


def looks_lang_combo(vals):
    """값 목록이 **언어 콤보**인가 — 셋 이상이고 절반 넘게 언어 코드."""
    vals = [str(v) for v in (vals or ())]
    hit = [v for v in vals if is_code(v)]
    return len(hit) >= 3 and len(hit) >= len(vals) * 0.5


def retrofit(cb, force=False):
    """**이미 만든 콤보**를 이름으로 갈아 끼운다 → 그 콤보를 돌려준다.

    ★★★ **읽는 문을 안 건드린다** — `cb.get()` 은 그대로 **코드**를 내고
      `cb.set('KO')` 도 그대로 듣는다. 보이는 글자만 이름이 된다.
    ⚠ 언어 콤보가 아니면 **아무 일도 안 한다**(역본 코드 콤보 보호).
      정말로 강제할 때만 `force=True`.
    ⚠ 두 번 걸어도 안전하다(멱등).
    """
    import tkinter as _tk
    try:
        vals = [str(v) for v in (cb['values'] or ())]
    except Exception:                                         # noqa: BLE001
        return cb
    if getattr(cb, '_lang_named', False):
        # ⚠⚠ **값이 코드로 되덮였으면 다시 건다** — 화면이 나중에
        #   `cb['values'] = [...]` 로 채우면 이름이 통째로 사라진다.
        if not looks_lang_combo(vals):
            return cb
    if not vals or (not force and not looks_lang_combo(vals)):
        return cb

    # 자리표(언어가 아닌 값)는 글자 그대로 남긴다
    order = list(vals)
    lang_v = {v for v in vals if is_code(v)}

    def _c2d(c):
        c = '' if c is None else str(c)
        return name_en(c) if c in lang_v else c

    d2c = {}
    for v in order:
        d2c[_c2d(v)] = v

    def _d2c(d):
        d = '' if d is None else str(d)
        return d2c.get(d, code_of(d) if d else d)

    # 붙어 있던 변수는 **코드를 담는 변수**로 남기고 보이는 것만 새 변수로
    code_var = None
    try:
        nm = cb.cget('textvariable')
        if nm:
            code_var = _tk.StringVar(cb, name=str(nm))
    except Exception:                                         # noqa: BLE001
        code_var = None
    cur = cb.get()
    disp = _tk.StringVar(cb)
    cb.configure(values=[_c2d(v) for v in order], textvariable=disp)

    _busy = [False]

    def _to_disp(*_a):
        if _busy[0] or code_var is None:
            return
        _busy[0] = True
        try:
            disp.set(_c2d(code_var.get()))
        finally:
            _busy[0] = False

    def _to_code(*_a):
        if _busy[0] or code_var is None:
            return
        _busy[0] = True
        try:
            code_var.set(_d2c(disp.get()))
        finally:
            _busy[0] = False

    if code_var is not None:
        _to_disp()
        code_var.trace_add('write', _to_disp)
        cb.bind('<<ComboboxSelected>>', _to_code, add='+')
    else:
        disp.set(_c2d(cur))

    # ★★ **읽고 쓰는 문은 그대로** — 코드를 주고받는다
    # ⚠⚠ **두 번 감싸지 않는다** — 처음 것을 위젯에 붙들어 두고 다시 쓴다.
    #   겹쳐 감싸면 코드를 두 번 되돌려 엉뚱한 값이 된다.
    if getattr(cb, '_lang_raw', None) is None:
        cb._lang_raw = (cb.get, cb.set)
    _raw_get, _raw_set = cb._lang_raw
    cb.get = lambda: _d2c(_raw_get())
    cb.set = lambda v: _raw_set(_c2d(v))
    cb._get_code = cb.get
    cb._set_code = cb.set
    cb._lang_named = True
    # ⚠⚠⚠ **변수를 위젯에 붙들어 둔다** — 안 그러면 파이썬이 `StringVar` 를
    #   거둬 가며 Tk 변수까지 지워 **칸이 통째로 빈다**(실측으로 당했다.
    #   오류도 안 난다 — 그냥 아무것도 안 보인다).
    cb._lang_disp = disp
    cb._lang_codevar = code_var
    # ⚠⚠ **처음 값을 반드시 되살린다** — `ttk` 가 스스로 빈 변수를 달아 두는
    #   경우가 있어(실측) 그 빈 값이 보이는 칸을 덮는다. 그러면 화면에 아무
    #   것도 안 뜨고 `get()` 이 빈 글자를 낸다.
    if cur and cb.get() != cur:
        if code_var is not None:
            code_var.set(cur)
            _to_disp()
        else:
            _raw_set(_c2d(cur))

    def _set_codes(new_codes, keep=True):
        """값 목록을 **코드로** 다시 준다(화면이 나중에 채울 때)."""
        cur_code = cb.get()
        order[:] = [str(x) for x in (new_codes or [])]
        lang_v.clear()
        lang_v.update(v for v in order if is_code(v))
        d2c.clear()
        for v in order:
            d2c[_c2d(v)] = v
        cb.configure(values=[_c2d(v) for v in order])
        if keep and cur_code in order:
            cb.set(cur_code)

    cb.set_codes = _set_codes
    return cb


def retrofit_tree(w, n=[0]):
    """그 아래 **모든** 언어 콤보를 이름으로 → 바꾼 개수.

    ⚠ 지연 생성되는 콤보는 안 잡힌다 — 생성 자리에서 `retrofit` 을 부르는
      것이 정본이고 이 문은 **훑어보기·시험용**이다.
    """
    from tkinter import ttk as _ttk
    cnt = 0
    for ch in w.winfo_children():
        if isinstance(ch, _ttk.Combobox) and not getattr(ch, '_lang_named',
                                                         False):
            before = getattr(ch, '_lang_named', False)
            retrofit(ch)
            cnt += 1 if (getattr(ch, '_lang_named', False) and not before) \
                else 0
        cnt += retrofit_tree(ch)
    return cnt


def _selftest():
    ok = [0]
    bad = []

    def chk(name, cond, extra=''):
        if cond:
            ok[0] += 1
            print('  PASS %s %s' % (name, extra))
        else:
            bad.append(name)
            print('  FAIL %s %s' % (name, extra))

    print('lang_ui selftest')
    cs = codes()
    ns = names()
    chk('코드와 이름의 수가 같다', len(cs) == len(ns), (len(cs), len(ns)))
    chk('EN 은 English', name_en('EN') == 'English', name_en('EN'))
    chk('KO 는 Korean(현지어가 아니다)', name_en('KO') == 'Korean', name_en('KO'))
    # ★ 사용자가 물은 그 표기 — DB 값을 그대로 쓴다
    chk('ZH = Chinese (Simplified)',
        'Simplified' in name_en('ZH'), name_en('ZH'))
    chk('ZHT = Chinese (Traditional)',
        'Traditional' in name_en('ZHT'), name_en('ZHT'))
    # ⚠ 옛 함정 — 한 콤보에 영어와 현지어가 섞여 있었다
    hangul = [n for n in ns if any('가' <= ch <= '힣' for ch in n)]
    cjk = [n for n in ns if any('一' <= ch <= '鿿' for ch in n)]
    cyr = [n for n in ns if any('Ѐ' <= ch <= 'ӿ' for ch in n)]
    chk('이름이 전부 라틴 글자다(섞임 0)',
        not (hangul or cjk or cyr), hangul + cjk + cyr)
    chk('이름이 겹치지 않는다', len(set(ns)) == len(ns))
    chk('이름 → 코드 왕복', all(code_of(name_en(c)) == c for c in cs))
    chk('DB 밖 코드도 이름이 있다', name_en('LA') == 'Latin')
    chk('모르는 코드는 그대로', name_en('XX') == 'XX', name_en('XX'))
    chk('칩 색이 언어마다 다르다',
        len({chip_bg(c) for c in cs}) >= len(cs) - 1)
    chk('모르는 코드 칩은 회색', chip_bg('XX') == CHIP_FALLBACK)
    # 실제로 그려 본다 — 위젯이 붙고 비워진다
    try:
        root = tk.Tk()
        root.withdraw()
        f = tk.Frame(root)
        render_chips(f, [('원문·EN', 'EN'), ('번역·KO', 'KO')])
        n1 = len(f.winfo_children())
        render_chips(f, [('원문·EN', 'EN')])
        n2 = len(f.winfo_children())
        root.destroy()
        chk('칩을 그리고 다시 그리면 남지 않는다', (n1, n2) == (2, 1), (n1, n2))
    except Exception as e:
        chk('칩을 그리고 다시 그리면 남지 않는다', False, e)
    # ★ 이름 콤보 — 보이는 글자와 값이 따로 논다
    try:
        import tkinter as _tk
        root = _tk.Tk()
        root.withdraw()
        var = _tk.StringVar(value='KO')
        cb = name_combo(root, var)
        chk('콤보 값은 이름', 'Korean' in list(cb['values']))
        chk('처음 글자가 코드를 따라간다', cb.get() == 'Korean', cb.get())
        var.set('ZHT')
        chk('밖에서 코드를 바꾸면 글자가 따라온다',
            cb.get() == 'Chinese (Traditional)', cb.get())
        cb.set('Japanese')
        cb.event_generate('<<ComboboxSelected>>')
        root.update()
        chk('선택하면 변수에는 코드가 들어간다', var.get() == 'JA', var.get())
        chk('코드로 직접 세울 수 있다',
            (cb._set_code('DE'), cb._get_code())[1] == 'DE')
        root.destroy()
    except Exception as e:
        chk('이름 콤보', False, e)
    # ★ 자리표가 섞인 콤보 — 이름 표에 안 밀려 들어간다
    try:
        import tkinter as _tk
        root = _tk.Tk()
        root.withdraw()
        v2 = _tk.StringVar(value='(전체)')
        cb2 = name_combo(root, v2, extra=[('(전체)', '(전체)')])
        chk('자리표가 맨 앞에', list(cb2['values'])[0] == '(전체)',
            list(cb2['values'])[:2])
        chk('자리표는 글자가 그대로', cb2.get() == '(전체)', cb2.get())
        v2.set('KO')
        chk('언어는 이름으로 바뀐다', cb2.get() == 'Korean', cb2.get())
        cb2.set('(전체)')
        cb2.event_generate('<<ComboboxSelected>>')
        root.update()
        chk('자리표를 선택하면 값도 자리표', v2.get() == '(전체)', v2.get())
        # 변수 없는 콤보 — `_get_code` 가 코드를 낸다
        cb3 = name_combo(root, None, extra=[('(any)', '(any)')])
        cb3._set_code('JA')
        chk('변수 없이도 코드를 세운다', cb3._get_code() == 'JA', cb3._get_code())
        chk('그때 보이는 글자는 이름', cb3.get() == 'Japanese', cb3.get())
        cb3._set_code('(any)')
        chk('변수 없이도 자리표가 산다',
            cb3._get_code() == '(any)' and cb3.get() == '(any)')
        root.destroy()
    except Exception as e:
        chk('자리표 콤보', False, e)
    # ★ retrofit — 이미 만든 콤보를 갈아 끼운다(읽는 문은 그대로)
    try:
        import tkinter as _tk
        from tkinter import ttk as _ttk
        root = _tk.Tk()
        root.withdraw()

        # ⓐ 변수 없는 콤보 — get()/set() 이 코드를 그대로 주고받는다
        c1 = _ttk.Combobox(root, values=['KO', 'EN', 'ZH', 'JA'],
                           state='readonly')
        c1.set('KO')
        retrofit(c1)
        chk('보이는 글자가 이름', c1.cget('values')[0] == 'Korean',
            c1.cget('values')[:2])
        chk('get() 은 여전히 코드', c1.get() == 'KO', c1.get())
        c1.set('JA')
        chk('set(코드) 도 그대로', c1.get() == 'JA', c1.get())
        chk('두 번 걸어도 같다', (retrofit(c1), c1.get())[1] == 'JA')

        # ⓑ 자리표가 섞인 콤보
        c2 = _ttk.Combobox(root, values=['(전체)', 'KO', 'EN', 'ZH', 'JA'],
                           state='readonly')
        c2.set('(전체)')
        retrofit(c2)
        chk('자리표는 글자 그대로', list(c2.cget('values'))[0] == '(전체)',
            list(c2.cget('values'))[:2])
        chk('자리표를 그대로 읽는다', c2.get() == '(전체)', c2.get())
        c2.set('ZH')
        chk('자리표 콤보에서도 코드', c2.get() == 'ZH', c2.get())

        # ⓒ 변수가 붙은 콤보 — 변수에는 코드가 남는다
        v3 = _tk.StringVar(value='KO')
        c3 = _ttk.Combobox(root, textvariable=v3, state='readonly',
                           values=['KO', 'EN', 'ZH', 'JA'])
        retrofit(c3)
        chk('변수에는 코드', v3.get() == 'KO', v3.get())
        v3.set('EN')
        root.update()
        chk('변수를 바꾸면 글자가 따라온다',
            c3.cget('values') and c3.get() == 'EN', (v3.get(), c3.get()))

        # ⓓ **언어 콤보가 아니면 안 건드린다**(역본 코드 보호)
        c4 = _ttk.Combobox(root, values=['KRV', 'BSB', 'NIV', 'WEB'],
                           state='readonly')
        c4.set('KRV')
        retrofit(c4)
        chk('역본 콤보는 그대로', list(c4.cget('values'))[0] == 'KRV'
            and not getattr(c4, '_lang_named', False),
            list(c4.cget('values'))[:2])

        # ⓔ 값을 다시 채울 수 있다
        c1.set_codes(['DE', 'FR', 'ES'])
        chk('다시 채워도 이름', list(c1.cget('values'))[0] == 'German',
            list(c1.cget('values'))[:2])

        # ⓕ 훑어보기
        box = _ttk.Frame(root)
        _ttk.Combobox(box, values=['KO', 'EN', 'ZH']).pack()
        _ttk.Combobox(box, values=['KRV', 'BSB']).pack()
        chk('훑어보기가 언어 콤보만 센다', retrofit_tree(box) == 1)
        # ⓖ 값이 코드로 되덮여도 다시 건다(겹쳐 감싸지 않는다)
        c5 = _ttk.Combobox(root, values=['KO', 'EN', 'ZH'], state='readonly')
        c5.set('KO')
        retrofit(c5)
        c5.configure(values=['KO', 'EN', 'ZH', 'JA'])      # 화면이 되덮었다
        retrofit(c5)
        chk('되덮여도 이름으로 돌아온다',
            list(c5.cget('values'))[0] == 'Korean', list(c5.cget('values'))[:2])
        c5.set('JA')
        chk('되건 뒤에도 코드를 낸다', c5.get() == 'JA', c5.get())
        root.destroy()
    except Exception as e:
        chk('retrofit', False, e)
    print('lang_ui selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    return 1 if bad else 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        raise SystemExit(_selftest())
    for _c in codes():
        print('%-4s %s' % (_c, name_en(_c)))
