# -*- coding: utf-8 -*-
"""모바일 팩 관리 ▸ ② 서버 — 폰 팩 전부 · ③ 스토어 초판 (2026-10-12 · 영구 · `--selftest` 의무).

사용자 「다운로드 처음 시작은 PC 가 아니라 모바일 앱」 · 「개별팩도 초판은 앱스토어에서 받고 수정본은 무료 서버」 ·
「관리자가 앱스토어에 게시할 팩 만드는 기능과 화면도 자세히 살펴보아라」.

② 서버 — 폰이 혼자 받는 팩 전부(공통 · 언어 11 · 유튜브 · 사진 · AI 기본 꾸러미 11 · 도서)를 만들고 **바뀐 것만** 올린다.
   서버 목록(mobile_index.json)에 종류·언어·도서 제목이 실려 폰 「자료 받기」가 그 목록으로 고른다.
③ 스토어 초판 — ②에서 만든 팩을 스토어 자산 팩 단위(core · lang_<언어> · books_<언어>)로 묶고 상한을 점검한다.
   결과 폴더 = `_store_dist/<판>/android`(구글 앱 번들에 넣는 모양) · `apple`(애플 자산 팩 재료) · `store_index.json`
   (폰 앱 assets 에 넣는다). ★ 해마다 스토어에 올리는 연례 업데이트 때 이 판을 새로 묶는다.
⚠ 만들기·묶기는 일꾼 스레드에서 한다(수십 초) — 화면은 큐로 받는다(§279차 ⑭).
"""
import os
import queue
import subprocess
import threading
import tkinter as tk
from tkinter import ttk

MB = 1e6


def _C(role, fb):
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb


def _tree(parent, cols):
    tv = ttk.Treeview(parent, columns=[c for c, *_ in cols], show='headings', selectmode='browse')
    for c, txt, w, an in cols:
        tv.heading(c, text=txt)
        tv.column(c, width=w, anchor=an, stretch=(an == 'w'))
    sb = ttk.Scrollbar(parent, orient='vertical', command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(fill='both', expand=True)
    return tv


class _Worker:
    """단추 → 일꾼 스레드 → 큐 → after 로 화면에 적는다."""

    def _setup_q(self):
        self._q = queue.Queue()
        self._busy = False
        self.after(200, self._poll)

    def _poll(self):
        try:
            while True:
                kind, val = self._q.get_nowait()
                if kind == 'msg':
                    self._msg.config(text=val)
                elif kind == 'done':
                    self._busy = False
                    for b in self._btns:
                        b.config(state='normal')
                    self.reload()
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(200, self._poll)

    def _run(self, label, fn):
        if self._busy:
            return
        self._busy = True
        for b in self._btns:
            b.config(state='disabled')
        self._msg.config(text=label)

        def work():
            try:
                self._q.put(('msg', fn()))
            except Exception as e:                       # noqa: BLE001
                self._q.put(('msg', '실패: %s' % str(e)[:160]))
            self._q.put(('done', None))
        threading.Thread(target=work, daemon=True).start()


class ServerTab(ttk.Frame, _Worker):
    def __init__(self, master, db_path):
        super().__init__(master)
        self.db = db_path
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        b1 = ttk.Button(bar, text='서버용 전부 만들기', command=self._make)
        b2 = ttk.Button(bar, text='바뀐 것 서버에 올리기', command=self._upload)
        b3 = ttk.Button(bar, text='폴더 열기', command=lambda: _open_dir(_mc().OUT_DIR))
        for b in (b1, b2, b3):
            b.pack(side='left', padx=(0, 6))
        self._btns = (b1, b2)
        self._msg = ttk.Label(bar, text='')
        self._msg.pack(side='left', padx=8)
        tk.Label(self, anchor='w', justify='left', wraplength=1100, foreground=_C('fg_dim', '#666666'),
                 text='폰이 PC 없이 혼자 받는 팩 전부입니다(공통 · 언어 11 · 유튜브 · 사진 · AI 기본 꾸러미 11 · 도서). '
                      '올리면 서버 목록(mobile_index.json)에 종류·언어·도서 제목이 함께 실리고, 폰 「설정 ▸ 자료 받기」가 '
                      '그 목록으로 선택합니다. [바뀐 것 서버에 올리기]는 올린 뒤 바뀐 파일만 올립니다.'
                 ).pack(fill='x', padx=10, pady=(0, 4))
        self._sum = ttk.Label(self, text='', anchor='w')
        self._sum.pack(fill='x', padx=10)
        box = ttk.Frame(self)
        box.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        self._tv = _tree(box, (('name', '파일', 330, 'w'), ('kind', '종류', 80, 'center'),
                               ('lang', '언어', 60, 'center'), ('title', '도서 제목', 260, 'w'),
                               ('mb', 'MB', 70, 'e'), ('st', '서버', 110, 'center')))
        self._setup_q()
        self.reload()

    def reload(self):
        import appdb
        MC = _mc()
        self._tv.delete(*self._tv.get_children())
        c = appdb.connect(self.db)
        try:
            idx = MC.index_of(MC.OUT_DIR, c)
        finally:
            c.close()
        st = MC._up_state(MC.OUT_DIR)
        n_up = 0
        for n, e in idx.items():
            up = st.get(n) == MC._sig(os.path.join(MC.OUT_DIR, n))
            n_up += up
            self._tv.insert('', 'end', values=(n, e['kind'], e['lang'], e.get('title', ''),
                                                '%.2f' % (e['bytes'] / MB), '올림' if up else '안 올림'))
        tot = sum(e['bytes'] for e in idx.values())
        self._sum.config(text='팩 %d개 · 합계 %.1f MB · 서버에 올린 그대로인 것 %d · 올릴 것 %d'
                         % (len(idx), tot / MB, n_up, len(idx) - n_up))

    def _make(self):
        import appdb
        MC = _mc()

        def fn():
            c = appdb.connect(self.db)
            try:
                ps = MC.build_server_set(c, MC.OUT_DIR, log=lambda *a: None)
            finally:
                c.close()
            return '만듦 %d개 · %.1f MB' % (len(ps), sum(os.path.getsize(p) for p in ps) / MB)
        self._run('만드는 중… (1~3분)', fn)

    def _upload(self):
        MC = _mc()

        def fn():
            import rss_publish
            r = MC.upload_all(rss_publish.get_servers(), MC.OUT_DIR)
            return ('올림 %d개' % len(r['files'])) if r['ok'] else '못 올림: %s' % ' · '.join(r['msgs'])[:160]
        self._run('올리는 중…', fn)


class StoreTab(ttk.Frame, _Worker):
    def __init__(self, master):
        super().__init__(master)
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Label(bar, text='판(날짜)').pack(side='left')
        import time
        self._ed = tk.StringVar(value=time.strftime('%Y-%m-%d'))
        ttk.Entry(bar, textvariable=self._ed, width=12).pack(side='left', padx=(4, 8))
        b1 = ttk.Button(bar, text='스토어 초판 묶기', command=self._build)
        b2 = ttk.Button(bar, text='스토어 폴더 열기', command=lambda: _open_dir(_mc().STORE_DIR))
        for b in (b1, b2):
            b.pack(side='left', padx=(0, 6))
        self._btns = (b1,)
        self._msg = ttk.Label(bar, text='')
        self._msg.pack(side='left', padx=8)
        tk.Label(self, anchor='w', justify='left', wraplength=1100, foreground=_C('fg_dim', '#666666'),
                 text='② 서버 탭에서 만든 폰 팩을 스토어 자산 팩으로 묶습니다 — core(설치 때 · 공통·유튜브·사진·AI 기본), '
                      'lang_<언어>(요청할 때), books_<언어>(요청할 때). 결과 폴더의 android 는 구글 앱 번들에, apple 은 애플 자산 '
                      '팩에, store_index.json 은 폰 앱 assets 에 넣습니다. 스토어에 있는 판보다 서버 판이 새것이면 폰은 서버에서 '
                      '그 팩만 받습니다. 스토어는 해마다 한 번(의무 업데이트 때) 새 판으로 바꿔 올립니다.'
                 ).pack(fill='x', padx=10, pady=(0, 4))
        pw = ttk.PanedWindow(self, orient='vertical')
        pw.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        top, bot = ttk.Frame(pw), ttk.Frame(pw)
        pw.add(top, weight=3)
        pw.add(bot, weight=1)
        self._tv = _tree(top, (('pack', '자산 팩', 140, 'center'), ('dl', '받는 때', 120, 'center'),
                               ('n', '파일', 60, 'e'), ('mb', 'MB', 80, 'e'), ('files', '담은 파일', 520, 'w')))
        self._ck = _tree(bot, (('ok', '', 40, 'center'), ('what', '점검', 260, 'w'),
                               ('v', '값', 140, 'e'), ('lim', '상한', 140, 'e')))
        self._setup_q()
        self.reload()

    def reload(self):
        MC = _mc()
        plan = MC.store_plan(MC.OUT_DIR)
        self._tv.delete(*self._tv.get_children())
        for pk, e in sorted(plan.items(), key=lambda x: (x[1]['delivery'] != 'install-time', x[0])):
            self._tv.insert('', 'end', values=(pk, '설치 때' if e['delivery'] == 'install-time' else '요청할 때',
                                                len(e['files']), '%.2f' % (e['bytes'] / MB),
                                                ' · '.join(e['files'])[:300]))
        self._ck.delete(*self._ck.get_children())
        for what, v, lim, ok in MC.store_checks(plan):
            cnt = what == '자산 팩 개수'
            self._ck.insert('', 'end', values=('✔' if ok else '✘', what, ('%d' % v) if cnt else '%.1f MB' % (v / MB),
                                                ('%d' % lim) if cnt else '%.0f MB' % (lim / MB)))
        eds = sorted(os.listdir(MC.STORE_DIR)) if os.path.isdir(MC.STORE_DIR) else []
        if not self._busy:
            self._msg.config(text=('묶어 둔 판: %s' % ', '.join(eds[-3:])) if eds else '아직 묶은 판이 없습니다')

    def _build(self):
        MC = _mc()
        ed = self._ed.get().strip() or None

        def fn():
            r = MC.build_store(ed)
            bad = [w for w, _v, _l, ok in r['checks'] if not ok]
            return '묶음 %s — 자산 팩 %d개%s' % (r['index']['edition'], len(r['plan']),
                                           (' · ⚠ 상한 넘음: ' + ', '.join(bad)) if bad else ' · 상한 모두 통과')
        self._run('묶는 중…', fn)


def _mc():
    import db_mobile_core as MC
    return MC


def _open_dir(d):
    os.makedirs(d, exist_ok=True)
    try:
        os.startfile(d)                                   # noqa: S606 — 관리자 PC(윈도우)
    except Exception:
        subprocess.Popen(['explorer', d])


def selftest():
    import tempfile
    MC = _mc()
    ok = tot = 0

    def t(nm, c):
        nonlocal ok, tot
        tot += 1
        ok += bool(c)
        print(('PASS ' if c else 'FAIL ') + nm)
    with tempfile.TemporaryDirectory() as d:
        for n, size in (('mobile_common.json.gz', 10), ('mobile_youtube.json.gz', 5), ('mobile_lang_KO.json.gz', 7),
                        ('mobile_ai_KO.json.gz', 1), ('mobile_book_X_KO.json.gz', 3), ('mobile_book_Y_EN.json.gz', 4),
                        ('mobile_core_KO.json.gz', 9), ('readme.txt', 1)):
            with open(os.path.join(d, n), 'wb') as f:
                f.write(b'x' * size)
        p = MC.store_plan(d)
        t('core = 공통·유튜브·AI(설치 때)', sorted(p['core']['files']) ==
          ['mobile_ai_KO.json.gz', 'mobile_common.json.gz', 'mobile_youtube.json.gz']
          and p['core']['delivery'] == 'install-time')
        t('언어팩·도서는 언어마다 요청할 때', p['lang_ko']['delivery'] == 'on-demand'
          and p['books_ko']['files'] == ['mobile_book_X_KO.json.gz'] and 'books_en' in p)
        t('옛 판·다른 파일은 안 묶는다', not any('mobile_core_' in f or 'readme' in f
                                        for e in p.values() for f in e['files']))
        t('자산 팩 이름 규칙(소문자·밑줄)', all(k == k.lower() and k.replace('_', '').isalnum() for k in p))
        r = MC.build_store('T', d, os.path.join(d, 'store'))
        t('구글 모양 — build.gradle + assets/<팩>/파일',
          os.path.exists(os.path.join(r['dir'], 'android', 'lang_ko', 'build.gradle'))
          and os.path.exists(os.path.join(r['dir'], 'android', 'lang_ko', 'src', 'main', 'assets', 'lang_ko',
                                          'mobile_lang_KO.json.gz')))
        t('store_index 에 판·sha', r['index']['edition'] == 'T'
          and r['index']['packs']['core']['files']['mobile_common.json.gz'] == MC.sha16(os.path.join(d, 'mobile_common.json.gz')))
        t('상한 점검 다섯이 다 통과', len(r['checks']) == 5 and all(c[3] for c in r['checks']))
    print('%d/%d' % (ok, tot))
    return ok == tot


if __name__ == '__main__':
    import sys
    sys.exit(0 if selftest() else 1)
