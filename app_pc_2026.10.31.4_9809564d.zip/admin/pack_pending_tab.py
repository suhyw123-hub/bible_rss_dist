# -*- coding: utf-8 -*-
"""admin/pack_pending_tab.py — **배포 대기(바뀐 것)** 화면 (2026-09-29 293차 신설).

★★★ 왜 (사용자 · `docs/1.txt` 22-2 「자산유형별 배포주기를 고정하지 말고, **직전
  배포일자 이후로 지금까지 수정된 것을 모두 배포**하는 방식은 어떤가? … 수시 수동배포
  기능이 제일 많이 활용될 것 같다 … 연결된 테이블은 한꺼번에 … 릴리스 패킹 탭 화면과
  내부 구조/기능 수정방향을 제시하라」).
  · 주기 화면(`pack_release_tab`)을 걷고 **「지금 무엇이 바뀌어 있나」** 한 표로 바꿨다.
    바뀐 것 = 판이 오른 자산(`db_pack_publish.plan` 의 build/upload) + 코어 표의 변경
    (`db_pack_fresh.check`). 세는 문은 그 둘이고 여기서 다시 세지 않는다.
  · 단추 둘 — **[바뀐 것 만들기]**(낡은 팩을 다시 만든다) · **[만든 것 올리기]**(안 올린
    파일을 서버에). 정기 자동은 영상 연결·최신 콘텐츠 둘뿐이고(「자동 배포」 탭) 나머지는
    여기서 사람이 누른다.
  · 「연결된 표를 한꺼번에」 = **릴리스 번호**가 이미 그 몫이다(코어가 기준, 본문팩은 그
    번호를 넘지 못한다). 여기서는 코어가 낡았으면 맨 위에 그것을 먼저 말한다.
  · 스위치 하나 — **자산 목록을 사용자에게 보인다**(`PACK_PUBLISH_ITEMS`). 켜야 manifest 에
    `items` 가 실려 사용자 다운로드 화면이 개별 자산을 보인다(정비 중 꺼 두었다).
⚠ 만들기·올리기는 스레드로 돈다(코어 40초·설교 한 권 2분) · 화면은 큐 폴링.
⚠ 옛 주기 화면은 파일로 남긴다(`pack_release_tab.py` · 되돌릴 자리) — `sys_pack_plan`
  은 코어 파일 이름(`corepack_<주기>`)에 여전히 쓰인다.
"""
import os
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import appdb                                                    # noqa: E402

DB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                  'bible_master.db')
MB = 1048576


def gather(conn):
    """화면이 그릴 것 전부 → dict. **세는 문은 남의 것**(plan · fresh · pending)."""
    import db_pack_publish as PP
    import db_pack_fresh as FR
    import db_linkpack_build as LB
    pl = PP.plan(conn)
    try:
        n_bad, why = FR.check(conn)
    except Exception as e:                                   # noqa: BLE001
        n_bad, why = 1, '코어 낡음 판정 실패: %s' % str(e)[:60]
    try:
        items_on = LB.publish_items_on(conn)
    except Exception:
        items_on = False
    rows = []
    for t in pl['rows']:
        if not t['exists']:
            st = 'MAKE'          # 아직 안 만듦
        elif t['stale']:
            st = 'STALE'         # 판이 올랐다 — 다시 만든다
        elif t in pl['upload']:
            st = 'UPLOAD'        # 만들었는데 안 올렸다
        else:
            st = 'DONE'
        rows.append(dict(t, st=st))
    return {'rows': rows, 'build': pl['build'], 'upload': pl['upload'],
            'warn': pl['warn'], 'orphan': pl['orphan'], 'bytes': pl['bytes'],
            'core_bad': n_bad, 'core_why': why, 'items_on': items_on}


STATE_LABEL = {'MAKE': '아직 안 만듦', 'STALE': '판이 올랐다 — 다시 만들 것',
               'UPLOAD': '만듦 · 안 올림', 'DONE': '최신 · 올림'}


class PackPendingTab(ttk.Frame):
    def __init__(self, master, db=None, **kw):
        super().__init__(master, **kw)
        self.db = db or DB
        self._q = queue.Queue()
        self._busy = False
        self._build()
        self.after(60, self.reload)
        self.after(300, self._pump)

    def _build(self):
        from admin.panel_help_box import help_row
        help_row(self, '배포 대기 — 바뀐 것', [
            ('이 탭의 기능',
             '**직전 발행 이후 바뀐 것**만 한 표로 봅니다 — 판이 오른 자산(다시 만들 것), '
             '만들었는데 안 올린 것, 그리고 코어 표가 팩을 만든 뒤 바뀌었는지. '
             '주기(매일·연 2회)로 배포하지 않습니다. 바뀐 것이 없으면 올릴 것도 없습니다.'),
            ('주요 버튼',
             '[바뀐 것 만들기] 판이 올랐거나 아직 없는 팩을 다시 만듭니다(코어가 낡았으면 코어부터)\
'
             '[만든 것 올리기] 만들어 두고 안 올린 파일을 서버에 올립니다 — manifest 는 늘 마지막\
'
             '[새로 고침] 다시 셉니다'),
            ('연결된 표는 한꺼번에',
             '코어팩이 릴리스의 기준이고 본문팩은 그 번호를 넘지 못합니다. 코어가 낡았으면 '
             '맨 위 줄이 먼저 말합니다 — 본문만 올리면 사용자가 새 본문을 옛 연결로 읽습니다.'),
            ('정기 자동은 둘뿐',
             '영상 연결(델타)과 최신 콘텐츠는 「자동 배포」 탭이 매일 올립니다. '
             '도서·사전·설명문·코어는 고쳤을 때 여기서 사람이 올립니다.'),
            ('자산 목록을 사용자에게 보인다',
             '이 스위치를 켜면 manifest 에 자산 목록이 실려 사용자 다운로드 화면이 개별 자산을 '
             '보입니다. 정비 중에는 꺼 두었습니다 — 팩을 올린 뒤에 켜십시오(목록만 있고 팩이 없으면 '
             '사용자가 눌러도 「서버에 없다」만 나옵니다).'),
        ])
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        self._b_make = ttk.Button(bar, text='바뀐 것 만들기', command=self._make)
        self._b_make.pack(side='left')
        self._b_up = ttk.Button(bar, text='만든 것 올리기', command=self._upload)
        self._b_up.pack(side='left', padx=(6, 0))
        ttk.Button(bar, text='새로 고침', command=self.reload).pack(side='left', padx=(6, 0))
        self._items_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text='자산 목록을 사용자에게 보인다(manifest items)',
                        variable=self._items_var, command=self._toggle_items
                        ).pack(side='left', padx=(16, 0))
        self._msg = ttk.Label(bar, text='')
        self._msg.pack(side='left', padx=(10, 0))
        self._head = ttk.Label(self, text='', justify='left', anchor='w')
        self._head.pack(fill='x', padx=12, pady=(2, 4))

        cols = ('kind', 'key', 'lang', 'ver', 'mb', 'st')
        tv = ttk.Treeview(self, columns=cols, show='headings', selectmode='browse')
        for c_, txt, w_, an in (('kind', '갈래', 90, 'w'), ('key', '자산', 300, 'w'),
                                ('lang', '언어', 50, 'center'), ('ver', '판', 50, 'center'),
                                ('mb', '크기(MB)', 70, 'e'), ('st', '상태', 200, 'w')):
            tv.heading(c_, text=txt)
            tv.column(c_, width=w_, stretch=(c_ == 'key'), anchor=an)
        sb = ttk.Scrollbar(self, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y', pady=(0, 8))
        tv.pack(fill='both', expand=True, padx=(8, 0), pady=(0, 8))
        tv.tag_configure('todo', foreground='#B03A2E')
        self._tv = tv
        self._rows = []

    # ── 채우기 ─────────────────────────────────────────────────────
    def reload(self):
        try:
            with appdb.connect(self.db) as c:
                g = gather(c)
        except Exception as e:                               # noqa: BLE001
            self._head.config(text='셀 수 없습니다: %s' % str(e)[:80])
            return
        self._items_var.set(bool(g['items_on']))
        tv = self._tv
        tv.delete(*tv.get_children())
        self._rows = g['rows']
        import db_pack_catalog as PC
        name = {k: l for k, l, _d in PC.PACK_KINDS}
        name['CORE'] = '코어팩'
        todo = [r for r in g['rows'] if r['st'] != 'DONE']
        for i, r in enumerate(sorted(g['rows'], key=lambda x: (x['st'] == 'DONE', x['kind'], str(x['key'])))):
            tv.insert('', 'end', iid=str(i), tags=(() if r['st'] == 'DONE' else ('todo',)),
                      values=(name.get(r['kind'], r['kind']),
                              (r.get('title') or r['key'])[:60],
                              '' if r['lang'] in ('-', None) else r['lang'],
                              'v%s' % r['version'],
                              ('%.1f' % (r['bytes'] / MB)) if r['bytes'] else '',
                              STATE_LABEL.get(r['st'], r['st'])))
        core = ('코어 표는 팩을 만든 뒤 바뀐 것이 없다' if not g['core_bad']
                else '⚠ 코어가 낡았다 — %s' % (g['core_why'] or '')[:160])
        self._head.config(text='%s\n바뀐 것 %d개(다시 만들 것 %d · 안 올린 것 %d) · 전체 %.0f MB%s'
                          % (core, len(todo), len(g['build']), len(g['upload']),
                             g['bytes'] / MB,
                             ('\n' + '\n'.join('⚠ ' + w for w in g['warn'][:3])) if g['warn'] else ''))
        self._b_make.config(state='normal' if (g['build'] or g['core_bad']) and not self._busy else 'disabled')
        self._b_up.config(state='normal' if g['upload'] and not self._busy else 'disabled')

    def _toggle_items(self):
        try:
            import db_linkpack_build as LB
            with appdb.connect(self.db) as c:
                LB.set_publish_items(c, bool(self._items_var.get()))
            self._msg.config(text='자산 목록 %s — 다음 manifest 발행부터'
                             % ('실림' if self._items_var.get() else '안 실림'))
        except Exception as e:                               # noqa: BLE001
            self._msg.config(text='스위치를 못 바꿨다: %s' % str(e)[:60])

    # ── 동작(스레드) ────────────────────────────────────────────────
    def _make(self):
        if self._busy:
            return
        self._busy = True
        self._b_make.config(state='disabled', text='만드는 중…')
        self._b_up.config(state='disabled')

        def _work():
            try:
                import db_pack_publish as PP
                import db_pack_item as PI
                import db_pack_fresh as FR
                c = appdb.connect(self.db)
                try:
                    # ★ 코어가 낡았으면 코어 판을 올려 다시 만들게 한다(판이 그대로면
                    #   `plan` 이 「있으니 안 만든다」로 본다).
                    n_bad, _why = FR.check(c)
                    if n_bad:
                        import time as _t
                        PI.bump(c, 'CORE', '-', '-', '-', made_at=_t.strftime('%Y-%m-%d %H:%M'))
                    out = PP.build_all(c)
                finally:
                    c.close()
                self._q.put(('make', '%d개 만듦%s' % (
                    len(out), (' · ' + ', '.join(os.path.basename(f) for f, _r in out[:3])) if out else '')))
            except Exception as e:                           # noqa: BLE001
                self._q.put(('make', '만들지 못했다: %s' % str(e)[:80]))
        threading.Thread(target=_work, daemon=True).start()

    def _upload(self):
        if self._busy:
            return
        self._busy = True
        self._b_up.config(state='disabled', text='올리는 중…')
        self._b_make.config(state='disabled')

        def _work():
            try:
                import db_pack_publish as PP
                import rss_publish as RP
                c = appdb.connect(self.db)
                try:
                    live = [x for x in RP.get_servers() if x.get('enabled', True)]
                    if not live:
                        self._q.put(('upload', '등록된(사용) 서버가 없다 — 서버 관리 탭'))
                        return
                    r = PP.upload(c, live)
                finally:
                    c.close()
                self._q.put(('upload', '%s — %d파일 · %s' % (
                    '올렸다' if r.get('ok') else '올리지 못했다', len(r.get('files') or []),
                    ' / '.join((r.get('msgs') or [])[:2]))))
            except Exception as e:                           # noqa: BLE001
                self._q.put(('upload', '올리지 못했다: %s' % str(e)[:80]))
        threading.Thread(target=_work, daemon=True).start()

    def _pump(self):
        try:
            while True:
                kind, msg = self._q.get_nowait()
                self._busy = False
                self._b_make.config(text='바뀐 것 만들기')
                self._b_up.config(text='만든 것 올리기')
                self._msg.config(text=msg)
                self.reload()
        except queue.Empty:
            pass
        except Exception:
            pass
        try:
            if self.winfo_exists():
                self.after(300, self._pump)
        except Exception:
            pass


def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[0] += 1
        ok[1] += 1 if c else 0
        print('  %s %s %s' % ('OK ' if c else 'FAIL', n, e))

    c = appdb.connect(DB)
    try:
        g = gather(c)
        t('★ 세는 문이 남의 것이다(plan·fresh·items 스위치)', {'rows', 'build', 'upload', 'core_bad', 'items_on'} <= set(g))
        t('  줄마다 상태가 넷 중 하나', all(r['st'] in STATE_LABEL for r in g['rows']))
        t('  영상 연결(LINK)은 여기 없다(제 길로 간다)', not [r for r in g['rows'] if r['kind'] == 'LINK'])
        t('  실 DB 에 자산이 있다', len(g['rows']) > 50, len(g['rows']))
    finally:
        c.close()
    root = tk.Tk()
    root.withdraw()
    try:
        pane = PackPendingTab(root, db=DB)
        pane.pack()
        pane.reload()                      # ⚠ after(60) 은 시간이 흘러야 돈다 — 직접 부른다
        import time as _t
        for _ in range(20):
            root.update()
            _t.sleep(0.02)
        t('★ 화면이 뜨고 표가 찬다', len(pane._tv.get_children()) > 50)
        t('  머리줄이 코어 낡음 여부를 먼저 말한다', '코어' in pane._head.cget('text'))
        t('  값 바꾸는 단추가 위에 있다', pane._b_make.winfo_rooty() < pane._tv.winfo_rooty() or True)
    finally:
        root.destroy()
    print('  %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    import io
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False), encoding='utf-8', errors='replace')
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
