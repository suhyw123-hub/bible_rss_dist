# -*- coding: utf-8 -*-
"""admin/lang_badge.py — 번역 보유 언어 라벨 줄 (관리자 공통 부품, 2026-08-26).

0.txt 1-2)-(2) 사용자 지시: 「번역된 언어와 번역되지 않은 언어를 한눈에 볼 수
있도록 텍스트 라벨로 표시. 클릭하면 해당 언어를 입력/수정. 언어가 많아지면
2열로 배치. 언어 코드가 아니라 English, Korean, Russian 등 **영어이름**으로.」

- 언어 목록은 `sys_language`(is_ui=1, sort_order)에서 읽는다 — 언어를 추가하면
  라벨이 저절로 는다(§0-3 단일 소스). 이름은 `lang_name_en`.
- 보유 = **파스텔 바탕 + 진한 초록 글자** / 미보유 = 회색 / 지금 편집 언어 =
  굵게+밑줄 (2026-09-19 1.txt 3-5 사용자 지시 「번역된 것 파스텔, 안된 것 회색」).
  ⚠ **글자색만으로는 안 갈린다** — 초록도 회색도 옅어 한눈에 안 들어온다.
    바탕을 칠하면 라벨이 칩처럼 보여 「누를 수 있다」는 것도 함께 말한다.
- 클릭 = `on_pick(lang_code)` — 붙이는 화면이 편집 언어 전환·재로드를 맡는다.
- 관리자 전용 부품이라 색 리터럴 허용(사용자 화면 표준서식 §36 대상 아님).

`--selftest` 의무.
"""
import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

_HAVE_FG = '#1E7B3A'
# ★ 2026-10-27 (docs/1.txt 14-1) 옛 #A6ACAF 는 밝은 바탕에서 대비 2.0 이라 안 읽혔다 — 흐린 글자 역할(밝은 화면 대비 3.9)
try:
    import ui_theme as _ut
    _MISS_FG = _ut.PALETTE[_ut.DEFAULT]['fg_dim']
except Exception:
    _MISS_FG = '#6F757C'
#: 파스텔 바탕 — 보유 / 미보유
_HAVE_BG = '#DCF2E3'
_MISS_BG = '#F1F2F3'


def _cols(got):
    """(글자색, 바탕) — 밝은 화면은 위 파스텔 그대로 · 어두운 화면(관리자 ◐)이면 테마 역할 색(2026-10-24)."""
    try:
        import ui_theme
        if ui_theme.is_dark():
            return ((ui_theme.C('success'), ui_theme.C('success_bg')) if got
                    else (ui_theme.C('fg_dim'), ui_theme.C('panel_alt')))
    except Exception:
        pass
    return (_HAVE_FG, _HAVE_BG) if got else (_MISS_FG, _MISS_BG)


_DB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   'bible_master.db')


def ui_langs_en(db_path=None):
    """[(lang_code, 영어 이름)] — sys_language is_ui=1, sort_order 순."""
    import appdb
    try:
        with appdb.connect(db_path or _DB) as c:
            rows = c.execute(
                "SELECT lang_code, COALESCE(lang_name_en, lang_code) "
                "  FROM sys_language WHERE is_ui=1 ORDER BY sort_order"
            ).fetchall()
        if rows:
            return [(str(a).upper(), b) for a, b in rows]
    except Exception as e:
        print('[lang_badge] ui_langs_en:', e)
    return [('EN', 'English'), ('KO', 'Korean')]


class LangBadgeRow(ttk.Frame):
    def __init__(self, parent, db_path=None, on_pick=None, per_row=6, **kw):
        super().__init__(parent, **kw)
        self._on_pick = on_pick
        self._langs = ui_langs_en(db_path)
        self._lbls = {}
        for i, (code, name) in enumerate(self._langs):
            _f, _b = _cols(False)
            lb = tk.Label(self, text=name, fg=_f, bg=_b,
                          cursor='hand2', padx=6, pady=1,
                          borderwidth=1, relief='solid')
            lb.grid(row=i // per_row, column=i % per_row,
                    sticky='w', padx=1, pady=1)
            # ⚠ `_e=None` 으로 받는다 — 클릭 말고 **다른 길로 불리는 경우**가
            #   있다(전수 기동 검사에서 「missing 1 required positional argument:
            #   '_e'」가 stderr 로 튀었다). 화면은 멀쩡한데 오류만 흘러나오면
            #   진짜 오류를 못 본다.
            lb.bind('<Button-1>', lambda _e=None, c=code: self._pick(c))
            self._lbls[code] = lb
        self._have = set()
        self._current = None

    def _pick(self, code):
        if self._on_pick:
            self._on_pick(code)

    def set_have(self, have, current=None):
        """have = 보유 언어 코드 집합 · current = 지금 편집 언어."""
        self._have = {str(c).upper() for c in (have or ())}
        self._current = (current or '').upper() or None
        base = tk.Label(self).cget('font')
        for code, lb in self._lbls.items():
            got = code in self._have
            fg, bg = _cols(got)
            if code == self._current:
                lb.config(fg=fg, bg=bg, font=(base, 9, 'bold underline'))
            else:
                lb.config(fg=fg, bg=bg, font=(base, 9))

    def langs(self):
        return list(self._langs)


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    langs = ui_langs_en()
    t('언어 목록(영어 이름)', len(langs) >= 2
      and langs[0][1][0].isascii(), langs[:3])
    t('코드 대문자', all(c == c.upper() for c, _ in langs))

    root = tk.Tk()
    root.withdraw()
    picked = []
    row = LangBadgeRow(root, on_pick=picked.append, per_row=6)
    row.pack()
    root.update_idletasks()
    t('라벨 수 = 언어 수', len(row._lbls) == len(langs))
    t('2열 배치', int(row._lbls[langs[-1][0]].grid_info()['row']) >= 1
      if len(langs) > 6 else True)

    row.set_have({'EN', 'ko'}, current='KO')
    t('보유 = 초록', row._lbls['EN'].cget('fg') == _HAVE_FG)
    t('보유 = 파스텔 바탕', row._lbls['EN'].cget('bg') == _HAVE_BG)
    t('미보유 = 회색', row._lbls[langs[-1][0]].cget('fg') == _MISS_FG
      if langs[-1][0] not in ('EN', 'KO') else True)
    t('미보유 = 회색 바탕', row._lbls[langs[-1][0]].cget('bg') == _MISS_BG
      if langs[-1][0] not in ('EN', 'KO') else True)
    t('두 바탕이 다르다', _HAVE_BG != _MISS_BG)
    t('소문자 보유도 인정', 'KO' in row._have)

    row._pick('JA')
    t('클릭 → on_pick', picked == ['JA'], picked)
    root.destroy()

    print('lang_badge selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
