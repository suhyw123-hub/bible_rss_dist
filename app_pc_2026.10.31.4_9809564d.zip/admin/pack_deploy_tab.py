# -*- coding: utf-8 -*-
"""**표준 「배포」 부품** — 어느 자산이나 같은 다섯 구획.

★★★ 왜 (2026-09-04 사용자 지시 — 「업무흐름에 맞게 트리/메뉴/탭 구조를 만들고
  **각 화면의 구조가 최대한 표준화되면 좋다**. 링크자산처럼 성격에 따라 차이가
  있는 것은 당연하다」 · 「각 자산별로 배포 이전의 **준비작업이 서로 다르다.
  준비해야 할 내용이나 성격, 점검 포인트가 다르다**」).

**다섯 구획 — 위에서 아래로 업무흐름 그대로**
  ① **준비 상태**  무엇이 갖춰졌나 · 무엇이 비었나   ← **자산마다 다르다**
  ② **점검**       [점검하기] · 판정 n/m
  ③ **팩**         지금 판 · 만든 날 · 크기 · [만들기]
  ④ **배포**       안내문(제목·내용·주의) · [올리기]
  ⑤ **이력**       판별 목록

★★ **①만 갈아 끼운다** — `PREP` 표에 갈래별 점검 항목을 적고, 나머지 넷은
  코드가 하나다. 자산 관리 화면에 이 부품을 심으면 탭이 하나 늘 뿐이다.
⚠ 점검은 **누를 때만** 돈다 — 화면을 열 때마다 무거운 도구를 돌리면 탭 전환이
  몇 초씩 걸린다(§29 지연 빌드와 같은 이유).
⚠ **없는 기능을 회색으로만 두지 않는다** — 아직 빌더가 없는 갈래는 「무엇이
  있어야 하는지」를 글로 적는다(§0-1).

`--selftest`(의무).
"""
import io
import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import appdb                      # noqa: E402
import db_pack_item as PI         # noqa: E402

DB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                  'bible_master.db')


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


# ── ① 준비 점검 — **자산마다 다른 자리** ────────────────────────────────────
def _prep_core(conn, key=None, lang=None):
    """코어팩 — 연결·껍데기가 온전한가."""
    out = []
    try:
        import db_pack_catalog as PC
        miss = PC.missing(conn)
        out.append(('분류 안 된 표', not miss,
                    '없음' if not miss else '%d개: %s' % (len(miss), miss[:3])))
        _tot, rows = PC.core_bytes(conn)
        # ⚠ **잰 것을 넘긴다** — 안 넘기면 `core_size` 가 90개 표를 또 훑는다
        #   (실측 한 번에 1.3초 · 286차).
        # ★★ **지금 설정으로 실제로 나갈 크기**를 잰다(282차 ③) — 분류표
        #   전체가 아니다. 관리자가 뺀 표·함께 싣는 맛보기가 반영된다.
        import db_pack_core_pick as _CK
        sz = _CK.core_size(conn, rows)
        tot = sz['ship']
        out.append(('코어 크기', tot < 20 * 1048576,
                    '%.1f MB%s%s' % (
                        tot / 1048576,
                        (' · 뺀 표 %d개(−%.1fMB)'
                         % (sz['n_off'], sz['cut'] / 1048576))
                        if sz['n_off'] else '',
                        (' · 맛보기 %d개(+%.1fMB)'
                         % (sz['n_extra'], sz['extra'] / 1048576))
                        if sz['n_extra'] else '')))
        big = [r for r in rows if tot and r[1] > tot * 0.4]
        out.append(('한 표가 40%를 안 넘는다', not big,
                    '' if not big else big[0][0]))
        # ★★★ **코어팩 안 다국어 자료**(1.txt 12-3 · 12-5 사용자 물음)
        #   ⚠ 「빠졌다」가 아니라 「아직 안 썼다」다 — 그래도 **배포 전에**
        #     알아야 열한 언어 사용자가 빈 화면을 안 본다(§0-1).
        import lang_config as _LC
        want = len(_LC.ui_langs())
        gaps = PC.core_lang_gaps(conn)
        thin = [(t_, d_, g_) for t_, d_, g_ in gaps if len(g_) < want]
        out.append(('코어팩 다국어 자료가 %d언어를 채웠나' % want, not thin,
                    ('%d개 모두 채움' % len(gaps)) if not thin
                    else '%d개 중 %d개가 모자람 — %s'
                         % (len(gaps), len(thin),
                            ', '.join('%s(%d언어)' % (d_[:14], len(g_))
                                      for _t, d_, g_ in thin[:4]))))
    except Exception as e:                                   # noqa: BLE001
        out.append(('카탈로그를 읽을 수 없다', False, str(e)[:60]))
    try:
        n = conn.execute("SELECT COUNT(*) FROM sys_link_asset"
                         " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                         ).fetchone()[0]
        out.append(('연결', n > 0, '%s행' % f'{n:,}'))
    except Exception:
        pass
    return out


def _prep_bible(conn, key=None, lang=None):
    """역본 — 절 수·라이선스."""
    out = []
    if not key:
        return [('역본을 선택하세요', False, '')]
    n = conn.execute("SELECT COUNT(*) FROM bible_content WHERE version_code=?",
                     (key,)).fetchone()[0]
    out.append(('절 수', n > 0, '%s절' % f'{n:,}'))
    try:
        r = conn.execute("SELECT COALESCE(license_type,''),"
                         " COALESCE(coverage_scope,'') FROM bible_version"
                         " WHERE version_code=?", (key,)).fetchone()
        # ⚠ **라이선스가 비면 배포하면 안 된다**(§db_version_license) —
        #   콥틱 3역본이 미확인인 채 배포물에 있던 것을 그 도구가 잡았다.
        out.append(('라이선스 확인', bool(r and r[0]), (r[0] if r else '') or '미확인'))
        out.append(('수록 범위', True, (r[1] if r else '') or 'FULL'))
    except Exception:
        out.append(('라이선스 칸 없음', False, 'db_version_license --init'))
    return out


def _prep_book(conn, key=None, lang=None):
    """도서·설교 — 원문 출처·편 수·언어."""
    if not key:
        return [('책을 선택하세요', False, '')]
    out = []
    r = conn.execute("SELECT title, COALESCE(author,''),"
                     " COALESCE(description,''), COALESCE(copyright_type,'')"
                     "  FROM sys_book_asset WHERE book_code=?", (key,)).fetchone()
    out.append(('껍데기(제목·저자)', bool(r and r[0]), (r[0] if r else '')[:34]))
    out.append(('소개문', bool(r and r[2]), '%d자' % len(r[2] if r else '')))
    out.append(('판권 표시', bool(r and r[3]), (r[3] if r else '') or '미확인'))
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_book_asset ba"
        "   ON ba.book_id=u.book_id WHERE ba.book_code=?", (key,)).fetchone()[0]
    out.append(('편 수', n > 0, '%s편' % f'{n:,}'))
    try:
        n2 = conn.execute("SELECT COUNT(*) FROM sys_book_source"
                          " WHERE book_code=?", (key,)).fetchone()[0]
        # ⚠ 출처 기록이 없으면 「어디서 온 글인가」를 못 답한다(§0-1b 규칙 ③)
        out.append(('출처 기록', n2 > 0, '%d건' % n2))
    except Exception:
        pass
    if lang:
        n3 = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text t"
            " JOIN sys_book_unit u ON u.unit_id=t.unit_id"
            " JOIN sys_book_asset ba ON ba.book_id=u.book_id"
            " WHERE ba.book_code=? AND UPPER(t.lang_code)=?",
            (key, lang.upper())).fetchone()[0]
        out.append(('%s 본문' % lang, n3 > 0, '%s편' % f'{n3:,}'))
    return out


def _prep_desc(conn, key=None, lang=None):
    """설명문 — 그 성경책의 커버·문체."""
    if not key:
        return [('성경책을 선택하세요', False, '')]
    out = []
    bc = int(key)
    tot = conn.execute("SELECT COUNT(*) FROM bible_index WHERE bcode=?",
                       (bc,)).fetchone()[0]
    q = ("SELECT COUNT(DISTINCT t.clicked_id) FROM sys_text_asset t"
         " JOIN bible_index bi ON bi.verse_id=t.clicked_id"
         " WHERE bi.bcode=? AND t.record_status='LIVE'"
         "   AND t.text_type='VERS_DESC'")
    a = [bc]
    if lang:
        q += ' AND UPPER(t.lang_code)=?'
        a.append(lang.upper())
    n = conn.execute(q, a).fetchone()[0]
    out.append(('구절 커버', n >= tot, '%s / %s절' % (f'{n:,}', f'{tot:,}')))
    # ⚠ **이중 엔터 금지**(§28-11) — 화면이 이중 간격으로 그린다
    bad = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset t"
        " JOIN bible_index bi ON bi.verse_id=t.clicked_id"
        " WHERE bi.bcode=? AND t.record_status='LIVE'"
        "   AND t.contents LIKE '%' || char(10) || char(10) || '%'",
        (bc,)).fetchone()[0]
    out.append(('이중 엔터 없음', bad == 0, '%d편' % bad))
    return out


def _prep_comm(conn, key=None, lang=None):
    if not key:
        return [('주석서를 선택하세요', False, '')]
    r = conn.execute("SELECT title, COALESCE(copyright_type,'')"
                     "  FROM sys_commentary_source WHERE commentary_code=?",
                     (key,)).fetchone()
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_commentary_text t"
        " JOIN sys_commentary_entry e ON e.entry_id=t.entry_id"
        " JOIN sys_commentary_source cs ON cs.commentary_id=e.commentary_id"
        " WHERE cs.commentary_code=?", (key,)).fetchone()[0]
    return [('껍데기', bool(r and r[0]), (r[0] if r else '')[:34]),
            ('판권 표시', bool(r and r[1]), (r[1] if r else '') or '미확인'),
            ('본문', n > 0, '%s편' % f'{n:,}')]


def _prep_dict(conn, key=None, lang=None):
    if not key:
        return [('자료집을 선택하세요', False, '')]
    r = conn.execute("SELECT title, COALESCE(copyright_type,'')"
                     "  FROM sys_ref_source WHERE src_code=?", (key,)).fetchone()
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_ref_unit u JOIN sys_ref_source rs"
        "   ON rs.ref_src_id=u.ref_src_id WHERE rs.src_code=?",
        (key,)).fetchone()[0]
    return [('껍데기', bool(r and r[0]), (r[0] if r else '')[:34]),
            ('판권 표시', bool(r and r[1]), (r[1] if r else '') or '미확인'),
            ('글 수', n > 0, '%s건' % f'{n:,}')]


def _prep_lex(conn, key=None, lang=None):
    return [('원어 사전', True, key or '')]


#: ★★★ **여기만 자산마다 다르다.** 갈래를 늘리면 한 줄.
#: ⚠ 안 적으면 화면이 「점검 항목이 아직 없습니다」라고 **말한다**(빈 칸 금지).
def _prep_image(conn, key=None, lang=None):
    """시작화면 사진 팩 — 그 팩의 사진·장면·다국어 제목.

    ⚠ **갈래를 늘리면 여기 한 줄**(§0-1). `IMAGE` 를 §197차에 팩 갈래로
      올려 놓고 이 표에 안 적어, 그 자산만 「점검 항목이 아직 없습니다」가
      떴다(selftest 가 그 자리에서 잡았다).
    """
    if not key:
        return [('사진 팩을 선택하세요', False, '')]
    out = []
    try:
        import db_splash_scene as SS
        codes = [c for c, *_ in SS.packs(conn)] if hasattr(SS, 'packs') else []
        out.append(('팩 코드', key in codes or not codes, key))
    except Exception:
        pass
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_splash_image"
        " WHERE COALESCE(is_active,1)=1").fetchone()[0]
    out.append(('켜 둔 사진', n > 0, '%s장' % f'{n:,}'))
    # ⚠ 팩에 사진 설명이 함께 안 실리면 **사진만 가고 설명은 영영 안 뜬다**(§197차)
    m = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset"
        " WHERE text_type IN ('SPLASH_TITLE','SPLASH_DESC')"
        "   AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    out.append(('다국어 제목·설명', m > 0, '%s행' % f'{m:,}'))
    return out


def _prep_link(conn, key=None, lang=None):
    """영상 연결 팩(2026-09-29 293차) — 승인분 · 바뀐 것 · 시퀀스 · 안 올린 파일 · 서버.

    ★ 세는 문은 `db_linkpack_build.status` **하나** — 가운데 칸도 같은 문을
      읽는다(두 곳이 따로 세면 갈린다).
    """
    try:
        import db_linkpack_build as LB
        st = LB.status(conn)
    except Exception as e:                                   # noqa: BLE001
        return [('영상 연결 현황을 못 읽었다', False, str(e)[:60])]
    out = [('승인된 영상 주소', st['media'] > 0, '%s편' % f"{st['media']:,}"),
           ('그 연결', st['links'] > 0, '%s건' % f"{st['links']:,}")]
    d = st['stats']
    if st['first']:
        out.append(('전체본', False, '아직 한 번도 안 만들었다 — [전체본 만들기]'))
    else:
        out.append(('지난 팩 이후 바뀐 것', True,
                    '주소 +%d ~%d -%d · 연결 +%d -%d'
                    % (d['add'], d['mod'], d['del'], d['link_add'], d['link_del'])))
    up = int(st.get('uploaded') or 0)
    out.append(('마지막 시퀀스 · 올린 시퀀스', st['seq'] == up,
                '%d · %d%s' % (st['seq'], up,
                               (' · 올린 때 %s' % st['uploaded_at'])
                               if st.get('uploaded_at') else '')))
    pend = st.get('pending') or []
    out.append(('안 올린 파일', not pend,
                ('%d개 — [올리기]' % len(pend)) if pend else '없음'))
    # ★★ **자동 배포와 같은 잣대** — 삭제(묘비)가 승인분의 절반을 넘으면 스냅샷이
    #   깨진 징후다(`db_auto_publish.check` 가 막는 그 잣대). 손 점검이 이것을 안
    #   보면 「점검은 통과했는데 자동 배포는 막힌다」가 된다.
    try:
        import db_auto_publish as AP
        n_del = int(d.get('del') or 0)
        too_many = (not st['first']) and n_del >= AP.DEL_MIN and n_del > st['media'] * AP.DEL_RATIO
        out.append(('삭제(묘비) 비율', not too_many,
                    ('%d편 — 승인분의 절반을 넘는다. 스냅샷을 사람이 본다' % n_del)
                    if too_many else '%d편 · 상식선' % n_del))
    except Exception:                                    # noqa: BLE001
        pass
    try:
        import rss_publish as RP
        live = [x for x in RP.get_servers() if x.get('enabled', True)]
        out.append(('올릴 서버', bool(live),
                    ' · '.join(x.get('label', '?') for x in live)
                    or '없음 — 서버 관리 탭'))
    except Exception as e:                                   # noqa: BLE001
        out.append(('올릴 서버', False, str(e)[:50]))
    return out


PREP = {
    'CORE': _prep_core, 'BIBLE': _prep_bible, 'BOOK': _prep_book,
    'SERMON': _prep_book, 'DESC': _prep_desc, 'COMM': _prep_comm,
    'DICT': _prep_dict, 'LEX': _prep_lex, 'IMAGE': _prep_image,
    'LINK': _prep_link,
}

#: ★ 갈래별 **팩 빌더** — 있으면 [만들기] 가 살아난다.
#: ⚠ 없으면 **왜 없는지 말한다** — 회색으로만 두지 않는다(§0-1).
#: ⚠⚠ **코어와 본문은 시그니처가 다르다** — 코어는 `build(conn)`, 본문은
#:   `build(conn, kind, key, lang, variant)`. `_do_build` 가 갈라 부른다.
BUILDERS = {
    'CORE': ('db_pack_core', 'build', '코어팩 빌더'),
    # ★★★ 영상 연결(2026-09-29 293차) — 시그니처가 또 다르다(`build(conn, full)`
    #   · 시퀀스·묘비). `_do_build/_do_delta/_do_upload` 가 갈라 부른다.
    #   **이 갈래만 [올리기]가 실제로 서버에 올린다** — 받는 쪽(트레이)이 이미
    #   서 있기 때문이다. 코어·본문팩의 [올리기]는 여전히 말만 한다.
    'LINK': ('db_linkpack_build', 'build', '영상 연결 팩 빌더'),
}
#: 본문팩 — `db_pack_body.PARTS` 에 담을 조회가 있으면 만들 수 있다.
BODY_MOD = 'db_pack_body'

NO_BUILDER = ('아직 이 자산의 팩 빌더가 없습니다.\n'
              '필요한 것: ① 무엇을 담을지 선택하는 조회 ② 델타를 만들 기준\n'
              '③ 받는 쪽 적재기.')


def has_builder(kind):
    """그 갈래의 팩을 만들 수 있나."""
    kind = (kind or '').upper()
    if kind in BUILDERS:
        return True
    try:
        import importlib
        m = importlib.import_module(BODY_MOD)
        return bool(m.PARTS.get(kind)) or kind == 'LEX'
    except Exception:
        return False


def prep_check(conn, kind, key=None, lang=None):
    """① 준비 상태 → `[(항목, 통과, 값)]`.

    ⚠ **모르는 갈래도 빈 목록을 돌려주지 않는다** — 화면이 무엇을 그릴지
      알 수 있어야 한다.
    """
    fn = PREP.get((kind or '').upper())
    if not fn:
        return [('점검 항목이 아직 없습니다', False,
                 'pack_deploy_tab.PREP 에 한 줄')]
    try:
        return fn(conn, key, lang)
    except Exception as e:                                   # noqa: BLE001
        return [('점검 중 오류', False, str(e)[:70])]


class DeployPane(ttk.Frame):
    """다섯 구획 — 자산 하나의 배포 화면.

    `set_target(kind, key, lang, variant, title)` 로 대상을 바꾼다.
    """

    def __init__(self, master, db_path=DB, on_changed=None):
        super().__init__(master)
        self.db_path = db_path
        self.on_changed = on_changed
        self._t = (None, None, None, None)
        self._build()
        # ⚠ 처음부터 「고르세요」를 보인다 — 빈 칸을 두지 않는다(§0-1)
        self._refresh()

    def _build(self):
        self._head = tk.Label(self, text='', anchor='w', justify='left',
                              fg=_C('fg', '#000'))
        self._head.pack(fill='x', padx=10, pady=(8, 0))
        self._sub = tk.Label(self, text='', anchor='w',
                             fg=_C('fg_dim', '#666'))
        self._sub.pack(fill='x', padx=10)

        # ① 준비 상태
        f1 = ttk.LabelFrame(self, text='① 준비 상태')
        f1.pack(fill='x', padx=10, pady=(8, 4))
        self._prep = tk.Text(f1, height=6, wrap='word', relief='flat',
                             state='disabled', bg=_C('panel', '#FFF'),
                             fg=_C('fg', '#000'))
        self._prep.pack(fill='x', padx=6, pady=4)

        # ② 점검
        # ★★ **「배포준비 점검」과 무엇이 다른지 화면이 말한다** (2026-09-06
        #   사용자 물음 0.txt 5-4 「배포관리의 **「점검하기」와 「배포점검」의
        #   기능은 어떤 차이가 있는가**? **점검하기 결과를 상세하게 표시하지
        #   않고 있다**」).
        #   ⚠ 물음이 나온 까닭 — ①이 이미 목록을 그리는데 ②는 **같은 것을 다시
        #     세어 숫자 한 줄**만 냈다. 새 일을 하는 것처럼 보이는데 하는 일이
        #     없었다(§0-1). ⇒ 이제 **걸린 것만 이유와 함께** 아래에 편다.
        f2 = ttk.LabelFrame(self, text='② 점검 — 이 자산만')
        f2.pack(fill='x', padx=10, pady=4)
        row2 = ttk.Frame(f2)
        row2.pack(fill='x', padx=6, pady=4)
        self._b_check = ttk.Button(row2, text='점검하기',
                                   command=self._do_check)
        self._b_check.pack(side='left')
        self._chk_lbl = tk.Label(row2, text='', anchor='w',
                                 fg=_C('fg_dim', '#666'))
        self._chk_lbl.pack(side='left', padx=(8, 0))
        tk.Label(f2, anchor='w', justify='left', fg=_C('fg_dim', '#7F8C8D'),
                 text='앱 전체(연결 무결성·고립 자산·배포 체크리스트)는 '
                      '배포 ▸ 배포준비 점검에서 봅니다. 여기는 선택한 자산 하나만 '
                      '봅니다.').pack(fill='x', padx=8, pady=(0, 2))
        self._chk_txt = tk.Text(f2, height=4, wrap='word', relief='flat',
                                state='disabled', bg=_C('panel', '#FFF'),
                                fg=_C('fg', '#000'))
        self._chk_txt.pack(fill='x', padx=6, pady=(0, 4))

        # ③ 팩
        # ★ **전체본과 델타의 뜻**(2026-09-06 사용자 물음 「전체본 릴리스 하면
        #   모두 교체하고 증분만 배포하면 증분이 추가되는가?」):
        #   · **전체본** — 그 팩 범위의 **모든 행을 덮어쓴다**(INSERT OR REPLACE).
        #     ⚠ **초기화가 아니다** — 팩에 없는 행은 사용자 DB 에 그대로 남는다.
        #   · **델타**   — 바뀐 행만 덮어쓰고, **지운 것은 묘비로 지운다**(DELETE).
        #   ⇒ 지우는 일은 **델타만** 한다. 전체본으로는 못 지운다.
        f3 = ttk.LabelFrame(self, text='③ 팩  (전체본=덮어쓰기 · 델타=바뀐 것+묘비)')
        f3.pack(fill='x', padx=10, pady=4)
        row3 = ttk.Frame(f3)
        row3.pack(fill='x', padx=6, pady=4)
        self._b_build = ttk.Button(row3, text='전체본 만들기',
                                   command=self._do_build)
        self._b_build.pack(side='left')
        # ★★ **델타 — 바뀐 것만**(2026-09-04 ⑨). 실측 자료집 1건 수정 + 1건
        #   삭제가 **0.3KB** 다(전체본은 0.29MB). 첫 판은 전체본이어야 하고,
        #   그 뒤로는 이것이 기본이다.
        self._b_delta = ttk.Button(row3, text='델타 만들기',
                                   command=self._do_delta)
        self._b_delta.pack(side='left', padx=(6, 0))
        self._pack_lbl = tk.Label(row3, text='', anchor='w',
                                  fg=_C('fg_dim', '#666'))
        self._pack_lbl.pack(side='left', padx=(8, 0))

        # ④ 배포 — 안내문 + 올리기
        f4 = ttk.LabelFrame(self, text='④ 배포')
        f4.pack(fill='both', expand=True, padx=10, pady=4)
        row4 = ttk.Frame(f4)
        row4.pack(fill='x', padx=6, pady=(4, 2))
        self._b_up = ttk.Button(row4, text='올리기', command=self._do_upload)
        self._b_up.pack(side='left')
        self._up_lbl = tk.Label(row4, text='', anchor='w',
                                fg=_C('fg_dim', '#666'))
        self._up_lbl.pack(side='left', padx=(8, 0))
        # ⚠⚠ **안내문 칸이 저장되지 않고 있었다**(2026-09-04 ⑧에서 검거) —
        #   적어도 사라지는 죽은 입력칸이었다. [저장] 을 달고, 안내 글은
        #   **다른 라벨**(`_note_hint`)에 적는다(한 칸을 둘로 쓰면 사용자가
        #   적은 것을 안내가 덮는다).
        row4b = ttk.Frame(f4)
        row4b.pack(fill='x', padx=6)
        # ⚠ 1.txt 22-4 점검(2026-09-29)에서 잡았다 — 이 글(`sys_pack_item.note`)은
        #   **지금 사용자에게 나가지 않는다**(자산 목록 발행 `PUBLISH_ITEMS=False`).
        #   「사용자가 읽고 받을지 판단합니다」는 거짓이었다(§0-1). 사실대로 적는다.
        ttk.Label(row4b, text='자산 안내문 — 지금은 관리자 메모(자산 목록을 발행하면 '
                              '사용자 다운로드 화면에 나간다)').pack(side='left')
        self._b_note = ttk.Button(row4b, text='저장', command=self._save_note)
        self._b_note.pack(side='right')
        self._note_hint = tk.Label(f4, text='', anchor='w', justify='left',
                                   fg=_C('fg_dim', '#666'), wraplength=420)
        self._note_hint.pack(fill='x', padx=6)
        self._note = tk.Text(f4, height=4, wrap='word')
        self._note.pack(fill='both', expand=True, padx=6, pady=(0, 4))

        # ⑤ 이력
        # ⚠⚠ **자산별 이력이 아니다 — 앱 전체다** (2026-09-06 사용자 물음
        #   0.txt 5-4 「**무엇을 해도 5번 이력은 바뀌지 않는다.** 각 자산별
        #   이력이 아니라 모든 이력을 표시하는가?」 — **그렇다**).
        #   까닭: `sys_pack_history` 의 갈래는 **CORE·DELTA 둘뿐**이다.
        #   「무슨 자산인가」가 아니라 **「얼마나 자주 바뀌나」**로 가른 축이라
        #   (§195차 ⑥) 자산으로 나눌 열쇠가 아예 없다.
        #   ⇒ 축을 바꾸지 않고 **이름이 그것을 말하게** 한다.
        f5 = ttk.LabelFrame(self, text='⑤ 이력 — 앱 전체 발행(자산별 아님)')
        f5.pack(fill='x', padx=10, pady=(4, 10))
        self._hist = tk.Text(f5, height=4, wrap='none', relief='flat',
                             state='disabled', bg=_C('panel', '#FFF'),
                             fg=_C('fg_dim', '#555'))
        self._hist.pack(fill='x', padx=6, pady=4)

    # ── 대상 ──────────────────────────────────────────────────────────
    def set_target(self, kind, key='-', lang='-', variant='-', title=''):
        self._t = (kind, key, lang, variant)
        self._head.config(text=title or '%s %s' % (kind, key))
        bits = [x for x in (kind, key if key != '-' else '',
                            lang if lang != '-' else '',
                            variant if variant != '-' else '') if x]
        self._sub.config(text=' · '.join(bits))
        self._refresh()

    def _say_note(self, text):
        """입력칸을 갈아 끼운다(읽기 전용이 아니다)."""
        self._note.delete('1.0', 'end')
        if text:
            self._note.insert('end', text)

    def _say(self, w, text):
        w.config(state='normal')
        w.delete('1.0', 'end')
        w.insert('end', text)
        w.config(state='disabled')

    def _refresh(self):
        kind, key, lang, variant = self._t
        if not kind:
            self._say(self._prep, '왼쪽에서 자산을 선택하세요')
            for b in (self._b_check, self._b_build, self._b_up):
                b.config(state='disabled')
            return
        c = appdb.connect(self.db_path)
        try:
            rows = prep_check(c, kind, None if key == '-' else key,
                              None if lang == '-' else lang)
            lines = []
            for name, ok, val in rows:
                lines.append('%s %-22s %s' % ('OK ' if ok else '·  ', name, val))
            self._say(self._prep, '\n'.join(lines))
            # ③ 팩 — 지금 판
            it = [x for x in PI.items(c, kind)
                  if x['key'] == key and x['lang'] == lang
                  and x['variant'] == variant]
            if it:
                x = it[0]
                self._pack_lbl.config(
                    text='v%d · %s · %s' % (
                        x['version'], x['made_at'] or '아직 안 만듦',
                        ('%s행' % f"{x['n_items']:,}") if x['n_items'] else ''))
                # ★ 저장해 둔 안내문을 되불러온다(안 그러면 옛 글이 남는다)
                self._say_note(x.get('note') or '')
            else:
                self._pack_lbl.config(text='아직 목록에 없습니다')
                self._say_note('')
            if kind == 'LINK':
                # ★ 영상 연결은 **판이 아니라 시퀀스**로 산다(델타 체인) —
                #   판 번호를 적으면 받는 쪽과 다른 말을 하게 된다.
                try:
                    import db_linkpack_build as LB
                    st = LB.status(c)
                    pend = st.get('pending') or []
                    self._pack_lbl.config(
                        text='시퀀스 %d · 올린 %d%s' % (
                            st['seq'], int(st.get('uploaded') or 0),
                            (' · 안 올린 파일 %d개' % len(pend)) if pend else ''))
                    self._up_lbl.config(
                        text=('안 올린 파일 %d개 — [올리기]' % len(pend)) if pend
                        else ('마지막 올린 때 %s' % st['uploaded_at']
                              if st.get('uploaded_at') else '아직 올린 적 없음'))
                except Exception as e:                       # noqa: BLE001
                    self._pack_lbl.config(text='현황을 못 읽었다: %s' % str(e)[:40])
            # ⑤ 이력
            try:
                import db_pack_history as PH
                h = PH.history(c, limit=6)
                # ⚠⚠ `history` 칸: 0 pack_id · 1 kind · 2 seq · 3 made_at ·
                #   4 file · 5 n_items · 6 bytes · 7 first_id · 8 last_id ·
                #   9 expects · **10 note**. 제목 자리에 id(정수)를 쓰면
                #   슬라이스가 터지고 `except` 가 삼켜 **조용히 빈다**.
                self._say(self._hist, '\n'.join(
                    '%-6s #%-3d %-17s %s' % (r[1], r[2], r[3] or '',
                                             (r[10] or '')[:34])
                    for r in h) or '아직 발행한 적이 없습니다')
            except Exception as e:                           # noqa: BLE001
                # ⚠ **조용히 비우지 않는다**(§0-1) — 왜 못 읽는지 적는다
                self._say(self._hist, '이력을 읽을 수 없습니다: %s' % str(e)[:60])
        finally:
            c.close()
        # ⚠ **빌더가 없으면 왜 없는지 말한다**(§0-1)
        has = has_builder(kind)
        self._b_build.config(state='normal' if has else 'disabled')
        # ⚠⚠ **코어 델타를 잠가 두고 있었다** (2026-09-06 사용자 물음
        #   「**코어팩은 증분 만들기가 안 되는가**?」 — 된다).
        #   §㉒(2026-09-04)에 `db_pack_delta._parts` 가 코어 갈래를 받아
        #   `db_pack_core.core_tables()` 로 표 85개를 견주게 됐는데,
        #   그때 **이 가드를 안 풀었다**(옛 주석: 「코어팩은 아직 델타가 없다」).
        #   ⇒ 빌더가 있으면 델타도 있다.
        self._b_delta.config(state='normal' if has else 'disabled')
        self._b_up.config(state='normal' if has else 'disabled')
        self._b_check.config(state='normal')
        # ⚠⚠ 안내 글은 **안내 자리**(`_note_hint`)에, 사용자가 적는 글은
        #   **입력칸**(`_note`)에. 한 칸을 둘로 쓰면 안내가 적은 글을 덮는다
        #   — 실제로 그랬고 그래서 안내문이 저장되지 않는 것처럼 보였다.
        self._note_hint.config(text='' if has else NO_BUILDER)
        if kind != 'LINK':
            self._up_lbl.config(text='' if has else NO_BUILDER.split('\n')[0])
        self._b_note.config(state='normal' if kind else 'disabled')

    def _save_note(self):
        """자산 안내문을 저장한다(`sys_pack_item.note`).

        ⚠ **판올림 안내문과 다르다** — 그것은 「3판에 무엇이 바뀌었나」(판 축,
          배포 안내문 탭)이고 이것은 「이 자산은 무엇인가」(자산 축)다.
        """
        kind, key, lang, variant = self._t
        if not kind:
            return
        txt = self._note.get('1.0', 'end').strip()
        c = appdb.connect(self.db_path)
        try:
            PI.init(c)
            c.execute("UPDATE sys_pack_item SET note=?"
                      " WHERE kind=? AND key=? AND lang=? AND variant=?",
                      (txt or None, kind, key, lang, variant))
            c.commit()
            n = c.execute("SELECT changes()").fetchone()[0]
        finally:
            c.close()
        # ⚠ **저장이 안 됐으면 그렇게 말한다**(§0-1) — 목록에 없는 자산일 수 있다
        self._up_lbl.config(text='안내문을 저장했습니다' if n
                            else '저장할 자산이 목록에 없습니다'
                                 ' — [목록 새로 고치기]')

    # ── 동작 ──────────────────────────────────────────────────────────
    def _do_check(self):
        kind = self._t[0]
        self._chk_lbl.config(text='점검 중…')
        self.update_idletasks()
        c = appdb.connect(self.db_path)
        try:
            if kind == 'CORE':
                # ⚠ 무거운 검사는 **누를 때만** 돈다
                import db_integrity as DI
                rows = DI.run(c)
                bad, tot, _f = DI.summary(rows)
                njudge = sum(1 for r in rows if r['kind'] == DI.JUDGE)
                self._chk_lbl.config(text='무결성 판정 %d/%d 실패' % (bad, njudge))
                fail = [r for r in rows
                        if r['kind'] == DI.JUDGE and not r['ok']]
                self._say(self._chk_txt, '\n'.join(
                    '·  %-28s %s건   %s' % (r['name'], format(r['n'] or 0, ',d'),
                                           r['why'])
                    for r in fail) or
                    '판정 %d개 전부 통과. 코어팩을 만들 수 있습니다.' % njudge)
            else:
                key = None if self._t[1] == '-' else self._t[1]
                lang = None if self._t[2] == '-' else self._t[2]
                rows = prep_check(c, kind, key, lang)
                ok = sum(1 for _n, o, _v in rows if o)
                self._chk_lbl.config(text='준비 항목 %d/%d 통과'
                                          % (ok, len(rows)))
                # ★ **걸린 것만** 이유와 함께 — 통과한 줄은 ①이 이미 그린다
                bad = [(n, v) for n, o, v in rows if not o]
                self._say(self._chk_txt, '\n'.join(
                    '·  %-24s %s' % (n, v or '값 없음') for n, v in bad) or
                    '준비 항목 %d개 전부 통과. 팩을 만들 수 있습니다.' % len(rows))
        except Exception as e:                               # noqa: BLE001
            self._chk_lbl.config(text='점검 실패: %s' % str(e)[:50])
            self._say(self._chk_txt, '점검 중 오류: %s' % str(e)[:120])
        finally:
            c.close()
        self._refresh()

    def _do_build(self):
        kind = self._t[0]
        if not has_builder(kind):
            return
        if kind == 'LINK':
            return self._do_link(full=True)
        # ★★ **큰 것은 미리 알린다** — 스펄전 설교 한 권이 125MB 다.
        #   누르고 나서 몇 분을 기다리게 하지 않는다.
        if kind not in BUILDERS:
            try:
                import importlib
                mb = importlib.import_module(BODY_MOD)
                c0 = appdb.connect(self.db_path)
                try:
                    rows, chars = mb.estimate(c0, kind, self._t[1],
                                              self._t[2], self._t[3])
                finally:
                    c0.close()
                if chars > 20 * 1048576:
                    from tkinter import messagebox
                    if not messagebox.askyesno(
                            '팩 만들기',
                            '이 자산은 큽니다 — %s행 · 약 %.0f MB.\n\n'
                            '만드는 데 시간이 걸립니다. 계속할까요?'
                            % (f'{rows:,}', chars / 1048576)):
                        return
            except Exception:
                pass
        self._pack_lbl.config(text='만드는 중…')
        self.update_idletasks()
        c = appdb.connect(self.db_path)
        try:
            import importlib
            if kind in BUILDERS:
                mod, fn, _name = BUILDERS[kind]
                r = getattr(importlib.import_module(mod), fn)(c)
            else:
                # ⚠ 본문팩은 **무엇을 담을지**를 인자로 받는다
                m = importlib.import_module(BODY_MOD)
                r = m.build(c, kind, self._t[1], self._t[2], self._t[3])
            import time
            v = PI.bump(c, kind, self._t[1], self._t[2], self._t[3],
                        made_at=time.strftime('%Y-%m-%d %H:%M'),
                        n_items=r.get('rows'), n_bytes=r.get('bytes'),
                        file_name=os.path.basename(r.get('file') or ''))
            # ★ **전체본을 만들면 델타 기준을 함께 잡는다** — 안 잡으면 다음
            #   델타가 「지난 판이 없다」로 안 만들어진다.
            try:
                import db_pack_delta as PD
                if kind not in BUILDERS:
                    PD.snap_now(c, kind, self._t[1], self._t[2], self._t[3])
            except Exception:
                pass
            # ★ **뺀 것·함께 실은 것을 말한다**(282차 ②) — 안 말하면
            #   관리자가 전부 담긴 줄 알고 배포한다(§0-1).
            _ex, _bd = r.get('excluded') or [], r.get('bundled') or []
            self._pack_lbl.config(
                text='v%d 만듦 · %.1f MB%s%s'
                     % (v, (r.get('bytes') or 0) / 1048576,
                        (' · 뺀 표 %d개' % len(_ex)) if _ex else '',
                        (' · 맛보기 %d개' % len(_bd)) if _bd else ''))
        except Exception as e:                               # noqa: BLE001
            self._pack_lbl.config(text='만들지 못했습니다: %s' % str(e)[:50])
        finally:
            c.close()
        if callable(self.on_changed):
            self.on_changed()
        self._refresh()

    def _do_link(self, full):
        """영상 연결 팩 — 전체본(커서를 통째로 갈아 끼운다) / 델타(바뀐 것 + 묘비).

        ★ 만드는 문은 `db_linkpack_build.build` 하나 — 여기서 SQL 을 다시 쓰지
          않는다. ⚠ 전체본은 **먼저 묻는다** — 받는 쪽이 팩을 비우고 다시 채운다.
        """
        if full:
            from tkinter import messagebox
            if not messagebox.askyesno(
                    '전체본 만들기',
                    '지금 승인된 영상 주소·연결 전부를 담은 전체본을 만듭니다.\n'
                    '받는 쪽은 이 파일을 받으면 팩을 비우고 다시 채웁니다.\n\n'
                    '계속할까요?'):
                return
        self._pack_lbl.config(text='만드는 중…')
        self.update_idletasks()
        c = appdb.connect(self.db_path)
        try:
            import db_linkpack_build as LB
            r = LB.build(c, full=full)
            if not r.get('file'):
                # ⚠ 못 만든 이유를 그대로 보인다(§0-1)
                self._pack_lbl.config(text=r.get('msg') or '만들지 못했습니다')
                return
            import time
            st = r['stats']
            PI.bump(c, 'LINK', self._t[1], self._t[2], self._t[3],
                    made_at=time.strftime('%Y-%m-%d %H:%M'),
                    n_items=(st['add'] + st['mod'] + st['del']),
                    n_bytes=os.path.getsize(r['file']),
                    file_name=os.path.basename(r['file']))
            self._pack_lbl.config(
                text='%s 시퀀스 %d · 주소 +%d ~%d -%d · 연결 +%d -%d — [올리기]'
                     % ('전체본' if full else '델타', r['seq'], st['add'],
                        st['mod'], st['del'], st['link_add'], st['link_del']))
        except Exception as e:                               # noqa: BLE001
            self._pack_lbl.config(text='만들지 못했습니다: %s' % str(e)[:50])
        finally:
            c.close()
        if callable(self.on_changed):
            self.on_changed()

    def _do_delta(self):
        """지난 판과 견주어 **바뀐 것만** 만든다.

        ⚠ 스냅샷이 없으면(첫 판) **안 만들고 그렇게 말한다** — 빈 델타를
          보내면 사용자가 받고도 아무것도 안 생긴다.
        """
        kind, key, lang, variant = self._t
        if not kind or not has_builder(kind):
            return
        if kind == 'LINK':
            return self._do_link(full=False)
        self._pack_lbl.config(text='견주는 중…')
        self.update_idletasks()
        c = appdb.connect(self.db_path)
        try:
            import db_pack_delta as PD
            it = [x for x in PI.items(c, kind)
                  if x['key'] == key and x['lang'] == lang
                  and x['variant'] == variant]
            ver = (it[0]['version'] if it else 0) + 1
            r = PD.build_delta(c, kind, key, lang, variant,
                               base_version=(it[0]['version'] if it else 0),
                               version=ver)
            if not r.get('file'):
                # ⚠ 못 만든 이유를 그대로 보인다(§0-1)
                self._pack_lbl.config(text=r.get('msg') or '만들지 못했습니다')
                return
            import time
            PI.bump(c, kind, key, lang, variant,
                    made_at=time.strftime('%Y-%m-%d %H:%M'),
                    n_items=r['changed'] + r['deleted'], n_bytes=r['bytes'],
                    file_name=os.path.basename(r['file']))
            self._pack_lbl.config(
                text='델타 v%d · 바뀐 %s · 지운 %s · %.1f KB'
                     % (ver, f"{r['changed']:,}", f"{r['deleted']:,}",
                        r['bytes'] / 1024))
        except Exception as e:                               # noqa: BLE001
            self._pack_lbl.config(text='델타를 만들지 못했습니다: %s'
                                       % str(e)[:50])
        finally:
            c.close()
        if callable(self.on_changed):
            self.on_changed()

    def _do_upload(self):
        kind = self._t[0]
        if kind == 'LINK':
            # ★★★ 영상 연결은 **실제로 올린다**(2026-09-29 293차) — 받는 쪽
            #   (트레이 · `db_linkpack_sync`)이 이미 서 있다. 올리는 문은
            #   `db_linkpack_build.upload` 하나(rss_publish._upload 를 쓴다).
            self._up_lbl.config(text='올리는 중…')
            self.update_idletasks()
            try:
                import db_linkpack_build as LB
                import rss_publish as RP
                names = LB.pending_files()
                if not names:
                    self._up_lbl.config(text='올릴 것이 없습니다 — 먼저 [델타 만들기]')
                    return
                live = [x for x in RP.get_servers() if x.get('enabled', True)]
                if not live:
                    self._up_lbl.config(text='등록된(사용) 서버가 없습니다 — 서버 관리 탭')
                    return
                res, up = LB.upload(live, names)
                ok = [x for x in res if x['status'] == 'OK']
                self._up_lbl.config(
                    text='%s — %d파일 · %s' % (
                        '올렸습니다' if ok else '올리지 못했습니다', len(up),
                        ' / '.join('%s %s' % (x['server'], x['status']) for x in res)))
            except Exception as e:                           # noqa: BLE001
                self._up_lbl.config(text='올리지 못했습니다: %s' % str(e)[:60])
            if callable(self.on_changed):
                self.on_changed()
            return
        # ⏭ 코어·본문팩의 실제 업로드는 받는 쪽이 선 뒤에 잇는다 — 지금은 말만 한다.
        self._up_lbl.config(
            text='아직 올리지 않습니다 — 받는 쪽(적재기)이 선 뒤에 잇습니다')


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    c = appdb.connect(DB)
    try:
        kinds = set(PI.discover(c) and [g[0] for g in PI.discover(c)])
        t('★ 갈래마다 준비 점검이 있다',
          all(k in PREP for k in kinds), str(sorted(kinds - set(PREP))))
        t('★ 모르는 갈래도 빈 목록이 아니다',
          len(prep_check(c, 'ZZZ')) == 1
          and not prep_check(c, 'ZZZ')[0][1])
        for kind, key, lang in (('CORE', None, None), ('BIBLE', 'KRV', None),
                                ('BOOK', 'SPURGEON_ME', 'KO'),
                                ('DESC', 'PENT', 'KO'), ('COMM', 'JFB', None),
                                ('DICT', 'EASTON_DICT', None),
                                ('LINK', 'MEDIA', None)):
            rows = prep_check(c, kind, key, lang)
            t('  %s 점검이 돈다' % kind, len(rows) >= 1 and
              all(len(r) == 3 for r in rows), '%d항목' % len(rows))
        t('★ 키가 없으면 「선택하세요」라 한다',
          prep_check(c, 'BOOK')[0][1] is False)
        t('★★ 빌더가 없는 갈래는 **왜 없는지 적혀 있다**',
          'BOOK' not in BUILDERS and '필요한 것' in NO_BUILDER)
        t('  코어는 빌더가 있다', 'CORE' in BUILDERS)
        # ★★★ 293차 — 영상 연결은 빌더가 있고 준비 점검이 시퀀스·서버를 말한다
        t('★★ 영상 연결(LINK)도 빌더가 있다', 'LINK' in BUILDERS and has_builder('LINK'))
        _lk = prep_check(c, 'LINK', 'MEDIA', None)
        t('  영상 연결 준비 점검이 서버·시퀀스를 말한다',
          any('서버' in n for n, _o, _v in _lk)
          and any('시퀀스' in n for n, _o, _v in _lk), str([n for n, _o, _v in _lk]))
    finally:
        c.close()

    # 화면 — 실제로 그려 본다
    try:
        r = tk.Tk()
        r.withdraw()
        pane = DeployPane(r)
        pane.pack()
        r.update()
        t('★ 대상이 없으면 「선택하세요」', '선택하세요' in
          pane._prep.get('1.0', 'end'))
        pane.set_target('CORE', '-', '-', '-', '앱 기본 자료')
        r.update()
        txt = pane._prep.get('1.0', 'end')
        t('★★ **다섯 구획이 다 그려진다**',
          all(w.winfo_exists() for w in (pane._prep, pane._chk_lbl,
                                         pane._pack_lbl, pane._note,
                                         pane._hist)))
        t('  코어 준비 상태가 나온다', '분류' in txt and '코어 크기' in txt,
          txt.strip().split('\n')[0][:40])
        t('  코어는 [만들기] 가 살아난다',
          str(pane._b_build.cget('state')) == 'normal')
        pane.set_target('BOOK', 'SPURGEON_ME', 'KO', 'TRANSLATED', '아침과 저녁')
        r.update()
        # ★ 본문팩 빌더가 선 뒤로 도서도 **만들 수 있다**(⑤ 완료)
        t('★★ 본문 갈래도 [만들기] 가 살아난다',
          str(pane._b_build.cget('state')) == 'normal',
          str(pane._b_build.cget('state')))
        pane.set_target('ZZZ', 'x', '-', '-', '없는 갈래')
        r.update()
        t('★★ **빌더 없는 갈래는 잠기고 이유를 말한다**',
          str(pane._b_build.cget('state')) == 'disabled'
          and '필요한 것' in pane._note_hint.cget('text'))
        # ★★ **안내문 칸이 살아 있다**(⑧에서 죽은 입력칸을 검거해 고쳤다)
        # ⚠ **목록에 실제로 있는 열쇠**로 잰다 — 역본의 `lang` 은 '-' 가 아니라
        #   'KO' 다(`discover` 가 `bible_version.lang_code` 를 넣는다).
        #   지어낸 열쇠로 재면 「목록에 없다」가 나오고 시험이 헛돈다.
        _c = appdb.connect(DB)
        try:
            _it = [x for x in PI.items(_c, 'BIBLE')][:1]
        finally:
            _c.close()
        if not _it:
            t('안내문 시험을 할 자산이 있다', False, '목록이 비었다')
            _it = [{'key': 'KRV', 'lang': '-', 'variant': '-', 'title': ''}]
        _x = _it[0]
        pane.set_target('BIBLE', _x['key'], _x['lang'], _x['variant'],
                        _x['title'] or _x['key'])
        r.update()
        pane._note.delete('1.0', 'end')
        pane._note.insert('end', '시험 안내문')
        pane._save_note()
        r.update()
        pane.set_target('CORE', '-', '-', '-', '코어팩')
        r.update()
        t('  다른 자산으로 가면 칸이 바뀐다',
          '시험 안내문' not in pane._note.get('1.0', 'end'))
        pane.set_target('BIBLE', _x['key'], _x['lang'], _x['variant'],
                        _x['title'] or _x['key'])
        r.update()
        t('★★★ **안내문이 저장되고 되불러진다**',
          '시험 안내문' in pane._note.get('1.0', 'end'),
          pane._note.get('1.0', 'end').strip()[:20])
        pane._note.delete('1.0', 'end')
        pane._save_note()          # ⚠ 시험 자국을 지운다
        r.update()
        pane.set_target('BOOK', 'SPURGEON_ME', 'KO', 'TRANSLATED', '아침과 저녁')
        r.update()
        t('  도서 준비 상태가 나온다',
          '편 수' in pane._prep.get('1.0', 'end'))
        pane._do_check()
        r.update()
        t('★ [점검하기] 가 답을 낸다', '통과' in pane._chk_lbl.cget('text')
          or '실패' in pane._chk_lbl.cget('text'), pane._chk_lbl.cget('text'))
        r.destroy()
    except Exception as e:                                   # noqa: BLE001
        t('화면 시험이 돈다', False, str(e)[:70])
    print('pack_deploy_tab selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
