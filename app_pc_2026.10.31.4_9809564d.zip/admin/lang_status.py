"""admin/lang_status.py — 「어느 언어로 등록됐는가」 한눈에 (공용 위젯, 2026-08-16).

> 「등록된 언어값에 대해서 DESC 작성여부를 한눈에 파악할 수 있으면 효과적
>  (사전, 주석 등 모든 화면에 공통)」 — 사용자 지시

★ **11개 언어를 모두 늘어놓고 없는 것도 자리를 차지하게 한다.**
  목록의 「언어」 칸이나 탭 라벨은 **한 줄 요약**이라 「무엇이 빠졌나」가 안 보인다.
  빠진 것이 **보여야** 채울 마음이 생긴다(`panel_research_manager` 2026-08-14 판단).

★ **화면마다 항목이 다르다** — 그래서 칸 목록과 세는 방법을 **밖에서 받는다**.

  | 화면 | 칸 |
  |---|---|
  | 연구자료 | 제목 · 본문 · 첨부 (한 글에 하나씩) |
  | **렌즈묵상** | 렌즈 설명 1 · **노드 설명 n/N** · 노드 질문 n/N · 구절 연결 n/M |
  | 사전·주석 | (그 화면이 정한다) |

  ⚠ **렌즈는 「있다/없다」로 끝나지 않는다** (2026-08-16 실측). 렌즈 하나에
    설명 1 + 노드 N개 × 2종 + 구절연결 M개가 달려 있어 **분수**가 나온다
    (`KO 1/1 · 1/3 · 0/3 · 0/1`). 그래서 값으로 `(된 수, 전체)` 를 받는다.

사용:
    tbl = LangStatusTable(parent,
                          columns=[('desc', '렌즈 설명', 90),
                                   ('node', '노드 설명', 90)],
                          provider=self._lang_counts,      # lang -> {key: 값}
                          on_pick=self._switch_edit_lang)  # 두 번 누르면 그 언어로
    tbl.pack(fill='both', expand=True)
    tbl.refresh()

값으로 줄 수 있는 것:
    `(된 수, 전체)`  → `2/3` · 색으로 다 됨/부분/없음을 가른다
    `True`/`False`  → `✓` / 빈칸
    문자열          → 그대로 (글자 수 등)

    python admin/lang_status.py --selftest   (의무)
"""
import sys

try:
    import tkinter as tk
    from tkinter import ttk
except Exception:                                   # 검사 환경에 Tk 가 없을 때
    tk = ttk = None

# 언어 목록은 `lang_config` 가 단일 소스다 (§0-3). 못 읽으면 이 순서로 떨어진다.
FALLBACK = ['KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT']


def ui_langs():
    try:
        import lang_config
        codes = [c for c in lang_config.ui_langs()]
        return codes or list(FALLBACK)
    except Exception:
        return list(FALLBACK)


def fmt(value):
    """값 → (보일 글자, 태그). 태그: full · part · none · plain."""
    if isinstance(value, tuple) and len(value) == 2:
        done, total = value
        try:
            done, total = int(done), int(total)
        except (TypeError, ValueError):
            return str(value), 'plain'
        if total <= 0:
            return '-', 'plain'                     # 셀 것이 없다 — 없음과 다르다
        txt = '%d/%d' % (done, total)
        if done >= total:
            return txt, 'full'
        return txt, ('none' if done == 0 else 'part')
    if isinstance(value, bool):
        return ('✓', 'full') if value else ('', 'none')
    if value in (None, ''):
        return '', 'none'
    return str(value), 'plain'


def row_tag(tags):
    """한 줄의 색 — 칸들의 상태를 모아 정한다.

    ⚠ `plain`·`-` 은 판정에 넣지 않는다. 셀 것이 없는 칸 때문에 줄이 통째로
      「없음」으로 보이면 정작 채워진 칸이 묻힌다.
    """
    real = [t for t in tags if t in ('full', 'part', 'none')]
    if not real:
        return 'plain'
    if all(t == 'full' for t in real):
        return 'full'
    if all(t == 'none' for t in real):
        return 'none'
    return 'part'


if ttk is not None:

    class LangStatusTable(ttk.Frame):
        """언어 × 항목 현황 표. `refresh()` 로 다시 읽는다."""

        HINT = '줄을 두 번 누르면 그 언어로 편집 언어가 바뀝니다.'

        def __init__(self, parent, columns, provider, on_pick=None,
                     langs=None, hint=None, **kw):
            super().__init__(parent, **kw)
            self._columns = list(columns)
            self._provider = provider
            self._on_pick = on_pick
            self._langs = list(langs) if langs else ui_langs()

            ttk.Label(self, text=(hint if hint is not None else self.HINT),
                      foreground='#7F8C8D').pack(anchor='w', padx=6, pady=(4, 2))
            w = ttk.Frame(self)
            w.pack(fill='both', expand=True, padx=6, pady=(0, 6))
            cols = ['lang'] + [k for k, _l, _wd in self._columns]
            self.tv = ttk.Treeview(w, columns=cols, show='headings',
                                   selectmode='browse')
            self.tv.heading('lang', text='언어')
            self.tv.column('lang', width=70, anchor='w', stretch=False)
            for k, label, wd in self._columns:
                self.tv.heading(k, text=label)
                self.tv.column(k, width=wd, anchor='center', stretch=False)
            # ⚠ 색만으로 가르지 않는다 — 글자(`2/3`)가 이미 말한다. 색은 거들 뿐이다.
            # ★ 2026-10-27 (docs/1.txt 14-1) 「없음」#B0B0B0 · 「일부」#B7770D 가 밝은 표에서 대비 1.7·2.6 — 역할 색으로
            import ui_theme as _ut
            self.tv.tag_configure('none',  foreground=_ut.C('fg_dim'))
            self.tv.tag_configure('part',  foreground=_ut.C('warning'))
            self.tv.tag_configure('full',  foreground='#1E8449')
            self.tv.tag_configure('plain', foreground='#555555')
            vs = ttk.Scrollbar(w, orient='vertical', command=self.tv.yview)
            self.tv.configure(yscrollcommand=vs.set)
            vs.pack(side='right', fill='y')
            self.tv.pack(fill='both', expand=True)
            self.tv.bind('<Double-1>', self._pick)

        def refresh(self):
            self.tv.delete(*self.tv.get_children())
            for lg in self._langs:
                try:
                    got = self._provider(lg) or {}
                except Exception as e:
                    print('[lang_status] %s %s' % (lg, e))
                    got = {}
                vals, tags = [], []
                for k, _l, _w in self._columns:
                    t, tag = fmt(got.get(k))
                    vals.append(t)
                    tags.append(tag)
                self.tv.insert('', 'end', iid=lg, values=[lg] + vals,
                               tags=(row_tag(tags),))

        def _pick(self, _e=None):
            sel = self.tv.selection()
            if sel and callable(self._on_pick):
                self._on_pick(sel[0])

else:                                               # Tk 없이 불러도 죽지 않는다
    LangStatusTable = None


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest():
    ok = True

    # ① 분수 — 렌즈가 쓰는 모양
    for val, want in (((3, 3), ('3/3', 'full')),
                      ((1, 3), ('1/3', 'part')),
                      ((0, 3), ('0/3', 'none')),
                      ((0, 0), ('-', 'plain'))):
        if fmt(val) != want:
            print('FAIL 분수 %s → %s (기대 %s)' % (val, fmt(val), want)); ok = False
    # ⚠ **전체가 0 이면 「없음」이 아니라 「셀 것이 없음」**이다. 노드가 아직 없는
    #   렌즈를 빨갛게 칠하면 「빠뜨렸다」로 읽힌다.
    if fmt((0, 0))[1] == 'none':
        print('FAIL 전체 0 을 없음으로 본다'); ok = False

    # ② 참/거짓 · 문자열
    if fmt(True) != ('✓', 'full') or fmt(False) != ('', 'none'):
        print('FAIL 참/거짓 표시'); ok = False
    if fmt('1,204자')[0] != '1,204자':
        print('FAIL 문자열을 그대로 안 보인다'); ok = False
    if fmt(None) != ('', 'none') or fmt('') != ('', 'none'):
        print('FAIL 빈 값'); ok = False

    # ③ 줄 색 — 섞이면 part, 셀 것이 없는 칸은 판정에서 뺀다
    if row_tag(['full', 'full']) != 'full':
        print('FAIL 다 됨'); ok = False
    if row_tag(['none', 'none']) != 'none':
        print('FAIL 다 없음'); ok = False
    if row_tag(['full', 'none']) != 'part':
        print('FAIL 섞임'); ok = False
    if row_tag(['full', 'plain']) != 'full':
        print('FAIL 셀 것 없는 칸이 판정을 흐린다'); ok = False
    if row_tag(['plain', 'plain']) != 'plain':
        print('FAIL 전부 셀 것 없음'); ok = False

    # ④ 언어 목록 — 11개가 나오고 KO·EN 이 있다
    ls = ui_langs()
    if len(ls) < 10 or 'KO' not in ls or 'EN' not in ls:
        print('FAIL 언어 목록이 이상하다: %s' % ls); ok = False

    print('lang_status selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__.split('\n')[0])
