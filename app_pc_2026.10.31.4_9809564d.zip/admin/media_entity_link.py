"""
admin/media_entity_link.py
--------------------------
미디어(영상)–엔티티(인물 등) 다중 연결 관리 다이얼로그.

한 영상에 여러 인물이 등장하면 등장 인물을 모두 연결한다
(통합 표 sys_link_asset, link_type='MEDI_ENTI' — media_link 모듈이 단일 소스).
엔티티/페리코프 검토 탭 양쪽에서 공용으로 호출한다.

open_dialog(parent, db_path, media_id, on_done=None)
"""
import os
import json
import sqlite3
import appdb
import media_link      # 영상 연결 단일 소스(통합 표 이름·link_type)
import tkinter as tk
from tkinter import ttk, messagebox


def _entity_name(conn, entity_id, lang='KO'):
    r = conn.execute(
        "SELECT COALESCE(ko.contents, en.contents, em.entity_code) "
        "FROM sys_entity_master em "
        "LEFT JOIN sys_text_asset ko ON ko.clicked_id=em.entity_id "
        "  AND ko.text_type='ENTITY_NAME' AND ko.lang_code='KO' "
        "LEFT JOIN sys_text_asset en ON en.clicked_id=em.entity_id "
        "  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN' "
        "WHERE em.entity_id=?", (entity_id,)).fetchone()
    return r[0] if r else str(entity_id)


class _EntityLinkDialog(tk.Toplevel):
    def __init__(self, parent, db_path, media_id, on_done=None):
        super().__init__(parent)
        self.db_path = db_path
        self.media_id = media_id
        self.on_done = on_done
        self._changed = False
        self.title('등장 인물 연결')
        self.geometry('560x520')
        self.grab_set()
        self._build()
        self._load_linked()
        self.wait_window()

    def _db(self):
        return appdb.connect(self.db_path)

    def _build(self):
        # 영상 제목
        conn = self._db()
        row = conn.execute("SELECT title FROM sys_media_asset WHERE media_id=?",
                           (self.media_id,)).fetchone()
        conn.close()
        ttk.Label(self, text=f'영상: {row[0] if row else self.media_id}',
                  font=('Malgun Gothic', 9, 'bold'), wraplength=530
                  ).pack(anchor='w', padx=10, pady=(10, 4))

        # 현재 연결된 인물
        lf1 = ttk.LabelFrame(self, text=' 현재 연결된 대상 (등장 인물) ')
        lf1.pack(fill='both', expand=True, padx=10, pady=4)
        self._linked_tv = ttk.Treeview(lf1, columns=('type', 'name'),
                                       show='headings', selectmode='browse', height=6)
        self._linked_tv.heading('type', text='유형'); self._linked_tv.column('type', width=80, anchor='center')
        self._linked_tv.heading('name', text='이름');  self._linked_tv.column('name', width=380, anchor='w')
        self._linked_tv.pack(side='left', fill='both', expand=True, padx=4, pady=4)
        ttk.Button(lf1, text='선택 연결 해제', command=self._unlink
                   ).pack(side='right', padx=6, pady=4, anchor='n')

        # 인물 검색 + 추가
        lf2 = ttk.LabelFrame(self, text=' 인물/대상 검색해서 연결 추가 ')
        lf2.pack(fill='both', expand=True, padx=10, pady=4)
        sr = ttk.Frame(lf2); sr.pack(fill='x', padx=4, pady=4)
        ttk.Label(sr, text='검색:').pack(side='left')
        self._q_var = tk.StringVar()
        ent = ttk.Entry(sr, textvariable=self._q_var)
        ent.pack(side='left', fill='x', expand=True, padx=4)
        ent.bind('<Return>', lambda e: self._search())
        self._person_only = tk.BooleanVar(value=False)
        ttk.Checkbutton(sr, text='인물만', variable=self._person_only,
                        command=self._search).pack(side='left', padx=4)
        ttk.Button(sr, text='검색', command=self._search).pack(side='left')
        self._res_tv = ttk.Treeview(lf2, columns=('type', 'name'),
                                    show='headings', selectmode='browse', height=8)
        self._res_tv.heading('type', text='유형'); self._res_tv.column('type', width=80, anchor='center')
        self._res_tv.heading('name', text='이름');  self._res_tv.column('name', width=380, anchor='w')
        self._res_tv.pack(fill='both', expand=True, padx=4, pady=(0, 4))
        self._res_tv.bind('<Double-1>', lambda e: self._link())
        ttk.Button(lf2, text='▲ 선택 인물 연결 추가', command=self._link
                   ).pack(padx=4, pady=(0, 6))

        ttk.Button(self, text='닫기', command=self._close, width=10
                   ).pack(side='right', padx=10, pady=8)

    def _load_linked(self):
        self._linked_tv.delete(*self._linked_tv.get_children())
        conn = self._db()
        rows = conn.execute(
            "SELECT l.target_id, em.entity_type, "
            "  COALESCE(ko.contents, en.contents, em.entity_code) AS name "
            "FROM " + media_link.TBL + " l "
            "JOIN sys_entity_master em ON em.entity_id=l.target_id "
            "LEFT JOIN sys_text_asset ko ON ko.clicked_id=em.entity_id "
            "  AND ko.text_type='ENTITY_NAME' AND ko.lang_code='KO' "
            "LEFT JOIN sys_text_asset en ON en.clicked_id=em.entity_id "
            "  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN' "
            "WHERE l.clicked_id=? AND l.link_type=? "
            "ORDER BY name",
            (self.media_id, media_link.lt('ENTITY'))).fetchall()
        conn.close()
        for eid, etype, name in rows:
            self._linked_tv.insert('', 'end', iid=str(eid), values=(etype, name))

    def _search(self):
        q = self._q_var.get().strip()
        self._res_tv.delete(*self._res_tv.get_children())
        if not q:
            return
        type_clause = " AND em.entity_type='PERSON'" if self._person_only.get() else ''
        conn = self._db()
        # 이름(KO/EN) + 별명(json_detail.aliases) 매칭
        rows = conn.execute(
            f"SELECT em.entity_id, em.entity_type, "
            f"  COALESCE(ko.contents, en.contents, em.entity_code) AS name, "
            f"  COALESCE(em.json_detail,'') "
            f"FROM sys_entity_master em "
            f"LEFT JOIN sys_text_asset ko ON ko.clicked_id=em.entity_id "
            f"  AND ko.text_type='ENTITY_NAME' AND ko.lang_code='KO' "
            f"LEFT JOIN sys_text_asset en ON en.clicked_id=em.entity_id "
            f"  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN' "
            f"WHERE em.record_status='LIVE'{type_clause} "
            f"  AND (ko.contents LIKE ? OR en.contents LIKE ? "
            f"       OR em.json_detail LIKE ?) "
            f"ORDER BY name LIMIT 80",
            (f'%{q}%', f'%{q}%', f'%{q}%')).fetchall()
        conn.close()
        ql = q.lower()
        for eid, etype, name, jd in rows:
            # 별명 매칭 확인(json_detail LIKE 는 넓으니 이름/별명 실제 포함만)
            ok = ql in (name or '').lower()
            if not ok and jd:
                try:
                    al = json.loads(jd).get('aliases', {})
                    ok = any(ql in str(a).lower()
                             for lst in al.values() for a in lst)
                except Exception:
                    ok = True   # 파싱 실패 시 보수적으로 표시
            if ok:
                self._res_tv.insert('', 'end', iid=str(eid), values=(etype, name))

    def _link(self):
        sel = self._res_tv.selection()
        if not sel:
            return
        eid = int(sel[0])
        conn = self._db()
        exists = conn.execute(
            "SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? AND target_id=?"
            % media_link.TBL,
            (media_link.lt('ENTITY'), self.media_id, eid)).fetchone()
        if exists:
            conn.close()
            messagebox.showinfo('알림', '이미 연결된 대상입니다.', parent=self)
            return
        conn.execute(
            "INSERT INTO %s (link_type, clicked_id, target_id, record_status) "
            "VALUES (?,?,?,'LIVE')" % media_link.TBL,
            (media_link.lt('ENTITY'), self.media_id, eid))
        conn.commit(); conn.close()
        self._changed = True
        self._load_linked()

    def _unlink(self):
        sel = self._linked_tv.selection()
        if not sel:
            return
        eid = sel[0]
        name = self._linked_tv.item(eid, 'values')[1]
        if not messagebox.askyesno('확인', f'"{name}" 연결을 해제합니까?', parent=self):
            return
        conn = self._db()
        conn.execute(
            "DELETE FROM %s WHERE link_type=? AND clicked_id=? AND target_id=?"
            % media_link.TBL,
            (media_link.lt('ENTITY'), self.media_id, int(eid)))
        conn.commit(); conn.close()
        self._changed = True
        self._load_linked()

    def _close(self):
        if self._changed and self.on_done:
            try:
                self.on_done()
            except Exception:
                pass
        self.destroy()


def open_dialog(parent, db_path, media_id, on_done=None):
    if not media_id:
        messagebox.showinfo('알림', '먼저 영상을 선택하세요.', parent=parent)
        return
    _EntityLinkDialog(parent, db_path, media_id, on_done=on_done)


# ── 제목 → 등장 인물 자동 매칭 ─────────────────────────────────────────────────
def load_entity_terms(conn, min_len=2, types=('PERSON',)):
    """LIVE 엔티티의 이름(KO/EN) + 별명(json_detail.aliases) 을 {entity_id: {용어,...}} 로.
    - min_len 미만 용어 제외(오탐 방지).
    - types: 자동매칭 대상 entity_type (기본 PERSON 만 — 장소/나라 부분일치 오탐 차단,
      예: '출애굽기'의 '애굽'=NATION). types=None 이면 전체.
    """
    tclause, tparams = '', []
    if types:
        ph = ','.join('?' * len(types))
        tclause = f" AND em.entity_type IN ({ph})"
        tparams = list(types)
    ent = {}
    for eid, name in conn.execute(
            "SELECT t.clicked_id, t.contents FROM sys_text_asset t "
            "JOIN sys_entity_master em ON em.entity_id=t.clicked_id "
            "WHERE t.text_type='ENTITY_NAME' AND em.record_status='LIVE'"
            # ⚠⚠ **찬양 주제 전용(TOPIC)은 뺀다**(2026-09-10) — EN 은
            #   TERM·DOCTRINE 이 열려 있어(`TYPES_BY_LANG`) `Worship`·`Hope`
            #   가 영어 제목 어디에나 걸린다.
            " AND COALESCE(json_extract(em.json_detail,'$.subtype'),'')"
            "     <> 'TOPIC'" + tclause,
            tparams):
        nm = (name or '').strip()
        if len(nm) >= min_len:
            ent.setdefault(eid, set()).add(nm)
    for eid, jd in conn.execute(
            "SELECT em.entity_id, em.json_detail FROM sys_entity_master em "
            "WHERE em.record_status='LIVE' AND em.json_detail LIKE '%aliases%'" + tclause,
            tparams):
        try:
            al = json.loads(jd).get('aliases', {})
            for lst in al.values():
                for a in lst:
                    s = str(a).strip()
                    if len(s) >= min_len:
                        ent.setdefault(eid, set()).add(s)
        except Exception:
            pass
    return ent


def find_entities_in_title(title, ent_terms):
    """제목에서 **낱말 경계를 지켜** 이름을 찾는다 → entity_id 집합.

    ★★★ **부분 문자열로 찾으면 안 된다** (2026-09-08 — 오연결 11,308건).
      「엘」(EN `Er`)이 `chapter` 에, 「벨」(`Bel`)이 `Abel` 에 걸렸다.
      경계 판정의 집은 `db_media_range.name_ok` 하나다.
    ⚠ 가운뎃점(「대표어 · 음역」)을 가르고 라틴 짧은 이름을 뺀다 —
      `media_text_linker._clean_terms` 와 **같은 규칙**이다.
    """
    if not title:
        return set()
    try:
        import db_media_range as _mr
    except ImportError:                      # 경계 판정을 못 하면 잇지 않는다
        return set()
    low = title.lower()
    out = set()
    for eid, terms in (ent_terms or {}).items():
        hit = False
        for term in terms:
            for part in str(term or '').split('·'):
                part = part.strip()
                if len(part) < 2:
                    continue
                if _mr._script(part) == 'LAT' and len(part) < _mr._LAT_MIN:
                    continue
                tl = part.lower()
                i = low.find(tl)
                while i != -1:
                    if _mr.name_ok(low, i, i + len(part), part):
                        hit = True
                        break
                    i = low.find(tl, i + 1)
                if hit:
                    break
            if hit:
                break
        if hit:
            out.add(eid)
    return out


def autolink_media(conn, media_id, title, ent_terms, also=None):
    """media_id 를 제목 매칭 엔티티(+also) 에 모두 연결(scope='ENTITY'). 신규 링크 수 반환."""
    targets = find_entities_in_title(title, ent_terms)
    if also:
        targets.add(int(also))
    if not targets:
        return 0
    _ty = media_link.lt('ENTITY')
    existing = {int(r[0]) for r in conn.execute(
        "SELECT target_id FROM %s WHERE clicked_id=? AND link_type=?"
        % media_link.TBL, (media_id, _ty)).fetchall()}
    added = 0
    for eid in targets:
        if int(eid) not in existing:
            conn.execute(
                "INSERT INTO %s (link_type, clicked_id, target_id, "
                "record_status) VALUES (?,?,?,'LIVE')" % media_link.TBL,
                (_ty, media_id, int(eid)))
            added += 1
    return added


def batch_autolink(db_path, active_only=True, kids_only=False):
    """기존 영상 제목을 스캔해 누락된 등장인물 링크를 일괄 추가. (영상수, 추가링크수) 반환."""
    conn = appdb.connect(db_path)
    ent_terms = load_entity_terms(conn)
    where = "record_status='LIVE' AND url LIKE '%youtube%'"
    if active_only:
        where += " AND is_active=1"
    if kids_only:
        where += " AND audience='KIDS'"
    rows = conn.execute(
        f"SELECT media_id, title FROM sys_media_asset WHERE {where}").fetchall()
    total_added = 0
    touched = 0
    for mid, title in rows:
        n = autolink_media(conn, mid, title, ent_terms)
        if n:
            total_added += n
            touched += 1
    conn.commit()
    conn.close()
    return touched, total_added
