# -*- coding: utf-8 -*-
"""admin/panel_ad_manager.py — 광고·후원 배너 원격 관리 (Cloudflare ad-config 발행).

'사용자 소통관리 ▸ 광고·후원 관리'. 서버 config(GET /v1/ad-config)를 불러와 편집하고,
[발행]으로 PUT(ADMIN_TOKEN)하면 배포된 앱이 다음 fetch 때 자동 반영(앱 업데이트 0).
타겟 = 사용자 user_country/user_lang (앱 로컬, IP 미수집). 클릭=외부 브라우저.
"""
import json
import os
import threading
import urllib.request
import tkinter as tk
from tkinter import ttk, messagebox

try:
    from admin.panel_help_box import build_help_box
except ImportError:
    from panel_help_box import build_help_box

AD_ENDPOINT = "https://api.hagahtorah.com/v1/ad-config"   # ads.AD_ENDPOINT 와 동일
SCREENS = ['p1_latest', 'shop', 'splash', 'book_chapter_end', 'support_tab']
LIVE_SCREENS = {'p1_latest', 'splash'}   # ★ 2026-10-23 쇼핑몰은 「추천몰 관리」로 옮김(db_shop)   # 앱에 실제 배치된 화면
SCREEN_LABELS = {
    'p1_latest':        '최신 콘텐츠 탭 (작동중)',
    'shop':             '(추천몰 관리로 옮김 — 여기서는 안 쓴다)',
    'splash':           '시작화면 띠 (작동중 · 다음 실행부터)',
    'book_chapter_end': '장 끝 (앱 미배치)',
    'support_tab':      '지원·설정 탭 (앱 미배치)',
}
# 좌우로 펼칠 때 쓰는 짧은 라벨(작동/예약만 표기 — 자세한 설명은 도움말)
SCREEN_SHORT = {
    'p1_latest':        '최신 콘텐츠 (작동)',
    'shop':             '쇼핑몰 (추천몰 관리로 옮김)',
    'splash':           '시작화면 (작동)',
    'book_chapter_end': '장 끝 (예약)',
    'support_tab':      '지원·설정 (예약)',
}
#: 목록 거르개 — 배너와 쇼핑몰을 **갈래로 나눠 본다**(사용자 지시).
#: ⚠ 표를 새로 만들지 않는다 — 같은 `creatives` 를 `screens` 로 가를 뿐이다.
VIEWS = [('ALL', '전체'), ('BANNER', '배너 광고'), ('SHOP', '쇼핑몰 상품')]
SHOP_SCREENS = {'shop'}
#: 보이는 글자 → 슬롯 코드. ⚠ **표를 두 곳에 적지 않는다** — 위 `SCREEN_SHORT`
#: 하나에서 뒤집어 만든다(손으로 또 적으면 이름을 고칠 때 한쪽만 바뀐다).
SCREEN_BY_SHORT = {v: k for k, v in SCREEN_SHORT.items()}
TYPES = ['HOUSE', 'AFFILIATE', 'SPONSOR']
#: 슬롯 기본값 — **화면마다 다르다.** ⚠ 그전에는 전부 `max=1` 이라 서버가
#: 값을 안 주면 **쇼핑몰이 한 칸만** 떴다(5열 × 2행 = 열 칸 설계인데).
#: ★ 이 표 하나를 `__init__` 과 `_apply_loaded` 가 함께 쓴다 — 두 곳에
#:   적으면 「처음 열 때와 불러온 뒤가 다르다」가 난다.
SLOT_DEFAULT = {
    'p1_latest':        {'enabled': True,  'max': 3},
    'shop':             {'enabled': False, 'max': 10},
    'splash':           {'enabled': False, 'max': 1},
    'book_chapter_end': {'enabled': False, 'max': 1},
    'support_tab':      {'enabled': False, 'max': 1},
}
#: 갈래를 고르면 폼의 「띄울 화면」이 **저절로 그 화면에 맞춰진다.**
#: ⚠ 이것이 없으면 「쇼핑몰 상품」을 골라 상품을 담아도 `screens` 가 비어
#:   **그 목록에서 곧바로 사라진다**(실측으로 당했다 · §0-1).
VIEW_SCREEN = {'SHOP': 'shop', 'BANNER': 'p1_latest'}

# 관리자 토큰을 매번 입력하지 않도록 로컬에 기억(개발자 PC 전용, git 밖 홈 디렉터리).
_TOKEN_FILE = os.path.join(os.path.expanduser('~'), '.gemini_ad_admin_token')


def _load_saved_token():
    try:
        with open(_TOKEN_FILE, encoding='utf-8') as f:
            return f.read().strip()
    except Exception:
        return ''


def _save_token(tok):
    try:
        with open(_TOKEN_FILE, 'w', encoding='utf-8') as f:
            f.write(tok or '')
    except Exception:
        pass
def _ui_langs():
    """언어 목록은 `sys_language` 가 정한다(§0-3) — 박아 두면 언어를
    늘렸을 때 이 화면만 예전 목록을 들고 있게 된다."""
    try:
        import lang_config
        # ⚠ `ui_langs()` 는 **코드 문자열의 목록**이다 — 튀플이 아니다.
        #   `for c, *_ in …` 로 풀면 'EN' 이 **'E'** 가 된다(§266차 ⑥ 그 자리).
        return list(lang_config.ui_langs())
    except Exception:
        return ['EN', 'KO', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT']


LANG_CODES = _ui_langs()
COUNTRY_CODES = ['KR', 'US', 'GB', 'JP', 'CN', 'TW', 'HK', 'DE', 'AT', 'CH',
                 'FR', 'ES', 'MX', 'BR', 'PT', 'RU', 'SA', 'AE', 'CA', 'AU']
_TIMEOUT = 8

HELP = [
    ('이 탭의 기능',
     '배포된 사용자 앱의 배너(후원·제휴·하우스 광고)를 서버에서 원격 제어합니다. 여기서 config(배너 목록과 표시 설정)를 '
     '편집해 [발행]하면 Cloudflare 서버(D1 ad_config 표)에 저장되고, 사용자 앱이 시작할 때 받아와 화면에 표시합니다. '
     '→ 앱을 새로 배포하지 않아도 반영됩니다. 타겟은 사용자가 첫 실행/설정에서 선택한 국가(user_country)·언어(user_lang)이며, '
     'IP·위치는 수집하지 않습니다(클릭 시 외부 브라우저로 열림).'),
    ('작업 순서 (이 순서를 지켜야 합니다)',
     '① 위쪽 [화면 슬롯] 에서 배너를 띄울 화면을 체크하고 max(표시 개수)를 정합니다. (체크 안 하면 그 화면엔 안 뜸)\n'
     '② 오른쪽 폼에 배너 하나를 채우고 [추가/수정] 을 누르면 왼쪽 목록에 나타납니다 (여러 개면 반복).\n'
     '③ 맨 위 [발행] 을 눌러야 비로소 서버에 올라가 사용자에게 보입니다.\n'
     '※ [추가/수정] 만 하고 [발행] 을 안 누르면 서버에는 반영되지 않습니다(화면 편집 상태일 뿐).'),
    ('관리자 토큰 (매번 입력 안 해도 됨)',
     '토큰은 발행할 때 "내가 관리자다"를 증명하는 비밀번호입니다. 한 번 [발행] 에 성공하면 이 PC에 기억되어 '
     '다음에 탭을 열면 자동으로 채워집니다 — 매번 입력할 필요 없습니다. (홈 폴더의 숨김파일에 저장; 다른 사람 PC엔 안 옮겨감.) '
     '[서버 불러오기] 는 토큰이 없어도 됩니다(읽기는 공개). 토큰은 [발행](쓰기)에만 필요합니다.'),
    ('"config" 와 "서버 불러오기" 의 뜻',
     'config = 이 탭이 다루는 설정 한 묶음 = ① 배너 목록(크리에이티브) + ② 화면별 표시설정(슬롯 on/off·개수) + '
     '③ 새로고침 주기 + ④ 전체 차단 스위치. 즉 "사용자에게 무엇을·어디에·언제 보일지" 전체입니다.\n'
     '[서버 불러오기] = 지금 서버에 저장돼 있는 이 config(배너 목록 포함)를 그대로 가져와 화면에 채웁니다. '
     '편집을 새로 시작하기 전에 한 번 눌러, 기존에 발행해 둔 내용 위에서 수정하세요(안 누르고 발행하면 빈 상태로 덮어쓸 수 있음).'),
    ('상단 버튼',
     '[발행] — 지금 화면의 편집 내용을 서버에 저장합니다(토큰 필요). 이 버튼을 눌러야 실제로 사용자에게 반영됩니다.\n'
     '[전체 OFF(kill switch)] — 체크 후 [발행] 하면 모든 배너를 즉시 숨깁니다(긴급 차단용. 해제하려면 체크 풀고 다시 발행).\n'
     '[새로고침(h)] — 사용자 앱이 몇 시간마다 config를 다시 받아올지(기본 24시간).'),
    ('띄울 수 있는 화면 (지금 다섯 자리)',
     '최신 콘텐츠 = P4 최신 콘텐츠 탭 우측. 앱에 배너가 들어가 있어 지금 바로 보입니다(작동중).\n'
     '쇼핑몰 = P4 맨 끝 쇼핑몰 탭. 상품 카드가 5열 두 줄로 놓입니다(작동중 · 개수는 max 가 정하고 기본 10).\n'
     '시작화면 = 시작 사진 위/아래의 좁은 띠. 성경구절 띠의 반대편에 붙습니다(작동중 · '
     '다만 시작화면은 켤 때 파일 캐시만 읽으므로 **다음 실행부터** 보입니다).\n'
     '장 끝 · 지원·설정 = 미래용으로 미리 만들어 둔 자리입니다. 아직 앱 화면에 위젯을 안 붙였으므로 '
     '체크하고 발행해도 사용자에게 안 보입니다("앱 미배치"). 나중에 붙이면 같은 설정이 그대로 살아납니다.'),
    ('쇼핑몰 상품 담기 (배너와 담는 법이 같습니다)',
     '상품도 배너와 똑같이 [썸네일 주소] + [설명문] + [누르면 갈 주소] 한 벌입니다. 다른 것은 '
     '「띄울 화면」에서 쇼핑몰을 선택한다는 것뿐입니다 — 그래서 상품용 표를 따로 만들지 않았습니다.\n'
     '① 보기에서 [쇼핑몰 상품] 을 선택하면 폼의 「띄울 화면」에 쇼핑몰이 저절로 켜집니다.\n'
     '② 폼을 채우고 [추가/수정] → 왼쪽 목록에 나타납니다(열 개까지 권장).\n'
     '③ 위쪽에서 쇼핑몰 슬롯을 켜고 [발행] 합니다.\n'
     '※ 사용자 화면의 쇼핑몰 탭은 **상품이 0개면 탭 자체가 없습니다** — 담고 발행하면 저절로 생기고, '
     '비우면 사라집니다. 그래서 "표시하기" 같은 스위치를 따로 누를 필요가 없습니다.\n'
     '※ 제휴 상품이면 종류를 AFFILIATE 로 — 카드마다 "수수료를 받을 수 있습니다" 고지가 자동으로 붙습니다.'),
    ('화면 슬롯 / 크리에이티브 버튼',
     '[화면 슬롯] 의 체크박스 = 그 화면에 배너를 켤지, max = 한 화면에 최대 몇 개.\n'
     '[추가/수정] — 오른쪽 폼 내용을 배너 목록에 추가합니다. 같은 id가 있으면 덮어써서 수정합니다.\n'
     '[삭제] — 왼쪽 목록에서 선택한 배너를 제거합니다(발행해야 서버에도 반영).\n'
     '[폼 비우기] — 입력 폼을 초기화합니다(새 배너 작성 시작). 왼쪽 목록 항목을 클릭하면 그 내용이 폼으로 불려와 수정할 수 있습니다.'),
    ('입력 필드 의미 (배너 1개 = 카드)',
     '배너는 SNS 공유카드처럼 [썸네일 이미지] + [설명문] + [링크] 로 표시됩니다(테두리 없음, 좌/중/우 가로 배치).\n'
     'id = 배너 고유 이름(영문·숫자, 예 donate1). 같은 id로 [추가/수정]하면 수정됨. (id만 필수)\n'
     'type = HOUSE(자체 후원·홍보) · AFFILIATE(제휴 — "수수료를 받을 수 있습니다" 고지 자동 표시) · SPONSOR(유료 스폰서).\n'
     'image = 썸네일 주소(url·선택). 외부 URL 또는 내 서버 URL 무엇이든. 없어도 됨(설명문만으로도 표시).\n'
     'click = 클릭 시 열 주소(선택). 비우면 클릭해도 안 열림 → 이미지만 넣어 배경/말씀카드로 쓸 수 있음.\n'
     'desc(설명문) = 카드에 보일 문구. 다국어 불필요 — 타겟 langs/countries 언어에 맞춰 그 언어로 쓰면 됨.\n'
     'weight = 같은 자리 경합 시 우선순위(클수록 먼저). active_from/active_to = 게재 기간(YYYY-MM-DD, 비우면 제한 없음).'),
    ('미리보기',
     '[미리보기] — lang·country·screen을 입력하면, 그 조건의 사용자에게 어떤 배너가 실제로 표시될지 시뮬합니다. '
     '슬롯이 꺼져 있거나 타겟(언어/국가)이 안 맞으면 "표시될 배너 없음"이 나옵니다. 발행 전 확인용입니다.'),
]


def _http(method, url, token=None, body=None):
    headers = {'User-Agent': 'GeminiBibleApp/1.0 (+ad-admin)'}
    data = None
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode('utf-8')
        headers['content-type'] = 'application/json'
    if token:
        headers['x-admin-token'] = token
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
        return resp.status, resp.read().decode('utf-8')


def _csv(s):
    return [x.strip() for x in (s or '').split(',') if x.strip()]


class AdManagerPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self._cfg = {'config_version': 0, 'kill_switch': False, 'refresh_hours': 24,
                     'slots': {s: dict(SLOT_DEFAULT[s]) for s in SCREENS},
                     'creatives': []}
        #: 목록 갈래 — 배너/쇼핑몰을 나눠 본다
        self._view = tk.StringVar(value='ALL')
        self._loaded = False     # 서버에서 한 번이라도 받았나(빈 목록의 까닭)
        self._build()
        self._refill_top()
        self._refill()
        # ⚠ **열면 저절로 불러온다** — 그전에는 눌러야 채워져서 「관리자 화면에
        #   아무것도 등록된 것이 없다」로 보였다(사용자 신고 그 자리).
        try:
            self.after(200, self._load_server)
        except Exception:
            pass

    # ── UI ────────────────────────────────────────────────────────────
    def _build(self):
        build_help_box(self, '광고·후원 관리 (원격 발행)', HELP, height=12)

        bar = ttk.Frame(self); bar.pack(fill='x', padx=8, pady=4)
        ttk.Label(bar, text='관리자 토큰:').pack(side='left')
        self._token = ttk.Entry(bar, width=24, show='*'); self._token.pack(side='left', padx=(2, 2))
        _saved = _load_saved_token()
        if _saved:
            self._token.insert(0, _saved)   # 한 번 발행하면 다음부터 자동 채움
        ttk.Label(bar, text='(한번 발행하면 기억됨)', foreground='#888',
                  font=('Malgun Gothic', 8)).pack(side='left', padx=(0, 10))
        ttk.Button(bar, text='서버 불러오기', command=self._load_server).pack(side='left', padx=2)
        ttk.Button(bar, text='발행(PUT)', command=self._publish).pack(side='left', padx=2)
        self._kill = tk.IntVar(value=0)
        ttk.Checkbutton(bar, text='전체 OFF(kill switch)', variable=self._kill).pack(side='left', padx=12)
        ttk.Label(bar, text='새로고침(h):').pack(side='left')
        self._refresh = ttk.Spinbox(bar, from_=1, to=168, width=4); self._refresh.set('24')
        self._refresh.pack(side='left', padx=2)
        self._stat = tk.Label(bar, text='', fg='#1A5276', font=('Malgun Gothic', 9))
        self._stat.pack(side='right', padx=8)

        # 슬롯(화면별 on/off·max)
        sf = ttk.LabelFrame(self, text=' 화면 슬롯 ')
        sf.pack(fill='x', padx=8, pady=(0, 4))
        self._slot_vars = {}
        for i, s in enumerate(SCREENS):
            row = ttk.Frame(sf); row.pack(side='left', anchor='w', padx=12, pady=2)
            en = tk.IntVar(value=1 if self._cfg['slots'][s]['enabled'] else 0)
            mx = tk.StringVar(value=str(self._cfg['slots'][s]['max']))
            ttk.Checkbutton(row, text=SCREEN_SHORT.get(s, s), variable=en).pack(side='left')
            ttk.Label(row, text='max').pack(side='left', padx=(6, 1))
            # ⚠ 상한 5 → 20 — 쇼핑몰은 한 화면에 10개다(5 면 값이 잘린다).
            ttk.Spinbox(row, from_=0, to=20, width=3, textvariable=mx).pack(side='left')
            self._slot_vars[s] = (en, mx)

        body = ttk.Panedwindow(self, orient='horizontal'); body.pack(fill='both', expand=True, padx=8, pady=4)
        # 좌: 크리에이티브 목록
        left = ttk.Frame(body); body.add(left, weight=1)
        # 갈래 — **목록만** 가른다(값은 한 벌 그대로다)
        vb = ttk.Frame(self); vb.pack(fill='x', padx=8, pady=(4, 0))
        ttk.Label(vb, text='보기:').pack(side='left')
        for code, name in VIEWS:
            ttk.Radiobutton(vb, text=name, value=code, variable=self._view,
                            command=self._on_view).pack(side='left', padx=4)
        self._empty = tk.Label(vb, text='', fg='#7F8C8D',
                               font=('Malgun Gothic', 9))
        self._empty.pack(side='left', padx=12)

        cols = ('id', 'type', 'screens', 'tgt', 'w')
        tv = ttk.Treeview(left, columns=cols, show='headings', selectmode='browse')
        for c, t, w in (('id', '이름', 110), ('type', '종류', 70),
                        ('screens', '띄울 화면', 110),
                        ('tgt', '언어 / 국가', 110), ('w', '순위', 40)):
            tv.heading(c, text=t); tv.column(c, width=w, anchor='w')
        vs = ttk.Scrollbar(left, orient='vertical', command=tv.yview); tv.configure(yscrollcommand=vs.set)
        vs.pack(side='right', fill='y'); tv.pack(side='left', fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_select)
        self._tv = tv

        # 우: 편집 폼 — 코드 직접 타이핑 대신 콤보/체크로 선택
        right = ttk.Frame(body); body.add(right, weight=1)
        self._fields = {}

        def _entry(rr, key, label):
            ttk.Label(right, text=label).grid(row=rr, column=0, sticky='w', padx=4, pady=2)
            w = ttk.Entry(right, width=34); w.grid(row=rr, column=1, sticky='w', padx=4, pady=2)
            self._fields[key] = w

        # 버튼은 항상 폼 맨 위(잘림 방지·§0). 필드는 그 아래로.
        btns = ttk.Frame(right); btns.grid(row=0, column=0, columnspan=2, pady=(0, 6), sticky='w')
        ttk.Button(btns, text='추가/수정', command=self._upsert).pack(side='left', padx=2)
        ttk.Button(btns, text='삭제', command=self._delete).pack(side='left', padx=2)
        ttk.Button(btns, text='폼 비우기', command=self._clear_form).pack(side='left', padx=2)

        _entry(1, 'id', '이름 (영문·숫자 · 같은 이름이면 덮어씁니다)')
        ttk.Label(right, text='종류').grid(row=2, column=0, sticky='w', padx=4, pady=2)
        self._fields['type'] = ttk.Combobox(right, values=TYPES, state='readonly', width=31)
        self._fields['type'].set('HOUSE')
        self._fields['type'].grid(row=2, column=1, sticky='w', padx=4, pady=2)

        # screens = 체크박스(여러 화면 선택 가능) — 좌우로 펼침(짧은 라벨)
        ttk.Label(right, text='띄울 화면').grid(row=3, column=0, sticky='nw', padx=4, pady=2)
        sfr = ttk.Frame(right); sfr.grid(row=3, column=1, sticky='w', padx=4, pady=2)
        self._screen_vars = {}
        for s in SCREENS:
            v = tk.IntVar(value=0)
            ttk.Checkbutton(sfr, text=SCREEN_SHORT.get(s, s), variable=v).pack(side='left')
            self._screen_vars[s] = v

        # langs / countries = 콤보에서 골라 추가 (빈=전체)
        self._langs_sel, self._langs_disp = self._multi_row(
            right, 4, '언어 (비우면 전체)', LANG_CODES)
        self._cc_sel, self._cc_disp = self._multi_row(
            right, 5, '국가 (비우면 전체)', COUNTRY_CODES)

        _entry(6, 'image', '썸네일 주소 (없어도 됩니다)')
        _entry(7, 'click', '누르면 갈 주소 (비우면 눌러도 안 열립니다)')
        _entry(8, 'desc', '설명문 (카드에 보일 글 · 그 언어로 씁니다)')
        _entry(9, 'weight', '우선순위 (클수록 먼저)')
        # ★ 게재 기간 = 「지금 만들어 두고 나중에 보인다」(1.txt 20번 5)
        _entry(10, 'active_from', '게재 시작일 (YYYY-MM-DD · 비우면 제한 없음)')
        _entry(11, 'active_to', '게재 종료일 (YYYY-MM-DD · 비우면 제한 없음)')
        self._fields['weight'].insert(0, '1')

        # 미리보기
        pv = ttk.LabelFrame(self, text=' 미리보기 (특정 언어·국가에서 표시될 배너) ')
        pv.pack(fill='x', padx=8, pady=(0, 8))
        ttk.Label(pv, text='언어').pack(side='left', padx=(8, 1))
        self._pv_lang = ttk.Entry(pv, width=6); self._pv_lang.insert(0, 'KO'); self._pv_lang.pack(side='left')
        ttk.Label(pv, text='국가').pack(side='left', padx=(8, 1))
        self._pv_cc = ttk.Entry(pv, width=8); self._pv_cc.insert(0, 'KR'); self._pv_cc.pack(side='left')
        ttk.Label(pv, text='화면').pack(side='left', padx=(8, 1))
        # ⚠ 보이는 것은 사람 말, 고른 값은 **여전히 슬롯 코드**다
        #   (`_preview` 가 그 코드로 재다 — 한 자리만 바꾸면 조용히 엉뚱한
        #   화면을 재게 된다).
        self._pv_scr = ttk.Combobox(pv, state='readonly', width=22,
                                    values=[SCREEN_SHORT.get(s, s) for s in SCREENS])
        self._pv_scr.set(SCREEN_SHORT.get('p1_latest', 'p1_latest'))
        self._pv_scr.pack(side='left')
        ttk.Button(pv, text='미리보기', command=self._preview).pack(side='left', padx=8)
        self._pv_out = tk.Label(pv, text='', fg='#1E8449', font=('Malgun Gothic', 9))
        self._pv_out.pack(side='left', padx=8)

    def _multi_row(self, parent, row, label, options):
        """콤보에서 선택해 추가하는 다중선택 행. (sel 리스트, disp StringVar) 반환. 빈 리스트=전체."""
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky='w', padx=4, pady=2)
        fr = ttk.Frame(parent); fr.grid(row=row, column=1, sticky='w', padx=4, pady=2)
        sel = []
        disp = tk.StringVar(value='(전체)')
        cb = ttk.Combobox(fr, values=options, state='readonly', width=8)
        cb.pack(side='left')
        ttk.Label(fr, textvariable=disp, foreground='#1A5276', width=20, anchor='w').pack(side='left', padx=4)

        def _add(_e=None):
            v = cb.get().strip()
            if v and v not in sel:
                sel.append(v); disp.set(', '.join(sel))
            cb.set('')

        def _clr():
            sel.clear(); disp.set('(전체)'); cb.set('')

        cb.bind('<<ComboboxSelected>>', _add)
        ttk.Button(fr, text='비우기', width=6, command=_clr).pack(side='left', padx=2)
        return sel, disp

    # ── 데이터 ↔ UI ───────────────────────────────────────────────────
    def _on_view(self):
        """갈래를 바꾸면 목록을 거르고, **빈 폼이면 기본 화면을 맞춘다.**

        ⚠ **적다 만 폼은 안 건드린다** — 갈래를 잘못 눌렀다고 쓰던 글을
          날리면 안 된다. 그래서 `id` 칸이 비었을 때만 손댄다.
        """
        self._refill()
        try:
            if not self._fields['id'].get().strip():
                self._clear_form()
        except Exception:
            pass

    def _refill_top(self):
        """위쪽 값(전체 OFF · 새로고침 · 화면 슬롯)을 `_cfg` 에서 채운다.

        ⚠⚠⚠ **목록을 그릴 때 함께 부르면 안 된다** — 이 값들은 `_collect`
          전까지 `_cfg` 에 없으므로, 슬롯을 체크하고 상품을 담는 순간
          (`_upsert` → `_refill`) **그 체크가 조용히 풀렸다**(실측).
          그대로 발행하면 사용자에게 0개다. ⇒ **처음 열 때와 서버에서
          불러왔을 때만** 부른다.
        """
        self._kill.set(1 if self._cfg.get('kill_switch') else 0)
        self._refresh.set(str(self._cfg.get('refresh_hours', 24)))
        for s, (en, mx) in self._slot_vars.items():
            sl = self._cfg.get('slots', {}).get(s, SLOT_DEFAULT.get(s, {}))
            en.set(1 if sl.get('enabled') else 0)
            mx.set(str(sl.get('max', SLOT_DEFAULT.get(s, {}).get('max', 1))))

    def _refill(self):
        self._tv.delete(*self._tv.get_children())
        view = self._view.get()
        shown = 0
        for i, c in enumerate(self._cfg.get('creatives', [])):
            scr = set(c.get('screens') or [])
            # ⚠ **iid 는 언제나 원본 자리 번호**다 — 걸러 낸 뒤 다시 매기면
            #   [삭제]가 엉뚱한 줄을 지운다(`del creatives[int(iid)]`).
            if view == 'SHOP' and not (scr & SHOP_SCREENS):
                continue
            if view == 'BANNER' and (scr & SHOP_SCREENS) and not (scr - SHOP_SCREENS):
                continue
            tgt = '/'.join([','.join(c.get('langs') or []) or '*', ','.join(c.get('countries') or []) or '*'])
            self._tv.insert('', 'end', iid=str(i),
                            values=(c.get('id', ''), c.get('type', ''),
                                    ','.join(c.get('screens') or []), tgt, c.get('weight', 1)))
            shown += 1
        # ⚠ 빈 목록의 **까닭**을 말한다 — 「아직 안 불러왔다」와 「없다」는 다르다
        if shown:
            self._empty.config(text='%d개' % shown)
        elif not self._loaded:
            self._empty.config(text='아직 서버에서 불러오지 않았습니다.')
        elif self._cfg.get('creatives'):
            self._empty.config(text='이 갈래에 해당하는 것이 없습니다.')
        else:
            self._empty.config(text='서버에 등록된 것이 없습니다.')

    def _collect(self):
        """UI → config dict."""
        self._cfg['kill_switch'] = bool(self._kill.get())
        try:
            self._cfg['refresh_hours'] = int(self._refresh.get())
        except ValueError:
            self._cfg['refresh_hours'] = 24
        for s, (en, mx) in self._slot_vars.items():
            try:
                m = int(mx.get())
            except ValueError:
                m = 1
            self._cfg.setdefault('slots', {})[s] = {'enabled': bool(en.get()), 'max': m}
        self._cfg['config_version'] = int(self._cfg.get('config_version', 0)) + 1
        return self._cfg

    def _on_select(self, _e):
        sel = self._tv.selection()
        if not sel:
            return
        c = self._cfg['creatives'][int(sel[0])]
        self._clear_form()
        for k, w in self._fields.items():
            v = c.get(k, '')
            if k == 'type':
                w.set(v or 'HOUSE')
            else:
                w.delete(0, 'end'); w.insert(0, str(v) if v != '' else '')
        for s, var in self._screen_vars.items():
            var.set(1 if s in (c.get('screens') or []) else 0)
        self._langs_sel[:] = list(c.get('langs') or [])
        self._langs_disp.set(', '.join(self._langs_sel) or '(전체)')
        self._cc_sel[:] = list(c.get('countries') or [])
        self._cc_disp.set(', '.join(self._cc_sel) or '(전체)')
        # 구버전 text_default → 설명문(desc) 칸에 표시(호환)
        if not self._fields['desc'].get().strip() and c.get('text_default'):
            self._fields['desc'].delete(0, 'end')
            self._fields['desc'].insert(0, c.get('text_default'))

    def _clear_form(self):
        for k, w in self._fields.items():
            if k == 'type':
                w.set('HOUSE')
            else:
                w.delete(0, 'end')
        self._fields['weight'].insert(0, '1')
        for var in getattr(self, '_screen_vars', {}).values():
            var.set(0)
        # ★ 고른 갈래가 **기본 화면**을 정한다 — 「쇼핑몰 상품」을 보며
        #   담으면 `shop` 이 켜진 채로 시작한다. 「전체」에서는 안 건드린다
        #   (무엇을 담는지 화면이 모르므로 지어내지 않는다).
        _s = VIEW_SCREEN.get(self._view.get())
        if _s and _s in getattr(self, '_screen_vars', {}):
            self._screen_vars[_s].set(1)
        if hasattr(self, '_langs_sel'):
            self._langs_sel.clear(); self._langs_disp.set('(전체)')
        if hasattr(self, '_cc_sel'):
            self._cc_sel.clear(); self._cc_disp.set('(전체)')

    def _form_to_creative(self):
        f = self._fields
        cid = f['id'].get().strip()
        if not cid:
            messagebox.showinfo('광고', 'id를 입력하세요.', parent=self.winfo_toplevel()); return None
        try:
            w = int(f['weight'].get() or '1')
        except ValueError:
            w = 1
        screens = [s for s, v in self._screen_vars.items() if v.get()]
        return {
            'id': cid, 'type': f['type'].get() or 'HOUSE',
            'screens': screens, 'langs': list(self._langs_sel), 'countries': list(self._cc_sel),
            'image': f['image'].get().strip(), 'click': f['click'].get().strip(),
            'desc': f['desc'].get().strip(), 'weight': w,
            'active_from': f['active_from'].get().strip(), 'active_to': f['active_to'].get().strip(),
        }

    def _upsert(self):
        c = self._form_to_creative()
        if not c:
            return
        lst = self._cfg.setdefault('creatives', [])
        for i, e in enumerate(lst):
            if e.get('id') == c['id']:
                lst[i] = c; break
        else:
            lst.append(c)
        self._refill()
        # ⚠⚠⚠ **담았는데 아무 데도 안 뜨는 자리를 말한다**(§0-1).
        #   담는 것과 보이는 것은 다른 일이고, 그 사이에 문이 넷 있다 —
        #   화면 · 슬롯 스위치 · 개수 상한 · 게재 기간. 조용히 지나가면
        #   관리자는 발행하고 나서야 안 보이는 것을 안다.
        #   ★ **자동으로 켜지 않는다** — 「지금 만들고 나중에 켠다」가
        #     사용자가 요구한 기능이다(20번 5). 코드가 그 결정을 대신하면
        #     날짜를 넣어 둔 뜻이 사라진다.
        self._stat.config(text=f"{c['id']} 반영(미발행) {self._why_hidden(c)}")

    def _why_hidden(self, c):
        """이 크리에이티브가 **지금 설정으로는 안 보이는 까닭** 한 줄."""
        if self._kill.get():
            return '· ⚠ 전체 OFF 라 아무것도 안 뜹니다'
        scr = c.get('screens') or []
        if not scr:
            return '· ⚠ 「띄울 화면」을 하나도 안 선택해 어디에도 안 뜹니다'
        why = []
        for s in scr:
            en, mx = self._slot_vars.get(s, (None, None))
            name = SCREEN_SHORT.get(s, s)
            if en is not None and not en.get():
                why.append('「%s」 슬롯이 꺼져 있습니다' % name)
                continue
            try:
                m = int(mx.get() or '0') if mx is not None else 1
            except ValueError:
                m = 1
            if m <= 0:
                why.append('「%s」 개수가 0 입니다' % name)
                continue
            # ⚠ 상한에 걸려 **일부만 뜨는 것**도 말한다 — 슬롯이 켜져 있어
            #   「보입니다」로 끝나면 아홉 개가 조용히 사라진다.
            n = sum(1 for x in self._cfg.get('creatives', [])
                    if s in (x.get('screens') or []))
            if n > m:
                why.append('「%s」 에 %d개를 담았는데 max 가 %d 이라 %d개만 뜹니다'
                           % (name, n, m, m))
        try:
            import ads as _ads
            if not _ads.in_window(c):
                why.append('게재 기간이 아직/이미 지났습니다')
        except Exception:
            pass
        return ('· ⚠ ' + ' · '.join(why)) if why else '· 발행하면 보입니다'

    def _delete(self):
        sel = self._tv.selection()
        if not sel:
            return
        del self._cfg['creatives'][int(sel[0])]
        self._refill(); self._clear_form()

    # ── 서버 ──────────────────────────────────────────────────────────
    # 네트워크 호출은 백그라운드 스레드에서 — 메인 UI가 멈추지(=목록이 늦게 뜨지) 않게.
    def _load_server(self):
        self._stat.config(text='서버에서 불러오는 중...')

        def work():
            try:
                st, body = _http('GET', AD_ENDPOINT)
                cfg = json.loads(body)
                self.after(0, lambda: self._apply_loaded(cfg))
            except Exception as e:
                self.after(0, lambda e=e: messagebox.showerror(
                    '광고', f'불러오기 실패:\n{e}', parent=self.winfo_toplevel()))
        threading.Thread(target=work, daemon=True).start()

    def _apply_loaded(self, cfg):
        self._loaded = True
        self._cfg = cfg
        # 서버에 슬롯이 비어있어도 알려진 화면은 항상 유지(체크 상태 보존용 기본 채움)
        slots = self._cfg.get('slots') or {}
        for s in SCREENS:
            slots.setdefault(s, dict(SLOT_DEFAULT[s]))
        self._cfg['slots'] = slots
        self._cfg.setdefault('creatives', [])
        self._refill_top()      # ★ 위쪽 값은 **여기서만** 갈아 끼운다
        self._refill()
        self._stat.config(text=f"불러옴 (v{self._cfg.get('config_version', 0)})")

    def _publish(self):
        token = self._token.get().strip()
        if not token:
            messagebox.showinfo('광고', '관리자 토큰을 입력하세요.', parent=self.winfo_toplevel()); return
        cfg = self._collect()
        self._stat.config(text='발행 중...')

        def work():
            try:
                st, body = _http('PUT', AD_ENDPOINT, token=token, body=cfg)
                _save_token(token)   # 성공 시 토큰 기억 → 다음부터 자동 채움
                self.after(0, lambda: (
                    self._stat.config(text=f"발행 완료 (v{cfg['config_version']})"),
                    messagebox.showinfo('광고', f'발행되었습니다.\n{body}',
                                        parent=self.winfo_toplevel())))
            except Exception as e:
                self.after(0, lambda e=e: messagebox.showerror(
                    '광고', f'발행 실패:\n{e}', parent=self.winfo_toplevel()))
        threading.Thread(target=work, daemon=True).start()

    # ── 미리보기 (in-memory config 기준, ads.pick 로직과 동일) ──
    def _preview(self):
        self._collect()
        lang = self._pv_lang.get().strip().upper()
        cc = self._pv_cc.get().strip().upper()
        # ⚠ 보이는 글자를 다시 **슬롯 코드**로 되돌린다 — 안 되돌리면
        #   없는 슬롯을 묻게 되어 늘 「이 슬롯 OFF」만 나온다.
        screen = SCREEN_BY_SHORT.get(self._pv_scr.get(), self._pv_scr.get())
        if self._cfg.get('kill_switch'):
            self._pv_out.config(text='(kill switch ON — 전부 숨김)'); return
        slot = self._cfg.get('slots', {}).get(screen, {})
        if not slot.get('enabled'):
            self._pv_out.config(text='(이 슬롯 OFF)'); return
        out = []
        for c in self._cfg.get('creatives', []):
            if screen not in (c.get('screens') or []):
                continue
            ls = [x.upper() for x in (c.get('langs') or [])]
            cs = [x.upper() for x in (c.get('countries') or [])]
            if ls and lang not in ls:
                continue
            if cs and cc not in cs:
                continue
            out.append(c.get('id'))
        out = out[: int(slot.get('max', 1))]
        self._pv_out.config(text=('표시: ' + ', '.join(out)) if out else '(표시될 배너 없음)')
