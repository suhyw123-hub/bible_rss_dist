"""
admin/lazy_tabs.py
------------------
ttk.Notebook 서브탭 '지연 빌드' 헬퍼.

각 관리자 패널이 생성자에서 서브탭 4~5개를 전부 생성하던 것을, **보이는 첫 탭만 즉시
빌드하고 나머지는 그 탭을 처음 선택할 때 빌드**한다. 사용자가 대개 패널을 열고 한 탭만
보므로 4~5개 → 1개로 생성 작업이 줄어 화면 열기가 빨라진다. 화면 모양은 동일하다.

핵심 원칙 (CLAUDE.md §29):
- 무거운 빌드를 `<<NotebookTabChanged>>` 핸들러 안에서 동기 실행하지 않는다 → after_idle 양보.
  (핸들러 내 동기 빌드는 UI 블로킹 + geometry 회귀를 부른다.)
- 첫(보이는) 탭만 생성 시 동기 빌드(start), 나머지는 최초 선택 시 빌드.
- 프로그램이 특정 탭을 직접 띄워야 하면 `select(idx)`/`ensure(idx)`로 동기 빌드 후 접근.

사용 패턴:
    self._lazy = LazyNotebook(self)
    self._lazy.nb.pack(fill='both', expand=True)
    self._lazy.add('  수집  ', lambda c: _CollectTab(c, on_done=self._after))
    self._lazy.add('  검토  ', lambda c: _ReviewTab(c))
    self._lazy.start()
    ...
    rev = self._lazy.ensure(1)   # 빌드 보장 후 위젯 접근
    built = self._lazy.get(1)    # 이미 빌드됐으면 위젯, 아니면 None (강제 빌드 안 함)
"""

import tkinter as tk
from tkinter import ttk


class LazyNotebook:
    def __init__(self, parent, on_show=None):
        """on_show(idx): 탭이 표시될 때마다(빌드 완료 후) 호출되는 선택적 콜백.
        기존 패널의 '탭 선택 시 새로고침' 로직을 보존하는 데 쓴다."""
        self.nb = ttk.Notebook(parent)
        self._builders = []     # idx -> builder(container) -> widget
        self._containers = []    # idx -> 컨테이너 Frame
        self._widgets = {}       # idx -> 빌드된 위젯
        self._on_show = on_show
        self.nb.bind('<<NotebookTabChanged>>', self._on_tab_changed)

    def add(self, title, builder):
        """탭 추가. builder(container)는 container를 부모로 위젯을 생성해 반환한다.
        반환 위젯은 헬퍼가 fill·expand로 pack한다 (builder가 직접 pack할 필요 없음)."""
        idx = len(self._builders)
        container = ttk.Frame(self.nb)
        self.nb.add(container, text=title)
        self._builders.append(builder)
        self._containers.append(container)
        return idx

    def ensure(self, idx):
        """탭 idx의 실제 위젯을 최초 1회 빌드하고 반환한다. 이미 빌드됐으면 그대로 반환."""
        if idx in self._widgets:
            return self._widgets[idx]
        container = self._containers[idx]
        try:
            w = self._builders[idx](container)
        except Exception:
            import traceback
            traceback.print_exc()
            w = tk.Label(container, text='패널 로드 오류 — 콘솔 로그 확인',
                         fg='red', bg='#fff0f0')
        if w is not None:
            w.pack(fill='both', expand=True)
        self._widgets[idx] = w
        return w

    def get(self, idx):
        """이미 빌드됐으면 위젯, 아니면 None (지연 빌드 강제하지 않음)."""
        return self._widgets.get(idx)

    def select(self, idx):
        """탭 idx를 빌드 보장 후 선택(표시)한다."""
        self.ensure(idx)
        self.nb.select(idx)

    def start(self):
        """첫(보이는) 탭만 즉시 빌드한다. 패널 생성 마지막에 호출."""
        if self._builders:
            self.ensure(0)

    def _on_tab_changed(self, _evt):
        idx = self.nb.index('current')
        if idx in self._widgets:
            self._fire_show(idx)
        else:
            # 핸들러 내 동기 빌드 금지 → 유휴 시간에 빌드(브리프 빈 화면 후 채워짐)
            self.nb.after_idle(lambda i=idx: self._build_then_show(i))

    def _build_then_show(self, idx):
        self.ensure(idx)
        self._fire_show(idx)

    def _fire_show(self, idx):
        if self._on_show:
            try:
                self._on_show(idx)
            except Exception:
                import traceback
                traceback.print_exc()
