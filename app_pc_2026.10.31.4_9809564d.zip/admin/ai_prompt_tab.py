# -*- coding: utf-8 -*-
"""AI 작성·번역 ▸ 프롬프트 탭 — **개별 프롬프트를 적고 조립해 본다** (2026-09-29 294차 · `docs/1.txt` 1번).

사용자 지시(1.txt 1번 1)~5)):
  「개별 프롬프트 작성 후 조립 방식으로 변경. 왼쪽 트리 제거. [수정]/[조회].
   수정 = 세 계층(자산/업무/언어) 버튼 · **셋 중 하나만** 선택 · 버튼마다 개별
   프롬프트 · **자동 저장**(저장 버튼 없음) · 「전체」→「공통」 · 추가 버튼 없음.
   296차 — 단추 ● 표식 없음 · [예제][게이트]는 위 띠 오른쪽(다시 누르면 접힘) ·
   예제는 고른 단추의 것만.
   조회 = 계층마다 하나씩 · 공통 버튼 없음 · **읽기 전용**(고치려 하면 「수정
   버튼을 누르고 수정하세요」) · 결합 프롬프트를 보인다 → 「프롬프트 보기」 불필요.
   결합목록 화면·「이 층 지우기」·「새층」 제거. 왼쪽 아래 = 예제 · 게이트.
   오른쪽 성격 칸은 크기를 바꿀 수 있어야 한다.」

★★★ **층의 집은 그대로다** — `sys_ai_prompt`(`db_ai_job.set_layer/get_layer`).
  이 화면은 **고르는 방법**만 바꿨다: 목록(트리)에서 층을 찾는 대신 **세 계층의
  단추 하나**가 곧 층이다. 자산 단추 = `(kind, 범위, '', '')` · 업무 단추 =
  `('', '', task, '')` · 언어 단추 = `('', '', '', lang)` · 공통 = 넷이 다 빈 층.
  ⚠ 옛 프로필(`sys_ai_profile`)은 `db_ai_job.migrate_profiles` 가 층으로 옮겼다 —
    범위가 있던 프로필은 자산 단추 옆 **범위 콤보**에서 그대로 열린다.

★★★ **자동 저장** — 칸을 고치면 0.7초 뒤에 그 칸만 `set_layer` 로 적는다.
  단추를 옮기거나 [조회]로 넘어갈 때 **먼저 남은 것을 적는다**(잃지 않는다).
  ⚠ 빈 칸으로 지우면 그 칸이 **삭제**된다(`set_layer` 규칙 — 빈 줄이 남으면
    화면이 거짓말한다). 그래서 「이 층 지우기」 단추가 필요 없다.

★★★ **조회 = 실제로 나가는 글** — `db_ai_job.layer_sources` 가 `compose_prompt`
  와 **같은 규칙**으로 합치고, 줄마다 어느 단추에서 왔는지 회색으로 적는다.
  쌓는 성격(문체·반드시·금지·용어)은 다 보이고, 이기는 성격(역할·할 일·성경
  인용·분량·예시·출력서식)은 **이긴 것만** 보인다 — 실제로 보내는 것이 그것이다.

⚠ 팝업을 안 쓴다 — 경고는 칸 위 붉은 글 한 줄이다(§262차 ② 하네스가 모달을 막는다).
"""
import os
import sys
import time

import tkinter as tk
from tkinter import ttk

# ⚠ `admin/` 안 모듈은 앱 뿌리를 스스로 경로에 둔다(§0-5 `panel_channel_mine` 그 자리) —
#   관리자 앱이 넣어 주는 차례에 기대면 단독 selftest 가 그 자리에서 죽는다.
_APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _APP not in sys.path:
    sys.path.insert(0, _APP)

import db_ai_job as AJ          # noqa: E402
import db_ai_run as AR          # noqa: E402

try:
    import ui_theme as UT
except Exception:                                         # noqa: BLE001
    UT = None

#: 계층 이름 — 화면 글자(사람 말)
ROW_NAME = {'KIND': '자산', 'TASK': '업무', 'LANG': '언어'}
COMMON = '공통'
VIEW_WARN = '수정 버튼을 누르고 수정하세요'
AUTOSAVE_MS = 700
ROW_COLS = 7          # 자산 단추가 한 줄에 몇 개 — 넘으면 다음 줄로 흐른다
KIND_COLS = 3         # ★ 317차-19 (42-3) — 왼쪽 기둥이 좁아 자산은 세 칸씩


def _kw(active):
    """단추 서식 — 선택한 것은 [Focus] 규격(진한 바탕), 나머지는 밋밋하게."""
    if UT is None:
        return {'relief': 'sunken' if active else 'raised'}
    try:
        kw = UT.focus_kw() if active else UT.flat_btn()
        kw.setdefault('padx', 8)
        kw.setdefault('pady', 2)
        if not active:
            kw['highlightthickness'] = 1
            kw['highlightbackground'] = UT.C('border') or '#C8C8C8'
        return kw
    except Exception:                                     # noqa: BLE001
        return {'relief': 'sunken' if active else 'raised'}


class _Row(ttk.Frame):
    """단추 한 줄(계층 하나) — `items=[(열쇠, 글자)]` · 흐르는 배치."""

    def __init__(self, parent, key, name, items, on_pick, cols=ROW_COLS):
        super().__init__(parent)
        # ★★★ `key` 는 계층 열쇠('KIND'·'TASK'·'LANG') · `name` 은 화면 글자('자산').
        #   295차 실측 — 옛 판은 단추가 **화면 글자**를 `on_pick` 에 넘겨
        #   `self._rows['자산']` 에서 죽고, `_active` 가 ('자산', kind) 로 남아
        #   자산 프롬프트가 **언어 층**(lang=kind)에 저장됐다. 하네스는 `pick('KIND')`
        #   를 직접 불러 그 길을 안 지났다 — 이제 실제 단추를 눌러 잰다.
        self._key = key
        self._name = name
        self._on_pick = on_pick
        self._btn = {}
        self._active = None
        ttk.Label(self, text=name, width=5,
                  font=('', 9, 'bold')).grid(row=0, column=0, sticky='nw',
                                             padx=(4, 6), pady=2)
        body = ttk.Frame(self)
        body.grid(row=0, column=1, sticky='w')
        for i, (key, text) in enumerate(items):
            b = tk.Button(body, text=text,
                          command=lambda k=key: self._on_pick(self._key, k),
                          **_kw(False))
            b.grid(row=i // cols, column=i % cols, sticky='w', padx=2, pady=2)
            self._btn[key] = b

    def keys(self):
        return list(self._btn)

    def set_active(self, key):
        self._active = key if key in self._btn else None
        for k, b in self._btn.items():
            try:
                b.configure(**_kw(k == self._active))
            except Exception:                             # noqa: BLE001
                pass

    def active(self):
        return self._active

    # ⚠ 296차 — 단추 뒤 ● 표식(`set_mark`)을 걷었다. 자산 층 스무 줄이 다 차자 **모든**
    #   단추에 ● 가 붙어 「층이 있는 자리」를 가르던 뜻을 잃었다(사용자 「너무 이상하다.
    #   왜 필요한가? 모두 제거하라」). 어디에 무엇이 적혔는지는 [예제] 칸의 「이미
    #   등록된 프롬프트」가 말한다.


class PromptTab(ttk.Frame):
    """프롬프트 탭 몸통. `db` = 연결을 여는 함수(`appdb.connect` 꼴)."""

    def __init__(self, parent, db, help_factory=None, lang_getter=None, **kw):
        super().__init__(parent, **kw)
        self._db = db
        self._help_factory = help_factory
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._mode = 'EDIT'
        self._active = None           # ('KIND', kind) | ('TASK', t) | ('LANG', l) | ('ALL', '')
        #: ★ 317차-5 — 자산을 고른 채 업무를 누르면 그 업무가 **자산의 한정어**가 된다
        #:   (자산×업무 층 — 예: 구절묶음 · 신규작성 — 이 수정 화면에서 안 열려 빈칸으로 보였다)
        self._edit_task = ''
        self._view = {'KIND': None, 'TASK': None, 'LANG': None}
        self._loaded = {}             # part -> 마지막으로 읽거나 적은 글
        self._loading = False
        self._save_after = None
        self._scope = ''
        self._scope_vals = [('', '(전체)')]
        self._build()
        self.after(150, self.reload)

    # ── 짓기 ────────────────────────────────────────────────────────
    def _build(self):
        # ★★★ 317차-19 (docs/1.txt 42-3 사용자 「화면을 좌우로 · 좌 = 수정/조회 · 업무/자산/언어/범위 목록 ·
        #   예제/게이트 · 우 = 오른쪽 화면 전체를 프롬프트 표시화면으로」). 그전에는 단추 줄이 위를 가로로
        #   먹고 그 아래를 좌우로 나눠 프롬프트 칸이 위아래로 짧았다.
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=6)
        self._pw = pw
        lc = ttk.Frame(pw)
        pw.add(lc, weight=1)
        self._lc = lc
        bar = ttk.Frame(lc)
        bar.pack(fill='x', pady=(0, 2))
        self._b_edit = tk.Button(bar, text='수정', width=8,
                                 command=lambda: self.set_mode('EDIT'), **_kw(True))
        self._b_edit.pack(side='left')
        self._b_view = tk.Button(bar, text='조회', width=8,
                                 command=lambda: self.set_mode('VIEW'), **_kw(False))
        self._b_view.pack(side='left', padx=(4, 8))
        if self._help_factory_ok():
            self._help_factory(bar).pack(side='right', padx=4)
        self._status = ttk.Label(lc, text='', foreground='#7F8C8D')
        self._status.pack(fill='x', padx=2)
        self._hint = ttk.Label(lc, foreground='#7F8C8D', text='', justify='left', wraplength=440)
        self._hint.pack(fill='x', padx=2, pady=(0, 4))

        rows = ttk.Frame(lc)
        rows.pack(fill='x')
        kinds = [('', COMMON)] + [(a[0], a[1]) for a in AJ.ASSETS_UI]
        _langs = AJ.ui_langs()
        # ★ 차례 = 업무 · 자산 · 언어(**반드시 한 줄**) · 범위(317차-5 사용자 배치) — 좁은 기둥이라 자산은 세 칸씩 흐른다
        self._rows = {
            'TASK': _Row(rows, 'TASK', ROW_NAME['TASK'], [(t[0], t[1]) for t in AJ.TASKS], self._on_pick),
            'KIND': _Row(rows, 'KIND', ROW_NAME['KIND'], kinds, self._on_pick, cols=KIND_COLS),
            'LANG': _Row(rows, 'LANG', ROW_NAME['LANG'], [(lg, lg) for lg in _langs],
                         self._on_pick, cols=max(1, len(_langs))),
        }
        for k in ('TASK', 'KIND', 'LANG'):
            self._rows[k].pack(fill='x')
        # 범위 — 자산 단추를 골랐을 때만 뜻이 있다(옛 범위 프로필이 여기 산다)
        sf = ttk.Frame(rows)
        sf.pack(fill='x', pady=(2, 4))
        ttk.Label(sf, text='범위', width=5, font=('', 9, 'bold')).pack(side='left', padx=(4, 6))
        self._scope_cb = ttk.Combobox(sf, state='readonly', width=30, values=['(전체)'])
        self._scope_cb.current(0)
        self._scope_cb.pack(side='left')
        self._scope_cb.bind('<<ComboboxSelected>>', lambda _e: self._on_scope())
        self._scope_note = ttk.Label(rows, text='', foreground='#7F8C8D')
        self._scope_note.pack(fill='x', padx=(56, 2))

        sb = ttk.Frame(lc)
        sb.pack(fill='x', pady=(4, 2))
        self._b_ex = tk.Button(sb, text='예제', width=8,
                               command=lambda: self.set_side('EX'), **_kw(True))
        self._b_ex.pack(side='left')
        self._b_gate = tk.Button(sb, text='게이트', width=8,
                                 command=lambda: self.set_side('GATE'), **_kw(False))
        self._b_gate.pack(side='left', padx=(4, 0))
        # ── 왼쪽 아래 — 예제 · 게이트(같은 단추를 다시 누르면 접힌다) ───────
        lf = ttk.Frame(lc)
        lf.pack(fill='both', expand=True)
        self._lf = lf
        self._side = 'EX'
        self._side_on = True
        self._side_lbl = ttk.Label(lf, text='', foreground='#7F8C8D')
        self._side_lbl.pack(fill='x', padx=2)
        self._side_txt = tk.Text(lf, wrap='word', width=40, height=8)
        ssb = ttk.Scrollbar(lf, orient='vertical', command=self._side_txt.yview)
        self._side_txt.configure(yscrollcommand=ssb.set)
        ssb.pack(side='right', fill='y')
        self._ssb = ssb
        # ★★★ 2026-10-13 (docs/1.txt 71 「예제 / 게이트를 수정할 수 없다 … 문제가 심각하다」) —
        #   게이트 칸이 읽기 전용 목록뿐이었다. **규칙마다 세기(기본·흠·참고·끔)** 와 **금지 문구**를
        #   여기서 정한다. 판정 방법은 코드(`db_ai_run.GATE_RULES`)이고 세기만 관리자가 정한다.
        self._gate_f = ttk.Frame(lf)
        gb = ttk.Frame(self._gate_f)
        gb.pack(fill='x', pady=(2, 2))
        tk.Button(gb, text='금지 문구 저장', command=self._save_banned, **_kw(False)).pack(side='left')
        self._ban_lbl = ttk.Label(gb, text='금지 문구 — 한 줄에 하나 · 공백 무시', foreground='#7F8C8D')
        self._ban_lbl.pack(side='left', padx=6)
        self._ban_txt = tk.Text(self._gate_f, height=3, wrap='word', width=40)
        self._ban_txt.pack(fill='x', pady=(0, 4))
        self._rules_f = ttk.Frame(self._gate_f)
        self._rules_f.pack(fill='x')
        self._side_txt.pack(fill='both', expand=True)
        self._side_txt.tag_configure('h', font=('', 9, 'bold'))
        self._side_txt.tag_configure('g', foreground='#7F8C8D')
        self._side_txt.tag_configure('must', foreground='#A93226')
        self._side_txt.tag_configure('note', foreground='#1A5276')
        self._side_txt.bind('<Key>', self._ro_key)
        lc.bind('<Configure>', self._fit_hint, add='+')

        # ── 오른쪽 — 프롬프트 칸이 높이 전부를 쓴다(크기를 바꿀 수 있다) ─────────
        rf = ttk.Frame(pw)
        pw.add(rf, weight=3)
        self._rf = rf
        self._head = ttk.Label(rf, text='', font=('', 10, 'bold'))
        self._head.pack(anchor='w', padx=4, pady=(2, 0))
        self._warn = ttk.Label(rf, text='', foreground='#C0392B')
        self._warn.pack(anchor='w', padx=4)
        self._part_hint = ttk.Label(rf, text='', foreground='#7F8C8D')
        self._part_hint.pack(side='bottom', anchor='w', padx=4, pady=(0, 2))
        self._parts_pw = ttk.PanedWindow(rf, orient='vertical')
        self._parts_pw.pack(fill='both', expand=True, padx=4, pady=(0, 4))
        self._box = {}
        for key, name, stack in AJ.PROMPT_PARTS:
            fr = ttk.Frame(self._parts_pw)
            self._parts_pw.add(fr, weight=(3 if stack else 1))
            top = ttk.Frame(fr)
            top.pack(side='left', fill='y')
            ttk.Label(top, text=name, width=9, font=('', 9, 'bold')).pack(anchor='nw')
            t = tk.Text(fr, height=(3 if stack else 1), wrap='word', undo=True)
            t.pack(side='left', fill='both', expand=True)
            t.tag_configure('src', foreground='#7F8C8D')
            t.bind('<<Modified>>', lambda _e, k=key: self._on_modified(k))
            t.bind('<Key>', lambda e, k=key: self._on_key(e, k))
            self._box[key] = t
        # 성격 설명 — 마우스를 올린 칸의 몫을 아래 한 줄로
        for key, t in self._box.items():
            t.bind('<FocusIn>', lambda _e, k=key: self._show_companions(k), add='+')

    def _fit_hint(self, e=None):
        """안내 줄을 왼쪽 기둥 폭으로 감는다(값이 같으면 아무 일도 안 한다 — 고리 방지)."""
        try:
            # ★ 처음 한 번 — 왼쪽 기둥이 단추 줄(언어 한 줄)보다 좁으면 사시를 옮긴다.
            #   사람이 끌어 둔 자리는 빼앗지 않는다(한 번뿐) · 오른쪽이 400px 아래로 줄면 안 한다.
            if not getattr(self, '_sash_fit', False) and self._pw.winfo_width() > 1:
                need = int(self._lc.winfo_reqwidth()) + 6
                if int(self._lc.winfo_width()) >= need:
                    self._sash_fit = True                # 이미 넉넉하다
                elif int(self._pw.winfo_width()) - need >= 400:
                    self._sash_fit = True                # ⚠ 창이 다 펴진 뒤에 한 번만 옮긴다
                    self.after_idle(lambda: self._pw.sashpos(0, need))   # ⚠ <Configure> 안에서 옮기면 칸이 안 따라온다
            w = max(200, int(self._lc.winfo_width()) - 12)
            if int(self._hint.cget('wraplength') or 0) != w:
                self._hint.configure(wraplength=w)
                self._scope_note.configure(wraplength=w - 56)
        except Exception:                                 # noqa: BLE001
            pass

    def _help_factory_ok(self):
        return callable(getattr(self, '_help_factory', None))

    # ── 모드 ────────────────────────────────────────────────────────
    def set_mode(self, mode):
        assert mode in ('EDIT', 'VIEW'), mode
        if self._mode == 'EDIT':
            self._flush()
        self._mode = mode
        self._b_edit.configure(**_kw(mode == 'EDIT'))
        self._b_view.configure(**_kw(mode == 'VIEW'))
        self._warn.config(text='')
        # 공통 단추는 수정에만 있다(조회는 계층마다 하나씩 · 공통은 늘 깔린다)
        try:
            b = self._rows['KIND']._btn['']
            if mode == 'EDIT':
                b.grid()
            else:
                b.grid_remove()
        except Exception:                                 # noqa: BLE001
            pass
        if mode == 'EDIT':
            self._hint.config(text=(
                '수정 — 단추 **하나**를 선택하면 그 단추의 프롬프트가 열립니다(자산을 선택한 채 업무를 누르면 '
                '「자산 · 업무」 프롬프트). '
                '고친 것은 저절로 저장됩니다(저장 단추 없음). 칸을 비우면 그 칸이 지워집니다.'))
            for k in ('KIND', 'TASK', 'LANG'):
                self._rows[k].set_active(None)
            if self._active:
                self._rows[self._active[0] if self._active[0] != 'ALL' else 'KIND'].set_active(
                    self._active[1])
            self._show_edit()
        else:
            self._hint.config(text=(
                '조회 — 계층마다 하나씩 선택하면 실제로 나가는 **결합 프롬프트**를 보입니다. '
                '읽기만 합니다(복사는 됩니다). 줄 끝 회색 글자가 어느 단추에서 온 줄인지 말합니다.'))
            for k in ('KIND', 'TASK', 'LANG'):
                self._rows[k].set_active(self._view.get(k))
            self._show_view()
        self._paint_side()

    def mode(self):
        return self._mode

    def set_side(self, side):
        """[예제]/[게이트] — 다른 갈래면 그것을 보이고, **보이는 갈래를 다시 누르면
        왼쪽 칸을 접는다**(오른쪽 성격 칸이 넓어진다). 접힌 채 누르면 다시 편다."""
        side = 'GATE' if side == 'GATE' else 'EX'
        if self._side_on and side == self._side:
            self._side_on = False
            self._lf.pack_forget()       # ★ 317차-19 — 예제·게이트 칸만 접는다(단추 기둥은 남는다)
        else:
            self._side = side
            if not self._side_on:
                self._side_on = True
                self._lf.pack(fill='both', expand=True)
        self._b_ex.configure(**_kw(self._side_on and self._side == 'EX'))
        self._b_gate.configure(**_kw(self._side_on and self._side == 'GATE'))
        self._paint_side()

    def side_shown(self):
        """왼쪽 칸(예제·게이트)이 보이면 그 갈래 이름, 접혀 있으면 ''."""
        return self._side if self._side_on else ''

    # ── 고르기 ──────────────────────────────────────────────────────
    def _on_pick(self, row, key):
        if row not in self._rows:
            # ★ 모르는 계층 이름은 **거부한다** — 옛 판이 '자산' 을 받아 언어 층에
            #   저장한 자리. 조용히 넘기면 같은 자국이 또 생긴다.
            self._status.config(text='모르는 계층: %r' % (row,))
            return
        if self._mode == 'EDIT':
            self._flush()
            # ★★★ **한 층만 연다** — 언어·공통은 홀로 · 자산은 업무를 한정어로 함께 가질 수 있다
            #   (자산×업무 층). 업무만 누르면 업무 층이다.
            cur_kind = self._active[1] if (self._active and self._active[0] == 'KIND') else None
            if row == 'TASK' and cur_kind:
                self._edit_task = '' if self._edit_task == key else key
            else:
                self._edit_task = self._edit_task if (row == 'KIND' and key) else ''
                if row == 'KIND' and key == '':
                    self._active = ('ALL', '')
                else:
                    self._active = (row, key)
                # ⚠ 자산을 새로 고르면 **범위를 비운다** — 앞 자산의 범위가 남아 빈 층을 읽던 자리
                self._scope = ''
            for k in ('KIND', 'TASK', 'LANG'):
                self._rows[k].set_active(None)
            if self._active[0] == 'ALL':
                self._rows['KIND'].set_active('')
            else:
                self._rows[self._active[0]].set_active(self._active[1])
            if self._active[0] == 'KIND' and self._edit_task:
                self._rows['TASK'].set_active(self._edit_task)
            self._fill_scopes()
            self._show_edit()
        else:
            # 조회 — 계층마다 하나 · 같은 단추를 다시 누르면 푼다
            cur = self._view.get(row)
            self._view[row] = None if cur == key else key
            self._rows[row].set_active(self._view[row])
            if row == 'KIND':
                self._scope = ''
                self._fill_scopes()
            self._show_view()
        self._paint_side()

    def pick(self, row, key):
        """밖에서 부르는 문 — 단추를 누른 것과 같다."""
        self._on_pick(row, key)

    def show_for(self, kind, task, lang):
        """작업 선택하기 탭에서 넘어올 때 — 그 조합을 **조회**로 연다."""
        self._view = {'KIND': kind or None, 'TASK': task or None,
                      'LANG': (lang or '').upper() or None}
        self._scope = ''
        self.set_mode('VIEW')
        self._fill_scopes()
        self._show_view()
        self._paint_side()

    def selected(self):
        """지금 화면이 가리키는 `(kind, scope, task, lang)` — 수정이면 그 층, 조회면 조합."""
        if self._mode == 'EDIT':
            return self._edit_key()
        return ((self._view.get('KIND') or ''), self._scope,
                (self._view.get('TASK') or ''), (self._view.get('LANG') or ''))

    def _edit_key(self):
        if not self._active:
            return None
        row, key = self._active
        if row == 'ALL':
            return ('', '', '', '')
        if row == 'KIND':
            return (key, self._scope or '', getattr(self, '_edit_task', '') or '', '')
        if row == 'TASK':
            return ('', '', key, '')
        return ('', '', '', key)

    def _cur_kind(self):
        if self._mode == 'EDIT':
            return self._active[1] if (self._active and self._active[0] == 'KIND') else ''
        return self._view.get('KIND') or ''

    def _fill_scopes(self):
        kind = self._cur_kind()
        vals = [('', '(전체)')]
        if kind:
            try:
                with self._db() as conn:
                    ax = AJ.axis_values(conn, AJ.ASSET[kind]['axis'], self.lang_getter())
                    have = {r[1] for r in AJ.layer_list(conn) if r[0] == kind and r[1]}
                vals = [(v, n) for v, n in ax]
                self._scope_have = have
            except Exception as e:                        # noqa: BLE001
                print('[prompt_tab scopes] %s' % e)
        self._scope_vals = vals
        self._scope_cb.configure(values=[n for _v, n in vals],
                                 state=('readonly' if kind else 'disabled'))
        idx = 0
        for i, (v, _n) in enumerate(vals):
            if v == (self._scope or ''):
                idx = i
        self._scope_cb.current(idx)
        _hv = len(getattr(self, '_scope_have', ()) or ())
        self._scope_note.config(
            text=(('따로 적힌 범위 %d개' % _hv if _hv else '따로 적힌 범위 없음') if kind else
                  '자산 단추를 선택하면 범위를 선택할 수 있습니다'))

    def _on_scope(self):
        if self._mode == 'EDIT':
            self._flush()
        i = self._scope_cb.current()
        self._scope = self._scope_vals[i][0] if 0 <= i < len(self._scope_vals) else ''
        if self._mode == 'EDIT':
            self._show_edit()
        else:
            self._show_view()
        self._paint_side()

    # ── 수정 ────────────────────────────────────────────────────────
    def _name_of(self, key):
        k, sc, tk_, lg = key
        if not any(key):
            return COMMON
        if k:
            nm = AJ.ASSET[k]['name']
            if sc:
                for v, n in self._scope_vals:
                    if v == sc:
                        nm += ' · ' + n
                        break
            if tk_:
                nm += ' · ' + AJ.TASK_NAME.get(tk_, tk_)
            return nm
        if tk_:
            return AJ.TASK_NAME.get(tk_, tk_)
        return lg

    def _show_edit(self):
        key = self._edit_key()
        self._loading = True
        try:
            for t in self._box.values():
                t.configure(state='normal')
                t.delete('1.0', 'end')
                t.edit_modified(False)
            self._loaded = {}
            if not key:
                self._head.config(text='위 단추 가운데 하나를 선택하세요 — 그 단추의 프롬프트를 적습니다.')
                return
            self._head.config(text='수정 — %s' % self._name_of(key))
            got = {}
            try:
                with self._db() as conn:
                    got = AJ.get_layer(conn, *key)
                    if not any(key) and not got.get('must'):
                        rr = AJ.common_rules(conn)
                        if rr:
                            got['must'] = chr(10).join(rr)
            except Exception as e:                        # noqa: BLE001
                print('[prompt_tab show] %s' % e)
                self._status.config(text='프롬프트를 못 읽었습니다: %s' % e)
            for part, t in self._box.items():
                t.insert('end', got.get(part, ''))
                t.edit_modified(False)
                self._loaded[part] = (got.get(part, '') or '').strip()
        finally:
            self._loading = False
        self._paint_conflicts()

    def _on_modified(self, part):
        t = self._box[part]
        if not t.edit_modified():
            return
        t.edit_modified(False)
        if self._loading or self._mode != 'EDIT':
            return
        if self._save_after:
            try:
                self.after_cancel(self._save_after)
            except Exception:                             # noqa: BLE001
                pass
        self._save_after = self.after(AUTOSAVE_MS, self._flush)

    def _flush(self):
        """고친 칸을 **지금** 적는다 — 단추를 옮기거나 모드를 바꾸기 전에 반드시."""
        if self._save_after:
            try:
                self.after_cancel(self._save_after)
            except Exception:                             # noqa: BLE001
                pass
            self._save_after = None
        if self._mode != 'EDIT':
            return 0
        key = self._edit_key()
        if not key:
            return 0
        n = 0
        try:
            with self._db() as conn:
                for part, t in self._box.items():
                    cur = t.get('1.0', 'end').strip()
                    if cur == self._loaded.get(part, ''):
                        continue
                    AJ.set_layer(conn, *(key + (part, cur)))
                    self._loaded[part] = cur
                    n += 1
                    if not any(key) and part == 'must':
                        AJ.set_common_rules(conn, cur)
        except Exception as e:                            # noqa: BLE001
            self._status.config(text='저장 못 함: %s' % e)
            return 0
        if n:
            self._status.config(text='저장됨 %s · %d칸' % (time.strftime('%H:%M:%S'), n))
            self._mark_rows()
            self._paint_conflicts()
        return n

    def flush(self):
        return self._flush()

    # ── 조회 ────────────────────────────────────────────────────────
    def _show_view(self):
        """★★★ 2026-10-13 (사용자 「작업방식과 업무유형을 선택하면 프롬프트 세트가 전체내용을 표시해야 한다」) —
        **실제로 나가는 것을 그대로** 그린다: `AJ.compose_trace` 한 문(보내는 쪽과 같은 함수).
        옛 판은 여기서 합치는 코드를 따로 가져 실측 132조합 중 59조합이 실제와 달랐다
        (언어를 안 고르면 언어 층이 빠지고 · 연결 점검은 아예 다른 글이 보였다).
        · 업무를 안 고르면 「신규」, 언어를 안 고르면 「KO」로 본다(보내는 글은 늘 업무·언어가 있다) — 머리에 적는다.
        · 이기는 칸에서 더 좁은 층에 **가려진 글**도 회색 줄로 보인다(왜 내 글이 안 나가는지 알 수 있게).
        · **보낼 때 붙는 줄**(묶음 칸 지시 · 연결설명문 함께 쓰기)도 보인다.
        """
        kind, sc, task, lang = self.selected()
        task_eff = task or 'NEW'
        lang_eff = (lang or 'KO').upper()
        self._loading = True
        try:
            for t in self._box.values():
                t.configure(state='normal')
                t.delete('1.0', 'end')
                t.tag_configure('lost', foreground='#A0A0A0', overstrike=True)
                t.tag_configure('rt', foreground='#1A5276')
            picked = [x for x in (kind and AJ.ASSET[kind]['name'],
                                  task and AJ.TASK_NAME.get(task, task), lang) if x]
            assumed = []
            if not task:
                assumed.append('업무 미선택 → 신규로 봄')
            if not lang:
                assumed.append('언어 미선택 → KO 로 봄')
            head = '조회 — %s  (실제로 나가는 프롬프트 전체)' % (' + '.join(picked) if picked else '공통만')
            if assumed:
                head += '   · ' + ' · '.join(assumed)
            self._head.config(text=head)
            trace, lost, extras = {}, {}, []
            try:
                with self._db() as conn:
                    _obj, trace, lost = AJ.compose_trace(conn, kind, sc, task_eff, lang_eff)
                extras = AJ.runtime_extras(kind) if kind else []
            except Exception as e:                        # noqa: BLE001
                print('[prompt_tab view] %s' % e)
                self._status.config(text='결합 프롬프트를 못 읽었습니다: %s' % e)
            for part, t in self._box.items():
                first = True
                for line, key in trace.get(part, []):
                    if not first:
                        t.insert('end', chr(10))
                    first = False
                    t.insert('end', line)
                    t.insert('end', '   ‹%s›' % self._src_name(key), 'src')
                for line, key, when in [(l, AJ.SRC_RUNTIME, w) for p_, l, w in extras if p_ == part]:
                    if not first:
                        t.insert('end', chr(10))
                    first = False
                    t.insert('end', line, 'rt')
                    t.insert('end', '   ‹보낼 때 붙음 · %s›' % when, 'src')
                for line, key in lost.get(part, []):
                    if not first:
                        t.insert('end', chr(10))
                    first = False
                    t.insert('end', line.replace(chr(10), ' / '), 'lost')
                    t.insert('end', '   ‹가려짐 · %s — 더 좁은 층이 이긴다›' % self._src_name(key), 'src')
            for t in self._box.values():
                t.configure(state='disabled')
        finally:
            self._loading = False
        self._paint_conflicts()

    def _src_name(self, key):
        k, sc, tk_, lg = key
        if not any(key):
            return COMMON
        if str(k).startswith('@'):
            return str(k)[1:]
        bits = []
        if k:
            nm = AJ.ASSET[k]['name'] if k in AJ.ASSET else k
            if sc:
                for v, n in self._scope_vals:
                    if v == sc:
                        nm += '·' + n
                        break
                else:
                    nm += '·' + sc
            bits.append(nm)
        if tk_:
            bits.append(AJ.TASK_NAME.get(tk_, tk_))
        if lg:
            bits.append(lg)
        return ' '.join(bits)

    def _on_key(self, e, part):
        """조회에서 글을 고치려 하면 — 팝업 대신 붉은 줄로 말한다. 복사(Ctrl+C)는 둔다."""
        if self._mode != 'VIEW':
            return None
        if (e.state & 0x4) and e.keysym.lower() in ('c', 'a'):
            return None
        if e.keysym in ('Up', 'Down', 'Left', 'Right', 'Home', 'End', 'Prior', 'Next',
                        'Shift_L', 'Shift_R', 'Control_L', 'Control_R'):
            return None
        self._warn.config(text=VIEW_WARN)
        return 'break'

    def _ro_key(self, e):
        if (e.state & 0x4) and e.keysym.lower() in ('c', 'a'):
            return None
        if e.keysym in ('Up', 'Down', 'Left', 'Right', 'Home', 'End', 'Prior', 'Next'):
            return None
        return 'break'

    # ── 왼쪽 아래 — 예제 · 게이트 ───────────────────────────────────
    def _paint_side(self):
        t = self._side_txt
        t.configure(state='normal')
        t.delete('1.0', 'end')
        kind, sc, task, lang = self.selected() or ('', '', '', '')
        if self._side == 'GATE':
            self._side_lbl.config(text='게이트 — 규칙마다 세기를 정합니다(기본·흠·참고·끔). 아래는 게이트 설명')
            try:
                self._gate_f.pack(fill='x', before=self._ssb)
            except Exception:                             # noqa: BLE001
                pass
            self._paint_gate_cfg(kind, task)
            self._paint_gates(t, kind, task)
        else:
            try:
                self._gate_f.pack_forget()
            except Exception:                             # noqa: BLE001
                pass
            # ★ 2026-10-13 — 예제는 **보내는 프롬프트에 실리지 않는다**. 그 사실을 분명히 적는다
            #   (사용자 「예제를 채택하지도 않았는데 예제가 적용되는 것 같다」).
            self._side_lbl.config(text='예제 — 참고용입니다. 보내는 프롬프트에는 실리지 않습니다 '
                                       '(오른쪽 칸에 직접 적은 것만 실립니다)')
            self._paint_examples(t, kind, task, lang)
        t.configure(state='disabled')

    def _paint_gates(self, t, kind, task):
        rows = AR.gate_rows(kind or None, task or 'NEW')
        if kind:
            on = [r for r in rows if r[5]]
            t.insert('end', '%s · %s 에 걸리는 게이트 %d개 / 전체 %d개%s'
                     % (AJ.ASSET[kind]['name'], AJ.TASK_NAME.get(task or 'NEW', task or 'NEW'),
                        len(on), len(rows), chr(10)), 'h')
            if not on:
                t.insert('end', '⚠ 이 자산·업무에는 기계 게이트가 하나도 없습니다 — 사람이 봅니다.'
                         + chr(10), 'must')
        else:
            t.insert('end', '자산 단추를 선택하면 그 자산에 걸리는 게이트를 ✓ 로 표시합니다.' + chr(10), 'g')
        for key, name, lv, what, risk, on in rows:
            mark = ('✓ ' if on else '· ') if kind else '  '
            t.insert('end', chr(10) + mark)
            t.insert('end', '[%s] ' % ('필수' if lv == 'MUST' else '참고'),
                     'must' if lv == 'MUST' else 'note')
            t.insert('end', name, 'h')
            t.insert('end', chr(10) + '   재는 것: ' + what + chr(10))
            t.insert('end', '   놓치면: ' + risk + chr(10), 'g')

    def _paint_examples(self, t, kind, task, lang):
        """★★★ 296차 — **선택한 단추의 본보기만** 보인다(사용자 「상단에서 선택한 개념에
        부합하도록 · 공통버튼 누르지도 않았는데 왜 공통 프롬프트를 표시하는가」).
        수정 = 그 단추 하나(공통 단추면 공통) · 조회 = 고른 계층들 · 아무것도 안 골랐으면
        안내 한 줄뿐."""
        ex = AJ.PROMPT_EXAMPLES
        blocks = []
        _picked = None if self._mode == 'EDIT' else True
        if self._mode == 'EDIT':
            _picked = self._edit_key()
        if _picked is None:
            t.insert('end', '단추를 선택하면 그 자산·업무·언어에 맞는 본보기를 보입니다.'
                     + chr(10), 'g')
            return
        if self._mode == 'EDIT' and not any(_picked):
            blocks.append(('공통', ex.get('ALL', {})))
        if task:
            blocks.append(('업무 · %s' % AJ.TASK_NAME.get(task, task), ex['TASK'].get(task, {})))
        if kind:
            blocks.append(('자산 · %s' % AJ.ASSET[kind]['name'], ex['KIND'].get(kind, {})))
        if lang:
            blocks.append(('언어 · %s' % lang, ex['LANG'].get(lang, {})))
        if not blocks:
            t.insert('end', '단추를 선택하면 그 자산·업무·언어에 맞는 본보기를 보입니다.'
                     + chr(10), 'g')
            return
        for title, parts in blocks:
            t.insert('end', chr(10) + '▶ ' + title + chr(10), 'h')
            if not parts:
                t.insert('end', '   (본보기가 아직 없습니다)' + chr(10), 'g')
                continue
            for key, name, _st in AJ.PROMPT_PARTS:
                body = parts.get(key)
                if not body:
                    continue
                t.insert('end', '  · %s' % name + chr(10), 'note')
                for line in body.splitlines():
                    t.insert('end', '    %s' % line + chr(10))
        # 이미 적힌 층 — 그 자산의 것(범위 층도)
        if kind:
            try:
                with self._db() as conn:
                    lays = [r for r in AJ.layer_list(conn) if r[0] == kind]
                    t.insert('end', chr(10) + '▶ 이미 등록된 프롬프트 · %s (%d층)'
                             % (AJ.ASSET[kind]['name'], len(lays)) + chr(10), 'h')
                    for k, sc2, tk2, lg2, _n in lays:
                        got = AJ.get_layer(conn, k, sc2, tk2, lg2)
                        t.insert('end', '  [%s]' % self._src_name((k, sc2, tk2, lg2)) + chr(10), 'note')
                        for key, name, _st in AJ.PROMPT_PARTS:
                            if got.get(key):
                                t.insert('end', '    %s: %s' % (name, got[key].replace(chr(10), ' / '))
                                         + chr(10))
                    why = AR.reject_reasons(conn, kind, limit=12)
                    if why:
                        t.insert('end', chr(10) + '▶ 사람이 적은 반려 사유 (최근 %d건)' % len(why)
                                 + chr(10), 'h')
                        for _k, tk2, lg2, w, head in why:
                            t.insert('end', '  · [%s·%s] %s' % (AJ.TASK_NAME.get(tk2, tk2), lg2, w)
                                     + chr(10), 'must')
                            t.insert('end', '      「%s…」' % (head or '').replace(chr(10), ' ')
                                     + chr(10), 'g')
            except Exception as e:                        # noqa: BLE001
                t.insert('end', chr(10) + '(등록된 층을 못 읽었습니다: %s)' % e, 'g')

    # ── 2026-10-13 · 게이트 세기 · 금지 문구 · 부딪힘 · 함께 실리는 줄 ─────────────
    def _gate_scope(self):
        """게이트 설정이 걸릴 (자산, 업무) — 업무가 비면 모든 업무."""
        kind, _sc, task, _lg = self.selected() or ('', '', '', '')
        return (kind or ''), (task or '')

    def _paint_gate_cfg(self, kind, task):
        for w in self._rules_f.winfo_children():
            w.destroy()
        key = kind or '*'
        try:
            with self._db() as conn:
                d = {}
                try:
                    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                                     (AR.BANNED_KEY,)).fetchone()
                    d = __import__('json').loads(r[0]) if r and r[0] else {}
                except Exception:                         # noqa: BLE001
                    d = {}
                self._ban_txt.delete('1.0', 'end')
                self._ban_txt.insert('end', chr(10).join(d.get(key) or []))
                self._ban_lbl.config(text='금지 문구 — %s · 한 줄에 하나 · 공백 무시'
                                     % (AJ.ASSET[kind]['name'] if kind in AJ.ASSET else '모든 자산'))
                if not kind:
                    ttk.Label(self._rules_f, foreground='#7F8C8D', wraplength=380, justify='left',
                              text='자산 단추를 선택하면 그 자산(업무까지 선택하면 그 업무)의 규칙 세기를 정합니다.'
                              ).grid(row=0, column=0, columnspan=3, sticky='w')
                    return
                tasks = [task] if task else ['NEW', 'EDIT', 'TRANS']
                gs = set()
                for t_ in tasks:
                    gs |= set(AR.gates_for(kind, t_))
                rules = [r for r in AR.GATE_RULES
                         if r[0] != 'pass' and (r[1] in gs or r[1] in ('', 'banned', 'formula'))]
                cfg_exact = {}
                AR.ensure_cfg(conn)
                for rr, m in conn.execute("SELECT rule, mode FROM sys_ai_gate_cfg WHERE kind=? AND task=?",
                                          (kind, task or '')):
                    cfg_exact[rr] = m
                eff = AR.gate_cfg(conn, kind, task or '')
                cnt = self._rule_counts(conn, kind, task)
        except Exception as e:                            # noqa: BLE001
            ttk.Label(self._rules_f, text='게이트 설정을 못 읽었습니다: %s' % e,
                      foreground='#C0392B').grid(row=0, column=0, sticky='w')
            return
        ttk.Label(self._rules_f, font=('', 9, 'bold'),
                  text='규칙 세기 — %s · %s' % (AJ.ASSET[kind]['name'],
                                               AJ.TASK_NAME.get(task, task) if task else '모든 업무')
                  ).grid(row=0, column=0, columnspan=3, sticky='w')
        ttk.Label(self._rules_f, text='최근 걸림(적재)', foreground='#7F8C8D').grid(row=0, column=3, sticky='e')
        vals = ['기본', '흠(막음)', '참고(알림)', '끔']
        to_mode = {'기본': '', '흠(막음)': 'MUST', '참고(알림)': 'NOTE', '끔': 'OFF'}
        to_val = {v: k for k, v in to_mode.items()}
        for i, (rk, _g, name, _rx) in enumerate(rules, 1):
            ttk.Label(self._rules_f, text=name).grid(row=i, column=0, sticky='w', padx=(2, 4))
            cb = ttk.Combobox(self._rules_f, values=vals, state='readonly', width=9)
            cb.set(to_val.get(cfg_exact.get(rk, ''), '기본'))
            cb.grid(row=i, column=1, sticky='w')
            if rk == 'crash':
                cb.configure(state='disabled')
            inh = '' if rk in cfg_exact or not eff.get(rk) else '(물려받음: %s)' % AR.GATE_MODE_KO.get(eff[rk], '')
            ttk.Label(self._rules_f, text=inh, foreground='#7F8C8D').grid(row=i, column=2, sticky='w')
            n_all, n_load = cnt.get(rk, (0, 0))
            ttk.Label(self._rules_f, text='%d (%d)' % (n_all, n_load) if n_all else '',
                      foreground='#7F8C8D').grid(row=i, column=3, sticky='e')
            cb.bind('<<ComboboxSelected>>',
                    lambda _e, c=cb, r=rk: self._set_rule(kind, task or '', r, to_mode[c.get()]))

    def _rule_counts(self, conn, kind, task):
        import json as _j
        q = ("SELECT i.gate_json, i.state FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id"
             " WHERE j.asset_kind=? AND COALESCE(i.gate_json,'')<>''")
        a = [kind]
        if task:
            q += " AND j.task=?"
            a.append(task)
        out = {}
        for g, st in conn.execute(q + " ORDER BY i.item_id DESC LIMIT 3000", a):
            try:
                lines = _j.loads(g).get('lines') or []
            except Exception:                             # noqa: BLE001
                continue
            for r in {AR.gate_rule_of(l) for l in lines if not AR._is_note(l)}:
                n, m = out.get(r, (0, 0))
                out[r] = (n + 1, m + (1 if st == 'LOADED' else 0))
        return out

    def _set_rule(self, kind, task, rule, mode):
        try:
            with self._db() as conn:
                AR.set_gate_cfg(conn, kind, task, rule, mode)
            self._status.config(text='게이트 세기 저장 %s · %s → %s' % (
                time.strftime('%H:%M:%S'), AR.GATE_RULE_NAME.get(rule, rule), AR.GATE_MODE_KO.get(mode, '기본')))
        except Exception as e:                            # noqa: BLE001
            self._status.config(text='저장 못 함: %s' % e)
        kind_, _sc, task_, _lg = self.selected() or ('', '', '', '')
        self._paint_gate_cfg(kind_, task_)

    def _save_banned(self):
        kind, _task = self._gate_scope()
        lines = [x.strip() for x in self._ban_txt.get('1.0', 'end').split(chr(10)) if x.strip()]
        try:
            with self._db() as conn:
                AR.set_banned_phrases(conn, kind or '*', lines)
            self._status.config(text='금지 문구 저장 %s · %d개' % (time.strftime('%H:%M:%S'), len(lines)))
        except Exception as e:                            # noqa: BLE001
            self._status.config(text='저장 못 함: %s' % e)

    def _paint_conflicts(self):
        """함께 실리는 층끼리 부딪히는 줄 — 붉은 줄로(팝업 아님)."""
        kind, sc, task, lang = self.selected() or ('', '', '', '')
        if not kind:
            return
        if self._mode == 'VIEW' and not task:
            task = 'NEW'
        try:
            with self._db() as conn:
                found = []
                for t_ in ([task] if task else ['NEW', 'EDIT', 'TRANS']):
                    for c in AJ.layer_conflicts(conn, kind, sc, t_, lang or 'KO'):
                        found.append((t_,) + tuple(c))
        except Exception as e:                            # noqa: BLE001
            print('[prompt_tab conflicts] %s' % e)
            return
        if not found:
            if self._warn.cget('text').startswith('⚠ 부딪힘'):
                self._warn.config(text='')
            return
        t_, pk, pp, pl, nk, nl, seg = found[0]
        self._warn.config(text='⚠ 부딪힘 %d건 — [%s · %s] %s  ↔  [%s · 하지 말 것] %s  (%s 업무에 함께 실린다)'
                          % (len(found), self._src_name(pk), AJ.PART_NAME.get(pp, pp), pl[:40],
                             self._src_name(nk), nl[:40], AJ.TASK_NAME.get(t_, t_)))

    def _show_companions(self, part):
        """그 칸에 **함께 실리는 다른 층의 줄**을 아래 한 줄에 — 한 층만 보고 고치다 다른 층을 놓치지 않게."""
        txt = '%s — %s' % (AJ.PART_NAME[part], AJ.PART_HINT.get(part, ''))
        try:
            kind, sc, task, lang = self.selected() or ('', '', '', '')
            own = self._edit_key() if self._mode == 'EDIT' else None
            with self._db() as conn:
                cl = AJ.companion_lines(conn, kind, sc, task or 'NEW', lang or 'KO', part, own or ('', '', '', ''))
            if cl:
                txt += '   ·  함께 실리는 다른 층 %d줄: ' % len(cl) + ' / '.join(
                    '[%s] %s' % (self._src_name(k), l[:30]) for k, l in cl[:3])
        except Exception as e:                            # noqa: BLE001
            print('[prompt_tab companions] %s' % e)
        self._part_hint.config(text=txt)

    # ── 새로 읽기 ───────────────────────────────────────────────────
    def _mark_rows(self):
        """296차 — 단추 표식(●)을 걷었다. 이름만 남긴다(부르는 자리가 있다)."""
        return

    def reload(self):
        """DB 를 다시 읽어 단추 표식·범위·칸을 맞춘다."""
        self._mark_rows()
        self._fill_scopes()
        if self._mode == 'EDIT':
            self._show_edit()
        else:
            self._show_view()
        self._paint_side()


def selftest():
    """화면 없이 재는 것 — 층 열쇠 계산·이름·결합 규칙(위젯은 하네스가 잰다)."""
    ok = [0, 0]

    def ck(c, msg, extra=''):
        ok[0 if c else 1] += 1
        print('  %s %s %s' % ('PASS' if c else 'FAIL', msg, extra if not c else ''))

    # 위젯 없이 검사할 수 있게 껍데기만 만든다
    class _P:
        _active = None
        _edit_task = ''
        _scope = ''
        _mode = 'EDIT'
        _view = {'KIND': None, 'TASK': None, 'LANG': None}
        _scope_vals = [('', '(전체)')]
    p = _P()
    ck(PromptTab._edit_key(p) is None, '아무것도 안 선택하면 층이 없다')
    p._active = ('ALL', '')
    ck(PromptTab._edit_key(p) == ('', '', '', ''), '공통 = 넷이 다 빈 층')
    p._active = ('KIND', 'BOOK_UNIT')
    p._scope = '42'
    ck(PromptTab._edit_key(p) == ('BOOK_UNIT', '42', '', ''), '자산 단추 + 범위')
    p._edit_task = 'NEW'
    ck(PromptTab._edit_key(p) == ('BOOK_UNIT', '42', 'NEW', ''), '★ 자산 + 업무 = 자산×업무 층(317차-5)')
    p._edit_task = ''
    p._active = ('TASK', 'TRANS')
    ck(PromptTab._edit_key(p) == ('', '', 'TRANS', ''), '업무 단추')
    p._active = ('LANG', 'RU')
    ck(PromptTab._edit_key(p) == ('', '', '', 'RU'), '언어 단추')
    p._mode = 'VIEW'
    p._view = {'KIND': 'VERS_DESC_LAY', 'TASK': 'NEW', 'LANG': 'KO'}
    p._scope = ''
    ck(PromptTab.selected(p) == ('VERS_DESC_LAY', '', 'NEW', 'KO'), '조회 조합')
    ck(PromptTab._src_name(p, ('', '', '', '')) == COMMON, '공통 이름')
    ck(PromptTab._src_name(p, ('', '', 'TRANS', 'RU')) == '번역 RU', '출처 이름 = 업무 + 언어',
       PromptTab._src_name(p, ('', '', 'TRANS', 'RU')))
    ck('수정' in VIEW_WARN, '경고 글이 사용자 지시 그대로다')
    # ★★★ 실제 단추가 넘기는 것은 화면 글자가 아니라 계층 열쇠다(295차 실측)
    try:
        _r = tk.Tk()
        _r.withdraw()
        got = []
        row = _Row(_r, 'KIND', ROW_NAME['KIND'], [('BOOK_UNIT', '도서')],
                   lambda rk, k: got.append((rk, k)))
        row._btn['BOOK_UNIT'].invoke()
        ck(got == [('KIND', 'BOOK_UNIT')],
           '단추가 계층 열쇠(KIND)를 넘긴다 — 화면 글자가 아니다', str(got))
        _r.destroy()
    except tk.TclError as e:
        print('  SKIP 화면이 없어 단추 클릭을 못 잰다: %s' % e)
    ck(set(AJ.PART_HINT) == set(AJ.PART_STACK), '성격 설명이 성격마다 있다')
    # ★★★ 296차 — 예제 칸은 고른 단추의 것만 · 단추 표식 없음 · 접기
    import re as _re
    _src = open(__file__, encoding='utf-8').read()
    _body = _src[_src.find('def _paint_examples'):_src.find('def _mark_rows')]
    ck("blocks.append(('공통'" in _body and "not any(_picked)" in _body,
       '예제의 공통 블록은 공통 단추를 골랐을 때만 붙는다')
    ck(not _re.search(r"configure\(text=\(base \+ ' ●'", _src), '단추 ● 표식 코드가 없다')
    try:
        _r = tk.Tk(); _r.withdraw()
        pt = PromptTab(_r, db=lambda: None)
        _r.update_idletasks()
        ck(pt._b_ex.master is not pt._b_edit.master and pt._b_ex.master is pt._b_gate.master,
           '★ 317차-5 — [예제][게이트]는 6열(예제·프롬프트 화면 바로 위)')
        ck(len(pt._rows['LANG']._btn) and all(int(b.grid_info()['row']) == 0
                                                for b in pt._rows['LANG']._btn.values()),
           '★ 언어 단추가 한 줄')
        ck(pt.side_shown() == 'EX', '처음은 예제가 보인다')
        pt.set_side('EX')
        ck(pt.side_shown() == '' and not pt._lf.winfo_manager(),
           '보이는 갈래를 다시 누르면 예제·게이트 칸이 접힌다')
        pt.set_side('GATE')
        ck(pt.side_shown() == 'GATE' and pt._lf.winfo_manager() == 'pack',
           '접힌 채 게이트를 누르면 다시 펴진다')
        _panes = [str(x) for x in pt._pw.panes()]
        ck(_panes == [str(pt._lc), str(pt._rf)] and pt._rows['KIND'].master.master is pt._lc
           and pt._parts_pw.master is pt._rf,
           '★ 317차-19 — 좌 = 단추 기둥(업무·자산·언어·범위·예제/게이트) · 우 = 프롬프트 칸')
        ck(not any('●' in str(b.cget('text')) for row in pt._rows.values() for b in row._btn.values()),
           '단추 글자에 ● 가 없다')
        _r.destroy()
    except tk.TclError as e:
        print('  SKIP 화면이 없어 접기를 못 잰다: %s' % e)
    print('%d/%d PASS' % (ok[0], ok[0] + ok[1]))
    return 0 if not ok[1] else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(selftest())
    print('python admin/ai_prompt_tab.py --selftest')
