"""
admin/panel_announcement_admin.py
---------------------------------
공지사항 관리 — '사용자 소통관리 ▸ 공지사항' 독립 화면.

성격이 전송관리(주소록·항목색인 배포)와 달라 분리(사용자 결정 2026-06-15).
작성·발행 로직은 RssTransferPanel 의 `_build_announce`/`_ann_*` 를 상속·재사용한다
(코드 중복 없이, 전송관리에서는 탭만 제거).

★★★ **다국어 = 「시작화면 사진」 문법** (2026-09-06 사용자 0.txt 7) —
  언어 콤보를 걷고 **11언어를 한 표**로 본다. 부품은
  `admin/multilang_edit.MultiLangEdit`(FAQ 와 공용).

    python admin/panel_announcement_admin.py --selftest
"""

import io
import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from admin.panel_rss_transfer import RssTransferPanel
    from admin.lazy_tabs import LazyNotebook
except ImportError:
    from panel_rss_transfer import RssTransferPanel
    from lazy_tabs import LazyNotebook


class AnnouncementAdminPanel(RssTransferPanel):
    """공지 작성·발행만 단독 표시(전송관리의 다른 탭 없이)."""

    def __init__(self, master, **kw):
        # RssTransferPanel.__init__(5탭 빌드)을 건너뛰고 공지 본문만 구성.
        ttk.Frame.__init__(self, master)
        self._srv_rows = []
        f = self._build_announce(self)     # 상속받은 빌더(공지 UI + _ann_* 메서드)
        f.pack(fill='both', expand=True)


def selftest():
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    root = tk.Tk(); root.withdraw()
    p = AnnouncementAdminPanel(root)
    p.pack()
    root.update()
    t('다국어 부품을 쓴다', hasattr(p, '_ann_ml'))
    # ★ 편집 언어 콤보가 **위젯으로** 없는지 (글자로 세면 안내문에 걸린다)
    langs = {c for c, _n in p._ann_ml._langs}

    def _combos(w, out):
        for c in w.winfo_children():
            if isinstance(c, ttk.Combobox):
                out.append(c)
            _combos(c, out)
        return out
    bad = []
    for c in _combos(p, []):
        vals = set(str(v).upper() for v in (c.cget('values') or ()))
        if langs <= vals and 'ALL' not in vals:      # 대상 콤보는 ALL 을 갖는다
            bad.append(c)
    t('★ 편집 언어 콤보가 없다', not bad, bad)
    rows = p._ann_tv.get_children()
    t('공지 목록이 그려진다', len(rows) > 0, len(rows))
    if rows:
        p._ann_tv.selection_set(rows[0])
        root.update()
        n = len(p._ann_ml._tv.get_children())
        t('★ 선택하면 모든 언어가 한 표로', n == len(p._ann_ml._langs), n)
        t('빈 언어는 붉다', any('empty' in p._ann_ml._tv.item(i, 'tags')
                              for i in p._ann_ml._tv.get_children()))
        t('공지 단위 설정이 따라온다',
          bool(p._ann_state_lbl.cget('text')), p._ann_state_lbl.cget('text'))
        # 목록 이름은 대표 언어(KO→아무 언어) — 언어를 골라도 안 바뀐다
        first = p._ann_tv.item(rows[0], 'values')[1]
        p._ann_ml._tv.selection_set(p._ann_ml._langs[-1][0])
        root.update()
        t('★ 언어를 선택해도 목록이 안 바뀐다',
          p._ann_tv.item(rows[0], 'values')[1] == first)
    t('[저장]은 조용히 끝나지 않는다(공지 설정으로 이어진다)',
      p._ann_save.__doc__ is not None
      and '_ann_save_meta' in p._ann_save.__code__.co_names)
    root.destroy()
    print('panel_announcement_admin selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    r = tk.Tk(); r.title('공지사항 관리'); r.geometry('1200x800')
    AnnouncementAdminPanel(r).pack(fill='both', expand=True)
    r.mainloop()
