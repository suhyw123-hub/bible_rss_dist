# -*- coding: utf-8 -*-
"""admin/multilang_edit.py — **다국어 한눈에 편집** (관리자 공통 부품, 2026-09-06 신설).

★★★ **사용자 지시 (0.txt 7 소통)** — 「FAQ/공지사항 **다국어 관리모드를
  「시작화면 사진」 메뉴처럼 개편**할 것. **목록 하나 클릭하고 오른쪽에서
  모든 다국어 관리**하는 방식」.
  · 0.txt 「관리자화면 수정방향」 1-2)-(2) 와 같은 결이다 — 「번역된 언어와
    번역되지 않은 언어를 **한눈에** … **그러면 언어콤보도 필요 없어진다**」.

⚠⚠ **왜 콤보가 나쁜가** — 한 언어씩 갈아 끼우면 **무엇이 비었는지 안 보인다.**
  FAQ·공지 실측은 더 나빴다: 목록의 「질문」 칸이 편집 언어를 따라가서, JA 를
  고르면 **목록 전체가 (미작성)** 이 되어 무슨 항목인지조차 못 읽었다.

**얼개** — 시작화면 사진(`panel_splash_manager`)과 같은 문법:
    ┌ 언어 표 (11줄 · 빈 언어는 붉게) ┐
    │ Korean   제목…      본문…      │  ← 한 줄 = 한 언어
    │ English  (없음)     (없음)     │
    └────────────────────────────────┘
    고른 언어의 칸들 + [저장] [이 언어 지우기]

⚠ **사진과 다른 점 하나** — 사진은 제목이 한 줄이라 `simpledialog` 로 받지만
  FAQ 답변·공지 본문은 **여러 줄**이라 그 자리에서 Text 로 고친다. 팝업으로
  받으면 긴 글을 못 쓴다.

⚠ **저장은 그 언어만** 건드린다 — 다른 언어 행을 덮지 않는다.
⚠ **빈 값으로 저장하면 그 언어 행을 지운다**(빈 껍데기를 남기면 「있다」로
  세어져 번역 현황이 거짓말을 한다 — §197차 사진 제목과 같은 규칙).

붙이는 화면이 주는 것 셋:
  · `fields`  = [(열쇠, 라벨, 편집 높이)]  — 첫 칸이 목록 미리보기의 기준
  · `load(conn, item_id, lang)` → {열쇠: 글}
  · `save(conn, item_id, lang, values)` → None   (빈 값이면 지우기)

    python admin/multilang_edit.py --selftest   (의무)
"""
import io
import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import appdb                                            # noqa: E402

try:
    from admin.lang_badge import ui_langs_en
except ImportError:                                     # 단독 실행
    from lang_badge import ui_langs_en

_EMPTY_FG = '#B03A2E'
_NONE = '(없음)'


class MultiLangEdit(ttk.Frame):
    """목록에서 선택한 항목 하나의 **모든 언어**를 한 화면에서 다룬다."""

    def __init__(self, parent, db_path, fields, load, save,
                 rows_height=8, on_saved=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self._fields = list(fields)
        self._load = load
        self._save = save
        self._on_saved = on_saved
        self._item = None
        self._lang = None
        try:
            self._langs = ui_langs_en(db_path) or [('KO', 'Korean'),
                                                   ('EN', 'English')]
        except Exception:
            self._langs = [('KO', 'Korean'), ('EN', 'English')]
        # ⚠⚠ **self._name 을 쓰면 안 된다** — Tk 위젯이 제 이름(문자열)을 담는
        #   칸이다. dict 로 덮어쓰면 destroy() 가 「cannot use 'dict' as a
        #   dict key」로 죽는다(실측으로 잡았다).
        self._lang_name = dict(self._langs)
        self._build(rows_height)

    # ── UI ────────────────────────────────────────────────────────
    def _build(self, rows_height):
        head = ttk.Frame(self)
        head.pack(fill='x', pady=(2, 2))
        self._title = ttk.Label(head, text='', font=('', 10, 'bold'))
        self._title.pack(side='left')
        self._badge = ttk.Label(head, text='', foreground='#5D6D7E')
        self._badge.pack(side='left', padx=10)

        # ⚠ **표는 감싼 프레임 안에서 만든다** — `w.master` 를 나중에 갈아
        #   끼우면 Tk 내부 자식 표가 깨져 `destroy` 에서 죽는다(실측).
        wrap = ttk.Frame(self)
        wrap.pack(fill='x')
        cols = ['lang'] + [f[0] for f in self._fields]
        tv = ttk.Treeview(wrap, columns=cols, show='headings',
                          height=rows_height, selectmode='browse')
        tv.heading('lang', text='언어')
        tv.column('lang', width=110, anchor='w', stretch=False)
        for key, label, _h in self._fields:
            tv.heading(key, text=label)
            tv.column(key, width=240, anchor='w')
        sb = ttk.Scrollbar(wrap, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        tv.pack(side='left', fill='both', expand=True)
        tv.tag_configure('empty', foreground=_EMPTY_FG)
        tv.bind('<<TreeviewSelect>>', lambda _e: self._on_lang())
        self._tv = tv

        bar = ttk.Frame(self)
        bar.pack(fill='x', pady=(6, 2))
        self._lang_lbl = ttk.Label(bar, text='', font=('', 10, 'bold'))
        self._lang_lbl.pack(side='left')
        self._btn_save = ttk.Button(bar, text=' 저장 ', command=self._do_save,
                                    state='disabled')
        self._btn_save.pack(side='right')
        self._btn_del = ttk.Button(bar, text=' 이 언어 지우기 ',
                                   command=self._do_clear, state='disabled')
        self._btn_del.pack(side='right', padx=6)
        self._msg = ttk.Label(bar, text='', foreground='#1A5276')
        self._msg.pack(side='left', padx=10)

        self._box = {}
        for key, label, h in self._fields:
            ttk.Label(self, text=label + ':').pack(anchor='w', pady=(4, 0))
            t = tk.Text(self, height=h, wrap='word')
            t.pack(fill='both', expand=(h > 3))
            self._box[key] = t

    # ── 항목 ──────────────────────────────────────────────────────
    def set_item(self, item_id, title=''):
        """목록에서 선택한 항목으로 갈아 끼운다."""
        self._item = item_id
        self._title.config(text=title or '')
        self._lang = None
        self._lang_lbl.config(text='')
        self._msg.config(text='')
        self._clear_boxes()
        self.reload()

    def clear(self):
        self._item = None
        self._lang = None
        self._title.config(text='')
        self._badge.config(text='')
        self._lang_lbl.config(text='')
        self._tv.delete(*self._tv.get_children())
        self._clear_boxes()
        self._sync_btns()

    def reload(self):
        """언어 표를 다시 채운다 — **빈 언어도 줄을 만든다**."""
        tv = self._tv
        keep = self._lang
        tv.delete(*tv.get_children())
        if self._item is None:
            self._badge.config(text='')
            self._sync_btns()
            return
        have = 0
        with appdb.connect(self.db_path) as conn:
            for code, name in self._langs:
                try:
                    d = self._load(conn, self._item, code) or {}
                except Exception:
                    d = {}
                vals = [(d.get(k) or '').strip() for k, _l, _h in self._fields]
                filled = bool(vals and vals[0])
                if filled:
                    have += 1
                show = [(v.replace('\n', ' ')[:60] or _NONE) for v in vals]
                tv.insert('', 'end', iid=code, tags=() if filled else ('empty',),
                          values=[name] + show)
        self._badge.config(text='번역됨 %d / %d' % (have, len(self._langs)))
        if keep and keep in [c for c, _n in self._langs]:
            tv.selection_set(keep)
        self._sync_btns()

    # ── 언어 ──────────────────────────────────────────────────────
    def _on_lang(self):
        sel = self._tv.selection()
        if not sel or self._item is None:
            return
        self._lang = sel[0]
        self._lang_lbl.config(text='%s (%s)'
                              % (self._lang_name.get(self._lang, self._lang),
                                 self._lang))
        self._msg.config(text='')
        with appdb.connect(self.db_path) as conn:
            try:
                d = self._load(conn, self._item, self._lang) or {}
            except Exception as e:
                d = {}
                self._msg.config(text='읽기 실패: %s' % e)
        for key, _l, _h in self._fields:
            t = self._box[key]
            t.delete('1.0', 'end')
            t.insert('1.0', d.get(key) or '')
        self._sync_btns()

    def _clear_boxes(self):
        for t in self._box.values():
            t.delete('1.0', 'end')

    def _sync_btns(self):
        on = 'normal' if (self._item is not None and self._lang) else 'disabled'
        self._btn_save.config(state=on)
        self._btn_del.config(state=on)

    def _values(self):
        return {k: self._box[k].get('1.0', 'end').strip()
                for k, _l, _h in self._fields}

    def _do_save(self):
        if self._item is None or not self._lang:
            return
        vals = self._values()
        try:
            with appdb.connect(self.db_path) as conn:
                self._save(conn, self._item, self._lang, vals)
                conn.commit()
        except Exception as e:
            self._msg.config(text='저장 실패: %s' % e)
            return
        self._msg.config(text='%s 저장했습니다.'
                              % self._lang_name.get(self._lang, self._lang))
        self.reload()
        if callable(self._on_saved):
            try:
                self._on_saved()
            except Exception:
                pass

    def _do_clear(self):
        """빈 값으로 저장 = 그 언어 행 지우기(빈 껍데기를 안 남긴다)."""
        if self._item is None or not self._lang:
            return
        self._clear_boxes()
        self._do_save()


# ── 자가 검증 ──────────────────────────────────────────────────────
def selftest():
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    store = {}          # (item, lang) → dict

    def load(_conn, item, lang):
        return dict(store.get((item, lang), {}))

    def save(_conn, item, lang, vals):
        if not (vals.get('q') or '').strip():
            store.pop((item, lang), None)
        else:
            store[(item, lang)] = dict(vals)

    root = tk.Tk()
    root.withdraw()
    db = os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), 'bible_master.db')
    w = MultiLangEdit(root, db, [('q', '질문', 3), ('a', '답변', 6)],
                      load, save)
    w.pack()
    root.update()
    n_lang = len(w._langs)
    t('언어 목록을 DB 에서 읽는다', n_lang >= 2, n_lang)
    t('영어 이름으로 보인다(코드 아님)',
      any(nm.lower() in ('korean', 'english') for _c, nm in w._langs))

    store[(1, 'KO')] = {'q': '설치는 어떻게 하나요?', 'a': '내려받아 실행합니다.'}
    w.set_item(1, '설치·실행')
    root.update()
    rows = w._tv.get_children()
    t('★ 빈 언어도 줄을 만든다', len(rows) == n_lang, len(rows))
    t('★ 빈 언어는 붉게', 'empty' in w._tv.item('EN', 'tags'))
    t('있는 언어는 안 붉다', 'empty' not in w._tv.item('KO', 'tags'))
    t('번역됨 배지', '1 /' in w._badge.cget('text'), w._badge.cget('text'))

    t('안 골랐으면 [저장] 잠김', str(w._btn_save['state']) == 'disabled')
    w._tv.selection_set('KO')
    root.update()
    t('선택하면 [저장] 열림', str(w._btn_save['state']) == 'normal')
    t('그 언어 글이 칸에 온다',
      w._box['q'].get('1.0', 'end').strip() == '설치는 어떻게 하나요?')

    w._tv.selection_set('EN')
    root.update()
    t('★ 다른 언어를 선택하면 칸이 비워진다',
      w._box['q'].get('1.0', 'end').strip() == '')
    w._box['q'].insert('1.0', 'How do I install?')
    w._box['a'].insert('1.0', 'Download and run.')
    w._do_save()
    root.update()
    t('★ 저장 — 그 언어만 들어간다',
      store.get((1, 'EN'), {}).get('q') == 'How do I install?'
      and store[(1, 'KO')]['q'] == '설치는 어떻게 하나요?')
    t('★ 표가 곧바로 따라온다',
      'empty' not in w._tv.item('EN', 'tags')
      and '2 /' in w._badge.cget('text'))

    w._do_clear()
    root.update()
    t('★ 빈 값 저장 = 그 언어 행을 지운다', (1, 'EN') not in store)
    t('★ 지우면 다시 붉어진다', 'empty' in w._tv.item('EN', 'tags'))

    w.set_item(2, '다른 항목')
    root.update()
    t('항목을 바꾸면 표가 갈린다',
      all('empty' in w._tv.item(c, 'tags') for c, _n in w._langs))
    w.clear()
    root.update()
    t('비우면 표가 빈다', not w._tv.get_children())
    root.destroy()
    print('multilang_edit selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('부품입니다 — 화면에 심어서 씁니다. --selftest 로 검사하세요.')
