# -*- coding: utf-8 -*-
"""⑦ 추천 받은 채널 — 사용자가 「관리자에게 채널 추천」으로 보낸 채널 (2026-10-24 docs/4.txt).

통로 = 소통 통로(user_feedback kind CHANNEL · 폰은 PC 동기화 때 PC 가 대신 보낸다) → qa_admin 이 받아 둔다(q_type CHANNEL).
글 꼴은 `mobile_sync.ch_reco_text` 하나 · 읽는 문은 `mobile_sync.parse_ch_reco`.
[채널 등록] = 채널 목록의 단일 문 `panel_media_channel.register_channel`(기본값 그대로) → 그 줄은 「처리함」(CHANNEL_DONE).
채널 번호가 없으면 담은 영상으로 유튜브에 한 번 묻는다(`my_channel.channel_of_video`).
⚠ 일꾼 스레드는 결과만 담는다 — Tk 는 메인에서만(after 폴링).
"""
import threading
import tkinter as tk
import webbrowser
from tkinter import ttk

import appdb

NEW, DONE = 'CHANNEL', 'CHANNEL_DONE'
COLS = (('받은 때', 120), ('채널', 200), ('주소', 240), ('채널 번호', 190), ('사용자 언어', 70), ('상태', 80))


def _registered(conn, cid):
    return bool(cid) and bool(conn.execute(
        "SELECT 1 FROM sys_media_channel WHERE channel_ext_id=? AND record_status='LIVE'", (cid,)).fetchone())


class ChannelRecoTab(ttk.Frame):
    def __init__(self, master, on_done=None):
        super().__init__(master)
        self.on_done = on_done
        self._rows = {}
        self._build()

    def _build(self):
        b = ttk.Frame(self)
        b.pack(fill='x', pady=(4, 2), padx=4)
        ttk.Button(b, text='받아 오기', command=self._fetch).pack(side='left')
        ttk.Button(b, text='채널 등록', command=self._register).pack(side='left', padx=(12, 0))
        ttk.Button(b, text='채널 열기', command=lambda: self._open('url')).pack(side='left', padx=6)
        ttk.Button(b, text='담은 영상 보기', command=lambda: self._open('vid')).pack(side='left')
        ttk.Button(b, text='처리함 표시', command=lambda: self._mark(True)).pack(side='left', padx=(12, 0))
        ttk.Button(b, text='처리 안 함으로', command=lambda: self._mark(False)).pack(side='left', padx=6)
        try:
            from admin.panel_help_box import build_help_button
        except ImportError:
            from panel_help_box import build_help_button
        build_help_button(b, '추천 받은 채널 — 사용방법', [
            ('이 화면', '사용자가 폰·PC 에서 「관리자에게 채널 추천」을 누르면 여기에 옵니다. 채널 이름·주소와 '
                       '(있으면) 담은 영상 하나만 옵니다 — 누가 보냈는지는 오지 않습니다.'),
            ('받아 오기', '새 추천을 가져옵니다(문의·추천을 함께 받는 통로).'),
            ('채널 등록', '고른 줄의 채널을 ⑤ 등록채널 목록에 넣고 「처리함」으로 옮깁니다. 채널 번호가 없으면 담은 영상으로 '
                        '유튜브에 한 번 물어 찾습니다. 언어·수집 주기는 ⑤ 에서 고칩니다. 등록하면 다음 수집부터 '
                        '모든 사용자의 「최신 유튜브」에 나갑니다.'),
            ('채널 열기 · 담은 영상 보기', '등록하기 전에 브라우저로 확인합니다. 줄을 두 번 눌러도 채널이 열립니다.'),
            ('처리함 표시', '등록하지 않기로 한 추천을 목록에서 뺍니다. 「처리한 것도 보기」로 다시 볼 수 있습니다.'),
            ('상태', '새로 · 이미 등록됨(채널 목록에 벌써 있다) · 처리함.'),
        ]).pack(side='right')
        self._all = tk.BooleanVar(value=False)
        ttk.Checkbutton(b, text='처리한 것도 보기', variable=self._all, command=self.fill).pack(side='right', padx=8)
        self._msg = ttk.Label(self, text='사용자가 「관리자에게 채널 추천」으로 보낸 채널입니다. [받아 오기]로 새 추천을 가져옵니다.')
        self._msg.pack(fill='x', padx=6, pady=(0, 4))
        tv = ttk.Treeview(self, columns=[c for c, _w in COLS], show='headings', selectmode='browse')
        for c, w in COLS:
            tv.heading(c, text=c)
            tv.column(c, width=w, stretch=(c == '주소'))
        tv.pack(fill='both', expand=True, padx=4, pady=(0, 4))
        tv.bind('<Double-1>', lambda _e: self._open('url'))
        self.tv = tv
        self.fill()

    def _say(self, t):
        self._msg.config(text=t)

    def fill(self):
        import mobile_sync as MS
        try:
            import qa_admin as QA
            rows = QA.list_qa(q_type=NEW) + (QA.list_qa(q_type=DONE) if self._all.get() else [])
        except Exception as e:                                  # noqa: BLE001
            rows = []
            self._say('추천 목록을 못 읽었습니다: %s' % e)
        self.tv.delete(*self.tv.get_children())
        self._rows = {}
        with appdb.connect() as c:
            for r in rows:
                d = MS.parse_ch_reco(r.get('question') or '')
                d['lang'] = r.get('lang') or ''
                self._rows[r['msg_id']] = d
                st = ('처리함' if r.get('q_type') == DONE
                      else '이미 등록됨' if _registered(c, d['id']) else '새로')
                self.tv.insert('', 'end', iid=r['msg_id'], values=(
                    (r.get('ts') or '')[:16], d['name'], d['url'], d['id'], d['lang'], st))
        if not rows:
            self._say('받은 채널 추천이 없습니다. [받아 오기]로 새 추천을 가져옵니다.')

    def _poll(self, box, done):
        if not box:
            self.after(200, lambda: self._poll(box, done))
            return
        done(box[0])

    def _fetch(self):
        self._say('받아 오는 중…')
        box = []

        def work():
            try:
                import qa_admin as QA
                rows, err = QA.fetch_all()
                box.append((QA.absorb(rows) if not err else 0, err))
            except Exception as e:                              # noqa: BLE001
                box.append((0, str(e)[:80]))

        def done(r):
            n, err = r
            self.fill()
            self._say(('받아 오지 못했습니다: %s' % err) if err else '새로 받은 문의·추천 %d건' % n)
        threading.Thread(target=work, daemon=True).start()
        self._poll(box, done)

    def _cur(self):
        sel = self.tv.selection()
        if not sel:
            self._say('줄을 하나 선택하세요.')
            return None, None
        return sel[0], self._rows.get(sel[0]) or {}

    def _open(self, what):
        mid, d = self._cur()
        if not mid:
            return
        if what == 'vid':
            if not d.get('vid'):
                self._say('담은 영상이 적혀 있지 않습니다.')
                return
            webbrowser.open('https://www.youtube.com/watch?v=' + d['vid'])
            return
        url = d.get('url') or (('https://www.youtube.com/channel/' + d['id']) if d.get('id') else '')
        if url:
            webbrowser.open(url)
        else:
            self._say('채널 주소가 없습니다.')

    def _mark(self, done):
        mid, _d = self._cur()
        if not mid:
            return
        import qa_admin as QA
        QA.set_type(mid, DONE if done else NEW)
        self.fill()

    def _register(self):
        mid, d = self._cur()
        if not mid:
            return
        if d.get('id'):
            self._do_register(mid, d)
            return
        if not d.get('vid'):
            self._say('채널 번호도 담은 영상도 없어 등록할 수 없습니다 — [채널 열기]로 확인한 뒤 ⑤ 등록채널 목록에서 손으로 넣으세요.')
            return
        self._say('채널 번호를 찾는 중…')
        box = []

        def work():
            try:
                import my_channel as MC
                box.append(MC.channel_of_video(d['vid']))
            except Exception:                                   # noqa: BLE001
                box.append(None)

        def done(r):
            if not r:
                self._say('채널 번호를 알아내지 못했습니다 — [채널 열기]로 확인하세요.')
                return
            d['id'], d['name'], d['url'] = r[0], d.get('name') or r[1], d.get('url') or r[2]
            self._do_register(mid, d)
        threading.Thread(target=work, daemon=True).start()
        self._poll(box, done)

    def _do_register(self, mid, d):
        try:
            from admin.panel_media_channel import register_channel
        except ImportError:
            from panel_media_channel import register_channel
        with appdb.connect() as c:
            r = register_channel(c, d['id'], d.get('name') or d['id'], d.get('url') or None, d.get('lang') or None)
            c.commit()
        import qa_admin as QA
        QA.set_type(mid, DONE)
        self.fill()
        self._say(('「%s」을(를) 등록했습니다 — 언어·수집 주기는 ⑤ 등록채널 목록에서 고치세요.' if r == 'NEW'
                   else '「%s」은(는) 이미 등록된 채널입니다 — 처리함으로 표시했습니다.') % (d.get('name') or d['id']))
        if self.on_done:
            try:
                self.on_done()
            except Exception:                                   # noqa: BLE001
                pass


def selftest():
    import mobile_sync as MS
    ok = []

    def ck(n, c):
        ok.append(bool(c)); print(('OK   ' if c else 'FAIL ') + n)

    cid = 'UC' + 'c' * 22
    d = MS.parse_ch_reco(MS.ch_reco_text('란스', 'https://www.youtube.com/@x', cid, 'dQw4w9WgXcQ'))
    ck('추천 글 왕복', d == {'name': '란스', 'url': 'https://www.youtube.com/@x', 'id': cid, 'vid': 'dQw4w9WgXcQ'})
    ck('틀린 채널 번호는 비운다', MS.parse_ch_reco('채널: x\n채널 번호: bad')['id'] == '')
    root = tk.Tk(); root.withdraw()
    t = ChannelRecoTab(root)
    ck('탭이 지어진다 · 단추가 위', t.tv.winfo_exists())
    root.destroy()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    sys.path.insert(0, '.')
    sys.exit(0 if selftest() else 1)
