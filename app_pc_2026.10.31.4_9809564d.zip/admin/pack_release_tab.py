# -*- coding: utf-8 -*-
"""admin/pack_release_tab.py — **릴리스 패킹 머신** 화면
(2026-09-05 신설 · `--selftest` 의무).

★★★ 왜 (사용자 확정 설계):
  「릴리스 패킹 머신은 각 **스몰팩 단위를 지정해서 하나의 릴리스 단위**를
   구성한다. 스몰팩 단위의 업데이트 주기가 해마다 변동할 수 있다.
   **코드를 수정하지 않는다는 것이 핵심**이다.」

★★ **화면이 반드시 보여야 하는 셋**(사용자 지시 2026-09-05):
  ① 각 자산마다 **얼마나 자주 업데이트 되는지 숫자**
  ② 어떤 자산들과의 **연결이 포함되어 있는지**
  ③ **용량이 얼마나 되는지**
  ⇒ 가운데 목록의 세 칸 + 오른쪽 상세가 그것이다. 데이터는 전부
    `db_pack_stat` 한 문에서 온다(화면이 다시 세지 않는다).

★ **좌·중·우** — 배포 센터의 다른 탭과 같은 축:
    좌 = 주기 묶음(릴리스가 어떤 모양이 되나)
    중 = 스몰팩 목록(빈도·용량·연결)
    우 = 고른 것 상세 + **주기 바꾸기**

⚠⚠ **통계로 자동 배정하지 않는다**(사용자 지적 — 감사 로그 기간이 편향될 수
  있다). 권고는 보이되 **누르는 것은 사람**이다.
⚠ 무거운 계산은 **누를 때만**(§29) — 탭을 열면 캐시로 0.1초, [크기 다시 재기]
  를 눌러야 3.6초짜리 전수 측정을 한다.
"""
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import appdb                                                    # noqa: E402
import ui_theme                                                 # noqa: E402
import theme_font                                               # noqa: E402
import db_pack_stat as ST                                       # noqa: E402
from admin.panel_help_box import help_row                 # noqa: E402

HELP_SECTIONS = [
    ('이 탭의 기능 — 릴리스 패킹',
     '어떤 스몰팩을 함께 묶어 내보낼지를 정합니다. 코드를 고치지 않습니다 — '
     'sys_pack_plan 한 표가 그 답을 담고 이 화면이 그것을 고칩니다.\n'
     '· 스몰팩 = 코어 표 하나 또는 본문 자산 하나(이미 조각이라 새로 안 '
     '쪼갭니다)\n'
     '· 주기 셋 = 매일 · 주간 · 연 2회\n'
     '· 주기가 다른 것은 파일도 다릅니다. 겹치는 날에는 나란히 나가고 '
     '사용자 앱이 안 받은 것만 선택해 받습니다.'),
    ('목록의 세 칸',
     '· 변경 — 최근 30일 그 표가 몇 번 바뀌었나(sys_audit_log)\n'
     '· 용량 — 원본 크기 어림(배포물은 gzip 이라 더 작습니다)\n'
     '· 연결 — 그 스몰팩이 낀 연결의 행 수. 오른쪽에서 상대를 봅니다'),
    ('주요 버튼',
     '· [지금 동작 그대로 배정] — 처음 한 번. 지금 매일 나가는 표만 매일로, '
     '나머지는 연 2회. 통계로 정하지 않습니다\n'
     '· [크기 다시 재기] — 자산을 전수 측정(약 4초). 잰 날이 함께 남습니다\n'
     '· [주기 바꾸기] — 오른쪽에서 선택한 스몰팩의 주기를 옮깁니다\n'
     '· 왼쪽 권고는 겹클릭하면 그대로 옮깁니다 — 통계는 권하고 정하는 것은 '
     '사람입니다'),
    ('아래 경고 — 주기를 넘는 연결',
     '빠른 스몰팩이 느린 것을 가리키면, 상대가 아직 안 온 사용자에게 그 '
     '연결이 미아가 됩니다. 막지는 않습니다(자연 열쇠로 싣고 보류하는 길이 '
     '있습니다) — 릴리스를 짤 때 보고 판단하라는 자리입니다.'),
]

_CYCLE_NAME = {c: n for c, n, _d, _i in ST.CYCLES}


def _mb(b):
    if b is None or b < 0:
        return '못 잼'
    if b < 1048576:
        return '%.0f KB' % (b / 1024.0)
    return '%.1f MB' % (b / 1048576.0)


class PackReleaseTab(ttk.Frame):
    """배포 센터에 심는 부품."""

    def __init__(self, master, db=None, **kw):
        super().__init__(master, **kw)
        self.db = db or 'bible_master.db'
        self._rows = []
        self._due_map = {}
        self._cur = None
        self._build()
        self.after(60, lambda: self.reload(quiet=True))

    # ── 짓기 ────────────────────────────────────────────────────────
    def _build(self):
        try:
            help_row(self, '릴리스 패킹', HELP_SECTIONS, height=7)
        except Exception:
            pass

        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=6, pady=(4, 2))
        tk.Button(bar, **ui_theme.flat_btn(
            text='새로 고침', command=lambda: self.reload())
        ).pack(side='left')
        tk.Button(bar, **ui_theme.flat_btn(
            text='지금 동작 그대로 배정', command=self._seed)
        ).pack(side='left', padx=(6, 0))
        tk.Button(bar, **ui_theme.flat_btn(
            text='크기 다시 재기', command=lambda: self.reload(refresh=True))
        ).pack(side='left', padx=(6, 0))
        self._log_lbl = ttk.Label(bar, text='')
        self._log_lbl.pack(side='right')

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=(0, 4))

        # ── 좌: 주기 묶음 ────────────────────────────────────────────
        left = ttk.Frame(pw)
        pw.add(left, weight=1)
        ttk.Label(left, text='릴리스 묶음',
                  font=('', 10, 'bold')).pack(anchor='w')
        self._btv = ttk.Treeview(left, columns=('n', 'sz', 'f'),
                                 show='tree headings', height=5)
        self._btv.heading('#0', text='주기')
        self._btv.heading('n', text='스몰팩')
        self._btv.heading('sz', text='용량')
        self._btv.heading('f', text='변경')
        self._btv.column('#0', width=88)
        self._btv.column('n', width=62, anchor='e')
        self._btv.column('sz', width=76, anchor='e')
        self._btv.column('f', width=78, anchor='e')
        self._btv.pack(fill='x')
        self._btv.bind('<<TreeviewSelect>>', self._on_bundle)

        # ★★ **그날 실제로 나가는 파일** — 주기가 겹치는 날에는 여러 파일이
        #   나란히 나간다(합치지 않는다). 관리자가 그 모양을 미리 본다.
        self._due = ttk.Label(left, text='', justify='left', wraplength=290)
        self._due.pack(anchor='w', pady=(4, 0))

        ttk.Label(left, text='권고 — 누르면 옮긴다',
                  font=('', 10, 'bold')).pack(anchor='w', pady=(8, 0))
        self._adv = ttk.Treeview(left, columns=('w',), show='tree headings')
        self._adv.heading('#0', text='스몰팩')
        self._adv.heading('w', text='권하는 주기')
        self._adv.column('#0', width=170)
        self._adv.column('w', width=90)
        self._adv.pack(fill='both', expand=True)
        self._adv.bind('<Double-1>', self._take_advice)
        self._adv_note = ttk.Label(left, text='', wraplength=280,
                                   justify='left')
        self._adv_note.pack(anchor='w', pady=(2, 0))

        # ── 중: 스몰팩 목록 ─────────────────────────────────────────
        mid = ttk.Frame(pw)
        pw.add(mid, weight=3)
        head = ttk.Frame(mid)
        head.pack(fill='x')
        self._mid_lbl = ttk.Label(head, text='스몰팩',
                                  font=('', 10, 'bold'))
        self._mid_lbl.pack(side='left')
        self._only = tk.StringVar(value='ALL')
        for v, nm in (('ALL', '전체'), ('TABLE', '코어 표'),
                      ('ASSET', '본문 자산')):
            ttk.Radiobutton(head, text=nm, value=v, variable=self._only,
                            command=self._fill_mid).pack(side='left',
                                                         padx=(8, 0))
        self._tv = ttk.Treeview(
            mid, columns=('f', 'sz', 'lk', 'cy'), show='tree headings')
        for k, t, w, a in (('#0', '스몰팩', 240, 'w'), ('f', '변경', 74, 'e'),
                           ('sz', '용량', 82, 'e'), ('lk', '연결', 82, 'e'),
                           ('cy', '주기', 68, 'center')):
            self._tv.heading(k, text=t,
                             command=(lambda kk=k: self._sort(kk)))
            self._tv.column(k, width=w, anchor=a)
        vs = ttk.Scrollbar(mid, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=vs.set)
        self._tv.pack(side='left', fill='both', expand=True)
        vs.pack(side='right', fill='y')
        self._tv.bind('<<TreeviewSelect>>', self._on_pick)

        # ── 우: 상세 ────────────────────────────────────────────────
        right = ttk.Frame(pw)
        pw.add(right, weight=2)
        self._name = ttk.Label(right, text='(왼쪽에서 선택하세요)',
                               font=('', 11, 'bold'), wraplength=300,
                               justify='left')
        self._name.pack(anchor='w')
        self._facts = ttk.Label(right, text='', justify='left',
                                wraplength=300)
        self._facts.pack(anchor='w', pady=(2, 6))

        cy = ttk.Frame(right)
        cy.pack(fill='x')
        ttk.Label(cy, text='주기').pack(side='left')
        self._cy_var = tk.StringVar(value=ST.DEFAULT_CYCLE)
        self._cy_cmb = ttk.Combobox(
            cy, textvariable=self._cy_var, state='readonly', width=10,
            values=[n for _c, n, _d, _i in ST.CYCLES])
        self._cy_cmb.pack(side='left', padx=(4, 4))
        self._cy_btn = tk.Button(cy, **ui_theme.flat_btn(
            text='주기 바꾸기', command=self._set_cycle))
        self._cy_btn.pack(side='left')
        self._cy_btn.configure(state='disabled')

        ttk.Label(right, text='② 이 스몰팩이 낀 연결',
                  font=('', 10, 'bold')).pack(anchor='w', pady=(8, 0))
        self._lk = ttk.Treeview(right, columns=('n', 'cy'),
                                show='tree headings')
        self._lk.heading('#0', text='상대 · 종류')
        self._lk.heading('n', text='행')
        self._lk.heading('cy', text='상대 주기')
        self._lk.column('#0', width=210)
        self._lk.column('n', width=72, anchor='e')
        self._lk.column('cy', width=76, anchor='center')
        self._lk.pack(fill='both', expand=True)

        # ── 하: 주기를 넘는 연결 ────────────────────────────────────
        self._warn = tk.Text(self, height=4, wrap='word')
        self._warn.pack(fill='x', padx=6, pady=(0, 6))
        try:
            theme_font.register(self._warn, self.db, 'ui')
        except Exception:
            pass
        self._warn.configure(state='disabled')

        # ★ 목록 표준 서식(§theme_font.list_style) — 손으로 rowheight 를
        #   박지 않는다. 그 순간 표준 밖으로 나간다.
        try:
            # 2026-09-05 사용자 신고 「릴리스패킹 탭을 누르면 전체 화면의
            #   폰트체가 바뀐다」.
            #   ttk.Style 은 인터프리터 전역이라 기본 이름(Treeview)을
            #   설정하면 관리자 앱의 모든 트리가 그 자리에서 바뀐다
            #   (되돌릴 길도 없다). 사용자 앱은 시작 때 등록하지만
            #   (user_main:801) 관리자 앱은 안 한다 — 그래서 이 탭을 여는
            #   순간 튄다. 전용 이름을 쓴다. 이 화면만 표준 서식을 따른다.
            theme_font.list_style('PackRel.Treeview', self.db)
        except Exception:
            pass

    # ── 데이터 ──────────────────────────────────────────────────────
    def reload(self, refresh=False, quiet=False):
        c = appdb.connect(self.db)
        try:
            ST.ensure(c)
            self._rows = ST.stat(c, 30, refresh=refresh)
            self._bundles = ST.bundles(c, rows=self._rows)
            # 겹치는 날(0) · 보통 날(1) — 실제로 나가는 파일 모양
            self._due_map = {d: ST.due(c, d, self._rows) for d in (0, 1)}
            self._advice = ST.advice(c, 30, rows=self._rows)
            self._cross = ST.cross_cycle(c, self._rows)
            lo, hi, n = ST.log_span(c)
        finally:
            c.close()
        self._log_lbl.configure(
            text='감사 로그 %s ~ %s · %s건  ⚠ 이 기간이 대표성 있는지 사람이 판단'
                 % (lo or '?', hi or '?', format(n, ',')))
        self._fill_bundles()
        self._fill_mid()
        self._fill_advice()
        self._fill_warn()
        if not quiet:
            self._name.configure(text='(가운데에서 선택하세요)')

    def _fill_bundles(self):
        self._btv.delete(*self._btv.get_children())
        for b in self._bundles:
            self._btv.insert('', 'end', iid=b['cycle'], text=b['name'],
                             values=(format(b['units'], ','), _mb(b['bytes']),
                                     format(b['freq'], ',')))
        # ★★★ **주기가 겹치는 날 — 파일은 따로, 번호는 하나**
        #   합치지 않는 이유: ⓐ 매일 받는 사람이 연 2회 것을 매일 다시 받는다
        #   ⓑ 한 덩이가 실패하면 나머지도 못 받는다.
        try:
            lines = []
            for days, when in ((0, '겹치는 날'), (1, '보통 날')):
                ds = self._due_map.get(days) or []
                if not ds:
                    continue
                lines.append('%s — 파일 %d개  %s'
                             % (when, len(ds),
                                ' + '.join('%s %s' % (x['name'], _mb(x['bytes']))
                                           for x in ds)))
            order = ' → '.join(_CYCLE_NAME.get(c, c) for c in ST.apply_order())
            lines.append('넣는 차례: %s  (껍데기가 먼저, 연결이 나중)' % order)
            self._due.configure(text='\n'.join(lines))
        except Exception:
            self._due.configure(text='')

    def _fill_advice(self):
        self._adv.delete(*self._adv.get_children())
        for a in self._advice:
            self._adv.insert('', 'end', iid=a['code'], text=a['label'],
                             values=(_CYCLE_NAME.get(a['want'], a['want']),))
        self._adv_note.configure(
            text=('권고 %d건 — 겹클릭하면 옮깁니다. **통계는 권하고 정하는 것은 '
                  '사람입니다.**' % len(self._advice)) if self._advice
                 else '어긋난 것이 없습니다.')

    def _fill_warn(self):
        self._warn.configure(state='normal')
        self._warn.delete('1.0', 'end')
        if not self._cross:
            self._warn.insert('end', '주기를 넘는 연결이 없습니다.')
        else:
            self._warn.insert(
                'end', '⚠ 주기를 넘는 연결 %d줄 — 빠른 쪽이 느린 쪽을 '
                       '가리킵니다. 상대가 아직 안 온 사용자에게 그 연결은 '
                       '미아가 됩니다(막지는 않습니다).\n' % len(self._cross))
            for x in self._cross[:4]:
                self._warn.insert(
                    'end', '   · %s(%s) → %s(%s) %s행\n'
                           % (x['label'], _CYCLE_NAME.get(x['mine'],
                                                          x['mine']),
                              x['other'], _CYCLE_NAME.get(x['theirs'],
                                                          x['theirs']),
                              format(x['rows'], ',')))
        self._warn.configure(state='disabled')

    def _visible(self):
        f = self._only.get()
        rs = [r for r in self._rows if f == 'ALL' or r['kind'] == f]
        cy = getattr(self, '_bundle_filter', None)
        if cy:
            rs = [r for r in rs if r['cycle'] == cy]
        return rs

    def _fill_mid(self, rows=None):
        self._tv.delete(*self._tv.get_children())
        rs = rows if rows is not None else self._visible()
        rs = sorted(rs, key=lambda r: (-r['freq'], -r['bytes']))
        for r in rs:
            self._tv.insert(
                '', 'end', iid=r['code'], text=r['label'],
                values=(format(r['freq'], ','), _mb(r['bytes']),
                        format(r['link_rows'], ','),
                        _CYCLE_NAME.get(r['cycle'], r['cycle'])))
        self._mid_lbl.configure(text='스몰팩 %d개' % len(rs))

    def _sort(self, col):
        key = {'#0': lambda r: r['label'], 'f': lambda r: -r['freq'],
               'sz': lambda r: -r['bytes'], 'lk': lambda r: -r['link_rows'],
               'cy': lambda r: r['cycle']}.get(col)
        if not key:
            return
        self._fill_mid(sorted(self._visible(), key=key))

    # ── 고르기 ──────────────────────────────────────────────────────
    def _on_bundle(self, _e=None):
        s = self._btv.selection()
        self._bundle_filter = s[0] if s else None
        self._fill_mid()

    def _on_pick(self, _e=None):
        s = self._tv.selection()
        if not s:
            return
        r = next((x for x in self._rows if x['code'] == s[0]), None)
        if not r:
            return
        self._cur = r
        self._name.configure(text=r['label'])
        at = r.get('measured') or ''
        meas = '' if at in ('', 'now') else '  (잰 날 %s)' % at
        self._facts.configure(
            text=('① 최근 30일 변경  %s번\n'
                  '③ 용량            %s · %s행%s\n'
                  '   %s\n%s'
                  % (format(r['freq'], ','), _mb(r['bytes']),
                     format(r['rows'], ','), meas,
                     r['code'], r.get('note') or '')))
        self._cy_var.set(_CYCLE_NAME.get(r['cycle'], r['cycle']))
        self._cy_btn.configure(state='normal')
        cy = {x['code']: x['cycle'] for x in self._rows}
        self._lk.delete(*self._lk.get_children())
        for i, x in enumerate(r['links']):
            other_cy = cy.get(x['other_unit'], ST.DEFAULT_CYCLE)
            self._lk.insert(
                '', 'end', iid='L%d' % i,
                text='%s %s · %s' % (x['dir'], x['other'], x['type']),
                values=(format(x['rows'], ','),
                        _CYCLE_NAME.get(other_cy, other_cy)))
        if not r['links']:
            self._lk.insert('', 'end', text='(낀 연결이 없습니다)', values=('', ''))

    # ── 고치기 ──────────────────────────────────────────────────────
    def _cycle_code(self, name):
        for c, n, _d, _i in ST.CYCLES:
            if n == name:
                return c
        return ST.DEFAULT_CYCLE

    def _set_cycle(self):
        if not self._cur:
            return
        cy = self._cycle_code(self._cy_var.get())
        if cy == self._cur['cycle']:
            messagebox.showinfo('릴리스 패킹', '지금과 같은 주기입니다.',
                                parent=self)
            return
        if not messagebox.askyesno(
                '릴리스 패킹',
                '「%s」의 주기를 %s → %s 로 바꿉니다.\n\n'
                '다음 릴리스부터 그 묶음에 실립니다. 코드는 안 바뀝니다.'
                % (self._cur['label'],
                   _CYCLE_NAME.get(self._cur['cycle'], ''),
                   _CYCLE_NAME.get(cy, '')), parent=self):
            return
        c = appdb.connect(self.db)
        try:
            ST.set_cycle(c, self._cur['code'], cy, '릴리스 패킹 화면에서')
        finally:
            c.close()
        self.reload(quiet=True)
        try:
            self._tv.selection_set(self._cur['code'])
            self._tv.see(self._cur['code'])
        except Exception:
            pass

    def _take_advice(self, _e=None):
        s = self._adv.selection()
        if not s:
            return
        a = next((x for x in self._advice if x['code'] == s[0]), None)
        if not a:
            return
        if not messagebox.askyesno(
                '릴리스 패킹',
                '「%s」\n%s\n\n%s 로 옮길까요?'
                % (a['label'], a['why'], _CYCLE_NAME.get(a['want'], '')),
                parent=self):
            return
        c = appdb.connect(self.db)
        try:
            ST.set_cycle(c, a['code'], a['want'], '권선택할 받아들임')
        finally:
            c.close()
        self.reload(quiet=True)

    def _seed(self):
        c = appdb.connect(self.db)
        try:
            n = ST.seed(c)
        finally:
            c.close()
        messagebox.showinfo(
            '릴리스 패킹',
            '%d개 스몰팩에 초기 주기를 배정했습니다.\n\n'
            '⚠ 통계로 정한 것이 아니라 **지금 실제로 나가는 모양 그대로**'
            '입니다. 이미 정해 둔 것은 안 건드립니다.' % n, parent=self)
        self.reload(quiet=True)


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-50s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-50s %s' % (n, e))

    print('=== pack_release_tab selftest')
    root = tk.Tk()
    root.withdraw()
    try:
        ui_theme.adopt(root)
    except Exception:
        pass
    p = PackReleaseTab(root, db='bible_master.db')
    p.pack(fill='both', expand=True)
    root.update()
    p.reload(quiet=True)
    root.update()

    t('★ 탭이 지어진다', bool(p._rows), '%d개' % len(p._rows))
    t('★★★ ① **변경 칸이 있다**', 'f' in p._tv['columns'])
    t('★★★ ③ **용량 칸이 있다**', 'sz' in p._tv['columns'])
    t('★★★ ② **연결 칸이 있다**', 'lk' in p._tv['columns'])
    t('  주기 칸도 있다', 'cy' in p._tv['columns'])
    n_mid = len(p._tv.get_children())
    t('★ 목록이 실제로 그려진다', n_mid > 50, '%d줄' % n_mid)
    t('★★ **묶음 요약이 주기 수만큼**',
      len(p._btv.get_children()) == len(ST.CYCLES))
    t('★★ **로그 기간을 화면이 말한다**(며칠치인지 모르면 잘못 읽는다)',
      '감사 로그' in p._log_lbl.cget('text'))

    # 가운데에서 하나 고르면 오른쪽이 찬다
    hot = max(p._rows, key=lambda r: r['link_rows'])
    p._tv.selection_set(hot['code'])
    root.update()
    t('★★★ **선택하면 오른쪽에 셋이 다 나온다**',
      '①' in p._facts.cget('text') and '③' in p._facts.cget('text'),
      p._name.cget('text')[:26])
    t('★★★ ② **연결 상대와 그 주기를 낸다**(릴리스 짤 때 이것을 본다)',
      len(p._lk.get_children()) > 0,
      '%d줄' % len(p._lk.get_children()))
    t('  주기 바꾸기 단추가 살아난다',
      str(p._cy_btn.cget('state')) == 'normal')

    # 걸러보기
    p._only.set('TABLE')
    p._fill_mid()
    root.update()
    n_tab = len(p._tv.get_children())
    p._only.set('ASSET')
    p._fill_mid()
    root.update()
    n_ast = len(p._tv.get_children())
    t('★★ **코어 표와 본문 자산을 갈라 본다**',
      n_tab > 0 and n_ast > 0 and n_tab + n_ast == n_mid,
      '표 %d + 자산 %d = %d' % (n_tab, n_ast, n_mid))
    p._only.set('ALL')
    p._fill_mid()

    # 묶음을 누르면 그 주기만
    if p._bundles:
        big = max(p._bundles, key=lambda b: b['units'])
        p._btv.selection_set(big['cycle'])
        root.update()
        t('★★ **묶음을 누르면 그 주기만 보인다**',
          len(p._tv.get_children()) == big['units'],
          '%s %d개' % (big['name'], big['units']))
        p._btv.selection_remove(big['cycle'])
        p._bundle_filter = None
        p._fill_mid()

    # 못 잰 크기를 0 으로 안 낸다
    t('★★ **못 잰 크기는 「못 잼」이라 적는다**(0 은 「작다」로 읽힌다)',
      _mb(-1) == '못 잼' and _mb(None) == '못 잼')

    due_txt = p._due.cget('text')
    t('★★★ **그날 나가는 파일 모양을 말한다**(겹쳐도 합치지 않는다)',
      '파일' in due_txt, due_txt.replace(chr(10), ' / ')[:60])
    t('★★ **넣는 차례를 말한다**(껍데기가 먼저)',
      '넣는 차례' in due_txt and '연 2회' in due_txt)

    # 경고 줄
    txt = p._warn.get('1.0', 'end')
    t('★★★ **주기를 넘는 연결을 화면이 말한다**',
      ('주기를 넘는 연결' in txt) or ('없습니다' in txt), txt.strip()[:44])

    # 권고는 보이되 안 바꾼다
    c = appdb.connect('bible_master.db')
    try:
        before = ST.cycles(c)
    finally:
        c.close()
    p._fill_advice()
    root.update()
    c = appdb.connect('bible_master.db')
    try:
        after = ST.cycles(c)
    finally:
        c.close()
    t('★★★ **권선택할 그리는 것만으로 주기가 안 바뀐다**', before == after,
      '%d개 그대로' % len(after))

    root.destroy()
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
