# -*- coding: utf-8 -*-
"""운영 ▸ AI 작업 현황 — AI 심사·번역 일의 진행을 한 화면에서 본다 (2026-10-08 · 사용자 「전체 진행상황
모니터링 화면도 배치하라」).

줄마다 = 작업 · 대상 · 처리 · 남음 · 결과(정확도·판정 분포) · 비용/사용 · 마지막.
  · 찬양 AI 심사(Gemini)        db_ai_worship
  · 설교 용어 연결(Gemini/Claude) db_ai_term_link — 정답 표본 대비 정확도
  · Q&A                         qa_ai · qa_agent
  · Gemini 오늘 사용량(ai_client 를 거친 호출) · Claude 30일 사용(claude_run 기록)
줄을 고르면 아래에 그 작업의 보고서(파일)나 세부를 보인다.

★ 세는 문은 각 모듈의 것을 쓴다 — 여기서 SQL 을 새로 짜지 않는다(두 벌이 되면 화면과 도구가 갈린다).
★ 읽기만 한다 · 무거운 셈은 일꾼 스레드에서(화면이 안 멎는다).
"""
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
try:
    from admin.panel_help_box import build_help_button
except ImportError:
    from panel_help_box import build_help_button

COLS = (('task', '작업', 220), ('target', '대상', 90), ('done', '처리', 90), ('left', '남음', 80),
        ('result', '결과', 360), ('cost', '비용·사용', 150), ('last', '마지막', 130))


def _worship(conn):
    import db_ai_worship as W
    import db_ai_worship_test as AT
    AT.ensure(conn)
    pend = len(W.pending_ids(conn))
    rows = W.judged(conn)
    import collections
    k = collections.Counter(v['cls'] for _m, v in rows)
    last = conn.execute('SELECT MAX(at) FROM %s WHERE model=?' % AT.T_RUN, (W.TAG,)).fetchone()[0]
    tok = conn.execute('SELECT SUM(tok_in), SUM(tok_out) FROM %s WHERE model=?' % AT.T_RUN, (W.TAG,)).fetchone()
    approved = conn.execute('SELECT COUNT(*) FROM %s t JOIN sys_media_asset m ON m.media_id=t.media_id'
                            " WHERE t.model=? AND t.ok=1 AND m.media_type='WORSHIP'"
                            ' AND COALESCE(m.is_active,0)=1' % AT.T_RUN, (W.TAG,)).fetchone()[0]
    return {'task': '찬양 AI 심사 (Gemini)', 'target': pend, 'done': len(rows), 'left': pend - len(rows),
            'result': '승인 상태 %d(사람 승인 포함) · 일치(자동승인 후보) %d · 다름 %d · 규칙 없음 %d · 찬양 아님 %d'
                      % (approved, k['AGREE'], k['DISAGREE'], k['NO_RULE'], k['AI_NOT_WORSHIP']),
            'cost': '토큰 %s / %s' % (tok[0] or 0, tok[1] or 0), 'last': last or '-',
            'report': os.path.join(APP, '_ai_worship_quality.txt')}


def _term(conn):
    import db_ai_term_link as T
    T.ensure(conn)
    pl = T.plan(conn)
    out = []
    for mdl, nm in ((T.MODEL, 'Gemini'), (T.CLAUDE_MODEL, 'Claude')):
        n = conn.execute('SELECT COUNT(*), MAX(at) FROM %s WHERE model=?' % T.T_JUDGE, (mdl,)).fetchone()
        acc = T.accuracy(conn, mdl)
        res = ('정답 %d건 · 세 갈래 일치 %.0f%% · 주제 정밀도 %.0f%%/찾음 %.0f%% · 연결 전체 정밀도 %.0f%%/찾음 %.0f%%'
               % (acc['n'], 100.0 * acc['agree'] / max(1, acc['n']), 100 * acc['prec'], 100 * acc['recall'],
                  100 * acc['link_prec'], 100 * acc['link_recall'])) if acc['n'] else '정답 표본으로 아직 안 쟀습니다'
        out.append({'task': '설교 용어 연결 심사 (%s)' % nm, 'target': pl['ai_links'], 'done': n[0],
                    'left': pl['ai_links'] - n[0], 'result': res, 'cost': '-', 'last': n[1] or '-',
                    'report': os.path.join(APP, '_ai_term_report.txt')})
    return out


def _qa():
    import qa_ai
    c = qa_ai.conn()
    try:
        tot = c.execute("SELECT COUNT(*), SUM(COALESCE(reply,'')='') FROM qa").fetchone()
        a = c.execute('SELECT SUM(q_ko IS NOT NULL), SUM(sim_json IS NOT NULL), SUM(checked_hash IS NOT NULL),'
                      ' SUM(sent_at IS NOT NULL), MAX(updated_at) FROM qa_ai').fetchone()
    finally:
        c.close()
    key_ok = bool(qa_ai._gct_key())
    return {'task': 'Q&A (번역·비슷한 질문·검증)%s' % ('' if key_ok else ' ⚠ 번역 키 없음'), 'target': tot[0] or 0, 'done': a[0] or 0,
            'left': tot[1] or 0,
            'result': '번역 %d · 비슷한 질문 찾음 %d · 검증 %d · AI 흐름으로 보냄 %d · 미답변 %d'
                      % (a[0] or 0, a[1] or 0, a[2] or 0, a[3] or 0, tot[1] or 0),
            'cost': '-', 'last': a[4] or '-', 'report': '',
            'note': ('Cloud Translation 키: 있음 — 역번역은 구글 번역(다른 엔진)' if qa_ai._gct_key() else
                     '⚠ Cloud Translation 키가 없습니다 — 역번역을 같은 엔진(Gemini)이 해서 오류가 덮일 수 있습니다. '
                     '수집 ▸ 유튜브 주소 수집기 ▸ API 키 관리에서 넣으세요.')}


def _gemini_today():
    try:
        import ai_client
        c = ai_client._conn()
        try:
            rows = ai_client.usage(c)
        finally:
            c.close()
    except Exception as e:                                # noqa: BLE001
        return {'task': 'Gemini 오늘 사용', 'result': '읽지 못함: %s' % e, 'report': ''}
    calls = sum(r[1] for r in rows)
    return {'task': 'Gemini 오늘 사용 (ai_client)', 'target': '-', 'done': calls, 'left': '-',
            'result': ' · '.join('%s %d회(성공 %d)' % (r[0], r[1], r[2]) for r in rows) or '오늘 0회',
            'cost': '토큰 %d / %d' % (sum(r[3] for r in rows), sum(r[4] for r in rows)), 'last': '-',
            'report': '', 'note': '찬양·용어 심사 도구는 ai_client 를 거치지 않아 여기 안 잡힙니다(위 줄의 토큰을 보세요).'}


def _claude():
    import claude_run
    out = []
    names = {'QA_SIMILAR': 'Q&A 비슷한 질문', 'TERM_JUDGE': '용어 연결 판정'}
    for task, n, ok, cost, sec, last in claude_run.log_summary():
        out.append({'task': 'Claude 30일 · %s' % names.get(task, task), 'target': '-', 'done': n,
                    'left': '-', 'result': '성공 %d/%d · 평균 %.0f초' % (ok or 0, n, sec or 0),
                    'cost': '$%.2f' % (cost or 0), 'last': last or '-', 'report': ''})
    if not out:
        out.append({'task': 'Claude 30일 사용', 'result': '기록 없음', 'report': ''})
    return out


def collect():
    """화면 줄 전부 — 한 갈래가 터져도 나머지는 낸다."""
    import appdb
    rows = []
    conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
    try:
        for fn in (lambda: [_worship(conn)], lambda: _term(conn), lambda: [_qa()],
                   lambda: [_gemini_today()], _claude):
            try:
                rows += fn()
            except Exception as e:                        # noqa: BLE001
                rows.append({'task': '(읽지 못함)', 'result': str(e)[:200], 'report': ''})
    finally:
        conn.close()
    return rows


class AiMonitorPanel(ttk.Frame):
    def __init__(self, master):
        super().__init__(master)
        self._rows = []
        self._q = queue.Queue()
        self._busy = False
        self._build()
        self.after_idle(self.refresh)

    def _build(self):
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(6, 2))
        self._btn = ttk.Button(bar, text='새로 고침', command=self.refresh)
        self._btn.pack(side='left')
        self._stat = ttk.Label(bar, text='')
        self._stat.pack(side='left', padx=8)
        build_help_button(bar, 'AI 작업 현황', [
            ('이 화면', 'AI 로 하는 심사·번역 일이 어디까지 왔는지 한곳에서 봅니다. 읽기만 합니다 — '
                       '실행은 각 도구(명령 줄)·Q&A 관리 화면에서 합니다.'),
            ('줄', '찬양 AI 심사 · 설교 용어 연결 심사(Gemini·Claude 를 따로) · Q&A · Gemini 오늘 사용 · '
                   'Claude 30일 사용. 줄을 선택하면 아래에 그 작업의 보고서가 보입니다.'),
            ('정확도', '용어 연결은 사람이 판정한 정답 80건과 견준 값입니다. 「살림 정밀도」는 AI 가 살린 것 중 '
                     '맞은 비율, 「찾은 비율」은 살려야 할 것 중 AI 가 살린 비율입니다.'),
        ]).pack(side='right')
        body = tk.PanedWindow(self, orient='vertical', sashwidth=6)
        body.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        top = ttk.Frame(body)
        tv = ttk.Treeview(top, columns=[c for c, _t, _w in COLS], show='headings', height=9)
        for c, t, w in COLS:
            tv.heading(c, text=t)
            tv.column(c, width=w, anchor='w' if c in ('task', 'result') else 'center',
                      stretch=c == 'result')
        tv.pack(fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_select)
        self._tv = tv
        body.add(top, minsize=160)
        det = ttk.Frame(body)
        self._det = tk.Text(det, wrap='word', height=12, state='disabled')
        sb = ttk.Scrollbar(det, command=self._det.yview)
        self._det.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._det.pack(fill='both', expand=True)
        body.add(det, minsize=120)

    def refresh(self):
        if self._busy:
            return
        self._busy = True
        self._btn.config(state='disabled')
        self._stat.config(text='세는 중…')
        threading.Thread(target=lambda: self._q.put(collect()), daemon=True).start()
        self.after(150, self._poll)

    def _poll(self):
        try:
            rows = self._q.get_nowait()
        except queue.Empty:
            self.after(150, self._poll)
            return
        self._busy = False
        try:
            self._btn.config(state='normal')
        except tk.TclError:
            return
        self._rows = rows
        self._tv.delete(*self._tv.get_children())
        for i, r in enumerate(rows):
            self._tv.insert('', 'end', iid=str(i), values=[r.get(c, '') for c, _t, _w in COLS])
        import datetime
        self._stat.config(text='%s 기준' % datetime.datetime.now().strftime('%H:%M:%S'))

    def _on_select(self, _e):
        sel = self._tv.selection()
        if not sel:
            return
        r = self._rows[int(sel[0])]
        txt = '%s\n%s\n' % (r.get('task', ''), r.get('result', ''))
        if r.get('note'):
            txt += '\n' + r['note'] + '\n'
        p = r.get('report')
        if p and os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                txt += '\n── 보고서 %s ──\n' % os.path.basename(p) + f.read()[:20000]
        self._det.config(state='normal')
        self._det.delete('1.0', 'end')
        self._det.insert('1.0', txt)
        self._det.config(state='disabled')


def selftest():
    rows = collect()
    ok = len(rows) >= 5 and all('task' in r for r in rows)
    print('panel_ai_monitor selftest %s · 줄 %d' % ('1/1' if ok else '0/1', len(rows)))
    for r in rows:
        print('  ', r.get('task'), '|', r.get('done', ''), '|', r.get('result', '')[:90])
    return ok


if __name__ == '__main__':
    import sys
    sys.path.insert(0, APP)
    sys.exit(0 if selftest() else 1)
