# -*- coding: utf-8 -*-
"""도서 소개문 본문 — `db_book_desc.py` 가 읽는 자료.

★ 문단 셋 = **개요 / 체계 / 주요내용**. 근거는 DB 에 실제로 들어 있는 장 제목·
  편 수·본문이다. 기억으로 쓰지 않는다.
★ 「출처」 줄은 어디서 왔는지·판본·번역자까지만. 그 다음은 소개문 끝의
  「출처·라이선스 보기 ▸」가 맡는다.
⚠ 문단 사이는 개행 하나. 빈 줄을 넣으면 게이트가 막는다.
"""

_PG = 'Project Gutenberg 전자책 #%s'
_PG_EN = 'Project Gutenberg eBook #%s'
_CCEL = 'Christian Classics Ethereal Library (ccel.org)'

BOOKS = {}

# ══ 전기 · 자서전 ═══════════════════════════════════════════════════════
BOOKS['AUGUSTINE_CONF'] = {
    'ko': [
        '4세기 북아프리카 히포의 감독 아우구스티누스가 자기 삶을 돌아보며 쓴 글입니다.'
        ' 독자에게 설명하는 형식이 아니라 처음부터 끝까지 하나님께 직접 말을 거는'
        ' 기도로 되어 있어서, 읽는 사람이 남의 기도를 곁에서 듣는 자리에 서게 됩니다.',
        '열세 권으로 나뉩니다. 1권부터 9권까지가 태어나서 회심하고 어머니 모니카를'
        ' 떠나보내기까지의 생애이고, 10권은 기억과 지금의 자기를 살피는 대목이며,'
        ' 11권부터 13권까지는 시간이란 무엇인가와 창세기 첫 장을 놓고 묵상합니다.',
        '어린 시절의 도둑질처럼 사소해 보이는 잘못을 오래 파고들어 죄의 뿌리를'
        ' 캐묻고, 지식과 명예를 좇던 시절과 오랜 방황, 그리고 어머니의 눈물과 기도를'
        ' 이야기합니다. 「주님을 향하도록 지으셨기에 주님 안에서 쉬기까지는 우리 마음이'
        ' 쉬지 못합니다」라는 첫 권의 고백이 책 전체를 꿰뚫습니다.',
    ],
    'en': [
        'Augustine, bishop of Hippo in fourth-century North Africa, looks back over'
        ' his own life. It is not addressed to the reader but to God from beginning'
        ' to end, so that reading it feels like overhearing a long prayer.',
        'Thirteen books. Books I to IX tell his life from birth through his'
        ' conversion and the death of his mother Monica; Book X examines memory and'
        ' his present self; Books XI to XIII meditate on the nature of time and on'
        ' the opening chapter of Genesis.',
        'He dwells at length on small sins, such as a boyhood theft, in order to dig'
        ' out the root of sin itself, and recounts his years of ambition, wandering,'
        ' and his mother’s tears. The confession of Book I, that the heart is'
        ' restless until it rests in God, runs through the whole work.',
    ],
    'src': [_PG % '3296', '역본: E. B. Pusey 영역'],
    'src_en': [_PG_EN % '3296', 'Translation: E. B. Pusey'],
}

BOOKS['BUNYAN_GRACE'] = {
    'ko': [
        '『천로역정』을 쓴 존 번연이 자기 회심의 내력을 적은 자서전입니다. 설교했다는'
        ' 이유로 갇힌 베드퍼드 감옥에서 썼고, 부제 그대로 「죄인 괴수에게 넘치는 은혜」의'
        ' 기록입니다.',
        '네 부분으로 되어 있습니다. 서문에 이어 자서전 본문이 있고, 1660년 11월에'
        ' 붙잡혀 재판받고 갇히기까지를 따로 적은 「나의 투옥에 대하여」가 뒤따르며,'
        ' 마지막에 그의 가족과 마지막 날들을 전하는 짧은 후기가 붙습니다.',
        '회심 이야기라기보다 오래 이어진 영혼의 싸움 기록에 가깝습니다. 자신이 버림받은'
        ' 자일지 모른다는 두려움, 성령을 모독했다는 공포, 성경 한 구절이 떠올라 겨우'
        ' 붙들리던 날들이 꾸밈 없이 이어집니다. 『천로역정』의 낙심의 수렁과 의심의 성이'
        ' 어디서 나왔는지 이 책이 보여 줍니다.',
    ],
    'en': [
        'The spiritual autobiography of John Bunyan, author of The Pilgrim’s'
        ' Progress, written in Bedford gaol where he was held for preaching. The'
        ' subtitle says it plainly: grace abounding to the chief of sinners.',
        'Four parts: a preface, the autobiography itself, a separate account of his'
        ' arrest, trial and imprisonment beginning in November 1660, and a short'
        ' postscript on his family and last days.',
        'It reads less as a conversion story than as a long record of inward'
        ' conflict: the fear that he was a castaway, the terror of having blasphemed'
        ' the Spirit, and the days when a single remembered verse held him up. Here'
        ' one sees where the Slough of Despond and Doubting Castle came from.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 #4186 은 **『Diary of Samuel Pepys 제62권』**
    #   이었다(바운즈 #16905 와 같은 꼴). 본문은 진본이며 **#654 에서 왔다**
    #   (문장 100% 일치, 전사자 David Price 의 이름이 본문에 남아 있었다).
    'src': [_PG % '654',
            '판본: The Religious Tract Society 1905년판 (제8판 개정)'],
    'src_en': [_PG_EN % '654',
               'Edition: The Religious Tract Society, 1905 (rev. 8th ed.)'],
    'url': 'https://www.gutenberg.org/ebooks/654',
}

BOOKS['MACLAREN_DAVID'] = {
    'ko': [
        '스코틀랜드 설교자 알렉산더 매클라렌이 다윗의 생애를 그가 쓴 시편으로 따라간'
        ' 글입니다. 사무엘서를 순서대로 훑는 전기가 아니라, 삶의 마디마다 그가 남긴 노래를'
        ' 놓고 그때 그 마음이 어떠했는지를 읽어 냅니다.',
        '열다섯 편입니다. 서론에 이어 베들레헴의 목동 시절, 사울을 피해 다니던 도망자'
        ' 시절, 왕이 된 뒤, 그리고 밧세바 사건 이후의 참회와 징계, 압살롬의 반역 때 지은'
        ' 노래들 순서로 이어집니다.',
        '저자 스스로 완전한 전기가 아니라고 밝히고, 시편에 자취가 남은 시기만 다룹니다.'
        ' 그래서 사건을 늘어놓는 대신 시편 51편의 참회나 도망자 시절의 노래처럼 한 편의'
        ' 시를 오래 붙들고, 그 안에서 자라기도 하고 무너지기도 하는 한 사람을 봅니다.',
    ],
    'en': [
        'The Scottish preacher Alexander Maclaren traces David’s life through'
        ' the psalms David wrote. Rather than working through Samuel in order, he'
        ' sets a song beside each stage of the life and reads the heart behind it.',
        'Fifteen chapters: an introduction, then the shepherd days at Bethlehem, the'
        ' long exile from Saul, the years as king, the penitence and chastening that'
        ' followed Bathsheba, and the songs of the fugitive during Absalom’s'
        ' revolt.',
        'Maclaren says openly that this is not a complete biography; he treats only'
        ' the periods the psalms actually touch. So instead of a chain of events we'
        ' get long attention to single poems, such as the penitence of Psalm 51, and'
        ' a man who grows and collapses within them.',
    ],
    'src': [_PG % '21872'],
    'src_en': [_PG_EN % '21872'],
}

# ══ 매일 묵상 ═══════════════════════════════════════════════════════════
BOOKS['BOUNDS_PTP'] = {
    'ko': [
        '미국 감리교 목사 E. M. 바운즈가 설교자의 기도를 두고 쓴 책입니다. 설교의 힘은'
        ' 방법이나 재능이 아니라 강단에 서는 사람 자체에서 나오며, 그 사람을 만드는 것이'
        ' 기도라는 한 가지를 스무 장 내내 되풀이해 두드립니다.',
        '스무 장이고 한 장이 대개 서너 쪽입니다. 장마다 앞에 앞선 시대 기도의 사람들이'
        ' 남긴 말을 인용문으로 붙여 두었는데, 이것도 원서의 일부입니다. 짧고 끝이 분명해'
        ' 하루 한 장씩 스무 날 읽기에 맞습니다.',
        '기도할 시간을 실제로 떼어 놓는 문제, 아침을 기도로 여는 습관, 머리가 아니라'
        ' 마음에서 나오는 은혜, 기름부음이 없는 설교의 공허함을 다룹니다. 사도들이'
        ' 「기도하는 일과 말씀 사역에 힘쓰리라」 한 대목이 책의 축이고, 웨슬리와 루터와'
        ' 브레이너드 같은 이들의 기도 생활이 예로 들어옵니다.',
    ],
    'en': [
        'E. M. Bounds, an American Methodist minister, on the preacher and prayer.'
        ' Over twenty chapters he hammers a single point: power in preaching comes'
        ' not from method or gift but from the man himself, and prayer is what makes'
        ' the man.',
        'Twenty chapters, most only three or four pages. Each opens with a quotation'
        ' from an earlier man of prayer; these epigraphs belong to the original book.'
        ' Short and self-contained, they suit twenty days of one chapter a day.',
        'He treats the practical problem of setting aside time, the habit of'
        ' beginning the day in prayer, grace that rises from the heart rather than'
        ' the head, and the emptiness of preaching without unction. The apostles’'
        ' resolve to give themselves to prayer and the ministry of the word is the'
        ' hinge, with Wesley, Luther and Brainerd brought in as examples.',
    ],
    'src': [_PG % '65115', _CCEL,
            '판본: Marshall Brothers 제12판 (런던)'],
    'src_en': [_PG_EN % '65115', _CCEL,
               'Edition: Marshall Brothers, 12th ed. (London)'],
    'url': 'https://www.gutenberg.org/ebooks/65115',
}

BOOKS['LAWRENCE_PPG'] = {
    'ko': [
        '17세기 프랑스 갈멜 수도원의 평수사 로렌스 형제가 남긴 말과 편지를 그의 벗이'
        ' 모은 책입니다. 부엌에서 그릇을 닦는 동안에도 하나님 앞에 서 있는 감각을 잃지'
        ' 않는 것, 그 한 가지를 평생 익힌 사람의 기록입니다.',
        '일곱 편으로 나누어 실었습니다. 앞의 네 편은 1666년부터 오간 대화 넷이고,'
        ' 뒤의 세 편은 편지 열다섯 통을 다섯씩 묶은 것입니다. 분량이 적어 한두 주면'
        ' 다 읽습니다.',
        '겨울에 잎을 다 떨군 나무를 보다가 열여덟 나이에 회심한 이야기로 시작합니다.'
        ' 정해진 기도 시간과 일하는 시간을 나누지 않았다는 것, 두려움이 아니라 사랑을'
        ' 모든 행동의 목적으로 삼았다는 것, 넘어졌을 때 길게 자책하지 않고 곧바로'
        ' 돌아섰다는 것이 되풀이해 나옵니다.',
    ],
    'en': [
        'Brother Lawrence was a lay brother in a seventeenth-century Carmelite house'
        ' in Paris; a friend gathered his conversations and letters into this small'
        ' book. Its single subject is keeping a sense of God’s presence even'
        ' while washing dishes in the kitchen.',
        'Seven pieces: the first four record conversations held from 1666 onward, the'
        ' last three gather his letters and short maxims. It is brief enough to'
        ' finish in a week or two.',
        'It opens with his conversion at eighteen, prompted by the sight of a tree'
        ' stripped bare in winter. Three things recur: he made no division between'
        ' set times of prayer and times of work; he took love, not fear, as the end'
        ' of every action; and when he fell he did not linger in self-reproach but'
        ' turned back at once.',
    ],
    # ★ 2026-08-22 — 옛 본문은 발췌·재서술본이었다(문장 56%만 실제 번역본에
    #   있었고 「스물여섯 살에 회심」은 어느 원문에도 없었다). **1895년 Revell
    #   판 전문으로 갈아 끼웠다**(9,046자 → 56,419자, `db_lawrence_import`).
    #   ⚠ 이 판에 「영적 잠언」은 없다 — 목차 실측: 대화 4 + 편지 15 뿐이다.
    'src': ['Internet Archive — Fleming H. Revell 1895년판 스캔',
            '프랑스어에서 옮김 (번역자 미상)',
            '프랑스어 원저: Nicolas Herman (로렌스 형제), 사후 편찬'],
    'src_en': ['Internet Archive — scan of the Fleming H. Revell 1895 edition',
               'Translated from the French (translator unnamed)',
               'French original: Nicolas Herman (Brother Lawrence), published'
               ' posthumously'],
    'url': 'https://archive.org/details/practiceofpresen00lawriala',
}

BOOKS['MEYER_ODH'] = {
    'ko': [
        '영국 설교자 F. B. 마이어가 성경 각 장에서 한 구절을 선택해 짧게 묵상한 글입니다.'
        ' 그 구절이 제목이 되고 한 편이 한 쪽 남짓이라, 하루치 읽을거리로 짜여 있습니다.',
        '다섯 권으로 성경 전체를 덮습니다. 창세기~룻기, 사무엘상~욥기, 시편,'
        ' 이사야~말라기, 마태복음~요한계시록 순서로 천백여든아홉 편입니다. 옛 인쇄본을'
        ' 스캔한 글이라 제목과 낱말 일부가 깨진 채 남아 있습니다.',
        '레위기의 피와 정결에서 시작해 「다시 바다가 있지 않더라」로 끝납니다. 구약에서는'
        ' 다윗과 욥과 선지자들의 한 마디를, 시편에서는 기도의 말을, 사복음서에서는'
        ' 예수님의 말과 행동에서 한 마디를 붙들고, 요한계시록에서는 마지막 날의 소망을'
        ' 짚습니다.',
    ],
    'en': [
        'The English preacher F. B. Meyer takes one verse from each chapter of the'
        ' Bible and writes a short meditation on it. The verse serves as the title,'
        ' and each piece runs about a page, so it is built for daily reading.',
        'Five volumes cover the whole Bible: Genesis to Ruth, 1 Samuel to Job, the'
        ' Psalms, Isaiah to Malachi, and Matthew to Revelation. One thousand one'
        ' hundred and eighty-nine readings. The text comes from scanned pages of an'
        ' old printing, so some titles and words remain garbled.',
        'It begins at "He shall save his people from their sins" and ends at "the sea'
        ' is no more". In the Gospels he fastens on a single saying or act of Jesus;'
        ' in Acts and the Epistles on prayer and service; in Revelation on the hope'
        ' of the last day.',
    ],
    'src': ['Internet Archive (archive.org) — 1898년판 다섯 권 스캔본'],
    'src_en': ['Internet Archive (archive.org) — scans of the five volumes'
               ' of the 1898 printing'],
}

BOOKS['MILLER_CYA'] = {
    'ko': [
        '미국 장로교 목사 J. R. 밀러가 그리스도의 생애를 따라 짠 한 해치 매일 묵상집'
        ' 입니다. 서문에서 밝힌 대로 돌봄과 씨름과 의무로 채워진 하루하루에 양식이 되기를'
        ' 바라며 쓴 글입니다.',
        '사복음서에서 본문을 선택해 예수님의 생애를 처음부터 마지막까지 시간 순서로 따라'
        ' 갑니다. 사백여 편이고 한 편이 한 쪽 남짓입니다. 옛 인쇄본을 스캔한 글이라 제목이'
        ' 깨진 곳이 적지 않으니 본문을 기준으로 읽으시기 바랍니다.',
        '탄생과 세례에서 시작해 갈릴리 사역과 가르침을 지나 수난과 부활에 이르고, 한 해'
        ' 마지막 날에는 「나를 따르라」는 부르심으로 닫습니다. 죽음의 문턱에 선 아이의'
        ' 아버지 이야기처럼 복음서의 한 장면을 붙들어 오늘의 삶으로 옮겨 놓는 방식이'
        ' 이어집니다.',
    ],
    'en': [
        'J. R. Miller, an American Presbyterian minister, arranged a year of daily'
        ' readings around the life of Christ. His preface hopes it may be daily food'
        ' for earnest people in a life of care, struggle and duty.',
        'Texts are drawn from the four Gospels and follow the earthly life of Jesus'
        ' from beginning to close. Over four hundred readings, each about a page. The'
        ' text comes from scanned pages of an old printing and many titles are'
        ' garbled, so read by the body rather than the heading.',
        'It runs from the nativity and baptism through the Galilean ministry and'
        ' teaching to the passion and resurrection, closing the year on the call'
        ' "Follow me". Throughout, a single Gospel scene, such as the father whose'
        ' daughter lay at the point of death, is carried over into present life.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 `ccel.org/ccel/miller/comeyeapart` 도 **404**
    #   다. 본문은 진본이며 **어디서 왔는지도 밝혀졌다** — Internet Archive 의
    #   Solid Ground 재인쇄본 스캔과 문장 **100%** 일치하고(첫 편 제목이
    #   `ISBN: 978-159925-207-0` 인 까닭), Thomas Nelson 판 스캔과도 92% 일치.
    'src': ['Internet Archive — Solid Ground 재인쇄본 스캔',
            '원저: 1888년판'],
    'src_en': ['Internet Archive — scan of the Solid Ground reprint',
               'Original edition: 1888'],
    'url': 'https://archive.org/details/isbn_9781599252070',
}

BOOKS['MULLER_ATP'] = {
    'ko': [
        '조지 뮐러가 브리스톨 애슐리 다운에 고아원을 세우고 운영하며 남긴 기록에서'
        ' 기도와 그 응답에 관한 대목을 뽑은 책입니다. 사람에게 후원을 청하지 않고 오직'
        ' 하나님께만 아뢰겠다는 원칙을 평생 지킨 사람의 장부이자 일기입니다.',
        '세 부분입니다. 고아원 사역이 시작되던 초기, 애슐리 다운에 새 고아원을 짓던 시기,'
        ' 그리고 「기도의 귀한 응답들」이라는 제목으로 모은 사례 모음입니다. 날짜별 일기'
        ' 형식이어서 어디서 끊어 읽어도 됩니다.',
        '「너희 믿음의 시련이 불로 연단하여도 없어질 금보다 더 귀하여」라는 베드로전서'
        ' 1장 7절을 앞세우고 시작합니다. 그날 먹일 것이 없던 아침, 예상치 못한 때에'
        ' 도착한 편지와 헌금, 건물을 지을 돈이 채워지던 과정이 날짜와 금액과 함께'
        ' 담담하게 적혀 있습니다.',
    ],
    'en': [
        'Selections on prayer and its answers from George Müller’s'
        ' narratives of founding and running the orphan houses at Ashley Down,'
        ' Bristol. It is the ledger and diary of a man who held to one rule: ask no'
        ' one but God.',
        'Three parts: the beginning and early days of the orphan work, the building'
        ' of the new houses at Ashley Down, and a gathered set of cases under the'
        ' title "Precious answers to prayer". Being dated diary entries, it can be'
        ' taken up anywhere.',
        'It opens under 1 Peter 1:7, on faith tried by fire being more precious than'
        ' gold. Mornings with nothing to feed the children, letters and gifts'
        ' arriving at unlooked-for hours, and the slow filling of a building fund'
        ' are all set down plainly, with dates and sums.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 #10388 은 『A Collection of Old English
    #   Plays 제1권』이었다. 실제로는 #25891 (문장 100% 일치).
    'src': [_PG % '25891', '판본: 1895년판'],
    'src_en': [_PG_EN % '25891', 'Edition: 1895'],
    'url': 'https://www.gutenberg.org/ebooks/25891',
}

BOOKS['MURRAY_AIC'] = {
    'ko': [
        '남아프리카 목사 앤드루 머레이가 요한복음 15장의 「내 안에 거하라」 한 마디를'
        ' 서른한 날에 걸쳐 풀어낸 책입니다. 그리스도께 나아온 사람에게 주어지는 다음'
        ' 부르심이 무엇인지가 처음부터 끝까지의 주제입니다.',
        '서른한 편이고 하루에 한 편씩 한 달이면 마칩니다. 각 편은 성경 한두 구절을 앞에'
        ' 걸고 시작하며, 마지막에 그 하루의 묵상을 짧은 기도로 맺습니다.',
        '「내게로 오라」에 응답한 사람에게 「내 안에 거하라」가 이어진다는 데서 출발해,'
        ' 포도나무 가지의 비유, 그리스도가 우리의 지혜와 의와 거룩함과 구속이 되신다는'
        ' 고린도전서 1장 30절의 네 마디, 십자가에 못 박히신 분과 영광 받으신 분 안에'
        ' 거함으로 나아갑니다. 매 순간과 날마다라는 말이 되풀이됩니다.',
    ],
    'en': [
        'Andrew Murray, a South African pastor, opens out the single phrase "Abide in'
        ' me" from John 15 across thirty-one days. Its subject throughout is the call'
        ' that follows for those who have already come to Christ.',
        'Thirty-one readings, one a day for a month. Each begins with a verse or two'
        ' set at the head and closes with a short prayer gathering up that'
        ' day’s meditation.',
        'It starts from the link between "Come unto me" and "Abide in me", moves'
        ' through the vine and the branch, the four words of 1 Corinthians 1:30'
        ' (wisdom, righteousness, sanctification, redemption), and on to abiding in'
        ' the Crucified and the Glorified One. The phrases "every moment" and "day by'
        ' day" return again and again.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 `ccel.org/ccel/murray/abide` 는 **404 다**
    #   (CCEL 저자 목록에 이 책이 없다). 본문은 진본으로 확인됐다 — Internet
    #   Archive 의 19세기 인쇄본 두 종(Revell·Altemus) 스캔과 문장 89%·87%
    #   일치하고 두 스캔끼리도 80~87% 일치한다. 받아 온 파일이 무엇이었는지는
    #   기록이 없으므로 **「대조 확인」이라고만 적는다** — 있지도 않은 곳을
    #   출처로 대면 그것이 곧 거짓 고지다.
    'src': ['Internet Archive — Fleming H. Revell 판·Altemus 판 스캔본 대조 확인'],
    'src_en': ['Internet Archive — verified against scans of the Fleming H.'
               ' Revell and Altemus printings'],
    'url': 'https://archive.org/details/abideinchristtho00murr_0',
}

BOOKS['SMITH_CSHL'] = {
    'ko': [
        '해나 위톨 스미스가 평범한 신자의 일상에서 믿음의 삶이 어떻게 가능한지를 쓴'
        ' 책입니다. 저자는 첫 장에서 이 가르침을 흐리는 오해 하나를 먼저 걷어내는데,'
        ' 하나님의 몫과 사람의 몫을 뒤섞는 오해입니다.',
        '스물두 장입니다. 앞쪽은 이 삶이 무엇이며 어떻게 들어가는지를 다루고, 가운데는'
        ' 헌신·믿음·의지·인도에 관한 어려움을 하나씩 짚으며, 뒤쪽은 순종의 기쁨과'
        ' 그리스도와의 연합, 그리고 시편 139편 묵상으로 맺습니다.',
        '「어려움에 관하여」라는 제목이 붙은 장이 여럿인 것이 이 책의 성격을 보여 줍니다.'
        ' 시험이 그치지 않는 이유, 넘어졌을 때 무엇을 해야 하는지, 의심이 찾아올 때'
        ' 어떻게 다루는지처럼 실제로 걸려 넘어지는 자리를 하나씩 붙들고 답합니다.',
    ],
    'en': [
        'Hannah Whitall Smith writes on how a life of faith is possible in the'
        ' ordinary days of an ordinary believer. Her first chapter clears away one'
        ' misunderstanding that blocks the whole subject: the confusion of God’s'
        ' side with man’s side.',
        'Twenty-two chapters. The early ones define this life and how to enter it;'
        ' the middle take up difficulties concerning consecration, faith, the will'
        ' and guidance; the later turn to the joy of obedience, oneness with Christ,'
        ' and close on Psalm 139.',
        'That several chapters are titled "Difficulties concerning..." tells you the'
        ' character of the book. Why temptation does not cease, what to do after a'
        ' failure, how to handle doubts when they come: it takes up the places where'
        ' people actually stumble, one at a time.',
    ],
    'src': [_CCEL],
    'src_en': [_CCEL],
}

BOOKS['SPURGEON_ME'] = {
    'ko': [
        '런던 메트로폴리탄 태버내클의 목사 찰스 스펄전이 쓴 하루 두 번의 묵상집입니다.'
        ' 성경 한 구절을 앞에 걸고 한 쪽 남짓 풀어내는데, 어느 편을 펴도 결국 그리스도와'
        ' 그분의 은혜로 돌아옵니다.',
        '1월 1일 아침부터 12월 31일 저녁까지 하루 두 편씩, 모두 칠백서른두 편입니다. 한'
        ' 편이 이천 자 안팎이라 아침저녁으로 짧게 읽기에 맞습니다.',
        '첫 편은 이스라엘이 광야를 지나 가나안 소산을 먹게 된 여호수아 5장 12절로 열고,'
        ' 마지막 편은 「추수할 때가 지나고 여름이 다하였으나 우리는 구원을 얻지'
        ' 못하였다」는 예레미야 8장 20절로 한 해를 닫습니다. 구약과 신약을 가리지 않고'
        ' 본문을 고르며, 위로와 경고가 나란히 놓입니다.',
    ],
    'en': [
        'Twice-daily meditations by Charles Spurgeon, pastor of the Metropolitan'
        ' Tabernacle in London. Each takes a single verse and opens it in about a'
        ' page, and wherever it starts it comes home to Christ and his grace.',
        'Seven hundred and thirty-two readings: morning and evening for every day'
        ' from 1 January to 31 December. Each runs around two thousand characters,'
        ' suited to a short reading at either end of the day.',
        'It opens on Joshua 5:12, Israel eating the fruit of Canaan after the'
        ' wilderness, and closes the year on Jeremiah 8:20, "The harvest is past, the'
        ' summer is ended, and we are not saved." Texts are taken freely from both'
        ' Testaments, and comfort stands next to warning.',
    ],
    'src': [_CCEL, '판본: 1865년 초판 계열'],
    'src_en': [_CCEL, 'Edition: from the 1865 first edition'],
    'url': 'https://ccel.org/ccel/spurgeon/morneve',
}

BOOKS['SPURGEON_TOD'] = {
    'ko': [
        '스펄전이 이십여 년에 걸쳐 쓴 시편 강해 『다윗의 보고』에서 편마다 앞에 붙인'
        ' 머리글만 모은 것입니다. 시편 한 편을 읽기 전에 그 편이 어떤 노래인지 먼저'
        ' 알려 주는 안내입니다.',
        '시편 1편부터 150편까지 백쉰 편입니다. 각 머리글은 표제(TITLE)와 주제(SUBJECT),'
        ' 그리고 그 편을 어떻게 나누어 읽을지(DIVISION)로 짜여 있어, 한 편을 하루치로'
        ' 읽는 백쉰 날 묵상에 그대로 쓰입니다.',
        '1편을 「서문 시편」이라 부르며 시편 전체의 내용을 미리 알리는 노래로 보고,'
        ' 150편에 이르러서는 이제 시편이라는 산맥의 마지막 봉우리에 올랐다고 말합니다.'
        ' 표제에 붙은 악기와 지휘자에 관한 옛 표기까지 짚어 주어 시편의 겉모습도 함께'
        ' 익히게 됩니다.',
    ],
    'en': [
        'The introductions Spurgeon placed at the head of each psalm in The Treasury'
        ' of David, his psalm exposition written over some twenty years, gathered on'
        ' their own. Each tells you what kind of song you are about to read.',
        'One hundred and fifty pieces, Psalm 1 to Psalm 150. Each is built as TITLE,'
        ' SUBJECT and DIVISION, which makes it usable directly as a hundred and fifty'
        ' days of one psalm a day.',
        'He calls Psalm 1 the preface psalm, containing notice of the whole book, and'
        ' at Psalm 150 says we have reached the last summit of the mountain chain.'
        ' He also explains the old headings about instruments and chief musicians, so'
        ' the outward form of the psalms is learned along the way.',
    ],
    'src': ['The Spurgeon Archive (archive.spurgeon.org)',
            '판본: 1885년판 계열'],
    'src_en': ['The Spurgeon Archive (archive.spurgeon.org)',
               'Edition: from the 1885 printing'],
}

# ══ 교리 · 초대교회 문서 ════════════════════════════════════════════════
_LF = '영역: J. B. Lightfoot 판 사도교부 문헌'
_LF_EN = 'Translation: J. B. Lightfoot, The Apostolic Fathers'

BOOKS['DIDACHE'] = {
    'ko': [
        '「열두 사도의 가르침」이라는 뜻의 짧은 글로, 1세기 후반에서 2세기 초에 쓰인'
        ' 것으로 봅니다. 지은이는 알려져 있지 않습니다. 지금 남아 있는 것 가운데 가장'
        ' 오래된 교회 생활 지침서입니다.',
        '열여섯 장이고 전체가 얇습니다. 앞부분은 생명의 길과 사망의 길로 나눈 윤리'
        ' 교훈이고, 가운데는 세례와 금식과 기도와 성찬에 관한 실제 지침이며, 뒤쪽은'
        ' 순회 예언자와 교사를 어떻게 분별할 것인가와 주일 모임, 그리고 재림을 기다리는'
        ' 권면으로 맺습니다.',
        '⚠ 읽기 전에: 성경(정경)이 아니라 초대교회 문서입니다. 신앙과 삶의 최종 권위는'
        ' 성경이며, 이 글은 신약 직후 세대가 말씀을 어떻게 살아냈는지 보여 주는 역사'
        ' 증언으로 읽어야 합니다. 세례 방식이나 수요일과 금요일의 금식 같은 구체 규례는'
        ' 그 시대 한 지역 교회의 관행이지 오늘의 교회가 그대로 따라야 할 규범이'
        ' 아닙니다. 지은이와 연대도 학자들 사이에 아직 논의 중입니다.',
    ],
    'en': [
        'A short work whose title means "the teaching of the twelve apostles",'
        ' generally dated to the late first or early second century. Its author is'
        ' unknown. It is the oldest surviving manual of church life.',
        'Sixteen brief chapters. The first part is moral instruction set out as the'
        ' way of life and the way of death; the middle gives practical direction on'
        ' baptism, fasting, prayer and the eucharist; the last treats how to test'
        ' travelling prophets and teachers, the assembly on the Lord’s Day, and'
        ' watchfulness for the Lord’s coming.',
        '⚠ Before you read: this is an early church document, not Scripture. The'
        ' final authority for faith and life is the Bible; read this as historical'
        ' witness to how the generation just after the apostles lived out the word.'
        ' Its specific rules, such as the mode of baptism or fasting on Wednesday and'
        ' Friday, were the practice of one region in one era, not a standard binding'
        ' on the church today. Authorship and date are still debated.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['CLEMENT_1ST'] = {
    'ko': [
        '로마 교회가 고린도 교회에 보낸 편지로 96년 무렵의 글입니다. 신약 이후 남아'
        ' 있는 가장 이른 기독교 문서 가운데 하나이며, 전하기로는 로마의 클레멘트가'
        ' 썼습니다.',
        '예순여섯 장으로 나뉘어 있습니다. 고린도 교회가 장로들을 부당하게 해임한 분쟁을'
        ' 놓고 시기와 분열이 어떤 결과를 낳는지 구약 인물들을 하나씩 들어 경고한 뒤,'
        ' 질서와 겸손과 회개를 권면하고 긴 기도로 맺습니다.',
        '⚠ 읽기 전에: 성경이 아닌 초대교회 문서입니다. 구약을 풍부하게 인용하고 바울이'
        ' 같은 교회에 보낸 고린도전서를 직접 언급합니다. 후대에 이 편지를 근거로 로마'
        ' 교회의 우위를 주장한 해석이 있으나 본문 자체는 형제 교회 사이의 권면 형식이며,'
        ' 교회 제도에 관한 결론은 교단마다 다르게 이어받은 주제이므로 특정 제도의 근거로'
        ' 읽지 않아야 합니다. 25장의 불사조 이야기처럼 당대의 자연 지식을 끌어온 대목은'
        ' 과학적 진술이 아니라 부활을 설명하려는 예화입니다.',
    ],
    'en': [
        'A letter from the church at Rome to the church at Corinth, written about the'
        ' year 96. It is among the earliest Christian writings to survive after the'
        ' New Testament, and tradition ascribes it to Clement of Rome.',
        'Sixty-six chapters. Facing a dispute in which Corinth had wrongly deposed'
        ' its elders, it warns from a series of Old Testament figures what jealousy'
        ' and division produce, then urges order, humility and repentance, and closes'
        ' with a long prayer.',
        '⚠ Before you read: this is an early church document, not Scripture. It'
        ' quotes the Old Testament freely and refers directly to Paul’s first'
        ' letter to the same church. Later writers used it to argue for the primacy'
        ' of Rome, but the text itself is an exhortation between sister churches, and'
        ' conclusions about church government differ between traditions, so it should'
        ' not be read as proof for any one polity. Passages drawing on the natural'
        ' lore of the day, such as the phoenix in chapter 25, are illustrations meant'
        ' to explain resurrection, not scientific statements.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['IGNATIUS_LETTERS'] = {
    'ko': [
        '안디옥의 감독 이그나티우스가 110년 무렵 로마로 압송되어 순교하러 가는 길에 쓴'
        ' 편지들입니다. 죽음을 앞둔 사람이 길 위에서 쓴 글이라 문장이 짧고 숨이'
        ' 가쁩니다.',
        '일곱 편입니다. 에베소·마그네시아·트랄레스·로마·필라델피아·서머나 여섯 교회에'
        ' 보낸 편지와, 서머나의 감독 폴리캅에게 보낸 편지로 이루어져 있습니다.',
        '⚠ 읽기 전에: 성경이 아닌 초대교회 문서입니다. 교회의 일치, 예수님이 실제 몸으로'
        ' 나시고 죽으시고 부활하셨다는 확언, 순교를 앞둔 담대한 신앙이 중심입니다. 편지'
        ' 전반의 강한 감독 중심 교회론은 교단마다 해석이 갈리는 주제이므로 특정 제도의'
        ' 근거가 아니라 이단 앞에서 흩어지지 않으려던 초대교회의 일치 열망으로 읽어야'
        ' 합니다. 내 순교를 막지 말라고 로마 교회에 쓴 대목은 순교를 자청하라는 가르침이'
        ' 아니라 박해 시대의 절박한 고백입니다. 후대에 부풀려진 판본들이 있었고 여기'
        ' 실린 일곱 편은 학계가 진본으로 확인한 것입니다.',
    ],
    'en': [
        'Letters written about the year 110 by Ignatius, bishop of Antioch, while he'
        ' was being taken under guard to Rome to die. They were written on the road'
        ' by a man facing execution, and the sentences are short and breathless.',
        'Seven letters: to the churches at Ephesus, Magnesia, Tralles, Rome,'
        ' Philadelphia and Smyrna, and one to Polycarp, bishop of Smyrna.',
        '⚠ Before you read: this is an early church document, not Scripture. Its'
        ' themes are the unity of the church, the insistence that Jesus was truly'
        ' born, truly died and truly rose, and a bold faith in the face of martyrdom.'
        ' The strong emphasis on the bishop is read differently by different'
        ' traditions, so take it as the early church’s longing not to be'
        ' scattered by heresy rather than as proof for a form of government. His plea'
        ' that the Roman church not prevent his death is the cry of a man under'
        ' persecution, not a teaching that one should seek martyrdom. Enlarged'
        ' versions circulated later; the seven here are those scholars accept as'
        ' genuine.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['POLYCARP_PHIL'] = {
    'ko': [
        '사도 요한의 제자로 알려진 서머나 감독 폴리캅과 관련된 두 글입니다. 하나는 110년'
        ' 무렵 그가 빌립보 교회에 보낸 편지이고, 다른 하나는 155년 무렵 그의 순교를'
        ' 서머나 교회가 기록한 글입니다.',
        '두 편입니다. 편지는 바울 서신을 풍부하게 인용하며 장로와 집사와 젊은이와'
        ' 아내들에게 각각 실천을 권면합니다. 순교록은 여든여섯 해를 섬긴 노감독이 붙잡혀'
        ' 화형당하기까지를 목격자의 시선으로 전하며, 남아 있는 순교 기록 가운데 가장'
        ' 이른 것입니다.',
        '⚠ 읽기 전에: 성경이 아닌 초대교회 문서입니다. 「팔십육 년 동안 그분을 섬겼으나'
        ' 그분은 한 번도 나를 저버리지 않으셨는데 나를 구원하신 왕을 어찌'
        ' 모독하겠는가」 하는 고백이 여기서 나왔습니다. 불길이 몸을 피해 돛처럼'
        ' 부풀었다는 식의 기적적 묘사는 목격 증언과 문학적 표현이 섞인 서술이라 세부의'
        ' 역사성에는 논의가 있습니다. 끝부분에 순교자의 유해를 소중히 모셨다는 대목도'
        ' 교단마다 평가가 갈리는 주제이므로 스승을 향한 애정 표현으로 읽는 것이'
        ' 안전합니다.',
    ],
    'en': [
        'Two pieces connected with Polycarp, bishop of Smyrna, remembered as a'
        ' disciple of the apostle John: a letter he sent to the church at Philippi'
        ' about the year 110, and the account of his death written by the church at'
        ' Smyrna about 155.',
        'Two parts. The letter quotes Paul freely and gives practical exhortation to'
        ' elders, deacons, young men and wives in turn. The martyrdom follows the old'
        ' bishop, who had served eighty-six years, from his arrest to the fire, told'
        ' by eyewitnesses; it is the earliest such account we have.',
        '⚠ Before you read: this is an early church document, not Scripture. The'
        ' famous confession comes from here: eighty-six years I have served him, and'
        ' he never did me wrong; how can I blaspheme my King who saved me?'
        ' Miraculous details, such as the flame arching away from his body like a'
        ' sail, mix eyewitness report with literary description, and their historical'
        ' detail is debated. The closing note about gathering the martyr’s'
        ' remains is also read differently by different traditions; it is safest to'
        ' take it as affection for a teacher.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['HERMAS_SHEPHERD'] = {
    'ko': [
        '2세기 전반 로마의 평신도 헤르마스가 받았다고 전하는 환상과 계명과 비유의'
        ' 모음입니다. 초대교회에서 가장 널리 읽힌 책 가운데 하나였습니다.',
        '스물일곱 편이 세 묶음으로 나뉩니다. 다섯 편의 환상, 열두 편의 계명, 그리고 열'
        ' 편의 비유입니다. 「목자」라 불리는 인물이 나타나 뒤의 두 묶음을 설명하는'
        ' 형식입니다.',
        '⚠ 읽기 전에: 여기 실린 초대교회 문서 가운데 정경이 아님을 가장 분명히 해 두어야'
        ' 할 책입니다. 중심 물음은 세례 이후에 죄를 지은 사람에게도 회개의 길이 열려'
        ' 있는가이며, 탑을 세우는 환상과 느릅나무와 포도나무 비유가 널리 알려져 있습니다.'
        ' 초대교회 일부가 정경처럼 읽었으나 교회는 최종적으로 정경에 넣지 않았고, 2세기의'
        ' 정경 목록인 무라토리 단편도 읽는 것은 좋으나 공적으로 낭독하지는 말라고'
        ' 했습니다. 특히 세례 후 회개는 한 번뿐이라는 엄격한 주장처럼 성경의 은혜 이해와'
        ' 긋는 대목이 있으므로 항상 성경으로 검증하며 읽어야 합니다.',
    ],
    'en': [
        'A collection of visions, commandments and parables said to have been'
        ' received by Hermas, a layman in Rome, in the first half of the second'
        ' century. It was among the most widely read books in the early church.',
        'Twenty-seven pieces in three groups: five visions, twelve commandments and'
        ' ten parables. A figure called the Shepherd appears and explains the second'
        ' and third groups.',
        '⚠ Before you read: of the early church works held here, this is the one'
        ' whose non-canonical status most needs stating. Its central question is'
        ' whether repentance remains open to those who sin after baptism; the vision'
        ' of the tower under construction and the parable of the elm and the vine are'
        ' the best known parts. Some in the early church read it as Scripture, but'
        ' the church did not finally receive it, and the Muratorian fragment already'
        ' said it should be read privately but not publicly. Some passages, such as'
        ' the strict claim that repentance after baptism is granted only once, sit'
        ' awkwardly beside the Bible’s account of grace, so test it by Scripture'
        ' as you read.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['DIOGNETUS'] = {
    'ko': [
        '디오그네투스라는 이교 지식인의 물음에 답한 짧은 편지로, 지은이는 알려져 있지'
        ' 않고 130년에서 200년 사이의 글로 봅니다. 초기 기독교 변증서 가운데 가장 아름다운'
        ' 글로 꼽힙니다.',
        '열두 장이고 전체가 짧습니다. 그리스도인의 하나님은 누구인가, 왜 저들은 서로'
        ' 사랑하는가, 왜 이 신앙은 이제야 세상에 나타났는가 하는 물음을 차례로 받아 답해'
        ' 갑니다.',
        '⚠ 읽기 전에: 성경이 아닌 초대교회 문서입니다. 그리스도인을 세상의 영혼에 견주며'
        ' 「모든 낯선 땅이 그들에게는 조국이요 모든 조국이 낯선 땅이다」라고 한 5~6장과,'
        ' 한 의인의 의가 많은 죄인을 의롭게 한 달콤한 교환을 노래한 9장이 특히'
        ' 유명합니다. 이 글의 유일한 사본은 1870년 스트라스부르 화재로 불타 그 이전의'
        ' 필사본으로만 전해지고, 마지막 10~12장은 다른 글이 뒤에 붙었을 가능성이 학자들'
        ' 사이에 논의됩니다. 3~4장의 유대 의식 비판은 당시 변증의 말투이므로 오늘의'
        ' 유대인을 향한 판단으로 읽지 않아야 합니다.',
    ],
    'en': [
        'A short letter answering the questions of a pagan inquirer named Diognetus.'
        ' The author is unknown and it is usually dated between 130 and 200. It is'
        ' often called the finest of the early Christian apologies.',
        'Twelve short chapters. It takes up in turn who the Christians’ God is,'
        ' why they love one another as they do, and why this faith appeared in the'
        ' world only now.',
        '⚠ Before you read: this is an early church document, not Scripture.'
        ' Chapters 5 and 6, which compare Christians to the soul of the world and say'
        ' that every foreign land is their homeland and every homeland a foreign'
        ' land, and chapter 9 on the sweet exchange in which the righteousness of one'
        ' justifies many sinners, are the best known. The single manuscript burned in'
        ' the fire at Strasbourg in 1870, so the text survives only through earlier'
        ' copies, and scholars discuss whether chapters 10 to 12 were joined on from'
        ' another work. The criticism of Jewish ritual in chapters 3 and 4 belongs to'
        ' the polemical manner of its time and should not be read as a judgement on'
        ' Jewish people today.',
    ],
    'src': [_CCEL, _LF],
    'src_en': [_CCEL, _LF_EN],
}

BOOKS['LUTHER_FOC'] = {
    'ko': [
        '마르틴 루터가 1520년에 쓴 짧은 글입니다. 종교개혁 초기의 글 가운데 가장 널리'
        ' 읽힌 것으로, 신앙과 자유와 사랑의 관계를 한 자리에서 정리합니다.',
        '두 편으로 되어 있습니다. 앞은 교황 레오 10세에게 보내는 편지이고, 뒤가 본문인'
        ' 논고입니다. 둘을 합해도 분량이 많지 않아 하루 이틀이면 읽습니다.',
        '논고는 서로 어긋나 보이는 두 문장으로 시작합니다. 「그리스도인은 만물 위에'
        ' 자유로운 주인이며 아무에게도 매이지 않는다. 그리스도인은 만물을 섬기는 종이며'
        ' 모두에게 매인다.」 앞의 문장은 믿음으로 받는 자유를, 뒤의 문장은 그 자유가 이웃'
        ' 사랑으로 흘러가는 길을 가리키며, 둘 다 바울에게서 왔음을 밝힙니다.',
    ],
    'en': [
        'A short work Martin Luther wrote in 1520, the most widely read of his early'
        ' Reformation writings. In one place it sets out how faith, freedom and love'
        ' belong together.',
        'Two parts: an open letter to Pope Leo X, and the treatise itself. Together'
        ' they are brief enough to finish in a day or two.',
        'The treatise begins with two sentences that appear to contradict each other:'
        ' a Christian is the most free lord of all and subject to none; a Christian is'
        ' the most dutiful servant of all and subject to everyone. The first points'
        ' to the freedom received by faith, the second to the way that freedom runs'
        ' out into love of neighbour, and Luther shows that both come from Paul.',
    ],
    'src': [_PG % '1911'],
    'src_en': [_PG_EN % '1911'],
}

BOOKS['SPURGEON_AOG'] = {
    'ko': [
        '스펄전이 1886년에 구원을 찾는 사람에게 직접 말을 걸듯 쓴 책입니다. 설교집이'
        ' 아니라 한 사람을 앞에 앉혀 놓고 처음부터 끝까지 붙들고 설득하는 글입니다.',
        '스무 장입니다. 「당신에게」로 시작해 「맺음말」로 끝나며 각 장에 성경 한 구절이'
        ' 걸려 있습니다. 로마서 4장 5절, 에베소서 2장 8절, 히브리서 11장 1절처럼 구원과'
        ' 믿음을 다루는 본문이 축을 이룹니다.',
        '「경건하지 아니한 자를 의롭다 하시는 이」에서 출발해 믿음이 무엇인지, 왜 믿음으로'
        ' 구원받는지, 아무것도 할 수 없다고 느낄 때 무엇을 붙들지, 회개는 어떻게'
        ' 주어지는지 순서로 나아갑니다. 뒤쪽 네 장은 끝까지 떨어지지 않을까 하는 두려움을'
        ' 다루고, 마지막은 요한계시록 22장 17절의 초대로 닫습니다.',
    ],
    'en': [
        'Spurgeon wrote this in 1886 as if speaking directly to someone seeking'
        ' salvation. It is not a book of sermons but a sustained appeal to one'
        ' reader, held to from first page to last.',
        'Twenty chapters, opening with "To you" and closing with "Close", each hung'
        ' on a text. Romans 4:5, Ephesians 2:8 and Hebrews 11:1 carry the argument.',
        'It begins with God justifying the ungodly and moves on to what faith is, why'
        ' salvation is by faith, what to hold when you feel able to do nothing, and'
        ' how repentance is given. The last four chapters take up the fear of falling'
        ' away at the end, and the book closes on the invitation of Revelation 22:17.',
    ],
    'src': [_CCEL, '판본: 1886년판'],
    'src_en': [_CCEL, 'Edition: 1886'],
}

# ══ 이야기 ══════════════════════════════════════════════════════════════
BOOKS['BUNYAN_PP'] = {
    'ko': [
        '존 번연이 감옥에서 쓴 알레고리입니다. 꿈의 형식을 빌려, 등에 짐을 진 사람이'
        ' 멸망의 도시를 떠나 천성에 이르기까지의 길을 이야기로 풀어냅니다. 성경 다음으로'
        ' 많이 번역된 영어 책으로 꼽힙니다.',
        '두 부로 되어 있습니다. 1부는 크리스천 혼자의 여정이고, 2부는 남편이 떠난 뒤'
        ' 아내 크리스티아나와 아이들이 같은 길을 따라가는 이야기입니다. 각 부가 통으로'
        ' 길어 며칠에 걸쳐 나누어 읽는 편이 좋습니다.',
        '낙심의 수렁, 좁은 문, 십자가 앞에서 짐이 굴러떨어지는 자리, 겸손의 골짜기,'
        ' 허영의 시장, 의심의 성과 절망 거인, 그리고 마지막 강을 건너는 장면이 차례로'
        ' 이어집니다. 등장인물의 이름이 곧 성격이라 이야기 자체가 신앙 여정의 지도처럼'
        ' 읽힙니다.',
    ],
    'en': [
        'An allegory John Bunyan wrote in prison. Under the figure of a dream it'
        ' tells of a man with a burden on his back who leaves the City of Destruction'
        ' and travels to the Celestial City. It is reckoned the most translated'
        ' English book after the Bible.',
        'Two parts. Part One follows Christian alone; Part Two follows his wife'
        ' Christiana and their children along the same road after he has gone. Each'
        ' part runs long, so it is best taken over several days.',
        'The Slough of Despond, the Wicket Gate, the place at the cross where the'
        ' burden rolls away, the Valley of Humiliation, Vanity Fair, Doubting Castle'
        ' and Giant Despair, and at last the crossing of the river. Since each'
        ' character’s name is his nature, the story reads as a map of the'
        ' Christian journey.',
    ],
    # ★ 2026-08-22 실측 — **1부와 2부가 서로 다른 파일에서 왔다.**
    #   1부 = #131(문장 99%) · 2부 = #6048 Works 제3권(문장 98~100%).
    #   `source_url` 한 칸에는 담기지 않던 사실이라 `sys_book_source` 에도 남겼다.
    'src': ['Project Gutenberg 전자책 #131 (제1부) · #6048 (제2부)',
            '판본: 1678년 1부 · 1684년 2부 계열'],
    'src_en': ['Project Gutenberg eBooks #131 (Part One) and #6048 (Part Two)',
               'Edition: from Part One (1678) and Part Two (1684)'],
}

BOOKS['SHELDON_IHS'] = {
    'ko': [
        '미국 목사 찰스 셸던이 1896년에 쓴 소설입니다. 한 목사가 교인들에게 앞으로 한 해'
        ' 동안 무슨 일을 하든 먼저 「예수님이라면 어떻게 하실까」를 묻고 그대로 따르자고'
        ' 제안하면서 이야기가 시작됩니다.',
        '서른한 장입니다. 레이먼드라는 도시의 여러 인물을 번갈아 따라가며, 그 약속이 각자의'
        ' 직업과 재산과 관계를 어떻게 흔들어 놓는지를 보여 줍니다.',
        '신문사 사장, 철도 회사 중역, 가수, 대학 총장이 각각 손해를 무릅쓰고 그 물음에'
        ' 답해 가고, 도시의 빈민가에서 벌어지는 일들이 그 결심을 시험합니다. 베드로전서'
        ' 2장 21절 「그의 자취를 따라오게 하려 하셨느니라」가 책 앞에 걸려 있습니다.',
    ],
    'en': [
        'A novel published in 1896 by the American minister Charles Sheldon. It'
        ' begins when a pastor asks his congregation to pledge that for one year they'
        ' will do nothing without first asking what Jesus would do.',
        'Thirty-one chapters, moving between several people in the town of Raymond'
        ' and showing how the pledge unsettles their work, their money and their'
        ' friendships.',
        'A newspaper owner, a railroad executive, a singer and a college president'
        ' each answer the question at real cost, and events in the slum district test'
        ' their resolve. The book stands under 1 Peter 2:21, that Christ left us an'
        ' example, that we should follow in his steps.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 #289 는 **『The Wind in the Willows』**
    #   (케네스 그레이엄)였다. 본문은 진본이며 #4540 과 문장 100% 일치한다.
    'src': [_PG % '4540', '판본: 1897년 초판 계열'],
    'src_en': [_PG_EN % '4540', 'Edition: from the 1897 first printing'],
    'url': 'https://www.gutenberg.org/ebooks/4540',
}

BOOKS['VANDYKE_OWM'] = {
    'ko': [
        '헨리 반 다이크가 1895년에 쓴 짧은 이야기입니다. 동방에서 아기 예수를 찾아온 세'
        ' 박사 말고 한 사람이 더 있었다면 어땠을까 하는 상상에서 출발합니다.',
        '여섯 편으로 되어 있고 전체가 짧아 한자리에서 읽을 수 있습니다. 서문에 이어'
        ' 아르타반이 별을 보고 길을 떠나 삼십삼 년을 헤매다 예루살렘에 이르기까지가'
        ' 차례로 이어집니다.',
        '아르타반은 사파이어와 루비와 진주를 들고 떠나지만, 길에서 만난 병자와 아이와'
        ' 팔려 가는 여인을 위해 보석을 하나씩 내어 줍니다. 결국 빈손으로 왕 앞에 서게'
        ' 되는 마지막 장면이 이 이야기의 요점입니다.',
    ],
    'en': [
        'A short tale published in 1895 by Henry van Dyke. It begins from a'
        ' supposition: what if there had been a fourth wise man who set out from the'
        ' East to find the child?',
        'Six short pieces, brief enough to read at one sitting. After an introduction'
        ' it follows Artaban from the night he sees the sign in the sky through'
        ' thirty-three years of searching to his arrival in Jerusalem.',
        'Artaban sets out carrying a sapphire, a ruby and a pearl, and gives each one'
        ' away for a sick man, a child and a woman about to be sold. That he comes'
        ' before the King at last with empty hands is the point of the story.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 #5050 은 『State of the Union Addresses』
    #   (미국 대통령 연설문)였다. 실제로는 #10679 (문장 100% 일치).
    'src': [_PG % '10679'],
    'src_en': [_PG_EN % '10679'],
    'url': 'https://www.gutenberg.org/ebooks/10679',
}

# ══ 역사 배경 ═══════════════════════════════════════════════════════════
BOOKS['EDERSHEIM_LT'] = {
    'ko': [
        '유대인으로 태어나 기독교로 회심한 학자 알프레드 에더샤임이 1883년에 낸 대작'
        ' 입니다. 복음서의 사건을 1세기 유대 사회와 랍비 문헌의 배경 위에 놓고 처음부터'
        ' 끝까지 따라갑니다.',
        '두 권 합본이며 다섯 부 아흔여덟 장입니다. 1부는 그리스도 당시의 유대 세계,'
        ' 2부는 탄생과 유년, 3부는 갈릴리 사역, 4부는 후기 사역, 5부는 수난과 부활을'
        ' 다룹니다. 장마다 다루는 복음서 구절이 앞에 적혀 있습니다.',
        '한 장면을 다룰 때 당시의 절기와 회당 예배, 랍비들의 가르침과 관습을 함께 펼쳐'
        ' 놓는 것이 이 책의 방식입니다. 유대인이 어떤 메시아를 기다렸는지, 헤롯 치하의'
        ' 예루살렘이 어떠했는지 같은 물음에 한 장씩을 할애합니다.',
    ],
    'en': [
        'The major work of Alfred Edersheim, a Jewish scholar who became a Christian,'
        ' published in 1883. It follows the Gospel narrative from beginning to end,'
        ' set against the Jewish society and rabbinic literature of the first'
        ' century.',
        'Two volumes bound together: five books in ninety-eight chapters. Book I on'
        ' the Jewish world in the days of Christ, Book II the nativity and early'
        ' years, Book III the Galilean ministry, Book IV the later ministry, Book V'
        ' the passion and resurrection. Each chapter names the Gospel passages it'
        ' treats.',
        'Its method is to open out the feasts, the synagogue service, and rabbinic'
        ' teaching and custom alongside each scene. Whole chapters are given to'
        ' questions such as what kind of Messiah the Jews expected, or what Jerusalem'
        ' was like under Herod.',
    ],
    'src': [_CCEL, '판본: 1883년판'],
    'src_en': [_CCEL, 'Edition: 1883'],
}

BOOKS['EDERSHEIM_TMP'] = {
    'ko': [
        '에더샤임이 예수님 당시의 성전을 두고 쓴 책입니다. 건물의 구조만이 아니라 그 안에서'
        ' 하루와 한 해가 어떻게 흘러갔는지를 복원해 보여 줍니다.',
        '열아홉 장입니다. 앞쪽은 예루살렘과 성전의 모습, 성소 안의 기구, 제사장과 레위인의'
        ' 직무와 성전의 재정과 음악을 다루고, 가운데는 제사의 종류와 뜻을, 뒤쪽은 안식일과'
        ' 절기들을 차례로 짚으며 서원에 관한 장으로 맺습니다.',
        '유월절과 오순절과 초막절, 그리고 대속죄일에 성전에서 실제로 무슨 일이 있었는지를'
        ' 시간 순서로 그려 냅니다. 유월절 식사와 주의 만찬을 나란히 놓은 12장처럼 레위기의'
        ' 제사 규례와 복음서의 장면을 잇는 대목이 많습니다.',
    ],
    'en': [
        'Edersheim on the temple as it stood in the days of Jesus. He reconstructs'
        ' not only the building but the course of a day and a year within it.',
        'Nineteen chapters. The first treat Jerusalem and the temple, the vessels of'
        ' the holy place, the priesthood, and the temple’s revenues and music;'
        ' the middle set out the kinds of sacrifice and their meaning; the last work'
        ' through the sabbath and the festivals, closing with a chapter on vows.',
        'It shows, hour by hour, what actually happened in the temple at Passover,'
        ' Pentecost, Tabernacles and the Day of Atonement. Many passages tie the'
        ' Levitical ordinances to Gospel scenes, as chapter 12 does by setting the'
        ' paschal meal beside the Lord’s Supper.',
    ],
    'src': [_CCEL, '판본: 1874년판'],
    'src_en': [_CCEL, 'Edition: 1874'],
}

BOOKS['EDERSHEIM_JSL'] = {
    'ko': [
        '에더샤임이 예수님 당시 유대인의 일상을 그린 책입니다. 신학이 아니라 생활을'
        ' 다룹니다. 집은 어떻게 생겼고 아이는 어떻게 자랐으며 길을 어떻게 다녔는지 같은'
        ' 것들입니다.',
        '열여덟 장입니다. 그 땅의 모습과 갈릴리와 유대 지방, 여행과 숙박, 가정과 자녀'
        ' 교육, 여성의 자리, 죽음과 장례, 상업과 동업 조합, 바리새인과 사두개인과 에세네파의'
        ' 관계, 회당의 구조와 예배 순서로 이어지고, 마지막 장은 옛 유대 문헌을 간추립니다.',
        '복음서를 읽다 걸리는 자리들이 여기서 풀립니다. 잔치의 자리 배치, 세리와 죄인이라는'
        ' 말이 왜 함께 붙어 다녔는지, 회당에서 두루마리를 받아 읽는 절차가 어떠했는지 같은'
        ' 것들이 당시 기록과 함께 설명됩니다.',
    ],
    'en': [
        'Edersheim on the ordinary life of Jewish people in the time of Jesus. Its'
        ' subject is not doctrine but daily living: what houses were like, how'
        ' children were raised, how people travelled.',
        'Eighteen chapters, covering the land itself, Galilee and Judaea, travel and'
        ' hospitality, homes and the upbringing of children, the place of women,'
        ' death and burial, trade and the guilds, the relations between Pharisees,'
        ' Sadducees and Essenes, and the structure and worship of the synagogue; the'
        ' last chapter outlines the ancient Jewish literature.',
        'It resolves the small puzzles that stop a reader in the Gospels: the seating'
        ' at a feast, why "publicans and sinners" were named in one breath, and the'
        ' order followed when a scroll was handed to a reader in the synagogue, each'
        ' explained from the sources of the time.',
    ],
    'src': [_CCEL, '판본: 1876년판'],
    'src_en': [_CCEL, 'Edition: 1876'],
}

# ══ 설교 ════════════════════════════════════════════════════════════════
BOOKS['EDWARDS_SERMONS'] = {
    'ko': [
        '18세기 뉴잉글랜드의 목사이자 신학자였던 조너선 에드워즈의 설교를 선택해 실었습니다.'
        ' 논문에 견주면 문장이 훨씬 잘 읽히면서도 다루는 내용은 그대로 무겁습니다.',
        '일곱 편입니다. 각 설교는 성경 한 구절을 본문으로 걸고, 그 뜻을 밝힌 뒤 교리를'
        ' 세우고 적용으로 맺는 순서를 따릅니다. 한 편이 길어 하루에 한 편씩 읽는 편이'
        ' 좋습니다.',
        '고린도전서 1장을 본문으로 삼아 사람의 모든 것이 하나님께 달렸음을 밝힌 설교로'
        ' 시작하고, 마태복음 16장의 「신적이며 초자연적인 빛」, 룻기 1장의 결단,'
        ' 요한복음 14장의 「내 아버지 집에 거할 곳이 많도다」가 이어집니다. 1741년의'
        ' 「진노하신 하나님의 손 안에 있는 죄인들」과 노샘프턴 교회를 떠나며 한 고별'
        ' 설교도 실려 있습니다.',
    ],
    'en': [
        'Selected sermons of Jonathan Edwards, the eighteenth-century New England'
        ' pastor and theologian. They read far more easily than his treatises while'
        ' carrying the same weight.',
        'Seven sermons. Each takes a text, opens its meaning, states the doctrine and'
        ' ends in application. They run long, so one a day suits.',
        'It opens with God glorified in man’s dependence, from 1 Corinthians 1,'
        ' and continues with the divine and supernatural light from Matthew 16,'
        ' Ruth’s resolution, and the many mansions of John 14. The 1741 sermon'
        ' Sinners in the Hands of an Angry God is here, as is the farewell sermon he'
        ' preached on leaving Northampton.',
    ],
    'src': [_CCEL],
    'src_en': [_CCEL],
}

BOOKS['FINNEY_SERMONS'] = {
    'ko': [
        '미국 부흥운동의 설교자 찰스 피니가 1836년에 묶어 낸 설교집입니다. 듣는 사람에게'
        ' 지금 결단하라고 곧장 밀고 들어오는 것이 이 설교들의 방식입니다.',
        '열두 편입니다. 각 설교는 본문을 걸고 논점을 번호로 나누어 차례로 밀고 가는'
        ' 형식이라, 논지를 따라가기 쉬운 대신 한 편이 깁니다.',
        '에스겔 18장 31절 「너희는 새 마음과 새 영을 지을지어다」를 본문으로 한 두 편이'
        ' 앞에 놓이고, 전적 부패를 다룬 두 편, 선택과 유기를 다룬 두 편, 그리고 청지기직과'
        ' 세상 사랑을 다룬 설교가 이어집니다. 사람의 책임을 강하게 세우는 대목들이'
        ' 특징입니다.',
    ],
    'en': [
        'Sermons gathered in 1836 by Charles Finney, preacher of the American'
        ' revivals. Their manner is to press the hearer for a decision now.',
        'Twelve sermons. Each takes a text and drives through numbered heads, which'
        ' makes the argument easy to follow but each piece long.',
        'Two sermons on Ezekiel 18:31, "Make you a new heart and a new spirit", stand'
        ' first, followed by two on total depravity, two on election and reprobation,'
        ' and sermons on stewardship and the love of the world. The strong emphasis'
        ' on human responsibility is their distinctive mark.',
    ],
    'src': ['Gospel Truth Ministries (gospeltruth.net)', '판본: 1836년판'],
    'src_en': ['Gospel Truth Ministries (gospeltruth.net)', 'Edition: 1836'],
}

BOOKS['WESLEY_SERMONS'] = {
    'ko': [
        '감리교 창시자 존 웨슬리가 교리의 기준으로 삼은 표준 설교집에서 선택해 실었습니다.'
        ' 논쟁하지 않고 차근차근 설명해 나가는 문체라 처음 읽는 사람도 따라갈 수 있습니다.',
        '원서는 마흔네 편이지만 이 앱에는 네 편이 실려 있습니다. 「자기 부인」,'
        ' 「험담을 고치는 길」, 「돈의 사용」, 「선한 청지기」입니다. 각 편은 본문을 걸고'
        ' 번호를 붙인 단락으로 논지를 이어 갑니다.',
        '네 편 가운데 두 편이 돈을 다룹니다. 웨슬리는 누가복음 16장을 본문으로, 힘껏 벌고'
        ' 힘껏 아끼고 힘껏 주라는 세 가지를 세웁니다. 나머지 두 편은 날마다 자기를'
        ' 부인하는 문제와 형제를 두고 하는 말의 문제를 다룹니다.',
    ],
    'en': [
        'Selections from the standard sermons John Wesley set as the doctrinal'
        ' measure for Methodism. The manner is patient exposition rather than'
        ' controversy, so a first-time reader can follow.',
        'The original collection has forty-four sermons; four of them are held here:'
        ' Self-Denial, The Cure of Evil-Speaking, The Use of Money, and The Good'
        ' Steward. Each takes a text and works through numbered paragraphs.',
        'Two of the four concern money. Preaching from Luke 16, Wesley sets out three'
        ' rules: gain all you can, save all you can, give all you can. The other two'
        ' treat daily self-denial and the way we speak of one another.',
    ],
    'src': [_CCEL, '수록: 표준 설교 마흔네 편 가운데 네 편'],
    'src_en': [_CCEL, 'Included: four of the forty-four standard sermons'],
}

BOOKS['WHITEFIELD_SERMONS'] = {
    'ko': [
        '18세기 대각성 운동의 순회 설교자 조지 휫필드의 설교를 선택해 실었습니다. 야외에서'
        ' 수만 명 앞에 서던 사람의 글이라 부르는 어투가 강하고 곧바로 청중을 향합니다.',
        '서른한 편입니다. 창세기부터 요한계시록까지 여러 본문에서 골랐고, 각 설교는 본문을'
        ' 앞에 건 뒤 그 뜻을 풀고 듣는 이에게 적용하는 순서로 이어집니다.',
        '창세기 3장 15절의 여자의 후손과 뱀의 후손을 다룬 설교로 시작하고, 에녹이 하나님과'
        ' 동행한 이야기, 아브라함이 이삭을 드린 사건이 뒤따릅니다. 성탄을 어떻게 지킬'
        ' 것인가를 다룬 설교와, 「한 가지만이라도 족하니라」를 본문으로 영혼을 돌보라 권하는'
        ' 마지막 설교도 실려 있습니다.',
    ],
    'en': [
        'Selected sermons of George Whitefield, the itinerant preacher of the'
        ' eighteenth-century awakening. Written by a man used to open-air crowds of'
        ' many thousands, they address the hearer directly and urgently.',
        'Thirty-one sermons drawn from texts across the whole Bible. Each sets its'
        ' text at the head, opens its meaning, and turns to application.',
        'It begins with the seed of the woman and the seed of the serpent from'
        ' Genesis 3:15, and goes on to Enoch walking with God and Abraham offering'
        ' Isaac. A sermon on how Christmas should be kept is included, and the last,'
        ' on "one thing is needful", urges care of the soul.',
    ],
    'src': [_CCEL],
    'src_en': [_CCEL],
}

BOOKS['SPURGEON_SERMONS'] = {
    'ko': [
        '찰스 스펄전이 런던에서 사십 년 가까이 전한 설교를 번호 순서로 모은 것입니다.'
        ' 첫 편은 1855년 뉴 파크 스트리트 예배당에서 한 설교이고, 이후 메트로폴리탄'
        ' 태버내클에서 전한 것들이 이어집니다.',
        '삼천오백 편이 넘습니다. 각 편에 번호가 붙어 있고, 전한 날짜와 장소, 본문 구절이'
        ' 앞에 적혀 있습니다. 한 편이 대개 삼만 자 안팎으로 설교 한 편 분량 그대로입니다.',
        '1번 「하나님의 불변하심」이 말라기 3장 6절을 본문으로 삼은 것처럼, 설교마다 성경'
        ' 한 구절을 붙들고 갑니다. 구약의 인물과 신약의 비유, 위로와 경고가 두루 들어'
        ' 있어 구절로 찾아 읽기에 맞습니다.',
    ],
    'en': [
        'The sermons Charles Spurgeon preached in London over nearly forty years,'
        ' gathered in their numbered order. The first was preached in 1855 at New'
        ' Park Street Chapel; the rest follow from the Metropolitan Tabernacle.',
        'More than three and a half thousand sermons. Each carries its number, the'
        ' date and place of delivery, and its text. Most run around thirty thousand'
        ' characters, the length of the sermon as preached.',
        'As No. 1, The Immutability of God, takes Malachi 3:6, every sermon holds to'
        ' a single text. Old Testament figures and New Testament parables, comfort'
        ' and warning are all here, which makes the collection well suited to'
        ' searching by verse.',
    ],
    'src': ['The Spurgeon Center (spurgeon.org)'],
    'src_en': ['The Spurgeon Center (spurgeon.org)'],
}

# ══ 영성 ════════════════════════════════════════════════════════════════
BOOKS['KEMPIS_IOC'] = {
    'ko': [
        '15세기 초 토마스 아 켐피스가 라틴어로 쓴 책으로, 성경 다음으로 많이 읽힌 신앙'
        ' 고전으로 꼽힙니다. 긴 논증 대신 짧은 권면을 잇대어 놓아 어디를 펴도 바로 읽힙니다.',
        '네 권으로 나뉘고 그 아래 짧은 장들이 이어집니다. 1권은 영적 생활에 유익한 권면,'
        ' 2권은 내면의 삶, 3권은 내적 위로, 4권은 성찬에 관한 것입니다. 한 장이 대개'
        ' 한두 쪽입니다.',
        '3권과 4권은 주님과 제자가 주고받는 대화 형식이라 「사랑하는 이의 음성」과'
        ' 「제자의 음성」이 번갈아 나옵니다. 자기를 낮게 보는 일, 말을 아끼는 일, 역경이'
        ' 주는 유익, 시험을 견디는 법처럼 일상에서 바로 부딪히는 것들을 다룹니다.',
    ],
    'en': [
        'Written in Latin by Thomas à Kempis in the early fifteenth century and'
        ' reckoned the most read Christian book after the Bible. Instead of long'
        ' argument it strings together short admonitions, so it can be opened'
        ' anywhere.',
        'Four books, each divided into short chapters. Book I gives admonitions'
        ' profitable for the spiritual life, Book II concerns the inner life, Book'
        ' III inward consolation, and Book IV the sacrament. Most chapters run a page'
        ' or two.',
        'Books III and IV are cast as a dialogue, alternating between the Voice of'
        ' the Beloved and the Voice of the Disciple. The subjects are the ones met'
        ' daily: thinking humbly of oneself, guarding the tongue, the uses of'
        ' adversity, and resisting temptation.',
    ],
    'src': [_PG % '1653', '영역: William Benham (1874)'],
    'src_en': [_PG_EN % '1653', 'Translation: William Benham (1874)'],
}

BOOKS['LAW_SCDHL'] = {
    'ko': [
        '영국 성직자 윌리엄 로가 1728년에 쓴 책입니다. 첫 장에서 경건이란 기도 시간이'
        ' 아니라 하나님께 드려진 삶 전체를 뜻한다고 못 박고, 그 정의를 끝까지 밀고'
        ' 나갑니다.',
        '스물네 장입니다. 경건의 뜻을 세운 뒤 시간과 재산과 직업과 말을 차례로 다루고,'
        ' 뒤쪽 여러 장은 하루의 시간대마다 무엇을 기도할지를 정해 놓습니다. 아홉 시에는'
        ' 겸손을, 열두 시에는 중보를, 세 시에는 순복을, 저녁에는 하루를 돌아보는 식입니다.',
        '이 책의 특징은 이름 붙인 인물들을 세워 놓고 비교하는 방식입니다. 재산을 어떻게'
        ' 쓰느냐에 따라 갈리는 사람들, 겉으로는 흠잡을 데 없으나 속이 비어 있는 삶이'
        ' 차례로 나옵니다. 존 웨슬리와 조지 휫필드가 이 책에 크게 흔들렸다고 밝힌 바'
        ' 있습니다.',
    ],
    'en': [
        'Written in 1728 by the English clergyman William Law. His first chapter'
        ' fixes the definition: devotion is not an hour of prayer but a life given to'
        ' God, and he presses that definition all the way through.',
        'Twenty-four chapters. Having settled what devotion means, he takes up time,'
        ' money, employment and speech in turn; the later chapters assign a subject'
        ' to each hour of the day, humility at nine, intercession at twelve,'
        ' resignation at three, and self-examination in the evening.',
        'Its distinctive method is the named character sketch, set one against'
        ' another: people divided by how they use an estate, or lives that are'
        ' outwardly blameless and inwardly empty. Both John Wesley and George'
        ' Whitefield said this book shook them.',
    ],
    # ⚠ 2026-08-22 — 적어 두었던 구텐베르크 #1606 은 월터 스콧의 『Kenilworth』
    #   였다. 이 책은 구텐베르크에 없고 **CCEL 에서 왔다**(문장 99% 일치).
    'src': [_CCEL],
    'src_en': [_CCEL],
    'url': 'https://ccel.org/ccel/law/serious_call',
}

BOOKS['PASCAL_PENSEES'] = {
    'ko': [
        '수학자이자 물리학자였던 블레즈 파스칼이 기독교 변증서를 쓰려고 남긴 초고'
        ' 뭉치입니다. 끝맺기 전에 세상을 떠나 짧은 단상들로 남았고, 다듬어지지 않은 그'
        ' 모양이 오히려 이 책의 힘이 되었습니다.',
        '열네 부로 묶여 있고 단상마다 번호가 붙어 있습니다. 앞쪽은 사람의 정신과 비참함을'
        ' 다루고, 가운데는 내기 논증과 믿음에 이르는 길을, 뒤쪽은 예언과 기적과 그리스도의'
        ' 증거를 다루며 마지막 부는 남은 단편들입니다.',
        '「하나님 없는 인간의 비참」이라는 제목이 붙은 둘째 부가 가장 길고, 사람이 왜'
        ' 가만히 있지 못하고 오락을 찾는지를 파고듭니다. 갈대 하나에 지나지 않지만 생각하는'
        ' 갈대라는 문장과, 믿음을 걸어 보라는 내기 논증이 여기서 나옵니다.',
    ],
    'en': [
        'The notes Blaise Pascal, the mathematician and physicist, left toward a'
        ' defence of the Christian faith. He died before finishing, so it survives as'
        ' short fragments, and that unfinished form has become its strength.',
        'Gathered into fourteen sections with the fragments numbered. The early'
        ' sections treat the human mind and human misery, the middle the wager and'
        ' the means of belief, the later prophecy, miracles and the proofs of Jesus'
        ' Christ, and the last collects remaining fragments.',
        'Section II, the misery of man without God, is the longest, and digs into why'
        ' people cannot sit still and must have diversion. The saying that man is but'
        ' a reed, yet a thinking reed, and the argument of the wager both come from'
        ' here.',
    ],
    'src': [_PG % '18269', '영역: W. F. Trotter'],
    'src_en': [_PG_EN % '18269', 'Translation: W. F. Trotter'],
}

BOOKS['SPURGEON_SW'] = {
    'ko': [
        '스펄전이 목회자 학교 학생들에게 한 강의를 묶은 책으로 그가 세상을 떠난 뒤'
        ' 1895년에 나왔습니다. 첫 강의에서 영혼을 얻는 일이 목회자의 본업이며 모든 신자가'
        ' 추구할 일이라고 못 박습니다.',
        '열다섯 편입니다. 앞의 여덟 편은 학생들에게 한 강의이고 뒤쪽은 여러 자리에서 한'
        ' 연설입니다. 각 편에 잠언 11장 30절, 시편 51편, 고린도전서 9장처럼 성경 본문이'
        ' 걸려 있습니다.',
        '영혼을 얻는다는 것이 무엇인지 정의하는 데서 시작해, 그 일을 하려는 사람에게'
        ' 하나님 앞에서 요구되는 것과 사람 앞에서 요구되는 것을 나누어 다룹니다. 방해가'
        ' 되는 것들, 교인들이 함께 나서게 하는 법, 치르게 되는 대가와 받게 되는 상을'
        ' 차례로 짚습니다.',
    ],
    'en': [
        'Lectures Spurgeon gave to the students of his Pastors’ College,'
        ' published in 1895 after his death. The first lecture states the premise:'
        ' soul-winning is the chief business of the minister and the main pursuit of'
        ' every believer.',
        'Fifteen pieces. The first eight are the college lectures; the rest are'
        ' addresses given elsewhere. Each hangs on a text, such as Proverbs 11:30,'
        ' Psalm 51 or 1 Corinthians 9.',
        'It begins by defining what winning a soul is, then divides the'
        ' qualifications for the work into those required Godward and those required'
        ' manward. Obstacles, how to move a congregation to take part, the cost'
        ' incurred and the reward received follow in turn.',
    ],
    'src': ['The Spurgeon Archive (archive.spurgeon.org)', '판본: 1895년판'],
    'src_en': ['The Spurgeon Archive (archive.spurgeon.org)', 'Edition: 1895'],
}

# ── 신앙고백 셋 (2026-08-30 적재) ──────────────────────────────────────────
# ★ 셋 다 **원문과 영역이 나란히** 실려 있다. 소개문에 그것을 적는다 —
#   독자가 지금 보는 글이 어느 언어에서 왔는지 알아야 한다.
BOOKS['WESTMINSTER_CONF'] = {
    'ko': [
        '1643년부터 영국 웨스트민스터 사원에 모인 신학자들이 육 년에 걸쳐 지은'
        ' 신앙고백입니다. 성경이 무엇을 가르치는지를 주제별로 정리해 조항으로 적었고,'
        ' 이후 장로교회의 표준 문서가 되었습니다.',
        '서른세 장입니다. 성경론에서 시작해 하나님과 작정, 창조와 섭리, 사람의 타락과'
        ' 그리스도의 중보, 믿음과 회개와 선행, 교회와 성례, 마지막 심판으로 끝맺습니다.'
        ' 조항마다 근거 구절이 붙어 있습니다.',
        '영어 원문과 라틴어 번역을 나란히 실었습니다. 첫 문장은 자연의 빛과 창조의'
        ' 일이 하나님을 드러내지만 구원에 이르는 지식에는 이르지 못한다는 것이고,'
        ' 마지막 장은 마지막 날을 알지 못하니 깨어 있으라는 권면으로 닫힙니다.',
    ],
    'en': [
        'The divines who gathered at Westminster Abbey from 1643 spent six years'
        ' producing this confession. It sets out what Scripture teaches, topic by'
        ' topic, in numbered articles, and became the standard document of'
        ' Presbyterian churches.',
        'Thirty-three chapters. It opens with Scripture, moves through God and his'
        ' decree, creation and providence, the fall and the mediation of Christ,'
        ' faith and repentance and good works, the church and the sacraments, and'
        ' closes with the last judgment. Proof texts are attached throughout.',
        'The English original is printed alongside a Latin translation. The first'
        ' sentence holds that the light of nature and the works of creation reveal'
        ' God yet fall short of the knowledge that saves; the last chapter closes'
        ' with the charge to watch, since the day is not known.',
    ],
    'src': ['CCEL — 필립 샤프 『Creeds of Christendom』 제3권',
            '판본: 1889년 제4판 (판권 만료)',
            '영어 원문 ‖ 라틴어 번역 두 단'],
    'src_en': ['CCEL — Philip Schaff, Creeds of Christendom, Vol. III',
               'Edition: 4th ed., 1889 (copyright expired)',
               'English original with facing Latin translation'],
    'url': 'https://www.ccel.org/ccel/schaff/creeds3.iv.xvii.ii.html',
}

BOOKS['BELGIC_CONF'] = {
    'ko': [
        '1561년 귀도 드 브레가 프랑스어로 쓴 신앙고백입니다. 박해 아래 있던 낮은'
        ' 지방(오늘의 벨기에·네덜란드) 개신교인들이 자기들의 믿음이 무엇인지를'
        ' 통치자에게 알리려고 지은 글이라, 변론하는 어조가 곳곳에 남아 있습니다.',
        '서른일곱 조입니다. 하나님을 아는 두 가지 길에서 시작해 성경과 삼위일체,'
        ' 창조와 섭리, 사람의 타락과 선택, 그리스도와 칭의, 교회와 직분과 성례,'
        ' 국가 권세, 마지막 심판으로 끝맺습니다.',
        '프랑스어 원문과 영역을 나란히 실었습니다. 첫 조는 하나님이 한 분이시며'
        ' 영적이시라는 고백이고, 둘째 조는 하나님을 아는 길이 창조 세계와 성경'
        ' 두 가지라고 말합니다. 조항마다 근거 구절이 붙어 있습니다.',
    ],
    'en': [
        'Guido de Brès wrote this confession in French in 1561. Protestants in the'
        ' Low Countries, then under persecution, meant it to show the authorities'
        ' what they actually believed, and the tone of that defense is still'
        ' audible in it.',
        'Thirty-seven articles. It opens with the two ways God is known, then moves'
        ' through Scripture and the Trinity, creation and providence, the fall and'
        ' election, Christ and justification, the church with its offices and'
        ' sacraments, the civil magistrate, and the last judgment.',
        'The French original is printed alongside an English translation. The first'
        ' article confesses that God is one and spiritual; the second names the two'
        ' means by which he is known, the created world and his Word. Proof texts'
        ' are attached throughout.',
    ],
    'src': ['CCEL — 필립 샤프 『Creeds of Christendom』 제3권',
            '판본: 1889년 제4판 (판권 만료)',
            '프랑스어 원문 ‖ 영어 번역 두 단'],
    'src_en': ['CCEL — Philip Schaff, Creeds of Christendom, Vol. III',
               'Edition: 4th ed., 1889 (copyright expired)',
               'French original with facing English translation'],
    'url': 'https://www.ccel.org/ccel/schaff/creeds3.iv.viii.html',
}

BOOKS['DORT_CANONS'] = {
    'ko': [
        '1618년부터 이듬해까지 네덜란드 도르트레흐트에 모인 회의가 내놓은 판단문입니다.'
        ' 당시 제기된 다섯 가지 물음에 조항으로 답하고, 이어서 오해를 하나씩 짚어'
        ' 바로잡는 형식을 취합니다.',
        '선택과 유기, 그리스도의 죽으심, 사람의 부패와 하나님께 돌아섬, 성도의 견인을'
        ' 다룹니다. 각 교리 항목은 긍정 조항과 그 뒤의 배격 조항으로 짝을 이루고,'
        ' 앞뒤로 서문과 결론, 참석자 명단이 붙어 있습니다.',
        '라틴어 원문 전체와 영역을 함께 실었습니다. 영역은 미국 개혁교회가 쓰던'
        ' 축약본이라 긍정 조항만 담고 있어, 서문과 배격 조항과 결론은 라틴어로만'
        ' 보입니다.',
    ],
    'en': [
        'The synod that met at Dordrecht from 1618 into the following year issued'
        ' this judgment. It answers the five questions then in dispute article by'
        ' article, and follows each set with a point-by-point rejection of the'
        ' errors it found attached to them.',
        'It treats election and reprobation, the death of Christ, human corruption'
        ' and conversion to God, and the perseverance of the saints. Each head of'
        ' doctrine pairs positive articles with a rejection of errors, framed by a'
        ' preface, a conclusion, and the list of those present.',
        'The complete Latin text is printed here with an English version beside it.'
        ' That English is the abridgment used in the Reformed Church in America and'
        ' carries only the positive articles, so the preface, the rejections, and'
        ' the conclusion appear in Latin alone.',
    ],
    'src': ['CCEL — 필립 샤프 『Creeds of Christendom』 제3권',
            '판본: 1889년 제4판 (판권 만료)',
            '라틴어 원문 + 영어 축약본'],
    'src_en': ['CCEL — Philip Schaff, Creeds of Christendom, Vol. III',
               'Edition: 4th ed., 1889 (copyright expired)',
               'Latin original with an abridged English version'],
    'url': 'https://www.ccel.org/ccel/schaff/creeds3.iv.xvi.html',
}

# ── 본문 끝 출처 줄의 괄호 안 ─────────────────────────────────────────────
# `db_book_attrib.py` 가 이것으로 「— 저자, "제목" (판본). Public domain.」을
# 짓는다. 소개문의 `▸ 출처` 블록과 **같은 자리에서 나온다** — 두 곳에 적으면
# 갈라진다(2026-08-22 정책, CLAUDE.md §0-1b 「저작권 표시 — 세 자리」).
#
# ★ 판본을 아는 책은 **판본**을, 모르면 그 저작의 연대를 적는다. 번역서는
#   번역자를 적는다 — 어느 번역을 읽고 있는지가 독자에게 실제로 중요하다.
EDITIONS = {
    'AUGUSTINE_CONF':     'tr. E. B. Pusey',
    'BOUNDS_PTP':         'Marshall Brothers, 12th ed.',
    'BUNYAN_GRACE':       'Religious Tract Society, 1905',
    'BUNYAN_PP':          '1678 · 1684',
    'CLEMENT_1ST':        'tr. J. B. Lightfoot, 1891',
    'DIDACHE':            'tr. J. B. Lightfoot, 1891',
    'GIRDLESTONE_OTS':    '2nd ed., Longmans, Green, and Co., 1897',
    'DIOGNETUS':          'tr. J. B. Lightfoot, 1891',
    'EDERSHEIM_JSL':      '1876',
    'EDERSHEIM_LT':       '1883',
    'EDERSHEIM_TMP':      '1874',
    'EDWARDS_SERMONS':    'CCEL edition',
    'FINNEY_SERMONS':     '1836',
    'HERMAS_SHEPHERD':    'tr. J. B. Lightfoot, 1891',
    'IGNATIUS_LETTERS':   'tr. J. B. Lightfoot, 1891',
    'KEMPIS_IOC':         'tr. William Benham, 1874',
    'LAWRENCE_PPG':       'Revell, 1895',
    'LAW_SCDHL':          '1729',
    'LUTHER_FOC':         'tr. R. S. Grignon',
    'MACLAREN_DAVID':     '1880',
    'MEYER_ODH':          '1898',
    'MEYER_MOSES':        'Morgan & Scott, London, 1909 (Seventh Impression)'
                          ' · Fleming H. Revell, New York',
    'BELGIC_CONF':        'Schaff, Creeds of Christendom III, 1889',
    'DORT_CANONS':        'Schaff, Creeds of Christendom III, 1889',
    'WESTMINSTER_CONF':   'Schaff, Creeds of Christendom III, 1889',
    'MILLER_CYA':         '1888',
    'MULLER_ATP':         '1895',
    'MURRAY_AIC':         'Revell',
    'PASCAL_PENSEES':     'tr. W. F. Trotter',
    'POLYCARP_PHIL':      'tr. J. B. Lightfoot, 1891',
    'SHELDON_IHS':        '1897',
    'SMITH_CSHL':         'CCEL edition',
    'SPURGEON_AOG':       '1886',
    'SPURGEON_ME':        '1865',
    'SPURGEON_SERMONS':   'preached from 1855',
    'SPURGEON_SW':        '1895',
    'SPURGEON_TOD':       '1885',
    'VANDYKE_OWM':        '1895',
    'WESLEY_SERMONS':     '1771',
    'WHITEFIELD_SERMONS': '1770',
}
