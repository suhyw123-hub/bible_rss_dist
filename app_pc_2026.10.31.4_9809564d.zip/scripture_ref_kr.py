"""
scripture_ref_kr.py — 한국어 성경 구절 참조 → verse_id 해석 (런타임 유틸)
------------------------------------------------------------------------
"창 12:8", "창 32:22-31", "출 19:1-2" 같은 한국어 참조를 bible_index 의 verse_id 로 변환.
책 약명(창/출/마/행…)은 book_names(lang_code='KO').short_name 에서 매핑.
bible_index.bcode 는 정수(book_names.book_code 와 동일, 1=창세기).

resolve(conn, ref) → (start_vid, end_vid) | (None, None)
  - 범위("-"): 같은 장 "12:1-5" 또는 교차 장 "32:31"→다음 표기. 시작/끝 verse_id.
  - 끝 미지정이면 end=start.
한국어 개신교 약명은 선행 숫자가 없으므로(삼상/왕상 등 2글자) book 은 [가-힣]+ 로 매칭.
"""
import re

# 책약명 + 장:절 [- (장:)절]
_RE = re.compile(r'\s*([가-힣]+)\s*(\d+)\s*[:：]\s*(\d+)'
                 r'(?:\s*[-~]\s*(?:(\d+)\s*[:：]\s*)?(\d+))?')
# 절 없이 장만(또는 장 범위): "출 15-17" · 꼬리 「장/편」 허용("열왕기하 4장")
_RE_CH = re.compile(r'\s*([가-힣]+)\s*(\d+)(?:\s*[-~]\s*(\d+))?\s*(?:장|편)?\s*$')


def book_map_ko(conn):
    """KO 약명·정식명 → book_code(int) 매핑.

    ★ **정식명도 싣는다** (2026-08-23) — 도서 각주가 「시편 94:12」처럼 정식명을
      쓰는데 약명만 싣고 있어 전부 `(None, None)` 이었다(켐피스 각주 184개).
    ⚠ 넓히기 전에 **겹치는 이름이 하나도 없음을 실측**했다. 어떤 책의 정식명이
      다른 책의 약명이었다면 조용히 딴 책으로 갔을 것이다
      (`book_footnote.py --selftest` 가 그 겹침을 계속 감시한다).
    ⚠ 약명을 **나중에** 넣어 혹시 생길 겹침에서 약명이 이긴다(옛 동작 보존).
    """
    rows = conn.execute(
        "SELECT book_code, short_name, full_name FROM book_names "
        "WHERE lang_code='KO'").fetchall()
    bm = {fn: bc for bc, _sn, fn in rows if fn}
    bm.update({sn: bc for bc, sn, _fn in rows if sn})
    return bm


def _vid(conn, bcode, ch, vs):
    r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                     (bcode, ch, vs)).fetchone()
    return r[0] if r else None


def resolve(conn, ref, book_map=None):
    """한국어 참조 → (start_vid, end_vid). 실패 시 (None, None)."""
    if not ref:
        return (None, None)
    bm = book_map if book_map is not None else book_map_ko(conn)
    m = _RE.match(ref)
    if m:
        book, ch, vs, ech, evs = m.group(1), int(m.group(2)), int(m.group(3)), m.group(4), m.group(5)
        bc = bm.get(book)
        if not bc:
            return (None, None)
        start = _vid(conn, bc, ch, vs)
        if start is None:
            return (None, None)
        end = start
        if evs:
            ec = int(ech) if ech else ch
            e = _vid(conn, bc, ec, int(evs))
            if e:
                end = e
        return (start, end)
    # 절 없이 장(또는 장 범위): "출 15-17" → 시작 장 1절 ~ 끝 장 마지막 절
    mc = _RE_CH.match(ref)
    if mc:
        book, ch, ech = mc.group(1), int(mc.group(2)), mc.group(3)
        bc = bm.get(book)
        if not bc:
            return (None, None)
        start = _vid(conn, bc, ch, 1)
        if start is None:
            return (None, None)
        ec = int(ech) if ech else ch
        last = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
                            "ORDER BY verse DESC LIMIT 1", (bc, ec)).fetchone()
        return (start, last[0] if last else start)
    return (None, None)
