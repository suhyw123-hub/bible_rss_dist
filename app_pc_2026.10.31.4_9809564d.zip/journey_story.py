"""
journey_story.py — 여정 정류장 스토리 슬라이딩 패널 (믿음의 발자취 / 엔티티 여정 탭 공통)
-----------------------------------------------------------------------------------
정류장 핀 클릭 시 지도 좌상단에 오버레이 카드로 뜬다(place — 지도 불변). 내용:
  · 헤더 한 줄: 인물 · 본문ref + [▲앞5][▼뒤5] + ✕
  · 본문 Text 하나에 ROUTE_STOP_DESC(첫 문단, 공란이면 생략) + 구절들 결합
  · 구절 약명 클릭 = P2 설명문 점프 (on_verse_jump)

show_stop(stop_id, scripture_ref, person_name) 로 갱신. PanedWindow.add/forget 은 호출자가.
"""
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 나열하면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import i18n
import tkinter as tk
from tkinter import ttk

import scripture_ref_kr
import bidi
import verse_ref                # 약명 형식·본문 시작선 (font.md §22 2단계)

_VER = {'KO': 'KRV', 'EN': 'BSB', 'ZH': 'CUVS', 'JA': 'JLV'}
_HARD_MAX = 80   # 렌더 상한(±확장 포함)



class JourneyStorySlide(tk.Frame):
    def __init__(self, parent, db_path, lang_getter=None,
                 on_close=None, on_verse_jump=None, on_sibling=None):
        super().__init__(parent, bg='white')
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_close = on_close
        self.on_verse_jump = on_verse_jump
        self.on_sibling = on_sibling   # 같은 장소 복수 정류장 전환 콜백
        self._vid = None

        # ★ 오버레이 개편 (2026-08-18 사용자 지시) — 이 패널은 이제 지도 위
        #   **오른쪽 상단에 place() 로 뜨는 카드**다. 지도를 밀지 않는다.
        #   높이는 내용을 따라가고(±5절 확장 시 아래로 펼쳐짐), 폭은
        #   pilgrimage_view 가 다국어 글꼴 실측으로 정해 넘긴다.
        #   [✍ 묵상→] 단추는 폐기 — 구절 약명 클릭이 그 일을 한다.
        # ★ 색·글꼴 표준 (2026-08-18 사용자 「폰트·배경색 자동으로 표준」) —
        #   색은 ui_theme 역할에서 읽고(테마 추종), 글꼴 이름은 적지 않는다
        #   (font.md §36). 구절 본문은 아래에서 theme_font 「bible」 등록.
        try:
            import ui_theme
            _C = ui_theme.C
        except Exception:
            _C = lambda r: {'dark_bg': '#5B2C6F', 'fg_on_dark': 'white',
                            'panel_alt': '#EFEAF5', 'panel': '#FBF7FF',
                            'bg': 'white', 'fg': '#2C3E50',
                            'border': '#B4BAC1'}.get(r, 'white')
        self._C = _C
        # ★ 헤더 한 줄에 다 담는다 (2026-08-18 사용자 재배치):
        #   「아브라함 · 창 12:1」 (여백) [▲앞5][▼뒤5] ✕
        #   제목 줄(「본문」 라벨 + 버튼 줄)은 없앴다 — 설명문과 본문을 한
        #   Text 에 결합해 높이를 아꼈다(아래 _render_verses).
        hdr = tk.Frame(self, bg=_C('dark_bg')); hdr.pack(fill='x')
        self._hdr_var = tk.StringVar(value='')
        tk.Label(hdr, textvariable=self._hdr_var, bg=_C('dark_bg'),
                 fg=_C('fg_on_dark'), anchor='w',
                 font=('', 10, 'bold')).pack(side='left', fill='x',
                                             expand=True, padx=8, pady=4)
        tk.Button(hdr, text='✕', bg=_C('dark_bg'), fg=_C('fg_on_dark'), bd=0,
                  cursor='hand2', font=('', 11),
                  command=self._close).pack(side='right', padx=6)
        tk.Button(hdr, text=i18n.t('JS_NEXT5', '▼ 뒤 5절'), font=('', 8),
                  bd=0, bg=_C('dark_bg'), fg=_C('fg_on_dark'), cursor='hand2',
                  command=self._expand_after).pack(side='right', padx=2)
        tk.Button(hdr, text=i18n.t('JS_PREV5', '▲ 앞 5절'), font=('', 8),
                  bd=0, bg=_C('dark_bg'), fg=_C('fg_on_dark'), cursor='hand2',
                  command=self._expand_before).pack(side='right',
                                                    padx=(16, 2))

        # 같은 장소 복수 정류장(벧엘 왕복 등) 전환 칩 — 2개 이상일 때만 표시
        self._sib_frame = tk.Frame(self, bg=_C('panel_alt'))

        self._desc_text = ''          # 여정 맥락 — 본문 Text 첫 문단으로 결합
        bot = tk.Frame(self, bg=_C('bg')); bot.pack(fill='both', expand=True)
        body = tk.Frame(bot, bg=_C('bg')); body.pack(fill='both', expand=True, padx=2, pady=2)
        self._txt = tk.Text(body, wrap='word', bg=_C('bg'),
                            relief='flat', padx=8, pady=6, height=6, cursor='arrow')
        # ★ 성경 구절은 **어디에 있든 「성경」 역할**이다 (font.md §22).
        #   화면마다 크기가 달라 「같은 구절인데 다르게 느껴진다」던 것을 묶는다.
        try:
            import theme_font
            theme_font.register(self._txt, self.db_path, 'bible')
        except Exception:
            pass
        sb = ttk.Scrollbar(body, command=self._txt.yview)
        self._txt.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y'); self._txt.pack(side='left', fill='both', expand=True)
        # 약명은 **클릭 = P2 설명문**(2026-08-18) — 파란색·손가락 커서
        self._txt.tag_configure('vn', foreground='#1A5276',
                                font=('', 9, 'bold'))
        self._txt.tag_bind('vn', '<Enter>',
                           lambda _e: self._txt.config(cursor='hand2'))
        self._txt.tag_bind('vn', '<Leave>',
                           lambda _e: self._txt.config(cursor='arrow'))
        # ★ 이어지는 줄을 본문 시작선에 (P1 본문과 같은 규칙 · 2026-08-14 표준화)
        # ⚠ 실제 들여쓰기는 그릴 때 `verse_ref.width_hint(범위)` 가 정한다.
        self._txt.tag_configure('body', lmargin1=0)
        self._txt.tag_configure('exp', foreground='#9AA0A6')   # ±확장 구절(흐리게)
        # 여정 맥락 설명 — 본문과 결합된 첫 문단(딸림글 서식: 9pt·흐린 색)
        self._txt.tag_configure('desc', font=('', 9), foreground='#5D6D7E',
                                lmargin1=0, lmargin2=0)
        self._txt.config(state='disabled')
        self._start_vid = None; self._end_vid = None
        self._exp_before = 0; self._exp_after = 0
        self.configure(bg=_C('bg'))

        # ★ 리사이즈 그립 — 우하단 ◢ 를 끌면 오른쪽/아래로 커진다
        #   (2026-08-18 사용자). 적용·클램프·직전값 저장은 pilgrimage 의
        #   `on_resize(w, h)` 가 맡는다.
        self.on_resize = None
        self._grip = tk.Label(self, text='◢', bg=_C('bg'), fg=_C('border'),
                              cursor='size_nw_se', font=('', 9))
        self._grip.place(relx=1.0, rely=1.0, anchor='se')
        self._grip.bind('<B1-Motion>', self._on_grip)

    def _on_grip(self, ev):
        if callable(self.on_resize):
            self.on_resize(ev.x_root - self.winfo_rootx(),
                           ev.y_root - self.winfo_rooty())

    def _close(self):
        if self.on_close:
            self.on_close()

    _max_px = 520          # 패널 최대 높이(지도 안) — pilgrimage 가 갱신

    def set_max_height(self, px):
        self._max_px = max(240, int(px))

    def _lang(self):
        return (self.lang_getter() or 'KO').upper()

    def show_stop(self, stop_id, scripture_ref, person_name, siblings=None):
        lang = self._lang()
        self._hdr_var.set(f'{person_name} · {scripture_ref}')
        # 같은 장소 복수 정류장 칩(벧엘 왕복 등)
        for w in self._sib_frame.winfo_children():
            w.destroy()
        sibs = siblings or []
        if len(sibs) > 1 and self.on_sibling:
            self._sib_frame.pack(fill='x', after=self.winfo_children()[0])
            _C = self._C
            tk.Label(self._sib_frame, text=i18n.t('JS_EVENTS','이 장소의 사건:'),
                     bg=_C('panel_alt'), fg=_C('fg'),
                     font=('', 8)).pack(side='left', padx=(4, 2))
            for s in sibs:
                on = (s['stop_id'] == stop_id)
                tk.Button(self._sib_frame, text=s['ref'], font=('', 8),
                          bd=1, relief='solid', cursor='hand2',
                          bg=_C('dark_bg') if on else _C('panel'),
                          fg=_C('fg_on_dark') if on else _C('fg'),
                          command=lambda x=s: self.on_sibling(x['stop_id'], x['ref'],
                                                              person_name, siblings=sibs)
                          ).pack(side='left', padx=1)
        else:
            self._sib_frame.pack_forget()
        conn = appdb.connect(self.db_path)
        try:
            # ROUTE_STOP_DESC (여정 맥락)
            desc = None
            if stop_id:
                r = conn.execute(
                    "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND "
                    "text_type='ROUTE_STOP_DESC' AND lang_code=? AND "
                    "COALESCE(record_status,'LIVE')='LIVE'", (stop_id, lang)).fetchone()
                if not r:
                    r = conn.execute(
                        "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND "
                        "text_type='ROUTE_STOP_DESC' AND lang_code='EN' AND "
                        "COALESCE(record_status,'LIVE')='LIVE'", (stop_id,)).fetchone()
                desc = r[0].strip() if r and r[0] else None
            start, end = scripture_ref_kr.resolve(conn, scripture_ref)
            self._vid = start
            self._start_vid = start
            self._end_vid = end or start   # ±확장은 verse_id 기준(verse_id ≈ 1씩 증가)
        except Exception as e:
            print(f'[journey_story] {e}')
            desc = None
            self._start_vid = self._end_vid = None
        finally:
            conn.close()

        self._desc_text = desc or ''
        self._exp_before = 0; self._exp_after = 0
        self._render_verses()

    def _render_verses(self):
        self._txt.config(state='normal'); self._txt.delete('1.0', 'end')
        # ★ 설명문(ROUTE_STOP_DESC)을 본문 첫 문단으로 **결합** (2026-08-18
        #   사용자 「설명문과 본문구절 텍스트를 결합한 효과」 — 별도 Label·
        #   프레임을 없애 높이를 아낀다). 서식은 표준 딸림글: 기본 글꼴
        #   9pt, 색은 구별되게 흐린 회색 — Text wrap 이 폭을 따라간다.
        n_desc = 0
        if self._desc_text:
            self._txt.insert('end', self._desc_text + '\n\n', ('desc',))
            n_desc = 1
        if self._start_vid is None:
            self._txt.insert('end', i18n.t('JS_NO_BODY', '(본문을 찾지 못했습니다)'))
            self._txt.config(state='disabled'); return
        lo = self._start_vid - self._exp_before
        hi = self._end_vid + self._exp_after
        lang = self._lang()
        import verse_tier   # 단일 소스(2026-07-30) — 없을 때만 언어별 기본값
        ver = verse_tier.get_version(self.db_path, None) or _VER.get(lang, 'KRV')
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT bi.verse_id, bi.chapter, bi.verse, bc.verse_text, "
                "       bn.short_name "
                "FROM bible_index bi LEFT JOIN bible_content bc "
                "  ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                "LEFT JOIN book_names bn ON bn.book_code=bi.bcode "
                "  AND UPPER(bn.lang_code)=? "
                "WHERE " + _vr.between_sql('bi.verse_id')
                + " ORDER BY bi.sort_order",
                [ver, lang] + _vr.between_args(lo, hi)).fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        # ★ **약명을 절마다 표시하고, 누르면 P2 설명문으로** (2026-08-18
        #   사용자 지시 — 「구절약명을 표시하라. 클릭하면 p2 탭의 설명문」.
        #   그래서 옛 [✍ 묵상→] 단추가 필요 없어졌다).
        import tkinter.font as _tkfont
        f = _tkfont.Font(font=('', 9, 'bold'))   # 약명 폭 실측(글꼴 이름 미지정)
        maxw = max((f.measure('%s%d:%d' % ((sn or ''), ch, vs))
                    for _v, ch, vs, _t, sn in rows[:_HARD_MAX]), default=40)
        self._txt.tag_configure('body', lmargin1=0, lmargin2=maxw + 8)
        for vid, ch, vs, vt, sn in rows[:_HARD_MAX]:
            core = self._start_vid <= vid <= self._end_vid
            tag = 'jv%d' % vid
            self._txt.insert('end', '%s%d:%d ' % ((sn or ''), ch, vs),
                             ('vn', tag) if core else ('vn', tag, 'exp'))
            self._txt.tag_bind(tag, '<Button-1>',
                               lambda _e, v=vid: (callable(self.on_verse_jump)
                                                  and self.on_verse_jump(v)))
            bidi.insert(self._txt,
                        (vt or i18n.t('MSG_NO_BODY', '(본문 없음)')) + '\n',
                        () if core else ('exp',))
        # ★ 높이는 내용을 따라 **아래로** 자란다 — ±5절을 누르면 패널이
        #   펼쳐진다(사용자 「상단 패널이 아래로 펼쳐지면 된다」).
        #   상한은 지도 높이(set_max_height) — 넘으면 안쪽 스크롤.
        try:
            n = len(rows[:_HARD_MAX])
            # 설명문이 본문에 결합됐으므로 그 줄수도 함께 센다(대략 40자/줄)
            desc_lines = (len(self._desc_text) // 40 + 2) if self._desc_text else 0
            est_lines = max(4, int(n * 2.1) + desc_lines)
            line_px = _tkfont.Font(font=self._txt.cget('font')).metrics(
                'linespace') or 18
            other_px = 60             # 헤더 한 줄 + 여백 어림(설명문·단추 줄 제거됨)
            cap = max(4, (self._max_px - other_px) // line_px)
            self._txt.config(height=min(est_lines, cap))
        except Exception:
            pass
        self._txt.config(state='disabled')

    def _expand_before(self):
        if self._start_vid is not None and self._exp_before < 60:
            self._exp_before += 5; self._render_verses()
            self._txt.see('1.0')

    def _expand_after(self):
        if self._start_vid is not None and self._exp_after < 60:
            self._exp_after += 5; self._render_verses()
            self._txt.see('end')
