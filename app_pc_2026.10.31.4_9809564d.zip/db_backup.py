# -*- coding: utf-8 -*-
"""DB 통째 백업 — **멈춘 순간의 사진**을 떠서 압축해 내보낸다.

★★★ 2026-09-12 사용자 「구글드라이버에 무료 10기가 이상이 있는데 여기에
  **db 통째로 백업**하려면 무엇을 해야 하는가」.
  ✅ 실측 — `bible_master.db` **1,400 MB** · `user_data.db` 7.5 MB ·
    gzip 압축률 **35%** → 합쳐서 약 **500 MB**. 15GB 에 서른 벌은 들어간다.

⚠⚠⚠ **그냥 복사하면 안 된다.** SQLite 는 `.db` + `.db-wal` + `.db-shm` **세
  파일이 한 몸**이다(실측 `bible_master.db-wal` 이 8MB 있다). 앱이 쓰는 도중에
  파일을 하나씩 복사하면 **반쪽짜리**가 되고, `.db` 는 새것인데 `.db-wal` 이
  옛것이면 **복구할 때 깨진다.**
  ⇒ **`VACUUM INTO`** 를 쓴다 — SQLite 가 스스로 만드는 **온전한 한 파일**이라
    WAL 이 합쳐지고 조각까지 정리된다.

⚠⚠⚠ **DB 폴더를 구글 드라이브 동기화 폴더에 두지 말 것.** 드라이브는 파일을
  하나씩 따로 올리므로 위와 같은 이유로 깨진다. 그리고 드라이브가 파일을
  잠그면 **앱이 DB 를 못 쓴다**. **여기서 만든 압축 파일만** 그 폴더에 둔다.

⚠ **뜬 사진을 반드시 확인한다**(`--no-verify` 로만 끌 수 있다) —
  **안 열어 본 백업은 백업이 아니다.** `quick_check` 과 표 수를 견준다.

사용:
    python db_backup.py --selftest
    python db_backup.py --plan                     무엇을 할지만 보인다(안 건드린다)
    python db_backup.py                            기본 자리(backup/)에 뜬다
    python db_backup.py --to "G:\\내 드라이브\\Hagah백업"
    python db_backup.py --keep 5                   최근 다섯 벌만 남긴다
    python db_backup.py --drill                    **복구 훈련** — 풀어서 읽어 본다
    python db_backup.py --drill --full             느리지만 꼼꼼히(integrity_check)
"""
import gzip
import os
import shutil
import sqlite3
import sys
import time
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))

#: 뜰 것 — **`user_data.db` 가 진짜 중요한 것**이다(§C-2). 배포로 덮이는
#: `bible_master.db` 와 달리 **다시 만들 수 없는 개인 자료**다.
DBS = ('bible_master.db', 'user_data.db')

#: 기본으로 내보낼 자리 — ⚠ **같은 디스크라 디스크가 죽으면 함께 죽는다.**
#:   구글 드라이브 폴더가 생기면 `--to` 로 바꾼다.
DEFAULT_TO = os.path.join(HERE, 'backup')

#: 남길 벌 수 — 오래된 것부터 지운다
DEFAULT_KEEP = 5

#: 여유 공간이 이만큼은 있어야 시작한다(원본 + 압축본)
ROOM = 1.6


def _mb(n):
    return n / 1048576.0


def _fmt(n):
    return '%.1f MB' % _mb(n)


def dbs_here(names=DBS):
    """있는 DB 만 → [(이름, 크기, WAL 크기)]."""
    out = []
    for nm in names:
        p = os.path.join(HERE, nm)
        if not os.path.exists(p):
            continue
        w = p + '-wal'
        out.append((nm, os.path.getsize(p),
                    os.path.getsize(w) if os.path.exists(w) else 0))
    return out


def free_space(path):
    """그 자리에 남은 바이트."""
    try:
        return shutil.disk_usage(path).free
    except Exception:
        return 0


def plan(to=DEFAULT_TO, names=DBS):
    """무엇을 할지 → dict. **아무것도 안 건드린다.**"""
    got = dbs_here(names)
    need = sum(s for _n, s, _w in got)
    return {'dbs': got, 'need': need,
            'guess_gz': int(need * 0.35),      # 실측 압축률
            'to': to, 'free': free_space(HERE),
            'ok': free_space(HERE) > need * ROOM}


#: 압축이 끝나기 전의 **원본 사진**이 갖는 꼬리표.
#: ⚠⚠⚠ **사람이 보는 이름으로 두면 안 된다**(2026-09-12 실측으로 당했다) —
#:   압축하는 31초 동안 폴더에 `.db`(1,371MB)와 `.db.gz`(388MB)가 **둘 다**
#:   있었고, 사용자가 그때 폴더를 열어 **압축 안 된 쪽을 구글 드라이브로
#:   복사**했다(1.4GB · 7분). **보이면 헷갈린다.**
TMP = '.snap.tmp'


def snapshot(src, dst):
    """**멈춘 순간의 사진**을 뜬다(`VACUUM INTO`) → 크기.

    ⚠ `VACUUM INTO` 는 **대상 파일이 이미 있으면 거부**한다 — 지우고 부른다.
    ⚠ 앱이 쓰기 트랜잭션을 열어 두면 `database is locked` 가 난다(§219차) —
      **까닭을 그대로 올린다**(조용히 반쪽을 뜨지 않는다).
    """
    if os.path.exists(dst):
        os.remove(dst)
    conn = sqlite3.connect(src, timeout=30)
    try:
        conn.execute('PRAGMA busy_timeout=30000')
        conn.execute("VACUUM INTO ?", (dst,))
    finally:
        conn.close()
    return os.path.getsize(dst)


def verify(snap, src=None):
    """뜬 사진이 **온전한가** → (참/거짓, 할 말).

    ★★★ **안 열어 본 백업은 백업이 아니다.** 두 가지를 잰다 —
      ⓐ `quick_check` ⓑ **표 수가 원본과 같은가**(표가 통째로 빠지는 자리).
    """
    try:
        c = sqlite3.connect(snap)
        r = c.execute('PRAGMA quick_check').fetchone()
        if not r or str(r[0]).lower() != 'ok':
            c.close()
            return False, 'quick_check 실패: %s' % (r[0] if r else '?')
        n = c.execute("SELECT COUNT(*) FROM sqlite_master"
                      " WHERE type='table'").fetchone()[0]
        c.close()
    except Exception as e:
        return False, '못 열었다: %r' % e
    if src and os.path.exists(src):
        try:
            c2 = sqlite3.connect('file:%s?mode=ro' % src.replace('\\', '/'),
                                 uri=True, timeout=20)
            n2 = c2.execute("SELECT COUNT(*) FROM sqlite_master"
                            " WHERE type='table'").fetchone()[0]
            c2.close()
            if n != n2:
                return False, '표 수가 다르다 — 사진 %d · 원본 %d' % (n, n2)
        except Exception:
            pass            # 원본을 못 읽어도 사진 자체는 온전하다
    return True, '표 %d개 · quick_check OK' % n


def squeeze(path, level=6, keep_raw=False):
    """압축한다 → (압축 파일, 크기). 끝나면 원본 사진을 지운다."""
    gz = path + '.gz'
    with open(path, 'rb') as f, gzip.open(gz, 'wb', compresslevel=level) as g:
        shutil.copyfileobj(f, g, length=1024 * 1024)
    if not keep_raw:
        os.remove(path)
    return gz, os.path.getsize(gz)


def prune(to, name, keep=DEFAULT_KEEP):
    """오래된 벌을 지운다 → 지운 파일 목록.

    ⚠ **이름이 그 DB 의 것인 파일만** 본다 — 남의 백업을 지우지 않는다.
    """
    if keep is None or keep <= 0:
        return []
    stem = os.path.splitext(name)[0] + '_'
    got = sorted((f for f in os.listdir(to)
                  if f.startswith(stem) and f.endswith('.db.gz')))
    gone = got[:-int(keep)] if len(got) > int(keep) else []
    for f in gone:
        os.remove(os.path.join(to, f))
    return gone


#: 복구 훈련에서 **실제로 읽어 보는 표** — 앱이 늘 읽는 자리로 골랐다.
#: ⚠ 「열린다」로는 모자란다 — **앱이 쓰는 조회가 도는가**를 봐야 한다.
#: ⚠⚠ **DB 마다 표가 다르다**(2026-09-12 실측으로 당했다) — `bible_master` 의
#:   잣대를 `user_data` 에 대니 **일곱 개가 다 「표가 없다」**로 나왔다. 백업은
#:   멀쩡한데 검사가 틀린 것이다. **DB 마다 제 잣대를 쓴다.**
DRILL_SQL = {
    'bible_master': (
        ('구절 좌표', "SELECT COUNT(*) FROM bible_index"),
        ('성경 본문', "SELECT COUNT(*) FROM bible_content"),
        ('연결', "SELECT COUNT(*) FROM sys_link_asset"),
        ('설명문', "SELECT COUNT(*) FROM sys_text_asset"),
        ('영상', "SELECT COUNT(*) FROM sys_media_asset"),
        ('곡', "SELECT COUNT(*) FROM sys_song"),
        ('창1:1 본문',
         "SELECT COUNT(*) FROM bible_content c JOIN bible_index i"
         " ON i.verse_id=c.verse_id WHERE i.bcode=1 AND i.chapter=1"
         "   AND i.verse=1"),
    ),
    # ★ **개인 자료** — 다시 만들 수 없는 것들이다(§C-2)
    'user_data': (
        ('내 연결', "SELECT COUNT(*) FROM user_link_asset"),
        ('내 글', "SELECT COUNT(*) FROM user_text_asset"),
        ('내 플랜', "SELECT COUNT(*) FROM user_plan_schedule"),
        ('내 등록', "SELECT COUNT(*) FROM user_plan_enrollment"),
        ('즐겨찾기', "SELECT COUNT(*) FROM user_favorite"),
        ('내 자료', "SELECT COUNT(*) FROM user_ref_asset"),
        ('설정', "SELECT COUNT(*) FROM user_config"),
    ),
}


def drill_sql(name):
    """그 DB 의 잣대 → 없으면 **표 수만** 센다(조용히 넘기지 않는다)."""
    stem = os.path.basename(name).split('_2')[0]
    return DRILL_SQL.get(stem) or (
        ('표 수', "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"),)


def restore_drill(gz, work=None, full=False, log=print):
    """**복구 훈련** — 압축을 풀어 실제로 읽어 보고 원본과 견준다 → dict.

    ★★★ **안 풀어 본 백업은 백업이 아니다.** `verify` 는 「사진이 온전한가」만
      보고, 이것은 **「앱이 실제로 읽는가」**를 본다.
    ⚠ **원본은 절대 안 건드린다** — 임시 폴더에 풀고 끝나면 지운다.
    ⚠ 끝에 **자국이 남지 않았는가**를 스스로 잰다.
    """
    import tempfile
    work = work or tempfile.mkdtemp(prefix='zzdrill_')
    made = not os.path.isdir(work) or True
    os.makedirs(work, exist_ok=True)
    nm = os.path.basename(gz)[:-3]                 # ….db
    out = {'gz': gz, 'ok': False, 'rows': {}, 'diff': [], 'sec': 0}
    t0 = time.time()
    dst = os.path.join(work, nm)
    try:
        log('  풀는 중 — %s (%s)' % (nm, _fmt(os.path.getsize(gz))))
        with gzip.open(gz, 'rb') as g, open(dst, 'wb') as f:
            shutil.copyfileobj(g, f, length=8 << 20)
        log('    풀었다 — %s' % _fmt(os.path.getsize(dst)))
        c = sqlite3.connect('file:%s?mode=ro' % dst.replace(os.sep, '/'),
                            uri=True)
        r = c.execute('PRAGMA %s' % ('integrity_check' if full
                                     else 'quick_check')).fetchone()
        log('    %s — %s' % ('integrity_check' if full else 'quick_check',
                             r[0] if r else '?'))
        if not r or str(r[0]).lower() != 'ok':
            c.close()
            return out
        # ★ 앱이 쓰는 조회를 실제로 돌린다
        live = os.path.join(HERE, nm.split('_2')[0] + '.db')
        lc = None
        if os.path.exists(live):
            try:
                lc = sqlite3.connect('file:%s?mode=ro' % live.replace(os.sep, '/'),
                                     uri=True, timeout=20)
            except Exception:
                lc = None
        for lbl, q in drill_sql(nm):
            try:
                n = c.execute(q).fetchone()[0]
            except Exception as e:
                log('    ✗ %s — %r' % (lbl, e))
                out['diff'].append((lbl, None, None))
                continue
            out['rows'][lbl] = n
            m = None
            if lc is not None:
                try:
                    m = lc.execute(q).fetchone()[0]
                except Exception:
                    m = None
            mark = ''
            if m is not None and m != n:
                out['diff'].append((lbl, n, m))
                mark = '   ⚠ 지금 DB 는 %s' % '{:,}'.format(m)
            log('    %-12s %12s%s' % (lbl, '{:,}'.format(n), mark))
        c.close()
        if lc is not None:
            lc.close()
        out['ok'] = True
    finally:
        try:
            os.remove(dst)
        except Exception:
            pass
        if made:
            shutil.rmtree(work, ignore_errors=True)
        out['left'] = os.path.exists(work)
        out['sec'] = time.time() - t0
    return out


def code_backup(to, keep=DEFAULT_KEEP, log=print):
    """**코드까지 한 파일로** 뜬다(`git bundle`) → dict.

    ★★★ 2026-09-12 사용자 「구글드라이브에 **코드자료까지 백업**하도록 하자」.
      ⚠⚠ **DB 백업과 코드 백업은 다른 것을 지킨다** — `db_backup` 이 뜨는 것은
        `.db` 둘뿐이고, 코드·원문 자료는 **한 줄도 안 들어간다**.
        실측 git 이 추적하는 것 **8,235파일 · 865 MB**(PDF 3,520개 429MB ·
        txt 668개 277MB · json 3,380개 99MB · **파이썬 425개 13MB**).
      ⇒ 디스크가 죽으면 **콘텐츠는 살고 앱이 없거나, 앱은 살고 콘텐츠가 없다.**

    ★★★ **왜 `git bundle` 인가** — 압축 묶음(zip)이 아니라 **저장소 통째**다.
      ⓐ **모든 이력**이 들어간다(언제 무엇을 왜 고쳤나) — zip 은 지금 모습뿐이다
      ⓑ 되살릴 때 `git clone <파일> <폴더>` **한 줄**이면 된다
      ⓒ 한 파일이라 드라이브에 올리기 쉽다
    ⚠ **추적 안 하는 것은 안 들어간다** — `.gitignore` 에 있는 DB·백업이 그렇다.
      그것이 옳다(DB 는 위쪽 문이 따로 뜬다).
    ⚠ 손댄 것이 남아 있으면 **커밋 안 된 것은 안 들어간다** — 알려 준다.
    """
    import subprocess
    if not os.path.isdir(os.path.join(HERE, '.git')):
        log('  git 저장소가 아닙니다 — 코드 백업을 건너뜁니다.')
        return {'file': None, 'err': 'NO_GIT'}
    os.makedirs(to, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M')
    fin = os.path.join(to, 'code_%s.bundle' % stamp)
    # ★★★ **번들은 로컬에서 만들고 그다음에 옮긴다**(2026-09-12 실측으로 당했다).
    #   ⚠⚠⚠ `git bundle create` 를 **구글 드라이브에 직접 쓰면 7시간**이 걸렸다
    #     (실측 25,965초). 같은 번들이 **로컬에서는 2.5초**다 — 2,800배다.
    #     git 은 번들을 만들며 **앞뒤로 오가며 쓰는데**, 드라이브의 가상
    #     파일시스템은 그 쓰기를 하나하나 망으로 보낸다.
    #   ★ 통째로 한 번에 **복사**하는 것은 빠르다(실측 389MB 가 1초).
    tmp = os.path.join(HERE, 'code_%s.bundle%s' % (stamp, TMP))
    # ⚠ 커밋 안 된 것이 있으면 **말한다**(조용히 빠뜨리지 않는다)
    try:
        d = subprocess.run(['git', 'status', '--porcelain'], cwd=HERE,
                           capture_output=True, text=True, timeout=120)
        n_dirty = len([x for x in d.stdout.splitlines() if x.strip()])
        if n_dirty:
            log('  ⚠ 커밋 안 된 것 %d개 — **번들에 안 들어갑니다**' % n_dirty)
    except Exception:
        pass
    log('  코드 — 저장소를 통째로 뜨는 중…')
    try:
        r = subprocess.run(['git', 'bundle', 'create', tmp, '--all'],
                           cwd=HERE, capture_output=True, text=True,
                           timeout=3600)
    except Exception as e:
        log('  ✗ %r' % e)
        return {'file': None, 'err': 'BUNDLE'}
    if r.returncode != 0 or not os.path.exists(tmp):
        log('  ✗ %s' % (r.stderr or '')[-200:])
        return {'file': None, 'err': 'BUNDLE'}
    n = os.path.getsize(tmp)
    # ★★★ **뜬 것을 확인한다** — 안 열어 본 백업은 백업이 아니다
    v = subprocess.run(['git', 'bundle', 'verify', tmp], cwd=HERE,
                       capture_output=True, text=True, timeout=600)
    if v.returncode != 0:
        os.remove(tmp)
        log('  ✗ 번들이 온전하지 않아 지웠습니다 — %s' % (v.stderr or '')[-200:])
        return {'file': None, 'err': 'VERIFY'}
    log('    확인 — git bundle verify OK (%s)' % _fmt(n))
    if os.path.exists(fin):
        os.remove(fin)
    # ★ 로컬에서 다 만든 뒤에 **한 번에** 옮긴다 — 그래야 드라이브가 빠르다
    try:
        shutil.move(tmp, fin)
    except Exception as e:
        # ⚠ 옮기다 실패하면 **로컬 것을 남긴다**(조용히 잃지 않는다)
        log('  ✗ 옮기지 못했습니다 — %r' % e)
        log('    번들은 여기 있습니다: %s' % tmp)
        return {'file': tmp, 'size': n, 'err': 'MOVE'}
    # 오래된 벌 지우기 — **이름이 code_ 인 것만**
    got = sorted(f for f in os.listdir(to)
                 if f.startswith('code_') and f.endswith('.bundle'))
    for f in (got[:-int(keep)] if keep and len(got) > int(keep) else []):
        os.remove(os.path.join(to, f))
        log('    오래된 벌을 지웠습니다 — %s' % f)
    return {'file': fin, 'size': n, 'err': None}


def run(to=DEFAULT_TO, names=DBS, keep=DEFAULT_KEEP, do_verify=True,
        do_gzip=True, do_code=True, log=print):
    """백업 한 바퀴 → 요약 dict."""
    pl = plan(to, names)
    if not pl['dbs']:
        log('백업할 DB 가 없습니다.')
        return {'files': [], 'err': 'NO_DB'}
    if not pl['ok']:
        log('⚠ 자리가 모자랍니다 — 필요 %s · 남은 것 %s'
            % (_fmt(pl['need'] * ROOM), _fmt(pl['free'])))
        return {'files': [], 'err': 'NO_ROOM'}
    os.makedirs(to, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M')
    out = {'files': [], 'raw': 0, 'gz': 0, 'sec': 0, 'err': None}
    t0 = time.time()
    for nm, size, wal in pl['dbs']:
        src = os.path.join(HERE, nm)
        # ★★★ **압축할 것은 임시 이름으로 뜬다** — 다 되기 전에는 백업처럼
        #   보이지 않아야 한다(2026-09-12 실측으로 당했다).
        fin = os.path.join(to, '%s_%s.db' % (os.path.splitext(nm)[0], stamp))
        dst = (fin + TMP) if do_gzip else fin
        log('  %s (%s%s) — 사진 뜨는 중…'
            % (nm, _fmt(size), ' · WAL %s' % _fmt(wal) if wal else ''))
        try:
            n = snapshot(src, dst)
        except Exception as e:
            # ⚠ **조용히 넘기지 않는다** — 앱이 켜져 있으면 여기서 막힌다
            log('  ✗ %s — %r' % (nm, e))
            log('    ⚠ 관리자·사용자 앱이 켜져 있으면 막힙니다. 닫고 다시 하세요.')
            out['err'] = 'LOCKED'
            continue
        out['raw'] += n
        if do_verify:
            ok, why = verify(dst, src)
            log('    확인 — %s' % why)
            if not ok:
                os.remove(dst)
                out['err'] = 'VERIFY'
                log('  ✗ 사진이 온전하지 않아 지웠습니다.')
                continue
        if do_gzip:
            gzp, gn = squeeze(dst)
            # ★ 압축이 **다 끝난 뒤에** 제 이름을 준다
            fgz = fin + '.gz'
            if os.path.exists(fgz):
                os.remove(fgz)
            os.replace(gzp, fgz)
            log('    %s → %s (%.0f%%)' % (_fmt(n), _fmt(gn), 100.0 * gn / n))
            out['files'].append(fgz)
            out['gz'] += gn
        else:
            out['files'].append(dst)
            out['gz'] += n
        for f in prune(to, nm, keep):
            log('    오래된 벌을 지웠습니다 — %s' % f)
    # ★★★ **코드까지 함께 뜬다**(2026-09-12 사용자) — DB 만으로는 못 살린다
    if do_code:
        c = code_backup(to, keep=keep, log=log)
        if c.get('file'):
            out['files'].append(c['file'])
            out['gz'] += c['size']
        elif c.get('err') not in (None, 'NO_GIT'):
            out['err'] = out['err'] or c['err']
    out['sec'] = time.time() - t0
    return out


def selftest():
    ok = [0, 0]

    def t(msg, cond, extra=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', msg,
                              '' if cond else extra))

    import tempfile
    d = tempfile.mkdtemp(prefix='zzbk_')
    src = os.path.join(d, 'zz.db')
    c = sqlite3.connect(src)
    c.execute('PRAGMA journal_mode=wal')
    c.execute('CREATE TABLE a(x INTEGER, s TEXT)')
    c.execute('CREATE TABLE b(y INTEGER)')
    c.executemany('INSERT INTO a VALUES(?,?)',
                  [(i, 'zz' * 200) for i in range(2000)])
    c.commit()
    t('★ WAL 이 실제로 생긴다(그래서 그냥 복사하면 안 된다)',
      os.path.exists(src + '-wal'))

    snap = os.path.join(d, 'snap.db')
    n = snapshot(src, snap)
    t('★★★ **사진이 뜬다**(`VACUUM INTO`)', n > 0 and os.path.exists(snap))
    t('★★★ **WAL 이 합쳐진다** — 사진은 한 파일이다',
      not os.path.exists(snap + '-wal'))
    v, why = verify(snap, src)
    t('★★★ **뜬 사진을 확인한다**(안 열어 본 백업은 백업이 아니다)', v, why)
    c2 = sqlite3.connect(snap)
    t('  ★ 줄이 다 들어 있다',
      c2.execute('SELECT COUNT(*) FROM a').fetchone()[0] == 2000)
    c2.close()

    t('★★ **대상이 있어도 다시 뜬다**(멱등)', snapshot(src, snap) > 0)

    import inspect
    t('★★★ **그냥 복사하지 않는다**(`VACUUM INTO` 를 쓴다)',
      'VACUUM INTO' in inspect.getsource(snapshot)
      and 'copyfile(' not in inspect.getsource(snapshot))

    gzp, gn = squeeze(snap)
    t('★★ 압축하면 준다', 0 < gn < n, (gn, n))
    t('  ★ 압축한 뒤 원본 사진을 지운다', not os.path.exists(snap))
    with gzip.open(gzp, 'rb') as g:
        head = g.read(16)
    t('★★★ **압축을 풀면 다시 SQLite 다**', head.startswith(b'SQLite format 3'))

    # 오래된 벌 지우기
    for i in range(7):
        open(os.path.join(d, 'zz_2026090%d_0000.db.gz' % i), 'w').close()
    open(os.path.join(d, 'other_20260901_0000.db.gz'), 'w').close()
    gone = prune(d, 'zz.db', keep=3)
    left = [f for f in os.listdir(d) if f.startswith('zz_')]
    t('★★ 최근 것만 남긴다', len(left) == 3 and len(gone) == 4, (left, gone))
    t('★★★ **남의 백업은 안 지운다**',
      os.path.exists(os.path.join(d, 'other_20260901_0000.db.gz')))
    t('★ 0 이나 음수면 아무것도 안 지운다', prune(d, 'zz.db', keep=0) == [])

    pl = plan(to=d, names=('zz.db',))
    t('★★ `--plan` 은 **아무것도 안 건드린다**',
      isinstance(pl, dict) and 'need' in pl
      and 'snapshot' not in inspect.getsource(plan))
    t('★★★ **자리가 모자라면 시작도 안 한다**',
      'NO_ROOM' in inspect.getsource(run))
    t('★★ **앱이 켜져 있으면 까닭을 말한다**(조용히 반쪽을 안 뜬다)',
      '앱이 켜져' in inspect.getsource(run))
    t('★★★ **개인 DB 를 함께 뜬다**(다시 만들 수 없는 것)',
      'user_data.db' in DBS)
    # ★★★ 다 되기 전에는 **백업처럼 보이지 않는다**(2026-09-12 실측으로 당했다)
    _rs = inspect.getsource(run)
    t('★★★ **압축할 것은 임시 이름으로 뜬다**(중간에 복사해 가지 못하게)',
      'TMP' in _rs and 'fin + TMP' in _rs)
    t('★★★ **압축이 다 끝난 뒤에 제 이름을 준다**', 'os.replace(gzp, fgz)' in _rs)
    t('  ★ 임시 꼬리표가 `.gz` 로 안 끝난다(오래된 벌 지우기에 안 걸린다)',
      not TMP.endswith('.gz'))
    # ★★★ **복구 훈련** — 안 풀어 본 백업은 백업이 아니다
    gz2, _n2 = squeeze(snapshot(src, os.path.join(d, 'zz2.db'))
                       and os.path.join(d, 'zz2.db'))
    r = restore_drill(gz2, log=lambda *a: None)
    t('★★★ **압축을 풀어 실제로 읽는다**', r['ok'], r)
    t('  ★ 훈련 자국이 안 남는다(임시 폴더를 지운다)', not r.get('left'))
    t('★★★ **원본은 안 건드린다**(읽기 전용으로 연다)',
      'mode=ro' in inspect.getsource(restore_drill)
      and os.path.exists(src))
    t('★★ **앱이 쓰는 조회를 돌려 본다**(열리는 것만으로는 모자라다)',
      all(len(v) >= 5 for v in DRILL_SQL.values()))
    t('★★★ **DB 마다 제 잣대를 쓴다**(bible_master 잣대를 user_data 에 대면 안 된다)',
      drill_sql('bible_master_20260912_0140.db')
      != drill_sql('user_data_20260912_0140.db'))
    t('  ★ 모르는 DB 는 **표 수라도** 센다(조용히 안 넘긴다)',
      len(drill_sql('zz_20260101_0000.db')) == 1)
    # ★★★ **코드까지 뜬다**(2026-09-12) — DB 만으로는 못 살린다
    _cs = inspect.getsource(code_backup)
    t('★★★ **코드는 `git bundle`** — zip 이 아니라 **이력까지** 들어간다',
      "'bundle', 'create'" in _cs and "'--all'" in _cs)
    t('★★★ **뜬 번들을 확인한다**(`git bundle verify`)',
      "'bundle', 'verify'" in _cs)
    t('★★★ **번들은 로컬에서 만들고 그다음에 옮긴다**'
      '(드라이브에 직접 쓰면 7시간 · 로컬은 2.5초)',
      'os.path.join(HERE,' in _cs and 'shutil.move(tmp, fin)' in _cs)
    t('★★ **옮기다 실패하면 로컬 것을 남긴다**(조용히 안 잃는다)',
      "'MOVE'" in _cs)
    t('★★ **커밋 안 된 것이 있으면 말한다**(조용히 안 빠뜨린다)',
      '커밋 안 된 것' in _cs)
    t('★ 오래된 벌은 **`code_` 인 것만** 지운다',
      "startswith('code_')" in _cs)
    t('★★ 한 바퀴에 **코드도 함께** 돈다', 'code_backup(' in inspect.getsource(run))
    c.close()
    shutil.rmtree(d, ignore_errors=True)
    t('  ★ 시험 자국이 안 남는다', not os.path.exists(d))
    print('db_backup selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    to = DEFAULT_TO
    if '--to' in argv:
        to = argv[argv.index('--to') + 1]
    keep = DEFAULT_KEEP
    if '--keep' in argv:
        keep = int(argv[argv.index('--keep') + 1])
    if '--drill' in argv:
        i = argv.index('--drill')
        pick = argv[i + 1] if len(argv) > i + 1 and not argv[i + 1].startswith('-')             else None
        got = ([pick] if pick else
               sorted(os.path.join(to, f) for f in os.listdir(to)
                      if f.endswith('.db.gz')))
        if not got:
            print('훈련할 백업이 없습니다 — %s' % to)
            return 1
        print('복구 훈련 — **원본은 안 건드린다**(임시 폴더에 풀었다 지운다)')
        bad = 0
        for g in got:
            r = restore_drill(g, full=('--full' in argv))
            if not r['ok']:
                bad += 1
                print('  ✗ %s — 못 읽었다' % os.path.basename(g))
            elif r['diff']:
                print('  △ %s — 지금 DB 와 다른 칸 %d개(그동안 자란 것이면 정상)'
                      % (os.path.basename(g), len(r['diff'])))
            else:
                print('  ✅ %s — **앱이 읽는 조회가 다 돈다** (%.0f초)'
                      % (os.path.basename(g), r['sec']))
            if r.get('left'):
                print('    ⚠ 임시 자국이 남았다')
        print('\n훈련한 백업 %d개 · 못 읽은 것 %d개' % (len(got), bad))
        return 1 if bad else 0
    if '--plan' in argv:
        pl = plan(to)
        print('백업할 DB %d개' % len(pl['dbs']))
        for nm, s, w in pl['dbs']:
            print('   %-20s %10s%s'
                  % (nm, _fmt(s), ' · WAL %s' % _fmt(w) if w else ''))
        print('   합계 %s → 압축하면 약 %s (실측 35%%)'
              % (_fmt(pl['need']), _fmt(pl['guess_gz'])))
        print('   내보낼 자리 %s' % pl['to'])
        print('   남은 공간 %s — %s' % (_fmt(pl['free']),
                                    '넉넉합니다' if pl['ok'] else '⚠ 모자랍니다'))
        return 0
    out = run(to, keep=keep, do_verify=('--no-verify' not in argv),
              do_gzip=('--no-gzip' not in argv),
              do_code=('--no-code' not in argv))
    if out.get('err'):
        print('\n⚠ 끝내지 못했습니다 — %s' % out['err'])
        return 1
    print('\n끝 — 파일 %d개 · %s → %s · %.0f초'
          % (len(out['files']), _fmt(out['raw']), _fmt(out['gz']), out['sec']))
    for f in out['files']:
        print('   %s' % f)
    print('\n⚠ 이 폴더를 구글 드라이브에 두십시오 — **DB 폴더 자체는 두지 마십시오.**')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
