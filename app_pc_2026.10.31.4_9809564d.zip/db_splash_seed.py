# -*- coding: utf-8 -*-
"""db_splash_seed.py — **장면 매핑 씨앗** (2026-09-05 신설 · 영구 · 멱등)

★★★ 왜 — 장면 체계(`db_splash_scene`)와 붙이는 화면(`admin/scene_map_tab`)을
  만들어도 **매핑이 0이면 시작화면은 여전히 무작위**다. 사용자 확정 요구는
  「어떤 사진을 첨부하더라도, 어떤 구절을 선택하더라도 **어느 정도의
  의미연관성**」이므로, 1,189장이 **빠짐없이** 한 벌은 덮여 있어야 한다.

★★★ **세 층을 서로 다른 촘촘함으로 채운다** — 층은 절 → 단락 → **장** 순으로
  **첫 자리에서 멈춘다**(§db_splash_scene). 그래서 겹쳐도 정밀한 것이 이긴다:
  | 층 | 무엇 | 몇 |
  |---|---|---|
  | **절** | 즐겨찾기에 가장 많이 오르는 대표 구절 | **31** |
  | **장** | 시편 150편 — 편마다 성격이 확 다르다(사용자 지적) | **150** |
  | **장** | 그 밖 66권의 책 성격 | **1,039** |
  ⇒ **1,189장 전부 덮인다.** 안 채운 장이 없으므로 어떤 구절을 골라도
    무작위로 물러서지 않는다.

⚠⚠ **책 기본값과 시편 편별 값은 같은 층(장)이라 겹친다** — 겹치면 weight 로
  뽑히므로 시편에는 책 기본값을 **넣지 않는다**(장마다 정확히 한 벌).

⚠ **지어내지 않는다** — 장면은 그 책·그 편이 실제로 그리는 그림에서 골랐다
  (시23 푸른 풀밭 · 시119 주의 말씀은 내 발의 등 · 욘 큰 바다 · 학 성전).
  근거가 흐린 자리는 그 책의 **지배적 이미지**를 쓴다.

⚠ **손으로 고친 것을 지우지 않는다** — 씨앗이 만든 행만 `note='seed'` 로
  표시하고 `--undo` 는 그것만 걷는다.

  `--check`(무엇이 바뀌나) · `--apply`(멱등) · `--undo` · `--status` · `--selftest`
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import appdb                                                    # noqa: E402
import db_splash_scene as SC                                    # noqa: E402

NOTE = 'seed'          # 이 표식이 붙은 행만 `--undo` 가 걷는다

#: 책 성격 — `bcode: (주 장면, 보조 장면)`.
#: ★ 둘을 주는 까닭 — 한 장면만 주면 그 책을 읽는 내내 같은 결의 사진만 뜬다.
#: ⚠ 시편(19)은 **편마다** 정하므로 여기 없다.
BOOK_SCENES = {
    1:  ('NIGHT_SKY', 'DESERT_ROAD'),   # 창세기 — 창조 · 족장의 길
    2:  ('WILDERNESS', 'CAMPFIRE'),     # 출애굽기 — 광야 · 불기둥
    3:  ('WORSHIP_PLACE', 'SNOW'),      # 레위기 — 제사 · 정결
    4:  ('WILDERNESS', 'PILGRIM_PATH'),  # 민수기 — 광야 여정
    5:  ('RIDGE', 'FIELD_WIDE'),        # 신명기 — 느보산에서 바라본 땅
    6:  ('RIVER', 'WALL'),              # 여호수아 — 요단 건넘 · 여리고
    7:  ('VALLEY', 'RUINS'),            # 사사기 — 반복되는 낮은 자리
    8:  ('HARVEST', 'FIELD_WIDE'),      # 룻기 — 보리 추수 · 이삭줍기
    9:  ('FLOCK', 'LAMP'),              # 사무엘상 — 목자 다윗 · 등불 사무엘
    10: ('WALL', 'BROOK'),              # 사무엘하 — 다윗 성 · 회개
    11: ('WORSHIP_PLACE', 'CAMPFIRE'),  # 열왕기상 — 성전 · 갈멜산 불
    12: ('RUINS', 'WILDERNESS'),        # 열왕기하 — 쇠락 · 포로
    13: ('WORSHIP_PLACE', 'WALL'),      # 역대상 — 법궤 · 성
    14: ('WORSHIP_PLACE', 'RUINS'),     # 역대하 — 성전 · 무너짐
    15: ('PILGRIM_PATH', 'WALL'),       # 에스라 — 귀환 · 재건
    16: ('WALL', 'LAMP'),               # 느헤미야 — 성벽
    17: ('NIGHT_SKY', 'LAMP'),          # 에스더 — 숨은 손길
    18: ('SEA_ROUGH', 'NIGHT_SKY'),     # 욥기 — 폭풍 · 별에서 오는 대답
    20: ('DESERT_ROAD', 'LAMP'),        # 잠언 — 두 길
    21: ('SUNSET', 'MIST'),             # 전도서 — 해 아래 · 헛됨
    22: ('FLOWER', 'VINEYARD'),         # 아가 — 동산
    23: ('WILDERNESS', 'DAWN'),         # 이사야 — 광야의 길 · 위로
    24: ('RAIN', 'RUINS'),              # 예레미야 — 눈물 · 무너짐
    25: ('RUINS', 'DAWN'),              # 애가 — 폐허 · 아침마다 새로움
    26: ('VALLEY', 'CLOUDS'),           # 에스겔 — 마른 뼈 골짜기 · 영광
    27: ('NIGHT_SKY', 'CAMPFIRE'),      # 다니엘 — 환상 · 풀무불
    28: ('MIST', 'VINEYARD'),           # 호세아 — 이슬 같은 사랑
    29: ('RAIN', 'WATERFALL'),          # 요엘 — 이른 비 · 영을 부으심
    30: ('RIVER', 'FLOCK'),             # 아모스 — 공의가 물 같이 · 목자
    31: ('ROCK', 'RUINS'),              # 오바댜 — 바위 틈 에돔
    32: ('SEA_ROUGH', 'SUNSET'),        # 요나 — 큰 바다 · 박넝쿨
    33: ('PILGRIM_PATH', 'RIDGE'),      # 미가 — 겸손히 행함 · 산에 오르자
    34: ('SEA_ROUGH', 'RUINS'),         # 나훔 — 니느웨
    35: ('RIDGE', 'WATERFALL'),         # 하박국 — 파수대 · 물이 바다 덮듯
    36: ('CLOUDS', 'RUINS'),            # 스바냐 — 여호와의 날
    37: ('WORSHIP_PLACE', 'FIELD_WIDE'),  # 학개 — 성전 재건
    38: ('LAMP', 'SPRING'),             # 스가랴 — 금 등대 · 열린 샘
    39: ('DAWN', 'CAMPFIRE'),           # 말라기 — 의로운 해 · 연단하는 불
    40: ('RIDGE', 'SOWING'),            # 마태 — 산상수훈 · 씨 뿌리는 자
    41: ('DESERT_ROAD', 'SEA_ROUGH'),   # 마가 — 곧 · 갈릴리 바다
    42: ('SHEPHERD', 'LAMP'),           # 누가 — 잃은 양을 찾는 목자
    43: ('LAMP', 'SPRING'),             # 요한 — 빛 · 생수
    44: ('CAMPFIRE', 'PILGRIM_PATH'),   # 사도행전 — 불의 혀 · 전파
    45: ('DAWN', 'ROCK'),               # 로마서 — 의 · 흔들리지 않음
    46: ('WORSHIP_PLACE', 'FIELD_WIDE'),  # 고린도전서 — 몸된 교회
    47: ('VALLEY', 'DAWN'),             # 고린도후서 — 질그릇 · 보배
    48: ('FRUIT', 'DESERT_ROAD'),       # 갈라디아서 — 성령의 열매 · 자유
    49: ('WALL', 'CLOUDS'),             # 에베소서 — 하나됨 · 전신갑주
    50: ('PILGRIM_PATH', 'FLOWER'),     # 빌립보서 — 달려감 · 기쁨
    51: ('TREE_ONE', 'CLOUDS'),         # 골로새서 — 뿌리 박고 · 충만
    52: ('DAWN', 'NIGHT_SKY'),          # 데살로니가전서 — 재림 · 깨어
    53: ('NIGHT_SKY', 'LAMP'),          # 데살로니가후서 — 인내
    54: ('LAMP', 'WORSHIP_PLACE'),      # 디모데전서 — 교회의 등불
    55: ('SUNSET', 'PILGRIM_PATH'),     # 디모데후서 — 달려갈 길을 마치고
    56: ('FIELD_WIDE', 'FRUIT'),        # 디도서 — 선한 일
    57: ('TREE_SHADE', 'MEADOW'),       # 빌레몬서 — 형제로 받아들임
    58: ('PILGRIM_PATH', 'WORSHIP_PLACE'),  # 히브리서 — 나그네 · 더 나은 제사
    59: ('RAIN', 'FIELD_WIDE'),         # 야고보서 — 이른 비 늦은 비 · 행함
    60: ('ROCK', 'DAWN'),               # 베드로전서 — 산 소망 · 산 돌
    61: ('DAWN', 'NIGHT_SKY'),          # 베드로후서 — 샛별이 떠오르기까지
    62: ('LAMP', 'SPRING'),             # 요한1서 — 빛 · 사랑
    63: ('LAMP', 'DESERT_ROAD'),        # 요한2서 — 진리 안에서 행함
    64: ('TREE_SHADE', 'PILGRIM_PATH'),  # 요한3서 — 나그네 대접
    65: ('ROCK', 'CLOUDS'),             # 유다서 — 지켜 주심
    66: ('DAWN', 'RIVER'),              # 요한계시록 — 새 아침 · 생명수 강
}

#: 시편 150편 — 편마다 그 편이 실제로 그리는 그림 하나.
#: ★ 사용자 지적 「시편은 페리코프에 따라 장면이 크게 달라질 수도 있다」.
#:   실측 시편은 **150장 = 150페리코프**라 장으로 적으면 그대로 편이 된다.
PSALM_SCENES = {
    1: 'TREE_ONE', 2: 'RIDGE', 3: 'NIGHT_SKY', 4: 'NIGHT_SKY', 5: 'DAWN',
    6: 'RAIN', 7: 'ROCK', 8: 'NIGHT_SKY', 9: 'DAWN', 10: 'VALLEY',
    11: 'ROCK', 12: 'CAMPFIRE', 13: 'MIST', 14: 'VALLEY',
    15: 'WORSHIP_PLACE', 16: 'FIELD_WIDE', 17: 'TREE_SHADE', 18: 'ROCK',
    19: 'NIGHT_SKY', 20: 'WORSHIP_PLACE', 21: 'DAWN', 22: 'VALLEY',
    23: 'MEADOW', 24: 'WALL', 25: 'DESERT_ROAD', 26: 'LAMP', 27: 'DAWN',
    28: 'ROCK', 29: 'WATERFALL', 30: 'DAWN', 31: 'ROCK', 32: 'SPRING',
    33: 'NIGHT_SKY', 34: 'SPRING', 35: 'SEA_ROUGH', 36: 'SPRING',
    37: 'BROOK', 38: 'VALLEY', 39: 'PILGRIM_PATH', 40: 'ROCK', 41: 'MEADOW',
    42: 'BROOK', 43: 'LAMP', 44: 'MIST', 45: 'FLOWER', 46: 'RIVER',
    47: 'WORSHIP_PLACE', 48: 'WALL', 49: 'SUNSET', 50: 'FLOCK', 51: 'SNOW',
    52: 'TREE_ONE', 53: 'VALLEY', 54: 'ROCK', 55: 'CLOUDS', 56: 'RAIN',
    57: 'DAWN', 58: 'VALLEY', 59: 'WALL', 60: 'VALLEY', 61: 'ROCK',
    62: 'LAKE_CALM', 63: 'WILDERNESS', 64: 'SEA_ROUGH', 65: 'HARVEST',
    66: 'CAMPFIRE', 67: 'HARVEST', 68: 'RAIN', 69: 'SEA_ROUGH',
    70: 'DESERT_ROAD', 71: 'SUNSET', 72: 'RAIN', 73: 'WORSHIP_PLACE',
    74: 'RUINS', 75: 'WORSHIP_PLACE', 76: 'WALL', 77: 'NIGHT_SKY',
    78: 'ROCK', 79: 'RUINS', 80: 'VINEYARD', 81: 'WORSHIP_PLACE',
    82: 'VALLEY', 83: 'SEA_ROUGH', 84: 'PILGRIM_PATH', 85: 'HARVEST',
    86: 'DESERT_ROAD', 87: 'WALL', 88: 'NIGHT_SKY', 89: 'CLOUDS',
    90: 'FLOWER', 91: 'ROCK', 92: 'TREE_ONE', 93: 'SEA_ROUGH', 94: 'ROCK',
    95: 'FLOCK', 96: 'TREE_SHADE', 97: 'CLOUDS', 98: 'RIVER', 99: 'CLOUDS',
    100: 'FLOCK', 101: 'DESERT_ROAD', 102: 'RUINS', 103: 'DAWN',
    104: 'SPRING', 105: 'DESERT_ROAD', 106: 'WILDERNESS', 107: 'SEA_ROUGH',
    108: 'DAWN', 109: 'VALLEY', 110: 'RIDGE', 111: 'HARVEST', 112: 'LAMP',
    113: 'MEADOW', 114: 'RIVER', 115: 'RUINS', 116: 'SPRING',
    117: 'WORSHIP_PLACE', 118: 'WALL', 119: 'LAMP', 120: 'PILGRIM_PATH',
    121: 'RIDGE', 122: 'WALL', 123: 'RIDGE', 124: 'CLOUDS', 125: 'RIDGE',
    126: 'HARVEST', 127: 'WALL', 128: 'VINEYARD', 129: 'FLOWER',
    130: 'DAWN', 131: 'LAKE_CALM', 132: 'WORSHIP_PLACE', 133: 'MIST',
    134: 'NIGHT_SKY', 135: 'RAIN', 136: 'DAWN', 137: 'RIVER',
    138: 'WORSHIP_PLACE', 139: 'DAWN', 140: 'VALLEY', 141: 'SUNSET',
    142: 'ROCK', 143: 'WILDERNESS', 144: 'NIGHT_SKY', 145: 'FIELD_WIDE',
    146: 'MEADOW', 147: 'SNOW', 148: 'NIGHT_SKY', 149: 'WORSHIP_PLACE',
    150: 'WORSHIP_PLACE',
}

#: 대표 구절 — 즐겨찾기에 가장 많이 오르는 자리. `(bcode, 장, 절, 장면)`.
#: ★ **절 층이라 장 매핑을 이긴다** — 그 구절만은 정확히 그 그림으로.
VERSE_SCENES = [
    (1, 1, 1, 'NIGHT_SKY'),      # 태초에 하나님이 천지를 창조하시니라
    (1, 1, 3, 'DAWN'),           # 빛이 있으라
    (19, 23, 2, 'MEADOW'),       # 푸른 풀밭에 누이시며
    (19, 23, 4, 'VALLEY'),       # 사망의 음침한 골짜기로 다닐지라도
    (19, 119, 105, 'LAMP'),      # 주의 말씀은 내 발에 등이요
    (23, 40, 31, 'RIDGE'),       # 독수리가 날개치며 올라감 같을 것이요
    (23, 41, 10, 'ROCK'),        # 두려워하지 말라 내가 너와 함께 함이라
    (24, 29, 11, 'DESERT_ROAD'),  # 너희를 향한 나의 생각은
    (40, 6, 33, 'FIELD_WIDE'),   # 먼저 그의 나라와 그의 의를 구하라
    (40, 11, 28, 'TREE_SHADE'),  # 수고하고 무거운 짐 진 자들아
    (40, 28, 19, 'PILGRIM_PATH'),  # 모든 족속으로 제자를 삼아
    (43, 3, 16, 'DAWN'),         # 하나님이 세상을 이처럼 사랑하사
    (43, 14, 6, 'DESERT_ROAD'),  # 내가 곧 길이요 진리요 생명이니
    (43, 15, 5, 'VINEYARD'),     # 나는 포도나무요 너희는 가지라
    (45, 8, 28, 'HARVEST'),      # 모든 것이 합력하여 선을 이루느니라
    (45, 12, 2, 'DAWN'),         # 마음을 새롭게 함으로 변화를 받아
    (46, 13, 13, 'SPRING'),      # 믿음 소망 사랑 그 중의 제일은 사랑
    (47, 5, 17, 'SPRING'),       # 새로운 피조물이라
    (48, 2, 20, 'CAMPFIRE'),     # 내가 그리스도와 함께 십자가에
    (48, 5, 22, 'FRUIT'),        # 오직 성령의 열매는
    (49, 2, 8, 'MIST'),          # 너희는 그 은혜를 인하여 믿음으로
    (50, 4, 6, 'LAKE_CALM'),     # 아무것도 염려하지 말고
    (50, 4, 13, 'RIDGE'),        # 내게 능력 주시는 자 안에서
    (51, 3, 2, 'CLOUDS'),        # 위의 것을 생각하고
    (52, 5, 16, 'FLOWER'),       # 항상 기뻐하라
    (55, 1, 7, 'CAMPFIRE'),      # 두려워하는 마음을 주신 것이 아니요
    (58, 11, 1, 'MIST'),         # 믿음은 바라는 것들의 실상이요
    (58, 12, 1, 'PILGRIM_PATH'),  # 우리 앞에 당한 경주를 경주하며
    (59, 1, 5, 'SPRING'),        # 지혜가 부족하거든 하나님께 구하라
    (60, 5, 7, 'TREE_SHADE'),    # 너희 염려를 다 주께 맡기라
    (62, 1, 9, 'SNOW'),          # 우리 죄를 자백하면
    (66, 21, 4, 'DAWN'),         # 모든 눈물을 그 눈에서 씻기시매
    (66, 22, 17, 'SPRING'),      # 생명수를 값없이 받으라
    # ★ 아래 셋은 **그 장면이 그려지는 유일한 자리**다 — 없으면 그 장면의
    #   사진을 넣어도 영영 안 뜬다(실측으로 잡았다).
    (1, 9, 13, 'RAINBOW'),       # 내가 내 무지개를 구름 속에 두었나니
    (41, 4, 28, 'GRAIN_GROW'),   # 처음에는 싹이요 다음에는 이삭이요
    (23, 53, 7, 'SHEARING'),     # 털 깎는 자 앞에 잠잠한 양 같이
]


# ── 계산 ────────────────────────────────────────────────────────────
def plan(conn):
    """넣을 것을 (scope, target_id, scene, weight) 로 낸다.

    ⚠ **장마다 정확히 한 벌** — 시편에는 책 기본값을 안 넣는다(같은 층이라
      겹치면 뽑기가 흐려진다).
    """
    out = []
    # ① 대표 구절 — 절 층
    for bcode, ch, vs, scene in VERSE_SCENES:
        r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=?"
                         " AND chapter=? AND verse=?",
                         (bcode, ch, vs)).fetchone()
        if r:
            out.append(('VERSE', int(r[0]), scene, 3))
    # ② 시편 — 편마다
    for ch, scene in sorted(PSALM_SCENES.items()):
        r = conn.execute("SELECT 1 FROM bible_index WHERE bcode=19"
                         " AND chapter=? LIMIT 1", (ch,)).fetchone()
        if r:
            out.append(('CHAP', SC.chap_key(19, ch), scene, 2))
    # ③ 그 밖 66권 — 책 성격 둘을 모든 장에
    for bcode, ch in conn.execute(
            "SELECT DISTINCT bcode, chapter FROM bible_index"
            " WHERE bcode<>19 ORDER BY bcode, chapter"):
        pair = BOOK_SCENES.get(int(bcode))
        if not pair:
            continue
        key = SC.chap_key(int(bcode), int(ch))
        out.append(('CHAP', key, pair[0], 2))
        out.append(('CHAP', key, pair[1], 1))
    return out


def check(conn):
    """무엇이 바뀌나 — `(넣을 것, 이미 있는 것, 잘못된 장면)`."""
    rows = plan(conn)
    bad = sorted({s for _sc, _t, s, _w in rows if s not in SC.SCENE_BY})
    have = set()
    try:
        for r in conn.execute(
                "SELECT scene_code, scope, target_id FROM sys_scene_map"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            have.add((str(r[0]), str(r[1]), int(r[2])))
    except Exception:
        pass
    add = [x for x in rows if (x[2], x[0], x[1]) not in have]
    return add, len(rows) - len(add), bad


def apply(conn, dry=False):
    """넣는다(멱등). ⚠ 잘못된 장면 코드가 하나라도 있으면 **아무것도 안 넣는다**."""
    SC.init(conn)
    add, same, bad = check(conn)
    if bad:
        raise SystemExit('없는 장면 코드: %s' % ', '.join(bad))
    if dry:
        return len(add), same
    for scope, tid, scene, w in add:
        SC.set_map(conn, scene, scope, tid, w, NOTE)
    conn.commit()
    return len(add), same


def undo(conn):
    """씨앗이 만든 행만 걷는다 — **손으로 고친 것은 안 건드린다**."""
    n = conn.execute("DELETE FROM sys_scene_map WHERE note=?",
                     (NOTE,)).rowcount
    conn.commit()
    return n


def status(conn):
    SC.init(conn)
    cov = SC.coverage(conn)
    seed = conn.execute("SELECT COUNT(*) FROM sys_scene_map WHERE note=?",
                        (NOTE,)).fetchone()[0]
    hand = conn.execute("SELECT COUNT(*) FROM sys_scene_map"
                        " WHERE COALESCE(note,'')<>?", (NOTE,)).fetchone()[0]
    return cov, seed, hand


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-54s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-54s %s' % (n, e))

    print('=== db_splash_seed selftest')
    # ── 표가 말이 되는가 (DB 없이) ──────────────────────────────────
    bad = sorted({s for s in list(PSALM_SCENES.values())
                  + [x for p in BOOK_SCENES.values() for x in p]
                  + [v[3] for v in VERSE_SCENES] if s not in SC.SCENE_BY})
    t('★★★ **없는 장면을 가리키지 않는다**', not bad, str(bad))
    t('★★ **시편 150편이 다 있다**',
      sorted(PSALM_SCENES) == list(range(1, 151)), '%d편' % len(PSALM_SCENES))
    t('★★ **66권에서 시편만 빠진다**(편마다 정하므로)',
      19 not in BOOK_SCENES and len(BOOK_SCENES) == 65,
      '%d권' % len(BOOK_SCENES))
    t('  책마다 장면 둘 — 한 결만 뜨지 않게',
      all(len(v) == 2 and v[0] != v[1] for v in BOOK_SCENES.values()))
    t('  대표 구절 30개 안팎', 25 <= len(VERSE_SCENES) <= 40,
      '%d절' % len(VERSE_SCENES))
    t('  대표 구절에 겹치는 자리가 없다',
      len({(b, c, v) for b, c, v, _s in VERSE_SCENES}) == len(VERSE_SCENES))
    used = (set(PSALM_SCENES.values())
            | {x for p in BOOK_SCENES.values() for x in p}
            | {v[3] for v in VERSE_SCENES})
    # ★★★ **장면 38이 하나도 안 빠진다** — 빠진 장면은 그 사진을 넣어도
    #   영영 안 뜬다(실측으로 셋을 잡았다: 무지개·자라는 곡식·양털깎이).
    t('★★★ **쓰이지 않는 장면이 없다**(있으면 그 사진이 영영 안 뜬다)',
      len(used) == len(SC.SCENES),
      '%d/%d · 빠진 것 %s' % (len(used), len(SC.SCENES),
                             [SC.SCENE_BY[s][2] for s in SC.SCENE_BY
                              if s not in used] or '없음'))

    # ── 메모리 DB 왕복 ─────────────────────────────────────────────
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER,
                               chapter INTEGER, verse INTEGER);
      CREATE TABLE sys_pericope_asset(pericope_id INTEGER, peri_type TEXT,
             start_vid INTEGER, end_vid INTEGER, record_status TEXT);
      CREATE TABLE sys_splash_image(img_id INTEGER, is_active INTEGER,
                                    name TEXT);
      CREATE TABLE user_splash_image(img_id INTEGER, is_active INTEGER);
      CREATE TABLE sys_text_asset(clicked_id INTEGER, text_type TEXT,
                                  lang_code TEXT, contents TEXT,
                                  record_status TEXT);
      INSERT INTO bible_index VALUES(1,1,1,1),(2,1,1,3),(3,1,2,1),
                                    (4,19,23,2),(5,19,23,4),(6,19,1,1);
    """)
    c.commit()
    SC.init(c)
    add, same, bad2 = check(c)
    t('★ 없는 절·장은 건너뛴다(빈 DB 라도 안 터진다)', not bad2 and add)
    n1, _ = apply(c)
    n2, s2 = apply(c)
    t('★★★ **멱등 — 두 번 넣어도 안 는다**', n2 == 0 and s2 == n1,
      '%d행 → 0행' % n1)
    got = SC.pick_for_verse(c, 1) if False else None
    pairs, via = SC.scenes_for_verse(c, 1)
    t('★★ 창1:1 은 **절 층**으로 붙는다(장을 이긴다)',
      via == 'VERSE' and [p[0] for p in pairs] == ['NIGHT_SKY'],
      '%s %s' % (via, pairs))
    pairs2, via2 = SC.scenes_for_verse(c, 3)
    t('★★ 매핑 없는 절은 **그 장의 책 성격**으로 덮인다',
      via2 == 'CHAP' and len(pairs2) == 2, '%s %s' % (via2, pairs2))
    pairs3, via3 = SC.scenes_for_verse(c, 4)
    t('  시23:2 도 절 층', via3 == 'VERSE'
      and pairs3[0][0] == 'MEADOW', str(pairs3))
    pairs4, _ = SC.scenes_for_verse(c, 6)
    t('★★ **시편에는 책 기본값이 안 붙는다**(장마다 한 벌)',
      len(pairs4) == 1 and pairs4[0][0] == 'TREE_ONE', str(pairs4))

    c.execute("INSERT INTO sys_scene_map(scene_code,scope,target_id,weight,"
              "note,record_status) VALUES('LAMP','CHAP',99001,1,'손','LIVE')")
    c.commit()
    n3 = undo(c)
    left = c.execute("SELECT COUNT(*) FROM sys_scene_map").fetchone()[0]
    t('★★★ **되돌려도 손으로 넣은 것은 남는다**', left == 1 and n3 == n1,
      '%d 걷고 %d 남음' % (n3, left))
    c.close()
    t('★ 시험이 실 DB 를 안 건드린다', True, '메모리 DB')
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect('bible_master.db')
    try:
        if '--undo' in a:
            print('걷은 씨앗 %d행' % undo(conn))
        elif '--apply' in a:
            n, s = apply(conn)
            print('넣음 %d행 · 이미 있던 것 %d행' % (n, s))
        elif '--check' in a:
            SC.init(conn)
            add, same, bad = check(conn)
            print('넣을 것 %d행 · 이미 있는 것 %d행 · 잘못된 장면 %s'
                  % (len(add), same, bad or '없음'))
        else:
            cov, seed, hand = status(conn)
            print('덮은 장 %d / %d  ·  덮은 절 %s / %s (%.1f%%)'
                  % (cov['chap'], cov['chap_total'],
                     format(cov['covered'], ','), format(cov['total'], ','),
                     100.0 * cov['covered'] / max(1, cov['total'])))
            print('씨앗 %d행 · 손으로 넣은 것 %d행 · 쓰인 장면 %d/%d'
                  % (seed, hand, cov['scenes_used'], len(SC.SCENES)))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
