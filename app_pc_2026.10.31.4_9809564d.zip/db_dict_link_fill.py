# -*- coding: utf-8 -*-
"""사전(Easton·Smith) ↔ 엔티티 연결 메우기 (영구 도구 · 2026-09-02).

★ 왜 — 사용자 신고 「감람산, 가인 등 사전에 등록되어 있을만한 이름들이
  사전연결이 안되었다」. 실측: 연결이 빠진 것이 아니라 **사전 항목 자체가
  DB 에 없었다.** 7/30 수입이 「그때 있던 엔티티와 매칭되는 항목만」 넣는
  필터 모드였고, 그 뒤 엔티티가 늘었다(용어 통합 51 포함 → 465).
  이 도구는 로컬 원본(source_texts/ — 이미 검증·등록된 PD 소스)을 다시 읽어
  **지금 엔티티 명부** 기준으로 빠진 항목을 수입하고 잇는다. 반복 실행 전제
  (엔티티가 또 늘면 다시 돌린다) · 멱등.

★ 매칭 원칙(§155차 「문자열로 못 세고 사람이 봐야 한다」) —
  · **정규화 완전 일치만 자동**: 영어 이름·별명 = 표제어(쉼표 도치
    「Olives, Mount of」→「Mount of Olives」 포함).
  · 첫 단어 매칭 같은 느슨한 규칙은 **후보로만** 내고 자동 적용하지 않는다.
  · 한 표제어에 엔티티 여럿이 걸리면 자동 제외(검토 목록으로).

데이터 모양(기존 수입분과 동일):
  sys_ref_unit(unit_code=EASTON_/SMITH_슬러그 · ENTRY · LIVE)
  + sys_ref_text(ORIGINAL · EN · body · title)
  + sys_link_asset(REFU_ENTI · clicked=unit · target=entity · rel=SUBJECT)

사용법
  python db_dict_link_fill.py --selftest
  python db_dict_link_fill.py --check     후보 표(적용 안 함)
  python db_dict_link_fill.py --apply     완전 일치만 수입·연결(멱등)
  python db_dict_link_fill.py --status
"""
import os
import re
import sys

import appdb

SRC = {
    'EASTON_DICT': ('source_texts/easton_dict.txt', 5),
    'SMITH_DICT': ('source_texts/smith_dict.txt', 6),
}
_MAX_BODY = 10000
_MIN_BODY_EASTON = 20
_MIN_BODY_SMITH = 30
_MIN_LOWER = 15


# ── 파서 (참고코드/db_easton_import·db_smith_dict_import 이식 — 원 수입과
#    같은 규칙이라 같은 항목이 같은 모양으로 나온다) ─────────────────────
def _easton_entry(chunk):
    chunk = chunk.strip()
    if not chunk:
        return None
    split_at = -1
    for i, ch in enumerate(chunk):
        if ch.islower() or ch == '(':
            split_at = i
            break
    if split_at <= 0:
        return None
    title = re.sub(r'\s+', ' ', chunk[:split_at]).strip()
    body = chunk[split_at:].strip()
    # ⚠⚠ **끝 외자 = 본문 첫 글자를 삼킨 것** (2026-09-02 실측 475건 —
    #   「JOSHUA J」 + 본문 「ehovah is his help…」. 대문자로 시작하는 본문의
    #   첫 글자가 제목 정규식에 먹혔다). 떼어 본문 앞에 되돌린다.
    m_tail = re.match(r'^(.+) ([A-Z])$', title)
    if m_tail and len(m_tail.group(1)) > 1:
        title = m_tail.group(1)
        body = m_tail.group(2) + body
    if not title or len(title) > 60:
        return None
    if not re.match(r"^[A-Z][A-Z0-9' \-]*$", title):
        return None
    if len(body) < _MIN_BODY_EASTON:
        return None
    return title, body[:_MAX_BODY]


def parse_easton(raw):
    raw = raw.replace('\r', '')
    raw = re.sub(r'  +', ' ', raw)
    out = {}
    for chunk in raw.split('•')[1:]:
        r = _easton_entry(chunk)
        if r and r[0] not in out:          # 같은 표제어 첫 항목만
            out[r[0]] = r[1]
    return out


def _smith_clean(raw):
    raw = re.sub(r'\[\[\d+\]([^\]]*)\]', r'\1', raw)
    raw = re.sub(r'\[\d+\]', '', raw)
    raw = re.sub(r'\n{3,}', '\n\n', raw)
    return raw.strip()


def parse_smith(raw):
    raw = raw.replace('\r', '')
    m = re.search(r'^   [A-Z]', raw, re.M)
    if m:
        raw = raw[m.start():]
    em = re.search(r'_{10,}\s*\n\s*\nIndex', raw)
    if em:
        raw = raw[:em.start()]
    out = {}
    title, body_lines = None, []

    def _flush():
        if not title:
            return
        body = _smith_clean('\n'.join(body_lines))
        if (len(body) >= _MIN_BODY_SMITH
                and sum(1 for c in body if c.islower()) >= _MIN_LOWER
                and title not in out):
            out[title] = body[:_MAX_BODY]

    for line in raw.split('\n'):
        if re.match(r'^   [A-Z]\s*$', line):
            continue
        m2 = re.match(r'^   ([A-Z].{1,77}?)\s*$', line)
        if m2:
            _flush()
            title = m2.group(1).strip()
            body_lines = []
        elif title:
            body_lines.append(line.strip())
    _flush()
    return out


# ── 정규화·열쇠 ─────────────────────────────────────────────────────────
def norm(s):
    s = (s or '').lower().strip()
    s = re.sub(r"[.'’]", '', s)
    s = re.sub(r'\s+', ' ', s)
    return s


def head_keys(title):
    """표제어의 비교 열쇠.

    · 쉼표 도치 — 「Olives, Mount Of」→「mount of olives」(도치 뒤 선두
      the 제거 — 「Atonement, The Day Of」→「day of atonement」도).
    · Smith 복합 — 「Bathsheba, Or Bathsheba」·「Michmas Or Michmash」는
      각 대안이 제 열쇠. 「Canaanites, The」는 The 접미를 벗긴다.
    · 쉼표 나열 — 「Greece, Greeks, Grecians」 각각."""
    ks = {norm(title)}
    # Or 복합 — 각 대안
    for part in re.split(r',?\s+[Oo]r\s+', title):
        part = part.strip().strip(',')
        if part:
            ks.add(norm(part))
    if ',' in title:
        parts = [p.strip() for p in title.split(',')]
        # The 접미 (「Canaanites, The」)
        if len(parts) == 2 and parts[1].lower() == 'the':
            ks.add(norm(parts[0]))
        elif len(parts) == 2 and parts[1]:
            inv = norm(parts[1] + ' ' + parts[0])
            ks.add(inv)
            if inv.startswith('the '):
                ks.add(inv[4:])
        elif len(parts) > 2:
            for p in parts:            # 나열 — 각각
                if p:
                    ks.add(norm(p))
    ks.discard('')
    return ks


def entity_keys(name, aliases):
    """엔티티의 비교 열쇠 — 이름·괄호 별칭·로마숫자 꼬리 제거·별명."""
    ks = set()

    def _add(v):
        v = norm(v)
        if v and len(v) > 1:
            ks.add(v)

    _add(name)
    _add(re.sub(r'\s+[IVX]+$', '', name or ''))
    m = re.search(r'\(([^)]+)\)', name or '')
    if m:
        _add(m.group(1))
    # 기계적 변형 (2026-09-02) — 사전 표제어의 굳은 꼴에 맞춘다.
    #   「Mount Sinai」→sinai · 「The Fall」→fall · 「Feast of Purim」→purim ·
    #   「Day of Atonement」→atonement (표제어 쪽 도치·The 제거와 맞물린다) ·
    #   「Jordan River」→jordan
    for pre in ('Mount ', 'The ', 'Feast of ', 'Day of '):
        if (name or '').startswith(pre):
            _add(name[len(pre):])
    if (name or '').endswith(' River'):
        _add(name[:-6])
    for a in aliases or ():
        _add(a)
    return ks


def _slug(title):
    return re.sub(r'[^A-Z0-9]', '_', title.upper())[:36]


# ── 조회 ────────────────────────────────────────────────────────────────
def load_entities(conn):
    """LIVE 엔티티 → [(id, code, type, EN이름, KO이름, [EN별명])]."""
    import json as _json
    out = []
    for eid, code, etype, jd, en, ko in conn.execute(
            "SELECT m.entity_id, m.entity_code, m.entity_type, m.json_detail,"
            " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            "   AND clicked_id=m.entity_id AND lang_code='EN'"
            "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),"
            " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            "   AND clicked_id=m.entity_id AND lang_code='KO'"
            "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1)"
            " FROM sys_entity_master m"
            " WHERE COALESCE(m.record_status,'LIVE')='LIVE'"):
        al = []
        try:
            al = list((_json.loads(jd or '{}').get('aliases') or {}).get('EN') or [])
        except Exception:
            pass
        out.append((eid, code, etype, en or '', ko or '', al))
    return out


def existing(conn):
    """(기존 유닛 {unit_code: (id, src_code, label)}, 기존 링크 {(src, eid)}, 링크 유닛짝 {(unit, eid)})."""
    units = {}
    for uid, ucode, label, scode in conn.execute(
            "SELECT u.ref_unit_id, u.unit_code, u.unit_label, s.src_code"
            " FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id"
            " WHERE s.src_type='DICTIONARY'"
            "   AND COALESCE(u.record_status,'LIVE')='LIVE'"):
        units[ucode] = (uid, scode, label)
    links = set()
    pair = set()
    for uid, eid, scode in conn.execute(
            "SELECT l.clicked_id, l.target_id, s.src_code"
            " FROM sys_link_asset l"
            " JOIN sys_ref_unit u ON u.ref_unit_id=l.clicked_id"
            " JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id"
            " WHERE l.link_type='REFU_ENTI' AND s.src_type='DICTIONARY'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"):
        links.add((scode, eid))
        pair.add((uid, eid))
    return units, links, pair


# ★ 오탐 제외 (2026-09-02 2차 검토) — 열쇠 규칙으로 잡혔지만 본문이 딴 주제.
#   · FEAST_TRUMPETS × Easton 「TRUMPETS」 — **악기 항목**(제사장의 은나팔·
#     양각나팔의 재질과 용도)이지 나팔절이 아니다. 나팔절은 Smith
#     「Trumpets, Feast Of」가 이미 이어져 있다.
#   · FEAST_ATONEMENT × Easton 「ATONEMENT」 — 교리 항목이라 D_ATONEMENT 의
#     것(MANUAL). D_ATONEMENT 이 연결되고 나면 겹침이 풀려 **이쪽이 유일
#     매칭으로 승격될 수 있으므로** 미리 막는다.
EXCLUDE = {
    ('EASTON_DICT', 'FEAST_TRUMPETS'),
    ('EASTON_DICT', 'FEAST_ATONEMENT'),
}


def unwrap_body(text):
    """하드랩을 문단으로 편다 (2026-09-02 사용자 신고 「내용이 일정한 간격으로
    잘렸다」 — 원문 txt 의 ~73자 줄바꿈이 본문에 그대로 저장돼 있었다.
    §101차 도서 하드랩과 같은 병·같은 처방).

    · 빈 줄 = 문단 경계(문단 사이 `\\n` 하나 — §28-11 서술 표준)
    · Smith 「+」 갈래 불릿 = 제 문단
    · **바꾸는 것은 공백뿐** — 낱말 차례가 다르면 호출부가 거부한다."""
    if not text:
        return text
    # ⚠ **접힌 본문만 손댄다** (멱등 가드). 잣대 = §101차 줄당 자수:
    #   하드랩은 ~73자, 편 문단은 수백 자.
    _ls = sorted(len(l) for l in text.split('\n') if l.strip())
    if not _ls or _ls[len(_ls) // 2] >= 100:
        return text
    paras, cur = [], []
    _TERM = ('.', '?', '!', ':')

    def _flush():
        if cur:
            paras.append(' '.join(' '.join(cur).split()))
            del cur[:]

    prev = ''
    for line in text.split('\n'):
        st = line.strip()
        if not st:
            _flush()
            prev = ''
            continue
        # 이어붙임 조건 — 앞 줄이 랩 폭에 차 있고(≥55자) 문장이 안 끝났을 때만.
        #   문장부호로 끝난 자리는 문단으로 가른다(문장 중간이 아니므로 무해 ·
        #   덕분에 편 본문을 다시 돌려도 안 합쳐진다 — 멱등).
        if st.startswith('+') and cur:
            _flush()
        elif cur and not (len(prev) >= 55
                          and not prev.rstrip().endswith(_TERM)):
            _flush()
        cur.append(st)
        prev = st
    _flush()
    return '\n'.join(paras)


def unwrap_all(conn, verbose=True):
    """사전 소스의 저장 본문을 편다 — **원본 재유도가 우선**(멱등의 정본).

    표제어가 원본 파일에 있고 **낱말 차례가 같으면** 원본을 다시 편 것으로
    덮는다 — 저장본이 몇 번 잘못 변형됐어도 원본에서 되살아난다. 원본에
    없는 유닛(MEYER_BC 등)만 unwrap_body 폴백."""
    src_map = {}
    try:
        for scode, entries in load_dicts().items():
            for title, body in entries.items():
                src_map[(scode, title)] = body
    except Exception as e:
        print('  ⚠ 원본 읽기 실패(폴백만 사용):', e)
    rows = conn.execute("""
        SELECT t.text_id, t.body_text, s.src_code, COALESCE(t.title, u.unit_label)
        FROM sys_ref_text t
        JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id
        JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id
        WHERE s.src_code IN ('EASTON_DICT', 'SMITH_DICT', 'MEYER_BC')
          AND t.body_text IS NOT NULL""").fetchall()
    n = skip = 0
    for tid, body, scode, title in rows:
        new = src_map.get((scode, title))
        if new is None or ' '.join(new.split()) != ' '.join(body.split()):
            new = unwrap_body(body)
        if new == body:
            continue
        if ' '.join(body.split()) != ' '.join(new.split()):
            skip += 1                      # 낱말이 달라지면 손대지 않는다
            continue
        conn.execute("UPDATE sys_ref_text SET body_text=? WHERE text_id=?",
                     (new, tid))
        n += 1
    conn.commit()
    if verbose:
        print('본문 펴기: %d행 갱신 · 보존가드 거부 %d · 전체 %d'
              % (n, skip, len(rows)))
    return n


def find_matches(conn, dicts):
    """→ (auto 목록, review 목록). auto = 정규화 완전 일치 · 유일.

    dicts = {'EASTON_DICT': {title: body}, 'SMITH_DICT': {...}}"""
    ents = load_entities(conn)
    units, links, _pair = existing(conn)
    auto, review = [], []
    for scode, entries in dicts.items():
        # 표제어 열쇠 → [title]
        by_key = {}
        for title in entries:
            for k in head_keys(title):
                by_key.setdefault(k, []).append(title)
        for eid, code, etype, en, ko, al in ents:
            if (scode, eid) in links:
                continue                       # 이미 이 사전과 연결돼 있다
            # ⚠⚠ **용어(TERM)는 자동 매칭에서 뺀다** (2026-09-02 검토에서 잡음)
            #   — 음역(Hesed·Gaal·Barak·Shama·Halak)이 **동명의 인명·산 이름**
            #   사전 항목과 정확히 겹친다. Smith 「Hesed」는 솔로몬의 관리,
            #   「Barak」은 드보라의 장군이다. 개념 항목은 교리(D_*)가 이미
            #   전체 낱말(COVENANT 등)로 맞는다.
            if (etype or '').upper() == 'TERM':
                continue
            if (scode, code) in EXCLUDE:
                continue                       # 검토에서 오탐 판정 — 아래 표
            hit_titles = set()
            for k in entity_keys(en, al):
                for t in by_key.get(k, ()):
                    hit_titles.add(t)
            if not hit_titles:
                continue
            if len(hit_titles) == 1:
                t = next(iter(hit_titles))
                # 한 표제어를 딴 엔티티도 잡으면 자동에서 뺀다
                clash = sum(1 for e2 in ents if e2[0] != eid
                            and (scode, e2[0]) not in links
                            and any(k in head_keys(t)
                                    for k in entity_keys(e2[3], e2[5])))
                row = (scode, eid, code, etype, ko or en, en, t,
                       len(entries[t]))
                if clash:
                    review.append(row + ('표제어를 %d개 엔티티가 공유' % (clash + 1),))
                else:
                    auto.append(row)
            else:
                review.append((scode, eid, code, etype, ko or en, en,
                               ' / '.join(sorted(hit_titles)), 0,
                               '표제어 후보 여럿'))
    return auto, review


# ★ 수동 배정 (2026-09-02 검토 판정) — 자동 규칙이 못 가르는 것들.
#   · Midian — Smith 한 항목이 인물(아브라함의 아들)과 땅을 함께 다룬다 →
#     **둘 다** 잇는다(정보다. 한 절 두 용어 §156차와 같은 판정).
#   · Sidon — Smith 「Sidon」 60자는 교차참조 stub. 본 항목은
#     「Zidon, Or Sidon」(3,092자) → 그쪽을 잇는다.
#   · Jeconiah — Smith·Easton 모두 표제어가 「Jehoiachin」(같은 인물의 왕명).
#   · Atonement — Easton 「ATONEMENT」은 **교리 항목**(롬5:11 의 대속) →
#     D_ATONEMENT. 속죄일(FEAST_ATONEMENT)의 Easton 별도 항목은 없다
#     (Smith 「Atonement, The Day Of」는 자동 매칭).
#   · Abijah — Smith 가 둘로 가른다. P_ABIJAH 는 유다 왕(르호보암의 아들 —
#     연결된 미디어·Easton 항목이 증언) → 「Abijah Or Abijam」.
#     「Abia, Abiah, Or Abijah」는 동명이인 모음(베겔의 아들·사무엘의 아들 등).
MANUAL = (
    ('SMITH_DICT', 'P_MIDIAN', 'Midian'),
    ('SMITH_DICT', 'PL_MIDIAN', 'Midian'),
    ('SMITH_DICT', 'PL_SIDON', 'Zidon, Or Sidon'),
    ('SMITH_DICT', 'P_JECONIAH', 'Jehoiachin'),
    ('EASTON_DICT', 'P_JECONIAH', 'JEHOIACHIN'),
    ('EASTON_DICT', 'D_ATONEMENT', 'ATONEMENT'),
    ('SMITH_DICT', 'P_ABIJAH', 'Abijah Or Abijam'),
    # ── 3차 검토 배정 (2026-09-02 — 이름꼴이 달라 자동이 못 잡은 것들.
    #    전부 본문을 읽고 판정했다) ──
    # 교리 — Easton 은 개념 표제어를 가진다.
    ('EASTON_DICT', 'D_INSPIRATION', 'INSPIRATION'),
    ('SMITH_DICT', 'D_INSPIRATION', 'Inspiration'),
    # ⚠ 갈래형 병합(db_term_branch, 2026-09-02) 뒤 재지향 — 하나님의 거룩은
    #   T_KADOSH 로, 마지막 부활은 T_ANASTASIS 로 흡수됐다(링크는 병합이
    #   옮겼고, 이 표는 미래 재실행의 무결성을 위해 목적지를 따라간다).
    ('EASTON_DICT', 'T_KADOSH', 'HOLINESS'),            # 「belongs to God (사6:3)」
    ('EASTON_DICT', 'D_SOVEREIGNTY', 'SOVEREIGNTY'),    # 「of God, his absolute right」
    ('EASTON_DICT', 'D_FALL', 'FALL OF MAN'),
    ('EASTON_DICT', 'D_CALLING', 'CALLING'),
    ('EASTON_DICT', 'T_ANASTASIS', 'RESURRECTION OF THE DEAD'),
    ('EASTON_DICT', 'D_TYPOLOGY', 'TYPE'),              # 투포스 낱말 연구 — 예표론 직결
    # 장소 — 「Garden of」·「Mount」 등 꾸밈이 붙은 우리 이름.
    ('EASTON_DICT', 'PL_EDEN', 'EDEN'),
    ('EASTON_DICT', 'PL_HARRAN', 'HARAN'),              # (2.) 아브람이 머문 성읍
    ('EASTON_DICT', 'PL_KADESH', 'KADESH'),
    ('SMITH_DICT', 'PL_KADESH', 'Kadesh, Kadeshbarnea'),
    ('EASTON_DICT', 'PL_UR', 'UR'),
    # 그룹·제도·사물
    ('EASTON_DICT', 'GRP_LEVITE', 'LEVITE'),
    ('EASTON_DICT', 'G_MAGI', 'WISE MEN'),              # 단2 + 마2 동방박사
    ('EASTON_DICT', 'SYS_HIGH_PRIESTHOOD', 'HIGH PRIEST'),
    ('SMITH_DICT', 'SYS_NAZIRITE', 'Nazarite'),
    ('EASTON_DICT', 'OBJ_ARK', 'ARK'),                  # 다의 항목 — 언약궤 절 포함(4,451자)
    ('EASTON_DICT', 'OBJ_MENORAH', 'CANDLESTICK'),      # 성막 등대 항목
    ('SMITH_DICT', 'OBJ_MENORAH', 'Candlestick'),
    ('EASTON_DICT', 'OBJ_BURNING_BUSH', 'BUSH'),        # 떨기나무 현현 전용 항목
    ('SMITH_DICT', 'OBJ_BURNING_BUSH', 'Bush'),
    ('SMITH_DICT', 'IDL_GOLDEN_CALF', 'Calf'),          # 「The molten calf prepared by Aaron」
    ('SMITH_DICT', 'IDL_ZEUS_HERMES', 'Jupiter'),       # 제우스 — 두 표제어를 한 엔티티에
    ('SMITH_DICT', 'IDL_ZEUS_HERMES', 'Mercurius'),     # 헤르메스
    # 민족 — 사전 표제어는 조상 이름·땅 이름(Moab·Egypt)이 민족을 함께 다룬다.
    ('SMITH_DICT', 'N_MOABITE', 'Moab'),
    ('EASTON_DICT', 'N_MOABITE', 'MOABITE'),
    ('SMITH_DICT', 'N_AMMONITE', 'Ammon'),
    ('EASTON_DICT', 'N_AMMONITE', 'AMMONITE'),
    ('SMITH_DICT', 'N_EDOMITE', 'Edom, Idumaea Or Idumea'),
    ('EASTON_DICT', 'N_EDOMITE', 'EDOM'),
    ('SMITH_DICT', 'N_EGYPTIAN', 'Egypt'),
    ('EASTON_DICT', 'N_EGYPTIAN', 'EGYPT'),
    ('SMITH_DICT', 'N_ASSYRIAN', 'Assyria, Asshur'),
    ('EASTON_DICT', 'N_ASSYRIAN', 'ASSYRIA'),
    ('EASTON_DICT', 'N_BABYLONIAN', 'BABYLON'),
    ('SMITH_DICT', 'N_PERSIAN', 'Persia'),
    ('EASTON_DICT', 'N_PERSIAN', 'PERSIA'),
    ('SMITH_DICT', 'N_ROMAN', 'Rome'),
    ('EASTON_DICT', 'N_ROMAN', 'ROME'),
    ('EASTON_DICT', 'N_MEDE', 'MEDIA'),
    ('SMITH_DICT', 'N_PERIZZITE', 'Perizzite, The'),    # 단수형 — 우리 이름은 복수
    ('SMITH_DICT', 'N_ARAMEAN', 'Syria'),               # 「term used for the Hebrew Aram」
    ('EASTON_DICT', 'N_ARAMEAN', 'ARAM'),
    ('SMITH_DICT', 'N_PHOENICIAN', 'Phoenice, Phoenicia'),
    ('EASTON_DICT', 'N_PHOENICIAN', 'PHENICIA'),        # PHOENICIA 는 27자 stub — 본 항목은 이 철자
    ('EASTON_DICT', 'N_GREEK', 'GREECE'),
    ('EASTON_DICT', 'N_CHALDEAN', 'CHALDEA'),
    ('EASTON_DICT', 'N_AMALEKITE', 'AMALEK'),           # 조상 항목 — Moab·Ammon 과 같은 판정
    ('SMITH_DICT', 'N_MIDIANITE', 'Midian'),            # 땅·백성을 함께 다룬다
    # ── 4차 검토 배정 (2026-09-02 — 제도·사물 확대 뒤. 전부 본문을 읽고 판정) ──
    ('EASTON_DICT', 'SYS_GRAIN_OFFERING', 'MEAT-OFFERING'),   # minhah — KJV 표기
    ('SMITH_DICT', 'SYS_GRAIN_OFFERING', 'Meat Offering'),
    ('EASTON_DICT', 'SYS_PEACE_OFFERING', 'PEACE OFFERINGS'),  # 복수형이라 자동이 놓침
    ('EASTON_DICT', 'SYS_GUILT_OFFERING', 'TRESPASS OFFERING'),  # asham
    ('SMITH_DICT', 'SYS_CITY_REFUGE', 'Cities Of Refuge'),
    ('EASTON_DICT', 'SYS_GOEL', 'GOEL'),                # 「participle of gaal」
    ('EASTON_DICT', 'OBJ_SHOWBREAD', 'SHEWBREAD'),      # 옛 철자
    ('SMITH_DICT', 'OBJ_SHOWBREAD', 'Shewbread'),
    ('EASTON_DICT', 'OBJ_LAVER', 'LAVER'),
    ('SMITH_DICT', 'OBJ_LAVER', 'Laver'),
    ('EASTON_DICT', 'OBJ_MERCY_SEAT', 'MERCY-SEAT'),
    ('SMITH_DICT', 'OBJ_MERCY_SEAT', 'Mercyseat'),      # 붙여 쓴 철자
    ('EASTON_DICT', 'OBJ_URIM_THUMMIM', 'THUMMIM'),     # URIM 은 57자 stub — 본항목은 이쪽
    ('EASTON_DICT', 'OBJ_NOAHS_ARK', 'ARK'),            # 한 항목이 방주·언약궤를 함께
                                                        # 다룬다(Midian 판정 — 둘 다)
    ('SMITH_DICT', 'FEAST_NEW_MOON', 'New Moon'),       # 「first day of the lunar month」
    ('EASTON_DICT', 'FEAST_FASTS', 'FAST'),             # 금식 항목(속죄일 유일 규정 서술)
    ('SMITH_DICT', 'FEAST_FASTS', 'Fasts'),
    # ⚠ 기각 — E 「MOON」=달 일반(자연) ·
    #   E·S 「Serpent」=뱀 일반(자연사, 놋뱀은 끝에 한 줄) · S 「Veil」=
    #   여성 면사포(성소 휘장 아님) · E 「TABLES」=식탁(막7:4 — 돌판 아님) ·
    #   E 「INCENSE」=향의 성분(분향단 아님). 돌판·휘장·놋뱀·분향단·아론의
    #   지팡이는 사전 표제어 부재가 정상.
)


def manual_rows(conn, dicts):
    """MANUAL → auto 와 같은 꼴의 행 목록(실재 확인 포함)."""
    out = []
    for scode, ecode, title in MANUAL:
        if title not in dicts.get(scode, {}):
            print('  ⚠ 수동 배정 표제어 없음:', scode, title)
            continue
        r = conn.execute(
            "SELECT m.entity_id, m.entity_type,"
            " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            "   AND clicked_id=m.entity_id AND lang_code='KO' LIMIT 1)"
            " FROM sys_entity_master m WHERE m.entity_code=?"
            "  AND COALESCE(m.record_status,'LIVE')='LIVE'", (ecode,)).fetchone()
        if not r:
            print('  ⚠ 수동 배정 엔티티 없음:', ecode)
            continue
        out.append((scode, r[0], ecode, r[1], r[2] or ecode, '',
                    title, len(dicts[scode][title])))
    return out


def apply(conn, dicts, auto):
    """auto 목록을 수입·연결 — 멱등. → (새 유닛, 새 링크)."""
    units, _links, pair = existing(conn)
    src_id = {k: v[1] for k, v in SRC.items()}
    seq = {}
    for scode, sid in src_id.items():
        r = conn.execute("SELECT COALESCE(MAX(sequence),0) FROM sys_ref_unit"
                         " WHERE ref_src_id=?", (sid,)).fetchone()
        seq[scode] = r[0]
    n_unit = n_link = 0
    for scode, eid, code, _etype, _ko, _en, title, _blen in auto:
        ucode = '%s_%s' % (scode.split('_')[0], _slug(title))
        got = units.get(ucode)
        if got is None:
            seq[scode] += 1
            cur = conn.execute(
                "INSERT INTO sys_ref_unit(ref_src_id, unit_code, sequence,"
                " unit_type, unit_label, record_status)"
                " VALUES(?,?,?,?,?,'LIVE')",
                (src_id[scode], ucode, seq[scode], 'ENTRY', title))
            uid = cur.lastrowid
            conn.execute(
                "INSERT INTO sys_ref_text(ref_unit_id, text_variant, lang_code,"
                " body_text, record_status, title)"
                " VALUES(?,?,?,?,'LIVE',?)",
                (uid, 'ORIGINAL', 'EN', dicts[scode][title], title))
            units[ucode] = (uid, scode, title)
            n_unit += 1
        else:
            uid = got[0]
        if (uid, eid) not in pair:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " rel_code, record_status)"
                " VALUES('REFU_ENTI',?,?,'SUBJECT','LIVE')", (uid, eid))
            pair.add((uid, eid))
            n_link += 1
    conn.commit()
    return n_unit, n_link


def load_dicts():
    out = {}
    for scode, (path, _sid) in SRC.items():
        with open(path, encoding='utf-8', errors='replace') as f:
            raw = f.read()
        d = parse_easton(raw) if scode == 'EASTON_DICT' else parse_smith(raw)
        # ★ 하드랩 펴기 — 새 수입도 편 본문으로 저장한다(unwrap_body)
        out[scode] = {t: unwrap_body(b) for t, b in d.items()}
    return out


def status(conn):
    units, links, _p = existing(conn)
    n_ent = conn.execute("SELECT COUNT(*) FROM sys_entity_master"
                         " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    have = len({e for _s, e in links})
    print('LIVE 엔티티 %d · 사전 유닛 %d · 사전 보유 엔티티 %d' % (n_ent, len(units), have))


# ══════════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    # 파서 — 합성 표본
    e = parse_easton('머리말•CAIN the first murderer, son of Adam and Eve.'
                     '•X y')
    t('Easton 파서 — 표제어·본문', e.get('CAIN', '').startswith('the first'), e)
    t('   짧은 본문 거른다', 'X' not in e)
    s = parse_smith('   A\n   Cain\n          (possession) the eldest son of'
                    ' Adam and Eve, murderer of his brother Abel indeed.\n')
    t('Smith 파서', 'Cain' in s and 'possession' in s['Cain'], list(s))
    # 열쇠 — 쉼표 도치
    t('쉼표 도치', 'mount of olives' in head_keys('Olives, Mount of'))
    t('로마숫자 꼬리', 'jeroboam' in entity_keys('Jeroboam I', ()))
    t('별명', 'chiun' in entity_keys('Rephan', ['Chiun']))
    t('슬러그', _slug('Olives, Mount of') == 'OLIVES__MOUNT_OF')
    # ★ 실데이터 불변식 — 기존 링크가 줄지 않는다 · unit_code 중복 0
    try:
        conn = appdb.connect(appdb.MAIN_DB)
        dup = conn.execute(
            "SELECT COUNT(*) FROM (SELECT unit_code FROM sys_ref_unit"
            " WHERE ref_src_id IN (5,6) GROUP BY unit_code HAVING COUNT(*)>1)"
        ).fetchone()[0]
        t('★ unit_code 중복 0', dup == 0, dup)
        orphan = conn.execute(
            "SELECT COUNT(*) FROM sys_ref_unit u"
            " WHERE u.ref_src_id IN (5,6)"
            "  AND COALESCE(u.record_status,'LIVE')='LIVE'"
            "  AND NOT EXISTS (SELECT 1 FROM sys_link_asset l"
            "   WHERE l.link_type='REFU_ENTI' AND l.clicked_id=u.ref_unit_id"
            "    AND COALESCE(l.record_status,'LIVE')='LIVE')").fetchone()[0]
        t('★ 링크 없는 사전 유닛 0', orphan == 0, orphan)
        notext = conn.execute(
            "SELECT COUNT(*) FROM sys_ref_unit u"
            " WHERE u.ref_src_id IN (5,6)"
            "  AND COALESCE(u.record_status,'LIVE')='LIVE'"
            "  AND NOT EXISTS (SELECT 1 FROM sys_ref_text t"
            "   WHERE t.ref_unit_id=u.ref_unit_id"
            "    AND COALESCE(t.record_status,'LIVE')='LIVE')").fetchone()[0]
        t('★ 본문 없는 사전 유닛 0', notext == 0, notext)
        conn.close()
    except Exception as ex:
        t('실데이터 접근', False, ex)
    # 하드랩 펴기 — 낱말 보존·문단 유지·불릿 문단·멱등.
    #   표본은 실제 랩 폭(~70자)으로 만든다 — 짧은 줄 표본은 이어붙임 조건
    #   (앞 줄 ≥55자·문장 미종결)에 안 걸려 시험이 헛돈다.
    NL = chr(10)
    _l1 = 'the eldest son of Amram and Jochebed a daughter of Levi who was born'
    _l2 = 'in Egypt three years before his brother Moses and married Elisheba.'
    _p2 = 'He was appointed by Jehovah to be the interpreter of his brother.'
    w = NL.join([_l1, _l2, '', _p2, '+ bullet one', '+ bullet two'])
    u = unwrap_body(w)
    lines = u.split(NL)
    t('unwrap — 문장이 이어진다', lines[0] == _l1 + ' ' + _l2)
    t('unwrap — 빈 줄 = 문단 경계', lines[1] == _p2)
    t('unwrap — + 불릿은 제 문단', len(lines) == 4 and lines[2] == '+ bullet one')
    t('unwrap — 낱말 차례 보존', ' '.join(w.split()) == ' '.join(u.split()))
    t('unwrap — 멱등', unwrap_body(u) == u)
    print('db_dict_link_fill selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if a == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(appdb.MAIN_DB)
    if a == '--status':
        status(conn)
        conn.close()
        sys.exit(0)
    if a == '--unwrap':
        unwrap_all(conn)
        conn.close()
        sys.exit(0)
    dicts = load_dicts()
    for k, v in dicts.items():
        print('%s 원본 표제어 %d' % (k, len(v)))
    auto, review = find_matches(conn, dicts)
    print('\n자동(완전 일치·유일) %d건:' % len(auto))
    for r in auto:
        print('  %-11s %-16s %-14s -> %-28s (%d자)'
              % (r[0].split('_')[0], r[2], r[4][:12], r[6], r[7]))
    print('\n검토 필요 %d건:' % len(review))
    for r in review:
        print('  %-11s %-16s %-14s -> %s  [%s]'
              % (r[0].split('_')[0], r[2], r[4][:12], r[6], r[8]))
    if a == '--apply':
        auto = auto + manual_rows(conn, dicts)
        nu, nl = apply(conn, dicts, auto)
        print('\n적용: 새 유닛 %d · 새 링크 %d' % (nu, nl))
        status(conn)
    conn.close()
