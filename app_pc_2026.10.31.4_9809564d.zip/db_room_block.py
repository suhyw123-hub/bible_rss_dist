# -*- coding: utf-8 -*-
"""db_room_block.py — 공동체 방 **취소 목록**(최종관리자 · 영구, 2026-09-08).

설계 = `정책자료/0.교회묵상.txt` §6-0 「차단 — 사후에 한다」 · §9-b ⓐ.
자동승인이므로 미리 막지 않는다. 문제가 생기면 **그 방 번호**를 여기 적는다.

★★★ **무엇이 막히나 — 정확히.** 목록은 `sys_config['ROOM_BLOCKLIST']` 에 살고
  **코어팩**으로 사용자에게 간다. 앱은 그 방의 화면(함께 묵상·올리기·받기·
  방 관리)을 **열지 않고 사유를 말한다.** 그뿐이다 — 폴더는 그 공동체 것이라
  파일은 남고, 동기화 클라이언트로 그대로 읽힌다. **자물쇠가 아니라 문패.**
  실제로 지키는 것은 책임 선언 + 방장 연락처(등록 신고)다.
⚠ 방 번호는 **등록 신고**(Q&A 문의 본문 「방 번호:」)에서 얻는다 — 신고를
  안 한 방(연락처를 안 적은 방)은 번호를 알 길이 없어 막을 수 없다. 그것도
  이 장치의 한계로 적어 둔다.

사용:  python db_room_block.py --list | --add <room_id> "<사유>" | --remove <room_id> | --selftest
"""
import json
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

KEY = 'ROOM_BLOCKLIST'


def _now():
    return datetime.now().strftime('%Y-%m-%d %H:%M')


def load(conn):
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (KEY,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save(conn, d):
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key,config_val) "
                 "VALUES(?,?)", (KEY, json.dumps(d, ensure_ascii=False)))
    conn.commit()


def add(conn, room_id, reason, note=''):
    """막는다 → 목록. ⚠ 사유 없이는 못 막는다 — 사용자에게 보이는 글이다."""
    rid = str(room_id or '').strip()
    why = (reason or '').strip()
    if not rid:
        raise ValueError('EMPTY_ROOM')
    if not why:
        raise ValueError('EMPTY_REASON')
    d = load(conn)
    d[rid] = {'reason': why, 'at': _now(), 'note': (note or '').strip()}
    save(conn, d)
    return d


def remove(conn, room_id):
    d = load(conn)
    if str(room_id) in d:
        del d[str(room_id)]
        save(conn, d)
        return True
    return False


def rows(conn):
    """화면용 → `[(room_id, reason, at, note)]` 최근 것부터."""
    d = load(conn)
    out = [(k, (v or {}).get('reason', ''), (v or {}).get('at', ''),
            (v or {}).get('note', '')) for k, v in d.items()]
    out.sort(key=lambda x: x[2], reverse=True)
    return out


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
    t('  비면 빈 dict', load(c) == {})
    try:
        add(c, 'r1', '')
        t('★ 사유 없이는 못 막는다', False)
    except ValueError as e:
        t('★ 사유 없이는 못 막는다', 'EMPTY_REASON' in str(e))
    add(c, 'r1', '저작권 침해 신고')
    t('★ 막으면 목록에 든다', 'r1' in load(c) and load(c)['r1']['reason'] == '저작권 침해 신고')
    import room_core as RC
    t('★★ 앱 쪽 판정(`room_core.blocked`)이 같은 열쇠를 읽는다',
      RC.blocked(c, 'r1') == '저작권 침해 신고' and RC.BLOCK_KEY == KEY)
    t('  안 막힌 방은 None', RC.blocked(c, 'r2') is None)
    t('  화면용 줄', rows(c)[0][0] == 'r1')
    t('★ 풀면 사라진다', remove(c, 'r1') and load(c) == {} and not remove(c, 'r1'))
    t('  sys_config 는 코어팩(CORE)이다',
      __import__('db_pack_catalog').TABLES['sys_config'][0] == 'CORE')
    print('db_room_block selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if '--add' in a:
        i = a.index('--add')
        add(conn, a[i + 1], a[i + 2] if len(a) > i + 2 else '')
        print('막음:', a[i + 1])
    elif '--remove' in a:
        print('풀음:', remove(conn, a[a.index('--remove') + 1]))
    for r in rows(conn):
        print('  %s  %s  (%s) %s' % r)
    if not rows(conn):
        print('  막힌 방 없음')
