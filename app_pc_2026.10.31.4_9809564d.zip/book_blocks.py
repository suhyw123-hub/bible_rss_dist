# -*- coding: utf-8 -*-
"""book_blocks.py — 도서 본문을 **덩어리로 가른다** (2026-08-28 신설·영구).

★★★ 왜 (사용자 지시): 「시, 인용구절 — 인덴트를 넣어서 사용자가 보기에
  본문과 구별 가능하도록 할 수 있는가」.

  실측으로 드러난 것 — **시는 문단 안에 들어 있다.** 빈 줄로 나뉜 문단이
  아니라 산문 줄 사이에 끼어 있다(스펄전 아침과저녁):

      The apostle John was privileged to look within the gates of heaven…
      "Not all the harps above          ← 여기부터
      Can make a heavenly place,
      If God his residence remove,
      Or but conceal his face."          ← 여기까지가 시
      All thou needest to make thee blessed…

  ⇒ **문단이 아니라 줄 단위로 본다.** 짧은 줄이 둘 이상 잇달면 운문이다.

**글자를 건드리지 않는다.** 공백을 넣어 들여쓰는 것이 아니라 화면이
  `lmargin1/lmargin2` 로 그린다. 그래야
    · 줄이 접혀도 둘째 줄부터 들여쓰기가 살고
    · 밑줄·메모의 닻(고른 글 자체)이 어긋나지 않으며
    · 검색·복사에 군더더기 공백이 안 섞인다.

실측 (2026-08-28) — 운문 덩어리 / 그런 유닛
      SPURGEON_ME 129 / 120편(732)   MILLER_CYA 35 / 35(423)
      SPURGEON_TOD  5 /   5(150)     PASCAL 3 / 3(172)
      CLEMENT_1ST   1 /   1( 66)     MEYER_ODH 0 / 0(1,373)
  ⚠ 마이어가 0인 것은 판정이 실패한 것이 아니라 **그 책에 운문이 없기**
    때문이다(묵상 산문집). 스펄전에 몰려 있는 것이 맞다.

⚠ **강제 줄바꿈 책에 쓰기 전에 편다**(`db_book_split --unwrap`). 안 그러면
  문단 끝의 짧은 꼬리 줄이 운문으로 잘못 잡힐 수 있다. 지금은 잇단 두 줄을
  요구하므로 꼬리 한 줄은 안 걸리지만, 여백을 남기지 않는다.

    python book_blocks.py --selftest     (의무)
"""
import sys

#: 이보다 짧은 줄은 운문 줄 후보 (실측 — 산문 한 줄은 174~651자, 운문은 25~45자)
VERSE_LINE = 48

#: 운문으로 보려면 짧은 줄이 몇 줄 잇달아야 하나
VERSE_MIN = 2


def blocks(text):
    """본문 → `[(갈래, 글)]`. 갈래는 `'body'` 또는 `'poem'`.

    ⚠ 글자는 그대로다 — 합치면 원문이 나온다(selftest 가 잰다).
    """
    out, run = [], []

    def flush_run():
        if len(run) >= VERSE_MIN:
            out.append(('poem', '\n'.join(run)))
        elif run:
            out.append(('body', '\n'.join(run)))
        del run[:]

    def add_body(s):
        if out and out[-1][0] == 'body':
            out[-1] = ('body', out[-1][1] + '\n' + s)
        else:
            out.append(('body', s))

    for ln in (text or '').split('\n'):
        s = ln.strip()
        if s and len(s) < VERSE_LINE:
            run.append(ln)
            continue
        # 긴 줄이나 빈 줄을 만났다 — 모아 둔 짧은 줄을 결산한다
        if len(run) >= VERSE_MIN:
            out.append(('poem', '\n'.join(run)))
            del run[:]
        elif run:
            for r in run:
                add_body(r)
            del run[:]
        add_body(ln)
    if len(run) >= VERSE_MIN:
        out.append(('poem', '\n'.join(run)))
    else:
        for r in run:
            add_body(r)
    return out


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    src = ('The apostle John was privileged to look within the gates of '
           'heaven, and in describing what he saw, he begins by saying.\n'
           '"Not all the harps above\n'
           'Can make a heavenly place,\n'
           'If God his residence remove,\n'
           'Or but conceal his face."\n'
           'All thou needest to make thee blessed is to be with Christ.')
    bs = blocks(src)
    t('★ 문단 안의 시를 갈라낸다 (%d덩어리)' % len(bs),
      [k for k, _ in bs] == ['body', 'poem', 'body'], [k for k, _ in bs])
    t('   시 4줄이 한 덩어리',
      bs[1][1].count('\n') == 3, repr(bs[1][1][:30]))
    t('★★ 글자 손실 없음 — 합치면 원문',
      '\n'.join(b for _k, b in bs) == src)

    # ⚠ 산문 한 줄짜리 책(마이어·클레멘트)은 아무것도 안 걸려야 한다
    prose = ('A' * 300 + '\n\n' + 'B' * 400)
    t('★ 긴 산문은 건드리지 않는다',
      [k for k, _ in blocks(prose)] == ['body'], blocks(prose)[0][0])

    # ⚠ 짧은 줄 **하나**는 운문이 아니다 (문단 꼬리·소제목)
    tail = ('C' * 300 + '\nShort tail.\n' + 'D' * 300)
    t('★ 짧은 줄 하나는 운문이 아니다',
      [k for k, _ in blocks(tail)] == ['body'], [k for k, _ in blocks(tail)])
    t('   그래도 글자는 남는다',
      'Short tail.' in blocks(tail)[0][1])

    # ⚠ 시로 시작하고 시로 끝나는 글
    both = ('Roses are red,\nviolets are blue.\n' + 'E' * 200 +
            '\nSugar is sweet,\nand so are you.')
    t('★ 처음과 끝의 시도 잡는다',
      [k for k, _ in blocks(both)] == ['poem', 'body', 'poem'],
      [k for k, _ in blocks(both)])
    t('   글자 손실 없음',
      '\n'.join(b for _k, b in blocks(both)) == both)

    t('빈 글은 빈 목록', blocks('') == [('body', '')] or blocks('') == [],
      blocks(''))

    # 실DB — 판정이 실제로 걸리는가
    try:
        import appdb
        conn = appdb.connect()
        rows = [r[0] for r in conn.execute(
            "SELECT x.body_text FROM sys_book_asset b "
            "JOIN sys_book_unit u ON u.book_id=b.book_id "
            "JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
            "  AND x.text_variant='ORIGINAL' "
            "WHERE b.book_code='SPURGEON_ME'")]
        conn.close()
        n = sum(1 for tx in rows for k, _b in blocks(tx) if k == 'poem')
        t('실DB — 스펄전 아침과저녁 운문 덩어리 (%d개)' % n, n > 100, n)
        keep = all('\n'.join(b for _k, b in blocks(tx)) == tx
                   for tx in rows[:200])
        t('실DB — 글자 손실 0 (200편)', keep)
    except Exception as e:
        t('실DB 확인', False, e)

    print('book_blocks selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        raise SystemExit(0 if selftest() else 1)
    print(__doc__)
