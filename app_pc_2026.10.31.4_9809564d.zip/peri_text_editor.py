"""
peri_text_editor.py
페리코프(구절단락) 텍스트 편집기 (v5 — 2026-09-19, 1.txt 3번 사용자 지시).

[v5 변경 — 전부 사용자 지시 1.txt 3번]
  1) **타입 · 책 차례를 바꿨다** — 타입이 정해져야 책 목록이 정해진다.
     화면 글자에서 **코드를 걷었다**: `BOTH/TITLE/DESC` → 「제목+설명문 /
     제목만 / 설명문만」, `PERI_TITLE/PERI_DESC` → 「페리코프 제목 /
     페리코프 설명문」, `BODY/CHRONOLOGICAL` → 「본문 단락 / 연대기 단락」.
  3) **NONE 표지를 걷었다** — 실측 **0건**이다(아래 ★). 없는 상태를 위해
     표지를 만들어 둘 까닭이 없다.
  4) **[사용방법] 단추**(맨 오른쪽 · `panel_help_box.help_btn`).
  5) **역본을 언어에서 떼어 냈다** — 구절 본문은 **한 벌**이고 그 위에
     역본 콤보 하나. 언어를 바꿔도 역본이 안 바뀐다.
     · 참고/편집 **언어 콤보는 제목·설명문 칸 머리**로 내려갔다.
     · **좌우 대비는 제목·설명문만** 한다(구절 본문은 어느 역본을 골라도
       같은 단락이라 두 벌로 볼 까닭이 없다 — 사용자 판단).
     · 언어 보유 라벨을 눌러도 **구절 본문은 안 바뀐다**(옛 판은 편집 언어가
       역본을 끌고 다녀 본문까지 갈아 끼웠다).
     · **책 콤보는 관리자 언어로 고정**(편집 언어를 아랍어로 바꾸면 책 이름이
       아랍어가 되던 자리 — 「관리자는 나 한명 뿐이다」).
     · 구절 본문 칸을 줄였다(14줄 → 8줄 · 사시로 조절).
  6) 자산 연결 — **팝업 단추를 걷고 「연결」 탭**으로(`panel_std.link_tab`).
  7) **「번역현황」 탭** 신설 — 고른 **책 단위**로 언어 × (제목·설명문).

★★★ **실측이 물음 둘에 답한다**(2026-09-19 · 전수):
  | 타입 | 단락 | 제목+설명문 | 제목만 | 설명문만 | 없음 |
  |---|---|---|---|---|---|
  | 본문 단락 | 3,061 | KO·EN 1,443 | KO·EN 1,618 · **그 밖 9언어 3,061** | **0** | **0** |
  | 연대기 단락 | 352 | KO 189 | KO 163 · 그 밖 10언어 352 | **0** | **0** |
  ⓐ **「제목만」이 정상 상태다**(물음 2) — 설명문이 있으면 안 되는 자리가
    아니라 **아직 안 쓴 것**이다. 설명문은 KO·EN 에만 있고 본문 단락의
    47% 뿐이다.
  ⓑ **「없음」도 「설명문만」도 한 건도 없다**(물음 3) — 모든 단락이 열한
    언어 전부에 제목을 갖고 있다. 그래서 NONE 표지를 걷었다.

[구조]
  상단 줄 : 타입 · 책 … [사용방법]
  왼쪽    : 페리코프 목록 (제목+설명문 / 제목만 / 설명문만)
  오른쪽  : 노트북 — 제목·설명문 / 번역현황 / 연결
            제목·설명문 탭 = 사시(세로)
              위  : [본문] [역본 ▾]        구절 본문 한 벌
              아래: 언어 보유 라벨 줄 + 좌우 대비(참고 | 수정)
"""

import os
import sys
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — 차례는 `sort_order` 다.
import verse_range as _vr
import appdb
# ⚠ 이 파일은 **앱 뿌리**에 있고 관리자 부품은 `admin/` 에 있다 — 부르는 곳은
#   관리자(`admin/panel_peri_editor`) 하나지만 뿌리에서 바로 띄울 수도
#   있으므로 **막히면 옛 모습으로 떨어진다**(조용히 안 죽는다).
try:
    import lang_ui as _lu          # 언어 콤보 = 영어 이름(값은 코드)
except Exception:
    _lu = None
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'admin'))
try:
    from admin.lang_badge import LangBadgeRow
except Exception:            # 팝업 단독 실행 등 경로 변형 대비
    from lang_badge import LangBadgeRow
try:
    from admin import panel_std as _std
except Exception:
    try:
        import panel_std as _std
    except Exception:
        _std = None
try:
    from admin import panel_help_box as _help
except Exception:
    try:
        import panel_help_box as _help
    except Exception:
        _help = None

_REF_NONE = '(없음)'

#: 단락 타입 — **화면에는 사람 말로**(1.txt 3-1 「코드를 쓰지 말라」)
TYPE_LABEL = (('BODY', '본문 단락'), ('CHRONOLOGICAL', '연대기 단락'))

#: 목록 보유 표지 — 옛 `BOTH/TITLE/DESC/NONE` 을 사람 말로 바꿨다.
#  ⚠ **「없음」을 안 만든다**(1.txt 3-3) — 실측 0건이다. 정말 0건이 되면
#    표지 칸이 빈다(그 자리에 없는 상태를 위한 이름을 지어내지 않는다).
FLAG_BOTH, FLAG_TITLE, FLAG_DESC = '제목+설명문', '제목만', '설명문만'

_VERSE_H = 8     # 구절 본문 — 사용자 「페리코프 화면이 너무 크다」(옛 14)
_DESC_H = 8      # 페리코프 설명문

HELP_SECTIONS = [
    ('이 화면이 하는 일',
     '성경을 **구절단락(페리코프)** 으로 나눠 놓은 3,413개 단락에 '
     '**제목**과 **설명문**을 언어마다 써 넣는 자리다.\n'
     '· **페리코프 제목**(`PERI_TITLE`) — 사용자 화면에서 단락 머리에 뜨는 한 줄.\n'
     '· **페리코프 설명문**(`PERI_DESC`) — P2 「설명」 탭의 **단락설명** 모드 본문.\n'
     '⚠ 구절 하나하나의 설명문(절 설명문)은 **다른 화면**(성경구절 관리)이다.'),
    ('단락 타입 둘',
     '**본문 단락** — 성경 전체를 빈틈없이 덮는 3,061개. 사용자 화면의 '
     '단락설명이 이것을 읽는다.\n'
     '**연대기 단락** — 사건을 일어난 차례로 묶은 352개. 복음서 대조·'
     '연대기 통독이 쓴다.\n'
     '⚠ 타입을 바꾸면 **책 목록이 달라진다** — 그래서 타입 콤보가 책 콤보보다 앞에 있다.'),
    ('목록의 보유 표지',
     '**제목+설명문** 둘 다 그 언어로 있다.\n'
     '**제목만** 제목은 있고 설명문은 아직 안 썼다 — **이것이 정상 상태다.** '
     '실측 본문 단락 3,061개 중 1,618개(53%)가 여기 있고, 설명문은 한국어·'
     '영어에만 있다.\n'
     '**설명문만** 제목 없이 설명문만 있는 자리 — 실측 **0건**이다.\n'
     '⚠ 표지는 **편집 언어 기준**이다. 편집 언어를 바꾸면 목록 표지가 함께 바뀐다.'),
    ('구절 본문과 역본',
     '위 칸은 그 단락의 **성경 본문**이고 **참고용**이다(고칠 수 없다).\n'
     '· **역본 콤보는 언어와 따로 논다** — 편집 언어를 아랍어로 바꿔도 본문은 '
     '선택한 역본 그대로다. 아랍어 본문을 보고 싶으면 역본을 아랍어 역본으로 선택한다.\n'
     '· 본문 칸과 아래 제목·설명문 칸 사이의 **경계선을 끌어** 높이를 나눌 수 있다.\n'
     '⚠ 신약만·구약만 담은 역본(원문 성경 등)을 선택하면 그 범위 밖에서는 '
     '「이 역본에 해당 구절 없음」이 뜬다 — 고장이 아니다.'),
    ('참고 언어 · 편집 언어',
     '**왼쪽이 참고(읽기 전용) · 오른쪽이 수정**이다 — 관리자 전 화면 공통 자리.\n'
     '한국어 설명문을 보면서 아랍어로 옮겨 적는 식으로 쓴다.\n'
     '· 참고 언어를 「(없음)」으로 두면 왼쪽 칸이 비고 **오른쪽만 넓게** 쓴다.\n'
     '· **언어 보유 라벨** — 그 단락의 제목·설명문이 어느 언어로 있는지 한눈에. '
     '색이 든 라벨 = 있음 · 회색 = 없음 · 밑줄 = 지금 편집 언어. '
     '라벨을 누르면 **편집 언어만** 그리로 바뀐다(구절 본문은 그대로).'),
    ('저장 규칙',
     '[저장] 은 **지금 편집 언어의 제목과 설명문을 함께** 쓴다.\n'
     '⚠ 칸을 비우고 저장하면 그 언어의 그 글을 **숨긴다**(지우지 않는다). '
     '다시 써 넣으면 그 행이 되살아나므로 숨은 행이 쌓이지 않는다.\n'
     '[지우기] 는 **화면의 입력칸만** 비운다 — DB 는 안 건드린다. '
     '실제로 지우려면 비운 뒤 [저장] 을 누른다.'),
    ('번역현황 탭',
     '**선택한 책 한 권**을 언어 × (제목 · 설명문)으로 센다 — `3061/3061` 꼴.\n'
     '언어 줄을 두 번 누르면 **편집 언어가 그 언어로 바뀌고** 제목·설명문 탭으로 간다.'),
    ('연결 탭',
     '이 단락에 붙은 다른 자산(주요용어 · 영상 · 연구자료 …)을 잇고 끊는다. '
     '실측 단락 연결은 **7,089건**(용어 1,621 · 영상 5,441)이다.\n'
     '⚠ 먼저 왼쪽 목록에서 단락을 선택해야 한다.'),
]


def open_peri_text_popup(parent, db_path, lang: str = 'KO',
                          initial_peri_id: int | None = None):
    win = tk.Toplevel(parent)
    win.title("구절단락 편집기")
    win.geometry("1280x900")
    win.resizable(True, True)
    win.minsize(1020, 700)
    ed = PeriTextEditor(win, db_path,
                        lang_getter=lambda: lang,
                        initial_peri_id=initial_peri_id)
    ed.pack(expand=True, fill='both')
    win.grab_set()
    return win


class PeriTextEditor(ttk.Frame):

    def __init__(self, parent, db_path,
                 lang_getter=None,
                 initial_peri_id: int | None = None):
        super().__init__(parent)
        self._db = str(db_path)
        self._lang_getter = lang_getter or (lambda: 'KO')
        self._init_peri_id = initial_peri_id

        init_edit = self._lang_getter() or 'KO'
        init_ref = 'EN' if init_edit != 'EN' else 'KO'
        self._edit_lang = tk.StringVar(value=init_edit)
        self._ref_lang = tk.StringVar(value=init_ref)
        self._peri_type = tk.StringVar(value='BODY')
        self._type_disp = tk.StringVar(value=TYPE_LABEL[0][1])

        # ★ 역본은 **언어와 따로 논다**(1.txt 3-5) — 언어를 바꿔도 안 바뀐다.
        self._ver = tk.StringVar(value='')

        self._versions: list[tuple] = []      # (code, lang, 표시이름)
        #: 제목·설명문을 쓰는 언어 = **UI 언어**(`sys_language`).
        #  ⚠ 역본의 언어 목록과 섞지 말 것 — 역본이 없는 언어(일본어·독일어…)
        #    에도 제목·설명문은 쓴다.
        self._all_langs: list[str] = self._ui_langs()

        self._books: list[tuple] = []
        self._pericopes: list[tuple] = []
        self._flags: dict[int, str] = {}
        self._cur_peri: int | None = None
        self._cur_range: str = ''
        self._dirty: bool = False

        self._load_versions()
        self._build()
        self._load_books()

    # ─────────────────────────── 버전 메타 ───────────────────────────

    def _ui_langs(self) -> list[str]:
        try:
            import lang_config
            out = [str(c).upper() for c in lang_config.ui_langs()]
            if out:
                return out
        except Exception as e:
            print('[peri langs] %s' % e)
        return ['KO', 'EN']

    def _load_versions(self):
        try:
            conn = appdb.connect(self._db)
            rows = conn.execute(
                "SELECT version_code, lang_code, "
                "       COALESCE(display_name, version_name, version_code) "
                "  FROM bible_version ORDER BY lang_code, version_code"
            ).fetchall()
            conn.close()
        except Exception:
            rows = []
        self._versions = [(r[0], (r[1] or '').upper(), r[2] or r[0])
                          for r in rows]

    def _ver_items(self) -> list[str]:
        """역본 콤보 글자 — **코드가 앞**(§269차 `_vname` 과 같은 규칙)."""
        return ['%s · %s' % (c, n) for c, _lg, n in self._versions]

    def _ver_code(self) -> str:
        s = self._ver.get()
        return s.split(' · ', 1)[0].strip() if s else ''

    def _default_ver(self) -> str:
        """처음 값 = 관리자 언어의 역본 → BSB → 첫째."""
        admin = (self._lang_getter() or 'KO').upper()
        for c, lg, n in self._versions:
            if lg == admin:
                return '%s · %s' % (c, n)
        for c, lg, n in self._versions:
            if c == 'BSB':
                return '%s · %s' % (c, n)
        return self._ver_items()[0] if self._versions else ''

    # ═════════════════════════════ BUILD ════════════════════════════════════

    def _build(self):
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)
        self._build_topbar()
        self._build_main()

    def _build_topbar(self):
        top = ttk.Frame(self)
        top.grid(row=0, column=0, sticky='ew', padx=8, pady=6)

        # ★ 1.txt 3-1 — **타입이 먼저, 책이 나중**(타입이 책 목록을 정한다)
        ttk.Label(top, text="단락 타입").pack(side='left', padx=(0, 4))
        type_cb = ttk.Combobox(top, textvariable=self._type_disp,
                               values=[n for _c, n in TYPE_LABEL],
                               state='readonly', width=12)
        type_cb.pack(side='left', padx=(0, 14))
        type_cb.bind('<<ComboboxSelected>>', lambda e: self._on_type_changed())

        ttk.Label(top, text="책").pack(side='left', padx=(0, 4))
        self._book_cb = ttk.Combobox(top, state='readonly', width=16)
        self._book_cb.pack(side='left', padx=(0, 10))
        self._book_cb.bind('<<ComboboxSelected>>',
                           lambda e: self._on_book_changed())

        # ★ 사용방법은 **그 줄 맨 오른쪽**(§241차 ㉔)
        if _help is not None:
            try:
                _help.help_btn(top, '구절단락 편집기 — 사용방법', HELP_SECTIONS)
            except Exception as e:
                print('[peri help] %s' % e)

    def _on_type_changed(self):
        disp = self._type_disp.get()
        for code, name in TYPE_LABEL:
            if name == disp:
                self._peri_type.set(code)
                break
        self._load_books()

    # ── 메인 레이아웃 ─────────────────────────────────────────────────────────

    def _build_main(self):
        main = ttk.Frame(self)
        main.grid(row=1, column=0, sticky='nsew', padx=6, pady=(0, 4))
        main.grid_rowconfigure(0, weight=1)
        main.grid_columnconfigure(1, weight=1)
        self._build_listpanel(main)

        # ★ 1.txt 3-6·3-7 — 팝업을 걷고 **관리자 표준 탭**으로.
        #   ⚠ 「본문」이라는 표준 이름을 쓰지 않는다 — 이 화면에서 「본문」은
        #     고칠 수 없는 성경 구절이라 뜻이 정반대로 읽힌다.
        nb = ttk.Notebook(main)
        nb.grid(row=0, column=1, sticky='nsew')
        self._nb = nb
        if _std is not None:
            self._tabs = _std.build(nb, {'TEXT': '제목·설명문',
                                         'TRANS': None, 'LINK': None})
        else:                       # panel_std 를 못 읽어도 편집은 된다
            f = ttk.Frame(nb)
            nb.add(f, text=' 제목·설명문 ')
            self._tabs = {'TEXT': f}

        self._build_edit_tab(self._tabs['TEXT'])
        if 'TRANS' in self._tabs:
            self._build_trans_tab(self._tabs['TRANS'])
        if 'LINK' in self._tabs:
            self._build_link_tab(self._tabs['LINK'])

    # ── 왼쪽: 페리코프 목록 ───────────────────────────────────────────────────

    def _build_listpanel(self, parent):
        left = ttk.Frame(parent, width=248)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 4))
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)
        left.grid_propagate(False)

        hdr = ttk.Frame(left)
        hdr.grid(row=0, column=0, columnspan=2, sticky='ew', pady=(2, 2), padx=4)
        ttk.Label(hdr, text="구절단락 목록",
                   font=('', 10, 'bold')).pack(side='left')
        self._lbl_count = ttk.Label(hdr, text="")
        self._lbl_count.pack(side='right')

        self._listbox = tk.Listbox(left,
                                    borderwidth=1, highlightthickness=0,
                                    relief='solid', activestyle='none')
        self._listbox.grid(row=1, column=0, sticky='nsew', padx=(4, 0))
        sb = ttk.Scrollbar(left, orient='vertical',
                            command=self._listbox.yview)
        sb.grid(row=1, column=1, sticky='ns')
        self._listbox.configure(yscrollcommand=sb.set)
        self._listbox.bind('<<ListboxSelect>>', self._on_peri_select)

        leg = ttk.Frame(left)
        leg.grid(row=2, column=0, columnspan=2, sticky='ew',
                  padx=4, pady=(2, 4))
        ttk.Label(leg, text="편집 언어 기준 보유 — 제목+설명문 / 제목만 / 설명문만",
                   font=('', 8), wraplength=238, justify='left'
                   ).pack(side='left')

    # ── 제목·설명문 탭 ────────────────────────────────────────────────────────

    def _build_edit_tab(self, parent):
        parent.grid_rowconfigure(0, weight=1)
        parent.grid_columnconfigure(0, weight=1)

        vp = ttk.PanedWindow(parent, orient='vertical')
        vp.grid(row=0, column=0, sticky='nsew', padx=4, pady=4)

        # ── 위: 구절 본문 한 벌 + 역본 콤보 ──────────────────────────────
        top_f = ttk.Frame(vp)
        vp.add(top_f, weight=1)
        vbar = ttk.Frame(top_f)
        vbar.pack(fill='x', pady=(0, 2))
        ttk.Label(vbar, text="구절 본문 (참고)",
                   font=('', 10, 'bold')).pack(side='left')
        ttk.Label(vbar, text="역본").pack(side='left', padx=(12, 4))
        self._ver_cb = ttk.Combobox(vbar, textvariable=self._ver,
                                    state='readonly', width=26)
        self._ver_cb['values'] = self._ver_items()
        self._ver.set(self._default_ver())
        self._ver_cb.pack(side='left')
        self._ver_cb.bind('<<ComboboxSelected>>', lambda e: self._reload_verses())
        self._lbl_range = ttk.Label(vbar, text='', font=('', 9))
        self._lbl_range.pack(side='right')

        self._verse_box = scrolledtext.ScrolledText(
            top_f, font=('Malgun Gothic', 10), height=_VERSE_H,
            wrap='word', state='disabled', padx=6, pady=4,
            borderwidth=1, relief='solid')
        self._verse_box.pack(fill='both', expand=True)

        # ── 아래: 언어 보유 라벨 + 좌우 대비(제목·설명문만) ───────────────
        bot_f = ttk.Frame(vp)
        vp.add(bot_f, weight=2)

        badge_f = ttk.Frame(bot_f)
        badge_f.pack(fill='x', pady=(2, 4))
        ttk.Label(badge_f, text="언어 보유", font=('', 9, 'bold')
                   ).pack(side='left', padx=(2, 8))
        self._badge_row = LangBadgeRow(badge_f, db_path=self._db,
                                       on_pick=self._on_badge_pick,
                                       per_row=11)
        self._badge_row.pack(side='left')

        pw = ttk.PanedWindow(bot_f, orient='horizontal')
        pw.pack(fill='both', expand=True)
        ref_f = ttk.Frame(pw)
        pw.add(ref_f, weight=1)
        self._ref_side = self._build_text_side(ref_f, role='ref')
        edit_f = ttk.Frame(pw)
        pw.add(edit_f, weight=1)
        self._edit_side = self._build_text_side(edit_f, role='edit')

    def _build_text_side(self, parent, role: str):
        """한 쪽 = 머리줄(언어 콤보 · 저장) + 페리코프 제목 + 페리코프 설명문."""
        parent.grid_columnconfigure(0, weight=1)
        parent.grid_rowconfigure(2, weight=1)
        readonly = (role == 'ref')

        # ★ 1.txt 3-5 — **언어 콤보가 제목·설명문 칸 머리에** 있다.
        hdr = ttk.Frame(parent)
        hdr.grid(row=0, column=0, sticky='ew', padx=2, pady=(0, 2))
        if readonly:
            ttk.Label(hdr, text="참고 언어", font=('', 9, 'bold')
                       ).pack(side='left', padx=(2, 4))
            cb = (_lu.name_combo(hdr, self._ref_lang, codes_=self._all_langs,
                                 extra=[(_REF_NONE, _REF_NONE)], width=15)
                  if _lu else ttk.Combobox(
                      hdr, textvariable=self._ref_lang,
                      values=[_REF_NONE] + self._all_langs,
                      state='readonly', width=10))
            cb.pack(side='left')
            cb.bind('<<ComboboxSelected>>', lambda e: self._on_ref_lang_changed())
            self._ref_cb = cb
        else:
            ttk.Label(hdr, text="편집 언어", font=('', 9, 'bold')
                       ).pack(side='left', padx=(2, 4))
            cb = (_lu.name_combo(hdr, self._edit_lang, codes_=self._all_langs,
                                 width=15) if _lu else ttk.Combobox(
                      hdr, textvariable=self._edit_lang,
                      values=self._all_langs, state='readonly', width=10))
            cb.pack(side='left')
            cb.bind('<<ComboboxSelected>>', lambda e: self._on_edit_lang_changed())
            self._edit_cb = cb
            # 단추는 **먼저 담아야 오른쪽 끝**에 선다(§238차 ⑥)
            ttk.Button(hdr, text="저장", command=self._save
                        ).pack(side='right', padx=(6, 2))
            ttk.Button(hdr, text="입력칸 비우기", command=self._clear_confirm
                        ).pack(side='right')
            self._lbl_status = ttk.Label(hdr, text="")
            self._lbl_status.pack(side='right', padx=8)

        # 페리코프 제목 — **코드 이름을 쓰지 않는다**(1.txt 3-1)
        t_row = ttk.Frame(parent)
        t_row.grid(row=1, column=0, sticky='ew', padx=2, pady=(2, 0))
        ttk.Label(t_row, text="페리코프 제목",
                   font=('', 9, 'bold')).pack(side='left', padx=(2, 6))
        if readonly:
            title_ent = ttk.Entry(t_row, font=('Malgun Gothic', 10),
                                    state='disabled')
        else:
            title_ent = ttk.Entry(t_row, font=('Malgun Gothic', 10))
            title_ent.bind('<KeyRelease>', lambda e: self._mark_dirty())
        title_ent.pack(side='left', fill='x', expand=True, padx=(0, 2))

        # 페리코프 설명문
        d_f = ttk.Frame(parent)
        d_f.grid(row=2, column=0, sticky='nsew', padx=2, pady=(4, 2))
        ttk.Label(d_f, text="페리코프 설명문",
                   font=('', 9, 'bold')).pack(anchor='w', padx=2)
        desc_box = scrolledtext.ScrolledText(
            d_f, font=('Malgun Gothic', 10),
            height=_DESC_H, wrap='word',
            padx=6, pady=4, borderwidth=1, relief='solid',
            state='disabled' if readonly else 'normal')
        desc_box.pack(fill='both', expand=True, pady=(2, 0))
        if not readonly:
            desc_box.bind('<KeyRelease>', lambda e: self._mark_dirty())

        return {'role': role, 'title_ent': title_ent, 'desc_box': desc_box}

    # ── 번역현황 탭 (1.txt 3-7) ───────────────────────────────────────────────

    def _build_trans_tab(self, parent):
        """**선택한 책 한 권**을 언어 × (제목 · 설명문)으로 센다.

        ⚠ 단락 하나만 세면 늘 `1/1` 이라 볼 것이 없다 — 번역은 책 단위로 돈다.
        """
        self._trans_tbl = _std.translation_tab(
            parent,
            columns=[('title', '페리코프 제목', 130),
                     ('desc', '페리코프 설명문', 130)],
            provider=self._lang_counts,
            on_pick=self._pick_lang_from_trans,
            hint='지금 선택한 책의 단락 전체를 셉니다. 언어를 두 번 누르면 '
                 '편집 언어가 그 언어로 바뀌고 제목·설명문 탭으로 갑니다.')

    def _lang_counts(self, lang):
        """그 언어로 무엇이 채워졌나 → `{칸: (된 수, 그 책 단락 수)}`."""
        pids = [p[0] for p in self._pericopes]
        total = len(pids)
        if not total:
            return {}
        ph = ','.join('?' * total)
        try:
            conn = self._conn()
            rows = conn.execute(
                "SELECT text_type, COUNT(DISTINCT clicked_id) "
                "  FROM sys_text_asset "
                " WHERE text_type IN ('PERI_TITLE','PERI_DESC') "
                "   AND record_status='LIVE' AND UPPER(lang_code)=UPPER(?) "
                "   AND clicked_id IN (%s) GROUP BY text_type" % ph,
                [lang] + pids).fetchall()
            conn.close()
        except Exception as e:
            print('[peri trans] %s' % e)
            return {}
        got = {t: n for t, n in rows}
        return {'title': (got.get('PERI_TITLE', 0), total),
                'desc': (got.get('PERI_DESC', 0), total)}

    def _pick_lang_from_trans(self, lang):
        self._edit_lang.set((lang or '').upper())
        self._on_edit_lang_changed()
        try:
            self._nb.select(self._tabs['TEXT'])
        except Exception:
            pass

    def _refresh_trans(self):
        tbl = getattr(self, '_trans_tbl', None)
        if tbl is not None:
            try:
                tbl.refresh()
            except Exception as e:
                print('[peri trans refresh] %s' % e)

    # ── 연결 탭 (1.txt 3-6) ───────────────────────────────────────────────────

    def _build_link_tab(self, parent):
        """★ **팝업을 걷고 탭에 진짜 작업대를 심는다** — 몸통은 같은 부품이라
        두 벌이 아니다(`panel_std.link_tab` → `link_picker.build_workbench`).
        """
        try:
            self._link_tab = _std.link_tab(
                parent,
                owner_getter=lambda: (('PERICOPE', self._cur_peri)
                                      if self._cur_peri else None),
                scope='SYS', db_path=self._db,
                lang_getter=lambda: self._edit_lang.get())
        except Exception as e:
            self._link_tab = None
            ttk.Label(parent, text='연결 작업대를 못 세웠다: %s' % e
                       ).pack(padx=8, pady=8)

    def _refresh_link(self):
        lt = getattr(self, '_link_tab', None)
        if lt is not None:
            try:
                lt.refresh()
            except Exception as e:
                print('[peri link refresh] %s' % e)

    # ── 언어 보유 라벨 ────────────────────────────────────────────────────────

    def _on_badge_pick(self, code: str):
        """언어 보유 라벨 클릭 = **편집 언어만** 전환(구절 본문은 그대로)."""
        if code == self._edit_lang.get():
            return
        if self._dirty and not messagebox.askyesno(
                "미저장 변경", "변경 내용을 버리고 언어를 바꾸겠습니까?",
                parent=self):
            return
        self._dirty = False
        self._edit_lang.set(code)
        self._on_edit_lang_changed()

    # ═════════════════════════════ EVENTS ════════════════════════════════════

    def _on_edit_lang_changed(self):
        new_edit = self._edit_lang.get()
        if self._ref_lang.get() == new_edit:
            for cand in ('EN', 'KO'):
                if cand != new_edit:
                    self._ref_lang.set(cand)
                    break
        # ⚠ **역본은 안 건드린다**(1.txt 3-5) — 옛 판은 여기서 버전을 갈아
        #   끼워 구절 본문까지 함께 바뀌었다.
        self._load_pericopes()          # 보유 표지가 편집 언어 기준이다
        if self._cur_peri:
            self._load_peri_data(self._cur_peri)
        self._refresh_trans()

    def _on_ref_lang_changed(self):
        if self._cur_peri:
            self._load_peri_data(self._cur_peri)

    def _on_book_changed(self):
        idx = self._book_cb.current()
        if idx >= 0:
            self._load_pericopes(self._books[idx][0])
        self._refresh_trans()

    def _on_peri_select(self, _event=None):
        if self._dirty:
            if not messagebox.askyesno(
                    "미저장 변경", "변경 내용을 버리고 이동하겠습니까?",
                    parent=self):
                return
        sel = self._listbox.curselection()
        if not sel:
            return
        self._load_peri_data(self._pericopes[sel[0]][0])

    def _mark_dirty(self):
        if not self._dirty:
            self._dirty = True
            self._lbl_status.config(text="● 미저장")

    # ═════════════════════════════ DATA ═════════════════════════════════════

    def _conn(self):
        return appdb.connect(self._db)

    def _load_books(self):
        # ★ 1.txt 3-5 — **책 이름은 관리자 언어**다. 편집 언어를 아랍어로
        #   바꿨다고 책 콤보가 아랍어가 되면 관리자가 못 읽는다.
        lang = (self._lang_getter() or 'KO').upper()
        peri_type = self._peri_type.get()
        conn = self._conn()
        rows = conn.execute("""
            SELECT DISTINCT bi.bcode,
                   COALESCE(bn_e.full_name,  bn_en.full_name,  '?') AS full_name,
                   COALESCE(bn_e.short_name, bn_en.short_name, '?') AS short_name
            FROM sys_pericope_asset pa
            JOIN bible_index bi ON bi.verse_id = pa.start_vid
            LEFT JOIN book_names bn_e
                   ON bn_e.book_code = bi.bcode AND bn_e.lang_code = ?
            LEFT JOIN book_names bn_en
                   ON bn_en.book_code = bi.bcode AND bn_en.lang_code = 'EN'
            WHERE pa.peri_type = ?
            ORDER BY bi.bcode
        """, (lang, peri_type)).fetchall()
        conn.close()

        # 타입을 바꿔도 보던 책을 지킨다
        prev_bcode = None
        prev_idx = self._book_cb.current()
        if 0 <= prev_idx < len(self._books):
            prev_bcode = self._books[prev_idx][0]

        self._books = rows
        self._book_cb['values'] = [r[1] if r[1] != '?' else r[2] for r in rows]
        if rows:
            idx = next((i for i, r in enumerate(rows) if r[0] == prev_bcode), 0)
            self._book_cb.current(idx)
            self._load_pericopes(rows[idx][0])
            self._refresh_trans()

    def _load_pericopes(self, bcode: int | None = None):
        if bcode is None:
            idx = self._book_cb.current()
            bcode = self._books[idx][0] if idx >= 0 else None
        if bcode is None:
            return

        peri_type = self._peri_type.get()
        edit_lang = self._edit_lang.get()
        conn = self._conn()

        rows = conn.execute("""
            SELECT pa.pericope_id,
                   s.chapter, s.verse,
                   e.chapter, e.verse
            FROM sys_pericope_asset pa
            JOIN bible_index s ON s.verse_id = pa.start_vid
            JOIN bible_index e ON e.verse_id = pa.end_vid
            WHERE s.bcode = ? AND pa.peri_type = ?
            ORDER BY pa.start_vid
        """, (bcode, peri_type)).fetchall()

        pids = [r[0] for r in rows]
        flags: dict[int, str] = {}
        if pids:
            ph = ','.join('?' * len(pids))
            flag_rows = conn.execute(f"""
                SELECT clicked_id, text_type
                FROM sys_text_asset
                WHERE text_type IN ('PERI_TITLE', 'PERI_DESC')
                  AND lang_code = ?
                  AND clicked_id IN ({ph})
                  AND record_status = 'LIVE'
            """, [edit_lang] + pids).fetchall()
            has: dict[int, set] = {}
            for cid, tt in flag_rows:
                has.setdefault(cid, set()).add(tt)
            for pid, types in has.items():
                if 'PERI_TITLE' in types and 'PERI_DESC' in types:
                    flags[pid] = FLAG_BOTH
                elif 'PERI_TITLE' in types:
                    flags[pid] = FLAG_TITLE
                else:
                    flags[pid] = FLAG_DESC
        conn.close()

        self._pericopes = rows
        self._flags = flags

        self._listbox.delete(0, 'end')
        for pid, sc, sv, ec, ev in rows:
            self._listbox.insert('end', self._list_line(pid, sc, sv, ec, ev))
        self._apply_list_colors()
        n_desc = sum(1 for f in flags.values() if f == FLAG_BOTH)
        self._lbl_count.config(text="%d개 · 설명문 %d" % (len(rows), n_desc))

        # 언어를 바꿔 목록을 다시 지어도 보던 단락 선택을 지킨다
        if self._cur_peri:
            for i, (pid, *_rest) in enumerate(rows):
                if pid == self._cur_peri:
                    self._listbox.selection_set(i)
                    self._listbox.see(i)
                    break

        if self._init_peri_id:
            for i, (pid, *_) in enumerate(rows):
                if pid == self._init_peri_id:
                    self._listbox.selection_set(i)
                    self._listbox.see(i)
                    self._load_peri_data(pid)
                    break
            self._init_peri_id = None

    def _list_line(self, pid, sc, sv, ec, ev) -> str:
        rng = f"{sc}:{sv}-{ev}" if sc == ec else f"{sc}:{sv}-{ec}:{ev}"
        # ⚠ **없는 상태를 위한 이름을 지어내지 않는다**(1.txt 3-3 · 실측 0건)
        return " %-11s  %s" % (rng, self._flags.get(pid, ''))

    def _flag_fg(self, flag):
        """목록 줄 글자색 — 테마 역할에서 그때 읽는다.

        ★ 2026-10-28 docs/1.txt 3 — 다크모드에서 「어떤 글자는 검은색, 어떤 글자는 흰색」이던 까닭:
          줄마다 진한 색(#1E7B3A 등)을 박아 두어 어두운 바탕에서 검게 보였고, 색을 안 단 줄은 테마가 칠한
          흰 글자였다. Listbox 줄 색은 화면 칠하기가 못 본다 — 그래서 역할로 그때 고른다."""
        try:
            import ui_theme as _UT
            # ★ 2026-10-28 (docs/1.txt 3 두 번째) 다른 화면과 같은 글자색 — 상태는 줄 끝 표시가 말한다 · 비어 있는 줄만 흐리게
            role = 'fg' if flag else 'fg_dim'
            c = _UT.C(role)
            if c:
                try:
                    c = _UT.readable(c, self._listbox.cget('bg'), self._listbox) or c
                except Exception:
                    pass
                return c
        except Exception:
            pass
        return '#808080'

    def _apply_list_colors(self):
        for i, (pid, *_) in enumerate(self._pericopes):
            self._listbox.itemconfig(
                i, fg=self._flag_fg(self._flags.get(pid, '')))

    def _load_peri_data(self, peri_id: int):
        self._cur_peri = peri_id

        conn = self._conn()
        meta = conn.execute(
            "SELECT start_vid, end_vid FROM sys_pericope_asset "
            "WHERE pericope_id=?", (peri_id,)).fetchone()
        conn.close()
        if not meta:
            return
        self._cur_sv, self._cur_ev = meta

        self._reload_verses()
        self._load_one_side(self._edit_side, peri_id, self._edit_lang.get())
        ref_lang = self._ref_lang.get()
        if ref_lang and ref_lang != _REF_NONE:
            self._load_one_side(self._ref_side, peri_id, ref_lang)
        else:
            self._clear_side(self._ref_side)

        self._update_lang_badges()
        self._refresh_link()
        self._dirty = False
        self._lbl_status.config(text="")

    def _reload_verses(self):
        """구절 본문 — **역본 하나**만 본다(언어와 무관)."""
        sv = getattr(self, '_cur_sv', None)
        ev = getattr(self, '_cur_ev', None)
        vb = self._verse_box
        vb.config(state='normal')
        vb.delete('1.0', 'end')
        if not sv:
            vb.config(state='disabled')
            self._lbl_range.config(text='')
            return
        ver = self._ver_code()
        lines = []
        rng_txt = ''
        try:
            conn = self._conn()
            v_rows = conn.execute(
                "SELECT bi.chapter, bi.verse, bc.verse_text "
                "  FROM bible_index bi "
                "  JOIN bible_content bc "
                "    ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                " WHERE " + _vr.between_sql('bi.verse_id') +
                " ORDER BY bi.sort_order",
                [ver] + _vr.between_args(sv, ev)).fetchall() if ver else []
            bk = conn.execute(
                "SELECT COALESCE(bn.short_name, bn.full_name, ''), "
                "       s.chapter, s.verse, e.chapter, e.verse "
                "  FROM bible_index s, bible_index e "
                "  LEFT JOIN book_names bn ON bn.book_code=s.bcode "
                "        AND bn.lang_code=? "
                " WHERE s.verse_id=? AND e.verse_id=?",
                ((self._lang_getter() or 'KO').upper(), sv, ev)).fetchone()
            conn.close()
            lines = [f"{r[0]}:{r[1]}  {r[2]}" for r in v_rows]
            if bk:
                nm, sc, svs, ec, evs = bk
                rng_txt = (f"{nm} {sc}:{svs}-{evs}" if sc == ec
                           else f"{nm} {sc}:{svs}-{ec}:{evs}")
        except Exception as e:
            print('[peri verses] %s' % e)
        vb.insert('1.0', '\n'.join(lines) if lines
                  else '(이 역본에 해당 구절 없음)')
        vb.config(state='disabled')
        self._lbl_range.config(text=rng_txt)

    def _update_lang_badges(self):
        """지금 단락의 제목·설명문 보유 언어를 라벨 줄에 반영."""
        if not hasattr(self, '_badge_row'):
            return
        have = set()
        if self._cur_peri:
            try:
                conn = self._conn()
                have = {r[0].upper() for r in conn.execute(
                    "SELECT DISTINCT lang_code FROM sys_text_asset "
                    " WHERE clicked_id=? "
                    "   AND text_type IN ('PERI_TITLE','PERI_DESC') "
                    "   AND record_status='LIVE'",
                    (self._cur_peri,)).fetchall() if r[0]}
                conn.close()
            except Exception as e:
                print('[peri editor] lang badges:', e)
        self._badge_row.set_have(have, current=self._edit_lang.get())

    def _load_one_side(self, side: dict, peri_id: int, lang: str):
        conn = self._conn()
        rows = conn.execute(
            "SELECT text_type, COALESCE(title,''), COALESCE(contents,'') "
            "  FROM sys_text_asset "
            " WHERE clicked_id=? AND text_type IN ('PERI_TITLE','PERI_DESC') "
            "   AND lang_code=? AND record_status='LIVE'",
            (peri_id, lang)).fetchall()
        conn.close()
        title_val = ''
        desc_val = ''
        for tt, t, c in rows:
            if tt == 'PERI_TITLE':
                title_val = t
            elif tt == 'PERI_DESC':
                desc_val = c or t

        is_edit = (side['role'] == 'edit')
        te = side['title_ent']
        te.config(state='normal')
        te.delete(0, 'end')
        te.insert(0, title_val)
        if not is_edit:
            te.config(state='disabled')

        db = side['desc_box']
        db.config(state='normal')
        db.delete('1.0', 'end')
        if desc_val:
            db.insert('1.0', desc_val)
        if not is_edit:
            db.config(state='disabled')

    def _clear_side(self, side: dict):
        te = side['title_ent']
        te.config(state='normal')
        te.delete(0, 'end')
        te.config(state='disabled')
        db = side['desc_box']
        db.config(state='normal')
        db.delete('1.0', 'end')
        db.config(state='disabled')

    # ═════════════════════════════ SAVE ══════════════════════════════════════

    def _save(self):
        if self._cur_peri is None:
            messagebox.showwarning("선택 없음", "구절단락을 먼저 선택하세요.",
                                    parent=self)
            return

        peri_id = self._cur_peri
        edit_lang = self._edit_lang.get()
        title_val = self._edit_side['title_ent'].get().strip()
        desc_val = self._edit_side['desc_box'].get('1.0', 'end').strip()

        conn = self._conn()
        try:
            cur = conn.cursor()
            self._upsert(cur, peri_id, 'PERI_TITLE', edit_lang, title_val, None)
            self._upsert(cur, peri_id, 'PERI_DESC', edit_lang, None, desc_val)
            conn.commit()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("저장 실패", str(e), parent=self)
            return
        finally:
            conn.close()

        has_t = bool(title_val)
        has_d = bool(desc_val)
        self._flags[peri_id] = (
            FLAG_BOTH if has_t and has_d else
            FLAG_TITLE if has_t else
            FLAG_DESC if has_d else ''
        )
        if not (has_t or has_d):
            self._flags.pop(peri_id, None)
        self._refresh_list_item(peri_id)
        self._update_lang_badges()
        self._refresh_trans()

        self._dirty = False
        self._lbl_status.config(text="✓ 저장됨")
        self.after(2000, lambda: self._lbl_status.config(text=""))

    def _upsert(self, cur: sqlite3.Cursor, peri_id: int,
                text_type: str, lang: str,
                title: str | None, contents: str | None):
        existing = cur.execute(
            "SELECT sys_text_id FROM sys_text_asset "
            "WHERE clicked_id=? AND text_type=? AND lang_code=? "
            "AND record_status='LIVE'",
            (peri_id, text_type, lang)
        ).fetchone()
        if existing:
            if not (title or contents):
                # 빈 값 저장 = 그 언어 행 HIDE — LIVE 로 남기면 보유 언어
                # 라벨이 「있다」고 거짓말한다(2026-08-26)
                cur.execute(
                    "UPDATE sys_text_asset SET record_status='HIDE' "
                    "WHERE sys_text_id=?", (existing[0],))
            else:
                cur.execute(
                    "UPDATE sys_text_asset SET title=?, contents=? "
                    "WHERE sys_text_id=?",
                    (title or None, contents or None, existing[0])
                )
        elif title or contents:
            # 숨겨 둔 행이 있으면 되살린다 — HIDE 행을 쌓지 않는다
            hidden = cur.execute(
                "SELECT sys_text_id FROM sys_text_asset "
                "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                "AND record_status='HIDE' ORDER BY sys_text_id DESC LIMIT 1",
                (peri_id, text_type, lang)).fetchone()
            if hidden:
                cur.execute(
                    "UPDATE sys_text_asset SET title=?, contents=?, "
                    "record_status='LIVE' WHERE sys_text_id=?",
                    (title or None, contents or None, hidden[0]))
            else:
                cur.execute(
                    "INSERT INTO sys_text_asset "
                    "(clicked_id, text_type, lang_code, title, contents, record_status) "
                    "VALUES (?, ?, ?, ?, ?, 'LIVE')",
                    (peri_id, text_type, lang, title or None, contents or None)
                )

    def _clear_confirm(self):
        if not messagebox.askyesno(
                "입력칸 비우기",
                "수정 측의 제목·설명문 입력칸을 비우겠습니까?\n"
                "(DB 는 안 바뀝니다 — 비운 채 [저장] 을 눌러야 지워집니다.)",
                parent=self):
            return
        self._edit_side['title_ent'].delete(0, 'end')
        self._edit_side['desc_box'].delete('1.0', 'end')
        self._dirty = False
        self._lbl_status.config(text="")

    def _refresh_list_item(self, peri_id: int):
        for i, (pid, sc, sv, ec, ev) in enumerate(self._pericopes):
            if pid != peri_id:
                continue
            sel = (i in self._listbox.curselection())
            self._listbox.delete(i)
            self._listbox.insert(i, self._list_line(pid, sc, sv, ec, ev))
            self._listbox.itemconfig(
                i, fg=self._flag_fg(self._flags.get(pid, '')))
            if sel:
                self._listbox.selection_set(i)
            break
