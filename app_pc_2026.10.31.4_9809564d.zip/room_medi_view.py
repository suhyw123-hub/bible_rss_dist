# -*- coding: utf-8 -*-
"""room_medi_view.py — 묵상플랜 ▸ 「함께 묵상」 (공동체 묵상 본 화면, 2026-09-08).

★★★ **사용자 확정**(2026-09-08):
  「공동체 묵상은 **구절단위가 아니라 하루 할당된 구절 전체 단위**」
  「**p2와 차별화**해야 함」
  「본인이 원하면 **구절과 연결하는 기능** · 그러면 **p2에 자동추가**」
  「**공동체 묵상보기 화면은 별도 제작**」
  「**플랜 날자 단위로 처리하는 것이 기본**」

★★★ **이 화면이 P2 와 다른 까닭** — P2 는 「이 구절에 대한 내 생각」이고
  여기는 **「오늘 읽은 범위 전체에 대한 나눔」**이다. 그리고 여기서만 되는 것:
    · **오늘 몫이 어디인가**(방의 진도)
    · ★★★ **누가 아직 안 썼나** — 설계 §3-1 이 「안 보이면 「나만 안 쓴
      건가」를 모른다」고 못 박은 그 자리. **P2 에서는 원리적으로 불가능하다.**
    · 날짜를 넘나들며 훑기
  ⚠ 「아직 안 썼습니다」는 **이름만 보이고 압박은 안 준다** — 「미제출」 같은
    말을 쓰지 않는다(설계 §3-1).

⚠ **나눔은 접어 둔다(개수만)** — 열자마자 남의 글이 쏟아지면 내 묵상을 쓰기
  전에 읽게 된다. **먼저 쓰고 그다음 읽는다**가 묵상의 순서다.

사용:  python room_medi_view.py --selftest
"""
import io
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox

import appdb

try:
    import i18n
    _t = i18n.t
except Exception:
    def _t(k, d=''):
        return d

try:
    import ui_theme

    def _C(role, fb):
        try:
            return ui_theme.C(role)
        except Exception:
            return fb
except Exception:
    def _C(role, fb):
        return fb


def _tfr(w, db, scope='ui', delta=0):
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=delta)
    except Exception:
        pass


def _quiet(msg):
    try:
        sys.stderr.write(str(msg) + chr(10))
    except Exception:
        pass


class RoomMediView(ttk.Frame):
    """묵상플랜 ▸ 함께 묵상."""

    def __init__(self, master, db_path, lang_getter=None, on_verse_open=None):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_verse_open = on_verse_open   # 구절로 가는 다리(호스트가 준다)
        self._rooms = []
        self._room = None
        self._plan = None       # (plan_code, 제목, 총 일수)
        self._day = 1
        self._shared_open = False
        self._build()
        self.after_idle(self.reload)

    # ── 화면 ─────────────────────────────────────────────────────────
    def _build(self):
        pad = 8
        # ── 머리 줄: 방 · 플랜 · 날짜 ─────────────────────────────
        top = ttk.Frame(self)
        top.pack(fill='x', padx=pad, pady=(pad, 4))
        ttk.Label(top, text=_t('RM_ROOM', '공동체')).pack(side='left')
        self._room_var = tk.StringVar()
        self._room_cb = ttk.Combobox(top, textvariable=self._room_var,
                                     state='readonly', width=24)
        self._room_cb.pack(side='left', padx=(4, 12))
        self._room_cb.bind('<<ComboboxSelected>>', lambda _e: self._on_room())

        ttk.Label(top, text=_t('RM_PLAN', '플랜')).pack(side='left')
        self._plan_var = tk.StringVar()
        self._plan_cb = ttk.Combobox(top, textvariable=self._plan_var,
                                     state='readonly', width=28)
        self._plan_cb.pack(side='left', padx=(4, 12))
        self._plan_cb.bind('<<ComboboxSelected>>', lambda _e: self._on_plan())

        ttk.Button(top, text='◀', width=3,
                   command=lambda: self._move(-1)).pack(side='left')
        self._day_var = tk.StringVar(value='')
        tk.Label(top, textvariable=self._day_var, width=14, anchor='center',
                 fg=_C('fg_title', '#1A5276')).pack(side='left')
        ttk.Button(top, text='▶', width=3,
                   command=lambda: self._move(1)).pack(side='left')
        ttk.Button(top, text=_t('RM_TODAY', '오늘'),
                   command=self._goto_today).pack(side='left', padx=(8, 0))
        # ★ M 자리를 **먼저** 오른쪽에 못 박는다 — 호스트(user_main)가 심는다
        self._m_slot = ttk.Frame(top)
        self._m_slot.pack(side='right')
        ttk.Button(top, text=_t('COMMON_REFRESH', '새로고침'),
                   command=self.reload).pack(side='right')
        self._sync_var = tk.StringVar(value='')
        tk.Label(top, textvariable=self._sync_var, fg=_C('fg_dim', '#666')
                 ).pack(side='right', padx=6)
        # ★★★ **[방 관리] — My Edit 과 별개의 입구**(2026-09-08 사용자 확정
        #   「이러한 방 관리기능은 My edit 버튼과 별도의 버튼을 만들어서
        #   진입한다」). **방장에게만** 보인다 — 참여자에게는 단추 자체가 없다.
        self._adm_btn = ttk.Button(top, text=_t('RM_ADMIN', '방 관리'),
                                   command=self._open_admin)

        # ── ★★★ 방 공지 — **방장만 올린다**(사용자 확정) ──────────
        #   ⚠ 공지가 없으면 **띠째 안 그린다**(§0-1 빈 서랍) — 방장에게는
        #     [공지 쓰기] 단추만 남는다.
        self._nt_f = tk.Frame(self, bg=_C('warning_bg', '#FBF3DC'))
        self._nt_lbl = tk.Label(self._nt_f, anchor='w', justify='left',
                                bg=_C('warning_bg', '#FBF3DC'),
                                fg=_C('fg', '#000'), wraplength=700)
        self._nt_lbl.pack(side='left', fill='x', expand=True, padx=8, pady=5)
        self._nt_btn = ttk.Button(self._nt_f, text=_t('RM_NOTICE_EDIT',
                                                      '공지 쓰기'),
                                  command=self._edit_notice)
        self._nt_btn.pack(side='right', padx=6, pady=4)
        _tfr(self._nt_lbl, self.db_path, 'ui')

        # ── 5단계 — 상태 띠(마무리됨 · 관리자 차단) ────────────────
        self._st_lbl = tk.Label(self, anchor='w', justify='left', wraplength=760,
                                text='', fg=_C('fg_dim', '#666'))
        _tfr(self._st_lbl, self.db_path, 'ui', -1)
        self._blocked = None

        # ── ★★★ 방 게시판(4단계) — 인사 · 지침 · 교재 · 마무리 ───────
        #   사용자 확정 흐름: 「관리자가 서로 인사하라고 한다 → 멤버들이 인사말
        #   → 관리자가 지침 → 날마다 묵상 → 마지막 인사」. **접어 둔다** —
        #   날마다 하는 일은 그 아래 「내 묵상」이고 게시판은 훑는 자리다.
        self._bd_btn = tk.Button(self, bd=0, relief='flat', anchor='w',
                                 cursor='hand2', text='',
                                 bg=_C('panel_alt', '#F2F3F4'),
                                 fg=_C('fg_title', '#1A5276'),
                                 command=self._toggle_board)
        self._bd_btn.pack(fill='x', padx=pad, pady=(0, 2))
        self._bd = ttk.Frame(self)
        self._board_open = False
        self._posts = []

        # ── 그 날 몫 ──────────────────────────────────────────────
        self._span_var = tk.StringVar(value='')
        sp = tk.Label(self, textvariable=self._span_var, anchor='w',
                      fg=_C('fg_title', '#1A5276'), cursor='hand2')
        sp.pack(fill='x', padx=pad)
        _tfr(sp, self.db_path, 'ui', 3)
        sp.bind('<Button-1>', lambda _e: self._open_span())

        self._hint = tk.StringVar(value='')
        hl = tk.Label(self, textvariable=self._hint, anchor='w', justify='left',
                      fg=_C('fg_dim', '#888'), wraplength=760)
        hl.pack(fill='x', padx=pad, pady=(0, 6))
        _tfr(hl, self.db_path, 'ui', -1)

        # ── 내 묵상 ───────────────────────────────────────────────
        mf = ttk.LabelFrame(self, text=' ' + _t('RM_MINE', '내 묵상') + ' ')
        mf.pack(fill='both', expand=True, padx=pad, pady=(0, 4))
        self._txt = tk.Text(mf, height=7, wrap='word', undo=True)
        self._txt.pack(fill='both', expand=True, padx=6, pady=(6, 2))
        _tfr(self._txt, self.db_path, 'prose')
        br = ttk.Frame(mf)
        br.pack(fill='x', padx=6, pady=(0, 6))
        ttk.Button(br, text=_t('COMMON_SAVE', '저장'),
                   command=self._save).pack(side='left')
        # ★ **구절과 연결** — 사용자 확정. 붙이면 P2 에도 뜬다.
        self._link_var = tk.StringVar(value='')
        ttk.Button(br, text=_t('RM_LINK_VERSE', '구절과 연결'),
                   command=self._link_verse).pack(side='left', padx=6)
        tk.Label(br, textvariable=self._link_var, fg=_C('fg_dim', '#666')
                 ).pack(side='left', padx=(6, 0))
        ttk.Button(br, text=_t('RM_PUSH', '올리기'),
                   command=self._push).pack(side='right')

        # ── 함께 나눈 글 (접힘) ───────────────────────────────────
        self._sh_btn = tk.Button(self, bd=0, relief='flat', anchor='w',
                                 cursor='hand2', text='',
                                 bg=_C('panel_alt', '#F2F3F4'),
                                 fg=_C('fg_title', '#1A5276'),
                                 command=self._toggle)
        self._sh_btn.pack(fill='x', padx=pad)
        self._sh = ttk.Frame(self)

        # ── 진도 — 누가 썼나 ──────────────────────────────────────
        self._who = tk.StringVar(value='')
        wl = tk.Label(self, textvariable=self._who, anchor='w', justify='left',
                      fg=_C('fg_dim', '#666'), wraplength=760)
        wl.pack(fill='x', padx=pad, pady=(6, pad))
        _tfr(wl, self.db_path, 'ui', -1)

        self._empty = tk.Label(
            self, text=_t('RM_EMPTY',
                          '참여한 공동체가 없습니다.\n\n'
                          '설정 ▸ 내 공동체 에서 방을 열거나 초대 파일로 '
                          '참여하세요.'),
            anchor='w', justify='left', fg=_C('fg_dim', '#888'))
        _tfr(self._empty, self.db_path, 'ui')

    # ── 채우기 ───────────────────────────────────────────────────────
    def reload(self):
        try:
            import room_core as RC
            with appdb.connect(self.db_path) as conn:
                self._rooms = RC.rooms(conn)
        except Exception as e:
            self._rooms = []
            _quiet('[rm] %s' % e)
        if not self._rooms:
            # ⚠ **왜 비었는지 말하고 어디로 가야 하는지 알린다**(§0-1)
            self._empty.pack(fill='both', expand=True, padx=14, pady=20)
            self._room_cb.config(values=[])
            return
        self._empty.pack_forget()
        names = [r['room_name'] for r in self._rooms]
        self._room_cb.config(values=names)
        if self._room_var.get() not in names:
            self._room_var.set(names[0])
        self._on_room()

    def _on_room(self):
        nm = self._room_var.get()
        self._room = next((r for r in self._rooms if r['room_name'] == nm), None)
        self._blocked = None
        if self._room:
            try:
                import room_core as RC0
                with appdb.connect(self.db_path) as conn:
                    self._blocked = RC0.blocked(conn, self._room['room_id'])
            except Exception:
                self._blocked = None
        # ★★ 자동 받기 — 방을 고를 때 남의 글을 **먼저** 받아 둔다(같은 방은 10분에 한 번).
        #   ⚠ 단추·띠보다 앞이다 — 방장 파일이 내 역할(부방장)·마무리를 바꿨을 수
        #     있고, 뒤에 받으면 이번 화면은 옛 역할로 그려진다(종단 시험이 잡았다).
        self._auto_pull()
        self._draw_status()
        # 운영자(방장·부방장)에게만 [방 관리]
        self._adm_btn.pack_forget()
        try:
            import room_core as RC
            if self._room and self._room.get('my_role') in RC.MANAGER_ROLES:
                self._adm_btn.pack(side='right', padx=(0, 6))
        except Exception:
            pass
        self._fill_plans()
        self._draw_board()

    def manual_slot(self):
        """[M] 자리 — 호스트가 `attach_manual_icon` 을 심는다(맨 오른쪽)."""
        return self._m_slot

    # ── 자동 동기화 ───────────────────────────────────────────────
    _pulled_at = {}      # room_id → 마지막 받은 시각(모든 인스턴스가 공유)

    def _folder_ok(self):
        import room_core as RC
        if not self._room or self._blocked:
            return None
        f = RC.folder_of(self._room)
        return f if (f and os.path.isdir(f)) else None

    def _auto_pull(self, force=False):
        """받기를 사람이 누르지 않아도 된다 — 탭에 들어올 때 받아 둔다.
        ⚠ 실패해도 조용하다(폴더 동기화가 아직일 수 있다). 결과는 머리 줄에."""
        import time
        f = self._folder_ok()
        if not f:
            self._sync_var.set('')
            return
        rid = self._room['room_id']
        last = RoomMediView._pulled_at.get(rid, 0)
        if not force and time.time() - last < 600:
            return
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                who, notes, _b = RS.pull(conn, rid, f, self.db_path)
            RoomMediView._pulled_at[rid] = time.time()
            from datetime import datetime as _dt
            self._sync_var.set(_t('RM_SYNC', '동기화 %s') % _dt.now().strftime('%H:%M'))
            # 방장 파일이 이름·플랜·역할을 바꿨을 수 있다 — 방 줄을 다시 읽는다
            import room_core as RC
            with appdb.connect(self.db_path) as conn:
                self._rooms = RC.rooms(conn)
                self._room = next((r for r in self._rooms
                                   if r['room_id'] == rid), self._room)
        except Exception as e:
            _quiet('[rm auto pull] %s' % e)

    def _auto_push(self):
        """저장하면 곧바로 올린다(폴더가 있을 때) → 됐나."""
        f = self._folder_ok()
        if not f:
            return False
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                RS.push(conn, self._room['room_id'], f, self._room['my_name'] or '',
                        self.db_path)
                RS.pull(conn, self._room['room_id'], f, self.db_path)
            from datetime import datetime as _dt
            self._sync_var.set(_t('RM_SYNC', '동기화 %s') % _dt.now().strftime('%H:%M'))
            return True
        except Exception as e:
            _quiet('[rm auto push] %s' % e)
            return False

    def _open_admin(self):
        if not self._room or self._stop_if_blocked():
            return
        try:
            import room_admin_view as RA
            RA.open_room_admin(self, self.db_path, self._room['room_id'],
                               self.lang_getter, on_changed=self.reload)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200],
                                 parent=self.winfo_toplevel())

    def _fill_plans(self):
        """플랜 목록 — **방 플랜이 맨 앞이고 기본**, 그다음 내가 등록한 플랜.

        ★★★ 2026-09-08 사용자 확정 「묵상플랜을 교회관리자가 특정한다 … 이
          플랜이 방 내부에 공유된다」 — 방장이 정한 플랜은 **등록하지 않았어도**
          여기 뜬다. 그 방의 묵상 단위이기 때문이다.
        ⚠ `plan_code` 가 자연 열쇠다.
        """
        self._plans = []
        room_pc = ((self._room or {}).get('plan_code') or '').strip()
        try:
            with appdb.connect(self.db_path) as conn:
                if room_pc:
                    r = conn.execute("SELECT duration_days FROM sys_bible_plan "
                                     "WHERE plan_code=?", (room_pc,)).fetchone()
                    if r:
                        self._plans.append((room_pc, _t('RM_ROOM_PLAN', '방 플랜')
                                            + ' · ' + self._plan_title(conn, room_pc),
                                            int(r[0] or 0)))
                for r in conn.execute(
                        "SELECT DISTINCT p.plan_code, p.duration_days "
                        "FROM user_plan_enrollment e "
                        "JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
                        "WHERE e.enrollment_status='ACTIVE' "
                        "AND COALESCE(e.user_plan_id,0)=0"):
                    if r[0] == room_pc:
                        continue
                    self._plans.append((r[0], self._plan_title(conn, r[0]),
                                        int(r[1] or 0)))
        except Exception as e:
            _quiet('[rm plans] %s' % e)
        vals = [t or c for c, t, _d in self._plans]
        self._plan_cb.config(values=vals)
        if vals and (self._plan_var.get() not in vals or room_pc):
            # ★ 방 플랜이 있으면 **늘 그것부터** — 방을 바꾸면 그 방의 플랜으로
            self._plan_var.set(vals[0])
        self._on_plan()

    def _plan_title(self, conn, plan_code):
        """플랜 이름 — **묶음을 앞에 붙인다**.

        ⚠⚠ 실측 등록 21개 중 **「1년」이 두 번** 나온다(정경순서통독·연대기통독).
          그대로 두면 콤보에서 어느 것인지 못 고른다 — 이 화면은 플랜을 고르는
          자리라 **문맥이 없다**(§152차 상세 화면과 같은 판단).
        ⚠ `plan_label.full` 한 문에 맡긴다 — 이름을 여기서 지으면 갈린다.
        """
        try:
            import plan_label
            r = conn.execute("SELECT plan_id, plan_type FROM sys_bible_plan "
                             "WHERE plan_code=?", (plan_code,)).fetchone()
            if r:
                got = plan_label.titles_of(conn, [r[0]],
                                           (self.lang_getter() or 'KO'))
                ttl = (got or {}).get(r[0]) or plan_code
                return plan_label.full(r[1], ttl, ambiguous=True) or ttl
        except Exception:
            pass
        return plan_code

    def _cur_plan(self):
        v = self._plan_var.get()
        for c, t, d in getattr(self, '_plans', []):
            if (t or c) == v:
                return c, d
        return None, 0

    def _on_plan(self):
        self._day = 1
        self._goto_today()

    def _goto_today(self):
        """**오늘 몫**으로 — 방 플랜이면 **방장이 정한 시작일**에서 센다.

        ★★★ 2026-09-08 사용자 확정 「시작하는 날자는 방장이 지정해야 한다. 같은 날
          모두 시작해야 한다」 — 각자의 플랜 등록(`current_day`)이 아니라 방의
          시작일이 기준이다. 등록을 안 했어도 오늘이 맞는다.
        """
        pc, dur = self._cur_plan()
        if not pc:
            self._render()
            return
        import room_core as RC
        if self._room and pc == (self._room.get('plan_code') or ''):
            td = RC.today_day(self._room)
            if td:
                self._day = min(td, dur) if dur else td
                self._render()
                return
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT e.current_day FROM user_plan_enrollment e "
                    "JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
                    "WHERE p.plan_code=? AND e.enrollment_status='ACTIVE' "
                    "LIMIT 1", (pc,)).fetchone()
            self._day = int(r[0] or 1) if r else 1
        except Exception:
            self._day = 1
        self._render()

    def _move(self, d):
        pc, dur = self._cur_plan()
        self._day = max(1, self._day + d)
        if dur:
            self._day = min(self._day, dur)
        self._render()

    def _render(self):
        pc, dur = self._cur_plan()
        if not pc:
            self._day_var.set('')
            self._span_var.set('')
            self._hint.set(_t('RM_NO_PLAN',
                              '등록한 묵상플랜이 없습니다. 묵상플랜에서 하나를 '
                              '등록하면 그 날짜 단위로 함께 묵상합니다.'))
            self._who.set('')
            self._sh_btn.pack_forget()
            # ⚠ **이 길에서도 공지를 다시 그린다** — 안 그리면 방장에서
            #   참여자로 바뀌어도 옛 상태가 화면에 남는다(실측으로 잡았다).
            self._draw_notice()
            return
        if self._sh_btn.winfo_manager() != 'pack':
            self._sh_btn.pack(fill='x', padx=8)
        self._day_var.set(_t('RM_DAY', '%d일차') % self._day
                          + (' / %d' % dur if dur else ''))
        rid = self._room['room_id'] if self._room else None
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                self._span = RS.day_span(conn, pc, self._day)
                lab = RS.day_label(conn, pc, self._day,
                                   (self.lang_getter() or 'KO'))
                mine = RS.note_of_day(conn, rid, pc, self._day) if rid else None
                shared = RS.notes_of_day(conn, rid, pc, self._day,
                                         self.db_path) if rid else []
                who = RS.wrote_map(conn, rid, pc, self._day,
                                   self.db_path) if rid else []
        except Exception as e:
            _quiet('[rm render] %s' % e)
            self._span, lab, mine, shared, who = (None, None), '', None, [], []
        self._span_var.set(lab if self._span[0] else
                           _t('RM_NO_DAY', '이 날짜에는 읽을 몫이 없습니다'))
        hint = _t('RM_HINT',
                  '오늘 읽은 범위 전체에 대한 묵상을 나눕니다. '
                  '구절 하나에 대한 메모는 성경 화면의 묵상노트에 씁니다.')
        import room_core as RC2
        if self._room and pc == (self._room.get('plan_code') or ''):
            ps = (self._room.get('plan_start') or '').strip()
            td = RC2.today_day(self._room)
            if ps and td:
                hint = (_t('RM_START', '시작 %s · 오늘 %d일차') % (ps, td)) + '   ' + hint
            elif not ps:
                hint = _t('RM_NO_START', '방장이 아직 시작일을 정하지 않았습니다.') + '   ' + hint
        self._hint.set(hint)
        # 내 글
        self._mine_pk = mine['pk'] if mine else None
        self._mine_vid = mine['clicked_id'] if mine else None
        self._txt.delete('1.0', 'end')
        if mine:
            self._txt.insert('1.0', mine['contents'])
        self._sync_link_label()
        # 나눔 — 접어 둔다
        self._shared = shared
        self._sh_btn.config(text='%s %s (%d)'
                            % ('▾' if self._shared_open else '▸',
                               _t('RM_SHARED', '함께 나눈 글'), len(shared)))
        self._draw_shared()
        self._draw_notice()
        # 진도
        # ⚠ **혼자면 안 그린다**(§0-1 빈 서랍) — 「아직 안 썼습니다: 나」는
        #   내가 이미 아는 사실이라 말해 줄 것이 없다. 사람이 둘 이상일 때
        #   비로소 「나만 안 쓴 건가」의 답이 된다.
        import room_core as RC1
        if len(who) > 1 and not RC1.is_closed(self._room):
            done = [n for n, ok in who if ok]
            yet = [n for n, ok in who if not ok]
            parts = []
            if done:
                parts.append(_t('RM_WROTE', '쓴 사람') + ': ' + ' · '.join(done))
            if yet:
                # ⚠ **압박하지 않는다** — 「미제출」 같은 말을 안 쓴다(설계 §3-1)
                parts.append(_t('RM_NOT_YET', '아직 안 썼습니다')
                             + ': ' + ' · '.join(yet))
            self._who.set('   '.join(parts))
        else:
            self._who.set('')

    def _draw_shared(self):
        for w in self._sh.winfo_children():
            w.destroy()
        if not self._shared_open:
            self._sh.pack_forget()
            return
        self._sh.pack(fill='x', padx=8)
        if not self._shared:
            tk.Label(self._sh, text=_t('RM_SHARED_NONE',
                     '아직 받은 글이 없습니다. 설정 ▸ 내 공동체 에서 '
                     '[함께 나눈 글 받기]를 눌러 보세요.'),
                     anchor='w', fg=_C('fg_dim', '#999')).pack(fill='x', pady=4)
            return
        for x in self._shared:
            f = ttk.Frame(self._sh)
            f.pack(fill='x', pady=(4, 0))
            meta = '%s · %s' % (x['name'], (x['at'] or '')[:10])
            if x.get('verse_key'):
                meta += ' · %s' % x['verse_key']
            tk.Label(f, text=meta, anchor='w',
                     fg=_C('fg_dim', '#95A5A6')).pack(fill='x')
            tk.Label(f, text=x['contents'], anchor='w', justify='left',
                     wraplength=740, fg=_C('fg', '#000')).pack(fill='x')
            tk.Frame(f, height=1, bg=_C('border', '#E5E7E9')).pack(
                fill='x', pady=(4, 0))

    def _toggle(self):
        self._shared_open = not self._shared_open
        self._sh_btn.config(text='%s %s (%d)'
                            % ('▾' if self._shared_open else '▸',
                               _t('RM_SHARED', '함께 나눈 글'),
                               len(getattr(self, '_shared', []))))
        self._draw_shared()

    # ── 5단계 — 상태 띠 · 차단 ───────────────────────────────────
    def _draw_status(self):
        import room_core as RC
        txt = ''
        if self._blocked:
            txt = _t('RA_BLOCKED', '관리자가 이 방을 막았습니다: %s') % self._blocked
        elif RC.is_closed(self._room):
            txt = _t('RM_CLOSED_BAND', '이 방은 %s 에 마무리되었습니다. 글과 자료는 '
                                       '그대로 볼 수 있습니다.') % (
                (self._room or {}).get('closed_at') or '')
        self._st_lbl.config(text=txt)
        if txt:
            if self._st_lbl.winfo_manager() != 'pack':
                self._st_lbl.pack(fill='x', padx=8, pady=(0, 4), before=self._bd_btn)
        else:
            self._st_lbl.pack_forget()

    def _stop_if_blocked(self):
        if self._blocked:
            messagebox.showinfo(_t('RM_TAB', '함께 묵상'),
                                _t('RM_BLOCKED_STOP',
                                   '관리자가 이 방을 막아 올리고 받을 수 없습니다: %s')
                                % self._blocked, parent=self.winfo_toplevel())
            return True
        return False

    # ── 방 게시판(4단계) ─────────────────────────────────────────
    def _draw_board(self):
        rid = self._room['room_id'] if self._room else None
        self._posts = []
        if rid:
            try:
                import room_share as RS
                with appdb.connect(self.db_path) as conn:
                    self._posts = RS.posts(conn, rid, self.db_path)
            except Exception as e:
                _quiet('[rm board] %s' % e)
        if not rid:
            self._bd_btn.pack_forget()
            self._bd.pack_forget()
            return
        if self._bd_btn.winfo_manager() != 'pack':
            self._bd_btn.pack(fill='x', padx=8, pady=(0, 2), before=self._span_h())
        self._bd_btn.config(text='%s %s (%d)'
                            % ('▾' if self._board_open else '▸',
                               _t('RM_BOARD', '게시판'), len(self._posts)))
        for w in self._bd.winfo_children():
            w.destroy()
        if not self._board_open:
            self._bd.pack_forget()
            return
        self._bd.pack(fill='x', padx=8, pady=(0, 4), before=self._span_h())
        br = ttk.Frame(self._bd)
        br.pack(fill='x', pady=(2, 2))
        ttk.Button(br, text=_t('RM_BOARD_WRITE', '글 쓰기'),
                   command=self._write_post).pack(side='left')
        if not self._posts:
            tk.Label(self._bd, text=_t('RM_BOARD_NONE',
                     '아직 글이 없습니다. 인사말부터 남겨 보세요.'),
                     anchor='w', fg=_C('fg_dim', '#999')).pack(fill='x', pady=4)
            return
        import room_admin_view as RA
        for x in self._posts:
            f = ttk.Frame(self._bd)
            f.pack(fill='x', pady=(4, 0))
            meta = '[%s] %s · %s' % (RA.kind_name(x['kind']), x['name'],
                                     (x['written_at'] or '')[:10])
            if x.get('leader'):
                meta += ' · ' + _t('ROOM_ROLE_LEADER', '방장')
            elif x.get('co'):
                meta += ' · ' + _t('ROOM_ROLE_CO', '부방장')
            if x.get('mine'):
                meta += ' · ' + _t('RM_ME', '(나)')
            tk.Label(f, text=meta, anchor='w',
                     fg=_C('fg_dim', '#95A5A6')).pack(fill='x')
            if x.get('title'):
                tk.Label(f, text=x['title'], anchor='w',
                         fg=_C('fg_title', '#1A5276')).pack(fill='x')
            if x.get('contents'):
                tk.Label(f, text=x['contents'], anchor='w', justify='left',
                         wraplength=740, fg=_C('fg', '#000')).pack(fill='x')
            for nm in x.get('files') or []:
                fr = ttk.Frame(f)
                fr.pack(fill='x')
                shown = nm.split('_', 2)[-1]
                tk.Label(fr, text='📎 ' + shown, anchor='w',
                         fg=_C('fg', '#000')).pack(side='left')
                ttk.Button(fr, text=_t('RM_ATTACH_OPEN', '열기'),
                           command=lambda n=nm: self._open_attach(n)
                           ).pack(side='left', padx=6)
            tk.Frame(f, height=1, bg=_C('border', '#E5E7E9')).pack(
                fill='x', pady=(4, 0))

    def _toggle_board(self):
        self._board_open = not self._board_open
        self._draw_board()

    def _write_post(self):
        if not self._room or self._stop_if_blocked():
            return
        _PostEdit(self, self.db_path, self._room, self.lang_getter,
                  self._draw_board)

    def _open_attach(self, name):
        """첨부를 연다 — **이 앱의 자료 파일이면 그 자리에서 앱에 담는다.**

        ★ 「연구자산을 나눌 다른 방법」은 따로 없다 — 자료 파일(묵상노트·
          연구자료·구절연결·렌즈 한 벌)을 게시판에 첨부하면 여기서 담긴다.
        ⚠ 아직 동기화가 안 됐으면 **그렇다고 말한다**(§0-1).
        """
        import room_core as RC
        import room_share as RS
        f = RC.folder_of(self._room)
        p = RS.attach_path(f, name) if f else None
        if not p:
            messagebox.showinfo(_t('RM_BOARD', '게시판'),
                                _t('RM_ATTACH_MISSING',
                                   '아직 이 PC 에 도착하지 않았습니다. 폴더 동기화가 '
                                   '끝난 뒤 다시 눌러 보세요.'),
                                parent=self.winfo_toplevel())
            return
        kind = RS.attach_kind(p)
        if kind == 'PACK':
            self._import_pack(p)
            return
        try:
            os.startfile(p)
        except Exception:
            try:
                import webbrowser
                webbrowser.open('file:///' + p.replace(chr(92), '/'))
            except Exception as e:
                messagebox.showerror(_t('RM_BOARD', '게시판'), str(e)[:200],
                                     parent=self.winfo_toplevel())

    def _import_pack(self, p):
        """자료 파일을 앱에 담는다 — 설정 ▸ 내 공동체와 **같은 문**(두 벌 금지)."""
        import json
        try:
            import share_pack as SP
            draft = json.load(io.open(p, encoding='utf-8'))
            lines = SP.preview(draft)
        except Exception as e:
            messagebox.showwarning(_t('RM_BOARD', '게시판'), str(e)[:200],
                                   parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno(
                _t('RM_ATTACH_PACK', '앱에 담기'),
                _t('ROOM_IMPORT_ASK', '다음 자료를 받습니다.') + chr(10) + chr(10)
                + chr(10).join('· %s' % x for x in lines) + chr(10) + chr(10)
                + _t('ROOM_IMPORT_NOTE',
                     '이미 받은 것은 다시 들어오지 않습니다. '
                     '내가 쓴 글은 지워지지 않습니다.'),
                parent=self.winfo_toplevel()):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                put, skip, bad = SP.import_pack(conn, draft)
        except Exception as e:
            messagebox.showerror(_t('RM_ATTACH_PACK', '앱에 담기'), str(e)[:300],
                                 parent=self.winfo_toplevel())
            return
        msg = _t('ROOM_IMPORT_OK', '받았습니다 — 새로 %d건') % put
        if skip:
            msg += chr(10) + _t('ROOM_IMPORT_DUP', '이미 있던 것 %d건') % skip
        if bad:
            msg += chr(10) + _t('ROOM_IMPORT_BAD',
                                '못 받은 것 %d건 (구절·용어를 찾지 못했습니다)') % bad
        messagebox.showinfo(_t('RM_ATTACH_PACK', '앱에 담기'), msg,
                            parent=self.winfo_toplevel())

    # ── 방 공지 ──────────────────────────────────────────────────────
    def _draw_notice(self):
        """공지 띠 — **방 단위로만 조회된다**(사용자 「방 단위로만 조회 가능」)."""
        rid = self._room['room_id'] if self._room else None
        self._notices, self._can_notice = [], False
        if rid:
            try:
                import room_core as RC
                import room_share as RS
                with appdb.connect(self.db_path) as conn:
                    self._can_notice = RC.can_notice(conn, rid)[0]
                    self._notices = RS.notices(conn, rid, self.db_path)
            except Exception as e:
                _quiet('[rm notice] %s' % e)
        if not (self._notices or self._can_notice):
            self._nt_f.pack_forget()
            # ⚠ **라벨도 비운다** — 안 비우면 방을 바꿨을 때 옛 방 공지가
            #   글자로 남아 있다가 다시 뜬다(실측으로 잡았다).
            self._nt_lbl.config(text='')
            return
        if self._nt_f.winfo_manager() != 'pack':
            self._nt_f.pack(fill='x', padx=8, pady=(0, 4), before=self._span_h())
        if self._notices:
            n0 = self._notices[0]
            more = ('  (+%d)' % (len(self._notices) - 1)
                    if len(self._notices) > 1 else '')
            self._nt_lbl.config(text='%s %s — %s%s'
                                % (_t('RM_NOTICE', '공지'), n0['name'],
                                   n0['contents'], more))
        else:
            # ⚠ 방장에게만 보이는 안내 — 참여자에게는 띠가 아예 없다
            self._nt_lbl.config(text=_t('RM_NOTICE_NONE',
                                        '아직 공지가 없습니다.'))
        self._nt_btn.pack_forget()
        if self._can_notice:
            self._nt_btn.pack(side='right', padx=6, pady=4)

    def _span_h(self):
        """공지 띠를 넣을 자리 — 그 날 몫 라벨 **앞**."""
        for w in self.pack_slaves():
            try:
                if w.cget('textvariable') == str(self._span_var):
                    return w
            except Exception:
                continue
        return None

    def _edit_notice(self):
        if not (self._room and self._can_notice):
            return
        cur = next((x for x in self._notices if x.get('mine')), None)
        _NoticeEdit(self, self.db_path, self._room['room_id'], cur,
                    self._render)

    # ── 동작 ─────────────────────────────────────────────────────────
    def _sync_link_label(self):
        vid = getattr(self, '_mine_vid', None)
        if not vid:
            self._link_var.set('')
            return
        try:
            with appdb.connect(self.db_path) as conn:
                import db_media_range as MR
                self._link_var.set(_t('RM_LINKED', '연결: %s')
                                   % MR.span_label(conn, vid, vid))
        except Exception:
            self._link_var.set('')

    def _save(self):
        pc, _d = self._cur_plan()
        if not (pc and self._room):
            return
        body = self._txt.get('1.0', 'end').strip()
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                self._mine_pk = RS.save_note(
                    conn, self._room['room_id'], pc, self._day, body,
                    verse_id=getattr(self, '_mine_vid', None),
                    pk=getattr(self, '_mine_pk', None),
                    lang=(self.lang_getter() or 'KO'))
        except Exception as e:
            messagebox.showerror(_t('RM_TAB', '함께 묵상'), str(e)[:200],
                                 parent=self.winfo_toplevel())
            return
        ok = self._auto_push()
        messagebox.showinfo(_t('RM_TAB', '함께 묵상'),
                            _t('ROOM_SAVED', '저장했습니다.') + ' '
                            + (_t('RM_SAVED_PUSHED', '올렸습니다.') if ok else
                               _t('RM_SAVED_LOCAL', '방 폴더가 없어 이 PC 에만 있습니다.')),
                            parent=self.winfo_toplevel())
        self._render()

    def _link_verse(self):
        """★ **구절과 연결** — 붙이면 P2 「함께 나눈 글」에도 뜬다.

        ⚠ **그 날 몫 안의 구절만** 고르게 한다 — 밖의 구절을 붙이면 「오늘
          읽은 범위」라는 이 화면의 뜻이 흐려진다.
        """
        s_, e_ = getattr(self, '_span', (None, None))
        if not s_:
            return
        cur = getattr(self, '_mine_vid', None)
        if cur:
            # 이미 붙어 있으면 뗀다(토글)
            self._mine_vid = None
            self._sync_link_label()
            self._save()
            return
        import verse_range as _vr      # §verse_range — 차례로 나열
        try:
            with appdb.connect(self.db_path) as conn:
                rows = list(conn.execute(
                    "SELECT i.verse_id, b.short_name, i.chapter, i.verse "
                    "FROM bible_index i JOIN book_names b "
                    "ON b.book_code=i.bcode AND b.lang_code='KO' "
                    "WHERE " + _vr.between_sql('i.verse_id')
                    + " ORDER BY i.sort_order",
                    _vr.between_args(s_, e_)))
        except Exception as e:
            _quiet('[rm link] %s' % e)
            return
        if not rows:
            return
        _VersePick(self, rows, self._on_picked)

    def _on_picked(self, vid):
        self._mine_vid = vid
        self._sync_link_label()
        self._save()

    def _open_span(self):
        s_, _e = getattr(self, '_span', (None, None))
        if s_ and callable(self.on_verse_open):
            try:
                self.on_verse_open(s_)
            except Exception as e:
                _quiet('[rm open] %s' % e)

    def _push(self):
        """올리기 — **설정 ▸ 내 공동체와 같은 문을 쓴다**(두 벌 금지)."""
        if not self._room or self._stop_if_blocked():
            return
        import room_core as RC
        f = RC.folder_of(self._room)
        if not f or not os.path.isdir(f):
            messagebox.showinfo(
                _t('RM_TAB', '함께 묵상'),
                _t('RM_NO_FOLDER',
                   '방 폴더가 없습니다. 방장이 방 관리에서 폴더를 정하고 '
                   '올리기를 해야 합니다.'), parent=self.winfo_toplevel())
            return
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                name, cnt, _sk = RS.push(conn, self._room['room_id'], f,
                                         self._room['my_name'] or '',
                                         self.db_path)
                who, notes, _bad = RS.pull(conn, self._room['room_id'], f,
                                           self.db_path)
        except Exception as e:
            messagebox.showerror(_t('RM_TAB', '함께 묵상'), str(e)[:200],
                                 parent=self.winfo_toplevel())
            return
        messagebox.showinfo(
            _t('RM_TAB', '함께 묵상'),
            _t('RM_PUSHED', '%d편을 올리고 %d명의 글 %d편을 받았습니다.')
            % (cnt, who, notes), parent=self.winfo_toplevel())
        # ⚠ 방장 파일이 이름·플랜을 바꿨을 수 있다 — 방 목록부터 다시 읽는다
        self.reload()


class _PostEdit(tk.Toplevel):
    """게시판 글 쓰기 — **누구나**(인사말). 지침·마무리·첨부는 방장만."""

    def __init__(self, parent, db_path, room, lang_getter, on_done):
        super().__init__(parent)
        self.db_path, self.room, self.on_done = db_path, room, on_done
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._files = []
        self.title(_t('RM_BOARD_WRITE', '글 쓰기'))
        self.transient(parent.winfo_toplevel())
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        import room_core as RC
        import room_admin_view as RA
        self._lead = (room.get('my_role') in RC.MANAGER_ROLES)
        kinds = [k for k in RA.KIND_KEYS
                 if self._lead or k[0] not in ('GUIDE', 'CLOSE')]
        self._kinds = [(c, _t(k, d)) for c, k, d in kinds]
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=10, pady=10)
        b = ttk.Frame(f)
        b.pack(fill='x', pady=(0, 6))            # ★ 단추는 맨 위(§0)
        ttk.Button(b, text=_t('COMMON_SAVE', '저장'),
                   command=self._save).pack(side='left')
        ttk.Button(b, text=_t('COMMON_CANCEL', '취소'),
                   command=self.destroy).pack(side='left', padx=6)
        r = ttk.Frame(f)
        r.pack(fill='x')
        ttk.Label(r, text=_t('RM_KIND', '갈래')).pack(side='left')
        self._kind_var = tk.StringVar(value=self._kinds[0][1])
        ttk.Combobox(r, textvariable=self._kind_var, state='readonly', width=12,
                     values=[n for _c, n in self._kinds]).pack(side='left', padx=6)
        ttk.Label(r, text=_t('RA_TITLE_F', '제목')).pack(side='left', padx=(8, 0))
        self._title_var = tk.StringVar()
        ttk.Entry(r, textvariable=self._title_var, width=24).pack(
            side='left', padx=6, fill='x', expand=True)
        self._txt = tk.Text(f, width=54, height=6, wrap='word')
        self._txt.pack(fill='both', expand=True, pady=6)
        _tfr(self._txt, db_path, 'prose')
        if self._lead:
            a = ttk.Frame(f)
            a.pack(fill='x')
            self._files_var = tk.StringVar(value='')
            ttk.Button(a, text=_t('RM_ATTACH_ADD', '파일 첨부'),
                       command=self._add_file).pack(side='left')
            tk.Label(a, textvariable=self._files_var, anchor='w',
                     fg=_C('fg_dim', '#666')).pack(side='left', padx=6)
        hint = _t('RM_POST_HINT',
                  '저장한 글은 [올리기]를 해야 방의 다른 분들에게 전해집니다.')
        tk.Label(f, text=hint, anchor='w', justify='left', wraplength=420,
                 fg=_C('fg_dim', '#888')).pack(fill='x', pady=(6, 0))
        self.grab_set()

    def _add_file(self):
        import room_core as RC
        import room_share as RS
        from tkinter import filedialog
        fold = RC.folder_of(self.room)
        if not fold or not os.path.isdir(fold):
            messagebox.showinfo(_t('RM_BOARD', '게시판'),
                                _t('RA_NEED_FOLDER',
                                   '방 폴더를 먼저 정해 주세요 — 내 PC 에서 보이는 '
                                   '동기화 폴더 경로여야 합니다(웹 주소는 열 수 '
                                   '없습니다).'), parent=self)
            return
        p = filedialog.askopenfilename(parent=self,
                                       title=_t('RM_ATTACH_ADD', '파일 첨부'))
        if not p:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                uid = RC.my_uuid(conn)
            self._files.append(RS.attach_file(fold, uid, p))
        except Exception as e:
            messagebox.showerror(_t('RM_BOARD', '게시판'), str(e)[:200], parent=self)
            return
        self._files_var.set(' · '.join(x.split('_', 2)[-1] for x in self._files))

    def _save(self):
        body = self._txt.get('1.0', 'end').strip()
        kind = next((c for c, n in self._kinds if n == self._kind_var.get()), 'POST')
        if not body and not self._files:
            self.destroy()
            return
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                RS.save_post(conn, self.room['room_id'], kind, body,
                             title=self._title_var.get(), files=self._files,
                             lang=(self.lang_getter() or 'KO'))
        except Exception as e:
            messagebox.showerror(_t('RM_BOARD_WRITE', '글 쓰기'), str(e)[:200],
                                 parent=self)
            return
        self.destroy()
        if callable(self.on_done):
            self.on_done()


class _NoticeEdit(tk.Toplevel):
    """방 공지 쓰기 — **방장만 열린다**(입구도 저장도 둘 다 막힌다)."""

    def __init__(self, parent, db_path, room_id, cur, on_done):
        super().__init__(parent)
        self.db_path, self.room_id, self.on_done = db_path, room_id, on_done
        self.pk = (int(cur['notice_id']) if cur and
                   str(cur.get('notice_id', '')).isdigit() else None)
        self.title(_t('RM_NOTICE_EDIT', '공지 쓰기'))
        self.transient(parent.winfo_toplevel())
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=10, pady=10)
        b = ttk.Frame(f)
        b.pack(fill='x', pady=(0, 6))            # ★ 단추는 맨 위(§0)
        ttk.Button(b, text=_t('COMMON_SAVE', '저장'),
                   command=self._save).pack(side='left')
        ttk.Button(b, text=_t('COMMON_CANCEL', '취소'),
                   command=self.destroy).pack(side='left', padx=6)
        tk.Label(f, text=_t('RM_NOTICE_HINT',
                 '방장만 올릴 수 있습니다. 올리기를 하면 참여자에게 전해집니다. '
                 '비우고 저장하면 공지가 내려갑니다.'),
                 anchor='w', justify='left', wraplength=420,
                 fg=_C('fg_dim', '#888')).pack(fill='x', pady=(0, 6))
        self._txt = tk.Text(f, width=54, height=6, wrap='word')
        self._txt.pack(fill='both', expand=True)
        _tfr(self._txt, db_path, 'prose')
        if cur:
            self._txt.insert('1.0', cur.get('contents') or '')
        self.grab_set()

    def _save(self):
        body = self._txt.get('1.0', 'end').strip()
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                RS.save_notice(conn, self.room_id, body, pk=self.pk)
        except Exception as e:
            messagebox.showerror(_t('RM_NOTICE_EDIT', '공지 쓰기'),
                                 str(e)[:200], parent=self)
            return
        self.destroy()
        if callable(self.on_done):
            self.on_done()


class _VersePick(tk.Toplevel):
    """그 날 몫 안에서 구절 하나 선택하기."""

    def __init__(self, parent, rows, on_pick):
        super().__init__(parent)
        self.on_pick = on_pick
        self.title(_t('RM_LINK_VERSE', '구절과 연결'))
        self.transient(parent.winfo_toplevel())
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=10, pady=10)
        tk.Label(f, text=_t('RM_PICK_HINT',
                 '이 날 몫 안에서 선택합니다. 선택하면 그 구절의 묵상노트 아래 '
                 '「함께 나눈 글」에도 보입니다.'),
                 anchor='w', justify='left', wraplength=320).pack(fill='x')
        self._lb = tk.Listbox(f, height=14, width=26)
        self._lb.pack(fill='both', expand=True, pady=6)
        self._ids = []
        for vid, sn, ch, vs in rows:
            self._ids.append(vid)
            self._lb.insert('end', '%s %d:%d' % (sn, ch, vs))
        b = ttk.Frame(f)
        b.pack(fill='x')
        ttk.Button(b, text=_t('COMMON_OK', '확인'),
                   command=self._ok).pack(side='left')
        ttk.Button(b, text=_t('COMMON_CANCEL', '취소'),
                   command=self.destroy).pack(side='left', padx=6)
        self._lb.bind('<Double-1>', lambda _e: self._ok())
        self.grab_set()

    def _ok(self):
        s = self._lb.curselection()
        if not s:
            return
        vid = self._ids[s[0]]
        self.destroy()
        if callable(self.on_pick):
            self.on_pick(vid)


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    import sqlite3
    import tempfile
    import shutil
    errs = []
    root = tk.Tk()
    root.withdraw()
    tk.Tk.report_callback_exception = lambda s, e, v, tb: errs.append(
        '%s: %s' % (e.__name__, v))
    d = tempfile.mkdtemp(prefix='rmv_')
    dbp = os.path.join(d, 'bible_master.db')
    udb = os.path.join(d, 'user_data.db')
    opened = []
    _orig = appdb.connect
    # ⚠⚠ **상자가 뜨면 시험이 멈춘다** — 통째로 막는다.
    #   ★ 다만 오류 상자는 **삼키지 않고 모은다** — 삼키면 시험이 헛돈다.
    import tkinter.messagebox as _MB
    _mb_i, _mb_e, _mb_a = _MB.showinfo, _MB.showerror, _MB.askyesno
    _MB.showinfo = lambda *a, **k: None
    _MB.showerror = lambda *a, **k: errs.append('showerror: %s' % (a[1:2],))
    _MB.askyesno = lambda *a, **k: True

    def fake(path=None, *a, **k):
        c = sqlite3.connect(dbp)
        c.execute("ATTACH ? AS userdb", (udb,))
        opened.append(c)
        return c
    try:
        c0 = sqlite3.connect(dbp)
        c0.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY,"
                   " bcode INTEGER, chapter INTEGER, verse INTEGER)")
        c0.execute("CREATE TABLE book_names(book_code INTEGER, lang_code TEXT,"
                   " full_name TEXT, short_name TEXT)")
        # ⚠ 절이 셋뿐이면 1~3 이 **책 전체**가 되어 라벨이 「창세기」로 나온다
        #   — 시험 DB 가 작아서지 코드 결함이 아니다. 넉넉히 넣는다.
        c0.executemany("INSERT INTO bible_index VALUES(?,?,?,?)",
                       [(i, 1, 1, i) for i in range(1, 9)])
        c0.execute("INSERT INTO book_names VALUES(1,'KO','창세기','창')")
        c0.execute("CREATE TABLE sys_bible_plan(plan_id INTEGER PRIMARY KEY,"
                   " plan_code TEXT, duration_days INTEGER)")
        c0.execute("CREATE TABLE sys_plan_schedule(plan_id INTEGER, day INTEGER,"
                   " start_vid INTEGER, end_vid INTEGER, sort_order INTEGER)")
        c0.execute("INSERT INTO sys_bible_plan VALUES(1,'P1',30)")
        c0.executemany("INSERT INTO sys_plan_schedule VALUES(?,?,?,?,?)",
                       [(1, 1, 1, 1, 1), (1, 1, 2, 3, 2)])
        c0.commit()
        c0.close()
        cu = sqlite3.connect(udb)
        cu.execute("CREATE TABLE user_text_asset(user_text_id INTEGER PRIMARY KEY,"
                   " clicked_id INTEGER, target_id INTEGER, text_type TEXT,"
                   " title TEXT, contents TEXT, lang_code TEXT,"
                   " record_status TEXT, created_at TEXT, updated_at TEXT)")
        cu.execute("CREATE TABLE user_config(config_key TEXT PRIMARY KEY,"
                   " config_val TEXT)")
        cu.execute("CREATE TABLE user_feedback(id INTEGER PRIMARY KEY)")
        cu.execute("CREATE TABLE user_plan_enrollment(enrollment_id INTEGER "
                   "PRIMARY KEY, plan_id INTEGER, user_plan_id INTEGER,"
                   " current_day INTEGER, enrollment_status TEXT)")
        cu.execute("INSERT INTO user_plan_enrollment VALUES(1,1,NULL,3,'ACTIVE')")
        cu.commit()
        cu.close()
        appdb.connect = fake

        v = RoomMediView(root, dbp)
        v.pack()
        root.update()
        v.reload()
        root.update()
        t('★ 화면이 뜬다', v.winfo_exists())
        t('★ 방이 없으면 어디로 가야 하는지 말한다',
          v._empty.winfo_manager() == 'pack')

        import room_core as RC
        import room_share as RS
        with fake() as c:
            rid = RC.create_room(c, '우리방', 'CHURCH_TR', '나', terms_ok=True)
            RC.set_my_name(c, rid, '나')
        v.reload()
        root.update()
        t('★ 방이 생기면 안내가 걷힌다', v._empty.winfo_manager() != 'pack')
        t('  플랜 콤보가 찬다', bool(v._plan_cb.cget('values')),
          v._plan_cb.cget('values'))
        t('★★ 오늘 몫으로 간다(current_day=3)', v._day == 3, v._day)
        t('  날짜 표기', '3' in v._day_var.get(), v._day_var.get())

        v._day = 1
        v._render()
        root.update()
        t('★★★ **하루 범위 전체**를 보인다(구절 하나가 아니다)',
          '~' in v._span_var.get(), v._span_var.get())
        t('  P2 와 다름을 화면이 적는다',
          '범위 전체' in v._hint.get() and '묵상노트' in v._hint.get())

        # ── 쓰기 ─────────────────────────────────────────────────
        v._txt.insert('1.0', '오늘 몫 전체 묵상')
        v._save()
        with fake() as c:
            got = RS.note_of_day(c, rid, 'P1', 1)
        t('★ 하루 글이 저장된다', got and got['contents'] == '오늘 몫 전체 묵상',
          got['contents'] if got else None)
        t('★★ 구절이 안 붙어 있다(기본)', got['clicked_id'] is None)

        # ── 구절과 연결 ──────────────────────────────────────────
        v._on_picked(2)
        with fake() as c:
            got2 = RS.note_of_day(c, rid, 'P1', 1)
            p2 = RS.notes_of_verse(c, rid, 2, dbp)
        t('★★★ 구절을 붙이면 그 값이 담긴다', got2['clicked_id'] == 2,
          got2['clicked_id'])
        t('  화면이 연결을 적는다', bool(v._link_var.get()), v._link_var.get())

        # ── 나눔은 접혀 있다 ─────────────────────────────────────
        t('★★ 나눔이 접혀 있다(먼저 쓰고 그다음 읽는다)',
          not v._shared_open and v._sh.winfo_manager() != 'pack')
        t('  머리에 개수가 있다', '(0)' in v._sh_btn.cget('text'),
          v._sh_btn.cget('text'))
        v._toggle()
        root.update()
        t('  펼치면 왜 비었는지 말한다', v._shared_open)
        v._toggle()

        # ── 진도 ─────────────────────────────────────────────────
        with fake() as c:
            RS.ensure_room(rid, dbp)
            RS.attach(c, rid, dbp)
            c.execute("INSERT INTO roomshare.room_member(member_id,display_name,"
                      "record_status) VALUES('zz','박청년','LIVE')")
            c.commit()
        v._render()
        root.update()
        t('★★★ **누가 아직 안 썼나**를 보인다(P2 에서는 불가능)',
          '박청년' in v._who.get() and '아직' in v._who.get(), v._who.get())
        t('⚠ 압박하는 말을 안 쓴다', '미제출' not in v._who.get())

        # ── 날짜 이동 ────────────────────────────────────────────
        v._move(1)
        t('★ 날짜를 옮긴다', v._day == 2, v._day)
        v._move(-5)
        t('  1일차 아래로 안 간다', v._day == 1, v._day)
        for _ in range(40):
            v._move(1)
        t('  마지막 날을 안 넘는다', v._day == 30, v._day)

        # ── ★★★ 방 공지 — 방장만 ────────────────────────────────
        v._day = 1
        v._render()
        root.update()
        t('★ 방장에게는 [공지 쓰기] 가 보인다',
          v._can_notice and v._nt_f.winfo_manager() == 'pack')
        t('  공지가 없으면 그렇게 말한다', '없습니다' in v._nt_lbl.cget('text'),
          v._nt_lbl.cget('text'))
        with fake() as c:
            RS.save_notice(c, rid, '이번 주는 3일차까지')
        v._render()
        root.update()
        t('★★ 공지가 띠에 뜬다', '3일차' in v._nt_lbl.cget('text'),
          v._nt_lbl.cget('text'))

        # ⚠ 참여자 화면에서는 단추가 없다 — 역할을 바꿔 본다
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='MEMBER'"
                      " WHERE room_id=?", (rid,))
            c.commit()
        v.reload()
        root.update()
        # ⚠ **자식의 `winfo_manager` 로 재면 안 된다** — 프레임을 forget 해도
        #   자식은 'pack' 그대로다(실측으로 잡았다). **띠 자체**를 본다.
        t('★★★ **참여자에게는 공지 단추가 없다**', not v._can_notice,
          v._can_notice)
        t('★★ 내가 쓴 공지는 남의 화면에 안 뜬다(내 원본이므로)',
          v._notices == [] and v._nt_f.winfo_manager() != 'pack',
          (len(v._notices), v._nt_f.winfo_manager()))
        t('  띠를 걷을 때 옛 글자가 안 남는다', v._nt_lbl.cget('text') == '',
          v._nt_lbl.cget('text'))
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='LEADER'"
                      " WHERE room_id=?", (rid,))
            c.commit()

        # ── ★★★ 4단계 — 방 관리 입구 · 방 플랜 · 게시판 ──────────────
        v.reload()
        root.update()
        t('★★ 방장에게 [방 관리] 단추가 보인다(My Edit 과 별개)',
          v._adm_btn.winfo_manager() == 'pack')
        with fake() as c:
            RC.set_plan(c, rid, 'P1')
            RS.save_post(c, rid, 'GUIDE', '지침입니다')
        v.reload()
        root.update()
        t('★★★ 방 플랜이 콤보 맨 앞이고 기본이다',
          v._plan_cb.cget('values') and '방 플랜' in v._plan_var.get(),
          v._plan_var.get())
        t('★ 게시판 띠가 접힌 채 개수를 보인다',
          v._bd_btn.winfo_manager() == 'pack' and '(1)' in v._bd_btn.cget('text'),
          v._bd_btn.cget('text'))
        v._toggle_board()
        root.update()
        t('  펼치면 지침 글이 그려진다',
          v._board_open and any('지침입니다' in str(w.cget('text'))
                                for fr in v._bd.winfo_children()
                                for w in fr.winfo_children()
                                if isinstance(w, tk.Label)))
        v._toggle_board()
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='MEMBER'"
                      " WHERE room_id=?", (rid,))
            c.commit()
        v.reload()
        root.update()
        t('★★ 참여자에게는 [방 관리] 단추가 없다',
          v._adm_btn.winfo_manager() != 'pack')
        t('  참여자도 게시판은 본다', v._bd_btn.winfo_manager() == 'pack')
        # ── 5단계 — 마무리 띠 · 차단 띠 ───────────────────────────
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET room_status='CLOSED',"
                      " closed_at='2026-09-08' WHERE room_id=?", (rid,))
            c.commit()
        v.reload()
        root.update()
        t('★ 마무리된 방은 띠가 뜨고 진도 재촉이 없다',
          v._st_lbl.winfo_manager() == 'pack' and '마무리' in v._st_lbl.cget('text')
          and v._who.get() == '', (v._st_lbl.cget('text')[:20], v._who.get()))
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET room_status='OPEN', closed_at=NULL"
                      " WHERE room_id=?", (rid,))
            c.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY,"
                      " config_val TEXT)")
            c.execute("INSERT OR REPLACE INTO sys_config VALUES('ROOM_BLOCKLIST',?)",
                      ('{"%s": {"reason": "신고"}}' % rid,))
            c.commit()
        v.reload()
        root.update()
        t('★★ 막힌 방은 사유가 띠에 뜨고 올리기가 막힌다',
          '신고' in v._st_lbl.cget('text') and v._stop_if_blocked(),
          v._st_lbl.cget('text')[:30])
        with fake() as c:
            c.execute("DELETE FROM sys_config WHERE config_key='ROOM_BLOCKLIST'")
            c.commit()
        v.reload()
        root.update()
        t('  풀면 띠가 걷힌다', v._st_lbl.winfo_manager() != 'pack')
        # ── 시작일 · 부방장 · 자동 동기화 ────────────────────────
        from datetime import date as _date, timedelta as _td
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='LEADER' WHERE room_id=?", (rid,))
            c.commit()
            RC.set_plan_start(c, rid, (_date.today() - _td(days=4)).isoformat())
        v.reload()
        root.update()
        t('★★★ 오늘 = 방장 시작일에서 센다(등록 current_day=3 과 무관)',
          v._day == 5, v._day)
        t('  힌트에 시작일·오늘 일차', '5일차' in v._hint.get(), v._hint.get()[:40])
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='CO_LEADER' WHERE room_id=?",
                      (rid,))
            c.commit()
        v.reload()
        root.update()
        t('★★ 부방장에게도 [방 관리] 단추', v._adm_btn.winfo_manager() == 'pack')
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='LEADER' WHERE room_id=?", (rid,))
            RC.set_folder(c, rid, d)
            c.commit()
        v.reload()
        root.update()
        t('★★ 폴더가 있으면 탭에 들어올 때 저절로 받는다(머리에 시각)',
          '동기화' in v._sync_var.get(), v._sync_var.get())
        v._txt.delete('1.0', 'end')
        v._txt.insert('1.0', '자동 올리기 시험')
        v._save()
        root.update()
        t('★★ 저장하면 곧바로 올라간다', any(n.startswith('note_') for n in os.listdir(d)),
          [n for n in os.listdir(d) if n.startswith('note_')])
        t('  M 자리가 맨 오른쪽에 있다', v.manual_slot().winfo_manager() == 'pack')
        with fake() as c:
            c.execute("UPDATE userdb.user_room SET my_role='LEADER'"
                      " WHERE room_id=?", (rid,))
            c.commit()

        t('  Tk 오류 0', len(errs) == 0, errs[:2])
        src = io.open(os.path.abspath(__file__), encoding='utf-8').read()
        _v = 'VERS' + '_NOTE'
        t('★★ P2 묵상노트를 안 건드린다', _v not in src)
        t('★ 폴더 두 칸을 직접 안 읽는다(폴더 하나 규칙)',
          ("['folder" + "_b']") not in src and ("['folder" + "_a']") not in src)
    finally:
        appdb.connect = _orig
        _MB.showinfo, _MB.showerror, _MB.askyesno = _mb_i, _mb_e, _mb_a
        try:
            root.destroy()
        except Exception:
            pass
        for c in opened:
            try:
                c.close()
            except Exception:
                pass
        shutil.rmtree(d, ignore_errors=True)
    print('room_medi_view selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    r = tk.Tk()
    r.title('함께 묵상')
    r.geometry('900x700')
    RoomMediView(r, 'bible_master.db').pack(fill='both', expand=True)
    r.mainloop()
