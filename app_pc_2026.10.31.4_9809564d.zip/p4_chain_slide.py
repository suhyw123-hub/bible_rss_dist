# -*- coding: utf-8 -*-
"""
p4_chain_slide.py — 구속사연결 요약 패널 (P2 · 오른쪽 NodePanel 임베드) + 공용 조회.

2026-08-19 전면 재작성 (사용자 확정 설계):
  이 패널 = **훑기 + 진입점**이다. 체인마다 ① 이름(다국어 — 코드 노출 없음)
  ② 체인 설명문 ③ **구절 약명 나열**(현재 P1 구절이 ★로 두드러짐)
  ④ [자세히 읽기] 단추(→ P4 「구속사 연결 설명」)만 보인다.
  본문 열거·마디 순회·연결설명문 읽기는 전부 P4(chain_detail_view)의 몫 —
  같은 내용이 두 화면에 반복되지 않는다(내부자료→P4 자료 탭과 같은 역할 분담).

  옛 방식(Label 쌓기)은 wraplength 가 320px 시절 고정값이라 문장이 엔터 친
  것처럼 끊기고, 휠이 자식 위젯 위에서 죽고, 색·글꼴이 하드코딩이었다.
  → **Text 위젯 하나**로 교체: 줄바꿈이 폭을 따라오고, 스크롤이 그냥 되고,
  색은 태그로 그릴 때마다 테마에서 읽는다(§36-5b).

클릭 규약 (2026-08-19 사용자 확정):
  · 약명/단추 싱글클릭 = P4 「구속사 연결 설명」으로 (P1 은 절대 안 움직인다)
  · 약명 더블클릭 = P1 이동 (본격 묵상 전환 — 의도적일 때만)
"""

import tkinter as tk
import i18n
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)



def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return fallback


# ───────── 공용 조회 (요약 패널·P4 상세가 함께 쓴다 — 드리프트 0) ─────────

def chains_for(db_path, vid):
    """vid 가 멤버인 chain_code 목록 (PRG/DEP 흐름 체인만 — 옛 C 마커 판정과
    같은 SQL). 2026-08-19 C 마커 폐기 후 노드 클릭 자동 로드가 이것을 쓴다."""
    try:
        vid_i = int(vid)
    except (TypeError, ValueError):
        return []
    try:
        with appdb.connect(db_path) as c:
            rows = c.execute(
                "SELECT DISTINCT chain_code FROM sys_link_asset "
                " WHERE chain_code IS NOT NULL AND record_status='LIVE' "
                "   AND link_type='VERS_VERS' "
                "   AND rel_code IN ('PRG', 'DEP') "
                "   AND (clicked_id=? OR target_id=?) "
                " ORDER BY chain_code", (vid_i, vid_i)).fetchall()
        return [r[0] for r in rows]
    except Exception:
        return []


def all_chains(db_path, lang='KO'):
    """전체 체인 [(code, name)] — **이름 가나다/ABC 순** (2026-08-19 사용자 —
    「뒤섞여있다」: 예전에는 접두 그룹(PRG→INC→…)별로 가나다가 다시 시작해
    콤보에서 순서가 없는 것처럼 보였다. 그룹은 [전체보기] 화면이 보여준다).
    이름은 lang→EN→KO, 없으면 코드. 이름 규칙 = **핵심단어가 맨 앞**."""
    out = []
    try:
        with appdb.connect(db_path) as c:
            codes = [r[0] for r in c.execute(
                "SELECT DISTINCT chain_code FROM sys_link_asset "
                " WHERE chain_code IS NOT NULL AND record_status='LIVE' "
                "   AND link_type='VERS_VERS'").fetchall()]
        for code in codes:
            name, _d = chain_meta(db_path, code, lang)
            out.append((name or code, code))
    except Exception:
        pass
    out.sort()
    return [(code, name) for name, code in out]


def chain_meta(db_path, chain_code, lang='KO'):
    """sys_chain_catalog 의 (name, description) — lang→EN→KO 폴백.
    없으면 (None, None). **코드는 화면에 내보내지 않는다** — 이름이 없으면
    카탈로그에 등록하는 것이 답이다(2026-08-19 CHAIN_* 4개 등록)."""
    lang = (lang or 'KO').upper()
    try:
        with appdb.connect(db_path) as c:
            for lg in (lang, 'EN', 'KO'):
                row = c.execute(
                    "SELECT chain_name, description FROM sys_chain_catalog "
                    " WHERE chain_code=? AND UPPER(lang_code)=? "
                    "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                    (chain_code, lg)).fetchone()
                if row and (row[0] or row[1]):
                    return row[0], row[1]
    except Exception:
        pass
    return None, None


def chain_members(db_path, chain_code, lang='KO', ver_code=None):
    """chain 의 멤버 절 시퀀스와 링크 설명문.

    반환: ([(vid, ref, body, bcode, chapter, verse)], [(from_idx, to_idx, desc)])
    desc = VERS_VERS_DESC (lang→KO 폴백). 장·절 숫자는 구간 병합 라벨용."""
    lang = (lang or 'KO').upper()
    if not ver_code:
        ver_code = _lang_to_version(db_path, lang)
    with appdb.connect(db_path) as c:
        rows = c.execute(
            "SELECT l.sys_link_id, l.clicked_id, l.target_id, "
            "       (SELECT t.contents FROM sys_text_asset t "
            "         WHERE t.clicked_id=l.sys_link_id "
            "           AND t.text_type='VERS_VERS_DESC' "
            "           AND UPPER(t.lang_code)=UPPER(?) "
            "           AND COALESCE(t.record_status,'LIVE')='LIVE' "
            "         ORDER BY t.sys_text_id DESC LIMIT 1), "
            "       (SELECT t.contents FROM sys_text_asset t "
            "         WHERE t.clicked_id=l.sys_link_id "
            "           AND t.text_type='VERS_VERS_DESC' "
            "           AND UPPER(t.lang_code)='KO' "
            "           AND COALESCE(t.record_status,'LIVE')='LIVE' "
            "         ORDER BY t.sys_text_id DESC LIMIT 1) "
            "  FROM sys_link_asset l "
            " WHERE l.chain_code=? AND l.record_status='LIVE' "
            "   AND l.link_type='VERS_VERS' "
            " ORDER BY l.sys_link_id", (lang, chain_code)).fetchall()

        seq, links, _seen = [], [], set()
        for (_lid, a, b, d_lang, d_ko) in rows:
            if a not in seq:
                seq.append(a)
            if b not in seq:
                seq.append(b)
            d = d_lang or d_ko or ''
            if (a, b, d) in _seen:
                continue        # 같은 쌍·같은 글 중복 링크(rel_code 만 다른 행) 접기
            _seen.add((a, b, d))
            links.append((a, b, d))

        verse_rows = []
        for vid in seq:
            r = c.execute(
                "SELECT bi.bcode, bi.chapter, bi.verse, bn.short_name "
                "  FROM bible_index bi "
                "  LEFT JOIN book_names bn ON bn.book_code=bi.bcode "
                "                         AND bn.lang_code=? "
                " WHERE bi.verse_id=?", (lang, vid)).fetchone()
            if not r:
                continue
            bc, ch, vs, sn = r
            # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text).
            #   ⚠ 옛 코드는 없으면 **아무 역본이나** 집어 와 어느 역본인지
            #     못 밝혔다 — 지금은 빌려 온 역본을 글에 적는다.
            _b = _vt.resolve(c, vid, ver_code, lang)['text']
            verse_rows.append((vid, f'{sn or bc}{ch}:{vs}', _b, bc, ch, vs))

        vids = [v[0] for v in verse_rows]
        link_rows = []
        for (a, b, d) in links:
            if a in vids and b in vids:
                link_rows.append((vids.index(a), vids.index(b), d))
        return verse_rows, link_rows


def _lang_to_version(db_path, lang):
    """현재 성경버전(단일 소스 user_config['v1_code']). 없으면 언어별 기본값."""
    try:
        import verse_tier
        v = verse_tier.get_version(db_path, None)
        if v:
            return v
    except Exception:
        pass
    return {
        'KO': 'KRV', 'EN': 'BSB', 'ZH': 'CUVS', 'JA': 'JLV',
        'DE': 'GerElb', 'FR': 'FreJND', 'ES': 'SpaRV',
        'AR': 'ARB', 'RU': 'RusSyn', 'PT': 'PorBL',
    }.get((lang or 'KO').upper(), 'BSB')


# ───────── 요약 패널 ─────────

class ChainSlidePanel(tk.Frame):
    """P2 · NodePanel 「구속사연결」 갈래의 내용물 (임베드 전용)."""

    def __init__(self, parent, db_path, lang_provider=None,
                 on_verse_click=None, on_detail=None,
                 show_header=False, **kwargs):
        # show_header 는 옛 슬라이드 모드의 흔적 — 이제 늘 임베드다(호환 수용만).
        kwargs.setdefault('bd', 0)
        kwargs.setdefault('relief', 'flat')
        show_edit = kwargs.pop('show_edit', True)
        kwargs.pop('width', None)
        super().__init__(parent, bg=_C('bg', '#FAFAFA'), **kwargs)
        self.db_path = db_path
        self.lang_provider = lang_provider or (lambda: 'KO')
        self.on_verse_click = on_verse_click        # 더블클릭 → P1 이동
        self.on_detail = on_detail                  # 싱글클릭/단추 → P4 상세
        self._current_vid = None
        self._click_job = None

        # ★★ **[My Edit]** (2026-08-30 사용자 지시 0.txt 2)P2 「P2 흐름묵상 탭 :
        #   My Edit 버튼 배치」). 구속사연결은 구절연결(`VERS_VERS`) 위에 얹힌
        #   태그라 **손으로 잇는 자리**가 필요하다 — 그전에는 읽기만 됐다.
        #   ⚠ 단추는 **맨 위**(§0). 본문 Text 보다 **먼저** pack 한다 —
        #     expand 자식 뒤에 붙이면 1px 로 사라진다(문서에 다섯 번 적힌 함정).
        #   ⚠⚠ **밖에 이미 있으면 안 그린다** (2026-08-31 사용자 신고 「My Edit,
        #     M 버튼 아래에 **My Edit 버튼이 또 있다.** 제거하고 아래 공간을
        #     넓게 확보하라」). P2 흐름묵상은 갈래 줄에 [My Edit]·[M] 이 있고
        #     이 패널이 또 하나를 그려 **한 화면에 둘**이었다.
        #     ⚠ 이 패널은 P4 NodePanel 도 쓴다 — 거기엔 밖의 단추가 없으므로
        #       **지우지 않고 호스트가 끄게** 한다.
        self._edit_btn = None
        if show_edit:
            _bar = tk.Frame(self, bg=_C('bg', '#FAFAFA'))
            _bar.pack(side='top', fill='x')
            self._edit_btn = tk.Button(
                _bar, text=i18n.t('OE_BTN', 'My Edit'),
                command=self._open_my_edit, **_flat())
            self._edit_btn.pack(side='right', padx=6, pady=2)

        sb = tk.Scrollbar(self, orient='vertical')
        sb.pack(side='right', fill='y')
        self._txt = tk.Text(self, wrap='word', bd=0, state='disabled',
                            cursor='arrow', padx=10, pady=8,
                            bg=_C('bg', '#FAFAFA'),
                            yscrollcommand=sb.set)
        sb.config(command=self._txt.yview)
        self._txt.pack(fill='both', expand=True)
        try:
            import theme_font
            theme_font.register(self._txt, self.db_path, 'prose')
        except Exception:
            pass

    def _open_my_edit(self):
        """이 구절을 출발지로 — 재고창고에서 「말씀의 흐름」 갈래가 눌린 채."""
        if not self._current_vid:
            return
        try:
            import my_edit
            my_edit.open(self, 'VERSE', self._current_vid, pick_kind='CHAIN')
        except Exception as e:
            print('[chain my edit] %s' % e)

    def _retag(self):
        """태그 색 — 그릴 때마다 그 시점 테마로 (§36-5b)."""
        t = self._txt
        t.tag_configure('h', foreground=_C('accent', '#1F618D'), spacing1=8)
        t.tag_configure('desc', foreground=_C('fg_dim', '#666'),
                        lmargin1=12, lmargin2=12, spacing1=2)
        t.tag_configure('refs', foreground=_C('fg', '#333'),
                        lmargin1=12, lmargin2=12, spacing1=4)
        t.tag_configure('ref', foreground=_C('accent', '#1F618D'))
        t.tag_configure('cur', foreground=_C('danger', '#C0392B'),
                        background=_C('accent_bg', '#EAF2F8'))
        t.tag_configure('empty', foreground=_C('fg_dim', '#999'), spacing1=10)

    # ── 외부 API (기존 이름 유지) ────────────────────────────────────

    def show_for(self, vid, chain_codes):
        self._current_vid = int(vid) if vid is not None else None
        self._retag()
        t = self._txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        # 이전 렌더의 약명 태그·단추 정리
        for tag in t.tag_names():
            if tag.startswith('r_'):
                t.tag_delete(tag)
        lang = (self.lang_provider() or 'KO')

        if not chain_codes:
            t.insert('end', i18n.t('PCS_NOCHAIN', '연결된 흐름이 없습니다.'),
                     ('empty',))
        else:
            for cc in chain_codes:
                self._render_chain(cc, lang)
        t.config(state='disabled')
        try:
            import ui_theme
            if ui_theme.current() != ui_theme.DEFAULT:
                ui_theme.paint(self)            # 단추(동적 위젯)까지 테마 추종
        except Exception:
            pass

    def hide(self):
        self.pack_forget()

    def set_pw_anchor(self, *_a):
        pass                                    # 옛 슬라이드 모드 호환

    # ── 내부 ────────────────────────────────────────────────────────

    def _render_chain(self, chain_code, lang):
        t = self._txt
        name, desc = chain_meta(self.db_path, chain_code, lang)
        try:
            members, _links = chain_members(self.db_path, chain_code, lang)
        except Exception:
            members = []
        pos = ''
        vids = [m[0] for m in members]
        if self._current_vid in vids:
            pos = '  %d/%d' % (vids.index(self._current_vid) + 1, len(vids))

        t.insert('end', '◆ %s%s  ' % (name or chain_code, pos), ('h',))
        btn = tk.Button(t, text=i18n.t('PCS_DETAIL', '자세히 읽기'),
                        bd=0, padx=8, pady=1, cursor='hand2',
                        bg=_C('accent_bg', '#D6EAF8'), fg=_C('accent', '#1F618D'),
                        command=lambda c=chain_code: self._open_detail(c, self._current_vid))
        t.window_create('end', window=btn)
        t.insert('end', '\n')
        if desc:
            t.insert('end', desc + '\n', ('desc',))

        # 약명 나열 — 현재 절이 ★로 두드러진다 (사용자 확정: 본문은 P4 몫)
        t.insert('end', '', ('refs',))
        for i, (vid, ref, *_rest) in enumerate(members):
            if i:
                t.insert('end', ' · ', ('refs',))
            rtag = 'r_%s_%d' % (chain_code, vid)
            cur = (vid == self._current_vid)
            tags = ('refs', 'ref', rtag) + (('cur',) if cur else ())
            t.insert('end', ('★' + ref) if cur else ref, tags)
            t.tag_bind(rtag, '<Button-1>',
                       lambda e, c=chain_code, v=vid: self._click_once(c, v))
            t.tag_bind(rtag, '<Double-1>',
                       lambda e, v=vid: self._dbl(v))
        t.insert('end', '\n')

    def _click_once(self, chain_code, vid):
        # 더블클릭과 가르기 — 300ms 안에 두 번째 클릭이 오면 싱글을 무른다
        if self._click_job:
            self.after_cancel(self._click_job)
        self._click_job = self.after(
            300, lambda: self._open_detail(chain_code, vid))
        return 'break'

    def _dbl(self, vid):
        if self._click_job:
            self.after_cancel(self._click_job)
            self._click_job = None
        if callable(self.on_verse_click):
            self.on_verse_click(vid)
        return 'break'

    def _open_detail(self, chain_code, vid):
        self._click_job = None
        if callable(self.on_detail):
            self.on_detail(chain_code, vid)
