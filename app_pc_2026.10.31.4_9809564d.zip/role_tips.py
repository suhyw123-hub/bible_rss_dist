# -*- coding: utf-8 -*-
"""role_tips.py — **분야별 도움말** 단일 소스 (2026-10-13 신설 · 영구 · `--selftest`).

사용자 확정(docs/1.txt 76-3) — 「사용자가 누구든지 분야별 도움말이 사전에 저장 · 각자 자기에게 해당하는 것을 읽는다 ·
분야별로 선택하는 기능 · 내 분야 관점으로 묻기는 프롬프트와 버튼 하나 · 그 결과를 도움말에 저장」.

· 저장 = `sys_text_asset`(text_type='VERS_ROLE_TIP', text_variant=분야, clicked_id=verse_id, lang_code) — 배포되는 글.
         `user_text_asset`(같은 꼴) — **내 도움말**(AI 에게 물어 저장한 것 · 그 분야는 내 것이 앞선다).
· 분야 = AI 도우미 상태 코드와 같다(`S_PASTOR` 목회 · `S_MISSION` 선교 · `S_STUDENT` 신학생 · `S_PWIFE` 사모) —
  두 곳에서 따로 정하면 갈린다.
· 보일 분야 = `user_config['ROLE_TIP_SHOW']`(쉼표) · 처음 = AI 도우미의 내 상태(`AI_STATE`)가 넷 중 하나면 그것, 아니면 넷 다.
· 화면은 [전문] 아래(연구질문 다음) — `user_main._role_sections` · 고르는 메뉴 = `desc_comm_group` 「분야 ▾」.
"""
import i18n

TYPE = 'VERS_ROLE_TIP'
# ★ 2026-10-21 사용자 「신학생은 분류에서 제거하라. 3개만 유지하자」 — 배포 글(S_STUDENT)은 지우지 않는다(안 보일 뿐)
ROLES = (('S_PASTOR', 'ROLE_PASTOR', '목회', 'Pastoral'),
         ('S_MISSION', 'ROLE_MISSION', '선교', 'Mission'),
         ('S_PWIFE', 'ROLE_PWIFE', '사모', "Pastor's wife"))
CODES = tuple(r[0] for r in ROLES)
SHOW_KEY = 'ROLE_TIP_SHOW'
# ★ 2026-10-26 [일반] 설명의 분야 = 평신도의 삶의 자리(docs/1.txt 6-2 · 사용자 「전문사역자가 아닌 일반 평신도들이므로
#   당연히 구분값이 달라야 한다」). 업무(RT_*)·이름은 `user_ai.LAY_WHO` 와 같은 코드 · 보일 분야는 따로 기억한다.
LAY_ROLES = (('L_BIZ', 'ROLE_L_BIZ', '사업가', 'Business'),
             ('L_WORK', 'ROLE_L_WORK', '직장인', 'Workplace'),
             ('L_YOUTH', 'ROLE_L_YOUTH', '학생/청년', 'Students & youth'),
             ('L_PUBLIC', 'ROLE_L_PUBLIC', '공무원/정치인', 'Public service'),
             ('L_MED', 'ROLE_L_MED', '의료계', 'Healthcare'),
             ('L_LAW', 'ROLE_L_LAW', '법조계', 'Law'),
             ('L_RETIRE', 'ROLE_L_RETIRE', '은퇴자', 'Retirees'))
LAY_CODES = tuple(r[0] for r in LAY_ROLES)
SHOW_KEY_LAY = 'ROLE_TIP_SHOW_LAY'


def roles(tier='EXPERT'):
    """그 설명 층의 분야 표 — [일반](LAY) = 평신도 · [전문] = 사역자."""
    return LAY_ROLES if str(tier).upper() == 'LAY' else ROLES


def codes(tier='EXPERT'):
    return tuple(r[0] for r in roles(tier))

#: 「내 분야 관점으로 묻기」 — 보낼 요구사항(AI 도우미 입력 칸에 채운다 · 사람이 고쳐 보낼 수 있다)
ASK = {
    'S_PASTOR': '이 구절을 설교하려는 목회자에게 도움말을 주세요. 설교의 중심 메시지, 청중이 붙잡을 한 문장, '
                '빠지기 쉬운 오해 하나를 2~4문장으로. 성경 본문에 근거하고 교단 색을 입히지 마세요.',
    'S_MISSION': '이 구절을 선교 현장(다른 문화·다른 언어)에서 전하려는 선교사에게 도움말을 주세요. '
                 '문화적으로 걸리는 낱말이나 개념, 그리고 그것을 풀어 전하는 방법을 2~4문장으로.',
    'S_STUDENT': '이 구절을 공부하는 신학생에게 도움말을 주세요. 더 파고들 원어·문맥·해석사의 실마리를 '
                 '2~4문장으로, 읽을 거리를 지어내지 말고.',
    'S_PWIFE': '사모(목회자의 아내)로서 이 구절을 성도 돌봄과 상담, 자기 신앙에 적용하려는 분에게 도움말을 주세요. '
               '2~4문장으로, 훈계하지 말고 따뜻하게.',
}
for _c, _k, _ko, _en in LAY_ROLES:
    ASK[_c] = ('%s의 자리에서 이 구절을 읽는 평신도에게 도움말을 주세요. 그 삶의 자리에서 이 본문이 비추는 것과 '
               '오늘 해 볼 작은 걸음 하나를 2~4문장으로, 훈계하지 말고.' % _ko)


def label(code):
    for c, k, ko, _en in ROLES + LAY_ROLES:
        if c == code:
            return i18n.t(k, ko)
    return code


def _cfg(conn, key, default=''):
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        return r[0] if r and r[0] is not None else default
    except Exception:
        return default


def my_role(conn):
    """AI 도우미의 내 상태가 네 분야 중 하나면 그것 — 아니면 ''."""
    s = (_cfg(conn, 'AI_STATE') or '').strip().upper()
    return s if s in CODES else ''


FIELD_KEY = 'AI_LAY_FIELD'          # ★ 2026-10-28 docs/1.txt 4-2 — User 가 평신도·초신자·선택 안 함일 때 고른 분야(일반 설명문 분야의 처음 값)
LAY_STATES = ('S_NONE', 'S_NEW', 'S_LAY')


def my_field(conn):
    """User 에서 고른 평신도 분야 — 그 상태(평신도 갈래)일 때만 · 아니면 ''."""
    s = (_cfg(conn, 'AI_STATE') or '').strip().upper()
    f = (_cfg(conn, FIELD_KEY) or '').strip().upper()
    return f if (s in LAY_STATES or not s) and f in LAY_CODES else ''


def get_show(conn, tier='EXPERT'):
    """보일 분야(차례 유지) — 층마다 따로 기억한다."""
    cs = codes(tier)
    raw = _cfg(conn, SHOW_KEY_LAY if str(tier).upper() == 'LAY' else SHOW_KEY)
    if raw:
        got = [c for c in cs if c in {x.strip().upper() for x in raw.split(',')}]
        if got or raw.strip() == '-':
            return got[:1]          # ★ 2026-10-21 하나만(사용자) — 옛 값이 여럿이면 첫째
    # 처음 값 = User 설정(사역자면 그 분야 · 평신도면 User 에서 고른 분야) — 그 뒤로는 따로 바꾼다(자동으로 따라가지 않는다)
    me = my_role(conn) if str(tier).upper() != 'LAY' else my_field(conn)
    return [me] if me else [cs[0]]


def tier_of(code):
    return 'LAY' if str(code or '').upper() in LAY_CODES else 'EXPERT'


def set_show(conn, codes_, tier=None, commit=True):
    tier = tier or tier_of((list(codes_) or [''])[0])
    cs = codes(tier)
    key = SHOW_KEY_LAY if str(tier).upper() == 'LAY' else SHOW_KEY
    val = ','.join(c for c in cs if c in set(codes_)) or '-'
    if conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key)).rowcount == 0:
        conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (key, val))
    if commit:                      # ⚠ selftest 는 SAVEPOINT 안이라 commit=False(커밋하면 시험 값이 실제로 남는다)
        conn.commit()


def fetch(conn, vid, lang, roles=None):
    """→ [(분야, 이름, 글, 내것인가)] — 그 분야의 내 도움말이 배포 글보다 앞선다 · 언어는 lang → EN → KO."""
    roles = list(roles if roles is not None else CODES)
    out = []
    for code in roles:
        row = None
        for lg in (lang, 'EN', 'KO'):
            try:
                row = conn.execute(
                    "SELECT contents, 1 FROM userdb.user_text_asset WHERE text_type=? AND text_variant=? "
                    "AND clicked_id=? AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT') "
                    "ORDER BY rowid DESC LIMIT 1", (TYPE, code, int(vid), lg)).fetchone()
            except Exception:
                row = None
            if not row:
                row = conn.execute(
                    "SELECT contents, 0 FROM sys_text_asset WHERE text_type=? AND text_variant=? AND clicked_id=? "
                    "AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                    (TYPE, code, int(vid), lg)).fetchone()
            if row and (row[0] or '').strip():
                break
            row = None
        if row:
            out.append((code, label(code), row[0].strip(), bool(row[1])))
    return out


def save_mine(conn, vid, role, lang, text):
    """내 도움말로 저장(그 구절·분야·언어 한 편 — 다시 저장하면 덮는다)."""
    role = (role or '').upper()
    if role not in CODES + LAY_CODES:
        raise ValueError('분야를 모릅니다: %s' % role)
    lang = (lang or 'KO').upper()
    cur = conn.execute(
        "UPDATE userdb.user_text_asset SET contents=?, record_status='EDIT', updated_at=datetime('now','localtime') "
        "WHERE text_type=? AND text_variant=? AND clicked_id=? AND UPPER(lang_code)=?",
        (text.strip(), TYPE, role, int(vid), lang))
    if cur.rowcount == 0:
        conn.execute("INSERT INTO userdb.user_text_asset(clicked_id, text_type, text_variant, lang_code, contents, "
                     "record_status, created_at, updated_at) VALUES(?,?,?,?,?,'NEW',datetime('now','localtime'),"
                     "datetime('now','localtime'))", (int(vid), TYPE, role, lang, text.strip()))
    conn.commit()


def ask_text(role, ref):
    return '%s — %s' % (ref, ASK.get(role, ASK['S_PASTOR']))


def selftest():
    import appdb
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)
    c = appdb.connect()
    c.execute('SAVEPOINT rt')
    try:
        ck([r[0] for r in ROLES] == ['S_PASTOR', 'S_MISSION', 'S_PWIFE'], '분야 셋 = AI 상태 코드(신학생 걷음)')
        c.execute("DELETE FROM user_config WHERE config_key=?", (SHOW_KEY,))
        c.execute("DELETE FROM user_config WHERE config_key='AI_STATE'")
        ck(get_show(c) == [CODES[0]], '처음 · 내 상태 없음 → 첫 분야 하나(목회)')
        c.execute("INSERT INTO user_config(config_key, config_val) VALUES('AI_STATE','S_MISSION')")
        ck(get_show(c) == ['S_MISSION'], '처음 · 내 상태 = 선교 → 선교만')
        c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?, 'S_PWIFE,S_PASTOR,S_STUDENT')", (SHOW_KEY,))
        ck(get_show(c) == ['S_PASTOR'], '하나만 · 옛 값이 여럿이면 표 차례의 첫째 · 걷은 분야(신학생)는 빠진다')
        c.execute("UPDATE user_config SET config_val='-' WHERE config_key=?", (SHOW_KEY,))
        ck(get_show(c) == [], '다 끄면 빈 목록')
        c.execute("INSERT INTO sys_text_asset(clicked_id, text_type, text_variant, lang_code, contents) "
                  "VALUES(-77, ?, 'S_PASTOR', 'KO', '배포 글')", (TYPE,))
        ck(fetch(c, -77, 'KO', ['S_PASTOR']) == [('S_PASTOR', label('S_PASTOR'), '배포 글', False)], '배포 글을 읽는다')
        c.execute("INSERT INTO userdb.user_text_asset(clicked_id, text_type, text_variant, lang_code, contents, record_status) "
                  "VALUES(-77, ?, 'S_PASTOR', 'KO', '내 글', 'NEW')", (TYPE,))
        ck(fetch(c, -77, 'KO', ['S_PASTOR'])[0][2:] == ('내 글', True), '내 도움말이 앞선다')
        ck(fetch(c, -77, 'JA', ['S_PASTOR'])[0][2] == '내 글', '언어가 없으면 EN → KO 로 물러난다')
        ck(fetch(c, -77, 'KO', ['S_MISSION']) == [], '없는 분야는 안 낸다(지어내지 않는다)')
        ck(codes('LAY') == LAY_CODES and 'L_BIZ' in LAY_CODES and not set(LAY_CODES) & set(CODES), '[일반] = 평신도 분야 · 사역자 분야와 안 겹친다')
        c.execute("DELETE FROM user_config WHERE config_key=?", (SHOW_KEY_LAY,))
        ck(get_show(c, 'LAY') == ['L_BIZ'], '[일반] 처음 = 첫 평신도 분야')
        set_show(c, ['L_MED'], commit=False)
        ck(get_show(c, 'LAY') == ['L_MED'] and get_show(c) == [], '[일반] 고른 것은 따로 기억(전문 값 불변)')
        ck(label('L_MED') and tier_of('L_MED') == 'LAY' and tier_of('S_PASTOR') == 'EXPERT', '이름 · 층 판정')
    finally:
        c.execute('ROLLBACK TO rt')
        c.execute('RELEASE rt')
        c.commit()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
