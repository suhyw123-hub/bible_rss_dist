# -*- coding: utf-8 -*-
"""연구자료 서식 게이트 — 사용자가 정해 준 꼴을 지키는가 (1.txt 16-1 · 4·5).

★★★ **사용자 지시가 곧 잣대다**(2026-09-24):
  · 「각종 기호는 사용하지 않고 **1. 1) A. A)** 와 같은 형식으로 한다」
  · 「아무런 **숨겨진 서식기능**을 사용해서는 안된다」
  · 「분량 : **A4용지 1장 미만**. 그런데, **중요한 주제는 분량이 많아도 된다**」
  · 「**장연결 금지, 구절표현방법 명시**」(314차) — 장만 가리킨 참조는 ⑥ 이
    **알림**으로 잡는다. 읽는 문은 `scripture_ref` 단일 소스다.
  · 「원어를 분석할 때에는 **히브리어/헬라어 음독, 원어를 괄호**로 표시」
  · 「인용구절 … 다만 **버전, 구절약명, 본문**을 표시해야 한다. 서식은 네가 정하라」

★★★ **인용 서식을 여기서 정한다** — 줄 하나에 `KRV 창 1:3 본문` 꼴이다.
  그래야 ⓐ 기호가 안 들어가고 ⓑ **기계가 약명을 뽑아 구절 연결을 만든다**
  (사용자 「연관성이 있는 구절 약명까지 db 형태로 가져올 수 있어야 한다」).
  ⇒ 서식을 자유롭게 두면 5번 지시의 뒷부분이 통째로 불가능해진다.

⚠⚠ **분량 초과는 막지 않는다 — 알림으로만 적는다.** 사용자가 「중요한
  주제는 분량이 많아도 된다」고 못 박았다. 막으면 코드가 그 지시를 뒤집는다.
  하한은 막는다 — 두어 문장짜리는 연구자료가 아니라 설명문이다.
⚠ **첫 줄은 제목이다** — 유닛 이름이 거기서 온다. 비면 이름 없는 글이 된다.
"""
import re
import sys

MIN_KO = 400            # 이보다 짧으면 연구자료가 아니다 (막는다)
SOFT_MAX = 1800         # A4 한 장 어림 — **넘어도 막지 않는다**(알림)
MAX_TITLE = 60

# ── 쓸 수 있는 줄머리 — 사용자가 적어 준 넷뿐 ────────────────────────
NUM_HEAD = re.compile(r'^(?:\d{1,2}[.)]|[A-Z][.)])\s')
#   번호는 맞는데 뒤에 칸이 없는 꼴 — `1)바라는`
NUM_HEAD_TIGHT = re.compile(r'^(?:\d{1,2}[.)]|[A-Z][.)])\S')

# ── 쓰면 안 되는 줄머리 기호 ─────────────────────────────────────────
#   ⚠ 여는 따옴표(「 “ ')는 넣지 않는다 — 인용 문장이 그것으로 시작한다.
BAD_HEAD = ('-*+•·▪■●◆★☆'
            '※→⇒#>▶▸–—')

# ── 숨은 서식 ────────────────────────────────────────────────────────
HIDDEN = [
    (re.compile(r'\*\*|__'),               '굵게 표시(** 또는 __)'),
    (re.compile(r'^#{1,6}\s', re.M),       '머리글 표시(#)'),
    (re.compile(r'`'),                     '코드 표시'),
    (re.compile(r'^\s*\|.*\|', re.M),      '표'),
    (re.compile(r'<[a-zA-Z/][^>]{0,40}>'), 'HTML 태그'),
    (re.compile(r'\t'),                    '탭 문자'),
    (re.compile(r'　'),                '전각 공백'),
    (re.compile(r'^\s*[-=_]{3,}\s*$', re.M), '가로줄'),
]

# ── 원어 ─────────────────────────────────────────────────────────────
HEB = re.compile(r'[֐-׿]')
GRK = re.compile(r'[Ͱ-Ͽἀ-῿]')
#   음독(원어) — 앞에 한글 음독이 붙고 원어가 괄호 안에 있다
OK_ORIG = re.compile(r'[가-힣]+\s*\(\s*[֐-׿Ͱ-Ͽ'
                     r'ἀ-῿][^)]*\)')
#   ★ 295차 — 한국어가 아닌 글에서는 **그 언어 글자**로 적은 음독을 받는다
#     (`Phyteuo (φυτεύω)` · `巴达尔（בדל）`). 실측 영어·중국어 번역 24편이 「음독이
#     없다」로 헛걸렸다 — 한글 음독을 영어 글에 요구하는 것은 잣대가 틀린 것이다.
#     원어 글자(히브리·헬라) 자체는 음독으로 치지 않는다.
OK_ORIG_ANY = re.compile(r'[^\W\d_\u0590-\u05FF\u0370-\u03FF\u1F00-\u1FFF]+\s*[(（]\s*[֐-׿Ͱ-Ͽ'
                         r'ἀ-῿][^)）]*[)）]')

# ── 인용 구절 ────────────────────────────────────────────────────────
#   `KRV 창 1:3 본문`  /  `BSB Gen 1:3 text`
CITE = re.compile(r'^([A-Z][A-Za-z0-9]{1,9})\s+'
                  r'(\S{1,12}(?:\s\S{1,12})?)\s+'
                  r'(\d{1,3}:\d{1,3}(?:-\d{1,3})?)\s+(\S.*)$')
#   역본 없이 약명만 적은 줄 — 인용인데 버전이 빠진 것
CITE_NOVER = re.compile(r'^\S{1,12}\s*\d{1,3}:\d{1,3}(?:-\d{1,3})?\s+\S')


def _lines(text):
    return [l.rstrip() for l in (text or '').replace('\r\n', chr(10))
            .replace('\r', chr(10)).split(chr(10))]


def title_of(text):
    """첫 줄 = 제목. 없으면 `''`."""
    for l in _lines(text):
        if l.strip():
            return l.strip()
    return ''


def body_of(text):
    """제목을 뺀 본문."""
    ls = _lines(text)
    for i, l in enumerate(ls):
        if l.strip():
            return chr(10).join(ls[i + 1:]).strip()
    return ''


def cites(text):
    """글 안의 인용 구절 — `[(역본, 약명, 장절, 본문)]`.

    ★ 이것이 **구절 연결의 재료**다(사용자 5번). 서식을 한 꼴로 정한 값이
      여기서 난다 — 자유 서식이면 약명을 뽑을 길이 없다.
    """
    out = []
    for l in _lines(body_of(text)):
        m = CITE.match(l.strip())
        if m:
            out.append((m.group(1), m.group(2).strip(), m.group(3),
                        m.group(4).strip()))
    return out


def check(text, strict_len=True, lang='KO', conn=None, min_ko=None):
    """흠 목록. 빈 목록이면 통과. `lang` = 써 넣은 언어(음독 글자를 정한다).

    ⚠ 분량 초과는 흠이 아니라 **알림**이라 `(` 로 시작한다 —
      `db_ai_run._is_note` 가 그것을 흠에서 걸러 낸다.
    ★ `conn` 을 주면 **장만 가리킨 참조**까지 잰다(314차 · ⑥). 안 주면 그
      항목만 건너뛴다 — 책 이름표가 DB 에 있어야 읽을 수 있다.
      ⚠ `conn` 은 **맨 뒤**다. 부르는 자리가 `check(text, lang=lang)` 꼴이라
        앞에 끼우면 조용히 어긋난다.
    """
    bad = []
    t = (text or '').strip()
    if not t:
        return ['글이 비었습니다.']
    ti, bd = title_of(t), body_of(t)
    # ★ 317차-18 ⑥ — 표(`|` 표·격자 표)는 저장할 때 구조로 바뀐다(ref_doc.absorb) — 표 줄의
    #   `+`·`|` 를 줄머리 기호·숨은 서식으로 재지 않게 먼저 자리표로 바꾼다.
    try:
        import ref_doc as _RD
        bd = _RD.absorb(bd)[0]
    except Exception:                                     # noqa: BLE001
        pass
    if not ti:
        bad.append('첫 줄에 제목이 없습니다.')
    elif len(ti) > MAX_TITLE:
        bad.append('제목이 깁니다 — %d자 (넘으면 안 되는 값 %d)'
                   % (len(ti), MAX_TITLE))
    elif NUM_HEAD.match(ti) or (ti[0] in BAD_HEAD):
        bad.append('제목에 번호나 기호가 붙었습니다: %s' % ti[:20])
    if not bd:
        bad.append('제목만 있고 본문이 없습니다.')
        return bad

    # ① 줄머리 기호
    for i, l in enumerate(_lines(bd), 1):
        s = l.strip()
        if s and s[0] in BAD_HEAD:
            bad.append('%d번째 줄이 기호로 시작합니다(%s) — 1. 1) A. A) 만 '
                       '씁니다: %s' % (i, s[0], s[:24]))

    # ①-2 번호 뒤에는 **한 칸**이 있어야 한다 — 실측으로 잡았다
    #   (모델이 `1)바라는` 처럼 붙여 적었다). 붙여 적으면 번호가
    #   아니라 낱말의 일부처럼 읽힌다.
    for i, l in enumerate(_lines(bd), 1):
        s = l.strip()
        if NUM_HEAD_TIGHT.match(s) and not NUM_HEAD.match(s):
            bad.append('%d번째 줄의 번호 뒤에 빈칸이 없습니다 — '
                       '「1) 」처럼 한 칸 띄웁니다: %s' % (i, s[:24]))

    # ② 숨은 서식
    for rx, nm in HIDDEN:
        if rx.search(bd):
            bad.append('숨은 서식을 썼습니다 — %s' % nm)

    # ③ 분량
    n = len(re.sub(r'\s', '', bd))
    _min = MIN_KO if min_ko is None else int(min_ko)   # ★ 2026-10-13 — 묶음은 사용자 기준 300자(프롬프트와 같게)
    if strict_len and n < _min:
        bad.append('너무 짧습니다 — %d자 (적어도 %d자)' % (n, _min))
    elif n > SOFT_MAX:
        bad.append('(A4 한 장이 넘습니다 — %d자. 중요한 주제면 괜찮습니다)' % n)

    # ④ 원어 표기
    #   ⚠ **원어가 나온 자리마다** 음독이 붙었는가를 잰다. 글 전체에 하나만
    #     맞아도 통과시키면 나머지가 샌다.
    for i, l in enumerate(_lines(bd), 1):
        if not (HEB.search(l) or GRK.search(l)):
            continue
        rest = (OK_ORIG if str(lang or 'KO').upper() == 'KO' else OK_ORIG_ANY).sub('', l)
        if HEB.search(rest) or GRK.search(rest):
            bad.append('%d번째 줄의 원어에 음독이 없습니다 — 음독(원어) 꼴로 '
                       '적습니다: %s' % (i, l.strip()[:30]))

    # ⑤ 인용 구절 서식
    for i, l in enumerate(_lines(bd), 1):
        s = l.strip()
        if not s or CITE.match(s):
            continue
        # ★ 317차-18 ⑩ — 「약명 + 따옴표 본문」(인용 포맷 ②)은 받는다 — 역본은 설정이 정한다(cite_format)
        _m2 = re.match(r'^\S{1,12}\s*\d{1,3}:\d{1,3}(?:-\d{1,3}(?::\d{1,3})?)?\s+(\S)', s)
        if _m2 and _m2.group(1) in '“"「«„\'':
            continue
        if CITE_NOVER.match(s) and not NUM_HEAD.match(s):
            bad.append('%d번째 줄이 인용인데 역본이 없습니다 — '
                       '「KRV 창 1:3 본문」 꼴로 적습니다: %s' % (i, s[:30]))

    # ⑥ 장만 가리킨 참조 — **알림**(314차 사용자 지시)
    #   ⚠ 막지 않는다. 「레위기 21장의 규정」은 바른 문장이고, 다만 **연결이
    #     그 장 1절로만 걸린다**는 사실을 사람이 알아야 한다.
    bad += chapter_only_notes(bd, conn, lang)
    return bad


def chapter_only_refs(text, conn, lang='KO', limit=200):
    """본문에서 **장만 가리킨 참조**를 찾는다 → 맞힌 글자 목록.

    ★ 읽는 문은 `scripture_ref` **하나**다 — 여기서 정규식을 또 쓰지 않는다
      (두 벌이 되면 「게이트는 잡는데 연결은 안 걸린다」가 난다 §219차 ⑤).
    """
    if not text or conn is None:
        return []
    try:
        import scripture_ref as SR
        return [m for _s, _e, m, k in SR.find(conn, text, lang, limit=limit)
                if k == SR.KIND_CHAPTER]
    except Exception:                                     # noqa: BLE001
        return []


def chapter_only_notes(text, conn, lang='KO'):
    """장만 가리킨 참조 알림 — `check` 가 쓴다. 없으면 빈 목록."""
    got = chapter_only_refs(text, conn, lang)
    if not got:
        return []
    uniq = []
    for g in got:
        if g not in uniq:
            uniq.append(g)
    return ['(장만 가리킨 참조가 %d곳 있습니다 — 구절까지 적으면 그 절에 '
            '연결됩니다. 지금은 그 장 1절에만 걸립니다: %s)'
            % (len(uniq), ' · '.join(uniq[:5]))]


# ══════════════════════════════════════════════════════════════════════
#  자가 검증 (의무 · 양방향 — 깨끗한 글은 0, 심은 흠은 잡는다)
# ══════════════════════════════════════════════════════════════════════

_TITLE = '첫날의 빛, 해가 아직 없는데 빛이 있었다'

_SAMPLE = _TITLE + chr(10) + chr(10) + chr(10).join([
    '1. 본문이 말하는 것',
    '창세기 1장 3절에서 하나님이 빛이 있으라 하시니 빛이 있었습니다. '
    '그런데 해와 달은 넷째 날에 지어집니다. 빛이 광원보다 먼저 있는 셈입니다. '
    '읽는 사람이 여기서 한 번 멈추게 되는 자리입니다.',
    'KRV 창 1:3 하나님이 가라사대 빛이 있으라 하시매 빛이 있었고',
    '2. 원어가 보여 주는 것',
    '여기 쓰인 말은 오르(אור) 입니다. 이 낱말은 해의 빛만이 아니라 '
    '생명과 질서가 서는 자리를 함께 가리킵니다. 그래서 넷째 날의 광원은 '
    '그 빛을 담는 그릇으로 나중에 놓입니다. 순서가 뒤집힌 것이 아니라 '
    '근원과 그릇을 나누어 보여 주는 것입니다.',
    '1) 첫째 날의 빛은 근원이고',
    '2) 넷째 날의 광원은 그 빛을 나르는 자리입니다.',
    '3. 이어지는 자리',
    '요한복음이 같은 말을 이어받아 생명이 사람들의 빛이라 말합니다. '
    '창세기의 첫 빛이 사람을 살리는 빛으로 이어지는 것입니다. 그래서 '
    '성경의 마지막에서는 해도 달도 쓸 데가 없다고 말합니다. 처음에 있던 '
    '빛이 마지막에 다시 서는 셈입니다. 첫 장과 마지막 장이 같은 말을 '
    '주고받는 자리라, 그 사이에 놓인 이야기 전체가 이 빛을 향해 간다고 '
    '읽을 수 있습니다.',
    'KRV 계 21:23 그 성은 해나 달의 비췸이 쓸데 없으니',
])


def selftest():
    bad = []
    n = [0]

    def ck(c, m, extra=''):
        n[0] += 1
        if not c:
            bad.append('%s %s' % (m, extra))

    ck(not check(_SAMPLE), '깨끗한 글에서 흠이 났다', check(_SAMPLE))
    ck(title_of(_SAMPLE).startswith('첫날의 빛'), '제목을 못 읽는다')
    cs = cites(_SAMPLE)
    ck(len(cs) == 2, '인용을 못 뽑는다', cs)
    ck(cs and cs[0][0] == 'KRV' and cs[0][2] == '1:3', '인용을 잘못 뽑는다', cs)

    # ── 양방향 — 흠을 심으면 잡는가 ────────────────────────────────
    def has(t, word, msg, **kw):
        r = check(t, **kw)
        ck(any(word in x for x in r), msg, r[:2])

    has(_SAMPLE.replace('1. 본문이', '• 본문이'), '기호로 시작',
        '줄머리 기호를 안 잡는다')
    has(_SAMPLE.replace('오르(אור)', '**오르**(אור)'), '굵게',
        '굵게 표시를 안 잡는다')
    has(_SAMPLE.replace('1. 본문이', '## 본문이'), '머리글',
        '머리글 표시를 안 잡는다')
    has(_SAMPLE.replace('오르(אור)', 'אור'), '음독이 없습니다',
        '음독 없는 원어를 안 잡는다')
    has(_SAMPLE.replace('KRV 창 1:3 ', '창 1:3 '), '역본이 없습니다',
        '역본 없는 인용을 안 잡는다')
    # ★ 295차 — 음독 글자는 언어를 따른다(양방향)
    _en = _SAMPLE.replace('오르(אור)', 'or (אור)')
    ck(not any('음독' in x for x in check(_en, lang='EN')), '영어 음독을 한국어 잣대로 잡는다',
       [x for x in check(_en, lang='EN') if '음독' in x][:1])
    ck(any('음독' in x for x in check(_en, lang='KO')), '한국어 글의 로마자 음독을 놓친다')
    ck(any('음독' in x for x in check(_SAMPLE.replace('오르(אור)', 'אור'), lang='EN')),
       '영어 글의 음독 없는 원어를 놓친다')
    has('제목만', '본문이 없습니다', '제목만 있는 글을 안 잡는다')
    has(_TITLE + chr(10) + '짧다.', '너무 짧습니다', '짧은 글을 안 잡는다')
    has('1. 번호 제목' + chr(10) + _SAMPLE.split(chr(10), 1)[1],
        '제목에 번호', '번호 붙은 제목을 안 잡는다')
    has(_SAMPLE.replace('1) 첫째 날', '| 첫째 날 |'), '표', '표를 안 잡는다')
    has(_SAMPLE.replace('1) 첫째 날', '1)첫째 날'), '빈칸이 없습니다',
        '번호 뒤에 칸이 없는 것을 안 잡는다')

    # ⚠ **분량 초과는 막지 않는다** — 사용자 지시
    long_t = _TITLE + chr(10) + '1. 긴 글' + chr(10) + ('가' * 2500) + '.'
    r = check(long_t)
    ck(r and all(x.startswith('(') for x in r),
       '분량 초과를 흠으로 잡는다 — 알림이라야 한다', r)

    # ⚠ **번호 줄은 인용으로 오해하지 않는다**
    ck(not check(_TITLE + chr(10) + '1. 창 1:1 을 보면 그렇습니다. '
                 + ('그렇습니다. ' * 120)),
       '번호 줄을 인용 흠으로 잡는다')

    # ── ⑥ 장만 가리킨 참조 — 양방향 (314차) ───────────────────────
    #   ⚠ 이 모듈은 평소 DB 에 기대지 않는다 — selftest 에서만 열고 닫는다.
    _conn = None
    try:
        import appdb
        _conn = appdb.connect()
    except Exception:                                     # noqa: BLE001
        bad.append('(DB 를 못 열어 ⑥ 항목을 건너뛰었다 — 조용히 통과한 것이 '
                   '아니다)')
    if _conn is not None:
        try:
            # ① 깨끗한 글 — 알림 0  (「창세기 1장 3절」은 절까지 있어 안 걸린다)
            r = check(_SAMPLE, conn=_conn)
            ck(not r, 'conn 과 함께 깨끗한 글에서 흠·알림이 났다', r[:2])
            # ② 장만 참조를 심으면 잡는다
            t2 = _SAMPLE.replace('이어지는 자리', '이어지는 자리(레위기 21장 참고)')
            r2 = check(t2, conn=_conn)
            ck(any('장만 가리킨' in x for x in r2),
               '장만 가리킨 참조를 안 잡는다', r2[:2])
            ck(any(x.startswith('(') for x in r2 if '장만 가리킨' in x),
               '장만 참조를 흠으로 냈다 — 알림이라 ( 로 시작해야 한다', r2[:2])
            # ③ 절까지 있으면 안 잡는다 (헛걸림)
            t3 = _SAMPLE.replace('이어지는 자리', '이어지는 자리(레위기 21장 1절)')
            r3 = check(t3, conn=_conn)
            ck(not any('장만 가리킨' in x for x in r3),
               '절까지 적은 참조를 장만으로 잡는다', r3[:2])
            # ④ conn 이 없으면 그 항목만 건너뛴다
            ck(not any('장만 가리킨' in x for x in check(t2)),
               'conn 없이도 ⑥ 이 돈다 — 책 이름표가 없으면 못 재야 한다')
            # ⑤ 읽는 문이 단일 소스인가
            ck(chapter_only_refs('레위기 21장', _conn, 'KO'),
               'chapter_only_refs 가 장만 참조를 못 낸다')
            ck(not chapter_only_refs('레위기 21장 1절', _conn, 'KO'),
               'chapter_only_refs 가 절 참조를 장만으로 낸다')
            ck(chapter_only_refs('', _conn, 'KO') == []
               and chapter_only_refs('레위기 21장', None, 'KO') == [],
               '빈 글·conn 없음에 빈 목록을 안 낸다')
        finally:
            _conn.close()

    print('[db_study_gate] %d개 검사 · 흠 %d건' % (n[0], len(bad)))
    for b in bad:
        print('  -', b)
    return not bad


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--check' in sys.argv:
        import io as _io
        p = sys.argv[sys.argv.index('--check') + 1]
        t = _io.open(p, encoding='utf-8').read()
        r = check(t)
        print('제목:', title_of(t))
        print('인용:', cites(t))
        print('흠 %d건' % len(r))
        for x in r:
            print('  -', x)
        sys.exit(0 if not r else 1)
    print(__doc__)
