# -*- coding: utf-8 -*-
"""도서 유닛 제목 — **번역 덮개를 먼저 본다** (영구 · 2026-08-23 신설)

  원제는 `sys_book_unit.unit_label`(영어)이고, 그 언어 제목은
  `sys_text_asset(text_type='BOOK_UNIT_LABEL')` 에 덮개로 얹혀 있다.
  ⇒ 사용자에게 보이는 제목은 **언제나** `COALESCE(덮개, 원제)` 다.

  ⚠ 이 규칙을 화면마다 손으로 쓰다가 여섯 곳 중 **다섯 곳이 빠졌다**
    (2026-08-23 사용자 「마이어 묵상플랜은 제목이 자동으로 바뀌는 것 같지
    않다」). 도서 화면만 COALESCE 를 쓰고 플랜·나의묵상·연결창은 원제를
    직접 읽고 있었다. **새 화면에서 도서 유닛 제목을 보일 때는 여기를 쓴다.**

  두 가지로 쓴다
      unit_title(conn, unit_id, lang)  — 한 유닛 (대부분의 화면)
      SQL_JOIN / SQL_PICK              — 목록 질의에 끼워 넣는 조각

  사용법
      python book_label.py --selftest      (의무)
"""
import io
import sys

try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass

TEXT_TYPE = 'BOOK_UNIT_LABEL'

# 목록 질의에 끼워 넣는 조각 — 유닛 별칭이 `bu` 일 때. 물음표 하나(언어)를 먹는다.
SQL_JOIN = (
    " LEFT JOIN sys_text_asset ta_bul "
    "        ON ta_bul.text_type = 'BOOK_UNIT_LABEL' "
    "       AND ta_bul.clicked_id = bu.unit_id "
    "       AND UPPER(ta_bul.lang_code) = UPPER(?) "
    "       AND ta_bul.record_status = 'LIVE' ")
SQL_PICK = "COALESCE(ta_bul.contents, bu.unit_label)"


def unit_title(conn, unit_id, lang, default=''):
    """그 언어의 유닛 제목. 덮개가 없으면 원제, 유닛이 없으면 `default`."""
    if not unit_id:
        return default
    try:
        r = conn.execute(
            "SELECT COALESCE(ta.contents, bu.unit_label) "
            "  FROM sys_book_unit bu "
            "  LEFT JOIN sys_text_asset ta "
            "         ON ta.text_type = ? "
            "        AND ta.clicked_id = bu.unit_id "
            "        AND UPPER(ta.lang_code) = UPPER(?) "
            "        AND ta.record_status = 'LIVE' "
            " WHERE bu.unit_id = ?",
            (TEXT_TYPE, (lang or 'KO'), unit_id)).fetchone()
    except Exception:
        return default
    return (r[0] if r and r[0] else default)


# ── 책 제목 (2026-08-24 신설) ────────────────────────────────────────────────
#
# ★ 유닛 제목과 **같은 규칙**이다 — 그 언어 덮개(`sys_book_asset_text`)를 먼저
#   보고 없으면 `sys_book_asset.title`.
# ★★ **짧은 이름이 곧 그 언어 제목이다** (2026-08-24 사용자 「책 제목 짧은 것만
#   표시하라. 클릭하면 풍선처럼 전체이름을 표시하자」). 실측 —
#   영어 제목 중앙값 21자·최대 49자(`Metropolitan Tabernacle Pulpit — Selected
#   Sermons`) ↔ **한국어 제목 중앙값 9자·최대 18자**(`스펄전 설교 선집`).
#   ⇒ 따로 「짧은 이름」 칸을 만들 필요가 없다. 번역 제목이 이미 짧다.
# ⚠ 그래도 상한을 둔다 — 새 책이 긴 제목으로 들어올 수 있다. 자른 것은
#   `…` 로 알리고 **전문은 부르는 쪽이 풍선으로** 보인다(§0 no silent caps).

SHORT_MAX = 16          # 목록 한 줄에 넣을 때의 상한

BOOK_SQL_JOIN = (
    " LEFT JOIN sys_book_asset_text ta_bat "
    "        ON ta_bat.book_id = ba.book_id "
    "       AND UPPER(ta_bat.lang_code) = UPPER(?) "
    "       AND COALESCE(ta_bat.record_status,'LIVE') = 'LIVE' ")
BOOK_SQL_PICK = "COALESCE(NULLIF(ta_bat.title,''), ba.title)"


def book_title(conn, book_id, lang, default=''):
    """그 언어의 **책 제목 전문**. 덮개가 없으면 원제."""
    if not book_id:
        return default
    try:
        r = conn.execute(
            "SELECT COALESCE(NULLIF(t.title,''), a.title) "
            "  FROM sys_book_asset a "
            "  LEFT JOIN sys_book_asset_text t "
            "         ON t.book_id = a.book_id "
            "        AND UPPER(t.lang_code) = UPPER(?) "
            "        AND COALESCE(t.record_status,'LIVE') = 'LIVE' "
            " WHERE a.book_id = ?", ((lang or 'KO'), book_id)).fetchone()
    except Exception:
        return default
    return (r[0] if r and r[0] else default)


def shorten(s, limit=SHORT_MAX):
    """목록용으로 자른다. 자르면 `…` 를 붙여 **잘렸음을 알린다.**"""
    s = (s or '').strip()
    return s if len(s) <= limit else (s[:limit - 1].rstrip() + '…')


def book_title_short(conn, book_id, lang, default='', limit=SHORT_MAX):
    """`(짧은 이름, 전문)` — 짧은 쪽을 보이고 전문은 풍선에 쓴다."""
    full = book_title(conn, book_id, lang, default)
    return shorten(full, limit), full


def selftest():
    import appdb
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    conn = appdb.connect('bible_master.db')
    try:
        # 마이어 1번 편 — KO·EN 덮개가 둘 다 있는 자리
        uid = conn.execute(
            "SELECT unit_id FROM sys_book_unit WHERE book_id=7 AND sequence=1 "
            "AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()
        t('마이어 1편 있음', uid is not None)
        if uid:
            uid = uid[0]
            orig = conn.execute(
                "SELECT unit_label FROM sys_book_unit WHERE unit_id=?",
                (uid,)).fetchone()[0]
            ko = unit_title(conn, uid, 'KO')
            en = unit_title(conn, uid, 'EN')
            t('KO 덮개가 원제와 다르다', ko and ko != orig)
            t('KO 에 한글이 있다', any('가' <= ch <= '힣' for ch in ko))
            t('EN 덮개가 있다', bool(en))
            t('소문자 lang 도 받는다', unit_title(conn, uid, 'ko') == ko)
            t('덮개 없는 언어는 원제', unit_title(conn, uid, 'JA') == orig)

        # 덮개가 아예 없는 책 — 원제가 그대로 나와야 한다
        u2 = conn.execute(
            "SELECT bu.unit_id, bu.unit_label FROM sys_book_unit bu "
            " WHERE bu.book_id != 7 AND COALESCE(bu.record_status,'LIVE')='LIVE' "
            "   AND NOT EXISTS (SELECT 1 FROM sys_text_asset ta "
            "        WHERE ta.text_type='BOOK_UNIT_LABEL' AND ta.clicked_id=bu.unit_id) "
            " LIMIT 1").fetchone()
        t('덮개 없는 유닛을 찾음', u2 is not None)
        if u2:
            t('덮개 없으면 원제', unit_title(conn, u2[0], 'KO') == u2[1])

        t('없는 유닛은 기본값', unit_title(conn, -1, 'KO', '(없음)') == '(없음)')
        t('None 도 견딘다', unit_title(conn, None, 'KO', 'x') == 'x')

        # 목록 조각이 실제로 도는지
        rows = conn.execute(
            "SELECT " + SQL_PICK + " FROM sys_book_unit bu " + SQL_JOIN +
            " WHERE bu.book_id=7 AND COALESCE(bu.record_status,'LIVE')='LIVE' "
            " ORDER BY bu.sequence LIMIT 3", ('KO',)).fetchall()
        t('조각 질의 3줄', len(rows) == 3)
        t('조각도 한글', all(any('가' <= ch <= '힣' for ch in r[0])
                          for r in rows))

        # ── 책 제목 ──────────────────────────────────────────────────────
        # ⚠ 특정 책 코드를 박지 않는다 — 데이터 상태에 검사를 걸지 않기 위해
        #   **덮개가 있는 책을 그때그때 찾아** 쓴다(§0-5).
        bid = conn.execute(
            "SELECT t.book_id FROM sys_book_asset_text t JOIN sys_book_asset a "
            "    ON a.book_id = t.book_id "
            " WHERE UPPER(t.lang_code)='KO' AND COALESCE(t.title,'')<>'' "
            "   AND t.title <> a.title LIMIT 1").fetchone()
        t('KO 덮개가 있는 책을 찾음', bid is not None)
        if bid:
            bid = bid[0]
            orig = conn.execute("SELECT title FROM sys_book_asset WHERE book_id=?",
                                (bid,)).fetchone()[0]
            ko = book_title(conn, bid, 'KO')
            t('책: KO 덮개가 원제와 다르다', ko and ko != orig)
            t('책: 소문자 lang', book_title(conn, bid, 'ko') == ko)
            t('책: 덮개 없는 언어는 원제', book_title(conn, bid, 'XX') == orig)
        t('책: 없는 id 는 기본값', book_title(conn, -1, 'KO', '(없음)') == '(없음)')
        t('책: None 도 견딘다', book_title(conn, None, 'KO', 'x') == 'x')

        # 자르기 — **짧으면 안 건드리고, 길면 알린다**
        t('짧은 것은 그대로', shorten('천로역정') == '천로역정')
        long = 'Metropolitan Tabernacle Pulpit — Selected Sermons'
        t('긴 것은 잘린다', len(shorten(long)) <= SHORT_MAX)
        t('자르면 … 로 알린다', shorten(long).endswith('…'))
        t('빈 값도 견딘다', shorten(None) == '' and shorten('') == '')
        s, full = book_title_short(conn, -1, 'KO', long)
        t('짧은/전문 두 값', full == long and s != full and s.endswith('…'))

        # 목록 조각 — 별칭 `ba` 로 실제로 도는가
        br = conn.execute(
            "SELECT " + BOOK_SQL_PICK + " FROM sys_book_asset ba " +
            BOOK_SQL_JOIN + " WHERE ba.book_id=? ", ('KO', bid or 1)).fetchone()
        t('책 조각 질의', br is not None and bool(br[0]))
        if bid:
            t('책 조각도 덮개를 본다', br[0] == book_title(conn, bid, 'KO'))
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
