# -*- coding: utf-8 -*-
"""side_rail — P1·P4 메인 탭을 **왼쪽 세로 탭**으로도 보이게 하는 부품 (2026-10-07 · 317차-26).

사용자 지시 — 「P1 / P4 화면을 각각 선택하여 상단 탭 구조, 좌측 탭구조 중에서 선택 ·
설정탭에 화면배치 탭 · 좌측 배치방식에서 서브탭은 **메인탭 아래에 펼쳐지는 방식**」.

★★★ 노트북을 **다시 짓지 않는다** — 탭 줄만 감추고(그 노트북 스타일의 Tab 레이아웃을
  비운다) 왼쪽 막대가 `nb.select` 를 부른다. 그래서 `select`·`index`·`<<NotebookTabChanged>>`·
  지연 빌드·`self.P4` 번호 표가 **한 줄도 안 바뀐다**(도서/설교집 갈래 단추가 이미 쓰는 방식 —
  `p1_reading_view._build_left` 의 `NoTabs.TNotebook`).
★ 서브탭 = **고른 메인 탭 바로 아래**에 들여쓰기로 펼친다(아코디언 — 고른 탭 하나만).
  어느 노트북이 그 탭의 서브탭인지는 화면이 `subs` 로 알려 준다(지연 빌드라 늦게 생긴다 —
  막대가 다시 물어본다). ⚠ **탭 줄에 단추·콤보를 얹은 노트북은 넘기지 않는다**(주요용어 —
  줄을 감추면 그 단추가 함께 사라진다).
★ 이름·배지·감춘 탭(쇼핑몰)은 **노트북에서 읽는다**(`nb.tab(t,'text')` · `state`) — 막대가
  따로 이름을 들면 배지 수가 갈린다. 바꾸는 자리가 수십 곳이라 이벤트 대신 **0.3초마다 견준다**
  (바뀐 것이 있을 때만 다시 그린다 · 왼쪽 모드일 때만 돈다).
⚠ `ui_theme.tab_strip` 이 노트북 스타일을 **스스로 되돌린다**(`P1Focus.TNotebook`) — 그래서
  스타일을 갈아 끼우지 않고 **그 스타일의 Tab 레이아웃**을 비운다. Focus 칸(탭 줄 맨 왼쪽)은
  감추고 같은 쌍을 막대 맨 위에 둔다.
"""
import tkinter as tk
from tkinter import ttk

AREAS = ('P1', 'P4')
MODES = ('TOP', 'LEFT')
KEY = 'TAB_LAYOUT_%s'
WKEY = 'TAB_RAIL_W'             # 사용자가 끌어 정한 폭(px) — **P1·P4 함께 하나**(317차-28)
SUB_STYLE = 'RailSub.TNotebook'
_RAILS = {}


# ── 설정 — user_config 한 열쇠 · 바꾸면 그 자리에서 막대에 알린다 ─────────────────
def get_mode(db_path, area):
    try:
        import appdb
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (KEY % area,)).fetchone()
        v = (r[0] if r and r[0] else 'TOP').upper()
        return v if v in MODES else 'TOP'
    except Exception:
        return 'TOP'


def set_mode(db_path, area, mode):
    mode = (mode or 'TOP').upper()
    if mode not in MODES or area not in AREAS:
        return False
    try:
        import appdb
        with appdb.connect(db_path) as c:
            k = KEY % area
            if c.execute("SELECT 1 FROM user_config WHERE config_key=?", (k,)).fetchone():
                c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (mode, k))
            else:
                c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (k, mode))
            c.commit()
    except Exception as e:
        print('[side_rail set_mode] %s' % e)
        return False
    r = _RAILS.get(area)
    if r is not None:
        try:
            r.apply(mode)
        except Exception as e:
            print('[side_rail apply] %s' % e)
    return True


def get_width(db_path, area=None):
    """사용자가 끌어 정한 막대 폭(없으면 0 = 글자에 맞춘다). P1·P4 가 **같은 값**을 쓴다
    (사용자 「좌측 메뉴 화면의 좌우 길이를 상하 일치시키는 것이 중요하다」)."""
    try:
        import appdb
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (WKEY,)).fetchone()
        return int(r[0]) if r and r[0] else 0
    except Exception:
        return 0


def set_width(db_path, area, w):
    try:
        import appdb
        with appdb.connect(db_path) as c:
            k = WKEY
            if c.execute("SELECT 1 FROM user_config WHERE config_key=?", (k,)).fetchone():
                c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (str(int(w)), k))
            else:
                c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)",
                          (k, str(int(w))))
            c.commit()
    except Exception as e:
        print('[side_rail set_width] %s' % e)


def rail(area):
    return _RAILS.get(area)


def shared_width(db_path=None):
    """P1·P4 막대가 함께 쓰는 **바깥 폭**(손잡이·세로 막대 자리까지 포함).

    끌어 정한 폭이 있으면 그것, 없으면 두 막대가 필요한 폭 중 큰 것 — 그래야 어느 쪽도
    글자가 가려지지 않고 둘의 폭이 같다."""
    rails = [r for a, r in _RAILS.items() if a in AREAS] or list(_RAILS.values())
    if not rails:
        return SideRail.MIN_W
    db = db_path or rails[0].db_path
    w = get_width(db)
    if w:
        return max(SideRail.DRAG_MIN, min(SideRail.DRAG_MAX, w))
    need = max(r.measure() for r in rails)
    return max(SideRail.MIN_W, min(SideRail.MAX_W, need))


def _sync_all(except_rail=None):
    """폭이 바뀌었으면 다른 막대도 그 폭으로 다시 그린다(다음 차례에 — 되부르기 고리를 피한다)."""
    for r in list(_RAILS.values()):
        if r is except_rail or r.mode != 'LEFT':
            continue
        try:
            r.after_idle(lambda rr=r: rr.refresh(force=True))
        except Exception:
            pass


def _empty(layout):
    """비운 레이아웃은 `[]` 가 아니라 `[('null', …)]` 로 읽힌다(실측)."""
    try:
        return (not layout) or all(str(x[0]) == 'null' for x in layout)
    except Exception:
        return False


def _C(role, fb):
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb


class SideRail(tk.Frame):
    MIN_W = 110
    MAX_W = 220                  # 저절로 정할 때의 위 한도 — 끌면 넘을 수 있다
    SB_W = 18                    # 세로 막대 자리 — **늘 비워 둔다**(나타나도 줄바꿈·폭이 안 흔들린다)
    DRAG_MIN, DRAG_MAX = 70, 420
    GRIP = 5
    POLL_MS = 300

    def __init__(self, host, nb, db_path, area, tab_style, strip=None, subs=None,
                 focus_builder=None):
        super().__init__(host, bd=0, highlightthickness=0, bg=_C('panel', '#F4F6F7'))
        self.nb = nb
        self.db_path = db_path
        self.area = area
        self.tab_style = tab_style
        self.strip = strip
        self.subs = dict(subs or {})
        self.mode = 'TOP'
        self._sig = None
        self._rw = self.MIN_W
        self._job = None
        self._orig_layout = None
        self._sub_orig = {}          # str(sub nb) -> 원래 스타일
        self._need = self.MIN_W      # 이 막대가 글자를 다 보이려면 필요한 바깥 폭(늘기만 한다)
        # ★ 바깥 폭을 **못 박는다** — 세로 막대가 한쪽에만 생겨도 P1·P4 폭이 같게(317차-28)
        self.pack_propagate(False)
        self.configure(width=self._rw)

        # 오른쪽 가장자리 = 끌어서 폭을 바꾸는 손잡이(선 한 줄 + 잡기 쉬운 폭)
        self.grip = tk.Frame(self, width=self.GRIP, bg=_C('panel', '#F4F6F7'),
                             cursor='sb_h_double_arrow')
        self.grip.pack(side='right', fill='y')
        tk.Frame(self.grip, width=1, bg=_C('border', '#D5D8DC')).pack(side='right', fill='y')
        self.grip.bind('<ButtonPress-1>', self._drag_start)
        self.grip.bind('<B1-Motion>', self._drag_move)
        self.grip.bind('<ButtonRelease-1>', self._drag_end)
        self.grip.bind('<Double-Button-1>', self._drag_reset)
        self.top = tk.Frame(self, bg=_C('panel', '#F4F6F7'))
        self.top.pack(side='top', fill='x', pady=(2, 2))
        if callable(focus_builder):
            try:
                focus_builder(self.top)
            except Exception as e:
                print('[side_rail focus] %s' % e)
        self.cv = tk.Canvas(self, bd=0, highlightthickness=0, width=10,
                            bg=_C('panel', '#F4F6F7'))
        self.cv.pack(side='top', fill='both', expand=True)
        # 넘칠 때만 보이는 세로 막대 — P1 은 낮아서(실측 449px) 탭·서브탭이 다 안 든다.
        #   안 보이면 「아래에 더 있다」를 알 길이 없다(§0-1).
        self.sb = ttk.Scrollbar(self, orient='vertical', command=self.cv.yview)
        self.cv.configure(yscrollcommand=self._sb_set)
        self.inner = tk.Frame(self.cv, bg=_C('panel', '#F4F6F7'))
        self._win = self.cv.create_window(0, 0, window=self.inner, anchor='nw')
        self.inner.bind('<Configure>', lambda e: self.cv.configure(
            scrollregion=self.cv.bbox('all')))
        self.cv.bind('<Configure>', lambda e: self.cv.itemconfigure(self._win, width=e.width))
        for w in (self.cv, self.inner):
            w.bind('<MouseWheel>', self._wheel)
        _RAILS[area] = self

    # ── 폭 끌기 ─────────────────────────────────────────────────────────────
    # ★ 끌기는 **두 막대를 함께** 넓힌다(317차-28 — 폭이 하나다). 글꼴을 키웠을 때 쓰라고 둔다.
    def _drag_start(self, e):
        self._drag0 = (e.x_root, int(self.cget('width') or self._rw))

    def _drag_move(self, e):
        d = getattr(self, '_drag0', None)
        if not d:
            return
        w = max(self.DRAG_MIN, min(self.DRAG_MAX, d[1] + (e.x_root - d[0])))
        for r in list(_RAILS.values()):           # 끄는 동안은 바깥 폭만 — 다시 그리기는 놓을 때
            try:
                if int(r.cget('width') or 0) != w:
                    r.configure(width=w)
            except Exception:
                pass

    def _drag_end(self, e=None):
        if not getattr(self, '_drag0', None):
            return
        self._drag0 = None
        set_width(self.db_path, self.area, int(self.cget('width') or self._rw))
        self.refresh(force=True)
        _sync_all(self)

    def _drag_reset(self, e=None):
        """손잡이를 두 번 누르면 글자에 맞춘 폭으로 돌아간다(두 막대 함께)."""
        set_width(self.db_path, self.area, 0)
        self.refresh(force=True)
        _sync_all(self)

    def measure(self):
        """이 막대가 글자를 가리지 않으려면 필요한 **바깥 폭** — 늘기만 한다(펼쳐 본 서브탭까지 기억)."""
        try:
            import tkinter.font as tkfont
            fb = tkfont.Font(font=self._font(True))
            need = max([fb.measure(x[3]) + (50 if x[0] == 'S' else 38)
                        for x in self.items()] or [0])
            need += self.GRIP + self.SB_W
            self._need = max(self._need, need)
        except Exception:
            pass
        return self._need

    # ── 모양 ───────────────────────────────────────────────────────────────
    def _font(self, bold=False):
        """탭 이름과 **같은 글꼴** — 위쪽 탭이 쓰는 글꼴을 그대로 읽는다(스타일 → 이름 글꼴).
        모드를 바꿔도 글자 크기가 안 바뀌어야 한다. 글꼴 설정을 바꾸면 그 값이 따라온다."""
        w = 'bold' if bold else 'normal'
        try:
            import tkinter.font as tkfont
            f = ttk.Style().lookup('TNotebook.Tab', 'font') or 'TkDefaultFont'
            a = tkfont.Font(font=f).actual()
            return (a.get('family') or '', int(abs(a.get('size') or 10)), w)
        except Exception:
            return ('', 10, w)

    def _sb_set(self, lo, hi):
        try:
            need = float(lo) > 0.0 or float(hi) < 1.0
            if need and not self.sb.winfo_manager():
                self.sb.pack(side='right', fill='y', before=self.cv)
            elif not need and self.sb.winfo_manager():
                self.sb.pack_forget()
            self.sb.set(lo, hi)
        except Exception:
            pass

    def _see_selected(self):
        """선택한 메인 탭(과 그 서브탭)이 보이게 굴린다."""
        try:
            self.update_idletasks()
            rows = self.inner.winfo_children()
            tot = max(1, self.inner.winfo_height())
            vis = self.cv.winfo_height()
            if tot <= vis:
                return
            on = [w for w in rows if getattr(w, '_rail_on', False)]
            if not on:
                return
            top = on[0].winfo_y()
            bot = on[-1].winfo_y() + on[-1].winfo_height()
            lo, hi = self.cv.yview()
            if top < lo * tot or bot > hi * tot:
                self.cv.yview_moveto(max(0.0, (top - 4) / tot))
        except Exception:
            pass

    def _wheel(self, e):
        try:
            if self.inner.winfo_reqheight() > self.cv.winfo_height():
                self.cv.yview_scroll(-1 if e.delta > 0 else 1, 'units')
        except Exception:
            pass
        return 'break'

    # ── 무엇을 그리나 ───────────────────────────────────────────────────────
    def _sub_of(self, tab):
        g = self.subs.get(str(tab))
        if not callable(g):
            return None
        try:
            s = g()
        except Exception:
            return None
        if s is None:
            return None
        try:
            if not s.winfo_exists():
                return None
        except Exception:
            return None
        if self.mode == 'LEFT':
            self._hide_sub(s)
        return s

    def items(self):
        """(갈래, 메인 탭, 서브 탭, 이름, 상태, 골랐나) — 그리는 차례 그대로."""
        out = []
        try:
            sel = self.nb.select()
            tabs = self.nb.tabs()
        except Exception:
            return out
        for t in tabs:
            try:
                st = str(self.nb.tab(t, 'state'))
                if st == 'hidden':
                    continue
                out.append(('M', str(t), None, str(self.nb.tab(t, 'text')).strip(), st,
                            str(t) == str(sel)))
            except Exception:
                continue
            if str(t) == str(sel):
                sub = self._sub_of(t)
                if sub is None:
                    continue
                try:
                    ssel = sub.select()
                    for s in sub.tabs():
                        sst = str(sub.tab(s, 'state'))
                        if sst == 'hidden':
                            continue
                        out.append(('S', str(t), str(s), str(sub.tab(s, 'text')).strip(),
                                    sst, str(s) == str(ssel)))
                except Exception:
                    pass
        return out

    # ── 그리기 ─────────────────────────────────────────────────────────────
    def refresh(self, force=False):
        its = self.items()
        sig = (tuple(its), self._font())
        if not force and sig == self._sig:
            return
        self._sig = sig
        for w in self.inner.winfo_children():
            w.destroy()
        self.measure()
        w = shared_width(self.db_path)
        changed = (w != self._rw)
        self._rw = w
        if int(self.cget('width') or 0) != w:
            self.configure(width=w)
        if changed:
            _sync_all(self)                 # 다른 막대도 같은 폭으로
        inner_w = self._rw - self.GRIP - self.SB_W
        panel = _C('panel', '#F4F6F7')
        for kind, t, s, txt, st, on in its:
            sub = (kind == 'S')
            if on and not sub:
                bg, fg = _C('accent_bg', '#EBF5FB'), _C('accent', '#2471A3')
            elif on:
                bg, fg = _C('panel_alt', '#E8E8E8'), _C('accent', '#2471A3')
            else:
                bg, fg = panel, (_C('fg_dim', '#7F8C8D') if (sub or st == 'disabled')
                                 else _C('fg', '#2C3E50'))
            lb = tk.Label(self.inner, text=txt, anchor='w', justify='left',
                          bg=bg, fg=fg, font=self._font(on),
                          padx=(22 if sub else 10), pady=(1 if sub else 3),
                          wraplength=max(50, inner_w - (36 if sub else 24)),
                          cursor='hand2')
            lb.pack(side='top', fill='x')
            if on and not sub:
                tk.Frame(lb, width=3, bg=_C('accent', '#2471A3')).place(x=0, y=0, relheight=1.0)
            lb.bind('<Button-1>', lambda e, t=t, s=s: self._pick(t, s))
            lb.bind('<MouseWheel>', self._wheel)
            if not on:
                lb.bind('<Enter>', lambda e, w=lb: w.configure(bg=_C('panel_alt', '#E8E8E8')))
                lb.bind('<Leave>', lambda e, w=lb, b=bg: w.configure(bg=b))
            setattr(lb, '_rail_item', (kind, t, s))
            # 고른 메인 탭과 그 아래 서브탭 묶음 = 보이게 굴릴 자리
            setattr(lb, '_rail_on', (kind == 'M' and on) or (kind == 'S'))
        self.after_idle(self._see_selected)

    def _pick(self, tab, sub_tab=None):
        try:
            if str(self.nb.select()) != str(tab):
                self.nb.select(tab)
            if sub_tab:
                sub = self._sub_of(tab)
                if sub is not None:
                    # 화면이 제 문을 주면 그 문으로 고른다(도서/설교집 `_pick_sub` —
                    # 서재 닫기·위 띠 단추 맞추기가 함께 돈다). 없으면 노트북을 고른다.
                    door = getattr(sub, '_rail_pick', None)
                    if callable(door):
                        door(sub.index(sub_tab))
                    else:
                        sub.select(sub_tab)
        except Exception as e:
            print('[side_rail pick] %s' % e)
        self.refresh()
        # 지연 빌드 탭 — 서브 노트북이 조금 뒤에 생긴다
        self.after(250, self.refresh)

    # ── 켜고 끄기 ───────────────────────────────────────────────────────────
    def _hide_main_tabs(self, hide):
        st = ttk.Style()
        name = self.tab_style + '.Tab'
        if hide:
            try:
                cur = st.layout(name)
            except Exception:
                cur = None
            # 아직 제 Tab 레이아웃이 없는 스타일(물려받는 중)도 있다 — 그래도 비운다
            if cur and not _empty(cur) and self._orig_layout is None:
                self._orig_layout = cur
            if cur is None or not _empty(cur):
                try:
                    st.layout(name, [])
                except Exception:
                    pass
        else:
            try:
                st.layout(name, self._orig_layout or st.layout('TNotebook.Tab'))
            except Exception:
                pass

    def _hide_sub(self, sub):
        k = str(sub)
        if k in self._sub_orig:
            return
        st = ttk.Style()
        try:
            if not _empty(st.layout(SUB_STYLE + '.Tab')):
                st.layout(SUB_STYLE + '.Tab', [])
        except Exception:
            try:
                st.layout(SUB_STYLE + '.Tab', [])
            except Exception:
                pass
        try:
            self._sub_orig[k] = str(sub.cget('style') or '')
            sub.configure(style=SUB_STYLE)
        except Exception:
            pass
        own = getattr(sub, '_rail_own', None)     # 그 화면이 따로 둔 갈래 단추(도서/설교집)
        if callable(own):
            try:
                own(False)
            except Exception:
                pass

    def _show_subs(self):
        for k, orig in list(self._sub_orig.items()):
            try:
                w = self.nametowidget(k)
                w.configure(style=orig)
                own = getattr(w, '_rail_own', None)
                if callable(own):
                    own(True)
            except Exception:
                pass
        self._sub_orig.clear()

    def apply(self, mode):
        mode = (mode or 'TOP').upper()
        self.mode = mode
        if mode == 'LEFT':
            self._hide_main_tabs(True)
            if self.strip is not None:
                try:
                    self.strip.place_forget()
                except Exception:
                    pass
            try:
                self.pack(side='left', fill='y', before=self.nb)
            except Exception:
                self.pack(side='left', fill='y')
            self.refresh(force=True)
            self._poll()
        else:
            if self._job:
                try:
                    self.after_cancel(self._job)
                except Exception:
                    pass
                self._job = None
            self._hide_main_tabs(False)
            self._show_subs()
            self.pack_forget()
            if self.strip is not None:
                try:
                    self.strip.place(x=2, y=2)
                    if hasattr(self.strip, 'fit'):
                        self.strip.fit()
                except Exception:
                    pass

    def _poll(self):
        self._job = None
        if self.mode != 'LEFT':
            return
        try:
            if not self.winfo_exists():
                return
            # 테마가 갈리면 비운 레이아웃이 되살아날 수 있다 — 다시 비운다
            st = ttk.Style()
            try:
                if not _empty(st.layout(self.tab_style + '.Tab')):
                    st.layout(self.tab_style + '.Tab', [])
            except Exception:
                pass
            self.refresh()
        except Exception as e:
            print('[side_rail poll] %s' % e)
        self._job = self.after(self.POLL_MS, self._poll)


def _selftest():
    ok = bad = 0

    def ck(c, m):
        nonlocal ok, bad
        if c:
            ok += 1
        else:
            bad += 1
            print('FAIL', m)
    root = tk.Tk()
    root.withdraw()
    host = tk.Frame(root)
    host.pack(fill='both', expand=True)
    nb = ttk.Notebook(host, style='RailT.TNotebook')
    nb.pack(fill='both', expand=True)
    f1, f2, f3 = (ttk.Frame(nb) for _ in range(3))
    nb.add(f1, text=' 하나 ')
    nb.add(f2, text=' 둘 (3) ')
    nb.add(f3, text=' 셋 ')
    sub = ttk.Notebook(f2)
    sub.pack(fill='both', expand=True)
    s1, s2 = ttk.Frame(sub), ttk.Frame(sub)
    sub.add(s1, text='가')
    sub.add(s2, text='나')
    nb.hide(f3)
    r = SideRail(host, nb, ':memory:', 'TEST', 'RailT.TNotebook', subs={str(f2): lambda: sub})
    r.apply('LEFT')
    root.update()
    names = [x[3] for x in r.items()]
    ck(names == ['하나', '둘 (3)'], '감춘 탭은 빼고 이름·배지 그대로 %s' % names)
    r._pick(str(f2))
    names = [(x[0], x[3]) for x in r.items()]
    ck(('S', '가') in names and ('S', '나') in names, '선택한 탭 아래에 서브탭 %s' % names)
    ck(str(sub.cget('style')) == SUB_STYLE, '서브 노트북 탭 줄을 감춘다')
    r._pick(str(f2), str(s2))
    ck(str(sub.select()) == str(s2), '서브탭 선택하기')
    r._pick(str(f1))
    ck(not [x for x in r.items() if x[0] == 'S'], '다른 탭을 선택하면 서브탭이 접힌다')
    ck(_empty(ttk.Style().layout('RailT.TNotebook.Tab')), '왼쪽 모드 = 메인 탭 줄을 비운다')
    r.apply('TOP')
    ck(not _empty(ttk.Style().layout('RailT.TNotebook.Tab')), '위쪽 모드 = 탭 줄 되살림')
    ck(str(sub.cget('style')) != SUB_STYLE, '서브 노트북 스타일 되돌림')
    ck(not r.winfo_manager(), '위쪽 모드에서 막대는 안 보인다')
    root.destroy()
    print('side_rail selftest %d/%d' % (ok, ok + bad))
    return 1 if bad else 0


if __name__ == '__main__':
    import sys
    sys.exit(_selftest())
