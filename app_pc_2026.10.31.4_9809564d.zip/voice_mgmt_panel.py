"""
voice_mgmt_panel.py  —  녹음 관리 뷰
필터: 목소리(owner) → 버전 → 책 → 장  (계층적 캐스케이드)
결과: 책별 / 장별 / 절별 진척도
액션: 무결성 검사 / 내보내기 / 가져오기
"""
import re
import i18n
import shutil
import sqlite3
import appdb
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from voice_bible import VOICES_ROOT, save_voice_record, resolve

BG     = "#1C2833"
BG2    = "#212F3D"
BG_HDR = "#17202A"
FG     = "#ECF0F1"
FG_DIM = "#AEB6BF"
GREEN  = "#27AE60"
RED    = "#E74C3C"
BLUE   = "#1A5276"
ORANGE = "#F0B27A"

_FNAME_RE = re.compile(
    r'^(.+)_([A-Z0-9]+)_(\d{3})_(\d{3})_(\d{3})\.(mp3|wav|ogg)$', re.IGNORECASE
)


class VoiceMgmtPanel(tk.Frame):

    def __init__(self, parent, db_path, lang_getter, version_getter):
        super().__init__(parent, bg=BG)
        self.db_path        = db_path
        self.lang_getter    = lang_getter
        self.version_getter = version_getter

        self._book_list: list[tuple[int, str]] = []  # [(bcode, name), ...]

        self._build()

    # ── 공개 API ──────────────────────────────────────────────────────────────

    def activate(self, owner: str, version: str):
        """관리 뷰 표시 시 owner/version 동기화 후 초기 상태."""
        self._load_owners()
        if owner and owner in self._owner_cb["values"]:
            self._owner_var.set(owner)
        elif self._owner_cb["values"]:
            self._owner_var.set(self._owner_cb["values"][0])
        self._load_owner_versions()
        if version and version in self._ver_cb["values"]:
            self._ver_var.set(version)
        self._load_books()
        self._book_var.set(i18n.t('COMMON_ALL', '전체'))
        self._chap_var.set(i18n.t('COMMON_ALL', '전체'))
        self._chap_cb.config(state="disabled")

    # ── UI 구성 ───────────────────────────────────────────────────────────────

    def _build(self):
        hdr = tk.Frame(self, bg=BG_HDR, pady=4)
        hdr.pack(fill="x")
        tk.Label(hdr, text=i18n.t('VMP_TITLE','   녹음 관리'), bg=BG_HDR, fg=FG,
                 font=("Malgun Gothic", 10, "bold")).pack(side="left", padx=6)

        pane = tk.PanedWindow(self, orient="horizontal",
                              sashwidth=4, bg="#2C3E50", sashrelief="flat")
        pane.pack(fill="both", expand=True, padx=4, pady=4)

        self._build_left(pane)
        self._build_right(pane)

    def _build_left(self, pane):
        left = tk.Frame(pane, bg=BG2, padx=8, pady=6)
        pane.add(left, width=185)

        # 녹음 집합
        sf = tk.LabelFrame(left, text=i18n.t('VMP_RECSET',' 녹음 집합 '), bg=BG2, fg=FG_DIM,
                           font=("Malgun Gothic", 8))
        sf.pack(fill="x", pady=(0, 6))

        tk.Label(sf, text=i18n.t('VOICE_VOICE','목소리'), bg=BG2, fg=FG,
                 font=("Malgun Gothic", 9)).pack(anchor="w", padx=4, pady=(4, 0))
        self._owner_var = tk.StringVar()
        self._owner_cb  = ttk.Combobox(sf, textvariable=self._owner_var,
                                       width=17, state="readonly",
                                       font=("Malgun Gothic", 9))
        self._owner_cb.pack(fill="x", padx=4, pady=(0, 4))
        self._owner_cb.bind("<<ComboboxSelected>>",
                            lambda e: self._load_owner_versions())

        tk.Label(sf, text=i18n.t('VOICE_VERSION','버전'), bg=BG2, fg=FG,
                 font=("Malgun Gothic", 9)).pack(anchor="w", padx=4)
        self._ver_var = tk.StringVar()
        self._ver_cb  = ttk.Combobox(sf, textvariable=self._ver_var,
                                     width=17, state="readonly",
                                     font=("Malgun Gothic", 9))
        self._ver_cb.pack(fill="x", padx=4, pady=(0, 4))

        # 탐색 범위
        nf = tk.LabelFrame(left, text=i18n.t('VMP_SCOPE',' 탐색 범위 '), bg=BG2, fg=FG_DIM,
                           font=("Malgun Gothic", 8))
        nf.pack(fill="x", pady=(0, 8))

        tk.Label(nf, text=i18n.t('VOICE_BOOK','책'), bg=BG2, fg=FG,
                 font=("Malgun Gothic", 9)).pack(anchor="w", padx=4, pady=(4, 0))
        self._book_var = tk.StringVar(value=i18n.t('COMMON_ALL', '전체'))
        self._book_cb  = ttk.Combobox(nf, textvariable=self._book_var,
                                      width=17, state="readonly",
                                      font=("Malgun Gothic", 9))
        self._book_cb.pack(fill="x", padx=4, pady=(0, 4))
        self._book_cb.bind("<<ComboboxSelected>>", self._on_book_change)

        tk.Label(nf, text=i18n.t('VOICE_CHAP','장'), bg=BG2, fg=FG,
                 font=("Malgun Gothic", 9)).pack(anchor="w", padx=4)
        self._chap_var = tk.StringVar(value=i18n.t('COMMON_ALL', '전체'))
        self._chap_cb  = ttk.Combobox(nf, textvariable=self._chap_var,
                                      width=17, state="disabled",
                                      font=("Malgun Gothic", 9))
        self._chap_cb.pack(fill="x", padx=4, pady=(0, 4))

        tk.Button(left, text='▶  '+i18n.t('VMP_QUERY_PROGRESS', '녹음 진도율 조회'), command=self._query,   # 2026-10-28 docs/1.txt 1-(2)
                  bg=BLUE, fg="white",
                  font=("Malgun Gothic", 9, "bold"),
                  bd=0, padx=10, pady=4).pack(fill="x", pady=4)

    def _build_right(self, pane):
        right = tk.Frame(pane, bg=BG)
        pane.add(right)

        # 결과 헤더
        rh = tk.Frame(right, bg=BG_HDR)
        rh.pack(fill="x")
        self._res_title = tk.Label(rh, text=i18n.t('VMP_RESULT','조회 결과'),
                                   bg=BG_HDR, fg=FG,
                                   font=("Malgun Gothic", 9, "bold"), pady=4)
        self._res_title.pack(side="left", padx=8)
        # ★ 2026-10-28 (docs/1.txt 1-(2) 「형광색으로 표시되는 것은 어떤 의미인가?」) — 색의 뜻을 적어 둔다
        tk.Label(rh, text=i18n.t('VMP_LEGEND', '초록 = 다 녹음함 · 주황 = 일부 녹음 · 회색 = 아직 없음'),
                 bg=BG_HDR, fg=FG_DIM, font=("Malgun Gothic", 8)).pack(side="right", padx=8)

        # 액션 바 — 헤더 바로 아래, 트리뷰 위에 배치
        act = tk.Frame(right, bg=BG2, pady=5)
        act.pack(fill="x", padx=4, pady=(4, 0))
        # ★ 2026-10-13 (74-3) — 단추 색을 하나로(형광 초록·보라가 눈부셨다)
        for text, cmd, bg_ in [
            (i18n.t('VMP_INTEGRITY', "무결성 검사"), self._integrity_check, BLUE),
            (i18n.t('COMMON_EXPORT', "내보내기"),   self._export,           BLUE),
            (i18n.t('COMMON_IMPORT', "가져오기"),   self._import_files,     BLUE),
        ]:
            tk.Button(act, text=text, command=cmd, bg=bg_, fg="white",
                      font=("Malgun Gothic", 9), bd=0, padx=10, pady=3
                      ).pack(side="left", padx=3)
        self._act_note = tk.Label(act, text="", bg=BG2, fg=FG_DIM,
                                  font=("Malgun Gothic", 8))
        self._act_note.pack(side="left", padx=8)
        # ★ 무결성 검사가 무엇을 재는지(74-3)
        tk.Label(right, text=i18n.t('VMP_INTEGRITY_NOTE',
                                    '무결성 검사 — ① 녹음 기록은 있는데 파일이 없는 것 ② 파일은 있는데 녹음 기록이 없는 것을 찾습니다.'),
                 bg=BG2, fg=FG_DIM, font=("Malgun Gothic", 8), anchor="w", justify="left",
                 wraplength=700).pack(fill="x", padx=8)

        # ★ 무결성 검사 결과를 고치는 단추(74-3) — 검사에서 문제가 나왔을 때만 보인다(표 바로 위)
        self._fix_bar = tk.Frame(right, bg=BG2, pady=4)
        tk.Button(self._fix_bar, text=i18n.t('VMP_I_ADD', '선택한 파일로 기록 만들기'),
                  command=lambda: self._fix_selected('ADD'), bg=BLUE, fg="white",
                  font=("Malgun Gothic", 9), bd=0, padx=10, pady=3).pack(side="left", padx=3)
        tk.Button(self._fix_bar, text=i18n.t('VMP_I_DEL', '선택한 것 지우기'),
                  command=lambda: self._fix_selected('DEL'), bg=BLUE, fg="white",
                  font=("Malgun Gothic", 9), bd=0, padx=10, pady=3).pack(side="left", padx=3)
        tk.Label(self._fix_bar, text=i18n.t('VMP_I_HELP', '기록만 있는 줄 → 기록을 지운 뒤 녹음 탭에서 다시 녹음 · '
                                                        '파일만 있는 줄 → 기록을 만들거나 파일을 지웁니다.'),
                 bg=BG2, fg=FG_DIM, font=("Malgun Gothic", 8)).pack(side="left", padx=8)

        # 결과 Treeview
        tv_f = tk.Frame(right, bg=BG)
        tv_f.pack(fill="both", expand=True, padx=4, pady=(4, 0))

        self._tv = ttk.Treeview(tv_f, columns=("c1", "c2", "c3", "c4"),
                                show="headings", selectmode="browse")
        self._set_tv_headings_default()
        self._tv.tag_configure("done",    foreground="#82E0AA")
        self._tv.tag_configure("partial", foreground=ORANGE)
        self._tv.tag_configure("none",    foreground="#808B96")
        self._tv.tag_configure("total",   foreground=FG_DIM)

        vsb = ttk.Scrollbar(tv_f, orient="vertical", command=self._tv.yview)
        self._tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self._tv.pack(fill="both", expand=True)

    # ── 필터 데이터 로드 ──────────────────────────────────────────────────────

    def _load_owners(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT voice_owner FROM user_voice_asset "
                    "ORDER BY voice_owner"
                ).fetchall()
            owners = [r[0] for r in rows]
        except Exception:
            owners = []
        if VOICES_ROOT.exists():
            for p in VOICES_ROOT.iterdir():
                if p.is_dir() and p.name not in owners:
                    owners.append(p.name)
        owners.sort()
        self._owner_cb["values"] = owners
        if not self._owner_var.get() and owners:
            self._owner_var.set(owners[0])

    def _load_owner_versions(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT version_code FROM bible_version ORDER BY version_code"
                ).fetchall()
            vers = [r[0] for r in rows]
        except Exception:
            vers = []
        self._ver_cb["values"] = vers
        cur = self._ver_var.get()
        default = self.version_getter()
        if vers:
            if cur in vers:
                pass
            elif default in vers:
                self._ver_var.set(default)
            else:
                self._ver_var.set(vers[0])
        else:
            self._ver_var.set(default)

    def _load_books(self):
        lang = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT bn.book_code, bn.full_name "     # 정식 이름(74-3)
                    "FROM book_names bn "
                    "JOIN bible_index bi ON bi.bcode = bn.book_code "
                    "WHERE bn.lang_code=? ORDER BY bn.book_code", (lang,)
                ).fetchall()
            self._book_list = [(r[0], r[1]) for r in rows]
        except Exception:
            self._book_list = []
        labels = [i18n.t('COMMON_ALL', '전체')] + [n for _, n in self._book_list]
        self._book_cb["values"] = labels

    def _on_book_change(self, event=None):
        val = self._book_var.get()
        if val == i18n.t('COMMON_ALL', '전체'):
            self._chap_cb.config(state="disabled")
            self._chap_var.set(i18n.t('COMMON_ALL', '전체'))
        else:
            bcode = next((c for c, n in self._book_list if n == val), None)
            if bcode:
                self._load_chapters(bcode)
            self._chap_cb.config(state="readonly")

    def _load_chapters(self, bcode: int):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT chapter FROM bible_index "
                    "WHERE bcode=? ORDER BY chapter", (bcode,)
                ).fetchall()
            chaps = [r[0] for r in rows]
        except Exception:
            chaps = []
        self._chap_cb["values"] = [i18n.t('COMMON_ALL', '전체')] + [str(c) for c in chaps]
        self._chap_var.set(i18n.t('COMMON_ALL', '전체'))

    # ── 조회 ──────────────────────────────────────────────────────────────────

    def _query(self):
        self._fix_bar.pack_forget()          # 무결성 검사 고치기 줄은 그 결과일 때만
        owner = self._owner_var.get()
        ver   = self._ver_var.get()
        if not owner or not ver:
            messagebox.showwarning(i18n.t('COMMON_QUERY', "조회"), i18n.t('MSG_SELECT_VOICE_VER', "목소리와 버전을 선택하세요."))
            return
        book_val = self._book_var.get()
        chap_val = self._chap_var.get()

        if book_val == i18n.t('COMMON_ALL', '전체'):
            self._query_books(owner, ver)
        else:
            bcode = next((c for c, n in self._book_list if n == book_val), None)
            if bcode is None:
                return
            if chap_val == i18n.t('COMMON_ALL', '전체'):
                self._query_chapters(owner, ver, bcode)
            else:
                try:
                    chapter = int(chap_val)
                except ValueError:
                    return
                self._query_verses(owner, ver, bcode, chapter)

    def _query_books(self, owner: str, ver: str):
        lang = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT bi.bcode, bn.full_name,     -- 정식 이름(2026-10-28 docs/1.txt 1-(2))
                           COUNT(bi.verse_id)  AS total_v,
                           COUNT(va.verse_id)  AS rec_v
                    FROM bible_index bi
                    JOIN  book_names bn
                          ON bi.bcode = bn.book_code AND bn.lang_code = ?
                    LEFT JOIN user_voice_asset va
                          ON va.verse_id      = bi.verse_id
                         AND va.voice_owner   = ?
                         AND va.bible_version = ?
                    GROUP BY bi.bcode
                    ORDER BY bi.bcode
                    """,
                    (lang, owner, ver)
                ).fetchall()
        except Exception:
            rows = []

        self._tv.delete(*self._tv.get_children())
        self._set_tv_headings_default()
        self._res_title.config(text=f"책별 진척도   {owner} / {ver}")

        total_tv = total_rv = 0
        for bcode, bname, total_v, rec_v in rows:
            pct = int(rec_v / total_v * 100) if total_v else 0
            total_tv += total_v
            total_rv += rec_v
            tag = "done" if pct == 100 else ("partial" if pct > 0 else "none")
            iid = f"bk_{bcode}"
            self._tv.insert("", "end", iid=iid,
                            values=(bname, f"{rec_v}절",
                                    f"{total_v}절", f"{pct}%"),
                            tags=(tag,))

        if rows:
            t_pct = int(total_rv / total_tv * 100) if total_tv else 0
            self._tv.insert("", "end", iid="__total__",
                            values=("── 전체 합계 ──",
                                    f"{total_rv}절",
                                    f"{total_tv}절",
                                    f"{t_pct}%"),
                            tags=("total",))
        self._act_note.config(text=f"{len(rows)}권")

    def _query_chapters(self, owner: str, ver: str, bcode: int):
        bname = next((n for c, n in self._book_list if c == bcode), str(bcode))
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT bi.chapter,
                           COUNT(bi.verse_id)  AS total_v,
                           COUNT(va.verse_id)  AS rec_v
                    FROM bible_index bi
                    LEFT JOIN user_voice_asset va
                          ON va.verse_id      = bi.verse_id
                         AND va.voice_owner   = ?
                         AND va.bible_version = ?
                    WHERE bi.bcode = ?
                    GROUP BY bi.chapter
                    ORDER BY bi.chapter
                    """,
                    (owner, ver, bcode)
                ).fetchall()
        except Exception:
            rows = []

        self._tv.delete(*self._tv.get_children())
        self._set_tv_headings_default()
        self._res_title.config(text=f"{bname}  장별 진척도   {owner} / {ver}")

        for chapter, total_v, rec_v in rows:
            pct = int(rec_v / total_v * 100) if total_v else 0
            tag = "done" if pct == 100 else ("partial" if pct > 0 else "none")
            iid = f"ch_{chapter}"
            self._tv.insert("", "end", iid=iid,
                            values=(f"{chapter}장", f"{rec_v}절",
                                    f"{total_v}절", f"{pct}%"),
                            tags=(tag,))
        self._act_note.config(text=f"{len(rows)}장")

    def _query_verses(self, owner: str, ver: str, bcode: int, chapter: int):
        bname = next((n for c, n in self._book_list if c == bcode), str(bcode))
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    """
                    SELECT bi.verse_id, bi.verse,
                           COALESCE(bc.verse_text, '') AS vtext,
                           CASE WHEN va.verse_id IS NOT NULL THEN 1 ELSE 0 END
                    FROM bible_index bi
                    LEFT JOIN bible_content bc
                          ON bc.verse_id = bi.verse_id AND bc.version_code = ?
                    LEFT JOIN user_voice_asset va
                          ON va.verse_id      = bi.verse_id
                         AND va.voice_owner   = ?
                         AND va.bible_version = ?
                    WHERE bi.bcode = ? AND bi.chapter = ?
                    ORDER BY bi.verse
                    """,
                    (ver, owner, ver, bcode, chapter)
                ).fetchall()
        except Exception:
            rows = []

        self._tv.delete(*self._tv.get_children())
        self._set_tv_headings_verse()
        self._res_title.config(
            text=f"{bname} {chapter}장  절별 상태   {owner} / {ver}")

        for vid, vnum, vtext, recorded in rows:
            preview = (vtext[:45] + "…") if len(vtext) > 45 else vtext
            status  = "✓" if recorded else "✗"
            tag     = "done" if recorded else "none"
            iid     = f"vr_{vid}"
            self._tv.insert("", "end", iid=iid,
                            values=(f"{vnum}절", preview, status, ""),
                            tags=(tag,))

        rec = sum(1 for r in rows if r[3])
        self._act_note.config(
            text=f"완료 {rec} / 전체 {len(rows)}절   미완료 {len(rows)-rec}절")

    # ── Treeview 헤딩 관리 ────────────────────────────────────────────────────

    def _set_tv_headings_default(self):
        self._tv.heading("c1", text=i18n.t('VMP_ITEM','항목'),   anchor="w")
        self._tv.heading("c2", text=i18n.t('VMP_DONEVERSE','완료절'), anchor="center")
        self._tv.heading("c3", text=i18n.t('VMP_TOTALVERSE','전체절'), anchor="center")
        self._tv.heading("c4", text=i18n.t('VMP_PROGRESS','진척도'), anchor="center")
        self._tv.column("c1", width=150, anchor="w",      stretch=True)
        self._tv.column("c2", width=70,  anchor="center", stretch=False)
        self._tv.column("c3", width=70,  anchor="center", stretch=False)
        self._tv.column("c4", width=70,  anchor="center", stretch=False)

    def _set_tv_headings_verse(self):
        self._tv.heading("c1", text=i18n.t('VOICE_VERSE','절'),   anchor="center")
        self._tv.heading("c2", text=i18n.t('COMMON_CONTENT','본문'), anchor="w")
        self._tv.heading("c3", text=i18n.t('COMMON_STATUS','상태'), anchor="center")
        self._tv.heading("c4", text="",     anchor="center")
        self._tv.column("c1", width=50,  anchor="center", stretch=False)
        self._tv.column("c2", width=300, anchor="w",      stretch=True)
        self._tv.column("c3", width=50,  anchor="center", stretch=False)
        self._tv.column("c4", width=0,   anchor="center", stretch=False)

    # ── 무결성 검사 ───────────────────────────────────────────────────────────

    def _integrity_check(self):
        """무결성 검사 → 문제 목록 [(종류, {...})] 을 **표에 줄로** 보이고 그 자리에서 고친다.
        ★ 2026-10-13 (docs/1.txt 74-3) — 그전에는 결과를 알림 창으로만 보여 줘 **할 수 있는 일이 없었다**.
          종류: NO_FILE 기록은 있는데 파일 없음(→ 기록 지우고 다시 녹음) · NO_REC 파일은 있는데 기록 없음
          (→ 기록 만들기 또는 파일 지우기). ⚠ 같은 목소리의 **다른 역본 파일은 문제가 아니다**(그전에는 잡았다)."""
        owner = self._owner_var.get()
        ver = self._ver_var.get()
        if not owner or not ver:
            self._act_note.config(text=i18n.t('MSG_SELECT_VOICE_VER', "목소리와 버전을 선택하세요."), fg=RED)
            return []
        try:
            with appdb.connect(self.db_path) as conn:
                from voice_bible import ensure_cols
                ensure_cols(conn)
                # ★ 87 — 파일을 일부러 지운 것(진척만 · has_file=0)은 문제가 아니다
                db_rows = conn.execute(
                    "SELECT verse_id, file_path FROM user_voice_asset "
                    "WHERE voice_owner=? AND bible_version=? AND COALESCE(has_file,1)=1",
                    (owner, ver)).fetchall()
        except Exception:
            db_rows = []
        probs = []
        db_paths = set()
        for vid, fpath in db_rows:
            if fpath:
                pth = resolve(fpath)
                db_paths.add(str(pth).lower())
                if not pth.exists():
                    probs.append(('NO_FILE', {'vid': vid, 'path': pth}))
        owner_dir = VOICES_ROOT / owner
        if owner_dir.exists():
            for f in sorted(list(owner_dir.glob("*.mp3")) + list(owner_dir.glob("*.wav"))
                            + list(owner_dir.glob("*.ogg"))):
                m = _FNAME_RE.match(f.name)
                if not m or m.group(1) != owner or m.group(2).upper() != ver.upper():
                    continue                                   # 다른 역본 · 다른 이름 꼴
                if str(f).lower() in db_paths:
                    continue
                vid = self._vid_of(int(m.group(3)), int(m.group(4)), int(m.group(5)))
                probs.append(('NO_REC', {'vid': vid, 'path': f, 'fmt': m.group(6).upper()}))
        self._show_integrity(owner, ver, probs)
        return probs

    def _vid_of(self, b, c, v):
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                                 (b, c, v)).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def _ref_of(self, vid):
        try:
            lang = (self.lang_getter() or 'KO').upper()
        except Exception:
            lang = 'KO'
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT COALESCE(n.short_name, b.bcode), b.chapter, b.verse FROM bible_index b"
                    " LEFT JOIN book_names n ON n.book_code=b.bcode AND n.lang_code=?"
                    " WHERE b.verse_id=?", (lang, vid)).fetchone()
            return '%s %s:%s' % r if r else str(vid)
        except Exception:
            return str(vid)

    def _show_integrity(self, owner, ver, probs):
        self._integ = {'owner': owner, 'ver': ver, 'rows': {}}
        self._tv.delete(*self._tv.get_children())
        self._tv.heading("c1", text=i18n.t('VMP_I_KIND', '문제'), anchor="w")
        self._tv.heading("c2", text=i18n.t('VOICE_VERSE', '절'), anchor="w")
        self._tv.heading("c3", text=i18n.t('VMP_I_FILE', '파일'), anchor="w")
        self._tv.heading("c4", text=i18n.t('VMP_I_TODO', '할 수 있는 일'), anchor="w")
        for col, w, st in (("c1", 170, False), ("c2", 90, False), ("c3", 230, True), ("c4", 230, True)):
            self._tv.column(col, width=w, anchor="w", stretch=st)
        for n, (kind, d) in enumerate(probs):
            iid = 'I%d' % n
            self._integ['rows'][iid] = (kind, d)
            if kind == 'NO_FILE':
                vals = (i18n.t('VMP_I_NOFILE', '기록은 있는데 파일 없음'), self._ref_of(d['vid']), d['path'].name,
                        i18n.t('VMP_I_NOFILE_DO', '기록 지우기 → 녹음 탭에서 다시 녹음'))
            else:
                vals = (i18n.t('VMP_I_NOREC', '파일은 있는데 기록 없음'),
                        self._ref_of(d['vid']) if d['vid'] else '?', d['path'].name,
                        i18n.t('VMP_I_NOREC_DO', '기록 만들기 · 또는 파일 지우기'))
            self._tv.insert('', 'end', iid=iid, values=vals, tags=('partial',))
        self._res_title.config(text=i18n.t('VMP_I_TITLE', '무결성 검사 — %s / %s') % (owner, ver))
        if probs:
            self._act_note.config(text=i18n.t('VMP_I_FOUND', '문제 %d건 — 줄을 선택하고 위 단추로 수정하세요.') % len(probs),
                                  fg=ORANGE)
            self._fix_bar.pack(fill="x", padx=4, pady=(4, 0), before=self._tv.master)
        else:
            self._act_note.config(text=i18n.t('VMP_I_OK', '이상 없음 — 녹음 기록과 파일이 모두 맞습니다.'), fg=GREEN)
            self._fix_bar.pack_forget()

    def _fix_selected(self, mode):
        """선택한 문제 줄을 고친다. ADD = 파일만 있는 것에 기록 만들기 · DEL = 기록만 있으면 기록을, 파일만 있으면 파일을 지운다."""
        info = getattr(self, '_integ', None)
        sel = [i for i in self._tv.selection() if info and i in info['rows']]
        if not sel:
            self._act_note.config(text=i18n.t('VMP_I_PICK', '고칠 줄을 선택하세요.'), fg=RED)
            return
        from voice_bible import delete_voice_record
        n = 0
        for iid in sel:
            kind, d = info['rows'][iid]
            try:
                if mode == 'ADD' and kind == 'NO_REC' and d['vid']:
                    save_voice_record(self.db_path, d['vid'], info['owner'], info['ver'], str(d['path']), d['fmt'])
                    n += 1
                elif mode == 'DEL' and kind == 'NO_FILE':
                    delete_voice_record(self.db_path, d['vid'], info['owner'], info['ver'])
                    n += 1
                elif mode == 'DEL' and kind == 'NO_REC':
                    d['path'].unlink()
                    n += 1
            except Exception as e:                       # noqa: BLE001
                try:
                    import errlog
                    errlog.warn('무결성 고치기 실패', e)
                except Exception:
                    pass
        self._integrity_check()
        self._act_note.config(text=(i18n.t('VMP_I_FIXED', '%d건을 고쳤습니다.') % n) + '  ' + self._act_note.cget('text'),
                              fg=GREEN if n else ORANGE)

    # ── 내보내기 ──────────────────────────────────────────────────────────────

    def _export(self):
        owner = self._owner_var.get()
        ver   = self._ver_var.get()
        if not owner or not ver:
            messagebox.showwarning(i18n.t('COMMON_EXPORT', "내보내기"), i18n.t('MSG_SELECT_VOICE_VER', "목소리와 버전을 선택하세요."))
            return
        dest = filedialog.askdirectory(title="내보낼 폴더 선택")
        if not dest:
            return
        dest_path = Path(dest)

        book_val = self._book_var.get()
        chap_val = self._chap_var.get()
        try:
            with appdb.connect(self.db_path) as conn:
                sql = ("SELECT va.file_path "
                       "FROM user_voice_asset va "
                       "JOIN bible_index bi ON bi.verse_id = va.verse_id "
                       "WHERE va.voice_owner=? AND va.bible_version=?")
                params: list = [owner, ver]
                if book_val != i18n.t('COMMON_ALL', '전체'):
                    bcode = next((c for c, n in self._book_list
                                  if n == book_val), None)
                    if bcode:
                        sql += " AND bi.bcode=?"
                        params.append(bcode)
                        if chap_val != i18n.t('COMMON_ALL', '전체'):
                            try:
                                sql += " AND bi.chapter=?"
                                params.append(int(chap_val))
                            except ValueError:
                                pass
                rows = conn.execute(sql, params).fetchall()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', "오류"), str(e))
            return

        copied = missing = 0
        for (fpath,) in rows:
            p = resolve(fpath) if fpath else None
            if p and p.exists():
                shutil.copy2(p, dest_path / p.name)
                copied += 1
            else:
                missing += 1

        msg = f"내보내기 완료\n복사: {copied}파일"
        if missing:
            msg += f"\n파일 없음(건너뜀): {missing}건"
        messagebox.showinfo(i18n.t('COMMON_EXPORT', "내보내기"), msg)

    # ── 가져오기 ──────────────────────────────────────────────────────────────

    def _import_files(self):
        src = filedialog.askdirectory(title="가져올 폴더 선택")
        if not src:
            return
        src_path = Path(src)

        valid: list[tuple] = []
        invalid_count = 0
        for f in list(src_path.glob("*.mp3")) + list(src_path.glob("*.wav")):
            m = _FNAME_RE.match(f.name)
            if not m:
                invalid_count += 1
                continue
            f_owner, f_ver, bs, cs, vs, _ = m.groups()
            valid.append((f_owner, f_ver, int(bs), int(cs), int(vs), f))

        if not valid:
            messagebox.showinfo(
                i18n.t('COMMON_IMPORT', "가져오기"),
                i18n.t('MSG_NO_VALID_FILE', "유효한 파일이 없습니다.\n파일명 형식: owner_version_BBB_CCC_VVV.mp3\n인식 불가: {n}개").format(n=invalid_count)
            )
            return

        owners  = sorted({v[0] for v in valid})
        vers    = sorted({v[1] for v in valid})
        preview = (f"가져올 파일: {len(valid)}개  /  인식 불가: {invalid_count}개\n"
                   f"목소리: {', '.join(owners)}\n"
                   f"버전:   {', '.join(vers)}\n\n"
                   f"계속하시겠습니까?")
        if not messagebox.askyesno(i18n.t('MSG_T_IMPORTCONFIRM', "가져오기 확인"), preview):
            return

        try:
            with appdb.connect(self.db_path) as conn:
                vid_map = {
                    (r[0], r[1], r[2]): r[3]
                    for r in conn.execute(
                        "SELECT bcode, chapter, verse, verse_id FROM bible_index"
                    ).fetchall()
                }
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', "오류"), str(e))
            return

        copied = skipped = 0
        for f_owner, f_ver, bcode, chapter, verse, src_file in valid:
            vid = vid_map.get((bcode, chapter, verse))
            if vid is None:
                skipped += 1
                continue
            dest_dir  = VOICES_ROOT / f_owner
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest_file = dest_dir / src_file.name
            shutil.copy2(src_file, dest_file)
            save_voice_record(self.db_path, vid, f_owner, f_ver, str(dest_file),
                              'WAV' if dest_file.suffix.lower() == '.wav' else 'MP3')
            copied += 1

        msg = f"가져오기 완료\n성공: {copied}파일"
        if skipped:
            msg += f"\nverse_id 없음(건너뜀): {skipped}건"
        messagebox.showinfo(i18n.t('COMMON_IMPORT', "가져오기"), msg)
        self._load_owners()
