"""
ai_sent_log.py — **AI 에게 보낸 글 전부를 글자 그대로** 남긴다 (2026-10-13 신설·영구).

사용자 지시 — 「AI 에게 보내는 모든 자료가 관리자의 눈에 전부 다 보여지는지 철저히 점검하라. 하나도 빠지면 안된다」.

★★★ 남기는 자리는 **보내는 마지막 문 셋**이다 — 그 앞에서 무엇이 붙든 여기서는 실제로 나간 글자다.
  · `ai_client.call`          — AI 작업실 · 용어 이름 제안 · 구절 연결 시험 · 문의 답변 초안 …
  · `db_ai_worship_test.ask`  — 찬양·용어 심사(제미나이 직접)
  · `claude_run.run`          — Claude(문의 유사 질문 · 용어 심사 Claude 갈래)
  ⚠ 이 셋 밖에서 AI 를 부르는 길을 새로 만들면 **여기를 부른다** — selftest 가 저장소를 훑어 잰다.

★ 집 = `admin_ai_sent.db`(관리자 PC 에만 · 배포 꾸러미·팩·git 에 안 실린다 — 사용자 문의 글이 들어 있다).
⚠ **열쇠는 남기지 않는다** — 받는 것은 글·모델·결과뿐이고, 혹시 섞이면 `secret_store.find_leaks` 로 가린다.
⚠ 기록이 실패해도 보내기는 멈추지 않는다(예외를 밖으로 안 던진다).

명령: --selftest · --list [N] · --show ID · --prune DAYS
"""
import datetime
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, 'admin_ai_sent.db')
SCHEMA = """
CREATE TABLE IF NOT EXISTS ai_sent (
    sent_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        TEXT NOT NULL,
    via       TEXT NOT NULL,          -- 보낸 문: ai_client · gemini_direct · claude
    source    TEXT NOT NULL DEFAULT '', -- 누가: AI 작업실 · 찬양 심사 · 문의 답변 …
    ref       TEXT NOT NULL DEFAULT '', -- 무엇: 'job 900 · item 123' 따위
    job_id    INTEGER,
    item_id   INTEGER,
    model     TEXT,
    prompt    TEXT NOT NULL,          -- ★ 실제로 나간 글 전부(글자 그대로)
    n_chars   INTEGER,
    ok        INTEGER,
    response  TEXT,                   -- 받은 글(전부)
    why       TEXT
);
CREATE INDEX IF NOT EXISTS idx_ai_sent_item ON ai_sent(item_id, sent_id);
CREATE INDEX IF NOT EXISTS idx_ai_sent_ts ON ai_sent(ts);
"""

#: 지금 보내는 일이 무엇인지 — 부르는 쪽이 `tag()` 로 적는다(인자를 늘리지 않으려고)
#: ★ 2026-10-30 **스레드마다 따로** — 전송과 오류 찾기가 함께 돌면 한 사전을 나눠 써서 서로의 이름표가 붙었다
#:   (실측 Pro 오류 찾기가 「AI 작업실」로, flash-lite 전송이 「오류 찾기」로 적혔다)
import threading as _th
_TLS = _th.local()


def _tagd():
    d = getattr(_TLS, 'd', None)
    if d is None:
        d = _TLS.d = {}
    return d


class tag:
    """`with ai_sent_log.tag('AI 작업실', 'job 1 · item 2', job_id=1, item_id=2): call(...)`"""

    def __init__(self, source, ref='', job_id=None, item_id=None):
        self.v = {'source': source or '', 'ref': ref or '', 'job_id': job_id, 'item_id': item_id}

    def __enter__(self):
        t = _tagd()
        self.old = dict(t)
        t.clear()
        t.update(self.v)
        return self

    def __exit__(self, *a):
        t = _tagd()
        t.clear()
        t.update(self.old)
        return False


def _conn(path=None):
    c = sqlite3.connect(path or FILE, timeout=30)
    c.executescript(SCHEMA)
    return c


def _clean(s):
    """열쇠가 섞였으면 가린다 — 기록에 열쇠가 남으면 안 된다."""
    s = s or ''
    try:
        import secret_store
        import re
        for rx in secret_store.PATTERNS:
            s = re.sub(rx.pattern.decode('ascii'), '[열쇠 가림]', s)
    except Exception:                                     # noqa: BLE001
        pass
    return s


#: 부른 모듈 → 사람 말 출처(이름표가 없을 때 호출 경로에서 읽는다 · 모르는 모듈은 파일 이름 그대로)
CALLER_NAME = {
    'db_ai_run': 'AI 작업실', 'panel_ai_workshop': 'AI 작업실(연결 시험)',
    'db_term_promote': '용어 이름 제안', 'db_ai_link_test': '구절 연결 시험',
    'qa_ai': '문의 답변 초안', 'qa_agent': '문의 유사 질문(Claude)',
    'db_ai_worship_test': '찬양 심사', 'db_ai_worship': '찬양 심사', 'db_ai_term_link': '용어 심사',
    'panel_qa_manager': '문의 답변 초안', 'panel_worship': '찬양 심사', 'panel_prayer': '기도 심사',
}
_DOOR_MODS = {'ai_sent_log', 'ai_client', 'claude_run'}


def _caller():
    """보내는 문 바깥에서 처음 만나는 모듈 → 사람 말 이름."""
    import inspect
    for fr in inspect.stack()[2:]:
        mod = os.path.splitext(os.path.basename(fr.filename))[0]
        if mod in _DOOR_MODS or (mod == 'db_ai_worship_test' and fr.function in ('ask', '_ask_raw')):
            continue
        return CALLER_NAME.get(mod, mod)
    return ''


def record(via, prompt, model='', ok=None, response='', why='', source=None, ref=None,
           job_id=None, item_id=None, path=None):
    """한 번 보낸 것을 남긴다 → sent_id(실패하면 None). 예외를 밖으로 안 던진다."""
    try:
        t = dict(_tagd())
        if not source and not t.get('source'):
            source = _caller()
        c = _conn(path)
        try:
            p = _clean(prompt)
            cur = c.execute(
                "INSERT INTO ai_sent(ts, via, source, ref, job_id, item_id, model, prompt, n_chars, ok, response, why)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (datetime.datetime.now().isoformat(timespec='seconds'), via,
                 source if source is not None else t.get('source', ''),
                 ref if ref is not None else t.get('ref', ''),
                 job_id if job_id is not None else t.get('job_id'),
                 item_id if item_id is not None else t.get('item_id'),
                 model or '', p, len(p), None if ok is None else int(bool(ok)),
                 _clean(response), (why or '')[:500]))
            c.commit()
            return cur.lastrowid
        finally:
            c.close()
    except Exception as e:                                # noqa: BLE001
        print('[ai_sent_log] 기록 못 함: %s' % e)
        return None


def rows(limit=200, source=None, q=None, path=None):
    """최근 것부터 — [(sent_id, ts, via, source, ref, model, n_chars, ok, why)]."""
    c = _conn(path)
    try:
        w, a = [], []
        if source:
            w.append('source=?')
            a.append(source)
        if q:
            w.append('(prompt LIKE ? OR response LIKE ? OR ref LIKE ?)')
            a += ['%' + q + '%'] * 3
        sql = ('SELECT sent_id, ts, via, source, ref, model, n_chars, ok, why FROM ai_sent'
               + (' WHERE ' + ' AND '.join(w) if w else '') + ' ORDER BY sent_id DESC LIMIT ?')
        return c.execute(sql, a + [int(limit)]).fetchall()
    finally:
        c.close()


def sources(path=None):
    c = _conn(path)
    try:
        return [r[0] for r in c.execute("SELECT source FROM ai_sent GROUP BY source ORDER BY MAX(sent_id) DESC")]
    finally:
        c.close()


def get(sent_id, path=None):
    c = _conn(path)
    try:
        r = c.execute("SELECT sent_id, ts, via, source, ref, job_id, item_id, model, prompt, ok, response, why"
                      " FROM ai_sent WHERE sent_id=?", (sent_id,)).fetchone()
        if not r:
            return None
        k = ('sent_id', 'ts', 'via', 'source', 'ref', 'job_id', 'item_id', 'model', 'prompt', 'ok', 'response', 'why')
        return dict(zip(k, r))
    finally:
        c.close()


def for_item(item_id, path=None):
    """그 건에 보낸 것 전부(최근 것부터) — 다시 보낸 건은 여러 번이다."""
    c = _conn(path)
    try:
        return [r[0] for r in c.execute("SELECT sent_id FROM ai_sent WHERE item_id=? ORDER BY sent_id DESC",
                                        (item_id,))]
    finally:
        c.close()


def prune(days, path=None):
    c = _conn(path)
    try:
        cut = (datetime.datetime.now() - datetime.timedelta(days=int(days))).isoformat(timespec='seconds')
        n = c.execute("DELETE FROM ai_sent WHERE ts < ?", (cut,)).rowcount
        c.commit()
        return n
    finally:
        c.close()


#: AI 에 실제로 보내는 문(이 셋만 있어야 한다) — selftest 가 저장소를 훑어 잰다
SEND_DOORS = {'ai_client.py', 'db_ai_worship_test.py', 'claude_run.py'}


def scan_senders(root=HERE):
    """저장소에서 AI 로 직접 보내는 코드를 찾는다 → 문 밖에 있는 파일 목록(있으면 빠진 것이다)."""
    import re
    pat = re.compile(r"generativelanguage\.googleapis\.com|api\.anthropic\.com|api\.openai\.com|api\.x\.ai"
                     r"|\[\s*claude_bin\(\)|'claude', '-p'")
    out = []
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if x not in ('참고코드', '.git', '.claude', 'mobile', '__pycache__', '_site_repo')
                 and not x.startswith(('_', 'rss_dist'))]
        for f in fs:
            if not f.endswith('.py') or f.startswith('temp_'):
                continue
            p = os.path.join(d, f)
            try:
                s = open(p, encoding='utf-8').read()
            except Exception:                             # noqa: BLE001
                continue
            if pat.search(s) and os.path.relpath(p, root).replace(os.sep, '/') not in SEND_DOORS \
                    and f not in ('ai_sent_log.py', 'user_ai.py', 'db_ai_models.py'):
                out.append(os.path.relpath(p, root))
    return out


def selftest():
    import tempfile
    ok = []
    ck = lambda c, m: (ok.append(bool(c)), print(('PASS ' if c else 'FAIL ') + m))   # noqa: E731
    d = tempfile.mkdtemp()
    p = os.path.join(d, 's.db')
    with tag('시험', 'job 1 · item 2', job_id=1, item_id=2):
        sid = record('ai_client', '보낸 글 전부' + chr(10) + '둘째 줄', model='m', ok=True, response='답', path=p)
    g = get(sid, path=p)
    ck(g and g['prompt'] == '보낸 글 전부' + chr(10) + '둘째 줄', '보낸 글을 글자 그대로 남긴다')
    ck(g['source'] == '시험' and g['item_id'] == 2 and g['job_id'] == 1, '누가·무엇을 tag 로 받는다')
    ck(for_item(2, path=p) == [sid], '건으로 찾는다')
    sid2 = record('ai_client', 'x', path=p)
    ck(get(sid2, path=p)['source'] == '', 'tag 밖이면 빈칸(앞 tag 가 새지 않는다)')
    key = 'AIza' + 'A' * 35
    sid3 = record('ai_client', '열쇠 ' + key, path=p)
    ck(key not in get(sid3, path=p)['prompt'], '열쇠가 섞이면 가린다')
    ck(record('x', 'y', path=os.path.join(d, 'no', 'dir', 'z.db')) is None, '기록 실패는 None — 예외 없음')
    ck(not scan_senders(), 'AI 로 보내는 문이 셋 밖에 없다: %s' % scan_senders())
    _g = {'record': record, 'p': p}
    exec(compile("sid4 = record('ai_client', 'z', path=p)", os.path.join(d, 'db_term_promote.py'), 'exec'), _g)
    ck(get(_g['sid4'], path=p)['source'] == '용어 이름 제안',
       '이름표 없으면 부른 모듈로 출처를 적는다: %r' % get(_g['sid4'], path=p)['source'])
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--list' in a:
        n = int(a[a.index('--list') + 1]) if len(a) > a.index('--list') + 1 else 30
        for r in rows(n):
            print(r)
    if '--show' in a:
        g = get(int(a[a.index('--show') + 1]))
        print(g and g['prompt'])
    if '--prune' in a:
        print(prune(int(a[a.index('--prune') + 1])))
