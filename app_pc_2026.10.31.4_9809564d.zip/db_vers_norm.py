# -*- coding: utf-8 -*-
"""db_vers_norm.py — 절별 설명문(VERS_DESC) 문단 나누기 (영구 도구)

`db_vers_gate` 의 `문단없음` 을 고친다. 한 덩어리로 붙어 있는 설명문을
**문장 수 기준으로** 나눈다.

⚠ 이 파일에 `temp_` 를 붙이지 말 것.
   전신 `temp_db_ot_norm.py` 가 이름 때문에 지워졌다. `db_vers_gate`(§0-5)·
   `db_chap_prep`(chapter.md) 에 이어 **세 번째**다. 반복 실행할 도구에는 안 붙인다.

★ 자수로 나누면 안 된다 (실측으로 확인된 것)
   문자 수로 자르면 영어가 과분할된다 — 문단당 1.55문장이 나와 게이트 하한
   2.5 에 걸렸다. 영어 문장이 한국어보다 길기 때문이다. **문장 수로 센다.**

★ 4문장 미만은 손대지 않는다 (`db_vers_gate.PARA_MIN_SENT`)
   3문장을 둘로 쪼개면 한쪽이 한 문장짜리 조각이 된다. 검사기도 같은 값으로
   잡지 않는다 — **두 값을 따로 두지 말 것.**

★ `신학적으로 이…` 앞에서 끊지 않는다
   그 자리에서 끊으면 문단이 그 말로 시작해 게이트의 `재인용요약` 에 걸린다.
   지난번에 이것을 몰라 34건을 새로 만들었다. 후보 점수에서 크게 깎고,
   그래도 생기면 `--apply` 뒤 `fix_theo` 가 되돌려 붙인다.

사용:
  python -X utf8 db_vers_norm.py --selftest              # 의무
  python -X utf8 db_vers_norm.py --check 1               # 창세기, DB 무변경
  python -X utf8 db_vers_norm.py --check 1 --ch 1-5
  python -X utf8 db_vers_norm.py --sample 1 --ch 1       # 전후 대조 출력
  python -X utf8 db_vers_norm.py --apply 1               # 실제 수정 (백업 후)
  python -X utf8 db_vers_norm.py --restore 1             # 백업에서 되돌리기
"""
import argparse
import re
import sys

import appdb
from db_vers_gate import PARA_MIN_SENT, THEO, sentences

BACKUP = 'temp_vers_norm_backup'

# 문단당 목표 문장 수의 상한. 이보다 촘촘하면 문단이 잘게 부서진다.
MAX_PER_PARA = 4
# 게이트 하한(SENT_PER_PARA_MIN=2.5)보다 넉넉히 위를 겨냥한다.
MIN_PER_PARA = 2


def _theo_start(s):
    return any(s.startswith(t) for t in THEO)


def split_paragraphs(text):
    """한 덩어리 글을 문단으로 나눈다. 나눌 수 없으면 원문 그대로 돌려준다."""
    if '\n\n' in text:
        return text
    ss = sentences(text)
    n = len(ss)
    if n < PARA_MIN_SENT:
        return text

    # 문단 수 = 문장 수를 3으로 나눈 값, 다만 2~4문장/문단 사이로 가둔다.
    n_para = max(2, min(round(n / 3.0) or 2, n // MIN_PER_PARA))
    per = n / n_para

    # 끊을 자리 후보: 각 문단 경계의 이상적 위치에서 가장 가까운 문장 사이.
    cuts = []
    for k in range(1, n_para):
        ideal = per * k
        best, best_sc = None, -1e9
        for i in range(MIN_PER_PARA, n - MIN_PER_PARA + 1):
            if i in cuts:
                continue
            sc = -abs(i - ideal)
            # ★ 다음 문단이 `신학적으로 이…` 로 시작하면 재인용요약이 된다.
            if _theo_start(ss[i]):
                sc -= 100.0
            if sc > best_sc:
                best, best_sc = i, sc
        if best is not None:
            cuts.append(best)
    cuts = sorted(set(cuts))
    if not cuts:
        return text

    out, prev = [], 0
    for cidx in cuts + [n]:
        chunk = ss[prev:cidx]
        if chunk:
            out.append(' '.join(chunk))
        prev = cidx
    return fix_theo('\n\n'.join(out))


def fix_theo(text):
    """`신학적으로 이…` 로 시작하는 문단을 앞 문단에 도로 붙인다."""
    ps = [p for p in text.split('\n\n') if p.strip()]
    if len(ps) < 2:
        return text
    merged = [ps[0]]
    for p in ps[1:]:
        if _theo_start(p.strip()) and merged:
            merged[-1] = merged[-1] + ' ' + p.strip()
        else:
            merged.append(p)
    return '\n\n'.join(merged)


def targets(conn, bcode, lo, hi):
    q = """SELECT t.sys_text_id, bi.chapter, bi.verse, t.lang_code,
                  COALESCE(t.text_variant,''), t.contents
           FROM sys_text_asset t JOIN bible_index bi ON bi.verse_id = t.clicked_id
           WHERE t.text_type='VERS_DESC' AND bi.bcode=?
             AND bi.chapter BETWEEN ? AND ?
             AND COALESCE(t.record_status,'LIVE')='LIVE'
             AND t.contents IS NOT NULL
           ORDER BY bi.chapter, bi.verse"""
    out = []
    for tid, ch, vs, lang, var, txt in conn.execute(q, (bcode, lo, hi)):
        if '\n\n' in txt:
            continue
        new = split_paragraphs(txt)
        if new != txt:
            out.append((tid, ch, vs, lang, var, txt, new))
    return out


def report(rows, total_skipped):
    from collections import Counter
    print('나눌 수 있는 행: %d' % len(rows))
    c = Counter('%s.%s' % (r[3], r[4]) for r in rows)
    for k, n in c.most_common():
        print('  %-12s %4d' % (k, n))
    if rows:
        avg = sum(len(r[6].split('\n\n')) for r in rows) / len(rows)
        sp = []
        for r in rows:
            ps = [p for p in r[6].split('\n\n') if p.strip()]
            sp.append(sum(len(sentences(p)) for p in ps) / max(len(ps), 1))
        print('  평균 %.1f문단 · 문단당 평균 %.1f문장 (게이트 하한 2.5)'
              % (avg, sum(sp) / len(sp)))
    print('손대지 않은 한 덩어리(4문장 미만): %d행' % total_skipped)


def count_skipped(conn, bcode, lo, hi):
    q = """SELECT t.contents FROM sys_text_asset t
           JOIN bible_index bi ON bi.verse_id = t.clicked_id
           WHERE t.text_type='VERS_DESC' AND bi.bcode=? AND bi.chapter BETWEEN ? AND ?
             AND COALESCE(t.record_status,'LIVE')='LIVE' AND t.contents IS NOT NULL"""
    n = 0
    for (txt,) in conn.execute(q, (bcode, lo, hi)):
        if '\n\n' not in txt and len(sentences(txt)) < PARA_MIN_SENT:
            n += 1
    return n


def apply(conn, rows):
    conn.execute("CREATE TABLE IF NOT EXISTS %s "
                 "(sys_text_id INTEGER PRIMARY KEY, contents TEXT)" % BACKUP)
    for tid, _, _, _, _, old, new in rows:
        conn.execute("INSERT OR IGNORE INTO %s VALUES (?,?)" % BACKUP, (tid, old))
        conn.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?", (new, tid))
    conn.commit()
    print('수정 %d행 · 백업 %s' % (len(rows), BACKUP))


def restore(conn):
    try:
        rows = list(conn.execute("SELECT sys_text_id, contents FROM %s" % BACKUP))
    except Exception:
        print('백업 테이블이 없다')
        return
    for tid, txt in rows:
        conn.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?", (txt, tid))
    conn.commit()
    print('되돌림 %d행' % len(rows))


def selftest():
    """★ 의무. 나누지 말아야 할 것을 나누는 것이 가장 나쁘다."""
    print('db_vers_norm 자가 검증')
    bad = []

    def ck(cond, msg):
        if not cond:
            bad.append(msg)

    # ① 하한 미만은 손대지 않는다 — 검사기와 같은 값
    s4 = ' '.join('%d번째다.' % i for i in range(1, 5))
    ck(split_paragraphs(s4) == s4, '4문장을 나눴다 — 2+2 는 문단당 2.0 이라 밀도 하한 미달')
    ck(PARA_MIN_SENT == 5, 'PARA_MIN_SENT 가 검사기와 어긋난다')

    # ② 하한 이상은 나눈다
    s6 = ' '.join('%d번째 문장이다.' % i for i in range(1, 7))
    r6 = split_paragraphs(s6)
    ck('\n\n' in r6, '6문장을 안 나눴다')
    ck(len(sentences(r6)) == 6, '나누면서 문장이 사라졌다: %d' % len(sentences(r6)))

    # ②-b ★ 밀도가 게이트 하한(2.5) 아래로 내려가지 않는가 — 5~20문장 전수
    for n in range(PARA_MIN_SENT, 21):
        src = ' '.join('%d번째 문장이다.' % i for i in range(1, n + 1))
        ps = [p for p in split_paragraphs(src).split('\n\n') if p.strip()]
        dens = sum(len(sentences(p)) for p in ps) / max(len(ps), 1)
        if dens < 2.5:
            bad.append('%d문장 → 문단당 %.1f문장 (하한 2.5 미달)' % (n, dens))

    # ②-c ★ 약어 뒤에서 문단을 끊지 않는가 (창 1:6 이 실제로 그렇게 깨졌다)
    abbr = ("God spoke and it was so. The text calls it good (cf. Ps 148:4). "
            "It is a created thing. It is not a deity. The order holds. "
            "The reader is meant to see this.")
    for p in split_paragraphs(abbr).split('\n\n'):
        if p.strip().startswith('Ps '):
            bad.append('약어 뒤에서 끊어 문장 한가운데가 갈렸다')

    # ③ ★ 자수가 아니라 문장 수로 나눈다 — 영어 과분할 재발 방지
    en = ' '.join(
        'This is a fairly long English sentence number %d that carries many characters.' % i
        for i in range(1, 9))
    ren = split_paragraphs(en)
    ps = [p for p in ren.split('\n\n') if p.strip()]
    dens = sum(len(sentences(p)) for p in ps) / max(len(ps), 1)
    ck(dens >= 2.5, '영어 과분할 — 문단당 %.1f문장 (게이트 하한 2.5)' % dens)

    # ④ `신학적으로 이…` 로 문단을 시작하지 않는다
    s = ('첫째 문장이다. 둘째 문장이다. 셋째 문장이다. '
         '신학적으로 이 대목은 중요하다. 다섯째 문장이다. 여섯째 문장이다.')
    r = split_paragraphs(s)
    ck(not any(p.strip().startswith('신학적으로 이') for p in r.split('\n\n')),
       '재인용요약을 새로 만들었다 — 신학적으로 이… 로 시작하는 문단이 생겼다')

    # ⑤ fix_theo 가 실제로 되붙이는가
    ck(fix_theo('앞이다.\n\n신학적으로 이 말은 크다.').count('\n\n') == 0,
       'fix_theo 가 되붙이지 못한다')

    # ⑥ 내용이 하나도 사라지지 않는가 (공백만 바뀐다)
    for src in (s6, en, s):
        a = re.sub(r'\s+', '', src)
        b = re.sub(r'\s+', '', split_paragraphs(src))
        ck(a == b, '내용이 바뀌었다')

    # ⑦ 이미 문단이 있는 것은 그대로 둔다
    done = '앞 문단이다. 둘째다.\n\n뒤 문단이다. 넷째다.'
    ck(split_paragraphs(done) == done, '이미 나뉜 글을 다시 건드렸다')

    # ⑧ 문단이 2개 미만으로 나오지 않는가
    ck(len([p for p in split_paragraphs(s6).split('\n\n') if p.strip()]) >= 2,
       '나눴다면서 문단이 하나다')

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 8개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', type=int)
    ap.add_argument('--sample', type=int)
    ap.add_argument('--apply', type=int)
    ap.add_argument('--restore', type=int)
    ap.add_argument('--ch', default='1-150')
    a = ap.parse_args()

    if a.selftest:
        sys.exit(selftest())

    conn = appdb.connect()
    if a.restore:
        restore(conn)
        return

    bcode = a.check or a.sample or a.apply
    if not bcode:
        ap.error('--check / --sample / --apply / --restore 중 하나가 필요하다')
    if '-' in a.ch:
        lo, hi = (int(x) for x in a.ch.split('-', 1))
    else:
        lo = hi = int(a.ch)

    rows = targets(conn, bcode, lo, hi)
    skipped = count_skipped(conn, bcode, lo, hi)

    if a.sample:
        for r in rows[:4]:
            print('=' * 70)
            print('%d:%d %s.%s' % (r[1], r[2], r[3], r[4]))
            print('--- 전 ---'); print(r[5][:400])
            print('--- 후 ---'); print(r[6][:500])
        report(rows, skipped)
        return

    report(rows, skipped)
    if a.apply:
        apply(conn, rows)


if __name__ == '__main__':
    main()
