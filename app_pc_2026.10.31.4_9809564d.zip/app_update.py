# -*- coding: utf-8 -*-
"""app_update — **앱만** 새 판으로 바꾼다(데이터는 그대로) · 2026-10-25 신설·영구 · `--selftest` 의무.

★ 사용자 지시 — 「지금 테스트 단계에서부터 데이터 이외의 업그레이드 방식을 확인하고 싶다」 ·
  「설정화면에 배치해야 하는가 아니면 업데이트 알림을 보내서 해야 하는가」 → 알림이 기본, 설정은 보조 ·
  「폰은 차선책으로」(앱이 판을 확인하고 APK 주소를 연다 · 설치는 안드로이드가).

★★ 길 = 자료 팩과 **같은 서버**(GitHub 저장소 · jsDelivr/raw) · 목록 파일 하나 `app_release.json`:
    {version, date, notes, pc:{version, file, sha256, size}, android:{version, code, file, sha256, size, url}}
  · PC = 앱 코드 zip(.py + admin/icons/browser_ext · 수 MB) — 파이썬·꾸러미·DB 는 안 싣는다.
  · 폰 = 릴리스 APK(arm64) — jsDelivr 는 20 MB 넘는 파일을 막아 **raw 주소**를 목록에 적는다.
★★ PC 받는 쪽 — 하루 한 번 목록을 보고 → 새 판이면 **미리 받아 sha 로 확인**(`_update/`) → 앱 위에 알림 한 줄 →
  **다음 시작 때**(`run.main` · DB 를 열기 전에) 갈아 끼운다(`apply_pending`) · 바로 앞 판은 `_update/prev/` 에 남겨
  설정 ▸ 앱 관리 [이전 판으로 되돌리기]로 되돌린다(역시 다음 시작 때).
⚠⚠ **데이터는 한 바이트도 안 건드린다** — zip 에 `.db` · `app_state.json` · 폴더 밖 경로가 있으면 통째로 거부한다.
⚠⚠ **개발·관리자 PC 는 갈아 끼우지 않는다**(`.git` 이 있거나 팩을 만드는 PC) — 거기 코드가 원천이다.

    python app_update.py --selftest
    python app_update.py --check                 # 이 PC 에서 새 판 확인(받지는 않음)
    python app_update.py --release --notes "바뀐 점" [--apk] [--no-pc]   # 관리자 — 판 올리고 만들고 서버에
"""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile

APP_DIR = os.path.dirname(os.path.abspath(__file__))
RELEASE_FILE = 'app_release.json'
UPD_DIR = '_update'
#: zip 안에 있으면 통째로 거부 — 데이터·설정·비밀
FORBID_EXT = ('.db', '.db-wal', '.db-shm', '.sqlite')
FORBID_NAMES = ('app_state.json', 'admin_secrets.db', 'user_data.db', 'bible_master.db')
APK_SRC = os.path.join(APP_DIR, 'mobile', 'build', 'app', 'outputs', 'flutter-apk', 'app-arm64-v8a-release.apk')


# ── 판 번호 ────────────────────────────────────────────────────────────
def current():
    try:
        import importlib
        import app_version
        importlib.reload(app_version)
        return app_version.VERSION
    except Exception:                                     # noqa: BLE001
        return '0'


def vtuple(v):
    return tuple(int(x) for x in re.findall(r'\d+', v or '0'))


def newer(a, b):
    """a 가 b 보다 새 판인가."""
    return vtuple(a) > vtuple(b)


def next_version(cur, today=None):
    today = today or time.strftime('%Y.%m.%d')
    t = vtuple(cur)
    if len(t) >= 4 and '%d.%02d.%02d' % t[:3] == today:
        return '%s.%d' % (today, t[3] + 1)
    return today + '.1'


def version_code(v):
    """폰 versionCode — 2026.10.25.1 → 2026102501(늘 커진다 · 하루 99판까지)."""
    t = vtuple(v) + (0, 0, 0, 0)
    return t[0] * 1000000 + t[1] * 10000 + t[2] * 100 + min(t[3], 99)


def write_version(v):
    """판 번호를 세 곳에 적는다 — PC(app_version.py) · 폰(lib/app_version.dart · pubspec.yaml)."""
    p = os.path.join(APP_DIR, 'app_version.py')
    s = io.open(p, encoding='utf-8').read()
    io.open(p, 'w', encoding='utf-8').write(re.sub(r"VERSION = '[^']*'", "VERSION = '%s'" % v, s))
    d = os.path.join(APP_DIR, 'mobile', 'lib', 'app_version.dart')
    io.open(d, 'w', encoding='utf-8', newline='\n').write(
        '// 자동 생성 — python app_update.py --release 가 적는다. 손으로 고치지 말 것.\n'
        "const appVersion = '%s';\nconst appVersionCode = %d;\n" % (v, version_code(v)))
    y = os.path.join(APP_DIR, 'mobile', 'pubspec.yaml')
    s = io.open(y, encoding='utf-8').read()
    # ⚠ pubspec 은 세 자리(x.y.z)만 받는다 — 해.달날.차례(2026.1025.1) · 화면에 보이는 판은 app_version.dart 의 네 자리
    t = vtuple(v) + (0, 0, 0, 0)
    s = re.sub(r'(?m)^version: .*$', 'version: %d.%d.%d+%d' % (t[0], t[1] * 100 + t[2], t[3], version_code(v)), s)
    io.open(y, 'w', encoding='utf-8').write(s)


# ── PC 코드 꾸러미 ─────────────────────────────────────────────────────
def _rules():
    import db_dist_build as DB
    return DB.SKIP_PY, DB.APP_DIRS


def code_files(app_dir=APP_DIR):
    """보낼 코드(앱 폴더 기준 상대 경로) — 배포 꾸러미의 ③과 **같은 규칙**(db_dist_build)."""
    skip, dirs = _rules()
    out = [f for f in sorted(os.listdir(app_dir))
           if f.endswith('.py') and not f.startswith(skip) and os.path.isfile(os.path.join(app_dir, f))]
    for d in dirs:
        base = os.path.join(app_dir, d)
        for root, ds, fs in os.walk(base):
            ds[:] = sorted(x for x in ds if x != '__pycache__')
            for f in sorted(fs):
                if f.endswith(('.pyc',) + FORBID_EXT):
                    continue
                out.append(os.path.relpath(os.path.join(root, f), app_dir).replace('\\', '/'))
    return out


def _bad_name(n):
    """zip 안 이름이 앱 폴더 밖이거나 데이터면 그 까닭."""
    n2 = n.replace('\\', '/')
    if n2.startswith('/') or ':' in n2 or '..' in n2.split('/'):
        return '폴더 밖 경로'
    base = n2.rsplit('/', 1)[-1].lower()
    if base.endswith(FORBID_EXT) or base in FORBID_NAMES:
        return '데이터 파일'
    if '/' not in n2 and not n2.endswith('.py'):
        return '앱 폴더 맨 위에는 .py 만'
    if '/' in n2 and n2.split('/')[0] not in _rules()[1]:
        return '알 수 없는 폴더'
    return ''


def build_pc_zip(version, app_dir=APP_DIR):
    """→ (파일 이름, 바이트, sha256). 같은 내용이면 같은 바이트(zip 시각을 못 박는다)."""
    import secret_store
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        for rel in code_files(app_dir):
            info = zipfile.ZipInfo(rel, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            data = open(os.path.join(app_dir, rel), 'rb').read()
            secret_store.assert_clean(data, rel)       # ⚠ 공개 저장소로 나간다 — 열쇠가 들었으면 판을 만들지 않는다
            z.writestr(info, data)
    data = buf.getvalue()
    sha = hashlib.sha256(data).hexdigest()
    return 'app_pc_%s_%s.zip' % (version, sha[:8]), data, sha


# ── 서버 ───────────────────────────────────────────────────────────────
def _get_bytes(srv, name, timeout=60):
    loc = (srv.get('location') or '').rstrip('/')
    if (srv.get('transport') or '').upper() == 'LOCAL_DIR':
        p = os.path.join(loc, name)
        return open(p, 'rb').read() if os.path.exists(p) else None
    from urllib.request import Request, urlopen
    try:
        with urlopen(Request('%s/%s?t=%d' % (loc, name, int(time.time() // 600)),
                             headers={'User-Agent': 'Hagah-Update/1.0'}), timeout=timeout) as r:
            return r.read()
    except Exception:                                     # noqa: BLE001
        return None


def fetch_manifest(servers=None):
    """서버 목록에서 판 목록을 읽는다 — **모든 서버에서 읽어 가장 새 판**. 없으면 None.
    ★ 2026-10-28 jsDelivr 가 옛 목록(.7)을 쥐고 있어 첫 서버만 보면 새 판(.11)이 안 보였다 · 옛 판 파일 걷기도 그 옛 목록을 봤다."""
    if servers is None:
        import rss_transport as RT
        servers = RT.client_servers()
    best = None
    for s in servers:
        if not s.get('enabled', True):
            continue
        b = _get_bytes(s, RELEASE_FILE, timeout=20)
        if not b:
            continue
        try:
            m = json.loads(b.decode('utf-8'))
        except Exception:                                 # noqa: BLE001
            continue
        if best is None or vtuple(m.get('version', '')) > vtuple(best.get('version', '')):
            best = m
    return best


def raw_url(name):
    """판 파일을 받을 주소 — ★ 2026-10-30 R2 공개 주소(크기 한도 없음 · 올린 즉시). 이름은 옛 그대로(raw 였을 때 지었다)."""
    import rss_transport as RT
    return '%s/%s' % (RT.R2_PUBLIC, name)


OLD_PAT = re.compile(r'^(app_android_.+\.apk|app_pc_.+\.zip)$')


def stale_files(names, keep):
    """판 파일 가운데 지금 목록이 가리키지 않는 것."""
    keep = {k for k in keep if k}
    return [n for n in names if OLD_PAT.match(n) and n not in keep]


def prune_old(servers, keep):
    """서버마다 지금 있는 판 파일을 보고 keep 밖의 것을 지운다 → 지운 수."""
    import rss_transport as RT
    n = 0
    for s in servers or []:
        if not s.get('enabled', True):
            continue
        tp = RT.make_transport(s)
        if not (hasattr(tp, 'listdir') and hasattr(tp, 'remove')):
            continue
        for g in stale_files(tp.listdir(), keep):
            try:
                ok, _m = tp.remove(g)
                n += 1 if ok else 0
            except Exception:                             # noqa: BLE001
                pass
        if hasattr(tp, 'flush'):
            tp.flush()
    return n


def release(servers, notes, pc=True, apk_path=None, version=None, log=print):
    """관리자 — 판 번호를 올리고(이미 정했으면 그것) · 코드 zip·APK 를 서버에 · 목록을 갈아 끼운다.
    → 올린 목록(dict). 실패하면 RuntimeError."""
    import rss_publish as P
    v = version or current()
    # ⚠ 2026-10-31 올리는 곳(git·R2)은 주소로 못 읽어 빈 목록이 되고 폰 항목이 지워졌다 — 받는 쪽 주소로도 읽고, 못 읽으면 멈춘다
    old = fetch_manifest(servers) or fetch_manifest() or {}
    if not old and not any((x.get('transport') or '').upper() == 'LOCAL_DIR' for x in servers or []):
        raise RuntimeError('지난 판 목록을 읽지 못해 올리지 않습니다')
    man = {'version': v, 'date': time.strftime('%Y-%m-%d %H:%M'), 'notes': (notes or '').strip(),
           'pc': old.get('pc') or {}, 'android': old.get('android') or {}}
    files = {}
    if pc:
        name, data, sha = build_pc_zip(v)
        files[name] = data
        man['pc'] = {'version': v, 'file': name, 'sha256': sha, 'size': len(data)}
        log('PC 코드 %s · %.1f MB' % (name, len(data) / 1e6))
    if apk_path:
        data = open(apk_path, 'rb').read()
        sha = hashlib.sha256(data).hexdigest()
        name = 'app_android_%s_%s.apk' % (v, sha[:8])
        files[name] = data
        man['android'] = {'version': v, 'code': version_code(v), 'file': name, 'sha256': sha,
                          'size': len(data), 'url': raw_url(name)}
        log('폰 APK %s · %.1f MB' % (name, len(data) / 1e6))
    js = json.dumps(man, ensure_ascii=False, indent=1)
    files[RELEASE_FILE] = js
    res = P._upload(servers, files, man['date'],
                    {'row_count': len(files), 'sha1': hashlib.sha1(js.encode('utf-8')).hexdigest()})
    if not any(r['status'] == 'OK' for r in res):
        raise RuntimeError('; '.join(r.get('message', '') for r in res))
    # 옛 판 파일은 걷는다 — ★ 2026-10-29 「지난 목록」(jsDelivr 가 옛것을 준다)이 아니라
    #   그 서버에 지금 있는 파일을 본다. 그전에는 옛 목록 탓에 APK 27개 · PC 꾸러미 27개가 하나도 안 지워졌다.
    keep = {man['pc'].get('file'), man['android'].get('file')}
    gone_n = prune_old(servers, keep)
    if gone_n:
        log('옛 판 파일 %d개 걷음' % gone_n)
    try:                                                  # ★ 2026-10-28 jsDelivr 가 옛 판 목록을 12시간까지 쥐고 있다 — 비운다
        import rss_transport as RT                        #   (올린 직후에는 jsDelivr 가 새 커밋을 아직 몰라 한 번 더 · 실측 1분 안팎)
        RT.purge_jsdelivr([RELEASE_FILE])
        if servers and not any((x.get('transport') or '').upper() == 'LOCAL_DIR' for x in servers):
            time.sleep(60)
            RT.purge_jsdelivr([RELEASE_FILE])
    except Exception:                                     # noqa: BLE001
        pass
    log('올림 — 판 %s' % v)
    return man


# ── PC 받는 쪽 ─────────────────────────────────────────────────────────
def is_dev(app_dir=APP_DIR):
    """개발·관리자 PC — 코드가 원천이라 갈아 끼우지 않는다."""
    if os.path.isdir(os.path.join(app_dir, '.git')):
        return True
    try:
        import db_linkpack_sync as LS
        return bool(LS.is_publisher(app_dir))
    except Exception:                                     # noqa: BLE001
        return False


def _ud(app_dir):
    return os.path.join(app_dir, UPD_DIR)


def pending(app_dir=APP_DIR):
    p = os.path.join(_ud(app_dir), 'pending.json')
    try:
        return json.load(open(p, encoding='utf-8'))
    except Exception:                                     # noqa: BLE001
        return None


def check(servers=None, app_dir=APP_DIR, download=True):
    """→ {'status': NEW|READY|SAME|NONE|DEV|ERROR, 'version', 'notes', 'message'}.
    NEW = 새 판이 있다(아직 안 받음) · READY = 받아 두었다(다음 시작 때 바뀐다)."""
    cur = current()
    man = fetch_manifest(servers)
    if not man:
        return {'status': 'NONE', 'version': cur, 'message': '판 목록을 읽지 못했습니다'}
    pc = man.get('pc') or {}
    v = pc.get('version') or ''
    if not v or not newer(v, cur):
        return {'status': 'SAME', 'version': cur, 'latest': v, 'notes': man.get('notes', '')}
    out = {'status': 'NEW', 'version': v, 'notes': man.get('notes', ''), 'current': cur}
    if is_dev(app_dir):
        out['status'] = 'DEV'
        return out
    pd = pending(app_dir)
    if pd and pd.get('version') == v and os.path.exists(os.path.join(_ud(app_dir), pd.get('file', ''))):
        out['status'] = 'READY'
        return out
    if not download:
        return out
    if servers is None:
        import rss_transport as RT
        servers = RT.client_servers()
    for s in servers:
        b = _get_bytes(s, pc.get('file', ''))
        if b and hashlib.sha256(b).hexdigest() == pc.get('sha256'):
            bad = verify_zip(b)
            if bad:
                return dict(out, status='ERROR', message='받은 꾸러미를 거부했습니다: ' + bad)
            os.makedirs(_ud(app_dir), exist_ok=True)
            open(os.path.join(_ud(app_dir), pc['file']), 'wb').write(b)
            json.dump({'version': v, 'file': pc['file'], 'sha256': pc['sha256'], 'notes': man.get('notes', '')},
                      open(os.path.join(_ud(app_dir), 'pending.json'), 'w', encoding='utf-8'), ensure_ascii=False)
            out['status'] = 'READY'
            return out
    return dict(out, status='ERROR', message='새 판을 받지 못했습니다(망 · 또는 확인 값이 다릅니다)')


def verify_zip(data):
    """zip 이 앱 코드만 담았나 → '' 또는 까닭."""
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
    except Exception as e:                                # noqa: BLE001
        return '열 수 없음(%s)' % e
    if 'app_version.py' not in names:
        return '판 번호 파일이 없음'
    for n in names:
        why = _bad_name(n)
        if why:
            return '%s — %s' % (n, why)
    return ''


def apply_pending(app_dir=APP_DIR):
    """`run.main` 이 **DB 를 열기 전에** 부른다 — 되돌리기 요청 · 받아 둔 새 판을 갈아 끼운다.
    → 사람 말 한 줄(한 일이 없으면 '')."""
    ud = _ud(app_dir)
    if not os.path.isdir(ud) or is_dev(app_dir):
        return ''
    prev = os.path.join(ud, 'prev')
    flag = os.path.join(ud, 'rollback.flag')
    if os.path.exists(flag):
        try:
            os.remove(flag)
            info = json.load(open(os.path.join(prev, '_prev.json'), encoding='utf-8'))
            for rel in info.get('added', []):
                p = os.path.join(app_dir, rel)
                if os.path.isfile(p):
                    os.remove(p)
            for rel in info.get('saved', []):
                dst = os.path.join(app_dir, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(os.path.join(prev, rel), dst)
            shutil.rmtree(prev, ignore_errors=True)
            return '이전 판(%s)으로 되돌렸습니다' % info.get('version', '?')
        except Exception as e:                            # noqa: BLE001
            return '되돌리지 못했습니다: %s' % e
    pd = pending(app_dir)
    if not pd:
        return ''
    zp = os.path.join(ud, pd.get('file', ''))
    try:
        data = open(zp, 'rb').read()
    except Exception:                                     # noqa: BLE001
        os.remove(os.path.join(ud, 'pending.json'))
        return ''
    if hashlib.sha256(data).hexdigest() != pd.get('sha256') or verify_zip(data):
        os.remove(os.path.join(ud, 'pending.json'))
        return '받아 둔 새 판이 상해 있어 바꾸지 않았습니다'
    was = current()
    shutil.rmtree(prev, ignore_errors=True)
    os.makedirs(prev)
    saved, added = [], []
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        for n in z.namelist():
            if n.endswith('/'):
                continue
            dst = os.path.join(app_dir, n)
            if os.path.isfile(dst):
                bk = os.path.join(prev, n)
                os.makedirs(os.path.dirname(bk), exist_ok=True)
                shutil.copy2(dst, bk)
                saved.append(n)
            else:
                added.append(n)
        json.dump({'version': was, 'saved': saved, 'added': added},
                  open(os.path.join(prev, '_prev.json'), 'w', encoding='utf-8'), ensure_ascii=False)
        for n in z.namelist():
            if n.endswith('/'):
                continue
            dst = os.path.join(app_dir, n)
            os.makedirs(os.path.dirname(dst) or app_dir, exist_ok=True)
            tmp = dst + '.upd_tmp'
            open(tmp, 'wb').write(z.read(n))
            os.replace(tmp, dst)
    os.remove(os.path.join(ud, 'pending.json'))
    try:
        os.remove(zp)
    except Exception:                                     # noqa: BLE001
        pass
    json.dump({'from': was, 'to': pd.get('version'), 'at': time.strftime('%Y-%m-%d %H:%M'), 'notes': pd.get('notes', '')},
              open(os.path.join(ud, 'applied.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    return '새 판 %s 로 바꿨습니다' % pd.get('version')


def can_rollback(app_dir=APP_DIR):
    p = os.path.join(_ud(app_dir), 'prev', '_prev.json')
    try:
        return json.load(open(p, encoding='utf-8')).get('version') or ''
    except Exception:                                     # noqa: BLE001
        return ''


def request_rollback(app_dir=APP_DIR):
    if not can_rollback(app_dir):
        return False
    open(os.path.join(_ud(app_dir), 'rollback.flag'), 'w').write(time.strftime('%Y-%m-%d %H:%M'))
    return True


def last_applied(app_dir=APP_DIR):
    try:
        return json.load(open(os.path.join(_ud(app_dir), 'applied.json'), encoding='utf-8'))
    except Exception:                                     # noqa: BLE001
        return None


def relaunch(app_dir=APP_DIR):
    """지금 앱이 끝나기를 기다렸다가 다시 켠다(새 판이 그때 들어간다)."""
    code = ('import os, sys, time, subprocess\n'
            'pid = %d\n'
            'if os.name == "nt":\n'
            '    import ctypes\n'
            '    h = ctypes.windll.kernel32.OpenProcess(0x100000, 0, pid)\n'
            '    if h:\n'
            '        ctypes.windll.kernel32.WaitForSingleObject(h, 60000)\n'
            '        ctypes.windll.kernel32.CloseHandle(h)\n'
            'else:\n'
            '    time.sleep(3)\n'
            'subprocess.Popen([sys.executable, os.path.join(%r, "run.py")], cwd=%r)\n') % (os.getpid(), app_dir, app_dir)
    kw = {}
    if os.name == 'nt':
        kw['creationflags'] = 0x00000008 | 0x00000200   # DETACHED_PROCESS | NEW_PROCESS_GROUP
    subprocess.Popen([sys.executable, '-c', code], cwd=app_dir, **kw)


# ── 시험 ───────────────────────────────────────────────────────────────
def selftest():
    import tempfile
    ok = [0, 0]

    def ck(c, m, got=''):
        ok[0 if c else 1] += 1
        print(('  PASS ' if c else '  FAIL ') + m + ('' if c else '  · %r' % (got,)))

    ck(newer('2026.10.25.2', '2026.10.25.1') and newer('2026.11.1.1', '2026.10.31.9') and not newer('1.0', '2026.1.1.1'),
       '판 견주기')
    ck(next_version('2026.10.25.1', '2026.10.25') == '2026.10.25.2' and next_version('2026.10.24.3', '2026.10.25') == '2026.10.25.1',
       '다음 판 번호')
    ck(version_code('2026.10.25.1') == 2026102501 and version_code('2026.10.25.12') > version_code('2026.10.25.2'),
       '폰 versionCode 가 늘 커진다')
    fs = code_files()
    ck('app_update.py' in fs and 'user_main.py' in fs and not any(f.startswith(('temp_', '_')) for f in fs)
       and not any(f.endswith(FORBID_EXT) for f in fs), '보낼 코드 — 하네스·데이터 없음', len(fs))
    ck(all(not _bad_name(f) for f in fs), '보낼 코드가 전부 허용 이름', [f for f in fs if _bad_name(f)][:3])
    ck(_bad_name('bible_master.db') and _bad_name('../x.py') and _bad_name('admin/../../x.py')
       and _bad_name('app_state.json') and _bad_name('C:/x.py') and not _bad_name('admin/panel_x.py'),
       '거부 — 데이터 · 폴더 밖 · 상태 파일')
    n1, b1, s1 = build_pc_zip('9.9.9.9')
    n2, b2, s2 = build_pc_zip('9.9.9.9')
    ck(s1 == s2 and not verify_zip(b1), '같은 코드 = 같은 꾸러미 · 검사 통과', (s1[:8], s2[:8]))
    # 가짜 앱 폴더에서 받기 → 갈아 끼우기 → 되돌리기 (진짜 앱 폴더는 안 건드린다)
    tmp = tempfile.mkdtemp(prefix='hagah_upd_')
    try:
        app = os.path.join(tmp, 'app')
        srv = os.path.join(tmp, 'srv')
        os.makedirs(os.path.join(app, 'admin'))
        os.makedirs(srv)
        open(os.path.join(app, 'app_version.py'), 'w').write("VERSION = '1.0'\n")
        open(os.path.join(app, 'a.py'), 'w').write('OLD = 1\n')
        open(os.path.join(app, 'user_data.db'), 'wb').write(b'MYDATA')
        zb = io.BytesIO()
        with zipfile.ZipFile(zb, 'w') as z:
            z.writestr('app_version.py', "VERSION = '2.0'\n")
            z.writestr('a.py', 'NEW = 1\n')
            z.writestr('admin/b.py', 'B = 1\n')
        data = zb.getvalue()
        sha = hashlib.sha256(data).hexdigest()
        open(os.path.join(srv, 'app_pc_2.0.zip'), 'wb').write(data)
        json.dump({'version': '2.0', 'notes': '시험', 'pc': {'version': '2.0', 'file': 'app_pc_2.0.zip', 'sha256': sha}},
                  open(os.path.join(srv, RELEASE_FILE), 'w', encoding='utf-8'))
        servers = [{'transport': 'LOCAL_DIR', 'location': srv, 'enabled': True}]
        g = globals()
        real_current, real_dev = g['current'], g['is_dev']
        g['current'] = lambda: (re.search(r"'(.*)'", open(os.path.join(app, 'app_version.py')).read()).group(1))
        g['is_dev'] = lambda app_dir=APP_DIR: False
        try:
            r = check(servers, app)
            ck(r['status'] == 'READY' and pending(app)['version'] == '2.0', '새 판을 받아 둔다(sha 확인)', r)
            ck(open(os.path.join(app, 'a.py')).read() == 'OLD = 1\n', '받기만 하고 아직 안 바꾼다')
            ck(check(servers, app)['status'] == 'READY', '다시 확인해도 다시 안 받는다')
            msg = apply_pending(app)
            ck('2.0' in msg and open(os.path.join(app, 'a.py')).read() == 'NEW = 1\n'
               and os.path.exists(os.path.join(app, 'admin', 'b.py')), '다음 시작 때 갈아 끼운다', msg)
            ck(open(os.path.join(app, 'user_data.db'), 'rb').read() == b'MYDATA', '데이터는 그대로')
            ck(check(servers, app)['status'] == 'SAME', '바뀐 뒤엔 같은 판', check(servers, app))
            ck(can_rollback(app) == '1.0' and request_rollback(app), '이전 판 되돌리기 요청')
            msg = apply_pending(app)
            ck(open(os.path.join(app, 'a.py')).read() == 'OLD = 1\n' and not os.path.exists(os.path.join(app, 'admin', 'b.py'))
               and "'1.0'" in open(os.path.join(app, 'app_version.py')).read(), '되돌림 — 옛 판 · 새로 생긴 파일 걷음', msg)
            # 나쁜 꾸러미 — 데이터를 덮으려 하면 거부
            zb = io.BytesIO()
            with zipfile.ZipFile(zb, 'w') as z:
                z.writestr('app_version.py', "VERSION = '3.0'\n")
                z.writestr('user_data.db', 'EVIL')
            bad = zb.getvalue()
            open(os.path.join(srv, 'app_pc_3.0.zip'), 'wb').write(bad)
            json.dump({'version': '3.0', 'pc': {'version': '3.0', 'file': 'app_pc_3.0.zip',
                                                'sha256': hashlib.sha256(bad).hexdigest()}},
                      open(os.path.join(srv, RELEASE_FILE), 'w', encoding='utf-8'))
            r = check(servers, app)
            ck(r['status'] == 'ERROR' and open(os.path.join(app, 'user_data.db'), 'rb').read() == b'MYDATA',
               '데이터를 덮는 꾸러미는 거부', r)
            g['is_dev'] = lambda app_dir=APP_DIR: True
            ck(check(servers, app)['status'] == 'DEV', '개발 PC 는 받지 않는다')
        finally:
            g['current'], g['is_dev'] = real_current, real_dev
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    ck(is_dev(), '이 PC(저장소)는 개발 PC 로 본다')
    print('app_update selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                     # noqa: BLE001
        pass
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--check' in a:
        print(check(download=False))
        return
    if '--prune' in a:                                   # 지금 판만 남기고 옛 판 파일을 걷는다
        import rss_publish as P
        man = fetch_manifest() or {}
        keep = {(man.get('pc') or {}).get('file'), (man.get('android') or {}).get('file')}
        if not any(keep):
            sys.exit('지금 판 목록을 못 읽어 걷지 않습니다')
        print('남길 것:', sorted(k for k in keep if k))
        print('걷은 수:', prune_old([s for s in P.get_servers() if s.get('enabled')], keep))
        return
    if '--release' in a:
        import rss_publish as P
        notes = a[a.index('--notes') + 1] if '--notes' in a else ''
        v = next_version(current())
        write_version(v)
        print('판 번호 →', v)
        apk = None
        if '--apk' in a:
            print('폰 APK 를 만듭니다(arm64)…')
            fl = os.path.join(os.path.dirname(APP_DIR), 'tools', 'flutter', 'bin', 'flutter.bat')
            env = dict(os.environ)
            env['PATH'] = os.pathsep.join([os.path.dirname(fl), os.path.join(os.path.dirname(APP_DIR), 'tools', 'jdk', 'bin'),
                                           env.get('PATH', '')])
            r = subprocess.run([fl, 'build', 'apk', '--release', '--split-per-abi', '--target-platform', 'android-arm64'],
                               cwd=os.path.join(APP_DIR, 'mobile'), env=env)
            if r.returncode != 0 or not os.path.exists(APK_SRC):
                sys.exit('APK 를 만들지 못했습니다')
            apk = APK_SRC
        live = [s for s in P.get_servers() if s.get('enabled')]
        release(live, notes, pc='--no-pc' not in a, apk_path=apk, version=v)
        return
    print(__doc__)


if __name__ == '__main__':
    main()
