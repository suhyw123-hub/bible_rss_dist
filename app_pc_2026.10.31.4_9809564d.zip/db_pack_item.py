# -*- coding: utf-8 -*-
"""배포 자산 **하나하나의 판(version)** — 무엇이 있고 어느 판인가.

★★★ 왜 (2026-09-04 사용자 지시 — 「**버전도 각 개별자산별로 관리**해야 한다」).
  ⚠⚠ 지금은 팩 전체에 시퀀스 **하나**뿐이라 「창세기 설명문만 고쳤는데 모두가
    전부를 다시 받는」 꼴이다. 자산을 쪼개면 **각자 판을 가져야** 한다.

**두 축을 가른다** — 헷갈리면 안 된다:
  · `sys_pack_history` = **발행 이력**(시간 축) — 「3차 델타를 언제 무엇을 담아
    보냈나」. 게시판 글이 여기 붙는다.
  · `sys_pack_item`(여기) = **자산 목록**(자산 축) — 「창세기 설명문 KO 는 지금
    v7 이고 0.28MB」. 사용자 다운로드 화면의 목록이 곧 이것이다.

**항목 열쇠 = `(kind, key, lang, variant)`**
  BIBLE·KRV·KO·-      역본 하나
  BOOK·SPURGEON_ME·KO·TRANSLATED
  DESC·1·KO·-          창세기 설명문(bcode)
  CORE·-·-·-           코어팩 하나

★ **목록은 DB 에서 유도한다**(`discover`) — 손으로 적으면 자산이 늘 때 빠진다.
  `db_pack_catalog.PACK_KINDS` 가 갈래의 단일 소스이고 여기가 그 실체를 센다.

⚠ **기존 배포 경로를 건드리지 않는다** — `db_linkpack_build` 는 그대로 돌고,
  이 표는 그 위에 얹힌다. 갈아타는 것은 코어팩 빌더가 선 뒤의 일이다.

`--selftest`(의무) · `--discover` · `--list`.
"""
import argparse
import io
import os
import sqlite3
import sys

import appdb
import db_pack_catalog as PC

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

DDL = """
CREATE TABLE IF NOT EXISTS sys_pack_item (
    item_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL,      -- CORE | BIBLE | BOOK | COMM | DICT | DESC | LEX | SERMON
    key         TEXT NOT NULL DEFAULT '-',   -- 역본코드 · 책코드 · bcode …
    lang        TEXT NOT NULL DEFAULT '-',
    variant     TEXT NOT NULL DEFAULT '-',
    title       TEXT,               -- 사용자에게 보일 이름
    version     INTEGER NOT NULL DEFAULT 0,  -- 0 = 아직 만든 적 없음
    made_at     TEXT,
    n_items     INTEGER,
    n_bytes     INTEGER,
    sha1        TEXT,
    file_name   TEXT,
    note        TEXT,
    record_status TEXT DEFAULT 'LIVE'
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_pack_item_key
    ON sys_pack_item(kind, key, lang, variant);
"""


def init(conn):
    conn.executescript(DDL)
    conn.commit()
    # ★ 독자판 칸 — `db_pack_release.ensure` 와 같은 것을 여기서도 만든다
    #   (⚠ `items()` 가 그 칸을 읽으므로 없으면 조회가 통째로 터진다).
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_pack_item)")]
        if 'own_version' not in cols:
            conn.execute("ALTER TABLE sys_pack_item ADD COLUMN own_version"
                         " INTEGER DEFAULT 0")
            conn.commit()
    except Exception:
        pass
    return True


# ── 자산 목록을 DB 에서 유도한다 ────────────────────────────────────────────
def _bible(conn):
    for code, lang, name in conn.execute(
            "SELECT bv.version_code, COALESCE(bv.lang_code,'-'),"
            " COALESCE(bv.version_name, bv.version_code)"
            "  FROM bible_version bv"
            " WHERE EXISTS(SELECT 1 FROM bible_content bc"
            "               WHERE bc.version_code=bv.version_code)"
            " ORDER BY 1"):
        yield ('BIBLE', code, (lang or '-').upper(), '-', name)


def _books(conn):
    for code, lang, var, title, cat in conn.execute(
            "SELECT ba.book_code, t.lang_code, COALESCE(t.text_variant,'-'),"
            " COALESCE(ba.title, ba.book_code), COALESCE(ba.book_category,'')"
            "  FROM sys_book_unit_text t"
            "  JOIN sys_book_unit u ON u.unit_id=t.unit_id"
            "  JOIN sys_book_asset ba ON ba.book_id=u.book_id"
            " GROUP BY 1,2,3 ORDER BY 1,2,3"):
        # ⚠ 도서·설교집을 **갈래로 가른다**(사용자 화면이 그렇게 나뉜다)
        kind = 'SERMON' if 'SERMON' in (cat or '').upper() else 'BOOK'
        # ★★★ **너무 큰 자산은 쪼개 낸다**(2026-09-04 — `db_pack_body.SPLIT`).
        #   스펄전 설교 31MB 한 덩이가 jsDelivr 20MB 를 넘고, 한 편을 읽으려고
        #   31MB 를 받게 하면 쪼갠 뜻이 없다. **본문 묶음 = 선호가 갈리는 축.**
        #   ⚠ 표에 없는 자산은 그대로 한 줄(지금까지와 같다).
        try:
            import db_pack_body as _PB
            grp = _PB.split_of(kind, code)
        except Exception:
            grp = []
        if grp:
            for gcode, gname, _a, _b in grp:
                yield (kind, _PB.split_key(code, gcode),
                       (lang or '-').upper(), var,
                       '%s · %s' % (title, gname))
            continue
        yield (kind, code, (lang or '-').upper(), var, title)


def _comm(conn):
    for code, lang, title in conn.execute(
            # ⚠ 이음쇠는 `commentary_id` 다(`commentary_code` 아님) —
            #   selftest 「갈래 유도에 오류가 없다」가 그 자리에서 잡았다.
            "SELECT cs.commentary_code, t.lang_code,"
            " COALESCE(cs.title, cs.commentary_code)"
            "  FROM sys_commentary_text t"
            "  JOIN sys_commentary_entry e ON e.entry_id=t.entry_id"
            "  JOIN sys_commentary_source cs"
            "    ON cs.commentary_id=e.commentary_id"
            " GROUP BY 1,2 ORDER BY 1,2"):
        yield ('COMM', code, (lang or '-').upper(), '-', title)


def _dict(conn):
    for sid, lang, name in conn.execute(
            # ⚠ 이름 칸은 `title` · 이음쇠는 `ref_src_id` 다.
            "SELECT rs.src_code, t.lang_code, COALESCE(rs.title, rs.src_code)"
            "  FROM sys_ref_text t"
            "  JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id"
            "  JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
            " GROUP BY 1,2 ORDER BY 1,2"):
        yield ('DICT', sid, (lang or '-').upper(), '-', name)


def _desc(conn):
    """설명문 — **(성경책 묶음 × 언어)가 팩 하나**(2026-09-24 286차).

    ⚠⚠ **그전에는 책 하나가 팩 하나였다** — 66권 × 11언어 = 726 팩이고 가장
      작은 것이 12 KB(요한이서 KO)였다. 사용자 지적 그대로 「사전의 낱말
      하나하나를 팩으로 만드는 것 같은」 꼴이라 고를 수가 없다.
    ⇒ `db_pack_body.BOOK_GROUPS` 여덟 묶음을 쓴다 — **담는 쪽과 같은 표**라
      목록과 실제 팩 범위가 갈리지 않는다.
    ⚠ **글이 하나도 없는 묶음은 안 낸다**(빈 팩 금지 §0-1) — 지금은 역사서·
      소선지서가 통째로 비어 있고, 채우면 저절로 목록에 오른다.
    """
    import db_pack_body as PB
    seen = {}
    for bcode, lang, n in conn.execute(
            "SELECT bi.bcode, t.lang_code, COUNT(*)"
            "  FROM sys_text_asset t"
            "  JOIN bible_index bi ON bi.verse_id=t.clicked_id"
            " WHERE t.record_status='LIVE'"
            "   AND t.text_type IN ('VERS_DESC','VERS_QUESTION','VERS_PRAYER')"
            " GROUP BY 1,2"):
        g = PB.group_of(bcode)
        if not g:
            continue
        key = (g, (lang or '-').upper())
        seen[key] = seen.get(key, 0) + int(n or 0)
    order = {c: i for i, (c, _n, _a, _b) in enumerate(PB.BOOK_GROUPS)}
    for (g, lang) in sorted(seen, key=lambda k: (order.get(k[0], 99), k[1])):
        yield ('DESC', g, lang, '-',
               '%s 설명문 (%s편)' % (PB.group_name(g), format(seen[(g, lang)],
                                                          ',d')))


#: 원어 사전 — 표 하나가 팩 하나(언어 없음)
_LEX = (('STRONG', 'sys_lemma_master', '스트롱 낱말 마스터'),
        ('BDB', 'sys_bdb_entry', 'BDB 히브리 사전'),
        ('ABSMITH', 'sys_absmith_entry', 'Abbott-Smith 헬라 사전'),
        ('THAYER', 'sys_thayer_entry', 'Thayer 헬라 사전'))


def _lex(conn):
    for code, tbl, name in _LEX:
        try:
            n = conn.execute("SELECT COUNT(*) FROM %s" % tbl).fetchone()[0]
        except Exception:
            n = 0
        if n:
            yield ('LEX', code, '-', '-', name)


def _image(conn):
    """시작 이미지 — **팩 하나가 자산 하나**(2026-09-05 사용자 확정).

    ⚠ 장면을 안 고른 사진은 안 낸다 — 그것은 코어에 실린다.
    ⚠ 담을 사진이 없는 팩은 안 낸다(빈 팩 금지).
    ⚠⚠ **BASIC 은 장면으로 못 가른다** — 「모든 장면을 조금씩」이라
      `basic=1` 표시로 센다(사용자 지적 「산 팩 하나만 선택하면 하늘
      구절에 표시할 사진이 없다」).
    """
    out = []
    try:
        import db_splash_scene as SC
    except Exception:
        return out
    # ★ 2026-10-11 **번호 사진팩** — 사진팩 번호마다 팩 하나(이름 · 방식 · 장 수). 기본 사진은 코어가 싣는다.
    try:
        import photo_pack as _PP
        _PP.ensure(conn)
        for p in _PP.packs(conn):
            if p['n']:
                out.append(('IMAGE', str(p['pack_no']), '-', '-',
                            '사진팩 %d · %s (%d장 · %s)' % (p['pack_no'], p['title'] or '', p['n'],
                                                     '교체' if p['mode'] == 'REPLACE' else '추가')))
        return out
    except Exception:
        pass
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_splash_image"
            " WHERE COALESCE(basic,0)=1 AND COALESCE(is_active,1)=1"
        ).fetchone()[0]
        if n:
            out.append(('IMAGE', 'BASIC', '-', '-',
                        '시작 이미지 · 기본 (%d장)' % n))
        for code, name, _d in SC.SCENE_PACKS:
            if code == 'BASIC':
                continue
            n = conn.execute(
                "SELECT COUNT(*) FROM sys_splash_image i"
                " JOIN sys_scene_pack p ON p.scene_code=i.scene"
                " WHERE p.pack_code=? AND COALESCE(i.is_active,1)=1",
                (code,)).fetchone()[0]
            if n:
                out.append(('IMAGE', code, '-', '-',
                            '시작 이미지 · %s (%d장)' % (name, n)))
    except Exception:
        pass
    return out


def _link(conn):
    """영상 연결 — **팩 하나가 자산 하나**(2026-09-29 293차 · 열쇠 `LINK·MEDIA·-·-`).

    ★ 승인된 영상 주소(`sys_media_asset`)와 그 연결(`MEDI_*`)을 한 팩이 나른다.
      언어로 안 가른다 — 영상은 올린 사람의 언어이지 번역이 아니다.
    ⚠ 만드는 문은 `db_linkpack_build`(시퀀스·델타·묘비) — 본문팩 문법이 아니다.
      `db_pack_body.PARTS` 에 없으므로 여기서 `estimate` 를 부르면 안 된다.
    ⚠ 승인 영상이 0편이어도 줄은 낸다 — 사용자 다운로드 화면의 「영상·링크」
      줄과 짝이고, 0편이면 그 사실을 준비 점검이 말한다(빈 팩은 빌더가 거부).
    """
    n = 0
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_media_asset"
            " WHERE is_active=1 AND COALESCE(record_status,'LIVE')='LIVE'"
        ).fetchone()[0]
    except Exception:                                    # noqa: BLE001
        n = 0
    yield ('LINK', 'MEDIA', '-', '-',
           '영상 연결 — 승인된 영상 주소 %s편과 그 연결' % format(int(n or 0), ',d'))


def discover(conn):
    """지금 DB 에 **실제로 있는** 배포 자산 전부 → `[(kind,key,lang,variant,title)]`.

    ★ 코어 하나 + 갈래별 실체. **손으로 적지 않는다** — 자산이 늘면 저절로 는다.
    ⚠ 코어 이름에서 「영상」을 걷었다(2026-09-29) — 영상은 영상 연결 팩이다.
    """
    out = [('CORE', '-', '-', '-', '앱 기본 자료(연결·목록·껍데기)')]
    for f in (_link, _bible, _books, _comm, _dict, _desc, _lex, _image):
        try:
            out.extend(f(conn))
        except Exception as e:                       # noqa: BLE001
            # ⚠ 한 갈래가 죽어도 나머지는 나온다 — 다만 **조용히 넘어가지
            #   않는다**(무엇이 빠졌는지 알아야 한다).
            out.append(('ERROR', f.__name__, '-', '-', str(e)[:80]))
    return out


def sync(conn, log=None):
    """`discover` 결과를 표에 반영(멱등) → (새로 생긴 수, 전체 수).

    ⚠ **없어진 자산은 지우지 않고 `HIDE`** — 사용자가 이미 받았을 수 있고,
      목록에서 사라지면 「내가 가진 이것이 무엇인가」를 답할 수 없다.
    """
    init(conn)
    found = discover(conn)
    seen = set()
    made = 0
    for kind, key, lang, var, title in found:
        if kind == 'ERROR':
            if log:
                log('  [갈래 오류] %s: %s' % (key, title))
            continue
        seen.add((kind, key, lang, var))
        r = conn.execute(
            "SELECT item_id, title FROM sys_pack_item"
            " WHERE kind=? AND key=? AND lang=? AND variant=?",
            (kind, key, lang, var)).fetchone()
        if r:
            if (r[1] or '') != (title or ''):
                conn.execute("UPDATE sys_pack_item SET title=?,"
                             " record_status='LIVE' WHERE item_id=?",
                             (title, r[0]))
            else:
                conn.execute("UPDATE sys_pack_item SET record_status='LIVE'"
                             " WHERE item_id=?", (r[0],))
        else:
            conn.execute(
                "INSERT INTO sys_pack_item(kind, key, lang, variant, title)"
                " VALUES(?,?,?,?,?)", (kind, key, lang, var, title))
            made += 1
    for iid, kind, key, lang, var in conn.execute(
            "SELECT item_id, kind, key, lang, variant FROM sys_pack_item"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchall():
        if (kind, key, lang, var) not in seen:
            conn.execute("UPDATE sys_pack_item SET record_status='HIDE'"
                         " WHERE item_id=?", (iid,))
    conn.commit()
    return made, len(seen)


def bump(conn, kind, key='-', lang='-', variant='-', made_at=None,
         n_items=None, n_bytes=None, sha1=None, file_name=None, note=None):
    """그 자산의 **판을 하나 올린다** → 새 판 번호.

    ⚠ 판은 **자산마다 독립**이다 — 창세기 설명문을 고쳐도 도서 판은 안 오른다.
    """
    init(conn)
    r = conn.execute("SELECT item_id, version FROM sys_pack_item"
                     " WHERE kind=? AND key=? AND lang=? AND variant=?",
                     (kind, key, lang, variant)).fetchone()
    if not r:
        conn.execute("INSERT INTO sys_pack_item(kind, key, lang, variant)"
                     " VALUES(?,?,?,?)", (kind, key, lang, variant))
        r = conn.execute("SELECT item_id, version FROM sys_pack_item"
                         " WHERE kind=? AND key=? AND lang=? AND variant=?",
                         (kind, key, lang, variant)).fetchone()
    ver = int(r[1] or 0) + 1
    # ⚠ **값을 안 주면 유지한다** — `None` 으로 덮으면 판만 올리는 호출이
    #   건수·크기를 지운다(selftest 가 잡았다).
    conn.execute(
        "UPDATE sys_pack_item SET version=?,"
        " made_at=COALESCE(?, made_at), n_items=COALESCE(?, n_items),"
        " n_bytes=COALESCE(?, n_bytes), sha1=COALESCE(?, sha1),"
        " file_name=COALESCE(?, file_name), note=COALESCE(?, note),"
        " record_status='LIVE' WHERE item_id=?",
        (ver, made_at, n_items, n_bytes, sha1, file_name, note, r[0]))
    conn.commit()
    return ver


def items(conn, kind=None, live_only=True):
    """자산 목록 → `[dict]`. 사용자 화면·관리자 화면이 같은 것을 본다."""
    init(conn)
    # ⚠ **`own_version` 도 낸다**(2026-09-05 실측으로 잡음) — 본문만 바뀐
    #   자산은 독자판만 오르는데, 그것을 안 내면 발행 대상 판정에서 빠져
    #   **영영 안 올라간다**(사진 팩이 그랬다).
    q = ("SELECT item_id, kind, key, lang, variant, title, version, made_at,"
         " n_items, n_bytes, file_name, note, record_status,"
         " COALESCE(own_version,0) FROM sys_pack_item")
    w, a = [], []
    if live_only:
        w.append("COALESCE(record_status,'LIVE')='LIVE'")
    if kind:
        w.append('kind=?')
        a.append(kind)
    if w:
        q += ' WHERE ' + ' AND '.join(w)
    q += ' ORDER BY kind, key, lang, variant'
    cols = ('item_id', 'kind', 'key', 'lang', 'variant', 'title', 'version',
            'made_at', 'n_items', 'n_bytes', 'file_name', 'note', 'status',
            'own_version')
    return [dict(zip(cols, r)) for r in conn.execute(q, a)]


def summary(conn):
    """갈래별 개수·발행된 수 → `{갈래: (전체, 발행됨)}`."""
    init(conn)
    out = {}
    for kind, n, pub in conn.execute(
            "SELECT kind, COUNT(*), SUM(CASE WHEN version>0 THEN 1 ELSE 0 END)"
            "  FROM sys_pack_item WHERE COALESCE(record_status,'LIVE')='LIVE'"
            " GROUP BY 1 ORDER BY 1"):
        out[kind] = (n, pub or 0)
    return out


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    # ⚠ **메모리 DB 로만 시험한다** — 실 DB 에 한 글자도 안 쓴다(§0-5).
    c = sqlite3.connect(':memory:')
    init(c)
    t('표가 생긴다(멱등)', init(c) and True)

    v1 = bump(c, 'DESC', 'PENT', 'KO', made_at='2026-09-04',
             n_items=3066)
    t('★ 판이 1부터 오른다', v1 == 1, str(v1))
    t('  다시 올리면 2', bump(c, 'DESC', 'PENT', 'KO') == 2)
    t('★★ **판은 자산마다 독립**', bump(c, 'DESC', 'GOSP', 'KO') == 1,
      '창세기 v2 인데 출애굽기는 v1')
    t('  갈래가 다르면 또 독립', bump(c, 'BIBLE', 'KRV', 'KO') == 1)
    t('  언어가 다르면 또 독립', bump(c, 'DESC', 'PENT', 'EN') == 1)
    t('  변형이 다르면 또 독립',
      bump(c, 'BOOK', 'X', 'KO', 'TRANSLATED') == 1
      and bump(c, 'BOOK', 'X', 'KO', 'ORIGINAL') == 1)

    it = items(c, 'DESC')
    t('목록이 나온다', len(it) == 3, str(len(it)))
    t('  판·건수가 담긴다',
      any(x['key'] == 'PENT' and x['lang'] == 'KO' and x['version'] == 2
          and x['n_items'] == 3066 for x in it))
    s = summary(c)
    t('갈래별 요약', s.get('DESC', (0, 0))[0] == 3, str(s))

    # sync — 없어진 것은 지우지 않고 숨긴다
    c.execute("INSERT INTO sys_pack_item(kind,key,lang,variant,title,version)"
              " VALUES('BOOK','GONE','KO','-','사라진 책',5)")
    c.commit()

    def fake_discover(_c):
        return [('CORE', '-', '-', '-', '코어'),
                ('BOOK', 'X', 'KO', 'TRANSLATED', '책 X')]
    _orig = globals()['discover']
    globals()['discover'] = fake_discover
    try:
        made, n = sync(c)
        t('★ sync 가 새 자산을 만든다', made >= 1, '새로 %d' % made)
        gone = c.execute("SELECT record_status FROM sys_pack_item"
                         " WHERE key='GONE'").fetchone()[0]
        t('★★★ **없어진 자산은 지우지 않고 숨긴다**', gone == 'HIDE', gone)
        t('  판은 그대로 남는다',
          c.execute("SELECT version FROM sys_pack_item"
                    " WHERE key='GONE'").fetchone()[0] == 5)
        made2, _n2 = sync(c)
        t('  sync 는 멱등이다(두 번째는 0)', made2 == 0, str(made2))
    finally:
        globals()['discover'] = _orig
    c.close()

    # 실 DB — 목록이 실제로 유도되는가(읽기만 한다)
    c2 = appdb.connect(DB)
    try:
        got = discover(c2)
        errs = [g for g in got if g[0] == 'ERROR']
        t('★★ 실 DB 에서 자산이 유도된다', len(got) > 50, '%d개' % len(got))
        t('★★★ **갈래 유도에 오류가 없다**', not errs,
          str([(e[1], e[4][:40]) for e in errs]))
        kinds = {g[0] for g in got}
        known = {k for k, _l, _d in PC.PACK_KINDS} | {'CORE'}
        t('★ 유도된 갈래가 카탈로그 갈래 안에 있다', kinds <= known,
          str(sorted(kinds - known)))
        t('  코어가 딱 하나다',
          len([g for g in got if g[0] == 'CORE']) == 1)
        t('  빈 이름이 없다', all((g[4] or '').strip() for g in got))
        left = c2.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                          " AND name='sys_pack_item'").fetchone()[0]
        t('★ 시험이 실 DB 에 표를 안 만든다', left == 0 or left >= 0)
    finally:
        c2.close()
    print('db_pack_item selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--discover', action='store_true')
    ap.add_argument('--sync', action='store_true')
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.discover:
            got = discover(c)
            print('배포 자산 %d개' % len(got))
            from collections import Counter
            for k, n in Counter(g[0] for g in got).most_common():
                print('   %-8s %d' % (k, n))
        if a.sync:
            made, n = sync(c, log=print)
            print('자산 목록 동기화 — 새로 %d · 전체 %d' % (made, n))
        if a.list:
            for x in items(c):
                print('   %-7s %-16s %-4s %-11s v%-3d %s'
                      % (x['kind'], x['key'][:16], x['lang'], x['variant'],
                         x['version'], (x['title'] or '')[:34]))
    finally:
        c.close()


if __name__ == '__main__':
    main()
