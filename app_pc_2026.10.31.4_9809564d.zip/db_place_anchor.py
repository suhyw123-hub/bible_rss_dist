# -*- coding: utf-8 -*-
"""성경 장소 ↔ 구절 — **원어 낱말 앵커**(2026-10-29 신설 · 영구 · 사용자 「성경구절 읽다가 베들레헴이라는 장소가 나왔다 ·
발자취/성지순례 지도 자산과 어떻게 연결될 수 있는가」 → 제안 「장소 용어 하나를 중심으로 · 주요용어와 같은 원어 앵커」 → 「진행하라」).

★ 장소 용어(PLACE)에 그 이름의 원어 낱말(Strong 번호)을 붙이면 그 낱말이 나오는 절이 기계로 이어진다 —
  주요용어(db_term_load)와 같은 문(`strong_verses` · 연결 = sys_link_asset ENTI_VERS · rel_code LEXICAL).
  실측 전 — 장소 140곳의 절 단위 연결 0 · 베들레헴 연결 1건.
★ 앵커는 사람이 고른다(이 표) — 사전(sys_lemma_master)의 PROPER 낱말 · `check` 가 번호마다 사전 뜻을 찍어 견준다.
⚠ 한 번호가 여러 곳·사람인 자리 — `ex`(빼는 절) · `only`(이 절만):
  베들레헴 H1035 에 스불론의 베들레헴(수 19:15) · 베다니 G963 에 요단 건너편 베다니(요 1:28) · 안디옥 G490 에 비시디아 안디옥 ·
  가이사랴 G2542 에 가이사랴 빌립보 · 숙곳 H5523 두 곳 · 헤브론 H2275 에 사람 헤브론 …
⚠ 너무 갈리는 이름은 안 붙인다(단 = 지파·사람·성읍 · 미스바 여럿 · 네게브 = 「남쪽」).
⚠ 원어 번호는 이 PC 밖으로 안 나간다(CC BY 4.0) — 폰에는 「장소 ↔ 절」 연결만 간다(주요용어와 같다).

  python db_place_anchor.py --selftest | --check | --apply | --status
"""
import sys

import appdb
import db_term_load as DT

B = {'Gen': 1, 'Exod': 2, 'Num': 4, 'Josh': 6, 'Judg': 7, '1Sam': 9, '2Sam': 10, '1Ki': 11, '2Ki': 12, '1Chr': 13, 'Mic': 33,
     '2Chr': 14, 'Ezra': 15, 'Neh': 16, 'Isa': 23, 'Hos': 28, 'Matt': 40, 'Mark': 41, 'John': 43, 'Acts': 44, '2Tim': 55}


def _r(*refs):
    """'Josh 19:15' … → [(bcode, 장, 절)]"""
    out = []
    for s in refs:
        b, cv = s.split(' ')
        c, v = cv.split(':')
        out.append((B[b], int(c), int(v)))
    return out


#: 장소 열쇠 → (원어 번호들, 빼는 절, 이 절만)
ANCHORS = {
    'PL_JERUSALEM': (['H3389', 'H3390', 'G2414', 'G2419'], [], []),
    'PL_BETHLEHEM': (['H1035', 'G965'], _r('Josh 19:15'), []),
    'PL_DAMASCUS': (['H1834', 'G1154'], [], []),
    'PL_SINAI': (['H5514', 'G4614'], [], []),
    'PL_EGYPT': (['H4714', 'G125'], [], []),
    'PL_BABYLON': (['H894', 'G897'], [], []),
    'PL_HEBRON': (['H2275'], _r('Exod 6:18', 'Num 3:19', '1Chr 2:42', '1Chr 2:43', '1Chr 6:2', '1Chr 6:18', '1Chr 15:9',
                                '1Chr 23:12', '1Chr 23:19', '1Chr 24:23'), []),
    'PL_JERICHO': (['H3405', 'G2410'], [], []),
    'PL_NAZARETH': (['G3478'], [], []),
    'PL_CAPERNAUM': (['G2584'], [], []),
    'PL_GETHSEMANE': (['G1068'], [], []),
    'PL_GOLGOTHA': (['G1115'], [], []),
    'PL_MT_OLIVES': (['G1638'], [], []),
    'PL_MT_CARMEL': (['H3760'], _r('Josh 15:55', '1Sam 15:12', '1Sam 25:2', '1Sam 25:5', '1Sam 25:7', '1Sam 25:40'), []),
    'PL_MT_HERMON': (['H2768'], [], []),
    'PL_MT_ZION': (['H6726', 'G4622'], [], []),
    'PL_SEA_GALILEE': (['H3672'], [], []),
    'PL_JORDAN': (['H3383', 'G2446'], [], []),
    'PL_BETHANY': (['G963'], _r('John 1:28'), []),
    'PL_BETHANY_JORDAN': (['G963'], [], _r('John 1:28')),
    'PL_SAMARIA': (['H8111', 'G4540'], [], []),
    'PL_NINEVEH': (['H5210', 'G3535'], [], []),
    'PL_ANTIOCH': (['G490'], _r('Acts 13:14', 'Acts 14:19', 'Acts 14:21', '2Tim 3:11'), []),
    'PL_PISIDIAN_ANTIOCH': (['G490'], [], _r('Acts 13:14', 'Acts 14:19', 'Acts 14:21', '2Tim 3:11')),
    'PL_HARRAN': (['H2771'], _r('1Chr 2:46'), []),
    'PL_RAMESES': (['H7486'], [], []),
    'PL_SUCCOTH': (['H5523'], [], _r('Exod 12:37', 'Exod 13:20', 'Num 33:5', 'Num 33:6')),
    'PL_SUCCOTH_JV': (['H5523'], _r('Exod 12:37', 'Exod 13:20', 'Num 33:5', 'Num 33:6'), []),
    'PL_MARAH': (['H4785'], [], []),
    'PL_ELIM': (['H362'], [], []),
    'PL_REPHIDIM': (['H7508'], [], []),
    'PL_UR': (['H218'], _r('1Chr 11:35'), []),
    'PL_SHECHEM': (['H7927', 'G4966'], [], []),
    'PL_BETHEL': (['H1008'], [], []),
    'PL_BEERSHEBA': (['H884'], [], []),
    'PL_GERAR': (['H1642'], [], []),
    'PL_BEER_LAHAI_ROI': (['H883'], [], []),
    'PL_MAHANAIM': (['H4266'], [], []),
    'PL_PENIEL': (['H6439'], _r('1Chr 4:4', '1Chr 8:25'), []),
    'PL_MORIAH': (['H4179'], [], []),
    'PL_GIBEON': (['H1391'], [], []),
    'PL_MIDIAN': (['H4080', 'G3099'], _r('Gen 25:2', 'Gen 25:4'), []),
    'PL_KADESH': (['H6946', 'H6947'], [], []),
    'PL_NEBO': (['H5015'], _r('Isa 46:1', 'Ezra 2:29', 'Ezra 10:43', 'Neh 7:33'), []),
    'PL_GILGAL': (['H1537'], [], []),
    'PL_AI': (['H5857'], [], []),
    'PL_SHILOH': (['H7887'], [], []),
    'PL_TIMNATH': (['H8556'], [], []),
    'PL_CHERITH': (['H3747'], [], []),
    'PL_ZAREPHATH': (['H6886', 'G4558'], [], []),
    'PL_ABEL_MEHOLAH': (['H65'], [], []),
    'PL_SHUNEM': (['H7766'], [], []),
    'PL_DOTHAN': (['H1886'], [], []),
    'PL_CANA': (['G2580'], [], []),
    'PL_CAESAREA_PHILIPPI': (['G2542'], [], _r('Matt 16:13', 'Mark 8:27')),
    'PL_CAESAREA': (['G2542'], _r('Matt 16:13', 'Mark 8:27'), []),
    'PL_SALAMIS': (['G4529'], [], []),
    'PL_PAPHOS': (['G3974'], [], []),
    'PL_PERGA': (['G4011'], [], []),
    'PL_ICONIUM': (['G2430'], [], []),
    'PL_LYSTRA': (['G3082'], [], []),
    'PL_DERBE': (['G1191'], [], []),
    'PL_TROAS': (['G5174'], [], []),
    'PL_EPHESUS': (['G2181'], [], []),
    'PL_MILETUS': (['G3399'], [], []),
    'PL_MYRA': (['G3460'], [], []),
    'PL_PHILIPPI': (['G5375'], [], []),
    'PL_THESSALONICA': (['G2332'], [], []),
    'PL_BEREA': (['G960'], [], []),
    'PL_ATHENS': (['G116'], [], []),
    'PL_CORINTH': (['G2882'], [], []),
    'PL_TYRE': (['H6865', 'G5184'], [], []),
    'PL_SIDON': (['H6721', 'G4605'], _r('Gen 10:15', '1Chr 1:13'), []),
    'PL_MALTA': (['G3194'], [], []),
    'PL_SYRACUSE': (['G4946'], [], []),
    'PL_PUTEOLI': (['G4223'], [], []),
    'PL_ROME': (['G4516'], [], []),
    'PL_JOPPA': (['H3305', 'G2445'], [], []),
    'PL_LYDDA': (['H3850', 'G3069'], [], []),
    'PL_GAZA': (['H5804', 'G1048'], [], []),
    'PL_AZOTUS': (['H795', 'G108'], [], []),
    'PL_PATMOS': (['G3963'], [], []),
    'PL_GIBEAH': (['H1390'], [], []),
    'PL_RAMAH': (['H7414', 'G4471'], _r('Josh 19:29', 'Josh 19:36'), []),
    'PL_MICHMASH': (['H4363'], [], []),
    'PL_ZIPH': (['H2128'], _r('1Chr 2:42', '1Chr 4:16'), []),
    'PL_ENGEDI': (['H5872'], [], []),
    'PL_ENDOR': (['H5874'], [], []),
    'PL_GILBOA': (['H1533'], [], []),
    'PL_OPHRAH': (['H6084'], _r('1Chr 4:14'), []),
    'PL_HAROD': (['H5878'], [], []),
    'PL_GOSHEN': (['H1657'], _r('Josh 10:41', 'Josh 11:16', 'Josh 15:51'), []),
    'PL_SODOM': (['H5467', 'G4670'], [], []),
    'PL_ZOAR': (['H6820'], [], []),
    'PL_DEBIR': (['H1688'], _r('Josh 10:3'), []),
    'PL_KEDESH_N': (['H6943'], [], _r('Josh 12:22', 'Josh 19:37', 'Josh 20:7', 'Josh 21:32', 'Judg 4:6', 'Judg 4:9', 'Judg 4:10',
                                      'Judg 4:11', '2Ki 15:29', '1Chr 6:76')),
    'PL_TABOR': (['H8396'], _r('1Sam 10:3', '1Chr 6:77'), []),
    'PL_MEGIDDO': (['H4023', 'G717'], [], []),
    'PL_ZORAH': (['H6881'], [], []),
    'PL_TIMNAH': (['H8553'], [], []),
    'PL_ASHKELON': (['H831'], [], []),
    'PL_ETAM': (['H5862'], [], _r('Judg 15:8', 'Judg 15:11')),
    'PL_LEHI': (['H3896'], [], []),
    'PL_SOREK': (['H7796'], [], []),
    'PL_MOAB': (['H4124'], _r('Gen 19:37'), []),
    'PL_GESHUR': (['H1650'], [], []),
    'PL_ZEREDAH': (['H6868'], [], []),
    'PL_TIRZAH': (['H8656'], _r('Num 26:33', 'Num 27:1', 'Num 36:11', 'Josh 17:3'), []),
    'PL_RAMOTH_GILEAD': (['H7433'], [], []),
    'PL_JEZREEL': (['H3157'], _r('Josh 15:56', '1Sam 25:43', '1Chr 4:3'), []),
    'PL_GATH_HEPHER': (['H1662'], [], []),
    'PL_ANATHOTH': (['H6068'], _r('1Chr 7:8', 'Neh 10:19'), []),
    'PL_TAHPANHES': (['H8471'], [], []),
    'PL_TEL_ABIB': (['H8512'], [], []),
    'PL_SUSA': (['H7800'], [], []),
    'PL_AHAVA': (['H163'], [], []),
    'PL_AENON': (['G137'], [], []),
    'PL_TARSUS': (['G5019'], [], []),
    'PL_ALEXANDRIA': (['G221'], [], []),
}
SRC = 'PLACE_ANCHOR'      # 이 도구가 만든 연결 표식(sys_link_asset.source) — 다시 만들 때 이것만 걷는다


def gloss(conn, strong):
    r = conn.execute('SELECT gloss, wtype, occurrences FROM sys_lemma_master WHERE strong=?', (strong,)).fetchone()
    return r


def plan(conn):
    """→ {장소 열쇠: (용어 번호, [절 번호])} · 못 푼 것은 [(열쇠, 까닭)]"""
    ids = {r[0]: r[1] for r in conn.execute("SELECT entity_code, entity_id FROM sys_entity_master WHERE entity_type='PLACE'")}
    out, bad = {}, []
    for code, (strongs, ex, only) in ANCHORS.items():
        if code not in ids:
            bad.append((code, '장소 없음'))
            continue
        exv = {DT._vid(conn, *x) for x in ex}
        onv = {DT._vid(conn, *x) for x in only}
        got = set()
        for s in strongs:
            vs = DT.strong_verses(s, conn)
            if vs is None:
                bad.append((code, '%s 절 자료 없음' % s))
                continue
            got.update(vs)
        if only:
            got &= onv
        got -= exv
        out[code] = (ids[code], sorted(got))
    return out, bad


def apply(conn):
    """앵커(sys_entity_lemma) + LEXICAL 연결을 다시 짓는다 — 이 도구가 만든 것만 걷고 다시(사람이 이은 것 · 단락 연결은 그대로)."""
    out, _bad = plan(conn)
    cur = conn.cursor()
    n_link = 0
    for code, (eid, vids) in out.items():
        cur.execute("DELETE FROM sys_entity_lemma WHERE entity_id=?", (eid,))
        for i, s in enumerate(ANCHORS[code][0]):
            g = gloss(conn, s)
            cur.execute('INSERT INTO sys_entity_lemma(entity_id, lang_code, strong, translit, gloss, sort_order, record_status)'
                        " VALUES(?,?,?,?,?,?,'LIVE')", (eid, 'HE' if s.startswith('H') else 'EL', s, '', (g[0] if g else '')[:120], i))
        cur.execute("DELETE FROM %s WHERE %s AND %s=? AND rel_code='LEXICAL' AND COALESCE(source,'')=?"
                    % (DT.EV_TABLE, DT.EV_WHERE, DT.EV_A), (eid, SRC))
        lid = cur.execute('SELECT lemma_id FROM sys_entity_lemma WHERE entity_id=? ORDER BY sort_order LIMIT 1', (eid,)).fetchone()[0]
        for v in vids:
            cur.execute('INSERT OR IGNORE INTO %s(link_type,%s,%s,rel_code,lemma_id,is_key,source,record_status)'
                        " VALUES('%s',?,?,'LEXICAL',?,0,?,'LIVE')" % (DT.EV_TABLE, DT.EV_A, DT.EV_B, DT.EV_TYPE),
                        (eid, v, lid, SRC))
            n_link += 1
    conn.commit()
    return len(out), n_link


def check(conn):
    out, bad = plan(conn)
    for code, (strongs, ex, only) in ANCHORS.items():
        gs = []
        for s in strongs:
            g = gloss(conn, s)
            gs.append('%s=%s' % (s, ('%s/%s' % (g[0][:38], g[1])) if g else '없음'))
        print('%-22s %4d절  %s%s%s' % (code, len(out.get(code, (0, []))[1]), ' · '.join(gs),
                                       '  빼기 %d' % len(ex) if ex else '', '  만 %d' % len(only) if only else ''))
    for b in bad:
        print('  ⚠', b)
    return out, bad


def status(conn):
    n = conn.execute("SELECT COUNT(*), COUNT(DISTINCT %s) FROM %s WHERE %s AND COALESCE(source,'')=?"
                     % (DT.EV_A, DT.EV_TABLE, DT.EV_WHERE), (SRC,)).fetchone()
    print('장소 원어 연결 %d절 · 장소 %d곳' % n)


def selftest():
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    conn = appdb.connect()
    gl = {s: gloss(conn, s) for v in ANCHORS.values() for s in v[0]}
    miss = [s for s, g in gl.items() if not g]
    ck(not miss, '모든 원어 번호가 사전에 있다', miss)
    # 사전이 GENERAL 로 적은 장소 이름(뜻을 보고 확인함) — 그릿 시내 · 가사(아사) · 감람원(올리브 산)
    notp = [s for s, g in gl.items() if g and g[1] != 'PROPER' and s not in ('G1638', 'H3747', 'H5804')]
    ck(not notp, '모두 고유명사(PROPER)', notp)
    out, b = plan(conn)
    ck(not [x for x in b if '장소 없음' in x[1]], '모든 장소가 있다', b)
    bl = out['PL_BETHLEHEM'][1]
    js = DT._vid(conn, 6, 19, 15)
    mic = DT._vid(conn, 33, 5, 2)
    mt = DT._vid(conn, 40, 2, 1)
    ck(js not in bl and mic in bl and mt in bl, '베들레헴 — 미 5:2 · 마 2:1 · 스불론의 베들레헴(수 19:15)은 뺀다')
    j128 = DT._vid(conn, 43, 1, 28)
    ck(out['PL_BETHANY_JORDAN'][1] == [j128] and j128 not in out['PL_BETHANY'][1], '베다니 둘 — 요 1:28 은 요단 건너편만')
    cp = out['PL_CAESAREA_PHILIPPI'][1]
    ck(len(cp) == 2 and not set(cp) & set(out['PL_CAESAREA'][1]), '가이사랴 둘 — 겹치지 않는다', cp)
    ck(len(out['PL_JERUSALEM'][1]) > 600, '예루살렘 — 구약·신약', len(out['PL_JERUSALEM'][1]))
    print('\ndb_place_anchor selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(a):
    if '--selftest' in a:
        return 0 if selftest() else 1
    conn = appdb.connect()
    if '--check' in a:
        check(conn)
    if '--apply' in a:
        print('장소 %d · 연결 %d절' % apply(conn))
    status(conn)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
