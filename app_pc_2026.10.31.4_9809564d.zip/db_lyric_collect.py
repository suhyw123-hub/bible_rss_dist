# -*- coding: utf-8 -*-
"""찬양 **가사** — 받아 두고 용어·구절을 뽑는 자리 (2026-09-10 신설).

사용자 지시 「용어 연결 문제는 **가사를 수집해야** 비로소 근본적으로 해결할 수
있다」 · 「나중에 연결된 것들이 과연 **가사에서 추출한 것인지 임의로 만든 것인지
알 수 없을 것이다**」.

★★★ **가사는 곡(판)의 것이지 영상의 것이 아니다.** 같은 곡 영상 15편에 가사를
  15벌 담으면 갈라진다. 실측 **판 45개에 영상 300편** — 가사 45벌이면 300편이
  덮인다.

⚠⚠⚠ **가사는 저작물이다 — 배포 DB 에 넣지 않는다.**
  `wlc_verify.db`·`gnt_verify.db` 와 같은 취급이다(§18-10·§18-11):
  받은 글은 **이 PC 의 `lyrics_work.db` 에만** 있고, 배포되는 것은 거기서 나온
  **연결(구절·용어 번호)과 근거 글자**뿐이다.
  ⇒ 이 파일은 `bible_master.db` 에 표를 만들지 않는다(selftest 가 잰다).

⚠ 설명문에는 가사가 **없다**(실측 856편 중 절/후렴 표지 11편 1.3% · 반복 후렴
  0편). 그 11편도 크레딧·타임스탬프였다. **밖에서 받아야 한다.**

명령
  --selftest   자가검증(의무)
  --probe      **자막이 있는지 센다**(쿼터 0 — 링크 점검이 이미 받는 값이다)
  --status     지금 담긴 가사와 자막 현황
"""
import io
import os
import sqlite3
import sys

APP = os.path.dirname(os.path.abspath(__file__))
#: ⚠ **배포 안 함** — 파일 이름부터 따로 둔다.
DB = os.path.join(APP, 'lyrics_work.db')

SCHEMA = (
    # 자막이 있나 — 영상마다. 받은 것이 아니라 **있나 없나**다.
    "CREATE TABLE IF NOT EXISTS caption_probe ("
    " media_id INTEGER PRIMARY KEY,"
    " has_caption INTEGER NOT NULL,"
    " probed_at TEXT DEFAULT (datetime('now')))",
    # 가사 본문 — **판(rendition)에 하나**.
    "CREATE TABLE IF NOT EXISTS lyric ("
    " lyric_id INTEGER PRIMARY KEY AUTOINCREMENT,"
    " rend_id INTEGER, song_id INTEGER,"
    " lang_code TEXT, body TEXT NOT NULL,"
    " src_kind TEXT, src_url TEXT, media_id INTEGER,"
    " got_at TEXT DEFAULT (datetime('now')))",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_lyric_rend"
    " ON lyric(rend_id, lang_code)",
)


def _db():
    conn = sqlite3.connect(DB)
    for q in SCHEMA:
        conn.execute(q)
    conn.commit()
    return conn


# ── 자막이 있나 ─────────────────────────────────────────────────────────
def probe(app_conn, keys=None, only_new=True, limit=None, log=print):
    """찬양 영상에 **자막이 있는지** 센다 → 요약 dict.

    ★★★ **쿼터가 0이다** — 링크 점검이 이미 `contentDetails` 를 받고 있고
      그 안에 `caption` 칸이 있다. 그동안 받아서 **버리고 있었다**.
      (`videos.list` 는 50개당 1 unit 이고 칸을 더해도 값이 안 는다.)
    ⚠ 「자막이 있다」가 「가사가 있다」는 아니다 — 자동 인식 자막일 수 있고
      찬양이면 대개 가사지만 **받아 봐야 안다**. 여기서는 **셈만** 한다.
    """
    import db_media_linkcheck as LC
    keys = keys if keys is not None else LC.api_keys(app_conn)
    if not keys:
        log('  [자막] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    lc = _db()
    try:
        have = ({r[0] for r in lc.execute('SELECT media_id FROM caption_probe')}
                if only_new else set())
        rows = [(m, u) for m, u in app_conn.execute(
            "SELECT media_id, url FROM sys_media_asset"
            " WHERE record_status='LIVE' AND is_active=1"
            "   AND media_type IN ('WORSHIP','READING')"
            "   AND url IS NOT NULL") if m not in have]
        if limit:
            rows = rows[:int(limit)]
        out = {'asked': len(rows), 'yes': 0, 'no': 0, 'units': 0, 'err': []}
        if not rows:
            log('  [자막] 물을 것이 없습니다.')
            return out

        def on_cap(mid, yes):
            lc.execute('INSERT INTO caption_probe(media_id, has_caption)'
                       ' VALUES(?,?) ON CONFLICT(media_id)'
                       ' DO UPDATE SET has_caption=excluded.has_caption,'
                       "  probed_at=datetime('now')", (int(mid), 1 if yes else 0))
            out['yes' if yes else 'no'] += 1

        log('  [자막] %d편 · 예상 %d units' % (len(rows), -(-len(rows) // 50)))
        LC.probe_api(rows, keys, lambda *a: None, on_caption=on_cap,
                     on_error=lambda m: out['err'].append(m))
        lc.commit()
        out['units'] = -(-len(rows) // 50)
        log('  [자막] 있다 %d · 없다 %d · 쓴 units %d'
            % (out['yes'], out['no'], out['units']))
        return out
    finally:
        lc.close()


def caption_map(only_yes=True):
    """{media_id: True/False} — 화면·도구가 묻는 문."""
    lc = _db()
    try:
        q = 'SELECT media_id, has_caption FROM caption_probe'
        if only_yes:
            q += ' WHERE has_caption=1'
        return {r[0]: bool(r[1]) for r in lc.execute(q)}
    finally:
        lc.close()


def status(app_conn, log=print):
    """자막·가사 현황 — **판 단위로** 센다(가사는 판의 것이라)."""
    import db_song as SG
    lc = _db()
    try:
        cap = {r[0]: r[1] for r in lc.execute(
            'SELECT media_id, has_caption FROM caption_probe')}
        lyr = {r[0] for r in lc.execute(
            'SELECT rend_id FROM lyric WHERE rend_id IS NOT NULL')}
    finally:
        lc.close()
    tot = app_conn.execute(
        "SELECT COUNT(*) FROM sys_media_asset WHERE record_status='LIVE'"
        "   AND is_active=1 AND media_type='WORSHIP'").fetchone()[0]
    rends = {}
    for mid, rid in app_conn.execute(
            "SELECT clicked_id, target_id FROM sys_link_asset"
            " WHERE link_type=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (SG.LINK_MEDI,)):
        rends.setdefault(rid, []).append(mid)
    with_cap = sum(1 for r, ms in rends.items() if any(cap.get(m) for m in ms))
    log('찬양 %d편 · 잰 것 %d · 자막 있다 %d'
        % (tot, len(cap), sum(1 for v in cap.values() if v)))
    log('판 %d개 · 자막 있는 영상을 가진 판 %d개 · 가사를 담은 판 %d개'
        % (len(rends), with_cap, len(lyr)))
    return {'videos': tot, 'probed': len(cap),
            'caption': sum(1 for v in cap.values() if v),
            'rends': len(rends), 'rend_caption': with_cap, 'rend_lyric': len(lyr)}


# ── 공개된 글에서 가사 찾기 ─────────────────────────────────────────────
#: 사용자 지시(2026-09-10) 「인터넷에 공개된 글을 조사하면 찬양곡 제목, 가사가
#: 기록된 것들이 있을 것이다. 이것을 수집하는 방법을 말한 것이다」.
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
                    ' AppleWebKit/537.36 Chrome/122 Safari/537.36',
      'Accept-Language': 'ko-KR,ko;q=0.9,en;q=0.8'}


def _get(url, timeout=15):
    import urllib.request
    return urllib.request.urlopen(
        urllib.request.Request(url, headers=UA), timeout=timeout
    ).read().decode('utf-8', 'replace')


def norm_title(s):
    """맞춤 대조용 — 부호·괄호·공백을 걷고 소문자로.

    ⚠ 괄호 꼬리(`(Live)`·`(Official)`)를 걷는다 — 안 걷으면 같은 곡이 안 맞는다.
    """
    import re as _re
    t = str(s or '')
    t = _re.sub(r'\([^)]*\)|\[[^\]]*\]', ' ', t)
    t = _re.sub(r'[^0-9A-Za-z가-힣]+', '', t)
    return t.lower()


def title_matches(want, got):
    """찾은 글이 **정말 그 곡인가**.

    ⚠⚠⚠ **첫 결과를 그냥 받으면 안 된다**(2026-09-10 실측으로 당했다) —
      genius 는 무엇을 물어도 무언가를 내놓아서, 우리 곡 20개를 물었더니
      **19개가 「찾았다」로 나왔는데 Kanye West·Kendrick Lamar·KARD 였다.**
      §233차 「흔한 낱말 곡명이 세속 음악을 끌고 온다」 그 자리다.
    ⇒ **곡 이름이 결과 제목에 낱말 그대로 들어 있어야** 받는다.
    """
    w, g = norm_title(want), norm_title(got)
    if len(w) < 3:
        return False               # 너무 짧으면 우연히 맞는다
    return w in g


def search_genius(title, artist='', limit=6):
    """공개 검색으로 후보를 찾는다 → [(제목, 주소)] — **맞는 것만**.

    ⚠ 키가 필요 없다(공개 엔드포인트). ⚠ 사이를 두고 부른다(부르는 쪽이).
    """
    import json as _j
    import urllib.parse as _up
    q = ' '.join(x for x in (str(title or ''), str(artist or '')) if x)
    try:
        j = _j.loads(_get('https://genius.com/api/search/multi?q=%s'
                          % _up.quote(q[:80])))
    except Exception:
        return []
    out = []
    for sec in j.get('response', {}).get('sections', []):
        for h in sec.get('hits', []):
            r = h.get('result', {}) or {}
            u, ft = str(r.get('url') or ''), str(r.get('full_title') or '')
            if u.endswith('-lyrics') and title_matches(title, ft):
                out.append((ft, u))
                if len(out) >= limit:
                    return out
    return out


def fetch_genius(url):
    """그 글에서 **가사 덩어리만** 뽑는다 → 글(못 뽑으면 '')."""
    import re as _re
    import html as _h
    try:
        page = _get(url)
    except Exception:
        return ''
    blocks = _re.findall(
        r'<div[^>]+data-lyrics-container="true"[^>]*>(.*?)</div>', page, _re.S)
    if not blocks:
        return ''
    txt = _h.unescape(_re.sub(r'<br\s*/?>', chr(10), ' '.join(blocks)))
    txt = _re.sub(r'<[^>]+>', '', txt)
    # ⚠ 머리의 「N Contributors…」 같은 군더더기를 걷는다
    lines = [x.strip() for x in txt.splitlines() if x.strip()]
    if lines and ('Contributor' in lines[0] or 'Translation' in lines[0]):
        lines = lines[1:]
    return chr(10).join(lines)


def looks_like_lyric(text, min_lines=6):
    """가사처럼 보이는가 — **짧은 줄이 잇달아** 나오는가.

    ⚠ 크레딧·타임스탬프·광고를 거른다(실측 설명문에서 그것에 속았다).
    """
    lines = [x.strip() for x in str(text or '').splitlines() if x.strip()]
    if len(lines) < min_lines:
        return False
    short = [x for x in lines if len(x) <= 48]
    url = sum(1 for x in lines if 'http' in x.lower())
    return len(short) >= len(lines) * 0.75 and url <= 1


def put_lyric(rend_id, lang, body, src_kind='WEB', src_url='', song_id=None,
              media_id=None):
    """가사를 담는다(판 하나에 언어마다 하나) → lyric_id.

    ⚠ **로컬 파일에만** 담는다 — 배포 DB 에 안 간다(selftest 가 잰다).
    ⚠ 이미 있으면 **덮는다** — 더 나은 것을 받았을 때 갈아 끼운다.
    """
    lc = _db()
    try:
        cur = lc.execute(
            'INSERT INTO lyric(rend_id, song_id, lang_code, body, src_kind,'
            '  src_url, media_id) VALUES(?,?,?,?,?,?,?)'
            ' ON CONFLICT(rend_id, lang_code) DO UPDATE SET'
            '  body=excluded.body, src_kind=excluded.src_kind,'
            "  src_url=excluded.src_url, got_at=datetime('now')",
            (rend_id, song_id, (lang or '').upper(), body, src_kind,
             src_url, media_id))
        lc.commit()
        return cur.lastrowid
    finally:
        lc.close()


def lyric_of(rend_id, lang=None):
    """담아 둔 가사 → (본문, 출처) · 없으면 (None, None)."""
    lc = _db()
    try:
        q = 'SELECT body, src_url FROM lyric WHERE rend_id=?'
        a = [int(rend_id)]
        if lang:
            q += ' AND lang_code=?'
            a.append(str(lang).upper())
        r = lc.execute(q, a).fetchone()
        return (r[0], r[1]) if r else (None, None)
    finally:
        lc.close()


# ── 자가검증 ────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0 if cond else 1] += 1
        print(('  OK   ' if cond else '  실패 ') + name
              + ('' if cond else '  ' + str(extra)))

    import appdb
    lc = _db()
    try:
        lc.execute('BEGIN')
        t('★ 표를 만든다(멱등)', True)
        lc.execute('INSERT INTO caption_probe(media_id, has_caption)'
                   ' VALUES(-1, 1)')
        lc.execute('INSERT INTO caption_probe(media_id, has_caption)'
                   ' VALUES(-1, 0) ON CONFLICT(media_id)'
                   ' DO UPDATE SET has_caption=excluded.has_caption')
        t('★★ 같은 영상을 다시 재면 **덮어쓴다**(행이 안 는다)',
          lc.execute('SELECT COUNT(*), MAX(has_caption) FROM caption_probe'
                     ' WHERE media_id=-1').fetchone() == (1, 0))
        lc.execute("INSERT INTO lyric(rend_id, lang_code, body, src_kind)"
                   " VALUES(-1,'KO','한 줄','CAPTION')")
        dup = False
        try:
            lc.execute("INSERT INTO lyric(rend_id, lang_code, body)"
                       " VALUES(-1,'KO','다른 줄')")
        except Exception:
            dup = True
        t('★★★ **판 하나에 가사 하나**(같은 언어로 두 벌이 안 들어간다)', dup)
        t('★ 다른 언어는 따로 담긴다',
          bool(lc.execute("INSERT INTO lyric(rend_id, lang_code, body)"
                          " VALUES(-1,'EN','one line')")))
    finally:
        lc.rollback()
        lc.close()

    # ⚠⚠ **배포 DB 에 표를 만들지 않는다**
    c = appdb.connect(appdb.MAIN_DB)
    try:
        n = c.execute("SELECT COUNT(*) FROM main.sqlite_master"
                      " WHERE name IN ('lyric','caption_probe')").fetchone()[0]
        t('★★★ **배포 DB(main)에 가사 표가 없다**(저작물이라 배포 안 한다)',
          n == 0, n)
        n2 = c.execute("SELECT COUNT(*) FROM userdb.sqlite_master"
                       " WHERE name IN ('lyric','caption_probe')").fetchone()[0]
        t('★★ 개인 DB 에도 안 만든다(그 파일도 나가지 않지만 자리가 아니다)',
          n2 == 0, n2)
    finally:
        c.close()
    t('★ 가사 파일이 앱 폴더의 딴 이름이다',
      os.path.basename(DB) == 'lyrics_work.db')
    try:
        import db_pack_catalog as PC
        t('★★ 팩 분류표에 **안 올린다**(배포 대상이 아니다)',
          'lyric' not in getattr(PC, 'TABLES', {})
          and 'caption_probe' not in getattr(PC, 'TABLES', {}))
    except Exception as e:
        t('★★ 팩 분류표 확인', False, str(e)[:60])
    import ast as _ast
    _tree = _ast.parse(io.open(__file__, encoding='utf-8').read())
    _imp = set()
    for _nd in _ast.walk(_tree):
        if isinstance(_nd, _ast.Import):
            _imp |= {al.name.split('.')[0] for al in _nd.names}
        elif isinstance(_nd, _ast.ImportFrom) and _nd.module:
            _imp.add(_nd.module.split('.')[0])
    t('★ 위젯 꾸러미를 안 부른다 — **데이터 층**이다',
      not (_imp & {'tk' + 'inter', 'ttk'}), sorted(_imp))
    print('db_lyric_collect selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


def main():
    import appdb
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(appdb.MAIN_DB)
    try:
        if '--probe' in sys.argv:
            lim = None
            if '--limit' in sys.argv:
                lim = int(sys.argv[sys.argv.index('--limit') + 1])
            probe(conn, limit=lim)
            status(conn)
            return
        status(conn)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
