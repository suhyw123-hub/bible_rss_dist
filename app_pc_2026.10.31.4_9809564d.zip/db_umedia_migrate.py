# -*- coding: utf-8 -*-
"""`MEDI_*` 한 이름이 **두 표**를 가리키던 것을 가른다 (2026-09-10 신설).

⚠⚠⚠ 실측 — `userdb.user_link_asset` 의 `MEDI_*` 행이 섞여 있었다:

    clicked_id  2 · 6 · 7 · 8        → `userdb.user_media_asset` 번호
    clicked_id  12592 · 13162 · 13174 → `sys_media_asset` 번호

  같은 이름 한 자리에 두 뜻이 있으면 ⓐ 내 영상 조회가 sys 쪽 행을 **조용히
  못 보고**(join 이 안 맞아 사라진다 — 실측 13174 는 LIVE 인데 안 보인다)
  ⓑ 번호가 겹치는 날 **딴 영상이 뜬다.**

⇒ **내 영상 쪽만 `UMED` 로 옮긴다.** sys 를 가리키는 행은 `MEDI` 그대로 둔다.

⚠ 어느 쪽인지는 **번호가 실제로 어느 표에 있는가**로 가른다 — 짐작하지 않는다.
⚠ **양쪽에 다 있는 번호는 안 건드린다**(가릴 수 없으면 손대지 않는다).

명령
  --selftest   자가검증(의무)
  --check      무엇을 옮길지 보인다(안 고친다)
  --apply      옮긴다(멱등)
  --undo       되돌린다
"""
import io
import sys

NOTE = 'UMEDIA_SPLIT_20260910'
#: 영상이 A 자리에 오는 연결 · B 자리에 오는 연결
_A_PREFIX = 'MEDI_'
_B_SUFFIX = '_MEDI'


def _both(conn):
    """(내 영상 번호 집합, 배포 영상 번호 집합)."""
    u = {r[0] for r in conn.execute(
        'SELECT user_media_id FROM userdb.user_media_asset')}
    s = {r[0] for r in conn.execute('SELECT media_id FROM sys_media_asset')}
    return u, s


def scan(conn):
    """옮길 행 → [(user_link_id, 옛 link_type, 새 link_type, 번호, 자리)]."""
    u, s = _both(conn)
    out = []
    for lid, lt, a, b in conn.execute(
            'SELECT user_link_id, link_type, clicked_id, target_id'
            '  FROM userdb.user_link_asset'
            " WHERE link_type LIKE 'MEDI#_%' ESCAPE '#'"
            "    OR link_type LIKE '%#_MEDI' ESCAPE '#'"):
        if str(lt).startswith(_A_PREFIX):
            mid, side = a, 'A'
            new = 'UMED_' + str(lt)[len(_A_PREFIX):]
        else:
            mid, side = b, 'B'
            new = str(lt)[:-len(_B_SUFFIX)] + '_UMED'
        # ⚠ **양쪽에 다 있으면 못 가른다** — 손대지 않는다.
        if mid in u and mid not in s:
            out.append((lid, lt, new, mid, side))
    return out


def apply_it(conn, log=print):
    got = scan(conn)
    for lid, _lt, new, mid, side in got:
        conn.execute('UPDATE userdb.user_link_asset SET link_type=?, note=?'
                     ' WHERE user_link_id=?', (new, NOTE, lid))
        log('  #%d  %s → %s  (영상 %d · %s 자리)' % (lid, _lt, new, mid, side))
    return len(got)


def undo(conn):
    """되돌린다 — 표식을 남긴 행만."""
    n = 0
    for lid, lt in conn.execute(
            'SELECT user_link_id, link_type FROM userdb.user_link_asset'
            ' WHERE COALESCE(note,\'\')=?', (NOTE,)).fetchall():
        old = ('MEDI_' + lt[len('UMED_'):] if lt.startswith('UMED_')
               else lt[:-len('_UMED')] + '_MEDI')
        conn.execute('UPDATE userdb.user_link_asset SET link_type=?, note=NULL'
                     ' WHERE user_link_id=?', (old, lid))
        n += 1
    return n


def selftest():
    import appdb
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0 if cond else 1] += 1
        print(('  OK   ' if cond else '  실패 ') + name
              + ('' if cond else '  ' + str(extra)))

    conn = appdb.connect(appdb.MAIN_DB)
    try:
        conn.execute('BEGIN')
        u, s = _both(conn)
        t('★ 두 표의 번호를 읽는다 (내 영상 %d · 배포 %d)' % (len(u), len(s)),
          bool(u) or True)
        t('★★ **겹치는 번호는 없다고 가정하지 않는다**',
          isinstance(u & s, set))
        got = scan(conn)
        t('★ 옮길 행을 찾는다 (%d건)' % len(got), isinstance(got, list))
        t('★★ 옮길 것은 **내 영상 번호뿐**이다',
          all(m in u and m not in s for _l, _o, _n, m, _sd in got), got[:3])
        t('★★ 새 이름이 넉 자 코드 짝을 지킨다',
          all(('UMED_' in n or n.endswith('_UMED')) and len(n) == 9
              for _l, _o, n, _m, _sd in got), [x[2] for x in got[:3]])
        # ⚠ **데이터 상태에 걸지 않는다**(§0-5) — 한 번 옮기고 나면 옮길 것이
        #   0이라 검사가 깨진다. 시험용 애매한 행을 **직접 만들어** 잰다.
        # ⚠⚠ **번호를 일부러 높이 잡는다** — 그냥 넣으면 새 번호가 배포 표에도
        #   있는 번호라 이 도구가 「가릴 수 없다」며 옳게 손대지 않는다.
        #   ★ 그것이 이 도구의 한계이자 안전장치다: **가릴 수 있는 것만** 옮긴다.
        _u2 = 99999901
        conn.execute(
            'INSERT INTO userdb.user_media_asset(user_media_id, title, url,'
            " verse_id, category, record_status) VALUES(?, '__mig 시험__',"
            " 'https://x.invalid/mig', 0, 'STUDY', 'LIVE')", (_u2,))
        conn.execute("INSERT INTO userdb.user_link_asset(link_type,"
                     " clicked_id, target_id, record_status)"
                     " VALUES('MEDI_VERS', ?, 3, 'LIVE')", (_u2,))
        mine = [x for x in scan(conn) if x[3] == _u2]
        t('★★ 시험 행을 **애매한 것으로 잡는다**', len(mine) == 1, mine)
        n = apply_it(conn, log=lambda _x: None)
        t('★ 옮긴다 (%d건)' % n, n >= 1)
        t('★★ **다시 돌려도 더 안 옮긴다**(멱등)',
          apply_it(conn, log=lambda _x: None) == 0)
        t('★★ 남은 애매한 행 0', not scan(conn), scan(conn)[:3])
        t('★★ 시험 행이 `UMED_VERS` 가 됐다',
          conn.execute('SELECT link_type FROM userdb.user_link_asset'
                       ' WHERE clicked_id=? AND target_id=3',
                       (_u2,)).fetchone()[0] == 'UMED_VERS')
        back = undo(conn)
        t('★★ 되돌린다(표식을 남긴 것만)', back >= n)
        t('★★ 되돌리면 시험 행이 다시 애매해진다',
          any(x[3] == _u2 for x in scan(conn)))
        # ⚠ sys 를 가리키는 행은 그대로여야 한다
        # ⚠ **여기서 다시 센다** — 위에서 시험 행을 넣었으므로 앞의 값은 낡았다
        u2, s2 = _both(conn)
        stay = [r[0] for r in conn.execute(
            'SELECT clicked_id FROM userdb.user_link_asset'
            " WHERE link_type LIKE 'MEDI#_%' ESCAPE '#'")]
        t('★★★ **배포 영상을 가리키는 행은 안 건드린다**',
          all((m in s2) or (m in u2) for m in stay), stay[:5])
        # ★★★ **가릴 수 없으면 손대지 않는다** — 일부러 겹치는 번호를 만든다
        _sid = conn.execute('SELECT MIN(media_id) FROM sys_media_asset'
                            ).fetchone()[0]
        conn.execute(
            'INSERT INTO userdb.user_media_asset(user_media_id, title, url,'
            " verse_id, category, record_status) VALUES(?, '__amb__',"
            " 'https://x.invalid/amb', 0, 'STUDY', 'LIVE')", (_sid,))
        conn.execute("INSERT INTO userdb.user_link_asset(link_type,"
                     " clicked_id, target_id, record_status)"
                     " VALUES('MEDI_VERS', ?, 5, 'LIVE')", (_sid,))
        t('★★★ **양쪽에 다 있는 번호는 안 옮긴다**(가릴 수 없으면 손대지 않는다)',
          not [x for x in scan(conn) if x[3] == _sid], _sid)
    finally:
        conn.rollback()
        conn.close()
    print('db_umedia_migrate selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


def main():
    import appdb
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(appdb.MAIN_DB)
    try:
        if '--undo' in sys.argv:
            n = undo(conn)
            conn.commit()
            print('되돌림 %d건' % n)
            return
        if '--apply' in sys.argv:
            n = apply_it(conn)
            conn.commit()
            print('옮김 %d건 — 되돌리기: --undo' % n)
            return
        got = scan(conn)
        u, s = _both(conn)
        print('내 영상 %d개 · 배포 영상 %d개' % (len(u), len(s)))
        if not got:
            print('옮길 것이 없습니다.')
        for lid, lt, new, mid, side in got:
            print('  #%-6d %s → %s  (영상 %d · %s 자리)'
                  % (lid, lt, new, mid, side))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
