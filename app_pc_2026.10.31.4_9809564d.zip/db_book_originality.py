# -*- coding: utf-8 -*-
"""db_book_originality.py — 담긴 본문이 **진짜 그 저자의 글인가** 전권 점검
================================================================================
`python db_book_originality.py --selftest`      — 의무
`python db_book_originality.py --links [CODE…]` — **받기 전에** 주소를 보인다
`python db_book_originality.py --check [CODE…] --links-confirmed`
                                                 — 받아서 문장 대조

★ 규칙 ⓪(§0-1b) — 받기 전에 링크를 보인다. `--links-confirmed` 없이는 받지
  않는다. `db_book_source_match.require_ack()` 가 막는다.

★ 후보 주소는 **DB 의 `source_url` 에서 기계로 만든다**(`db_book_source_match.
  _cands` 와 같은 방식 + 미러). 손으로 적으면 또 어긋난다.
⚠ 구텐베르크 미러 파일 이름은 책마다 다르다 — `1234-0.txt` · `1234-8.txt` ·
  `1234.txt` 를 차례로 두드린다(실측: 로렌스 `-0`, 뮐러 `-8`).
⚠ **한 파일로 안 받아지는 곳**이 있다(spurgeon.org · gospeltruth.net ·
  archive.spurgeon.org — 편마다 페이지가 따로다). 그런 책은 `단일파일없음`
  으로 표시하고 **표본 대조는 사람이 판단**한다. 조용히 통과시키지 않는다.
"""
import io
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
import db_book_verify as V
import db_book_source_match as SM

DB = 'bible_master.db'
RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_verify_raw')
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/125.0 Safari/537.36')
GENUINE, PARTIAL = 0.85, 0.15

# 여러 저작이 한 파일에 든 곳 — 그 파일과 대조하면 된다.
SHARED = {
    'CLEMENT_1ST': 'lightfoot/fathers', 'DIDACHE': 'lightfoot/fathers',
    'DIOGNETUS': 'lightfoot/fathers', 'HERMAS_SHEPHERD': 'lightfoot/fathers',
    'IGNATIUS_LETTERS': 'lightfoot/fathers', 'POLYCARP_PHIL': 'lightfoot/fathers',
}


def candidates(url, code=None):
    """`source_url` → 내려받을 수 있는 글 파일 주소 후보."""
    out = []
    u = (url or '').strip()
    m = re.search(r'gutenberg\.org/(?:ebooks|files|cache/epub)/(\d+)', u)
    if m:
        n = m.group(1)
        pre = '/'.join(n[:-1]) if len(n) > 1 else '0'
        out += ['http://aleph.gutenberg.org/%s/%s/%s-0.txt' % (pre, n, n),
                'http://aleph.gutenberg.org/%s/%s/%s-8.txt' % (pre, n, n),
                'http://aleph.gutenberg.org/%s/%s/%s.txt' % (pre, n, n),
                'https://www.gutenberg.org/cache/epub/%s/pg%s.txt' % (n, n)]
    w = SHARED.get(code or '')
    if not w:
        m = re.search(r'ccel\.org/ccel/([a-z_]+)/([a-z0-9_]+)', u)
        if m:
            w = '%s/%s' % (m.group(1), m.group(2))
    if w:
        a, ww = w.split('/')
        out += ['https://ccel.org/ccel/%s/%s/cache/%s.txt' % (a, ww, ww)]
    m = re.search(r'archive\.org/details/([^/\s]+)', u)
    if m:
        i = m.group(1)
        out += ['https://archive.org/download/%s/%s_djvu.txt' % (i, i)]
    return out


def fetch(code, urls):
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    for i, u in enumerate(urls):
        p = os.path.join(RAW, 'ORIG_%s_%d.txt' % (code, i))
        if os.path.exists(p) and os.path.getsize(p) > 20000:
            return u, p
        subprocess.run(['curl', '-sL', '--max-time', '300', '-A', UA,
                        '-o', p, u], capture_output=True)
        if not os.path.exists(p) or os.path.getsize(p) < 20000:
            continue
        head = io.open(p, encoding='utf-8', errors='replace').read(300)
        if '<html' in head.lower() or '503 Serv' in head:
            continue
        return u, p
    return None, None


def check_one(conn, code, url):
    cands = candidates(url, code)
    if not cands:
        return dict(code=code, verdict='단일파일없음', url=url, ratio=None,
                    got=None, note='그 곳은 편마다 페이지가 따로다')
    got_url, p = fetch(code, cands)
    if not p:
        return dict(code=code, verdict='못받음', url=url, ratio=None,
                    got=None, note='후보 %d개 모두 실패' % len(cands))
    n, h, r, rows = SM.match_book(conn, code, p)
    low = [x['seq'] for x in rows if x['verdict'] != '진본']
    return dict(code=code, verdict=('진본' if r >= GENUINE else
                                    '일부' if r >= PARTIAL else '위작의심'),
                url=url, got=got_url, ratio=r, n=n, hit=h, low=low)


def all_books(conn):
    return conn.execute("""SELECT book_code, source_url FROM sys_book_asset
             WHERE COALESCE(record_status,'LIVE')='LIVE'
             ORDER BY book_code""").fetchall()


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    c = candidates('https://www.gutenberg.org/ebooks/25891')
    ck('구텐베르크 미러 세 이름',
       any('25891-0.txt' in x for x in c) and any('25891-8.txt' in x for x in c)
       and any('/25891.txt' in x for x in c), len(c))
    ck('자릿수 나누기', any('/2/5/8/9/25891/' in x for x in c), c[0])
    c = candidates('https://www.gutenberg.org/ebooks/654')
    ck('세 자리도', any('/6/5/654/654-0.txt' in x for x in c), c[0])
    c = candidates('https://www.ccel.org/ccel/edersheim/sketches.html')
    ck('CCEL 후보',
       any('edersheim/sketches/cache/sketches.txt' in x for x in c), c)
    c = candidates('https://www.ccel.org/ccel/lightfoot/fathers.html',
                   'DIDACHE')
    ck('한 파일에 든 저작',
       any('lightfoot/fathers/cache/fathers.txt' in x for x in c), c)
    c = candidates('https://archive.org/details/abideinchristtho00murr_0')
    ck('IA 후보', any('_djvu.txt' in x for x in c), c)
    ck('한 파일로 못 받는 곳은 후보 0',
       candidates('https://www.spurgeon.org/resource-library/sermons/') == [])

    conn = appdb.connect(DB)
    codes = {c for c, _ in all_books(conn)}
    ck('35권을 센다', len(codes) == 35, len(codes))
    # ⚠ 밑줄 없는 코드가 인자 거르기에서 빠지면 안 된다
    ck('밑줄 없는 코드도 있다', 'DIDACHE' in codes and 'DIOGNETUS' in codes)
    conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    conn = appdb.connect(DB)
    every = all_books(conn)
    # ⚠ 「대문자에 밑줄」로 거르면 `DIDACHE`·`DIOGNETUS` 가 빠진다(실측).
    #   **실제 책 코드인지**로 가른다.
    known = {c for c, _ in every}
    only = [x for x in a if x in known]
    books = [(c, u) for c, u in every if not only or c in only]

    if '--links' in a:
        for code, url in books:
            cands = candidates(url, code)
            print('%-18s %s' % (code, url or '(주소 없음)'))
            if not cands:
                print('     (한 파일로 못 받는 곳 — 편마다 페이지가 따로다)')
            for u in cands:
                print('     %s' % u)
        conn.close()
        return

    if '--check' in a:
        SM.require_ack('전권', [(c, u) for c, u in books], argv=a)
        print('%-18s %-10s %14s  %s' % ('code', '판정', '문장', '받은 곳'))
        rows = []
        for code, url in books:
            r = check_one(conn, code, url)
            rows.append(r)
            frac = ('%d/%d = %3.0f%%' % (r['hit'], r['n'], r['ratio'] * 100)
                    if r.get('ratio') is not None else '-')
            mark = {'진본': '  ', '일부': '✗ ', '위작의심': '✗✗',
                    '못받음': '? ', '단일파일없음': '· '}[r['verdict']]
            print('%s%-18s %-10s %14s  %s'
                  % (mark, code, r['verdict'], frac,
                     (r.get('got') or r.get('note') or '')[:52]))
        conn.close()
        bad = [r for r in rows if r['verdict'] in ('일부', '위작의심')]
        todo = [r for r in rows if r['verdict'] in ('못받음', '단일파일없음')]
        print()
        print('%d권 · 진본 %d · 손봐야 할 것 %d · 사람이 볼 것 %d'
              % (len(rows), sum(1 for r in rows if r['verdict'] == '진본'),
                 len(bad), len(todo)))
        raise SystemExit(1 if bad else 0)
    conn.close()
    print(__doc__)


if __name__ == '__main__':
    main()
