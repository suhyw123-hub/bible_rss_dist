# -*- coding: utf-8 -*-
"""홈페이지 잡지 「이렇게 읽습니다」 — 기능을 실제 콘텐츠로 써 보이는 7쪽 (영구 · `--selftest`).

★ 관리자 화면이 없다(2026-10-15 사용자 판단 — 「주기적으로 업데이트하지 않으면 굳이 관리자
  화면이 필요한가」). 그 대신 이 스크립트 하나:
  · **앱 화면 틀 안의 글은 DB 에서 그때 읽는다** — DB 를 고치면 다시 만들 때 따라온다.
  · **바깥 글(제목·설명·사용법·예시)은 `site_magazine_<언어>.json`** — 사람이 고친다.
    그 파일이 있는 언어만 잡지를 만든다(지어낸 번역을 안 싣는다).
  · AI 답은 `site_magazine_ai.json`(실제로 한 번 받은 답 · `--capture-ai` 로 다시).
  · 유튜브 썸네일은 **미리 받아 우리 자산으로**(`--fetch` → site_assets/mag) — 방문자 브라우저가
    구글에 닿지 않는다(홈페이지 「추적 없음」).
⚠ 사용자가 쓰는 글(노트·메모)은 진짜가 없다 — 견본이고 화면에 「예시」를 붙인다.
⚠ 앱 화면이 바뀌면 그 틀(`_s_*`)만 고친다.

쓰는 법: `--preview 파일`(썸네일을 data: 로 품은 한 파일) · `--fetch` · `--capture-ai` · `--selftest`.
홈페이지 빌드(`site_gen.build`)가 `build_into` 를 부른다.
"""
import base64
import html
import json
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
import appdb  # noqa: E402

MAG_DIR = os.path.join(HERE, 'site_assets', 'mag')
AI_FILE = os.path.join(HERE, 'site_magazine_ai.json')
PAGE = 'magazine.html'

# 이야기마다 무엇을 보이나 — 열쇠 하나(관리자가 고르던 자리를 여기 한 줄로)
PICK = {
    'verse': {'bcode': 1, 'ch': 3, 'v': 15},
    'plan': {'plan_id': 119, 'day': 2},
    'lens': {'name': '희생제사와 피', 'step': 1},
    'book': {'code': 'SPURGEON_ME', 'seq': 1},
    'video': {'bcode': 1, 'ch': 3, 'v': 15, 'max': 12},
}
REL_KO = {'PRG': '흐름', 'COV': '언약', 'TYP': '모형', 'INC': '그리스도 성취', 'FUL': '성취',
          'REV': '역전', 'DEP': '깊어짐', 'ALL': '반향', 'PAR': '평행', 'REF': '인용', 'SUP': '뒷받침', 'SYN': '같은 뜻'}


def _e(s):
    return html.escape(s or '', quote=True)


def copy_of(lang):
    p = os.path.join(HERE, 'site_magazine_%s.json' % lang.lower())
    if not os.path.exists(p):
        return None
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def langs_ready():
    return [lg for lg in ('KO', 'EN', 'JA', 'ZH', 'ZHT', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR') if copy_of(lg)]


# ── DB 에서 읽기 ────────────────────────────────────────────────
def _vid(c, b, ch, v):
    r = c.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?', (b, ch, v)).fetchone()
    return r and r[0]


def _txt(c, vid, ver='KRV'):
    r = c.execute('SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?', (vid, ver)).fetchone()
    return (r and r[0]) or ''


def _ref(c, vid, lang='KO'):
    b, ch, v = c.execute('SELECT bcode,chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
    n = c.execute('SELECT short_name FROM book_names WHERE book_code=? AND lang_code=?', (b, lang)).fetchone()
    return '%s %d:%d' % (n[0] if n else b, ch, v)


def _ta(c, cid, tt, lang='KO', variant=None):
    q = 'SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=? AND lang_code=?'
    a = [cid, tt, lang]
    if variant:
        q += ' AND text_variant=?'
        a.append(variant)
    r = c.execute(q + ' ORDER BY text_variant IS NULL', a).fetchone()
    return (r and r[0]) or ''


def stats(c):
    q = lambda s: c.execute(s).fetchone()[0]  # noqa: E731
    import site_gen
    st = dict(site_gen.stats(c))
    st['links'] = q("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='VERS_VERS' AND COALESCE(record_status,'LIVE')='LIVE'")
    return st


def d_verse(c, lang):
    p = PICK['verse']
    v = _vid(c, p['bcode'], p['ch'], p['v'])
    links = []
    for lid, a, b, rel in c.execute(
            "SELECT sys_link_id,clicked_id,target_id,rel_code FROM sys_link_asset WHERE link_type='VERS_VERS' "
            "AND (clicked_id=? OR target_id=?) AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY target_id", (v, v)):
        o = b if a == v else a
        links.append({'ref': _ref(c, o, lang), 'rel': rel, 'text': _txt(c, o), 'desc': _ta(c, lid, 'VERS_VERS_DESC', lang)})
    comm = [r[0] for r in c.execute(
        "SELECT DISTINCT COALESCE(s.title,s.commentary_code) FROM sys_commentary_entry e JOIN sys_commentary_source s "
        "ON s.commentary_id=e.commentary_id WHERE e.start_vid=? OR (e.start_vid<=? AND e.end_vid>=?)", (v, v, v))]
    media = c.execute("SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l JOIN sys_media_asset m ON m.media_id=l.clicked_id "
                      "WHERE l.link_type LIKE 'MEDI_VERS%' AND l.target_id=? AND m.is_active=1 "
                      "AND COALESCE(l.record_status,'LIVE')='LIVE'", (v,)).fetchone()[0]
    return {'ref': _ref(c, v, lang), 'krv': _txt(c, v), 'bsb': _txt(c, v, 'BSB'),
            'lay': _ta(c, v, 'VERS_DESC', lang, 'LAY'), 'q': _ta(c, v, 'VERS_QUESTION', lang, 'LAY'),
            'pr': _ta(c, v, 'VERS_PRAYER', lang), 'links': links, 'comm': comm, 'media': media}


def d_plan(c, lang):
    p = PICK['plan']
    rows = c.execute('SELECT schedule_id,start_vid,end_vid,stage_type FROM sys_plan_schedule WHERE plan_id=? AND day=? '
                     'ORDER BY sort_order', (p['plan_id'], p['day'])).fetchall()
    days = c.execute('SELECT MAX(day) FROM sys_plan_schedule WHERE plan_id=?', (p['plan_id'],)).fetchone()[0]
    items = []
    for sid, a, b, st in rows:
        ra, rb = _ref(c, a, lang), _ref(c, b, lang)
        rng = ra if a == b else (ra + '~' + rb.split(':')[1] if ra.split(':')[0] == rb.split(':')[0] else ra + '~' + rb)
        items.append({'ref': rng, 'stage': st, 'focus': _ta(c, sid, 'PLAN_FOCUS', lang), 'text': _txt(c, a)})
    return {'title': _ta(c, p['plan_id'], 'PLAN_TITLE', lang), 'day': p['day'], 'days': days, 'items': items}


def d_lens(c, lang):
    p = PICK['lens']
    cid = c.execute("SELECT sys_unit_id FROM sys_unit_asset WHERE unit_type='CONTAINER' AND unit_name_sid=?", (p['name'],)).fetchone()[0]
    nodes = c.execute("SELECT u.sys_unit_id,u.unit_name_sid FROM sys_link_asset l JOIN sys_unit_asset u ON u.sys_unit_id=l.target_id "
                      "WHERE l.link_type='CONT_NODE' AND l.clicked_id=? AND COALESCE(l.record_status,'LIVE')='LIVE' "
                      "ORDER BY l.sys_link_id", (cid,)).fetchall()
    nid, nname = nodes[p['step'] - 1]
    vs = []
    for a, e in c.execute("SELECT target_id,end_id FROM sys_link_asset WHERE link_type='NODE_VERS' AND clicked_id=? "
                          "AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order,sys_link_id", (nid,)):
        vs.append({'ref': _ref(c, a, lang) + (('~' + _ref(c, e, lang).split(':')[1]) if e else ''), 'text': _txt(c, a)})
    return {'name': p['name'], 'steps': [n[1] for n in nodes], 'step': p['step'], 'node': nname,
            'desc': _ta(c, nid, 'NODE_DESC', lang), 'q': _ta(c, nid, 'NODE_QUESTION', lang), 'verses': vs}


def d_book(c, lang):
    p = PICK['book']
    bid = c.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?', (p['code'],)).fetchone()[0]
    uid, = c.execute('SELECT unit_id FROM sys_book_unit WHERE book_id=? ORDER BY sequence LIMIT 1 OFFSET ?', (bid, p['seq'] - 1)).fetchone()
    n = c.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?', (bid,)).fetchone()[0]
    t = c.execute('SELECT title,author FROM sys_book_asset_text WHERE book_id=? AND lang_code=?', (bid, lang)).fetchone() or ('', '')
    body = c.execute("SELECT body_text FROM sys_book_unit_text WHERE unit_id=? AND lang_code=? AND text_variant='TRANSLATED'",
                     (uid, lang)).fetchone()
    en = c.execute("SELECT body_text FROM sys_book_unit_text WHERE unit_id=? AND lang_code='EN' AND text_variant='ORIGINAL'",
                   (uid,)).fetchone()
    return {'title': t[0], 'author': t[1], 'seq': p['seq'], 'n': n, 'body': (body and body[0]) or '', 'en': (en and en[0]) or ''}


def d_study(c, lang, ex):
    import scripture_ref as SR
    rows = SR.find(c, ex or '', lang)
    keep = SR.linkable(rows)
    return {'chips': [r[2] for r in keep], 'skipped': [r[2] for r in rows if r not in keep]}


def d_video(c, lang):
    """그 절의 영상 — ★ 사람이 골라 내세우지 않는다(사용자 「특정한 컨텐츠를 제시하는 것은 부적절」).
    규칙 하나로 거른다: **제목이 맨 먼저 가리키는 구절이 그 절을 덮는 영상만**(제목에 구절이 없거나
    다른 책이 먼저 나오면 뺀다 — 계시록 강의가 창 3:15 를 지나가며 언급한 것 따위). 차례 = 사용자 언어 먼저 · 최신."""
    import scripture_ref as SR
    p = PICK['video']
    v = _vid(c, p['bcode'], p['ch'], p['v'])
    rows = c.execute("SELECT m.media_id,m.media_type,m.title,m.description,m.url,m.lang_code FROM sys_link_asset l "
                     "JOIN sys_media_asset m ON m.media_id=l.clicked_id WHERE l.link_type LIKE 'MEDI_VERS%' AND l.target_id=? "
                     "AND m.is_active=1 AND COALESCE(l.record_status,'LIVE')='LIVE'", (v,)).fetchall()
    out, seen = [], set()
    for mid, mt, title, desc, url, lg in rows:
        yid = (url or '').split('v=')[-1][:11]
        if not yid or title in seen:
            continue
        refs = []
        for L in (lg, lang, 'KO', 'EN'):
            refs = SR.find(c, title or '', L) if L else []
            if refs:
                break
        if not refs or not (refs[0][0] <= v <= (refs[0][1] or refs[0][0])):
            continue
        seen.add(title)
        try:
            meta = json.loads(desc or '{}')
        except Exception:                                  # noqa: BLE001
            meta = {}
        out.append({'yid': yid, 'title': title, 'channel': meta.get('channel', ''), 'kind': mt, 'lang': lg,
                    'date': meta.get('published', '')})
    out.sort(key=lambda x: (x['lang'] != lang, x['date']), reverse=False)
    out.sort(key=lambda x: x['date'], reverse=True)
    out.sort(key=lambda x: x['lang'] != lang)
    return {'ref': _ref(c, v, lang), 'items': out[:p['max']]}


def ai_capture():
    with open(AI_FILE, encoding='utf-8') as f:
        return json.load(f)


# ── 썸네일 ───────────────────────────────────────────────────────
def fetch_thumbs(items):
    os.makedirs(MAG_DIR, exist_ok=True)
    got = 0
    for it in items:
        p = os.path.join(MAG_DIR, it['yid'] + '.jpg')
        if os.path.exists(p):
            continue
        try:
            with urllib.request.urlopen('https://i.ytimg.com/vi/%s/mqdefault.jpg' % it['yid'], timeout=15) as r:
                data = r.read()
            with open(p, 'wb') as f:
                f.write(data)
            got += 1
        except Exception as ex:                            # noqa: BLE001
            print('썸네일 못 받음', it['yid'], ex)
    return got


def _thumb_src(yid, inline, prefix):
    p = os.path.join(MAG_DIR, yid + '.jpg')
    if not os.path.exists(p):
        return ''
    if inline:
        with open(p, 'rb') as f:
            return 'data:image/jpeg;base64,' + base64.b64encode(f.read()).decode()
    return prefix + 'mag/' + yid + '.jpg'


# ── 그리기 ───────────────────────────────────────────────────────
CSS = """
:root{--bg:#f6f1e7;--panel:#fffdf8;--ink:#2b2a27;--dim:#6b665c;--accent:#7a4e2d;--line:#e2d8c6;
--app-bg:#eef0f2;--app-panel:#fff;--app-ink:#22262b;--app-dim:#66707a;--app-tab:#5d6d7e;--app-tabfg:#fff;--app-line:#d5dade;--app-chip:#e6ebf0;--app-acc:#1a5276;--hl:#fde7b0;--memo:#8a5a12;
--serif:"Noto Serif KR","Batang","바탕",Georgia,serif;--sans:"Noto Sans KR","Malgun Gothic","맑은 고딕",system-ui,sans-serif}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#1b1916;--panel:#25221e;--ink:#ece6d9;--dim:#b4ab99;--accent:#d8a874;--line:#3a352e;
--app-bg:#1d2126;--app-panel:#262b31;--app-ink:#e6e9ec;--app-dim:#9aa4ae;--app-tab:#7d8fa1;--app-tabfg:#101316;--app-line:#39414a;--app-chip:#323a43;--app-acc:#8cb8d8;--hl:#5c4a1c;--memo:#e6c27a;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#1b1916;--panel:#25221e;--ink:#ece6d9;--dim:#b4ab99;--accent:#d8a874;--line:#3a352e;
--app-bg:#1d2126;--app-panel:#262b31;--app-ink:#e6e9ec;--app-dim:#9aa4ae;--app-tab:#7d8fa1;--app-tabfg:#101316;--app-line:#39414a;--app-chip:#323a43;--app-acc:#8cb8d8;--hl:#5c4a1c;--memo:#e6c27a;color-scheme:dark}
body{background:var(--bg);color:var(--ink);font-family:var(--serif);line-height:1.75;margin:0}
.wrap{max-width:1080px;margin:0 auto;padding-inline:20px;padding-block:28px 64px}
.mast{display:flex;flex-wrap:wrap;align-items:baseline;justify-content:space-between;gap:8px 24px;border-bottom:2px solid var(--ink);padding-bottom:10px}
.mast h1{font-size:clamp(28px,5vw,44px);margin:0;font-weight:800}.mast .issue{font-family:var(--sans);font-size:13px;color:var(--dim);letter-spacing:.06em}
.lede{max-width:66ch;font-size:17px;margin:18px 0 6px}
.stats{display:flex;flex-wrap:wrap;gap:8px 22px;font-family:var(--sans);font-size:13px;color:var(--dim)}
.stats b{color:var(--ink);font-variant-numeric:tabular-nums;font-size:16px}
.toc{display:flex;flex-wrap:wrap;gap:6px 18px;font-family:var(--sans);font-size:14px;margin:14px 0 30px;counter-reset:t}
.toc a{color:var(--accent);text-decoration:none;border-bottom:1px solid var(--line)}
a:focus-visible,.tab:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.story{display:grid;grid-template-columns:minmax(0,5fr) minmax(0,6fr);gap:28px;padding-block:34px;border-top:1px solid var(--line)}
.story:nth-of-type(even) .copy{order:2}
@media (max-width:820px){.story{grid-template-columns:minmax(0,1fr)}.story:nth-of-type(even) .copy{order:0}}
.kicker{font-family:var(--sans);font-size:12px;letter-spacing:.12em;color:var(--accent);font-weight:700}
.story h2{font-size:clamp(22px,3.4vw,30px);line-height:1.35;margin:6px 0 12px;text-wrap:balance}
.copy p{margin:0 0 12px;max-width:62ch}
.how{font-family:var(--sans);font-size:14px;color:var(--dim);margin-top:14px;padding-left:12px;border-left:3px solid var(--line)}
.how b{color:var(--ink)}
.app{background:var(--app-bg);color:var(--app-ink);font-family:var(--sans);font-size:14px;line-height:1.6;border:1px solid var(--app-line);border-radius:6px;overflow:hidden;min-width:0;align-self:start}
.bar{display:flex;align-items:center;gap:10px;padding:8px 12px;background:var(--app-panel);border-bottom:1px solid var(--app-line);font-size:13px}
.bar .ref{font-weight:700;color:var(--app-acc)}.bar .sp{flex:1}.mut{color:var(--app-dim);font-size:12px}
.verse{padding:12px 14px;background:var(--app-panel);border-bottom:1px solid var(--app-line)}.verse .en{color:var(--app-dim);font-size:12.5px;margin-top:4px}
.tabs{display:flex;flex-wrap:wrap;gap:2px;padding:8px 10px 0}
.tab{font:inherit;font-size:13px;border:1px solid var(--app-line);border-bottom:none;background:var(--app-chip);color:var(--app-ink);padding:5px 12px;border-radius:4px 4px 0 0;cursor:pointer}
.tab[aria-selected="true"]{background:var(--app-tab);color:var(--app-tabfg);border-color:var(--app-tab)}
.pane{background:var(--app-panel);border-top:1px solid var(--app-line);padding:12px 14px;max-height:380px;overflow:auto}
.pane p{margin:0 0 10px}.pre{white-space:pre-line}
.q{border-top:1px solid var(--app-line);padding-top:8px;margin-top:8px}
.lab{font-size:12px;color:var(--app-dim);font-weight:700}
.lk{padding:8px 0;border-bottom:1px solid var(--app-line)}.lk:last-child{border-bottom:none}
.lk .h{display:flex;flex-wrap:wrap;gap:6px;align-items:baseline}.lk .h b{color:var(--app-acc)}
.chip{font-size:11px;background:var(--app-chip);border-radius:9px;padding:1px 8px;color:var(--app-dim)}
.lk .t{color:var(--app-dim);font-size:12.5px}
.row{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:10px}
.src span{border:1px solid var(--app-line);border-radius:4px;padding:3px 10px;font-size:13px}
.day{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 12px;padding:8px 0;border-bottom:1px solid var(--app-line)}
.day .r{font-weight:700;color:var(--app-acc);white-space:nowrap}
.steps span{font-size:12px;padding:2px 8px;border-radius:3px;background:var(--app-chip);color:var(--app-dim)}
.steps span.on{background:var(--app-tab);color:var(--app-tabfg)}
.ex{display:inline-block;font-size:11px;border:1px solid var(--app-dim);color:var(--app-dim);border-radius:3px;padding:0 6px;margin-left:6px;vertical-align:1px}
.note{border:1px dashed var(--app-line);border-radius:4px;padding:8px 10px;margin-top:10px}
mark.hl{background:var(--hl);color:inherit}.memo{color:var(--memo);font-size:13px}
.sug{display:flex;flex-wrap:wrap;gap:6px 12px;align-items:center;padding:6px 10px;background:var(--app-chip);border-bottom:1px solid var(--app-line);font-size:13px}
.sug label{display:inline-flex;gap:4px;align-items:center}
mark.ref{background:var(--hl);color:inherit;border-radius:2px}
table.t{border-collapse:collapse;margin:10px 0;font-size:13px;width:100%}
table.t th,table.t td{border:1px solid var(--app-line);padding:4px 8px;text-align:left}table.t th{background:var(--app-chip)}
.tw{overflow-x:auto}
.chat{display:grid;gap:10px}.me{background:var(--app-chip);border-radius:6px;padding:8px 10px}
.ai{border-left:3px solid var(--app-acc);padding:2px 0 2px 10px}
.vids{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
.vid{display:grid;gap:4px;font:inherit;font-size:12.5px;text-align:left;color:inherit;background:none;border:0;padding:0;cursor:pointer}
.vid.on img{outline:3px solid var(--app-acc)}
.vid img{width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:4px;background:var(--app-chip)}
.vid .tt{font-weight:600;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.player{aspect-ratio:16/9;max-width:100%;background:var(--app-chip);border-radius:4px;display:grid;place-items:center;margin-bottom:10px;overflow:hidden}
.player iframe{width:100%;height:100%;border:0}
.foot{margin-top:40px;border-top:2px solid var(--ink);padding-top:14px;font-family:var(--sans);font-size:13px;color:var(--dim);display:grid;gap:6px}
"""
JS = """document.querySelectorAll('[data-tabs]').forEach(function(b){var ts=b.querySelectorAll('.tab'),ps=b.querySelectorAll('[role=tabpanel]');
ts.forEach(function(t,i){t.addEventListener('click',function(){ts.forEach(function(x,j){x.setAttribute('aria-selected',j===i?'true':'false')});
ps.forEach(function(p,j){p.hidden=j!==i})})})});
document.querySelectorAll('.vid').forEach(function(b){b.addEventListener('click',function(){var y=b.getAttribute('data-yid'),p=document.getElementById('mag-player');
document.querySelectorAll('.vid').forEach(function(x){x.classList.toggle('on',x===b)});
p.innerHTML='<iframe src="https://www.youtube-nocookie.com/embed/'+y+'?autoplay=1&rel=0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen title="video"></iframe>';});});"""


def _copy_block(s, cp_story):
    paras = ''.join('<p>%s</p>' % _e(p) for p in cp_story.get('paras', []))
    return ('<div class="copy"><div class="kicker">%s</div><h2>%s</h2>%s<p class="how"><b>이렇게 써 보세요.</b> %s</p></div>'
            % (_e(cp_story['kicker']), _e(cp_story['title']), paras, _e(cp_story.get('how', ''))))


def _tabs(pid, names, panes):
    t = ''.join('<button class="tab" role="tab" aria-selected="%s" id="%s%d">%s</button>'
                % ('true' if i == 0 else 'false', pid, i, _e(n)) for i, n in enumerate(names))
    p = ''.join('<div class="pane" role="tabpanel" aria-labelledby="%s%d"%s>%s</div>'
                % (pid, i, '' if i == 0 else ' hidden', body) for i, body in enumerate(panes))
    return '<div class="tabs" role="tablist">%s</div>%s' % (t, p)


def _paras(s):
    return ''.join('<p>%s</p>' % _e(x) for x in (s or '').split('\n') if x.strip())


def _clip(s, n):
    s = (s or '').strip()
    return s if len(s) <= n else s[:n].rstrip() + ' …'


def _s_verse(d):
    groups = {}
    for lk in d['links']:
        groups[lk['rel']] = groups.get(lk['rel'], 0) + 1
    chips = ''.join('<span class="chip">%s %d</span>' % (_e(REL_KO.get(k, k)), n) for k, n in groups.items())
    show = [lk for lk in d['links'] if lk['desc']][:6]
    rest = len(d['links']) - len(show)
    lks = ''.join('<div class="lk"><div class="h"><b>%s</b><span class="chip">%s</span></div><div class="t">%s</div><div>%s</div></div>'
                  % (_e(lk['ref']), _e(REL_KO.get(lk['rel'], lk['rel'])), _e(_clip(lk['text'], 60)), _e(lk['desc']))
                  for lk in show)
    if rest > 0:
        lks += '<div class="lk"><div class="t">그 밖에 %d개 연결</div></div>' % rest
    desc = _paras(d['lay']) + ('<div class="q"><div class="lab">묵상질문</div>%s</div>' % _e(d['q']) if d['q'] else '') + \
        ('<div class="q"><div class="lab">묵상기도</div>%s</div>' % _e(d['pr']) if d['pr'] else '')
    comm = '<div class="row src">%s</div><p class="mut">저작권이 끝난 고전 주석입니다. 원문과 현대 영어, 번역을 골라 읽습니다.</p>' % \
        ''.join('<span>%s</span>' % _e(x) for x in d['comm'])
    return ('<div class="app" data-tabs><div class="bar"><span class="ref">%s</span><span class="sp"></span><span class="mut">개역한글 · BSB</span></div>'
            '<div class="verse"><div>%s</div><div class="en">%s</div></div>%s</div>'
            % (_e(d['ref']), _e(d['krv']), _e(d['bsb']),
               _tabs('tv', ['설명', '연결구절 (%d)' % len(d['links']), '주석 (%d)' % len(d['comm']), '영상 (%d)' % d['media']],
                     [desc, '<div class="row">%s</div>%s' % (chips, lks), comm,
                      '<p>이 절과 이어진 설교·찬양 영상 %d편이 목록으로 뜨고 앱 안에서 바로 재생됩니다. 마지막 쪽에서 보입니다.</p>' % d['media']])))


def _s_plan(d, cp, tag):
    rows = ''.join('<div class="day"><span class="r">%s</span><span>%s</span></div>'
                   % (_e(it['ref']), _e(it['text'] if i == 0 else it['focus'])) for i, it in enumerate(d['items']))
    lead = d['items'][0]['focus'] if d['items'] else ''
    note = '<div class="note"><div class="lab">묵상노트<span class="ex">%s</span></div>%s</div>' % (_e(tag), _e(cp.get('example', '')))
    return ('<div class="app"><div class="bar"><span class="ref">%s</span><span class="sp"></span><span class="mut">%d / %d일</span></div>'
            '<div class="pane"><p>%s</p>%s%s</div></div>' % (_e(d['title']), d['day'], d['days'], _e(lead), rows, note))


def _s_lens(d):
    steps = ''.join('<span%s>%s</span>' % (' class="on"' if i + 1 == d['step'] else '', _e(n)) for i, n in enumerate(d['steps'][:4]))
    steps += '<span>…</span><span>%s</span>' % _e(d['steps'][-1])
    vs = ''.join('<div class="day"><span class="r">%s</span><span>%s</span></div>' % (_e(v['ref']), _e(_clip(v['text'], 80))) for v in d['verses'])
    return ('<div class="app"><div class="bar"><span class="ref">%s</span><span class="sp"></span><span class="mut">%d / %d걸음</span></div>'
            '<div class="pane"><div class="row steps">%s</div><p><b>%s</b></p><p>%s</p>%s<div class="q"><div class="lab">걸음 물음</div>%s</div></div></div>'
            % (_e(d['name']), d['step'], len(d['steps']), steps, _e(d['node']), _e(d['desc']), vs, _e(d['q'])))


def _s_book(d, cp, tag):
    body = d['body']
    cut = body.find('\n', 900)
    body = body[:cut if cut > 0 else 1100]
    hl = cp.get('highlight', '')
    memo = '<span class="memo"> (memo) %s (memo)</span><span class="ex">%s</span>' % (_e(cp.get('example', '')), _e(tag))
    parts = []
    for para in body.split('\n'):
        if not para.strip():
            continue
        p = _e(para)
        if hl and hl in para:
            p = p.replace(_e(hl), '<mark class="hl">%s</mark>%s' % (_e(hl), memo))
        parts.append('<p>%s</p>' % p)
    ko = ''.join(parts) + '<p class="mut">…</p>'
    en = _paras(_clip(d['en'], 700))
    return ('<div class="app" data-tabs><div class="bar"><span class="ref">%s</span><span class="sp"></span><span class="mut">%s · %d / %d편</span></div>%s</div>'
            % (_e(d['title']), _e(d['author']), d['seq'], d['n'], _tabs('tb', ['한국어', 'English'], [ko, en])))


def _s_study(d, cp, tag):
    text = _e(cp.get('example', ''))
    for ch in d['chips']:
        text = text.replace(_e(ch), '<mark class="ref">%s</mark>' % _e(ch), 1)
    chips = ''.join('<label><input type="checkbox" checked disabled> %s</label>' % _e(c) for c in d['chips'])
    tb = cp.get('table') or []
    table = ''
    if tb:
        table = '<div class="tw"><table class="t"><tr>%s</tr>%s</table></div>' % (
            ''.join('<th>%s</th>' % _e(x) for x in tb[0]),
            ''.join('<tr>%s</tr>' % ''.join('<td>%s</td>' % _e(x) for x in r) for r in tb[1:]))
    skip = ('<p class="mut">「%s」처럼 장만 적은 것은 추천하지 않습니다.</p>' % _e(d['skipped'][0])) if d['skipped'] else ''
    return ('<div class="app"><div class="bar"><span class="ref">연구/설교노트</span><span class="ex">%s</span><span class="sp"></span>'
            '<span class="mut">추가 · 수정 · Word편집 · to Word</span></div><div class="sug"><b>추천</b>%s<span class="sp"></span><span class="mut">남은 추천 지우기 ✕</span></div>'
            '<div class="pane"><p><b>%s</b></p><p>%s</p>%s%s</div></div>'
            % (_e(tag), chips, _e(cp.get('example_title', '')), text, table, skip))


def _s_ai(a, tag):
    ans = (a.get('answer') or '').replace('**', '')
    return ('<div class="app"><div class="bar"><span class="ref">AI 도우미 · 묵상노트 분석</span><span class="sp"></span><span class="mut">%s</span></div>'
            '<div class="pane chat"><div class="me"><div class="lab">보내는 글 · 내 묵상노트 창 12:6<span class="ex">%s</span></div>%s'
            '<div class="mut" style="margin-top:6px">함께 가는 것 · 필수 지침 · 창 12:6 본문과 단락 · 주요용어</div></div>'
            '<div class="ai"><div class="lab">%s</div>%s</div></div></div>'
            % (_e(a.get('model', '')), _e(tag), _e(a.get('note', '')), _e(a.get('model', '')), _paras(ans)))


def _s_video(d, inline, prefix):
    """목록을 보이고 누르면 그 자리에서 재생 — 누르기 전에는 유튜브에 아무것도 안 부른다(누른 뒤에야 youtube-nocookie)."""
    cards = ''
    for it in d['items']:
        src = _thumb_src(it['yid'], inline, prefix)
        cards += ('<button type="button" class="vid" data-yid="%s"><img src="%s" alt="" loading="lazy">'
                  '<span class="tt">%s</span><span class="mut">%s</span></button>'
                  % (_e(it['yid']), src, _e(it['title']), _e(it['channel'])))
    return ('<div class="app"><div class="bar"><span class="ref">온라인 영상 · %s</span><span class="sp"></span><span class="mut">%d편</span></div>'
            '<div class="pane"><div class="player" id="mag-player"><span class="mut">목록에서 영상을 누르면 여기서 재생됩니다</span></div>'
            '<div class="vids">%s</div></div></div>' % (_e(d['ref']), len(d['items']), cards))


def render(conn, lang='KO', inline=False, prefix='a/'):
    cp = copy_of(lang)
    if not cp:
        raise ValueError('잡지 글 파일이 없는 언어: %s' % lang)
    tag = cp.get('example_tag', 'Example')
    S = {s['key']: s for s in cp['stories']}
    st = stats(conn)
    stat = ''.join('<span><b>%s</b> %s</span>' % ('{:,}'.format(st[k]), _e(v)) for k, v in cp['stat_labels'].items() if k in st)
    toc = ''.join('<a href="#%s">%s</a>' % (s['key'], _e(s['title'])) for s in cp['stories'])
    vd = d_video(conn, lang)
    apps = {
        'verse': _s_verse(d_verse(conn, lang)),
        'plan': _s_plan(d_plan(conn, lang), S.get('plan', {}), tag),
        'lens': _s_lens(d_lens(conn, lang)),
        'book': _s_book(d_book(conn, lang), S.get('book', {}), tag),
        'study': _s_study(d_study(conn, lang, S.get('study', {}).get('example', '')), S.get('study', {}), tag),
        'ai': _s_ai(ai_capture(), tag),
        'video': _s_video(vd, inline, prefix),
    }
    body = ''.join('<section class="story" id="%s">%s%s</section>' % (s['key'], _copy_block(s['key'], s), apps[s['key']])
                   for s in cp['stories'] if s['key'] in apps)
    foot = ''.join('<div>%s</div>' % _e(x) for x in cp.get('foot', []))
    return ('<title>%s</title><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Serif+KR:wght@400;700;800&family=Noto+Sans+KR:wght@400;600;700&display=swap">'
            '<style>%s</style><div class="wrap"><header class="mast"><h1>%s</h1><span class="issue">%s</span></header>'
            '<p class="lede">%s</p><div class="stats">%s</div><nav class="toc">%s</nav>%s<footer class="foot">%s</footer></div><script>%s</script>'
            % (_e(cp['title']), CSS, _e(cp['title']), _e(cp['issue']), _e(cp['lede']), stat, toc, body, foot, JS))


def build_into(out, conn, lang_dir):
    """홈페이지 빌드가 부른다 — 글 파일이 있는 언어만 `<언어 폴더>magazine.html`. 만든 언어 목록을 돌려준다."""
    made = []
    if os.path.isdir(MAG_DIR):
        import shutil
        dst = os.path.join(out, 'a', 'mag')
        shutil.copytree(MAG_DIR, dst, dirs_exist_ok=True)
    for lg in langs_ready():
        d = os.path.join(out, lang_dir(lg))
        os.makedirs(d, exist_ok=True)
        up = '' if lang_dir(lg) == '' else '../'
        page = render(conn, lg, prefix=up + 'a/')
        with open(os.path.join(d, PAGE), 'w', encoding='utf-8') as f:
            f.write('<!doctype html><html lang="%s"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                    '<meta name="robots" content="noindex"></head><body>%s</body></html>' % (lg.lower(), page))
        made.append(lg)
    return made


def capture_ai():
    """6쪽 AI 답을 다시 받는다 — 앱 묵상노트 분석과 같은 자리(재료에 노트 · 할 일은 사용자 말)."""
    import user_ai as U
    import db_ai_guard as G
    c = appdb.connect()
    cp = copy_of('KO')
    note = {s['key']: s for s in cp['stories']}['plan']['example']
    v = _vid(c, 1, 12, 6)
    groups = [(v, _ref(c, v), [note])]
    role, task = U.task_texts(c, 'VERSE', task='NOTE', lang='KO')
    task = U.note_task_text(c, task, groups, 'KO')
    mat = U.materials(c, v, v, 'KO')
    mat['내 묵상노트'] = U.note_material(groups)
    system = (G.text(c, 'KO') or '') + '\n\n' + (role or '') + '\n\n' + U.render(mat)
    a = U.enabled_accounts(c)[0]
    r = U.call(a['provider'], a['key'], a['model'], [('user', task)], system=system)
    if not r.get('ok'):
        raise SystemExit('AI 답을 못 받음: %s' % r.get('why'))
    import datetime
    with open(AI_FILE, 'w', encoding='utf-8') as f:
        json.dump({'_about': '잡지 6쪽 AI 답 — 앱의 묵상노트 분석으로 실제로 한 번 받은 답', 'captured': str(datetime.date.today()),
                   'model': a['model'], 'note': note, 'task': task, 'answer': r['text']}, f, ensure_ascii=False, indent=1)
    print('받음', a['model'])


def selftest():
    ok = 0
    fail = []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            fail.append(m)
    c = appdb.connect()
    cp = copy_of('KO')
    ck(cp and len(cp['stories']) == 7, '한국어 글 파일 · 이야기 일곱')
    h = render(c, 'KO', inline=False)
    ck(h.count('class="story"') == 7, '쪽 일곱이 그려진다')
    dv = d_verse(c, 'KO')
    ck(dv['krv'] in h and len(dv['links']) > 5, '1쪽 — DB 본문·연결')
    ck(d_plan(c, 'KO')['items'], '2쪽 — 플랜 하루')
    ck(d_lens(c, 'KO')['verses'], '3쪽 — 렌즈 구절')
    ck(d_book(c, 'KO')['body'], '4쪽 — 도서 본문')
    ds = d_study(c, 'KO', {s['key']: s for s in cp['stories']}['study']['example'])
    ck(ds['chips'] and ds['skipped'], '5쪽 — 추천 약명과 장만 적은 것')
    ck(ai_capture().get('answer'), '6쪽 — 받은 AI 답')
    ck(d_video(c, 'KO')['items'], '7쪽 — 영상 목록')
    ck(h.count('class="ex"') >= 4, '사용자 글에 「예시」')
    vv = d_video(c, 'KO')['items']
    ck(all('계시록' not in x['title'] for x in vv), '7쪽 — 제목이 다른 책을 먼저 가리키는 영상은 빠진다')
    ck('<iframe' not in h.split('<script>')[0], '누르기 전에는 영상을 안 부른다')
    ck('i.ytimg.com' not in h, '방문자 브라우저가 유튜브 그림을 직접 부르지 않는다')
    ck('<script src' not in h, '밖의 스크립트를 안 부른다')
    print('site_magazine selftest %d/%d' % (ok, ok + len(fail)))
    for m in fail:
        print('  FAIL', m)
    return not fail


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--capture-ai' in a:
        capture_ai()
    if '--fetch' in a:
        c = appdb.connect()
        print('썸네일 받음', fetch_thumbs(d_video(c, 'KO')['items']))
    if '--preview' in a:
        c = appdb.connect()
        p = a[a.index('--preview') + 1]
        with open(p, 'w', encoding='utf-8') as f:
            f.write(render(c, 'KO', inline=True))
        print('미리보기', p)
