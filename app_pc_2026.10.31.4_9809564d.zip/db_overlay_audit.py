# -*- coding: utf-8 -*-
"""db_overlay_audit.py — 덮개 조회 규칙 검사기 (2026-08-27 신설·영구).

★★ 왜 (오버레이통합계획.md §1-②): 「sys 를 직접 읽지 말라」는 규칙이
  `coding.md` 에 글로 있었는데 **또 났다**(갈렙 사건들). 글로 막는 것은 증명이
  끝났다 — 코드가 세고, 새로 늘면 이름을 대고 실패한다.

무엇을 재나
  · 사용자 앱(user_main 의 **import 폐포** — 손 목록 금지, §0-6 교훈)에서
    덮개 대상 sys 표를 SQL 로 직접 읽는 자리를 센다.
  · 조회 문(허가 모듈)과 적재 도구는 제외 — 그들이 규칙의 집이다.

★ **기준선(ratchet) 방식** — 기존 위반이 수백 자리라 「위반=실패」로는 오늘
  통과가 불가능하다. `overlay_audit_baseline.json` 에 지금 상태를 기록하고,
  **기준선보다 는 파일만** 실패시킨다. 빚은 보이되 막지 않는다 — 줄이는
  방향으로만 움직인다. 자리를 줄였으면 `--rebase` 로 기준선을 내린다.
  ⚠ 기준선을 **올리는 rebase 는 이 도구가 거부한다** — 새 위반을 기준선에
    넣으려면 사람이 파일을 직접 고쳐야 하고, 그 diff 가 리뷰에 보인다.

    python db_overlay_audit.py            # 검사 (새 위반 있으면 exit 1)
    python db_overlay_audit.py --list     # 파일별 자리 수 전부
    python db_overlay_audit.py --rebase   # 기준선 갱신(줄이는 방향만)
    python db_overlay_audit.py --selftest # 의무
"""
import io
import json
import os
import re
import sys

APP = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(APP, 'overlay_audit_baseline.json')

#: 덮개 대상 표 — 이것을 사용자 화면이 직접 SELECT 하면 위반이다.
#  (sys_text_asset 은 덮개 유형이 정해져 있지만 표 단위로 잰다 — 유형까지
#   가리면 검사가 SQL 파서가 돼야 한다. 자리 수 추세만 지켜도 목적은 이룬다.)
TABLES = ('sys_link_asset', 'sys_media_asset', 'sys_text_asset',
          'sys_tag_asset', 'sys_entity_master')

#: 허가 모듈 — 조회 문 자신과, 덮개를 이미 합쳐 주는 검증된 단일 소스들.
#  ⚠ 여기 늘리는 것 = 「이 파일이 덮개 규칙의 집」이라는 선언이다. 화면을
#    넣지 말 것 — 화면이 들어오는 순간 검사가 눈을 감는다.
ALLOWED = {
    'overlay.py', 'overlay_read.py', 'overlay_mark.py',
    'link_picker.py', 'tag_picker.py', 'entity_overlay.py',
    'entity_aliases.py', 'media_link.py', 'db_tag_system.py',
    'db_term_load.py', 'db_link_rank.py', 'db_book_entity_link.py',
    'verse_tier.py', 'appdb.py',
    # 구절연결(VERS_VERS)의 데이터 층 단일 소스 — 덮개는 overlay 엔진 위임,
    # 직접 SQL 은 합침 조회의 sys 반쪽이다(2026-08-27 연결설명문 추가 때 선언)
    'verse_link_edit.py',
    # 링크 팩 증분 적재기 (2026-09-03 190차 선언). **화면이 아니다** — 위젯
    # 0. `sys_entity_master` 를 읽는 것은 델타의 **자연 열쇠(entity_code)를
    # 번호로 해석**하는 한 자리뿐이고(모르면 보류), 그것이 팩 주기와 본체
    # 주기가 어긋나도 안전한 이유다.
    # ★★★ **배포·검사 도구 — 화면이 아니다** (2026-09-05 선언).
    #   ⚠⚠ 이들이 폐포에 들어온 것은 **사용자 앱이 관리자 도구를 끌어오기**
    #     때문이다(실측 `user_main ← feedback_view ← pack_status/db_pack_*` ·
    #     `user_main ← tray_agent ← db_linkpack_build`). 덮개 문제가 아니라
    #     **다른 문제**를 가리키는 신호이고, 그것은 성능 쪽에서 볼 자리다.
    #   ★★ **팩 빌더가 덮개를 타면 배포물에 사용자 개인 글이 들어간다**
    #     (§0-6 C-2). 정확히 **반대로** 해야 하는 자리다 — sys 원본을 그대로
    #     담아야 한다. `db_integrity` 는 sys 표를 **세는 것이 그 일**이다.
    'db_integrity.py',            # 무결성 검사기 — sys 표를 센다
    'db_linkpack_build.py',       # 링크 팩 빌더(보내는 쪽)
    'db_pack_body.py', 'db_pack_catalog.py', 'db_pack_history.py',
    'db_pack_item.py', 'db_pack_stat.py',
    'rss_publish.py',             # 발행
    # 최신 콘텐츠 발행 규칙·정합성 점검 (2026-09-06 신설) — **화면이 아니다**
    # (위젯 0). `sys_media_channel`·`sys_media_asset` 을 읽는 것은
    # ⓐ 「등록 채널인가」(기독교 자료 판정) ⓑ 점검 세기 두 자리뿐이고,
    # 둘 다 **덮개를 타면 안 된다** — 사용자가 가린 것을 근거로 발행을
    # 정하면 배포물이 사람마다 달라진다.
    'latest_rules.py',
    # 앱에 담긴 것을 세는 한 문 (2026-09-06 신설) — **화면이 아니다**
    # (selftest 가 `tkinter` 를 import 하지 않는지 AST 로 잰다).
    # ⚠⚠ **덮개를 타면 안 되는 자리다** — 고지·소개가 말하는 것은 「배포물에
    #   담긴 양」이고, 사용자가 제 화면에서 고치거나 가린 것을 우리 저작량으로
    #   세면 **거짓 고지**가 된다.
    'app_facts.py',
    # ★★ 성경듣기 데이터 층 (2026-09-10 신설) — **화면이 아니다**(위젯 0).
    #   화면(2026-09-17 뒤로는 `kids_view` 의 왼쪽 책 트리)은
    #   `books_with_reading`·`media_of_book` 두 조회 문만 부르고 SQL 을 안 쓴다
    #   — §234차 `db_song` 을 선언한 그 조건 그대로.
    #   ⚠ **가림은 이 층이 지킨다** — `media_of_book(hide=…)` 이 사용자가 숨긴
    #     영상·채널을 뺀다. 안 주는 자리는 관리·집계용이다.
    'db_reading_book.py',
    # ★★ **재생목록 데이터 층** (2026-09-10 신설) — 위젯 0. 담는 표는
    #   `userdb.user_media_list*` 이고 본체가 sys 라 조인이 여기 한 곳에 있다.
    #   ⚠ **가림은 이 층이 지킨다** — `items(pref=…)` 이 숨긴 것을 뺀다
    #     (selftest 가 그 불변식을 잰다).
    'db_media_list.py',
    # ★★ **찬양 주제 데이터 층** (2026-09-10 신설) — 위젯 0. 주제는 새 축이
    #   아니라 영상↔용어 연결(`MEDI_ENTI`) 위에 얹는 **고른 용어 목록**이고,
    #   그 조인이 여기 한 곳에 있다. 화면은 `topics`·`media_of_topic` 만 부른다.
    #   ⚠ 가림은 `media_of_topic(pref=…)`·`unclassified(pref=…)` 이 지킨다.
    'db_worship_topic.py',
    # 인물 관계 데이터 층 (2026-09-05 신설) — 위젯 0. 관계·설명문·구절이
    # **배포 자산**이라 덮개 대상이 아니다(사용자가 고치는 글이 아니다).
    'db_person_relation.py',
    # ★★ **낱말 층 데이터 도구 넷** (2026-09-07 신설 · 1.txt A·B·C·D).
    #   전부 **위젯 0**이고 다루는 것이 **배포 자산**이다 — 이름의 뜻·어근
    #   가족·흐름 연결·용어 축은 우리가 짓는 것이고 사용자가 고치는 글이
    #   아니다(덮개 대상이 아니다).
    #   ⚠ 이들이 폐포에 들어온 것은 `entity_browser` 가 화면에서 부르기
    #     때문이다. **화면 쪽은 이 도구를 부르기만 하고 SQL 을 안 쓴다** —
    #     그것이 이 선언의 조건이다.
    'db_name_meaning.py', 'db_word_family.py',
    'db_word_chain.py', 'db_term_axis.py',
    # 개역한글 옮김새 (2026-09-07) — **성경 본문을 읽는다**(`bible_content`).
    #   ⚠ 그것은 **덮개 대상이 아니다** — 성경 본문은 사용자가 고치는 글이
    #     아니고 역본 그 자체다. 위젯 0 · 원장은 파일이다.
    'db_lemma_render.py',
    # 구절 구간 판정 단일 문 (2026-09-09) — **화면이 아니다**(위젯 0).
    #   sys 표를 읽는 두 자리는 `--audit` 이 **새는 구간을 세는 것**이고
    #   그것이 그 도구의 일이다. 판정 자체는 SQL **조각**만 낸다.
    'verse_range.py',
    # ★★ **찬양(CCM) 데이터 층 넷** (2026-09-09 신설).
    #   전부 **위젯 0**이고 다루는 것이 **배포 자산**이다(곡·판·사역자·수집).
    #   ⚠⚠ **수집기는 덮개를 타면 안 된다** — `media_intake` 는 sys 에 담는
    #     문이고, 사용자가 가린 것을 근거로 담기를 정하면 배포물이 사람마다
    #     달라진다(팩 빌더와 같은 자리 · §0-6 C-2).
    #   ⚠ 이들이 폐포에 들어온 것은 **화면(`song_panel`)이 `db_song` 을 부르고
    #     그 안의 `derive` 가 수집기를 부르기** 때문이다. 화면은 조회 문
    #     (`songs_of_verse`·`songs_of_entity`)만 쓰고 SQL 을 안 쓴다 —
    #     그것이 이 선언의 조건이다(§199차 ⑯ 「무거운 모듈의 함수를 부르면
    #     그 모듈의 짐이 통째로 따라온다」).
    'db_song.py', 'db_song_collect.py', 'db_worship_artist.py',
    'media_intake.py', 'media_text_linker.py',
    # 시작화면 사진의 제목·설명 (2026-09-05) — `photo_text()` 가 **이미
    # `user_text_asset` 과 합쳐 읽는다**(내 사진 글은 user 쪽). 관리자가 쓰는
    # `SPLASH_TITLE`/`SPLASH_DESC` 는 덮개 대상이 아니다.
    'db_splash_scene.py',
    # 팩 폴백 판정 (2026-09-05) — 「이 자산의 **본문을 갖고 있는가**」를 센다.
    # 사용자가 설명문을 고쳤다고 「받았다」가 바뀌면 안 된다.
    'pack_fallback.py',
    'db_linkpack_sync.py',
    # 묵상플랜 **이름**의 단일 소스 (2026-08-30 선언). 화면이 아니다 — 위젯이
    # 하나도 없고 `PLAN_TITLE` 만 읽는다. 이름을 짓는 곳(`full`·`combo`)과
    # 읽는 곳(`titles_of`)을 갈라 두면 화면마다 이름이 달라진다.
    # ⚠ `PLAN_TITLE` 은 덮개 대상이 아니다(사용자가 고치는 글이 아니라 배포
    #   이름이다) — 표 이름만 겹쳐 걸리던 자리다.
    'plan_label.py',
    # 장소 지역분류 코드표 도구 (2026-09-02 선언). 화면이 아니다 — 위젯 0 ·
    # selftest 7/7. `json_detail.region_code` 를 읽는 조회 문(`regions_of`)이
    # 여기 살고 화면(entity_browser)은 그것을 부른다.
    'db_region_code.py',
    # 용어 갈래·병합 도구 (2026-09-02 선언). `sys_entity_branch` 조회 문
    # (`branch_map`)의 집 — 화면이 여기서 읽는다.
    'db_term_branch.py',
    # 2026-09-08 (211~216차) 선언 — 전부 **화면이 아니다**:
    #   `db_media_linkcheck` 주소 점검 장부(sys_media_check 는 LOCAL 표) ·
    #   `db_media_range` 구간·이름 경계 읽기 규칙(수집기·검토 화면이 부른다) ·
    #   `media_taxonomy` 분류·수화 코드표(`sign_codes_in_use` 조회 문의 집) ·
    #   `share_pack` 내 자산을 자연 열쇠로 내보내는 도구(덮개를 타면 안 된다 —
    #   배포 DB 의 열쇠로 적어야 다른 PC 에서 풀린다).
    'db_media_linkcheck.py', 'db_media_range.py', 'media_taxonomy.py',
    'share_pack.py',
}

_SQL_RE = re.compile(
    r'(?:FROM|JOIN)\s+(%s)\b' % '|'.join(TABLES), re.IGNORECASE)


def _closure(root='user_main.py'):
    """user_main 이 실제로 끌어오는 로컬 모듈 전부 — 손으로 적지 않는다."""
    seen, todo = set(), [root]
    imp = re.compile(r'^\s*(?:import|from)\s+([A-Za-z_][\w.]*)', re.M)
    while todo:
        f = todo.pop()
        if f in seen or not os.path.exists(os.path.join(APP, f)):
            continue
        seen.add(f)
        try:
            src = io.open(os.path.join(APP, f), encoding='utf-8').read()
        except Exception:
            continue
        for m in imp.finditer(src):
            top = m.group(1).split('.')[0]
            cand = top + '.py'
            if os.path.exists(os.path.join(APP, cand)):
                todo.append(cand)
            sub = os.path.join(top, '__init__.py')
            if os.path.exists(os.path.join(APP, sub)):
                # admin/ 같은 패키지 — 사용자 앱 폐포에 들어오면 그 파일만
                todo.append(sub.replace(os.sep, '/'))
    return sorted(seen)


def scan(files=None):
    """{파일: 자리 수} — 허가 모듈 제외, SQL 문자열 안의 FROM/JOIN 만 센다."""
    out = {}
    for f in (files or _closure()):
        base = os.path.basename(f)
        if base in ALLOWED:
            continue
        try:
            src = io.open(os.path.join(APP, f), encoding='utf-8').read()
        except Exception:
            continue
        n = len(_SQL_RE.findall(src))
        if n:
            out[f] = n
    return out


def load_baseline():
    try:
        return json.load(io.open(BASELINE, encoding='utf-8'))
    except Exception:
        return None


def check(verbose=False):
    """새 위반(기준선 초과)만 실패. 반환 (ok, 초과목록, 현재)."""
    cur = scan()
    base = load_baseline()
    if base is None:
        print('⚠ 기준선이 없다 — `--rebase` 로 먼저 기록하라.')
        return False, [], cur
    worse = []
    for f, n in sorted(cur.items()):
        b = base.get(f, 0)
        if n > b:
            worse.append((f, b, n))
    if verbose or worse:
        for f, b, n in worse:
            print('  ★ 새 위반  %-34s %d → %d' % (f, b, n))
    total = sum(cur.values())
    print('덮개 대상 sys 직접 읽기: %d파일 %d자리 (기준선 %d자리) — %s'
          % (len(cur), total, sum(base.values()),
             '새 위반 %d파일' % len(worse) if worse else '늘지 않음 OK'))
    return not worse, worse, cur


def rebase():
    cur = scan()
    base = load_baseline()
    if base is not None:
        inc = [(f, base.get(f, 0), n) for f, n in cur.items()
               if n > base.get(f, 0)]
        if inc:
            print('✗ 기준선을 올리는 rebase 는 거부한다 — 먼저 위반을 줄여라:')
            for f, b, n in inc:
                print('    %-34s %d → %d' % (f, b, n))
            return False
    json.dump(cur, io.open(BASELINE, 'w', encoding='utf-8'),
              ensure_ascii=False, indent=1, sort_keys=True)
    print('기준선 기록: %d파일 %d자리 → %s'
          % (len(cur), sum(cur.values()), os.path.basename(BASELINE)))
    return True


def selftest():
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    # ① 폐포 — 손 목록이 아니라 계산 (핵심 화면이 실제로 들어오는가)
    cl = _closure()
    t('폐포 계산 — user_main 포함 %d개' % len(cl),
      'user_main.py' in cl and 'entity_browser.py' in cl and len(cl) > 40)
    t('허가 모듈은 폐포에 있어도 안 센다',
      'overlay_read.py' in cl and 'overlay_read.py' not in scan())
    # ② 탐지력 — 위반을 심으면 잡는가
    probe = os.path.join(APP, 'temp_code_audit_probe.py')
    io.open(probe, 'w', encoding='utf-8').write(
        'Q = "SELECT x FROM sys_link_asset WHERE 1"\n'
        'R = "SELECT y FROM t JOIN sys_media_asset m ON 1"\n')
    try:
        got = scan(files=['temp_code_audit_probe.py'])
        t('★ 탐지력 — 심은 위반 2자리를 잡는다',
          got.get('temp_code_audit_probe.py') == 2, got)
    finally:
        os.remove(probe)
    # ③ 기준선 왕복 — 실제 파일은 안 건드리고 메모리로
    base = {'a.py': 2}
    cur_ok, cur_bad = {'a.py': 2}, {'a.py': 3}
    t('기준선 같으면 통과',
      not [f for f, n in cur_ok.items() if n > base.get(f, 0)])
    t('기준선 초과는 잡힌다',
      [f for f, n in cur_bad.items() if n > base.get(f, 0)] == ['a.py'])
    # ④ 실기준선 — 있으면 check 가 돌고, 늘지 않았어야 한다
    if load_baseline() is not None:
        good, worse, _ = check()
        t('실기준선 대비 새 위반 0', good, worse)
    print('db_overlay_audit selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--rebase' in a:
        sys.exit(0 if rebase() else 1)
    if '--list' in a:
        for f, n in sorted(scan().items(), key=lambda kv: -kv[1]):
            print('  %-40s %d' % (f, n))
        sys.exit(0)
    good, _, _ = check(verbose=True)
    sys.exit(0 if good else 1)
