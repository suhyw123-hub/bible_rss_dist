# -*- coding: utf-8 -*-
"""plan_progress.py — 묵상플랜 「하루 완료」 단일 문 (2026-10-06 317차 신설·영구).

★★★ 왜 따로 뺐나 — 그전에는 이 규칙이 **화면 메서드 안**에만 있었다
  (`plan_focus_view._complete_day`). 모바일에서 「오늘 묵상 완료」를 누른 것도
  PC 에 똑같이 적어야 하는데(`mobile_sync` 의 사건), 규칙을 두 곳에 적으면
  반드시 갈린다(§219차 ⑤). 화면과 모바일 동기화가 **이 함수 하나**를 쓴다.

규칙(옛 화면 코드 그대로):
  · 그 날의 스케줄 줄마다 진행 기록을 **지우고 다시 넣는다**(멱등)
  · 그 날이 **지금 진행 중인 날**이면 다음 날로 넘기고, 끝까지 왔으면 완료
  · 지난 날을 다시 완료해도 진행 위치는 안 바뀐다

⚠ 커밋은 부르는 쪽이 한다 — 여러 사건을 한 번에 적을 때 묶을 수 있게.
⚠ 사용량 집계(`usage_stats.bump`)는 **화면만** 부른다 — 동기화가 부르면
  폰에서 한 번 누른 것이 PC 집계에 두 번 잡힌다(폰도 제 집계를 보낸다).

사용:  python plan_progress.py --selftest
"""
import sys
from datetime import date

sys.stdout.reconfigure(encoding='utf-8', errors='replace')


def enrollment(conn, enr_id):
    """그 등록의 (plan_id, user_plan_id, current_day, duration_days, status) — 없으면 None."""
    r = conn.execute(
        "SELECT e.plan_id, e.user_plan_id, e.current_day, "
        "       CASE WHEN e.user_plan_id IS NOT NULL "
        "            THEN u.duration_days ELSE p.duration_days END, "
        "       e.enrollment_status "
        "FROM user_plan_enrollment e "
        "LEFT JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
        "LEFT JOIN user_bible_plan u ON u.user_plan_id=e.user_plan_id "
        "WHERE e.enrollment_id=? AND COALESCE(e.record_status,'LIVE')='LIVE'",
        (int(enr_id),)).fetchone()
    if not r:
        return None
    return {'plan_id': r[0], 'user_plan_id': r[1], 'current_day': r[2] or 1,
            'duration_days': r[3] or 1, 'status': r[4] or 'ACTIVE'}


def schedule_ids(conn, enr, day):
    if enr['user_plan_id']:
        return [x[0] for x in conn.execute(
            "SELECT sched_id FROM user_plan_schedule "
            "WHERE user_plan_id=? AND day=? ORDER BY sort_order",
            (enr['user_plan_id'], int(day)))]
    return [x[0] for x in conn.execute(
        "SELECT schedule_id FROM sys_plan_schedule "
        "WHERE plan_id=? AND day=? ORDER BY sort_order",
        (enr['plan_id'], int(day)))]


def mark_day(conn, enr_id, day, when=None):
    """그 등록의 그 날을 완료로 적는다 → dict.

    돌려주는 것: {'ok', 'rows'(적은 스케줄 줄 수), 'advanced'(진행 위치를
    옮겼나), 'completed'(플랜을 끝냈나), 'why'(못 했으면 까닭)}.
    """
    enr = enrollment(conn, enr_id)
    if not enr:
        return {'ok': False, 'rows': 0, 'advanced': False,
                'completed': False, 'why': 'NO_ENROLLMENT'}
    day = int(day)
    dur = int(enr['duration_days'])
    if day < 1 or day > dur:
        return {'ok': False, 'rows': 0, 'advanced': False,
                'completed': False, 'why': 'DAY_OUT_OF_RANGE'}
    when = when or date.today().isoformat()
    sids = schedule_ids(conn, enr, day)
    for sid in sids:
        conn.execute("DELETE FROM user_plan_progress "
                     "WHERE enrollment_id=? AND schedule_id=?",
                     (int(enr_id), sid))
    conn.executemany(
        "INSERT INTO user_plan_progress (enrollment_id, schedule_id, "
        " completed_date, read_count, record_status) VALUES (?, ?, ?, 1, 'LIVE')",
        [(int(enr_id), sid, when) for sid in sids])
    advanced = completed = False
    if day == int(enr['current_day']):
        nxt = day + 1
        if nxt > dur:
            conn.execute(
                "UPDATE user_plan_enrollment SET current_day=?, "
                " enrollment_status='COMPLETED', end_date=?, "
                " final_status='COMPLETED' WHERE enrollment_id=?",
                (dur, when, int(enr_id)))
            completed = True
        else:
            conn.execute(
                "UPDATE user_plan_enrollment SET current_day=?, "
                " enrollment_status='ACTIVE' WHERE enrollment_id=?",
                (nxt, int(enr_id)))
        advanced = True
    return {'ok': True, 'rows': len(sids), 'advanced': advanced,
            'completed': completed, 'why': ''}


def selftest():
    import appdb
    ok = [0, 0]

    def ck(name, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s%s' % ('PASS' if cond else 'FAIL', name,
                             (' — %s' % got) if got and not cond else ''))

    conn = appdb.connect('bible_master.db')
    conn.execute('SAVEPOINT pp')
    try:
        p = conn.execute(
            "SELECT p.plan_id, p.duration_days FROM sys_bible_plan p "
            "WHERE p.duration_days >= 3 AND EXISTS (SELECT 1 FROM sys_plan_schedule s "
            " WHERE s.plan_id=p.plan_id AND s.day=1) "
            "AND COALESCE(p.record_status,'LIVE')='LIVE' ORDER BY p.plan_id LIMIT 1"
        ).fetchone()
        ck('시험할 플랜이 있다', p is not None)
        cur = conn.execute(
            "INSERT INTO user_plan_enrollment(plan_id, start_date, current_day,"
            " enrollment_status, record_status) VALUES(?, '2026-01-01', 1,"
            " 'ACTIVE', 'LIVE')", (p[0],))
        eid = cur.lastrowid
        r = mark_day(conn, eid, 1, '2026-01-02')
        ck('첫날 완료 — 줄을 적는다', r['ok'] and r['rows'] >= 1, r)
        ck('진행 위치가 2일로', conn.execute(
            "SELECT current_day FROM user_plan_enrollment WHERE enrollment_id=?",
            (eid,)).fetchone()[0] == 2)
        n1 = conn.execute("SELECT COUNT(*) FROM user_plan_progress "
                          "WHERE enrollment_id=?", (eid,)).fetchone()[0]
        r2 = mark_day(conn, eid, 1, '2026-01-03')
        n2 = conn.execute("SELECT COUNT(*) FROM user_plan_progress "
                          "WHERE enrollment_id=?", (eid,)).fetchone()[0]
        ck('같은 날을 두 번 — 줄이 안 는다(멱등)', n1 == n2, (n1, n2))
        ck('지난 날을 다시 — 진행 위치를 안 옮긴다', not r2['advanced'])
        ck('범위 밖 날은 거부', not mark_day(conn, eid, 99999)['ok'])
        ck('없는 등록은 거부', not mark_day(conn, -1, 1)['ok'])
        conn.execute("UPDATE user_plan_enrollment SET current_day=? "
                     "WHERE enrollment_id=?", (p[1], eid))
        r3 = mark_day(conn, eid, p[1], '2026-02-01')
        st = conn.execute("SELECT enrollment_status, end_date FROM "
                          "user_plan_enrollment WHERE enrollment_id=?",
                          (eid,)).fetchone()
        ck('마지막 날 — 플랜 완료', r3['completed'] and st[0] == 'COMPLETED'
           and st[1] == '2026-02-01', st)
    finally:
        conn.execute('ROLLBACK TO pp')
        conn.execute('RELEASE pp')
        conn.close()
    print('plan_progress selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
