# -*- coding: utf-8 -*-
"""
db_versification_audit.py  (영구 진단도구)

목적: 여러 성경 버전이 단일 bible_index.verse_id 축을 공유할 때,
      같은 verse_id 슬롯에 버전마다 다른 내용이 배치되는 위험을 전수 조사한다.

두 종류의 위험을 각각 탐지한다:
  Tier 1 (절수 불일치) : 장별로 각 버전이 채운 슬롯 수를 정본(bible_index) 대비 비교.
                         절 누락/추가·커버리지 갭을 색출. (전 버전, 값쌈, 전수)
  Tier 2 (내용 shift)  : 동일 언어군에서 verse_id별 고유명사·숫자 지문을 비교.
                         절수는 같은데 내용만 한 칸 밀린 "조용한 shift"를 이웃대조로 색출.
                         (족보·서사에서 발생. 사용자가 가장 우려한 유형.)

사용법:
  python -X utf8 db_versification_audit.py            # 전체 스캔 + 리포트
  python -X utf8 db_versification_audit.py --book 13  # 특정 책(bcode)만
결과: 콘솔 요약 + versification_audit_report.txt 저장. DB를 수정하지 않는다(읽기 전용).
"""
import sqlite3, re, sys, io

DB = 'bible_master.db'
OUT = 'versification_audit_report.txt'

# 동일 언어군 (Tier 2 대상) — 같은 언어의 여러 버전이 있어야 내용대조 가능
LANG_CLUSTERS = {
    'EN': ['KJV', 'ASV', 'WEB', 'BSB'],
    'ZH': ['CUV', 'CUVS'],
}

# baking 마커 (§18-5) — 이 마커로 시작하는 행은 "보충행"이라 실보유 아님
BAKE_MARK = ('<Absent>', '<없음>', '<缺>', '<Ausente>', '<Ausência>',
             '<Manque>', '<Fehlt>', '<Отсутствует>', '<欠>')

STOP = {'And','The','But','For','Now','His','Her','They','These','This','That',
        'With','All','Who','Their','Was','Were','Are','Not','Him','She','Also',
        'When','Then','From','Unto','Sons','Son','Have','Had','Will','Shall',
        'There','Which','Them','Out','Into','Over','After','Before','Because'}
# 신적 호칭 — 버전마다 철자가 달라(Lord/Jehovah/Yahweh/LORD) 오탐의 주범.
# prefix4 정규화 시 서로 다른 토큰이 되므로 앵커에서 제외한다.
# (인명·지명 David/Abraham/Zion 등은 족보 shift 탐지에 필요하므로 남긴다.)
DIVINE = {'lord','jeho','yahw','yhwh','god','jesu','chri','fath','spir','hol','ghos'}

def is_baked(t):
    if not t: return False
    ts = t.lstrip()
    return any(ts.startswith(m) for m in BAKE_MARK)

def has_text(t):
    return bool(t) and t.strip() != '' and not is_baked(t)

def anchors(t):
    """고유명사(대문자 시작 3자+) prefix4 + 숫자 → 철자차이에 견고한 지문.
    신적 호칭(철자변형 심함)은 제외."""
    if not t: return set()
    s = set()
    for w in re.findall(r'\b[A-Z][a-z]{2,}\b', t):
        if w in STOP: continue
        p = w.lower()[:4]
        if p in DIVINE: continue
        s.add(p)
    for n in re.findall(r'\d+', t):
        s.add('#'+n)
    return s

def jac(a, b):
    if not a and not b: return 1.0
    if not a or not b: return 0.0
    return len(a & b) / len(a | b)

def main():
    book_filter = None
    if '--book' in sys.argv:
        book_filter = int(sys.argv[sys.argv.index('--book')+1])

    conn = sqlite3.connect(DB); c = conn.cursor()
    out = io.StringIO()
    def P(*a):
        line = ' '.join(str(x) for x in a)
        print(line); out.write(line+'\n')

    # 버전 목록
    versions = [r[0] for r in c.execute(
        "SELECT version_code FROM bible_version ORDER BY version_code")]
    # 책 이름 (EN)
    bname = {r[0]: r[1] for r in c.execute(
        "SELECT book_code, short_name FROM book_names WHERE lang_code='EN'")}

    # bible_index 정본: (bcode,chapter) -> 정렬된 verse_id 리스트
    P("="*70)
    P("TIER 1 — 장별 절수 불일치 (정본 bible_index 대비 버전별 슬롯 커버리지)")
    P("="*70)

    q = "SELECT bcode, chapter, verse_id, verse FROM bible_index"
    if book_filter: q += f" WHERE bcode={book_filter}"
    q += " ORDER BY bcode, chapter, sort_order, verse"
    chapters = {}
    for bcode, ch, vid, vs in c.execute(q):
        chapters.setdefault((bcode, ch), []).append(vid)

    # 버전별 본문 보유 슬롯 집합 (전체 로드 1회)
    P("본문 로딩 중...")
    text = {}  # (vid, ver) -> text
    tq = "SELECT verse_id, version_code, verse_text FROM bible_content"
    if book_filter:
        tq = ("SELECT bc.verse_id, bc.version_code, bc.verse_text "
              "FROM bible_content bc JOIN bible_index bi ON bc.verse_id=bi.verse_id "
              f"WHERE bi.bcode={book_filter}")
    for vid, ver, t in c.execute(tq):
        text[(vid, ver)] = t

    gap_summary = {v: 0 for v in versions}     # 버전별 총 갭 슬롯
    tier1_rows = []
    for (bcode, ch), vids in sorted(chapters.items()):
        canon = len(vids)
        per = {}
        for ver in versions:
            filled = sum(1 for vid in vids if has_text(text.get((vid, ver))))
            per[ver] = filled
        # 정본 대비 부족한 버전만 기록 (커버리지 없는 언어=콥틱 NT_ONLY 등은 전량갭이라 별도표시)
        short = {ver: canon-per[ver] for ver in versions if per[ver] < canon}
        for ver, g in short.items():
            gap_summary[ver] += g
        # 콥틱(NT_ONLY)·부분버전 전량공백은 노이즈 → 갭이 정본의 90% 미만인 경우만 "부분 불일치"로
        partial = {ver: g for ver, g in short.items() if g < canon*0.9}
        if partial:
            tier1_rows.append((bcode, ch, canon, partial))

    P(f"\n[버전별 총 갭 슬롯 수 — 정본 {sum(len(v) for v in chapters.values())}절 대비]")
    for ver in sorted(versions, key=lambda v: -gap_summary[v]):
        P(f"  {ver:8} 갭 {gap_summary[ver]}")

    P(f"\n[부분 불일치 장 — 전량공백(콥틱 등) 제외, {len(tier1_rows)}개 장]")
    for bcode, ch, canon, partial in tier1_rows[:120]:
        bn = bname.get(bcode, str(bcode))
        ps = ', '.join(f"{ver} -{g}" for ver, g in sorted(partial.items()))
        P(f"  {bn} {ch}장 (정본 {canon}절): {ps}")
    if len(tier1_rows) > 120:
        P(f"  ... 외 {len(tier1_rows)-120}개 장 (리포트 파일 참조)")

    # ---- TIER 2 ----
    P("\n"+"="*70)
    P("TIER 2 — 같은 슬롯 내용 shift (동일 언어군 고유명사·숫자 이웃대조)")
    P("="*70)
    P("판정: 같은 verse_id에서 기준버전과 겹침이 낮고(<0.5), 이웃 절(±1)과의")
    P("      겹침이 더 높으면(+0.25 이상) → 경계 shift 후보. 철자차 견고(prefix4).")

    for lang, cluster in LANG_CLUSTERS.items():
        avail = [v for v in cluster if v in versions]
        if len(avail) < 2:
            continue
        ref = avail[0]
        others = avail[1:]
        P(f"\n--- {lang} 언어군: 기준={ref}, 대조={others} ---")
        flags = []
        for (bcode, ch), vids in sorted(chapters.items()):
            # 지문 사전
            fp = {}  # (vid,ver)->anchors
            for vid in vids:
                for ver in avail:
                    fp[(vid, ver)] = anchors(text.get((vid, ver)))
            for i, vid in enumerate(vids):
                ra = fp[(vid, ref)]
                if len(ra) < 2:   # 고유명사 거의 없는 절은 판정 불가 (서사 무명절)
                    continue
                prev_vid = vids[i-1] if i > 0 else None
                next_vid = vids[i+1] if i < len(vids)-1 else None
                # 반복 단락 가드: 기준버전 자신이 이웃과 앵커를 많이 공유하면(반복 서술)
                # 이웃겹침은 무의미 → 오탐. 이런 절은 건너뛴다.
                rp = fp[(prev_vid, ref)] if prev_vid else set()
                rn = fp[(next_vid, ref)] if next_vid else set()
                if jac(ra, rp) > 0.34 or jac(ra, rn) > 0.34:
                    continue
                for ver in others:
                    if not has_text(text.get((vid, ver))): continue
                    a_self = jac(ra, fp[(vid, ver)])
                    a_prev = jac(ra, fp[(prev_vid, ver)]) if prev_vid else 0
                    a_next = jac(ra, fp[(next_vid, ver)]) if next_vid else 0
                    best_nb = max(a_prev, a_next)
                    if a_self < 0.5 and best_nb > a_self + 0.25 and best_nb > 0.5:
                        direction = 'prev' if a_prev >= a_next else 'next'
                        flags.append((bcode, ch, vid, ver, round(a_self,2),
                                      round(best_nb,2), direction))
        P(f"  shift 후보: {len(flags)}건")
        # 책·장별 집계 (연속 shift = 진짜 경계차 신호)
        bych = {}
        for bcode, ch, vid, ver, s, nb, d in flags:
            bych.setdefault((bcode, ch), []).append((vid, ver, s, nb, d))
        for (bcode, ch), items in sorted(bych.items(), key=lambda x:-len(x[1]))[:40]:
            bn = bname.get(bcode, str(bcode))
            P(f"    {bn} {ch}장: {len(items)}건  " +
              ', '.join(f"vid{v}/{ver}({s}->{nb} {d})" for v,ver,s,nb,d in items[:6]) +
              (' ...' if len(items) > 6 else ''))

    P("\n"+"="*70)
    P("주의: Tier 2 결과는 '후보'다. 철자변형·의역으로 인한 오탐 가능 →")
    P("      한 장에 여러 건이 연속하면 진짜 경계 shift 신호(족보 특히). 1~2건 산발은")
    P("      대개 오탐. 반드시 해당 절을 사람이 직접 대조 검수 후 versification_map 반영.")
    P("="*70)

    with open(OUT, 'w', encoding='utf-8') as f:
        f.write(out.getvalue())
    print(f"\n리포트 저장: {OUT}")

if __name__ == '__main__':
    main()
