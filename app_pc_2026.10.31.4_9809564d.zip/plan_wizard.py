# -*- coding: utf-8 -*-
"""plan_wizard.py — 「새 플랜 만들기」 마법사 (2026-10-15 · docs/1.txt 87·88 · `docs/My Plan Builder.txt`).

자리 = 묵상플랜 ▸ 「내 플랜」 탭 ▸ 「사용자 모드」 콤보 ▸ 새 플랜 만들기.
다섯 걸음 — ① 범위 ② 기간 ③ 나누는 단위 ④ 미리보기·일정 수정 ⑤ 이름·저장.

★ 계산은 `plan_build` 한 곳(마법사와 「내 플랜 수정하기」 창이 같은 문을 쓴다).
★ **[저장]을 눌러야 내 플랜이 생긴다** — 그전에는 DB 에 아무것도 안 쓴다(88-8 과 같은 원칙).
★ 밀린 날 처리(끝까지 이어 읽기 / 날짜에 맞추기)는 마법사에 없다 — 플랜을 **시작하는 사람**이 정한다.
★ 화면 모양은 시안(아티팩트 「내 플랜 만들기 마법사」)을 따른 **디자인 시범**이다 — 여백·글자 단계·카드.
  색은 전부 `ui_theme.C(역할)` · 글꼴은 `theme_font` 설정 글꼴(박지 않는다).
⚠ 요일(읽는 요일 · 주말 적게/많이)은 넣지 않는다 — 플랜의 날은 날짜가 아니라 차례(일차)라 어느 날이 주말인지 정할 수 없다(사용자 확정).
"""
import datetime
import sys
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import i18n
import plan_build as PB

T = i18n.t
STEPS = (('PW_S1', '범위'), ('PW_S2', '기간'), ('PW_S3', '나누는 단위'),
         ('PW_S4', '미리보기·일정 수정'), ('PW_S5', '이름·저장'))
WD = (('PW_MON', '월'), ('PW_TUE', '화'), ('PW_WED', '수'), ('PW_THU', '목'),
      ('PW_FRI', '금'), ('PW_SAT', '토'), ('PW_SUN', '일'))
A4 = {'KO': 1500, 'ZH': 1500, 'ZHT': 1500, 'JA': 1500, 'AR': 2500}


def C(role, dflt):
    try:
        import ui_theme
        return ui_theme.C(role) or dflt
    except Exception:
        return dflt


CIRCLED = '①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳'


def circled(n):
    return CIRCLED[n - 1] if n and 1 <= n <= len(CIRCLED) else '(%s)' % n


class OpsStrip(tk.Frame):
    """「바꾼 것」 띠 — 합치기·나누기 하나마다 번호 단추 하나. 누르면 그것이 「되돌릴 것」으로 선택된다(다시 누르면 풀림).

    마법사 ④와 「내 플랜 수정하기」 창이 함께 쓴다. `host` 는 색(c_*)·글꼴(f_*)을 가진 것(마법사 · 수정 창의 꾸러미).
    op = {'no', 'kind', 'at', 'text'} (plan_build.do_split / do_merge)."""

    @staticmethod
    def kind_word(op):
        if not op:
            return ''
        return T('PW_W_SPLIT', '나눔') if op.get('kind') == 'SPLIT' else T('PW_W_MERGE', '합침')

    def __init__(self, parent, host, on_pick=None):
        super().__init__(parent, bg=host.c_bg)
        self.h, self.on_pick = host, on_pick
        self._sel = None
        self._ops = []

    def selected(self):
        return self._sel

    def select(self, no):
        self._sel = no
        self._draw()

    def set(self, ops, sel=None):
        self._ops = list(ops)
        if sel is not None and any(o['no'] == sel for o in self._ops):
            self._sel = sel
        elif not any(o['no'] == self._sel for o in self._ops):
            self._sel = None
        self._draw()

    def _click(self, no):
        self._sel = None if self._sel == no else no
        self._draw()
        if callable(self.on_pick):
            self.on_pick(self._sel)

    def _draw(self):
        h = self.h
        for w in self.winfo_children():
            w.destroy()
        tk.Label(self, text=T('PW_OPS', '바꾼 것'), font=h.f_bold, bg=h.c_bg, fg=h.c_fg).pack(side='left', padx=(0, 8))
        if not self._ops:
            tk.Label(self, text=T('PW_OPS_NONE', '아직 없음'), font=h.f_small, bg=h.c_bg, fg=h.c_dim).pack(side='left')
            return
        for op in self._ops:
            on = op['no'] == self._sel
            tk.Button(self, text='%s %s' % (circled(op['no']), op.get('text') or ''), relief='flat', bd=0,
                      padx=10, pady=3, cursor='hand2', font=h.f_bold if on else h.f_small,
                      bg=h.c_acc if on else h.c_ok, fg=h.c_ondark if on else h.c_fg, activebackground=h.c_sel,
                      command=lambda n=op['no']: self._click(n)).pack(side='left', padx=(0, 6))


class PlanWizard(tk.Toplevel):
    def __init__(self, parent, db_path, lang='KO', on_saved=None):
        super().__init__(parent)
        self.db_path, self.lang, self.on_saved = db_path, (lang or 'KO').upper(), on_saved
        self.title(T('PW_TITLE', '새 플랜 만들기'))
        self.geometry('1180x760')
        self.minsize(900, 600)
        self._ver = PB.version_of(self.lang)
        self._a4 = A4.get(self.lang, 3000)
        self._fonts()
        self._colors()
        self.configure(bg=self.c_bg)
        self.step = 0
        self.books = set()
        self.scope_v = tk.StringVar(value='')
        self.mode_v = tk.StringVar(value='DAYS')
        self.days_v = tk.StringVar(value='30')
        self.until_v = tk.StringVar(value='%d-12-31' % datetime.date.today().year)
        self.wd = [tk.BooleanVar(value=True) for _ in range(7)]
        self.unit_v = tk.StringVar(value='PERI')
        self.cap_v = tk.StringVar(value='0')
        self.capn_v = tk.StringVar(value='')
        self.name_v = tk.StringVar(value='')
        self.notes_v = tk.BooleanVar(value=False)
        self.days = []
        self._ops = []
        self._op_no = 0
        self._sig = None
        self._load_stats()
        self._build()
        self._show()
        # ⚠ `ui_theme.adopt` 를 부르지 않는다 — 색은 여기서 전부 역할로 넣었다. adopt 의 다시 칠하기가
        #   강조색 단추 바탕(accent)을 바탕 역할로 잘못 읽어 흐린 회색으로 바꿨다(화면을 찍어 확인 · 2026-10-15).
        self.protocol('WM_DELETE_WINDOW', self._close)

    # ── 모양 ──────────────────────────────────────────────────────────────
    def _fonts(self):
        fam, size = '', 11
        try:
            import theme_font
            f = theme_font.resolve(self.db_path, 'ui')
            fam = theme_font.resolve_family(f.get('family') or 'Malgun Gothic')
            size = int(f.get('size') or 11)
        except Exception:
            pass
        self.f_body = (fam, size)
        self.f_bold = (fam, size, 'bold')
        self.f_small = (fam, max(8, size - 1))
        self.f_head = (fam, size + 3, 'bold')
        self.f_big = (fam, size + 7, 'bold')

    def _colors(self):
        self.c_bg = C('bg', '#F4F7FA')
        self.c_card = C('panel', '#FFFFFF')
        self.c_alt = C('panel_alt', '#F0F4F8')
        self.c_line = C('border', '#D5DEE7')
        self.c_fg = C('fg', '#2C3E50')
        self.c_dim = C('fg_dim', '#6B7B8C')
        self.c_acc = C('accent', '#1A5276')
        self.c_accbg = C('accent_bg', '#D6EAF8')
        self.c_sel = C('select_bg', '#D6EAF8')
        self.c_ok = C('success_bg', '#E3F2E9')
        self.c_okfg = C('success', '#1E7A46')
        self.c_warn = C('warning_bg', '#FFF4D6')
        self.c_warnfg = C('warning', '#B2541A')
        self.c_dark = C('dark_bg', '#1A5276')
        self.c_ondark = C('fg_on_dark', '#FFFFFF')

    def _card(self, parent, **kw):
        return tk.Frame(parent, bg=self.c_card, highlightthickness=1, highlightbackground=self.c_line,
                        padx=kw.pop('padx', 14), pady=kw.pop('pady', 12), **kw)

    def _lbl(self, parent, text, font=None, fg=None, bg=None, **kw):
        return tk.Label(parent, text=text, font=font or self.f_body, fg=fg or self.c_fg,
                        bg=bg if bg is not None else parent.cget('bg'), **kw)

    def _btn(self, parent, text, cmd, primary=False, **kw):
        return tk.Button(parent, text=text, command=cmd, font=self.f_bold if primary else self.f_body,
                         bg=self.c_acc if primary else self.c_card,
                         fg=self.c_ondark if primary else self.c_fg,
                         activebackground=self.c_sel, activeforeground=self.c_fg,
                         relief='flat', bd=0, padx=14, pady=5, cursor='hand2',
                         highlightthickness=0 if primary else 1, highlightbackground=self.c_line, **kw)

    def _entry(self, parent, var, **kw):
        return tk.Entry(parent, textvariable=var, font=self.f_body, bg=self.c_card, fg=self.c_fg,
                        insertbackground=self.c_fg, relief='flat', highlightthickness=1,
                        highlightbackground=self.c_line, highlightcolor=self.c_acc, **kw)

    def _chip(self, parent, text, on, cmd):
        return tk.Button(parent, text=text, command=cmd, font=self.f_bold if on else self.f_body,
                         bg=self.c_sel if on else self.c_card, fg=self.c_acc if on else self.c_fg,
                         activebackground=self.c_sel, relief='flat', bd=0, padx=9, pady=3, cursor='hand2',
                         highlightthickness=2 if on else 1,
                         highlightbackground=self.c_acc if on else self.c_line)

    # ── 자료 ──────────────────────────────────────────────────────────────
    def _load_stats(self):
        """책마다 (이름, 장 수, 절 수, 단락 수, 글자 수) — 1단계 오른쪽 요약이 바로 쓴다."""
        self.stat = {}
        with appdb.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT b.bcode, COUNT(DISTINCT b.chapter), COUNT(*), "
                "SUM(COALESCE(LENGTH(REPLACE(REPLACE(c.verse_text,' ',''),char(10),'')),0)) "
                "FROM bible_index b LEFT JOIN bible_content c ON c.verse_id=b.verse_id AND c.version_code=? "
                "WHERE b.bcode BETWEEN 1 AND 66 GROUP BY b.bcode", (self._ver,)).fetchall()
            peri = dict(conn.execute(
                "SELECT b.bcode, COUNT(*) FROM sys_pericope_asset p JOIN bible_index b ON b.verse_id=p.start_vid "
                "WHERE p.peri_type='BODY' AND COALESCE(p.record_status,'LIVE')='LIVE' GROUP BY b.bcode").fetchall())
            for bc, ch, vs, n in rows:
                self.stat[bc] = {'name': PB._book_name(conn, bc, self.lang), 'ch': ch, 'vs': vs,
                                 'peri': peri.get(bc, 0), 'n': n or 0}

    # ── 뼈대 ──────────────────────────────────────────────────────────────
    def _build(self):
        top = tk.Frame(self, bg=self.c_dark, height=36)
        top.pack(fill='x')
        top.pack_propagate(False)
        self._lbl(top, T('PW_TITLE', '새 플랜 만들기'), self.f_bold, self.c_ondark, self.c_dark).pack(side='left', padx=14)
        bar = tk.Frame(self, bg=self.c_card, highlightthickness=1, highlightbackground=self.c_line)
        bar.pack(fill='x')
        self._steps = []
        for i, (k, ko) in enumerate(STEPS):
            if i:
                self._lbl(bar, '›', fg=self.c_dim).pack(side='left')
            w = tk.Label(bar, text='%s %s' % ('①②③④⑤'[i], T(k, ko)), font=self.f_body, padx=10, pady=4)
            w.pack(side='left', padx=2, pady=8)
            self._steps.append(w)
        self._b_close = self._btn(bar, T('COMMON_CLOSE', '닫기'), self._close)
        self._b_close.pack(side='right', padx=(4, 12))
        self._b_next = self._btn(bar, T('PW_NEXT', '다음'), self._next, primary=True)
        self._b_next.pack(side='right', padx=4)
        self._b_prev = self._btn(bar, T('PW_PREV', '이전'), self._prev)
        self._b_prev.pack(side='right', padx=4)
        self._body = tk.Frame(self, bg=self.c_bg)
        self._body.pack(fill='both', expand=True, padx=16, pady=14)
        self._msg = self._lbl(self, '', fg=self.c_warnfg, anchor='w')
        self._msg.pack(fill='x', padx=18, pady=(0, 8))

    def _say(self, text, warn=True):
        self._msg.config(text=text, fg=self.c_warnfg if warn else self.c_okfg)

    def _show(self):
        for w in self._body.winfo_children():
            w.destroy()
        self._say('')
        for i, w in enumerate(self._steps):
            if i == self.step:
                w.config(bg=self.c_acc, fg=self.c_ondark, font=self.f_bold)
            else:
                w.config(bg=self.c_card, fg=self.c_acc if i < self.step else self.c_dim, font=self.f_body)
        self._b_prev.config(state='normal' if self.step else 'disabled')
        last = self.step == len(STEPS) - 1
        self._b_next.config(text=T('PW_SAVE', '저장') if last else T('PW_NEXT', '다음'),
                            bg=self.c_okfg if last else self.c_acc)
        (self._s1, self._s2, self._s3, self._s4, self._s5)[self.step]()

    def _next(self):
        if self.step == 0 and not self.books:
            self._say(T('PW_NOBOOK', '읽을 책을 하나 이상 선택하세요'))
            return
        if self.step == 1 and self._ndays() < 1:
            self._say(T('PW_NODAY', '읽는 날이 하루도 없습니다 — 기간이나 요일을 확인하세요'))
            return
        if self.step == len(STEPS) - 1:
            self._save()
            return
        self.step += 1
        self._show()

    def _prev(self):
        if self.step:
            self.step -= 1
            self._show()

    def _close(self):
        if self.days and not messagebox.askyesno(T('PW_TITLE', '새 플랜 만들기'),
                                                 T('PW_CLOSE_Q', '저장하지 않고 닫을까요? 만든 일정은 남지 않습니다.'),
                                                 parent=self):
            return
        self.destroy()

    # ── ① 범위 ───────────────────────────────────────────────────────────
    #   2026-10-15 사용자 「신약구약 분류가 의미없다 · 모세오경 등 분류는 유지 · 상하 배치 · 가운데 책 목록을 정경순 상하로 ·
    #   체크상자 제거 · 목록에서 선택하면 색상반전 · 오른쪽 요약은 좋다」.
    #   왼쪽 = 분류(위→아래 · 누르면 그 책들을 한꺼번에 선택/해제) · 가운데 = 66권 목록(누르면 선택 · 다시 누르면 해제) · 오른쪽 = 요약.
    def _toggle_genre(self, lo, hi):
        g = set(range(lo, hi + 1))
        self.books = (self.books - g) if g <= self.books else (self.books | g)
        self._sync1()

    def _on_book_list(self, _e=None):
        self.books = {i + 1 for i in self._bk_lb.curselection()}
        self._sync1(from_list=True)

    def _s1(self):
        b = self._body
        left = tk.Frame(b, bg=self.c_bg)
        left.pack(side='left', fill='y')
        self._lbl(left, T('PW_Q1', '무엇을 읽을까요?'), self.f_head).pack(anchor='w')
        self._lbl(left, T('PW_GENRE_HINT2', '분류를 누르면 그 안의 책이\n한꺼번에 선택됩니다'), self.f_small,
                  self.c_dim, justify='left').pack(anchor='w', pady=(8, 6))
        self._genre_btns = []
        for key, ko, lo, hi in PB.GENRES:
            w = tk.Button(left, text=T('PW_G_' + key, ko), anchor='w', relief='flat', bd=0, padx=12, pady=5,
                          cursor='hand2', command=lambda lo=lo, hi=hi: self._toggle_genre(lo, hi))
            w.pack(fill='x', pady=(0, 3))
            self._genre_btns.append((w, lo, hi))
        mid = tk.Frame(b, bg=self.c_bg)
        mid.pack(side='left', fill='both', expand=True, padx=(16, 0))
        self._lbl(mid, T('PW_BOOKS', '책 — 누르면 선택, 다시 누르면 해제'), self.f_bold).pack(anchor='w')
        wrap = tk.Frame(mid, bg=self.c_card, highlightthickness=1, highlightbackground=self.c_line)
        wrap.pack(fill='both', expand=True, pady=(8, 0))
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        lb = tk.Listbox(wrap, selectmode='multiple', exportselection=False, activestyle='none', font=self.f_body,
                        bg=self.c_card, fg=self.c_fg, selectbackground=self.c_acc, selectforeground=self.c_ondark,
                        highlightthickness=0, bd=0, relief='flat', yscrollcommand=vsb.set)
        vsb.config(command=lb.yview)
        lb.pack(fill='both', expand=True, padx=6, pady=6)
        for bc in range(1, 67):
            st = self.stat.get(bc, {})
            lb.insert('end', '  %s' % st.get('name', str(bc)))
        lb.bind('<<ListboxSelect>>', self._on_book_list)
        self._bk_lb = lb
        self._lbl(mid, T('PW_ORDER_HINT', '여러 권을 선택하면 성경 차례대로 읽습니다'), self.f_small,
                  self.c_dim).pack(anchor='w', pady=(6, 0))
        right = self._card(b, width=230)
        right.pack(side='right', fill='y', padx=(14, 0), anchor='n', before=left)
        right.pack_propagate(False)
        self._lbl(right, T('PW_SEL_RANGE', '선택한 범위'), self.f_small, self.c_dim).pack(anchor='w')
        self._sum1_name = self._lbl(right, '', self.f_big, self.c_acc, wraplength=200, justify='left')
        self._sum1_name.pack(anchor='w', pady=(4, 6))
        self._sum1_body = self._lbl(right, '', justify='left', wraplength=200)
        self._sum1_body.pack(anchor='w')
        self._sum1_a4 = self._lbl(right, '', self.f_small, self.c_dim, justify='left', wraplength=200)
        self._sum1_a4.pack(anchor='w', pady=(10, 0))
        self._sync1()
        if self.books:
            lb.see(min(self.books) - 1)

    def _sync1(self, from_list=False):
        """목록 선택·분류 단추 모양·요약을 지금 고른 책에 맞춘다."""
        if not from_list:
            lb = self._bk_lb
            lb.selection_clear(0, 'end')
            for bc in self.books:
                lb.selection_set(bc - 1)
            if self.books:
                lb.see(min(self.books) - 1)
        for w, lo, hi in self._genre_btns:
            on = set(range(lo, hi + 1)) <= self.books
            part = not on and bool(set(range(lo, hi + 1)) & self.books)
            w.config(bg=self.c_acc if on else (self.c_sel if part else self.c_card),
                     fg=self.c_ondark if on else self.c_fg, font=self.f_bold if on or part else self.f_body,
                     activebackground=self.c_sel)
        self._sum1()

    def _range_name(self):
        bs = sorted(self.books)
        if not bs:
            return T('PW_NONE', '(아직 없음)')
        if set(bs) == set(range(1, 67)):
            return T('PW_ALL', '성경 전체')
        if set(bs) == set(PB.OT):
            return T('PW_OT', '구약')
        if set(bs) == set(PB.NT):
            return T('PW_NT', '신약')
        names = [self.stat[b]['name'] for b in bs if b in self.stat]
        return names[0] if len(names) == 1 else '%s ~ %s' % (names[0], names[-1]) if bs == list(
            range(bs[0], bs[-1] + 1)) else T('PW_NBOOKS', '%d권') % len(names)

    def _totals(self):
        s = [self.stat[b] for b in self.books if b in self.stat]
        return (len(s), sum(x['ch'] for x in s), sum(x['vs'] for x in s), sum(x['peri'] for x in s),
                sum(x['n'] for x in s))

    def _sum1(self):
        nb, ch, vs, pe, n = self._totals()
        self._sum1_name.config(text=self._range_name())
        self._sum1_body.config(text=T('PW_SUM1', '%d권 · %s장 · %s절\n단락 %s개\n본문 %s자 (공백 제외)') % (
            nb, '{:,}'.format(ch), '{:,}'.format(vs), '{:,}'.format(pe), '{:,}'.format(n)))
        self._sum1_a4.config(text=T('PW_A4', 'A4 한 장은 약 %s자입니다 — 모두 A4 약 %s장') % (
            '{:,}'.format(self._a4), '{:,}'.format(round(n / self._a4)) if n else '0'))

    # ── ② 기간 ───────────────────────────────────────────────────────────
    def _ndays(self):
        wd = tuple(i for i, v in enumerate(self.wd) if v.get())
        try:
            if self.mode_v.get() == 'UNTIL':
                return PB.reading_days('UNTIL', self.until_v.get().strip(), wd)
            return PB.reading_days('DAYS', int(self.days_v.get()), wd)
        except Exception:
            return 0

    def _s2(self):
        b = self._body
        left = tk.Frame(b, bg=self.c_bg)
        left.pack(side='left', fill='both', expand=True)
        self._lbl(left, T('PW_Q2', '얼마 동안 읽을까요?'), self.f_head).pack(anchor='w')
        c = self._card(left)
        c.pack(fill='x', pady=(10, 16))
        r1 = tk.Frame(c, bg=self.c_card)
        r1.pack(anchor='w', pady=(0, 8))
        tk.Radiobutton(r1, text=T('PW_FOR', '며칠 동안'), variable=self.mode_v, value='DAYS', font=self.f_bold,
                       bg=self.c_card, fg=self.c_fg, selectcolor=self.c_card, activebackground=self.c_card,
                       command=self._sum2).pack(side='left')
        for d, lab in ((7, '7'), (30, '30'), (90, '90'), (365, '365')):
            on = self.days_v.get() == str(d) and self.mode_v.get() == 'DAYS'
            self._chip(r1, T('PW_DAYS_N', '%s일') % lab, on,
                       lambda d=d: (self.mode_v.set('DAYS'), self.days_v.set(str(d)), self._show())
                       ).pack(side='left', padx=(8, 0))
        e = self._entry(r1, self.days_v, width=6, justify='right')
        e.pack(side='left', padx=(12, 2))
        e.bind('<KeyRelease>', lambda _e: (self.mode_v.set('DAYS'), self._sum2()))
        self._lbl(r1, T('PW_DAY_UNIT', '일')).pack(side='left')
        r2 = tk.Frame(c, bg=self.c_card)
        r2.pack(anchor='w')
        tk.Radiobutton(r2, text=T('PW_UNTIL', '언제까지'), variable=self.mode_v, value='UNTIL', font=self.f_bold,
                       bg=self.c_card, fg=self.c_fg, selectcolor=self.c_card, activebackground=self.c_card,
                       command=self._sum2).pack(side='left')
        e2 = self._entry(r2, self.until_v, width=12)
        e2.pack(side='left', padx=(12, 8))
        e2.bind('<KeyRelease>', lambda _e: (self.mode_v.set('UNTIL'), self._sum2()))
        self._lbl(r2, T('PW_UNTIL_HINT', '오늘부터 그날까지 읽는 날을 세어 나눕니다 (예: 2026-12-31)'), self.f_small,
                  self.c_dim, bg=self.c_card).pack(side='left')
        # ★ 2026-10-15 사용자 「요일 구분을 못한다고 하니까 제거」 — 읽는 요일을 걷었다(날마다 읽는 것으로 센다).
        note = tk.Label(left, text=T('PW_NOTE3', '여기서 정한 기간은 하루 분량을 나누는 계산에만 씁니다.\n'
                                              '실제로 언제 시작할지는 플랜을 시작할 때 정합니다.'),
                        font=self.f_small, fg=self.c_acc, bg=self.c_accbg, justify='left', anchor='w',
                        padx=12, pady=8)
        note.pack(fill='x', pady=(16, 0))
        right = self._card(b, width=230)
        right.pack(side='right', fill='y', padx=(14, 0), anchor='n', before=left)
        right.pack_propagate(False)
        self._lbl(right, T('PW_CALC', '계산 결과'), self.f_small, self.c_dim).pack(anchor='w')
        self._sum2_big = self._lbl(right, '', self.f_big, self.c_acc)
        self._sum2_big.pack(anchor='w', pady=(4, 6))
        self._sum2_body = self._lbl(right, '', justify='left', wraplength=200)
        self._sum2_body.pack(anchor='w')
        self._sum2()

    def _sum2(self):
        nd = self._ndays()
        n = self._totals()[4]
        self._sum2_big.config(text=T('PW_NDAYS', '읽는 날 %s일') % '{:,}'.format(nd))
        if nd:
            avg = n // nd
            self._sum2_body.config(text=T('PW_SUM2', '%s %s자\n하루 평균 %s자\nA4 약 %.1f장') % (
                self._range_name(), '{:,}'.format(n), '{:,}'.format(avg), avg / self._a4))
        else:
            self._sum2_body.config(text='')

    # ── ③ 나누는 단위 ────────────────────────────────────────────────────
    def _s3(self):
        b = self._body
        self._lbl(b, T('PW_Q3', '하루 몫을 어떤 단위로 묶을까요?'), self.f_head).pack(anchor='w')
        row = tk.Frame(b, bg=self.c_bg)
        row.pack(fill='x', pady=(10, 14))
        row.columnconfigure(0, weight=1, uniform='u')
        row.columnconfigure(1, weight=1, uniform='u')
        for col, (k, key, ko, desc, pros, cons, ex) in enumerate((
                ('CHAP', 'PW_U_CHAP', '장 단위', T('PW_U_CHAP_D', '하루에 한 장, 두 장처럼 장을 통째로 읽습니다.'),
                 [T('PW_U_CHAP_P', '익숙하고 단순합니다')],
                 [T('PW_U_CHAP_C', '장마다 길이 차이가 큽니다 (시편 117편 2절 · 119편 176절)')],
                 T('PW_U_CHAP_E', '예) 1일차 롬 1장 · 2일차 롬 2장')),
                ('PERI', 'PW_U_PERI', '단락 단위',
                 T('PW_U_PERI_D', '이야기나 생각이 한 덩어리인 단락으로 묶습니다. 날마다 단락 제목이 붙습니다.'),
                 [T('PW_U_PERI_P1', '흐름이 중간에 끊기지 않습니다'), T('PW_U_PERI_P2', '하루 분량을 고르게 맞추기 쉽습니다')],
                 [], T('PW_U_PERI_E', '예) 1일차 롬 1:1-17 「복음을 부끄러워하지 않음」')))):
            on = self.unit_v.get() == k
            c = tk.Frame(row, bg=self.c_card, highlightthickness=2 if on else 1,
                         highlightbackground=self.c_acc if on else self.c_line, padx=14, pady=12, cursor='hand2')
            c.grid(row=0, column=col, sticky='nsew', padx=(0, 8) if col == 0 else (8, 0))
            hd = tk.Radiobutton(c, text=T(key, ko), variable=self.unit_v, value=k, font=self.f_head,
                                bg=self.c_card, fg=self.c_acc if on else self.c_fg, selectcolor=self.c_card,
                                activebackground=self.c_card, command=self._show)
            hd.pack(anchor='w')
            self._lbl(c, desc, wraplength=420, justify='left').pack(anchor='w', pady=(4, 6))
            for p in pros:
                self._lbl(c, '✓ ' + p, fg=self.c_okfg).pack(anchor='w')
            for p in cons:
                self._lbl(c, '✕ ' + p, fg=self.c_warnfg, wraplength=420, justify='left').pack(anchor='w')
            tk.Label(c, text=ex, font=self.f_small, bg=self.c_alt, fg=self.c_dim, anchor='w', padx=8,
                     pady=6).pack(fill='x', pady=(8, 0))
            for w in (c,):
                w.bind('<Button-1>', lambda _e, k=k: (self.unit_v.set(k), self._show()))
        c = self._card(b)
        c.pack(fill='x')
        self._lbl(c, T('PW_CAP', '하루 분량 상한 (선택)'), self.f_bold, bg=self.c_card).pack(anchor='w')
        r = tk.Frame(c, bg=self.c_card)
        r.pack(anchor='w', pady=(8, 6))
        for v, key, ko in (('0', 'PW_CAP0', '정하지 않음'), (str(self._a4), 'PW_CAP1', 'A4 1장'),
                           (str(self._a4 * 2), 'PW_CAP2', 'A4 2장'), ('X', 'PW_CAPX', '직접')):
            tk.Radiobutton(r, text=T(key, ko) + ('' if v in ('0', 'X') else ' (%s자)' % '{:,}'.format(int(v))),
                           variable=self.cap_v, value=v, font=self.f_body, bg=self.c_card, fg=self.c_fg,
                           selectcolor=self.c_card, activebackground=self.c_card).pack(side='left', padx=(0, 14))
        e = self._entry(r, self.capn_v, width=7, justify='right')
        e.pack(side='left')
        e.bind('<KeyRelease>', lambda _e: self.cap_v.set('X'))
        self._lbl(r, T('PW_CHAR_UNIT', '자'), bg=self.c_card).pack(side='left', padx=(2, 0))
        self._lbl(c, T('PW_CAP_HINT', '분량은 장 수가 아니라 글자 수(공백 제외)로 고르게 맞춥니다. '
                                     '장이나 단락은 중간에서 자르지 않고, 넘치면 다음 날로 넘깁니다.'),
                  self.f_small, self.c_dim, bg=self.c_card, wraplength=900, justify='left').pack(anchor='w')

    def _cap(self):
        v = self.cap_v.get()
        if v == 'X':
            try:
                return max(100, int(self.capn_v.get()))
            except Exception:
                return None
        return int(v) or None

    # ── ④ 미리보기·일정 수정 ─────────────────────────────────────────────
    #   2026-10-15 사용자 「되돌릴 대상을 선택하지도 않았는데 순서대로 되돌린다 · 선택하지 않으면 메시지 ·
    #   색상반전으로는 부족하고 명확하게 항목 구분」 ⇒ 합치기·나누기 하나하나가 **번호 붙은 「바꾼 것」**이 된다
    #   (①②… · 표의 「바꾼 것」 칸에 그 번호 · 위 띠에 번호 단추). 되돌릴 것을 선택하고 [↶ 되돌리기] —
    #   **그것 하나만** 되돌린다(절로 기억하므로 다른 바꾼 것은 그대로 · plan_build.undo_op).
    def _compute(self):
        sig = (tuple(sorted(self.books)), self._ndays(), self.unit_v.get(), self._cap())
        if sig == self._sig and self.days:
            return
        with appdb.connect(self.db_path) as conn:
            us = PB.units(conn, self.books, self.unit_v.get(), self._ver, self.lang)
            groups = PB.distribute(us, sig[1], sig[3])
            self.days = PB.to_days(conn, groups)
        self._ops = []
        self._op_no = 0
        self._sig = sig

    def _s4(self):
        self._compute()
        b = self._body
        hd = tk.Frame(b, bg=self.c_bg)
        hd.pack(fill='x')
        self._lbl(hd, T('PW_Q4', '날마다 읽을 곳'), self.f_head).pack(side='left')
        self._s4_sum = self._lbl(hd, '', fg=self.c_dim)
        self._s4_sum.pack(side='left', padx=12)
        act = tk.Frame(b, bg=self.c_bg)
        act.pack(fill='x', pady=(10, 6))
        self._btn(act, T('PW_MERGE', '다음 날과 합치기'), self._merge).pack(side='left', padx=(0, 6))
        self._btn(act, T('PW_SPLIT', '둘로 나누기'), self._split).pack(side='left', padx=(0, 6))
        self._btn(act, T('PW_UNDO', '↶ 되돌리기'), self._undo).pack(side='left', padx=(0, 6))
        self._lbl(act, T('PW_PICK_DAY2', '합치기·나누기 = 날을 선택하고 · 되돌리기 = 아래 「바꾼 것」 번호를 선택하고'),
                  fg=self.c_dim).pack(side='left', padx=8)
        self._strip = OpsStrip(b, self, on_pick=self._on_op_pick)
        self._strip.pack(fill='x', pady=(0, 8))
        wrap = tk.Frame(b, bg=self.c_card, highlightthickness=1, highlightbackground=self.c_line)
        wrap.pack(fill='both', expand=True)
        st = ttk.Style()
        st.configure('PW.Treeview', rowheight=int(self.f_body[1] * 2.6), font=self.f_body,
                     background=self.c_card, fieldbackground=self.c_card, foreground=self.c_fg)
        st.configure('PW.Treeview.Heading', font=self.f_small, background=self.c_alt, foreground=self.c_dim,
                     relief='flat')
        st.map('PW.Treeview.Heading', background=[('active', self.c_sel)])
        st.map('PW.Treeview', background=[('selected', self.c_acc)], foreground=[('selected', self.c_ondark)])
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        tv = ttk.Treeview(wrap, columns=('d', 'c', 'r', 't', 'n'), show='headings', style='PW.Treeview',
                          selectmode='browse', yscrollcommand=vsb.set)
        vsb.config(command=tv.yview)
        for col, key, ko, w, st_ in (('d', 'PW_C_DAY', '일차', 56, False), ('c', 'PW_C_OP', '바꾼 것', 110, False),
                                     ('r', 'PW_C_REF', '읽을 곳', 160, False),
                                     ('t', 'PW_C_TITLE', '단락 제목', 380, True), ('n', 'PW_C_N', '글자', 160, False)):
            tv.heading(col, text=T(key, ko), anchor='w')
            tv.column(col, width=w, stretch=st_, anchor='w')
        tv.tag_configure('warn', background=self.c_warn)
        tv.tag_configure('op', background=self.c_ok)
        tv.tag_configure('opsel', background=self.c_sel, font=self.f_bold)
        tv.pack(fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_row)
        self._tv = tv
        self._lbl(b, T('PW_S4_HINT', '[둘로 나누기]는 두 쪽 글자 수가 가장 비슷해지는 자리를 저절로 찾습니다(단락 경계 먼저, '
                                    '단락이 하나면 절). 날 추가·지우기와 순서 바꾸기, 읽을 곳 직접 적기는 저장한 뒤 '
                                    '[수정하기] 창에서 합니다.'),
                  self.f_small, self.c_dim, wraplength=1000, justify='left').pack(anchor='w', pady=(8, 0))
        self._fill4()

    def _op_map(self, conn):
        """날 번호 → 그 날에 걸린 바꾼 것 번호들."""
        m = {}
        for op in self._ops:
            for i in PB.op_days(conn, self.days, op):
                m.setdefault(i, []).append(op['no'])
        return m

    def _fill4(self, sel=None):
        tv = self._tv
        self._filling = True
        tv.delete(*tv.get_children())
        cur = self._strip.selected()
        with appdb.connect(self.db_path) as conn:
            ns = [PB.day_n(conn, self._ver, dd) for dd in self.days]
            avg = (sum(ns) / len(ns)) if ns else 0
            mx = max(ns) if ns else 1
            om = self._op_map(conn)
            for i, (dd, n) in enumerate(zip(self.days, ns)):
                bar = '▇' * max(1, round(10 * n / mx)) if n else ''
                nos = om.get(i, [])
                tags = ('opsel',) if cur in nos else (('op',) if nos else
                                                       (('warn',) if avg and abs(n - avg) > 0.5 * avg else ()))
                tv.insert('', 'end', iid=str(i), tags=tags,
                          values=(i + 1, ' '.join('%s %s' % (circled(k), OpsStrip.kind_word(self._op(k)))
                                                  for k in nos),
                                  ' · '.join(r.get('ref') or '' for r in dd.get('r') or []),
                                  PB.titles(conn, dd, self.lang), '%s  %s' % (bar, '{:,}'.format(n))))
        self._s4_sum.config(text=T('PW_S4_SUM', '%d일 · 하루 평균 %s자 · 노란 줄 = 평균보다 많이 길거나 짧은 날') % (
            len(self.days), '{:,}'.format(int(avg))))
        self._strip.set(self._ops, cur)
        if sel is not None and str(sel) in tv.get_children():
            tv.selection_set(str(sel))
            tv.see(str(sel))
        self.after_idle(lambda: setattr(self, '_filling', False))

    def _op(self, no):
        return next((o for o in self._ops if o['no'] == no), None)

    def _on_row(self, _e=None):
        """번호가 붙은 날을 선택하면 그 바꾼 것이 「되돌릴 것」으로 선택된다."""
        if getattr(self, '_filling', False):
            return
        s = self._tv.selection()
        if not s:
            return
        nos = [x for x in self._tv.set(s[0], 'c').split() if x in CIRCLED]
        if nos:
            self._strip.select(CIRCLED.index(nos[-1]) + 1)
            self._fill4(sel=int(s[0]))

    def _on_op_pick(self, _no):
        self._fill4()
        with appdb.connect(self.db_path) as conn:
            op = self._op(self._strip.selected())
            ds = PB.op_days(conn, self.days, op) if op else []
        if ds:
            self._tv.see(str(ds[0]))

    def _cur(self):
        s = self._tv.selection()
        if not s:
            self._say(T('PW_PICK_DAY', '날을 선택하고 누르세요'))
            return None
        return int(s[0])

    def _add_op(self, op, text):
        self._op_no += 1
        op.update(no=self._op_no, text=text)
        self._ops.append(op)          # ⚠ 저절로 선택하지 않는다 — 되돌릴 것은 사람이 고른다(2026-10-15 사용자)

    def _merge(self):
        i = self._cur()
        if i is None:
            return
        with appdb.connect(self.db_path) as conn:
            a, b2 = (PB.span(self.days[i]), PB.span(self.days[i + 1])) if i + 1 < len(self.days) else (None, None)
            nd, op = PB.do_merge(conn, [dict(d) for d in self.days], i)
            if nd is None:
                self._say(T('PW_LASTDAY', '마지막 날은 다음 날이 없어 합칠 수 없습니다'))
                return
            import plan_share as PS
            text = T('PW_OP_MERGE', '＋ %s · %s 합침') % (PS._ref(conn, a[0], a[1]), PS._ref(conn, b2[0], b2[1]))
        self.days = nd
        self._add_op(op, text)
        self._say(T('PW_DID', '%s 번으로 적어 두었습니다 — 되돌리려면 그 번호를 선택하고 [↶ 되돌리기]') % circled(op['no']), False)
        self._fill4(sel=i)

    def _split(self):
        i = self._cur()
        if i is None:
            return
        with appdb.connect(self.db_path) as conn:
            nd, op, info = PB.do_split(conn, self._ver, [dict(d) for d in self.days], i)
            if nd is None:
                self._say(T('PW_NOSPLIT', '이 날은 한 절뿐이라 나눌 수 없습니다'))
                return
            text = T('PW_OP_SPLIT', '✂ %s 뒤에서 나눔 (%s자 + %s자)') % (
                PB.ref_of(conn, info[0]), '{:,}'.format(info[1]), '{:,}'.format(info[2]))
        self.days = nd
        self._add_op(op, text)
        self._say(T('PW_DID', '%s 번으로 적어 두었습니다 — 되돌리려면 그 번호를 선택하고 [↶ 되돌리기]') % circled(op['no']), False)
        self._fill4(sel=i)

    def _undo(self):
        no = self._strip.selected()
        op = self._op(no) if no else None
        if op is None:
            self._say(T('PW_UNDO_PICK', '되돌릴 것을 먼저 선택하세요 — 「바꾼 것」의 번호를 누르거나, 표에서 번호가 붙은 날을 선택하세요'))
            return
        with appdb.connect(self.db_path) as conn:
            nd = PB.undo_op(conn, self._ver, [dict(d) for d in self.days], op)
        if nd is None:
            self._say(T('PW_UNDO_NO', '%s 은(는) 뒤에 바꾼 것과 겹쳐 되돌릴 수 없습니다 — 겹친 번호를 먼저 되돌리세요') % circled(no))
            return
        self.days = nd
        self._ops.remove(op)
        self._strip.select(None)
        self._say(T('PW_UNDONE2', '%s 을(를) 되돌렸습니다') % circled(no), False)
        self._fill4()

    # ── ⑤ 이름·저장 ──────────────────────────────────────────────────────
    def _s5(self):
        self._compute()
        b = self._body
        left = tk.Frame(b, bg=self.c_bg)
        left.pack(side='left', fill='both', expand=True)
        if not self.name_v.get().strip():
            self.name_v.set(T('PW_NAME_AUTO', '%s %d일') % (self._range_name(), len(self.days)))
        self._lbl(left, T('PW_NAME', '플랜 이름'), self.f_bold).pack(anchor='w')
        self._entry(left, self.name_v).pack(fill='x', pady=(4, 12), ipady=4)
        self._lbl(left, T('PW_DESC', '설명 (선택 · 공유할 때 받는 사람이 처음 보는 글)'), self.f_bold).pack(anchor='w')
        self._desc = tk.Text(left, height=4, wrap='word', font=self.f_body, padx=8, pady=6, bg=self.c_card, fg=self.c_fg,
                             insertbackground=self.c_fg, relief='flat', highlightthickness=1,
                             highlightbackground=self.c_line)
        self._desc.pack(fill='x', pady=(4, 12))
        if getattr(self, '_desc_txt', ''):
            self._desc.insert('1.0', self._desc_txt)
        c = self._card(left)
        c.pack(fill='x')
        tk.Checkbutton(c, text=T('PW_NOTES', '날마다 묵상 포인트·질문 쓰기'), variable=self.notes_v, font=self.f_bold,
                       bg=self.c_card, fg=self.c_fg, selectcolor=self.c_card, activebackground=self.c_card
                       ).pack(anchor='w')
        self._lbl(c, T('PW_NOTES_HINT', '공동체에 나눌 플랜이라면 켜 두세요. 저장하면 「내 플랜 수정하기」 창이 열려 날마다 '
                                       '구간 제목 · 묵상 포인트 · 묵상 질문을 적을 수 있고, 내보낸 파일에도 함께 들어갑니다.'),
                  self.f_small, self.c_dim, bg=self.c_card, wraplength=640, justify='left').pack(anchor='w', pady=(4, 0))
        tk.Label(left, text=T('PW_SAVE_NOTE', '[저장]을 눌러야 비로소 내 플랜이 생깁니다. 저장하지 않고 닫으면 아무것도 남지 않습니다.'),
                 font=self.f_small, fg=self.c_acc, bg=self.c_accbg, anchor='w', padx=12, pady=8
                 ).pack(fill='x', pady=(14, 0))
        right = self._card(b, width=280)
        right.pack(side='right', fill='y', padx=(14, 0), anchor='n', before=left)
        right.pack_propagate(False)
        self._lbl(right, T('PW_WILL', '만들 플랜'), self.f_small, self.c_dim).pack(anchor='w')
        with appdb.connect(self.db_path) as conn:
            tot = sum(PB.day_n(conn, self._ver, dd) for dd in self.days)
        self._lbl(right, '%s · %s · %d%s\n%s %s%s' % (
            self._range_name(), T('PW_U_PERI', '단락 단위') if self.unit_v.get() == 'PERI' else T('PW_U_CHAP', '장 단위'),
            len(self.days), T('PW_DAY_UNIT', '일'), T('PW_AVG', '하루 평균'),
            '{:,}'.format(tot // max(1, len(self.days))), T('PW_CHAR_UNIT', '자')),
            justify='left', wraplength=250, bg=self.c_card).pack(anchor='w', pady=(6, 0))

    def _save(self):
        name = self.name_v.get().strip()
        if not name:
            self._say(T('PW_NONAME', '플랜 이름을 적으세요'))
            return
        try:
            import plan_builder
            name = plan_builder.check_plan_name(name, self)
        except Exception:
            pass
        if not name:
            return
        desc = self._desc.get('1.0', 'end').strip() if hasattr(self, '_desc') else ''
        import plan_share as PS
        try:
            with appdb.connect(self.db_path) as conn:
                uid, _bad = PS.save_plan(conn, name, [dict(d) for d in self.days], desc=desc, lang=self.lang,
                                         char_limit=self._cap(), ptype='WIZARD')
                conn.commit()
        except ValueError as e:
            self._say(str(e))
            return
        self.saved_uid = uid
        notes = self.notes_v.get()
        parent = self.master
        self.days = []
        self.destroy()
        if callable(self.on_saved):
            self.on_saved(uid)
        if notes:
            try:
                import my_plan_edit
                my_plan_edit.MyPlanEditor(parent, self.db_path, uid, self.lang, on_saved=self.on_saved)
            except Exception as e:
                print('[wizard notes] %s' % e)


# ── 자가 검증 — 창을 띄워 다섯 걸음을 눌러 보고 저장 · 자국 0 ─────────────────
def selftest():
    sys.stdout.reconfigure(encoding='utf-8')
    ok = [0, 0]

    def t(name, cond, got=''):
        ok[1] += 1
        ok[0] += bool(cond)
        print(('  OK   ' if cond else '  FAIL ') + name, '' if cond else got)
    conn = appdb.connect()
    base = {tb: conn.execute('SELECT COALESCE(MAX(%s),0) FROM %s' % (pk, tb)).fetchone()[0]
            for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'),
                           ('user_text_asset', 'user_text_id'))}
    root = tk.Tk()
    root.withdraw()
    errs = []
    root.report_callback_exception = lambda *a: errs.append(a[1])
    got = []
    try:
        w = PlanWizard(root, 'bible_master.db', 'KO', on_saved=got.append)
        root.update()
        w._next()
        t('범위 없이 다음 → 막고 말한다', w.step == 0 and w._msg.cget('text'))
        w._bk_lb.selection_set(44)
        w._on_book_list()
        root.update()
        t('책 목록에서 선택 = 로마서 · 바울서신 분류는 일부 선택 모양', w.books == {45})
        w._toggle_genre(45, 57)
        t('분류를 누르면 그 책들이 목록에서도 선택된다', len(w._bk_lb.curselection()) == 13)
        w._toggle_genre(45, 57)
        w._bk_lb.selection_set(44)
        w._on_book_list()
        root.update()
        t('로마서 선택 → 요약', '로마서' in w._sum1_name.cget('text') and '47' in w._sum1_body.cget('text'),
          w._sum1_body.cget('text'))
        w._next()
        root.update()
        t('② 기간 — 30일', w._ndays() == 30 and '30' in w._sum2_big.cget('text'))
        t('요일 칸 없음', not any('요일' in str(x.cget('text')) for x in w._body.winfo_children()
                               if isinstance(x, tk.Label)))
        w._next()
        root.update()
        t('③ 단위 — 단락 기본', w.unit_v.get() == 'PERI')
        w._next()
        root.update()
        t('④ 미리보기 30일', len(w.days) == 30 and len(w._tv.get_children()) == 30, len(w.days))
        t('DB 에 아직 아무것도 없다', conn.execute('SELECT COALESCE(MAX(user_plan_id),0) FROM user_bible_plan').fetchone()[0]
          == base['user_bible_plan'])
        i17 = next(k for k, dd in enumerate(w.days) if dd['r'][0]['ref'].startswith('롬 9:6'))
        w._tv.selection_set(str(i17))
        w._split()
        root.update()
        t('둘로 나누기 → 31일 · ① · 표에 번호', len(w.days) == 31 and len(w._ops) == 1
          and '①' in w._tv.set(str(i17), 'c') and '①' in w._tv.set(str(i17 + 1), 'c'), w._tv.set(str(i17), 'c'))
        w._tv.selection_set('2')
        w._merge()
        root.update()
        t('다음 날과 합치기 → 30일 · ②', len(w.days) == 30 and len(w._ops) == 2 and '②' in w._tv.set('2', 'c'))
        w._strip.select(None)
        w._undo()
        t('되돌릴 것을 안 고르면 되돌리지 않고 말한다', len(w.days) == 30 and len(w._ops) == 2
          and '선택' in w._msg.cget('text'), w._msg.cget('text'))
        w._strip.select(1)
        w._undo()
        root.update()
        t('① 만 되돌림 → 29일 · ②는 남는다', len(w.days) == 29 and [o['no'] for o in w._ops] == [2], [o['no'] for o in w._ops])
        w._tv.selection_set('2')
        w._on_row()
        t('번호 붙은 날을 선택하면 그 번호가 되돌릴 것으로', w._strip.selected() == 2)
        w._undo()
        t('② 도 되돌림 → 30일', len(w.days) == 30 and not w._ops)
        w._tv.selection_set(str(i17 + 1))
        w._merge()
        t('다음 날과 합치기 → 29일', len(w.days) == 29)
        w._next()
        root.update()
        t('⑤ 이름 저절로', w.name_v.get().startswith('로마서'), w.name_v.get())
        w.name_v.set('[시험] 마법사 로마서')
        w._next()
        root.update()
        t('저장 → 내 플랜 하나 · 콜백', got and conn.execute(
            'SELECT plan_type FROM user_bible_plan WHERE user_plan_id=?', (got[0],)).fetchone()[0] == 'WIZARD')
        import plan_share as PS
        t('저장된 일정 29일', got and len(PS.days_of(conn, 'USER', got[0])) == 29)
        t('종류 = 만든 것(✎)', got and PS.kind_of(conn, got[0]) == 'MINE')
        t('Tk 오류 0', not errs, errs[:2])
    finally:
        c = appdb.connect()
        for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'),
                       ('user_text_asset', 'user_text_id')):
            c.execute('DELETE FROM %s WHERE %s>?' % (tb, pk), (base[tb],))
        c.commit()
        t('자국 0', sum(c.execute('SELECT COUNT(*) FROM %s WHERE %s>?' % (tb, pk), (base[tb],)).fetchone()[0]
                       for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'))) == 0)
        try:
            root.destroy()
        except Exception:
            pass
    print('plan_wizard selftest: %d/%d' % tuple(ok))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    sys.stdout.reconfigure(encoding='utf-8')
    print(__doc__)
