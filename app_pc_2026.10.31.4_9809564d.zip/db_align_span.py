# -*- coding: utf-8 -*-
"""**역본차이 구간** — 기준(BSB)과 내용이 어긋나는 자리 (2026-09-22 신설).

★★★ **왜 페리코프를 안 쓰나** (사용자 지시 「페리코프 방식을 폐기하고 제대로
  된 역본차이 식별용 페리코프 개념을 만들어라」).
  실측이 그 지시를 받친다 — **페리코프로 묶으면 중앙 11절**인데 **실제로
  어긋나는 구간은 중앙 1절 · 평균 1.4절**이다(아래 실측). 4~11배 과하다.
  페리코프는 「단락을 요약하는 자리」이고 여기는 「경고하는 자리」라 **목적이
  다르다.** 크기가 다르면 같은 자산이 아니다.

  | | 페리코프 | 이 표 |
  |---|---|---|
  | 목적 | 단락 요약 | **역본 차이 경고** |
  | 크기 | 중앙 11절 | **중앙 1절 · 최대 23** |
  | 버전 축 | 없다 | **짝마다 한 행** |

★★★ **짝 구조 — 기준 하나와만 견준다** (사용자 「버전2와 버전3을 비교할 필요가
  있을까? … 필요하지 않을 것 같다」 — **맞다**).
  모든 설명문·연결이 **BSB 좌표에 걸려 있으므로** 물어야 할 것은 「이 BSB
  좌표가 그 역본에서도 같은 내용인가」 하나뿐이다. 버전2와 버전3이 서로
  어긋나도 각자 BSB 와의 관계만 알면 각자 처리된다.
  ⇒ 비교 수가 `n²/2` 에서 **`n−1`** 로 줄고, **버전이 늘면 행이 늘 뿐**이다.

★ **두 단계** (사용자 지시 그대로):
  `SUSPECT`   기계가 짚은 추정 구간
  `CONFIRMED` 본문을 읽어 차이로 확정
  `CLEARED`   읽어 보니 같은 내용
  ⚠⚠ **`CLEARED` 를 반드시 남긴다** — 지우면 다음 실행이 같은 자리를 또
    후보로 올린다. 「이미 봤고 문제없다」가 기록돼야 두 번 안 본다.

★ **갈래 셋**(`detector`) — 무엇이 짚었는지 남긴다. 잣대를 고칠 때 되짚는다.
  `MISSING` 기준엔 원문 낱말이 있는데 이 역본엔 없다 — **합쳐짐·없는절**
  `SHIFT`   그 내용이 **이웃 절에** 있다 — 밀림
  `LOW`     같은 자리인데 **겹침이 낮다** — 번역 차이

⚠ **근거(`evidence`)를 반드시 적는다** — 까닭 없는 판정은 다음 사람이 검증할
  수 없다(§0-1).

⚠ **재료는 `db_strong_align` 이 담은 `sys_verse_strong`** 이다. 그 역본을 안
  담았으면 **조용히 0건을 내지 않고 「잴 수 없다」고 말한다.**

쓰는 법
    python db_align_span.py --selftest
    python db_align_span.py --scan [--version CUVS]
    python db_align_span.py --apply [--version CUVS]
    python db_align_span.py --list [--version CUVS]
    python db_align_span.py --undo
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import appdb                                              # noqa: E402

BASE_VERSION = 'BSB'

# 겹침이 이 아래면 「같은 내용이라 보기 어렵다」. 실측 — 제자리 절의 99.4% 가
#   이보다 높다(CUVS 30,831/31,013). 문턱을 낮추면 놓치고 높이면 잡음이 는다.
LOW_J = 0.25
# 이웃이 이만큼 더 맞으면 **밀림**이다(§268차 「어긋남 판정」과 같은 원리 —
#   아무 데도 없으면 번역 차이이고, 이웃에 있을 때만 밀림이다).
SHIFT_GAIN = 0.15
# 이웃을 몇 칸까지 보나. ⚠ 넓히면 우연히 닮은 절이 걸린다(실측 ±2 로 충분).
NEIGHBOR = 2
# 후보 사이에 이만큼 틈이 있어도 한 구간으로 묶는다.
#   ⚠ 0 이면 한 칸 걸러 어긋난 자리가 구간 둘로 쪼개져 사람이 두 번 본다.
GAP = 2

STATES = ('SUSPECT', 'CONFIRMED', 'CLEARED')
DETECTORS = ('MISSING', 'SHIFT', 'LOW')

DET_LABEL = {
    'MISSING': '이 역본에 그 원문 낱말이 없다 (합쳐짐·없는 절)',
    'SHIFT': '그 내용이 이웃 절에 있다 (밀림)',
    'LOW': '같은 자리인데 내용이 크게 다르다',
}
STATE_LABEL = {
    'SUSPECT': '추정',
    'CONFIRMED': '차이 확정',
    'CLEARED': '같은 내용으로 확인',
}


def ensure(conn):
    """표를 만든다(멱등)."""
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_align_span (
        span_id        INTEGER PRIMARY KEY AUTOINCREMENT,
        base_version   TEXT    NOT NULL,
        other_version  TEXT    NOT NULL,
        start_vid      INTEGER NOT NULL,
        end_vid        INTEGER NOT NULL,
        state          TEXT    NOT NULL DEFAULT 'SUSPECT',
        detector       TEXT    NOT NULL,
        evidence       TEXT,
        decided_by     TEXT,
        decided_at     TEXT)""")
    conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_align_unq '
                 'ON sys_align_span(base_version, other_version, '
                 'start_vid, end_vid)')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_align_v '
                 'ON sys_align_span(other_version, start_vid)')


def jac(a, b):
    """두 스트롱 집합의 겹침. 한쪽이 비면 0."""
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def _order(conn):
    """정경 차례. ⚠ `verse_id` 가 아니라 `sort_order` 다(§236차)."""
    vs = [v for (v,) in conn.execute(
        'SELECT verse_id FROM bible_index ORDER BY sort_order')]
    return vs, dict((v, i) for i, v in enumerate(vs))


def _strongs(conn, version):
    return dict((v, set(t.split())) for v, t in conn.execute(
        'SELECT verse_id, strongs FROM sys_verse_strong '
        'WHERE version_code=?', (version,)))


def versions(conn):
    """재료가 담긴 역본 — 기준은 뺀다."""
    return [v for (v,) in conn.execute(
        'SELECT DISTINCT version_code FROM sys_verse_strong '
        'WHERE version_code<>? ORDER BY version_code', (BASE_VERSION,))]


def scan(conn, version, base=BASE_VERSION):
    """어긋남 후보를 찾아 **구간으로 묶어** 낸다 (DB 를 안 바꾼다).

    돌려주는 것: [(start_vid, end_vid, detector, evidence), …]
    ⚠ 재료가 없으면 **빈 목록이 아니라 예외** — 「0건」과 「못 쟀다」는 다르다.
    """
    bm = _strongs(conn, base)
    om = _strongs(conn, version)
    if not bm:
        raise SystemExit('기준 %s 의 스트롱이 없다 — db_strong_align --apply'
                         % base)
    if not om:
        raise SystemExit('%s 의 스트롱이 없다 — 그 역본은 재료가 없어 못 잰다'
                         % version)
    order, pos = _order(conn)
    flags = []
    for v in order:
        b = bm.get(v)
        if not b:
            continue                    # 기준에 원문 낱말이 없는 절
        o = om.get(v)
        if not o:
            flags.append((v, 'MISSING', '기준에 낱말 %d개 · 이 역본엔 0개'
                          % len(b)))
            continue
        here = jac(o, b)
        if here >= LOW_J:
            continue
        best, dbest = here, 0
        i = pos[v]
        for d in range(-NEIGHBOR, NEIGHBOR + 1):
            if d == 0 or not (0 <= i + d < len(order)):
                continue
            nb = bm.get(order[i + d])
            if not nb:
                continue
            j = jac(o, nb)
            if j > best:
                best, dbest = j, d
        if dbest and best > here + SHIFT_GAIN:
            flags.append((v, 'SHIFT', '제자리 겹침 %.2f · %+d절과 %.2f'
                          % (here, dbest, best)))
        else:
            flags.append((v, 'LOW', '겹침 %.2f (낱말 %d ↔ %d)'
                          % (here, len(b), len(o))))
    # ── 구간으로 묶는다 ──────────────────────────────────────────────
    spans = []
    cur = None
    for v, det, why in flags:
        i = pos[v]
        if cur and i - cur[1] <= GAP:
            cur = (cur[0], i, cur[2] + [det], cur[3] + [why])
        else:
            if cur:
                spans.append(cur)
            cur = (i, i, [det], [why])
    if cur:
        spans.append(cur)
    out = []
    for a, b, dets, whys in spans:
        # ⚠⚠ **갈래가 섞이면 다수결이다 — 「가장 무거운 것」이 아니다**
        #   (2026-09-22 실측으로 고쳤다). 민1:21~43 은 없는 절 12개에 밀린
        #   절 1개인데 「무거운 것」으로 고르니 **SHIFT 로 나오고 근거는
        #   「낱말 0개」**라 갈래와 까닭이 서로 어긋나 보였다.
        cnt = {}
        for d in dets:
            cnt[d] = cnt.get(d, 0) + 1
        det = max(cnt.items(), key=lambda kv: (kv[1], kv[0]))[0]
        if len(cnt) > 1:
            head = '갈래 섞임 — ' + ' · '.join(
                '%s %d' % (k, v) for k, v in sorted(cnt.items()))
            why = head + ' / ' + ' / '.join(whys[:2])
        else:
            why = ' / '.join(whys[:3])
        out.append((order[a], order[b], det, why[:300]))
    return out


def apply(conn, version, base=BASE_VERSION):
    """찾은 것을 담는다.

    ⚠⚠ **사람이 판단한 것은 절대 안 덮는다** — `CONFIRMED`·`CLEARED` 는
      그대로 두고 `SUSPECT` 만 새로 쓴다. 안 그러면 한 번 돌릴 때마다
      사람이 본 기록이 사라진다.
    """
    ensure(conn)
    found = scan(conn, version, base)
    keep = set((a, b) for a, b, in conn.execute(
        'SELECT start_vid, end_vid FROM sys_align_span '
        'WHERE base_version=? AND other_version=? AND state<>?',
        (base, version, 'SUSPECT')))
    conn.execute('DELETE FROM sys_align_span WHERE base_version=? AND '
                 'other_version=? AND state=?', (base, version, 'SUSPECT'))
    n_new = n_keep = 0
    for a, b, det, why in found:
        if (a, b) in keep:
            n_keep += 1
            continue
        conn.execute('INSERT OR IGNORE INTO sys_align_span(base_version, '
                     'other_version, start_vid, end_vid, state, detector, '
                     'evidence) VALUES(?,?,?,?,?,?,?)',
                     (base, version, a, b, 'SUSPECT', det, why))
        n_new += 1
    conn.commit()
    return n_new, n_keep


def decide(conn, span_id, state, who='ADMIN'):
    """사람이 판정한다. ⚠ 아는 상태만 받는다 — 오타를 조용히 담지 않는다."""
    if state not in STATES:
        raise ValueError('모르는 상태: %s' % state)
    import datetime
    ensure(conn)
    conn.execute('UPDATE sys_align_span SET state=?, decided_by=?, '
                 'decided_at=? WHERE span_id=?',
                 (state, who, datetime.datetime.now().isoformat(' ', 'seconds'),
                  span_id))
    conn.commit()


def spans_for(conn, verse_id, version=None, base=BASE_VERSION):
    """그 절을 덮는 구간. 화면이 쓰는 문.

    ⚠ 차례는 `sort_order` 로 잰다 — `verse_id` 는 정경 순서가 아니다(§236차).
    ⚠ `CLEARED` 는 **안 낸다** — 「보니 같더라」는 경고가 아니다.
    """
    q = ("""SELECT s.span_id, s.other_version, s.start_vid, s.end_vid,
                   s.state, s.detector, s.evidence
              FROM sys_align_span s
              JOIN bible_index a ON a.verse_id = s.start_vid
              JOIN bible_index b ON b.verse_id = s.end_vid
             WHERE s.base_version=? AND s.state<>'CLEARED'
               AND a.sort_order <= (SELECT sort_order FROM bible_index
                                     WHERE verse_id=?)
               AND b.sort_order >= (SELECT sort_order FROM bible_index
                                     WHERE verse_id=?)""")
    args = [base, verse_id, verse_id]
    if version:
        q += ' AND s.other_version=?'
        args.append(version)
    return conn.execute(q + ' ORDER BY s.other_version', args).fetchall()


# ══════════════════════════════════════════════════════════════════════
# ★★★ **위험 지대 — 재료가 없는 역본이 물려받을 자리** (2026-09-22 확정).
#   한국어는 공개된 스트롱 태그본이 없어 KRV 를 기계로 잴 수 없다. 그런데
#   **좌표가 흔들리는 자리는 그 역본의 성질이 아니라 기준(BSB)이 절을 나눈
#   자리**라 **어느 역본에서나 위험**하다. 그래서 잰 역본에서 찾아낸 그 자리를
#   **못 잰 역본이 그대로 물려받아 사람이 먼저 본다.**
#
# ⚠⚠⚠ **잣대는 「역본 몇 개가 걸렸나」가 아니다 — 실측으로 버렸다.**
#   처음엔 「둘 이상 역본에서 함께 어긋난 자리」로 잡았는데(69곳), 재 보니
#   그 가운데 **64곳이 CUV 와 CUVS** 였다. 둘은 **같은 和合本의 번체·간체
#   판**이라 한 번역을 두 번 센 것이고 증거가 아니다. 번역 계열이 다른 것끼리
#   겹치는 자리는 **5곳뿐**이었다.
#   ★ 게다가 지금 재료가 셋인데 그중 둘이 같은 판이라 **독립 표본이 둘**
#     (和合本 · Darby)이다. 교집합 잣대는 표본이 둘일 때 성립하지 않는다.
#
# ★★★ **그래서 잣대를 「무엇이 어긋났나」로 바꿨다.**
#   | 갈래 | 뜻 | 물려줄 수 있나 |
#   |---|---|---|
#   | `MISSING` | 기준엔 원문 낱말이 있는데 없다 = **절을 합쳤다** | ✅ 좌표 |
#   | `SHIFT`   | 그 내용이 이웃 절에 있다 = **절 번호가 밀렸다** | ✅ 좌표 |
#   | `LOW`     | 같은 자리인데 번역이 다르다 | ✗ 그 역본의 성질 |
#   ✅ 실측 **101지대**(시편 28 · 신 8 · 대상 8 · 민 7 · 겔 7) — 절체계가
#     흔들리는 대표 자리와 정확히 겹친다.
#
# ⚠⚠ **저장하지 않는다 — 부를 때 계산한다.** 표를 하나 더 두면 ① 역본이 늘
#   때 안 따라오고 ② 사람이 판정해도 안 바뀌고 ③ 고치는 문이 둘이 된다.
RISK_DETECTORS = ('MISSING', 'SHIFT')


def risk_zones(conn, base=BASE_VERSION, dets=RISK_DETECTORS):
    """겹치는 구간을 **한 지대**로 묶어 낸다.

    돌려주는 것 — 정경 차례로
      `[{start_vid, end_vid, versions, dets, span_ids, state}]`

    ⚠ **좌표 갈래가 하나도 없는 지대는 안 낸다** — 번역 차이는 그 역본의
      성질이라 남에게 물려줄 수 없다.
    ⚠ **전부 `CLEARED` 인 지대도 안 낸다** — 사람이 보고 같다고 한 자리는
      경고가 아니다(`spans_for` 와 같은 규칙).
    ⚠ 차례는 `sort_order` 로 잰다 — `verse_id` 는 정경 순서가 아니다(§236차).
    """
    ensure(conn)
    pos = dict(conn.execute('SELECT verse_id, sort_order FROM bible_index'))
    rows = [r for r in conn.execute(
        'SELECT span_id, other_version, start_vid, end_vid, state, detector '
        'FROM sys_align_span WHERE base_version=?', (base,)).fetchall()
        if r[2] in pos and r[3] in pos]
    rows.sort(key=lambda r: (pos[r[2]], pos[r[3]]))
    zones, cur = [], None
    for sid, ver, a, b, st, det in rows:
        sa, sb = pos[a], pos[b]
        if cur is not None and sa <= cur['_e']:
            if sb > cur['_e']:
                cur['_e'], cur['end_vid'] = sb, b
            cur['versions'].add(ver)
            cur['dets'].add(det)
            cur['span_ids'].append(sid)
            cur['_st'].append(st)
        else:
            if cur is not None:
                zones.append(cur)
            cur = {'start_vid': a, 'end_vid': b, '_e': sb,
                   'versions': {ver}, 'dets': {det}, 'span_ids': [sid],
                   '_st': [st]}
    if cur is not None:
        zones.append(cur)
    want = set(dets)
    out = []
    for z in zones:
        if not (z['dets'] & want):
            continue
        sts = z['_st']
        if all(x == 'CLEARED' for x in sts):
            continue
        z['state'] = 'CONFIRMED' if 'CONFIRMED' in sts else 'SUSPECT'
        z['versions'] = sorted(z['versions'])
        z['dets'] = sorted(z['dets'])
        z.pop('_e')
        z.pop('_st')
        out.append(z)
    return out


# ⚠⚠ **원문·사어는 「못 재는 역본」이 아니다** — 실측으로 걷었다.
#   처음엔 본문이 있는 역본을 다 세어 **15** 가 나왔는데 거기 히브리 원문
#   `WLC` · 헬라 원문 `GNT` · **콥트 셋**이 들어 있었다. 원문은 기준과 견줄
#   대상이 아니고(그 자체가 원문이다), 콥트는 §18-4 가 「예배 사어 · 평신도
#   실독 없음」으로 이미 갈라 둔 자리다. 세면 **못 재는 역본 수가 부풀어
#   거짓이 된다.**
ORIG_LANGS = ('HE', 'EL', 'COP')


def unmeasured(conn, base=BASE_VERSION):
    """`(잴 수 있는 역본, 아직 못 재는 역본)` — **없는 것을 화면이 말하게 한다.**

    ⚠ 「목록에 없다」와 「문제가 없다」는 다르다(§0-1). 스트롱 태그본이 없는
      역본은 **아직 못 잰 것**이고, 화면이 그 사실을 스스로 말해야 한다.
    ⚠ **본문이 실제로 담긴 번역 역본만** 센다 — 등록만 되고 빈 역본(`TRC`·
      `JLV`)이나 원문(`WLC`·`GNT`)·사어(콥트)를 세면 수가 부풀어 거짓이 된다.
    """
    can = set(v for (v,) in conn.execute(
        'SELECT DISTINCT version_code FROM sys_verse_strong '
        'WHERE version_code<>?', (base,)))
    live = [v for (v,) in conn.execute(
        'SELECT version_code FROM bible_version WHERE version_code<>? '
        'AND COALESCE(lang_code, \'\') NOT IN (%s) '
        'AND EXISTS(SELECT 1 FROM bible_content b WHERE '
        'b.version_code=bible_version.version_code) '
        'ORDER BY version_code' % ','.join('?' * len(ORIG_LANGS)),
        (base,) + ORIG_LANGS)]
    return sorted(can & set(live)), [v for v in live if v not in can]


def risk_for(conn, verse_id, base=BASE_VERSION):
    """그 절이 위험 지대 안인가 — 화면이 쓰는 문. 아니면 `None`."""
    pos = dict(conn.execute(
        'SELECT verse_id, sort_order FROM bible_index'))
    p = pos.get(verse_id)
    if p is None:
        return None
    for z in risk_zones(conn, base):
        if pos.get(z['start_vid'], 1) <= p <= pos.get(z['end_vid'], -1):
            return z
    return None


def undo(conn, version=None, base=BASE_VERSION):
    """⚠ **사람이 판정한 것은 안 지운다** — 되돌리는 것은 기계가 넣은 것뿐."""
    ensure(conn)
    if version:
        conn.execute('DELETE FROM sys_align_span WHERE base_version=? AND '
                     'other_version=? AND state=?',
                     (base, version, 'SUSPECT'))
    else:
        conn.execute('DELETE FROM sys_align_span WHERE base_version=? '
                     'AND state=?', (base, 'SUSPECT'))
    conn.commit()


# ══════════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, note=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  OK   %s' % name)
        else:
            print('  FAIL %s %s' % (name, note))

    def mkdb(n=12):
        m = sqlite3.connect(':memory:')
        m.execute('CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, '
                  'bcode INTEGER, chapter INTEGER, verse INTEGER, '
                  'sort_order INTEGER)')
        m.execute('CREATE TABLE sys_verse_strong(version_code TEXT, '
                  'verse_id INTEGER, strongs TEXT, n_word INTEGER)')
        for i in range(1, n + 1):
            m.execute('INSERT INTO bible_index VALUES(?,1,1,?,?)',
                      (i, i, i * 10))
        ensure(m)
        return m

    def put(m, vc, vid, words):
        m.execute('INSERT INTO sys_verse_strong VALUES(?,?,?,?)',
                  (vc, vid, ' '.join(words), len(words)))

    # ① 겹침 셈
    t('같으면 1', abs(jac({'H1', 'H2'}, {'H1', 'H2'}) - 1.0) < 1e-9)
    t('다르면 0', jac({'H1'}, {'H2'}) == 0.0)
    t('한쪽이 비면 0', jac(set(), {'H1'}) == 0.0)

    # ② 제자리면 후보가 없다
    m = mkdb()
    for i in range(1, 13):
        w = ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i]
        put(m, 'BSB', i, w)
        put(m, 'X', i, w)
    t('★ 제자리면 후보 0', scan(m, 'X') == [])

    # ③ 한 절이 비면 MISSING
    m.execute('DELETE FROM sys_verse_strong WHERE version_code=? '
              'AND verse_id=?', ('X', 5))
    got = scan(m, 'X')
    t('★★★ 낱말이 없으면 MISSING',
      len(got) == 1 and got[0][2] == 'MISSING', str(got))
    t('구간이 그 한 절', got and got[0][0] == 5 and got[0][1] == 5)
    t('근거를 함께 적는다', got and '0개' in got[0][3])
    m.close()

    # ④ 내용이 이웃에 있으면 SHIFT
    m = mkdb()
    for i in range(1, 13):
        put(m, 'BSB', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
    for i in range(1, 13):
        j = i + 1 if i in (6,) else i
        put(m, 'X', i, ['H%d' % j, 'H%d1' % j, 'H%d2' % j, 'H%d3' % j])
    got = scan(m, 'X')
    t('★★★ 이웃에 있으면 SHIFT',
      len(got) == 1 and got[0][2] == 'SHIFT', str(got))
    t('근거에 몇 절 밀렸는지 적는다', got and '+1' in got[0][3])
    m.close()

    # ⑤ 아무 데도 없으면 LOW (번역 차이 — 밀림이 아니다)
    m = mkdb()
    for i in range(1, 13):
        put(m, 'BSB', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
        put(m, 'X', i, (['H999', 'H998', 'H997', 'H996'] if i == 7
                        else ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i]))
    got = scan(m, 'X')
    t('★★★ 아무 데도 없으면 LOW (밀림이 아니다)',
      len(got) == 1 and got[0][2] == 'LOW', str(got))
    m.close()

    # ⑥ 이어진 후보는 한 구간
    m = mkdb()
    for i in range(1, 13):
        put(m, 'BSB', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
        if i not in (4, 5, 6):
            put(m, 'X', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
    got = scan(m, 'X')
    t('★ 이어진 셋이 한 구간',
      len(got) == 1 and got[0][0] == 4 and got[0][1] == 6, str(got))
    m.close()

    # ⑥-2 갈래가 섞이면 **다수결** (실측 민1:21~43 사고)
    m = mkdb(14)
    for i in range(1, 15):
        put(m, 'BSB', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
    for i in range(1, 15):
        if i in (4, 5, 7):
            continue                       # 없음 셋
        j = i + 1 if i == 6 else i         # 밀림 하나
        put(m, 'X', i, ['H%d' % j, 'H%d1' % j, 'H%d2' % j, 'H%d3' % j])
    got = scan(m, 'X')
    t('★★★ 갈래가 섞이면 다수결 (무거운 것이 아니다)',
      len(got) == 1 and got[0][2] == 'MISSING', str(got))
    t('★ 섞였다는 것을 근거가 말한다',
      got and '갈래 섞임' in got[0][3], str(got))
    m.close()

    m = mkdb()
    for i in range(1, 13):
        put(m, 'BSB', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])
        if i not in (4, 5, 6):
            put(m, 'X', i, ['H%d' % i, 'H%d1' % i, 'H%d2' % i, 'H%d3' % i])

    # ⑦ 담기 — 멱등 · 사람 판정 보존
    n1, _k = apply(m, 'X')
    t('담았다', n1 == 1)
    n2, _k2 = apply(m, 'X')
    t('★ 두 번 돌려도 안 는다',
      m.execute('SELECT COUNT(*) FROM sys_align_span').fetchone()[0] == 1)
    sid = m.execute('SELECT span_id FROM sys_align_span').fetchone()[0]
    decide(m, sid, 'CONFIRMED')
    apply(m, 'X')
    r = m.execute('SELECT state, decided_by FROM sys_align_span '
                  'WHERE span_id=?', (sid,)).fetchone()
    t('★★★ 사람이 판정한 것을 안 덮는다',
      r and r[0] == 'CONFIRMED' and r[1] == 'ADMIN', str(r))
    undo(m, 'X')
    t('★ 되돌려도 사람 판정은 남는다',
      m.execute('SELECT COUNT(*) FROM sys_align_span').fetchone()[0] == 1)

    # ⑧ 조회 — CLEARED 는 경고가 아니다
    rows = spans_for(m, 5, 'X')
    t('구간 안의 절에서 보인다', len(rows) == 1, str(rows))
    t('★ 구간 밖에서는 안 보인다', spans_for(m, 11, 'X') == [])
    decide(m, sid, 'CLEARED')
    t('★★★ CLEARED 는 경고로 안 낸다', spans_for(m, 5, 'X') == [])
    bad = False
    try:
        decide(m, sid, 'HMM')
    except ValueError:
        bad = True
    t('★ 모르는 상태는 거부한다', bad)
    m.close()

    # ⑧-2 위험 지대 — **재료 없는 역본이 물려받을 자리**
    m = mkdb(20)
    def _span(ver, a, b, det, st='SUSPECT'):
        m.execute('INSERT INTO sys_align_span(base_version, other_version, '
                  'start_vid, end_vid, state, detector, evidence) '
                  'VALUES(?,?,?,?,?,?,?)',
                  ('BSB', ver, a, b, st, det, 'x'))
    _span('A', 3, 3, 'MISSING')
    _span('B', 3, 4, 'SHIFT')          # 겹친다 — 한 지대
    _span('A', 9, 9, 'LOW')            # 번역 차이만 — 못 물려준다
    _span('A', 12, 12, 'MISSING', 'CLEARED')   # 보고 같다 한 자리
    _span('A', 15, 15, 'MISSING', 'CONFIRMED')
    z = risk_zones(m)
    t('★★★ 겹치면 한 지대로 묶는다', len(z) == 2, str(z))
    t('★ 지대가 걸린 역본을 모은다',
      z and z[0]['versions'] == ['A', 'B'], str(z[:1]))
    t('★ 구간을 다 담는다 (3~4)',
      z and z[0]['start_vid'] == 3 and z[0]['end_vid'] == 4, str(z[:1]))
    t('★★★ 번역 차이(LOW)만인 자리는 안 낸다 — 못 물려준다',
      all(9 not in (x['start_vid'], x['end_vid']) for x in z), str(z))
    t('★★★ 전부 「같은 내용」이면 안 낸다',
      all(12 not in (x['start_vid'], x['end_vid']) for x in z), str(z))
    t('★ 확정이 있으면 지대도 확정',
      any(x['state'] == 'CONFIRMED' and x['start_vid'] == 15 for x in z),
      str(z))
    t('★ 안 본 자리는 추정', z and z[0]['state'] == 'SUSPECT', str(z[:1]))
    t('★ 그 절이 지대 안인지 묻는다', bool(risk_for(m, 4)))
    t('★ 지대 밖은 없다고 말한다', risk_for(m, 7) is None)
    # 잣대를 넓히면 LOW 도 든다 — 잣대가 실제로 거르고 있다는 증거
    t('★ 잣대가 실제로 거른다',
      len(risk_zones(m, dets=('MISSING', 'SHIFT', 'LOW'))) == 3,
      str(len(risk_zones(m, dets=('MISSING', 'SHIFT', 'LOW')))))
    m.close()

    # ⑧-3 못 재는 역본을 짚는다
    m = mkdb()
    m.execute('CREATE TABLE bible_version(version_code TEXT, lang_code TEXT)')
    m.execute('CREATE TABLE bible_content(version_code TEXT, verse_id INT)')
    for v, lg in (('BSB', 'EN'), ('CUV', 'ZH'), ('KRV', 'KO'),
                  ('EMPTY', 'DE'), ('WLC', 'HE'), ('COPX', 'COP')):
        m.execute('INSERT INTO bible_version VALUES(?,?)', (v, lg))
        if v != 'EMPTY':
            m.execute('INSERT INTO bible_content VALUES(?,1)', (v,))
    put(m, 'BSB', 1, ['H1'])
    put(m, 'CUV', 1, ['H1'])
    can, cant = unmeasured(m)
    t('★★★ 잴 수 있는 역본', can == ['CUV'], str(can))
    t('★★★ 못 재는 역본을 짚는다 (한국어)', cant == ['KRV'], str(cant))
    t('★ 본문이 빈 역본은 안 센다', 'EMPTY' not in cant, str(cant))
    t('★★★ 원문(히브리·헬라)은 「못 재는 역본」이 아니다',
      'WLC' not in cant, str(cant))
    t('★★★ 사어(콥트)도 안 센다', 'COPX' not in cant, str(cant))
    m.close()

    # ⑨ 재료가 없으면 「0건」이 아니라 「못 쟀다」
    m = mkdb()
    put(m, 'BSB', 1, ['H1'])
    said = False
    try:
        scan(m, 'ZZZ')
    except SystemExit:
        said = True
    t('★★★ 재료가 없으면 조용히 0건을 내지 않는다', said)
    m.close()

    # ⑩ 상수·이름표
    t('상태 셋', set(STATES) == {'SUSPECT', 'CONFIRMED', 'CLEARED'})
    t('갈래 셋', set(DETECTORS) == {'MISSING', 'SHIFT', 'LOW'})
    t('★ 갈래마다 사람 말 이름표',
      all(k in DET_LABEL and DET_LABEL[k] for k in DETECTORS))
    t('★ 상태마다 사람 말 이름표',
      all(k in STATE_LABEL and STATE_LABEL[k] for k in STATES))
    t('이름표에 코드가 안 섞인다',
      not any(k in DET_LABEL[k] for k in DETECTORS))

    print('\n%d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def _ref(conn, vid):
    r = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                     'WHERE verse_id=?', (vid,)).fetchone()
    if not r:
        return '#%d' % vid
    nm = conn.execute("SELECT short_name FROM book_names WHERE book_code=? "
                      "AND lang_code='KO'", (r[0],)).fetchone()
    return '%s%d:%d' % (nm[0] if nm else r[0], r[1], r[2])


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    only = None
    if '--version' in argv:
        only = argv[argv.index('--version') + 1]
    conn = appdb.connect()
    try:
        ensure(conn)
        vs = [only] if only else versions(conn)
        if not vs:
            print('잴 수 있는 역본이 없다 — db_strong_align.py --apply 먼저')
            return 1
        if '--undo' in argv:
            for v in vs:
                undo(conn, v)
            print('되돌렸다(사람이 판정한 것은 남는다)')
            return 0
        if '--list' in argv:
            for v in vs:
                rows = conn.execute(
                    'SELECT span_id, start_vid, end_vid, state, detector, '
                    'evidence FROM sys_align_span WHERE other_version=? '
                    'ORDER BY span_id', (v,)).fetchall()
                print('== %s — %d구간' % (v, len(rows)))
                for sid, a, b, st, det, why in rows[:40]:
                    rng = (_ref(conn, a) if a == b
                           else '%s~%s' % (_ref(conn, a), _ref(conn, b)))
                    print('  #%-4d %-14s %-9s %-8s %s'
                          % (sid, rng, STATE_LABEL.get(st, st), det,
                             (why or '')[:52]))
            return 0
        for v in vs:
            if '--apply' in argv:
                n, k = apply(conn, v)
                print('  [%s] 새로 %d구간 · 사람이 본 것 %d 보존' % (v, n, k))
            else:
                found = scan(conn, v)
                kinds = {}
                for _a, _b, d, _w in found:
                    kinds[d] = kinds.get(d, 0) + 1
                sizes = []
                for a, b, _d, _w in found:
                    sa = conn.execute('SELECT sort_order FROM bible_index '
                                      'WHERE verse_id=?', (a,)).fetchone()[0]
                    sb = conn.execute('SELECT sort_order FROM bible_index '
                                      'WHERE verse_id=?', (b,)).fetchone()[0]
                    sizes.append(int((sb - sa) / 10) + 1)
                sizes.sort()
                print('  [%s] %d구간 · 크기 중앙 %d 최대 %d · %s'
                      % (v, len(found), sizes[len(sizes) // 2] if sizes else 0,
                         max(sizes) if sizes else 0, kinds))
                for a, b, d, w in found[:5]:
                    rng = (_ref(conn, a) if a == b
                           else '%s~%s' % (_ref(conn, a), _ref(conn, b)))
                    print('        %-14s %-8s %s' % (rng, d, w[:56]))
        return 0
    finally:
        conn.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
