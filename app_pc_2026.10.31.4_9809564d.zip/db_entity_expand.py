# -*- coding: utf-8 -*-
"""제도·사물·절기 엔티티 확대 — 2026-09-02 (0.txt 3번, 사용자 승인).

제도 6 → 16 · 사물 9 → 20 · 절기 10 → 12(월삭·금식일 — 같은 날 사용자 지시). **절기·에봇이 표준**(이름 KO+EN · 설명문 KO+EN
650~1,000자 · 단락연결 1~3)이라 새 엔티티도 그 모양으로 만든다 — 기존
사물·제도 대부분이 한 줄 설명(EN 0 · 연결 0)로 얇았던 것이 「데이터가 너무
적다」의 절반이었다.

★ 입장 조건은 §12-0 그대로 — 성경 안에서 손으로 짚을 수 있고, 설명문·구절
  연결이 실제로 만들어지는 것만. **교회력 절기(대림절 등)는 넣지 않는다**
  (성경 본문에 없어 연결이 만들어질 수 없다 — 152차 부활절 태그 삭제 전례).
★ 이름은 개역한글 표기를 따른다(속죄소·진설병·물두멍·분향단·도피성).
  장자권만 일반어(개역한글은 「장자의 명분」 — 설명문이 그 표기를 인용).
⚠ 놋뱀은 IDL_NEHUSHTAN(느후스단)과 **같은 물건의 두 국면**이다(민21 구원의
  표 · 왕하18:4 우상이 된 그것) — 별도 등록하고 비교 칸으로 잇는다(초안 =
  이 도구가 아니라 db_entity_compare).

사용:
    python db_entity_expand.py --selftest   (의무)
    python db_entity_expand.py --check
    python db_entity_expand.py --apply     (멱등 — entity_code 열쇠)
    python db_entity_expand.py --status
"""
import argparse
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb  # noqa: E402

DB = 'bible_master.db'

# (코드, 유형, KO이름, EN이름, importance, KO설명, EN설명,
#  단락앵커 [(bcode, ch, vs, rel, imp)...])
DRAFT = (
    # ═══ 제도 (SYSTEM) ═══
    ('SYS_BURNT_OFFERING', 'SYSTEM', '번제', 'Burnt Offering', 7, """번제는 제물 전부를 단 위에서 태워 드리는 제사입니다. 다른 제사는 제사장이나 드린 사람이 나눠 먹는 몫이 있지만, 번제만은 남기는 것이 없습니다. 전부가 하나님의 것입니다.
레위기가 첫 자리에 두는 제사가 번제입니다. 「그는 번제물의 머리에 안수할지니 그리하면 열납되어 그를 위하여 속죄가 될 것이라」(레1:4). 손을 얹는 것은 제물과 드리는 사람이 하나로 여겨진다는 표입니다. 제물이 다 타는 것은 곧 나를 남김없이 드린다는 고백입니다.
번제는 율법보다 오래됐습니다. 홍수 뒤에 노아가 단을 쌓아 번제를 드렸고(창8:20), 아브라함이 모리아산에서 드리려던 것도 번제였습니다(창22:2). 아침저녁으로 끊이지 않는 상번제(출29:38~42)는 하나님 앞의 삶이 특별한 날의 일이 아니라 매일의 일임을 가르칩니다.
신약은 이 그림으로 그리스도를 말합니다. 「그리스도께서 너희를 사랑하신 것같이 너희를 위하여 자신을 버리사 향기로운 제물과 생축으로 하나님께 드리셨느니라」(엡5:2). 그리고 그 온전한 드림이 성도의 삶의 문법이 됩니다. 「너희 몸을 하나님이 기뻐하시는 거룩한 산 제사로 드리라」(롬12:1).""",
     """The burnt offering is the sacrifice in which the whole animal is consumed on the altar. Other offerings leave portions for the priest or the worshiper; the burnt offering leaves nothing. All of it belongs to God.
Leviticus places it first. "He shall put his hand upon the head of the burnt offering; and it shall be accepted for him to make atonement for him" (Lev 1:4). The laying on of the hand marks the offerer as one with the offering; the total burning confesses a life given without remainder.
The burnt offering is older than the law. Noah offered it after the flood (Gen 8:20), and it was a burnt offering Abraham was asked to bring on Moriah (Gen 22:2). The continual burnt offering, morning and evening (Exod 29:38-42), taught that life before God is not an occasional matter but a daily one.
The New Testament reads Christ in this picture: he "hath given himself for us an offering and a sacrifice to God for a sweetsmelling savour" (Eph 5:2). And that whole self-giving becomes the grammar of the believer's life: "present your bodies a living sacrifice" (Rom 12:1).""",
     [(3, 1, 3, 'PROTAGONIST', 8), (1, 8, 20, 'MENTIONED', 6)]),

    ('SYS_GRAIN_OFFERING', 'SYSTEM', '소제', 'Grain Offering', 6, """소제는 피 없는 제사입니다. 고운 가루에 기름을 붓고 유향을 얹어 드립니다(레2:1). 짐승이 아니라 곡식, 곧 사람이 땀 흘려 거둔 것을 드리는 제사입니다.
그래서 소제는 일상 노동의 열매를 하나님께 올리는 제사로 읽혀 왔습니다. 밭에서 난 것을 빻고 반죽하고 구운 것, 곧 사람의 손이 간 것을 드립니다. 예배가 제단 곁에서만 아니라 부엌과 일터에서 시작된다는 가르침이 여기 있습니다.
소제에는 누룩과 꿀을 넣지 못하고(레2:11) 소금은 빠뜨리지 못합니다. 「네 모든 소제물에 소금을 치라 네 하나님의 언약의 소금을 네 소제에 빼지 못할지니」(레2:13). 썩게 하는 것은 빼고, 언약을 기억하게 하는 것은 반드시 넣습니다.
소제는 대개 번제와 함께 드려졌습니다(민28:3~5). 헌신(번제)과 일상의 열매(소제)가 나란히 가는 것입니다. 몸을 드린 사람이 손의 일도 드립니다.""",
     """The grain offering is the bloodless sacrifice: fine flour with oil poured on it and frankincense laid upon it (Lev 2:1). Not an animal, but grain — what a person has grown and gathered by labor.
So it has been read as the offering of daily work. What is brought has passed through human hands: ground, kneaded, baked. Worship begins not only beside the altar but in the kitchen and the field.
No leaven or honey could be added (Lev 2:11), and salt could never be left out: "with all thine offerings thou shalt offer salt," the salt of the covenant (Lev 2:13). What corrupts is excluded; what recalls the covenant is required.
The grain offering usually accompanied the burnt offering (Num 28:3-5): consecration and the fruit of daily labor go side by side. The one who has offered the body offers the work of the hands as well.""",
     [(3, 2, 1, 'PROTAGONIST', 7)]),

    ('SYS_PEACE_OFFERING', 'SYSTEM', '화목제', 'Peace Offering', 7, """화목제는 함께 먹는 제사입니다. 기름과 내장은 단 위에서 태우고, 가슴과 뒷다리는 제사장에게, 나머지는 드린 사람과 그 식구가 하나님 앞에서 먹습니다(레3장·레7:11~34). 제단과 식탁이 한 자리에 있는 유일한 제사입니다.
이름이 뜻을 말합니다. 히브리 이름은 샬롬과 한 뿌리입니다. 하나님과 사이가 온전할 때에만 그 앞에서 잔치를 벌일 수 있습니다. 화목제는 감사로, 서원을 갚는 일로, 자원하는 마음으로 드렸습니다(레7:12·16).
시내산에서 언약을 세울 때 「번제와 화목제를 드리고 … 하나님을 보고 먹고 마셨더라」(출24:5·11)는 장면이 이 제사의 절정입니다. 언약 백성의 마지막 그림이 식탁이라는 것입니다.
신약은 그리스도를 「우리의 화평」(엡2:14)이라 부릅니다. 화목제가 그리던 것, 곧 하나님과 사람이 한 상에 앉는 일이 그분 안에서 이루어집니다.""",
     """The peace offering is the sacrifice that is eaten together. The fat is burned on the altar, the breast and thigh go to the priest, and the rest is eaten before the LORD by the offerer and his household (Lev 3; 7:11-34). It is the one sacrifice where altar and table meet.
The name carries the meaning: it shares its root with shalom. Only when things are whole between God and his people can there be a feast in his presence. It was brought in thanksgiving, in payment of vows, or freely (Lev 7:12, 16).
Its high point is the covenant meal at Sinai: "they offered burnt offerings, and sacrificed peace offerings... they saw God, and did eat and drink" (Exod 24:5, 11). The final picture of a covenant people is a table.
The New Testament calls Christ "our peace" (Eph 2:14). What the peace offering sketched — God and his people at one table — is accomplished in him.""",
     [(3, 3, 1, 'PROTAGONIST', 7), (2, 24, 5, 'MENTIONED', 6)]),

    ('SYS_SIN_OFFERING', 'SYSTEM', '속죄제', 'Sin Offering', 7, """속죄제는 부지중에 지은 죄를 위한 제사입니다. 「누구든지 여호와의 금령 중 하나라도 그릇 범하였으되」(레4:2)로 시작하는 규례가 제사장·회중·족장·평민의 경우를 차례로 다룹니다. 몰랐다는 것이 변명이 되지 않고, 죄는 알게 된 그때 처리되어야 합니다.
이 제사의 중심은 피입니다. 피를 성소 휘장 앞에 뿌리고 단 뿔에 바르고 나머지는 단 밑에 쏟습니다(레4:6~7). 죄가 값없이 지워지는 것이 아니라 생명이 대신 치러진다는 것을 눈으로 보게 하는 절차입니다.
큰 속죄제일수록 제물의 몸은 진 밖에서 불살랐습니다(레4:12·21). 히브리서는 바로 그 자리에서 그리스도를 읽습니다. 「그러므로 예수도 자기 피로써 백성을 거룩케 하려고 성문 밖에서 고난을 받으셨느니라」(히13:12).
속죄제는 죄를 가볍게 여기지 않으면서도 죄인에게 길을 열어 둡니다. 죄를 자백하고 제물을 가져오는 사람에게 「제사장이 그를 위하여 속죄한즉 그가 사함을 얻으리라」(레4:26)는 말이 반복됩니다.""",
     """The sin offering is the sacrifice for unintentional sin. The rule that begins "If a soul shall sin through ignorance" (Lev 4:2) works through the cases of priest, congregation, ruler, and commoner in turn. Ignorance is no excuse; sin must be dealt with the moment it is known.
Its center is blood: sprinkled before the veil, put on the horns of the altar, poured out at its base (Lev 4:6-7). Sin is not erased for nothing; a life is paid in the sinner's place, and the ritual makes that visible.
For the greater sin offerings the body of the animal was burned outside the camp (Lev 4:12, 21). Hebrews reads Christ at exactly that spot: "Wherefore Jesus also, that he might sanctify the people with his own blood, suffered without the gate" (Heb 13:12).
The sin offering takes sin with full seriousness while keeping a way open for the sinner. To the one who confesses and brings the offering the refrain returns: "the priest shall make an atonement for him, and it shall be forgiven him" (Lev 4:26).""",
     [(3, 4, 1, 'PROTAGONIST', 8)]),

    ('SYS_GUILT_OFFERING', 'SYSTEM', '속건제', 'Guilt Offering', 7, """속건제는 배상이 딸린 제사입니다. 성물이나 이웃의 것을 침해했을 때, 숫양을 제물로 드리는 것에 더해 **원금에 오분의 일을 더한 배상**을 치릅니다(레5:16·6:5). 하나님께 용서를 구하는 일과 사람에게 물어 주는 일이 한 제사 안에 묶여 있습니다.
그래서 속건제는 죄를 감정의 문제로 두지 않습니다. 죄에는 값이 있고, 그 값은 구체적으로 계산되어 치러져야 합니다. 미안한 마음만으로 끝나지 않는 것이 이 제사의 가르침입니다.
이 제사의 이름이 성경에서 가장 무겁게 쓰인 자리는 이사야 53장입니다. 「여호와께서 그로 상함을 받게 하시기를 원하사 질고를 당케 하셨은즉 그 영혼을 속건제물로 드리기에 이르면」(사53:10). 종의 죽음이 속건제물이라 불립니다. 우리가 치를 수 없는 배상을 그가 치른다는 선언입니다.
속건제 규례는 「그가 이 중에 하나를 행하여 범과가 되었을 때」(레5:5)의 자백에서 시작합니다. 배상의 길은 죄를 인정하는 사람에게만 열립니다.""",
     """The guilt offering is the sacrifice with restitution attached. When holy things or a neighbor's property had been violated, a ram was offered — and on top of it the principal was repaid with a fifth added (Lev 5:16; 6:5). Seeking God's forgiveness and making the neighbor whole are bound into one sacrifice.
So the guilt offering refuses to treat sin as a matter of feeling. Sin has a cost, and the cost is calculated and paid. Being sorry is not the end of it.
The weightiest use of this sacrifice's name is Isaiah 53: "when thou shalt make his soul an offering for sin" — literally a guilt offering (Isa 53:10). The Servant's death is called the asham: the restitution we could not pay, paid by him.
The rule begins with confession — "he shall confess that he hath sinned in that thing" (Lev 5:5). The way of restitution opens only to the one who owns the wrong.""",
     [(3, 5, 14, 'PROTAGONIST', 7)]),

    ('SYS_CITY_REFUGE', 'SYSTEM', '도피성', 'City of Refuge', 7, """도피성은 부지중에 사람을 죽인 자가 피의 보수자를 피해 달려가 사는 성읍입니다. 요단 동서에 세 개씩, 여섯 성을 두었고(민35:13~14), 이스라엘 어디에서든 닿을 수 있게 배치했습니다.
도피성은 복수의 악순환을 끊는 제도입니다. 고의냐 부지중이냐를 회중이 재판으로 가리고(민35:24), 부지중인 자는 성 안에서 삽니다. 다만 마음대로 나갈 수는 없습니다. 「그는 대제사장의 죽은 후에야 자기 소유의 땅으로 돌아갈 것이니라」(민35:28).
대제사장의 죽음이 도피자를 놓아준다는 이 조항이 도피성의 가장 깊은 자리입니다. 죄값의 문제가 사람의 세월이 아니라 한 죽음으로 닫힌다는 그림이 여기 있습니다.
히브리서는 소망을 붙드는 일을 「앞에 있는 소망을 얻으려고 피하여 가는」(히6:18) 일이라고 씁니다. 도피성으로 달려가던 발걸음이 그 문장 뒤에 서 있습니다.""",
     """The cities of refuge were towns to which one who had killed without intent could flee from the avenger of blood and live. Six were appointed, three on each side of the Jordan (Num 35:13-14), placed so that they could be reached from anywhere in Israel.
The institution breaks the cycle of vengeance. The congregation judged between intent and accident (Num 35:24), and the unintentional killer lived within the city — but could not simply leave: "he shall abide in it unto the death of the high priest" (Num 35:28).
That clause — the high priest's death releasing the fugitive — is the deepest part of the picture: the question of blood is closed not by the passing of years but by a death.
Hebrews describes hope as something seized by those "who have fled for refuge to lay hold upon the hope set before us" (Heb 6:18). Behind that sentence run the feet of the one racing for the city gate.""",
     [(4, 35, 9, 'PROTAGONIST', 7)]),

    ('SYS_SABBATICAL_YEAR', 'SYSTEM', '안식년', 'Sabbatical Year', 6, """안식년은 일곱째 해마다 땅을 쉬게 하는 제도입니다. 「제 칠년에는 땅으로 쉬어 안식하게 할지니 여호와께 대한 안식이라 너는 그 밭에 파종하거나 포도원을 다스리지 말며」(레25:4). 안식일이 사람과 짐승의 쉼이라면 안식년은 땅의 쉼입니다.
그 해에 저절로 난 것은 주인의 것이 아니라 모두의 것입니다. 종과 품꾼과 나그네와 들짐승까지 먹습니다(레25:6~7). 소출을 움켜쥐지 않는 한 해가, 땅도 소출도 본래 하나님의 것임을 몸으로 배우게 합니다.
안식년에는 빚도 면제됩니다. 「매 칠년 끝에 면제하라」(신15:1). 가난이 대물림으로 굳지 않도록 일곱 해마다 셈을 지우는 것입니다.
이 제도는 지켜지지 않은 세월까지 기록으로 남았습니다. 바벨론 포로가 칠십 년인 것을 역대기는 「땅이 황무하여 안식년을 누림같이 안식하여 칠십 년을 지내었으니」(대하36:21)라고 읽습니다. 쉬게 하지 않은 땅을 하나님이 결국 쉬게 하셨다는 것입니다.""",
     """The sabbatical year rested the land every seventh year: "in the seventh year shall be a sabbath of rest unto the land... thou shalt neither sow thy field, nor prune thy vineyard" (Lev 25:4). The sabbath day rests people and animals; the sabbath year rests the ground itself.
What grew of itself that year belonged to no owner but to all — servant, hireling, sojourner, even the beasts (Lev 25:6-7). A year of not grasping the harvest taught in the body that land and harvest alike are God's.
Debts too were released: "At the end of every seven years thou shalt make a release" (Deut 15:1) — the ledger wiped every seventh year so that poverty could not harden into inheritance.
Even the years it went unkept were counted. Chronicles reads the seventy years of exile this way: "until the land had enjoyed her sabbaths" (2 Chr 36:21). The rest that was withheld, God at last gave.""",
     [(3, 25, 1, 'PROTAGONIST', 7)]),

    ('SYS_BIRTHRIGHT', 'SYSTEM', '장자권', 'Birthright', 6, """장자권은 맏아들의 몫과 자리입니다. 개역한글은 「장자의 명분」이라고 옮깁니다. 유산에서 두 몫을 받고(신21:17), 아버지를 이어 집안의 머리가 되는 권리입니다.
성경에서 이 제도가 가장 크게 다뤄지는 자리는 에서와 야곱입니다. 「에서가 … 팥죽을 먹고 마시고 일어나서 갔으니 에서가 장자의 명분을 경홀히 여김이었더라」(창25:34). 한 그릇 식사와 맞바꾼 그 순간을 성경은 두고두고 무겁게 기억합니다. 「망령된 자가 없도록 살피라 저는 한 그릇 식물을 위하여 장자의 명분을 판 에서와 같이」(히12:16).
그런데 성경의 이야기는 장자권이 번번이 큰아들을 비껴가는 이야기이기도 합니다. 이스마엘이 아니라 이삭, 에서가 아니라 야곱, 르우벤이 아니라 유다와 요셉(대상5:1~2), 형들이 아니라 다윗입니다. 사람의 서열이 아니라 하나님의 택하심이 집안의 줄기를 정합니다.
신약은 이 낱말로 그리스도와 성도를 말합니다. 그리스도는 「많은 형제 중에서 맏아들」(롬8:29)이고, 교회는 「하늘에 기록한 장자들의 총회」(히12:23)입니다. 경홀히 여겨 팔 것이 아니라 값을 알고 붙들 자리입니다.""",
     """The birthright is the portion and the place of the firstborn: a double share of the inheritance (Deut 21:17) and the headship of the house after the father.
Its greatest scene is Esau and Jacob: "he did eat and drink, and rose up, and went his way: thus Esau despised his birthright" (Gen 25:34). Scripture remembers that traded bowl of stew with lasting weight: "lest there be any profane person, as Esau, who for one morsel of meat sold his birthright" (Heb 12:16).
Yet the Bible's story is also one of the birthright repeatedly passing over the eldest — Isaac not Ishmael, Jacob not Esau, Judah and Joseph not Reuben (1 Chr 5:1-2), David not his brothers. Not human rank but God's choosing sets the line of the house.
The New Testament uses the word for Christ and his people: he is "the firstborn among many brethren" (Rom 8:29), and the church is "the general assembly and church of the firstborn, which are written in heaven" (Heb 12:23) — a place not to be despised and sold, but to be held knowing its worth.""",
     [(1, 25, 29, 'PROTAGONIST', 7)]),

    ('SYS_GOEL', 'SYSTEM', '기업 무름', 'Kinsman Redemption', 7, """기업 무름은 가까운 친족이 값을 치르고 잃어버린 것을 되찾아 주는 제도입니다. 가난하여 판 땅을 무르고(레25:25), 종으로 팔린 몸을 무르고(레25:47~49), 대가 끊긴 집의 이름을 잇습니다. 무르는 이를 고엘이라 부릅니다.
무를 권리는 아무에게나 없습니다. 「가까운 친족이 와서」(레25:25)라야 합니다. 친족이어야 하고, 값을 치를 힘이 있어야 하고, 무르려는 마음이 있어야 합니다.
이 제도가 이야기로 살아난 자리가 룻기입니다. 보아스는 성문에서 더 가까운 친족이 무르기를 포기하는 것을 확인한 뒤 「내가 … 사서 … 죽은 자의 이름으로 그 기업을 잇게 하리라」(룻4:9~10)고 선언합니다. 잃은 땅과 끊긴 이름과 과부의 앞날이 한 사람의 값 치름으로 회복됩니다.
욥은 이 낱말로 소망을 말합니다. 「내가 알기에는 나의 구속자가 살아 계시니」(욥19:25). 구속자가 곧 고엘입니다. 값을 치르고 되찾아 주시는 분이 살아 계시다는 고백이, 구속이라는 말의 뿌리 그림입니다.""",
     """Kinsman redemption is the institution by which a near relative pays the price to recover what was lost: land sold in poverty (Lev 25:25), a body sold into servitude (Lev 25:47-49), the name of a house left without heir. The one who redeems is the goel.
Not anyone may redeem. "If any of his kin come to redeem it" (Lev 25:25) — he must be kin, he must be able to pay, and he must be willing.
The institution comes alive as story in Ruth. At the gate, after the nearer kinsman declines, Boaz declares: "I have bought... to raise up the name of the dead upon his inheritance" (Ruth 4:9-10). Lost land, a cut-off name, and a widow's future are restored by one man's payment.
Job speaks his hope with this word: "I know that my redeemer liveth" (Job 19:25) — my goel. That the One who pays and recovers is alive: this is the root picture behind the word redemption.""",
     [(8, 4, 1, 'PROTAGONIST', 8), (3, 25, 25, 'MENTIONED', 6)]),

    ('SYS_SYNAGOGUE', 'SYSTEM', '회당', 'Synagogue', 6, """회당은 유대인이 모여 성경을 읽고 배우고 기도하는 집입니다. 제사는 예루살렘 성전에서만 드렸지만, 회당은 유대인이 사는 곳이면 어디든 세워졌습니다. 포로기 이후 성전에서 멀리 떨어져 살게 된 백성에게 말씀을 붙드는 자리가 된 것입니다.
회당의 중심은 제단이 아니라 두루마리입니다. 안식일마다 율법과 선지자의 글을 읽고 풀었습니다. 예수님의 공생애가 이 자리에서 시작됩니다. 「안식일에 자기 규례대로 회당에 들어가사 성경을 읽으려고 서시매」(눅4:16). 나사렛 회당에서 이사야를 펴 읽으신 그 장면입니다.
바울의 전도 여행도 회당에서 회당으로 이어집니다. 「저희가 … 유대인의 회당이 있는 데살로니가에 이르니 바울이 자기의 규례대로 저희에게로 들어가서 세 안식일에 성경을 가지고 강론하며」(행17:1~2). 성경이 이미 펴져 있는 자리가 복음의 첫 문이 된 것입니다.
말씀을 읽고 풀고 기도하는 모임이라는 회당의 뼈대는 초대 교회 예배의 밑그림이 되었습니다.""",
     """The synagogue is the house where Jews gathered to read the Scriptures, to learn, and to pray. Sacrifice belonged to the temple in Jerusalem alone, but synagogues rose wherever Jews lived — after the exile they became the place where a people far from the temple held on to the word.
Its center is not an altar but a scroll. Every sabbath the law and the prophets were read and expounded. Jesus' public ministry opens here: "as his custom was, he went into the synagogue on the sabbath day, and stood up for to read" (Luke 4:16) — the scene at Nazareth where he unrolled Isaiah.
Paul's journeys likewise run from synagogue to synagogue: "where was a synagogue of the Jews: and Paul, as his manner was, went in unto them, and three sabbath days reasoned with them out of the scriptures" (Acts 17:1-2). The place where Scripture already lay open became the gospel's first doorway.
The synagogue's skeleton — reading, exposition, prayer — became the outline of the early church's worship.""",
     [(42, 4, 16, 'PROTAGONIST', 7)]),

    # ═══ 사물 (OBJECT) ═══
    ('OBJ_NOAHS_ARK', 'OBJECT', '노아의 방주', "Noah's Ark", 8, """노아의 방주는 홍수 심판에서 노아의 여덟 식구와 짐승들을 건진 배입니다. 잣나무로 짓고 안팎에 역청을 칠했으며, 길이 삼백 규빗, 너비 오십 규빗, 높이 삼십 규빗의 세 층 배였습니다(창6:14~16).
방주의 설계는 노아의 것이 아닙니다. 치수와 재료와 문의 자리까지 하나님이 일러 주셨고, 노아의 몫은 「하나님이 자기에게 명하신 대로 다 준행」(창6:22)하는 것이었습니다. 구원의 길은 사람이 고안하는 것이 아니라 받아 순종하는 것임을 방주가 먼저 보여 줍니다.
문이 하나라는 것과, 그 문을 하나님이 닫으셨다는 것이 이 이야기의 무게입니다. 「여호와께서 그를 들여보내고 문을 닫으시니라」(창7:16). 들어간 자와 남은 자를 가른 것은 배의 성능이 아니라 그 닫힌 문이었습니다.
신약은 방주에서 구원의 그림을 읽습니다. 「방주 예비할 동안 하나님이 오래 참고 기다리실 때에 … 겨우 여덟 명이라 물로 말미암아 구원을 얻었으니」(벧전3:20). 예수님은 그 날들을 마지막 때의 거울로 세우십니다(마24:37~39).""",
     """Noah's ark is the vessel that carried Noah's household of eight and the animals through the judgment of the flood: gopher wood, pitched within and without, three hundred cubits long, fifty wide, thirty high, in three stories (Gen 6:14-16).
The design was not Noah's. God dictated the measurements, the material, even the placing of the door; Noah's part was that he "did according unto all that God commanded him" (Gen 6:22). The way of salvation is not devised but received and obeyed — the ark shows it first.
The weight of the story lies in the single door, and in who shut it: "and the LORD shut him in" (Gen 7:16). What divided those inside from those outside was not the ship's engineering but that closed door.
The New Testament reads salvation in the ark: "the longsuffering of God waited in the days of Noah, while the ark was a preparing, wherein few, that is, eight souls were saved by water" (1 Pet 3:20). Jesus holds those days up as a mirror of the last (Matt 24:37-39).""",
     [(1, 6, 14, 'PROTAGONIST', 8)]),

    ('OBJ_BRONZE_SERPENT', 'OBJECT', '놋뱀', 'Bronze Serpent', 8, """놋뱀은 광야에서 불뱀에 물린 백성을 살린 표입니다. 원망하다 불뱀에 물려 죽어 가던 백성에게 하나님은 뱀을 만들어 장대 위에 달게 하셨습니다. 「모세가 놋뱀을 만들어 장대 위에 다니 뱀에게 물린 자마다 놋뱀을 쳐다본즉 살더라」(민21:9).
처방이 이상할 만큼 단순합니다. 바르는 약도, 치러야 할 값도 없습니다. 쳐다보는 것뿐입니다. 죽어 가는 자가 할 수 있는 가장 작은 일에 살길을 걸어 두신 것입니다.
예수님은 이 장면을 자기 십자가의 그림으로 삼으셨습니다. 「모세가 광야에서 뱀을 든 것같이 인자도 들려야 하리니 이는 저를 믿는 자마다 영생을 얻게 하려 하심이니라」(요3:14~15). 들린 것을 바라보는 자가 산다는 문법이 그대로 이어집니다.
뒷이야기가 하나 있습니다. 세월이 지나 이 놋뱀 자체가 분향의 대상이 되자 히스기야가 그것을 부수고 느후스단, 곧 놋 조각이라 불렀습니다(왕하18:4). 살리던 표라도 붙드는 순간 우상이 된다는 경고가 같은 물건에 새겨져 있습니다.""",
     """The bronze serpent is the sign that saved the people bitten by fiery serpents in the wilderness. To a murmuring people dying of snakebite God said to make a serpent and set it on a pole: "if a serpent had bitten any man, when he beheld the serpent of brass, he lived" (Num 21:9).
The prescription is startlingly simple. No salve, no payment — only a look. The way of life was hung on the smallest act a dying person could still perform.
Jesus took this scene as the picture of his own cross: "as Moses lifted up the serpent in the wilderness, even so must the Son of man be lifted up: that whosoever believeth in him should not perish, but have eternal life" (John 3:14-15). The grammar carries straight over: the one who looks to the lifted-up one lives.
There is a sequel. Centuries later the bronze serpent itself was receiving incense, and Hezekiah broke it in pieces and called it Nehushtan — a piece of brass (2 Kgs 18:4). Even a sign that once saved becomes an idol the moment it is clung to; the warning is engraved on the same object.""",
     [(4, 21, 4, 'PROTAGONIST', 8)]),

    ('OBJ_STONE_TABLETS', 'OBJECT', '십계명 돌판', 'Tablets of the Law', 7, """십계명 돌판은 하나님이 친히 쓰신 언약의 문서입니다. 「여호와께서 … 친히 쓰신 증거판 둘을 모세에게 주시니 이는 돌판이요 하나님이 친수로 쓰신 것이더라」(출31:18). 시내산 언약의 조문이 사람의 기록이 아니라 하나님의 글씨로 남은 것입니다.
첫 돌판은 산 아래에서 깨졌습니다. 금송아지 앞에서 춤추는 백성을 본 모세가 「그 판들을 산 아래로 던져 깨뜨리니라」(출32:19). 언약 문서가 깨진 그 장면이 언약 자체가 깨어진 현장을 그대로 보여 줍니다.
그러나 하나님은 다시 쓰셨습니다. 「너는 처음과 같은 두 돌판을 다듬어 가지고 … 네가 깨뜨린 처음 판에 있던 말을 내가 그 판에 쓰리라」(신10:1~2). 다시 새겨진 돌판은 언약궤 안에 두었습니다(신10:5). 깨어진 언약을 다시 세우시는 분이 하나님이심을 돌판의 역사가 증언합니다.
선지자들은 이 그림을 앞으로 밀고 갑니다. 새 언약에서 하나님은 돌이 아니라 마음에 쓰십니다. 「내 법을 그들의 속에 두며 그 마음에 기록하여」(렘31:33).""",
     """The stone tablets are the covenant document written by God's own hand: "tables of stone, written with the finger of God" (Exod 31:18). The terms of the Sinai covenant survive not as a human record but as God's handwriting.
The first tablets were shattered at the foot of the mountain. Seeing the people dancing before the golden calf, Moses "cast the tables out of his hands, and brake them beneath the mount" (Exod 32:19). The broken document displays the broken covenant itself.
But God wrote again: "Hew thee two tables of stone like unto the first... and I will write on the tables the words that were in the first tables which thou brakest" (Deut 10:1-2). The rewritten tablets were placed inside the ark (Deut 10:5). The history of the tablets testifies that God is the one who remakes a broken covenant.
The prophets carry the picture forward: in the new covenant God writes not on stone but on hearts — "I will put my law in their inward parts, and write it in their hearts" (Jer 31:33).""",
     [(2, 31, 18, 'PROTAGONIST', 7), (5, 10, 1, 'MENTIONED', 6)]),

    ('OBJ_URIM_THUMMIM', 'OBJECT', '우림과 둠밈', 'Urim and Thummim', 6, """우림과 둠밈은 대제사장이 하나님의 뜻을 물을 때 쓴 도구입니다. 「너는 우림과 둠밈을 판결 흉패 안에 넣어 아론으로 여호와 앞에 들어갈 때에 그 가슴에 붙이게 하라」(출28:30). 판결 흉패 안에 두었다는 것 외에 모양도 쓰는 법도 성경은 밝히지 않습니다.
분명한 것은 쓰임새입니다. 여호수아를 세울 때 「그는 제사장 엘르아살 앞에 설 것이요 엘르아살은 그를 위하여 우림의 판결법으로 여호와 앞에 물을 것이며」(민27:21)라고 했습니다. 지도자조차 자기 판단이 아니라 물어서 걷게 하신 것입니다.
사울의 마지막이 이 도구의 침묵으로 그려집니다. 「여호와께서 꿈으로도 우림으로도 선지자로도 그에게 대답지 아니하시므로」(삼상28:6). 물어도 대답이 없는 상태가 버림받음의 그림이 됩니다.
포로 귀환 뒤에는 이 도구가 없었습니다. 계보를 밝히지 못한 제사장들에게 「우림과 둠밈을 가진 제사장이 일어나기 전에는 지성물을 먹지 말라」(스2:63)고 한 것이 마지막 언급입니다. 묻는 길이 끊긴 시대의 아쉬움이 그 한 줄에 담겨 있습니다.""",
     """The Urim and Thummim were the means by which the high priest inquired of God: "thou shalt put in the breastplate of judgment the Urim and the Thummim; and they shall be upon Aaron's heart, when he goeth in before the LORD" (Exod 28:30). Beyond their place in the breastplate, Scripture describes neither their form nor their method.
Their use is clear. At Joshua's commissioning: "he shall stand before Eleazar the priest, who shall ask counsel for him after the judgment of Urim before the LORD" (Num 27:21). Even the leader was to walk by asking, not by his own judgment.
Saul's end is drawn in this instrument's silence: "the LORD answered him not, neither by dreams, nor by Urim, nor by prophets" (1 Sam 28:6). To ask and receive no answer becomes the picture of abandonment.
After the return from exile the instrument was gone. Priests who could not prove their line were told not to eat the most holy things "till there stood up a priest with Urim and with Thummim" (Ezra 2:63) — the last mention, carrying the ache of an age in which the way of asking had ceased.""",
     [(2, 28, 30, 'MENTIONED', 6)]),

    ('OBJ_AARONS_ROD', 'OBJECT', '아론의 싹난 지팡이', "Aaron's Rod", 6, """아론의 싹난 지팡이는 하나님이 세우신 제사장이 누구인지를 판가름한 표입니다. 고라의 반역 뒤에도 원망이 그치지 않자, 하나님은 지파마다 지팡이 하나씩 열둘을 증거궤 앞에 두게 하셨습니다.
이튿날 아론의 지팡이에서만 일이 일어났습니다. 「아론의 지팡이에 움이 돋고 순이 나고 꽃이 피어서 살구 열매가 열렸더라」(민17:8). 움과 순과 꽃과 열매, 네 단계가 하룻밤에 한 지팡이 위에 있었습니다.
표가 말하는 것은 분명합니다. 잘린 지 오래된 죽은 나무가 살아난 것처럼, 제사장 직분은 사람의 주장이 아니라 하나님이 살리시고 세우시는 자리라는 것입니다. 그 지팡이는 「패역한 자에 대한 표징」(민17:10)으로 증거궤 앞에 보관되었고, 히브리서는 언약궤 안의 물건으로 만나 항아리·언약의 비석과 함께 그것을 꼽습니다(히9:4).
죽은 것에서 싹이 나게 하시는 하나님의 문법은 여기서 멈추지 않습니다. 「이새의 줄기에서 한 싹이 나며」(사11:1)로 이어지는 그림의 첫 자리에 이 지팡이가 서 있습니다.""",
     """Aaron's rod that budded is the sign that settled whom God had appointed priest. When murmuring continued even after Korah's rebellion, God had twelve rods, one per tribe, laid before the testimony.
By morning something had happened to Aaron's rod alone: it "was budded, and brought forth buds, and bloomed blossoms, and yielded almonds" (Num 17:8) — bud, shoot, blossom, and fruit on one rod in a night.
The sign's meaning is plain: as a long-dead stick came alive, so the priesthood is not a claim men make but a station God quickens and appoints. The rod was kept before the testimony "for a token against the rebels" (Num 17:10), and Hebrews lists it among the contents of the ark with the manna and the tables of the covenant (Heb 9:4).
God's grammar of life from dead wood does not stop here. "There shall come forth a rod out of the stem of Jesse" (Isa 11:1) — at the head of that picture stands this rod.""",
     [(4, 17, 1, 'PROTAGONIST', 7)]),

    ('OBJ_SHOWBREAD', 'OBJECT', '진설병', 'Showbread', 6, """진설병은 성소의 상 위에 늘 차려 둔 열두 덩이 떡입니다. 「상 위에 진설병을 두어 항상 내 앞에 있게 할지니라」(출25:30). 고운 가루로 구운 떡 열둘을 두 줄로 놓고 안식일마다 새것으로 바꾸었으며, 물린 떡은 제사장이 거룩한 곳에서 먹었습니다(레24:5~9).
열두 덩이는 열두 지파입니다. 열두 지파가 언제나 하나님 앞에 있다는 것, 그리고 그 백성의 양식이 하나님 앞에서 나온다는 것을 상 위의 떡이 말없이 증언합니다. 이름 그대로 「항상 내 앞에」 있는 떡입니다.
이 떡이 이야기에 등장하는 유명한 자리가 다윗입니다. 도망하던 다윗이 놉에서 제사장의 떡, 곧 물려 낸 진설병을 받아 먹었습니다(삼상21:6). 예수님은 안식일 논쟁에서 이 일을 앞세우십니다. 「다윗이 … 하나님의 전에 들어가서 제사장 외에는 자기나 그 함께한 자들이 먹지 못하는 진설병을 먹지 아니하였느냐」(마12:3~4).
규례가 지키려던 것이 무엇인지, 곧 사람을 살리시는 하나님의 뜻이 그 논쟁에서 드러납니다.""",
     """The showbread was the twelve loaves kept always on the table of the sanctuary: "thou shalt set upon the table shewbread before me alway" (Exod 25:30). Twelve loaves of fine flour in two rows, renewed every sabbath, the old loaves eaten by the priests in the holy place (Lev 24:5-9).
Twelve loaves are twelve tribes. The bread on the table testified silently that the twelve tribes stand always before God, and that the people's food comes from before his face — bread, as the name says, "before me alway."
Its famous narrative moment belongs to David: fleeing, he received at Nob the priests' bread, the removed showbread (1 Sam 21:6). Jesus put the incident at the front of the sabbath dispute: "Have ye not read what David did... how he entered into the house of God, and did eat the shewbread, which was not lawful for him to eat?" (Matt 12:3-4).
In that dispute what the rule existed to guard — God's will to give people life — comes to light.""",
     [(2, 25, 23, 'MENTIONED', 6), (3, 24, 5, 'PROTAGONIST', 6)]),

    ('OBJ_INCENSE_ALTAR', 'OBJECT', '분향단', 'Altar of Incense', 6, """분향단은 성소 안 휘장 앞에 둔 금 입힌 단입니다. 여기서는 제물이 아니라 향을 태웁니다. 「아론이 그 위에 향기로운 향을 사르되 아침마다 … 저녁때 등불을 켤 때에도 … 이 향은 너희가 대대로 여호와 앞에 끊지 못할지니라」(출30:7~8).
아침저녁으로 끊이지 않는 향의 자리는 성경 안에서 기도의 그림으로 읽혀 왔습니다. 「나의 기도가 주의 앞에 분향함과 같이 되며」(시141:2). 향이 위로 오르듯 기도가 오르고, 향이 끊이지 않아야 하듯 기도도 끊이지 않아야 합니다.
이 단에는 다른 향, 다른 불을 놓을 수 없었습니다(출30:9). 나답과 아비후가 「여호와의 명하시지 않은 다른 불」(레10:1)로 죽은 일이 그 경계의 무게를 보여 줍니다.
요한계시록은 이 그림을 하늘 성소에서 다시 보여 줍니다. 「향연이 성도의 기도와 함께 천사의 손으로부터 하나님 앞으로 올라가는지라」(계8:4). 땅의 작은 단에서 오르던 연기가 성도의 기도가 하나님 앞에 이르는 길의 그림이었던 것입니다.""",
     """The altar of incense was the gold-covered altar before the veil, on which not sacrifice but incense was burned: "Aaron shall burn thereon sweet incense every morning... and at even... a perpetual incense before the LORD throughout your generations" (Exod 30:7-8).
The place of unceasing morning-and-evening incense has been read within Scripture itself as the picture of prayer: "Let my prayer be set forth before thee as incense" (Ps 141:2). As incense rises, prayer rises; as incense must not cease, neither must prayer.
No strange incense, no strange fire could be brought to it (Exod 30:9). Nadab and Abihu, who died offering "strange fire before the LORD, which he commanded them not" (Lev 10:1), show the weight of that boundary.
Revelation shows the picture again in the heavenly sanctuary: "the smoke of the incense, which came with the prayers of the saints, ascended up before God" (Rev 8:4). The smoke that rose from the small altar on earth was all along a picture of the saints' prayers reaching God.""",
     [(2, 30, 1, 'PROTAGONIST', 6)]),

    ('OBJ_LAVER', 'OBJECT', '물두멍', 'Bronze Laver', 5, """물두멍은 회막 문과 번제단 사이에 둔 놋 대야입니다. 제사장은 성소에 들어가기 전, 단에 가까이 가기 전에 여기서 수족을 씻었습니다. 「아론과 그 아들들이 그 두멍에서 수족을 씻되 … 죽기를 면할 것이요」(출30:19~21). 씻는 일이 권면이 아니라 생사의 조건이었습니다.
자리가 뜻을 말합니다. 물두멍은 제단과 성소 사이에 있습니다. 제사로 죄가 처리된 뒤에도, 섬기러 나아가는 걸음에는 매번의 씻음이 필요하다는 배치입니다.
이 대야는 「회막문에서 수종드는 여인들의 거울로 만들었더라」(출38:8)는 기록이 남아 있습니다. 자기를 비추던 물건이 씻는 물건이 된 것입니다.
씻음의 그림은 신약으로 이어집니다. 예수님은 제자들의 발을 씻기시며 「이미 목욕한 자는 발밖에 씻을 필요가 없느니라」(요13:10) 하셨고, 교회는 「물로 씻어 말씀으로 깨끗하게 하사」(엡5:26)라는 문장으로 그 은혜를 고백합니다.""",
     """The bronze laver stood between the door of the tabernacle and the altar. Before entering the sanctuary or approaching the altar the priests washed hands and feet there: "so they shall wash their hands and their feet, that they die not" (Exod 30:19-21). Washing was not advice but a condition of life and death.
The position speaks: the laver stands between altar and sanctuary. Even after sin has been dealt with at the altar, every approach to serve requires washing anew.
One detail is preserved: it was made "of the lookingglasses of the women assembling... at the door" (Exod 38:8) — mirrors that had reflected the self became the vessel of cleansing.
The picture of washing runs on into the New Testament. Washing his disciples' feet Jesus said, "He that is washed needeth not save to wash his feet" (John 13:10), and the church confesses the grace of being cleansed "with the washing of water by the word" (Eph 5:26).""",
     [(2, 30, 17, 'PROTAGONIST', 5)]),

    ('OBJ_VEIL', 'OBJECT', '지성소 휘장', 'Temple Veil', 8, """휘장은 성소와 지성소를 가르는 막입니다. 청색 자색 홍색 실과 가늘게 꼰 베실로 짜고 그룹을 수놓았습니다(출26:31). 이 막 안쪽, 곧 지성소에는 대제사장이 일 년에 한 번, 피를 가지고만 들어갔습니다(레16:2·34).
휘장이 말하는 것은 막힘입니다. 거룩하신 하나님과 죄인 사이가 열려 있지 않다는 것을, 성소 한가운데 드리운 막이 매일 증언했습니다. 히브리서는 이것을 「성령이 이로써 보이신 것은 … 성소에 들어가는 길이 아직 나타나지 아니한 것이라」(히9:8)고 풉니다.
그래서 예수님이 숨지시던 순간의 기록이 무겁습니다. 「성소 휘장이 위로부터 아래까지 찢어져 둘이 되고」(마27:51). 위로부터 찢어졌다는 것은 사람의 손이 아니라는 뜻입니다. 막이 하나님 쪽에서 열렸습니다.
히브리서는 그 열린 길을 이렇게 부릅니다. 「그 길은 우리를 위하여 휘장 가운데로 열어 놓으신 새롭고 산 길이요 휘장은 곧 저의 육체니라」(히10:20). 담대히 나아가라는 초청(히10:19·22)이 찢어진 휘장 앞에서 주어집니다.""",
     """The veil was the curtain dividing the holy place from the most holy: blue, purple, scarlet, and fine twined linen, with cherubim worked into it (Exod 26:31). Behind it the high priest entered once a year, and only with blood (Lev 16:2, 34).
The veil speaks of barred access. That the way between the holy God and sinners does not stand open was testified daily by the curtain hung in the sanctuary's midst. Hebrews reads it so: "the Holy Ghost this signifying, that the way into the holiest of all was not yet made manifest" (Heb 9:8).
Hence the weight of the record at the moment Jesus died: "the veil of the temple was rent in twain from the top to the bottom" (Matt 27:51). Torn from the top — not by human hands. The barrier was opened from God's side.
Hebrews names the opened way: "a new and living way, which he hath consecrated for us, through the veil, that is to say, his flesh" (Heb 10:20). The invitation to draw near with boldness (Heb 10:19, 22) is issued before a torn veil.""",
     [(2, 26, 31, 'MENTIONED', 6), (40, 27, 51, 'MENTIONED', 8)]),

    ('OBJ_MERCY_SEAT', 'OBJECT', '속죄소', 'Mercy Seat', 7, """속죄소는 언약궤의 금 덮개입니다. 정금으로 만들고 두 그룹이 날개를 펴 그 위를 덮게 했습니다(출25:17~20). 크기는 궤와 꼭 맞아, 안에 든 언약의 돌판을 덮는 뚜껑이 됩니다.
하나님은 이 자리를 만남의 자리로 정하셨습니다. 「거기서 내가 너와 만나고 속죄소 위 곧 증거궤 위에 있는 두 그룹 사이에서 … 네게 이르리라」(출25:22). 언약궤에서 말씀이 나오는 자리가 바로 이 덮개 위입니다.
속죄일에는 대제사장이 이 덮개에 피를 뿌렸습니다(레16:14). 그 그림이 뜻하는 바가 여기 있습니다. 궤 안에는 백성이 깨뜨린 언약의 돌판이 있고, 그 위를 피 뿌려진 덮개가 덮습니다. 율법의 고발과 하나님의 임재 사이에 피가 놓이는 것입니다.
신약이 그리스도를 가리켜 쓰는 「화목제물」(롬3:25)이라는 낱말은 칠십인역이 속죄소를 부르던 바로 그 낱말입니다. 피 뿌려진 그 자리가 사람이 아니라 그리스도 자신이라는 선언입니다.""",
     """The mercy seat is the golden cover of the ark: pure gold, with two cherubim spreading their wings above it (Exod 25:17-20). Made to the ark's exact measure, it lies as a lid over the tables of the covenant within.
God appointed it the meeting place: "there I will meet with thee, and I will commune with thee from above the mercy seat, from between the two cherubims" (Exod 25:22). The place from which the word came forth is this cover.
On the Day of Atonement the high priest sprinkled blood upon it (Lev 16:14). The picture's meaning lies here: inside the ark, the tables of a covenant the people had broken; over them, a cover sprinkled with blood. Between the law's accusation and God's presence, blood is set.
The word the New Testament uses of Christ — "whom God hath set forth to be a propitiation" (Rom 3:25) — is the very word the Septuagint used for the mercy seat. The blood-sprinkled place, it declares, is no longer an object but Christ himself.""",
     [(2, 25, 10, 'MENTIONED', 7), (3, 16, 11, 'MENTIONED', 7)]),

    # ═══ 절기 (FEAST — 2026-09-02 추가분: 월삭·금식일. 사용자 지시.
    #     교회력 절기가 아니라 성경 본문의 절기다) ═══
    ('FEAST_NEW_MOON', 'FEAST', '월삭', 'New Moon', 6, """월삭은 매달 첫날, 곧 초하루를 지키는 절기입니다. 새 달이 뜨는 날 나팔을 불고 제사를 드렸습니다. 「너희 희락의 날과 너희 정한 절기와 월삭에는 … 나팔을 불라」(민10:10). 달마다 드리는 그 날의 제사 규례가 따로 정해져 있었습니다(민28:11~15).
월삭은 일상 달력에 새겨진 절기입니다. 한 해에 한 번이 아니라 달마다 돌아옵니다. 시간의 마디마다 새로 시작하게 하시는 하나님을 기억하는 날이었고, 안식일과 나란히 불리곤 했습니다(왕하4:23·암8:5).
다윗 이야기에 이 날의 실제 모습이 남아 있습니다. 「내일은 월삭인즉 내가 마땅히 왕을 모시고 앉아 식사를 하여야 할 것이나」(삼상20:5). 왕의 식탁에 자리가 정해져 있는 잔칫날이었던 것입니다.
선지자들은 마음 없는 월삭을 꾸짖었습니다. 「내가 … 월삭과 안식일과 대회로 모이는 것을 견디지 못하겠노라」(사1:13). 바울은 월삭이 「장래 일의 그림자이나 몸은 그리스도의 것이니라」(골2:16~17)고 정리합니다. 달마다 새로 시작하게 하던 그 날이 가리키던 실체가 그리스도라는 것입니다.""",
     """The new moon was the feast of the first day of each month. When the new moon appeared, trumpets were blown and sacrifices offered: "in the beginnings of your months, ye shall blow with the trumpets" (Num 10:10), with its own prescribed offerings (Num 28:11-15).
It is a feast engraved into the ordinary calendar — returning not once a year but every month, remembering at each joint of time the God who gives new beginnings, and often named alongside the sabbath (2 Kgs 4:23; Amos 8:5).
The story of David preserves the day's actual shape: "To morrow is the new moon, and I should not fail to sit with the king at meat" (1 Sam 20:5) — a feast day with assigned places at the king's table.
The prophets rebuked new moons kept without heart ("the new moons and sabbaths... I cannot away with," Isa 1:13), and Paul settles the matter: the new moon is "a shadow of things to come; but the body is of Christ" (Col 2:16-17). What the monthly new beginning pointed to has arrived in him.""",
     [(4, 28, 11, 'PROTAGONIST', 6), (9, 20, 5, 'MENTIONED', 5)]),

    ('FEAST_FASTS', 'FEAST', '금식일', 'Fast Days', 6, """금식일은 먹기를 그치고 하나님 앞에 마음을 쏟는 날입니다. 율법이 정한 금식은 속죄일 하나였습니다. 「너희는 스스로 괴롭게 하고」(레16:29)가 그 날의 명령입니다.
포로기를 지나며 정한 금식일들이 더해졌습니다. 예루살렘이 무너지던 일들을 기억하는 넷째 달, 다섯째 달, 일곱째 달, 열째 달의 금식입니다. 스가랴는 그 날들이 바뀔 것을 약속합니다. 「사월의 금식과 오월의 금식과 칠월의 금식과 시월의 금식이 변하여 유다 족속에게 기쁨과 즐거움과 희락의 절기가 되리니」(슥8:19). 슬픔을 새기던 날이 잔치가 되는 것입니다.
성경은 금식 자체보다 금식하는 마음을 묻습니다. 「나의 기뻐하는 금식은 흉악의 결박을 풀어 주며 … 주린 자에게 네 식물을 나눠 주는 것이 아니겠느냐」(사58:6~7). 굶는 일이 아니라 돌이키고 나누는 일이 참 금식이라는 것입니다.
예수님은 금식을 폐하지 않으시고 방향을 고치십니다. 「금식할 때에 외식하는 자들과 같이 슬픈 기색을 내지 말라 … 은밀한 중에 보시는 네 아버지께서 갚으시리라」(마6:16·18). 사람에게 보이는 금식이 아니라 아버지께 하는 금식입니다.""",
     """A fast day is a day of ceasing to eat and pouring out the heart before God. The law appointed one fast, the Day of Atonement: "ye shall afflict your souls" (Lev 16:29).
Through the exile, appointed fasts were added — the fasts of the fourth, fifth, seventh, and tenth months, marking the stages of Jerusalem's fall. Zechariah promises their transformation: "The fast of the fourth month, and the fast of the fifth, and the fast of the seventh, and the fast of the tenth, shall be to the house of Judah joy and gladness, and cheerful feasts" (Zech 8:19). Days that engraved grief will become festivals.
Scripture asks less about the fast than about the heart that fasts: "Is not this the fast that I have chosen? to loose the bands of wickedness... and that thou deal thy bread to the hungry?" (Isa 58:6-7). True fasting is not going hungry but turning and sharing.
Jesus does not abolish fasting; he redirects it: "when ye fast, be not, as the hypocrites, of a sad countenance... thy Father, which seeth in secret, shall reward thee openly" (Matt 6:16-18) — fasting done not before people but before the Father.""",
     [(38, 8, 18, 'PROTAGONIST', 6), (23, 58, 1, 'MENTIONED', 6)]),

    ('OBJ_RAINBOW', 'OBJECT', '무지개', 'Rainbow', 7, """무지개는 홍수 뒤에 하나님이 세우신 언약의 표입니다. 「내가 내 무지개를 구름 속에 두었나니 이것이 나의 세상과의 언약의 증거니라」(창9:13). 다시는 물로 모든 생물을 멸하지 않겠다는 약속이 하늘에 걸렸습니다.
이 표의 방향이 뜻밖입니다. 「무지개가 구름 사이에 있으리니 내가 보고 … 영원한 언약을 기억하리라」(창9:16). 무지개는 사람더러 보라고 있기 전에 하나님이 보시는 표입니다. 기억하셔야 할 분이 우리가 아니라 하나님이시라는 것, 언약의 무게가 그분 쪽에 실려 있다는 것이 이 구절의 위로입니다.
비가 지나가야 무지개가 섭니다. 심판의 구름 위에 약속이 걸린다는 배치 자체가 이 표의 문법입니다.
성경은 마지막까지 이 그림을 놓지 않습니다. 에스겔이 본 여호와의 영광 둘레에 「비 오는 날 구름에 있는 무지개 같은」(겔1:28) 광채가 있었고, 요한이 본 하늘 보좌에도 「무지개가 있어 모양이 녹보석 같더라」(계4:3)고 했습니다. 보좌를 두른 것이 언약의 표라는 것, 곧 다스리시는 분이 약속을 지키시는 분이라는 그림입니다.""",
     """The rainbow is the covenant sign God set after the flood: "I do set my bow in the cloud, and it shall be for a token of a covenant between me and the earth" (Gen 9:13). The promise never again to destroy all flesh by water was hung in the sky.
The sign's direction is unexpected: "the bow shall be in the cloud; and I will look upon it, that I may remember the everlasting covenant" (Gen 9:16). Before it is something for us to see, it is something God sees. The comfort of the verse is that the one who must remember is God, and the covenant's weight rests on his side.
A rainbow stands only after rain has passed. That the promise is hung upon the clouds of judgment is the sign's own grammar.
Scripture keeps the picture to the end. Around the glory Ezekiel saw was brightness "as the appearance of the bow that is in the cloud in the day of rain" (Ezek 1:28), and around the throne John saw "a rainbow... in sight like unto an emerald" (Rev 4:3). What encircles the throne is a covenant sign: the one who reigns is the one who keeps his word.""",
     [(1, 9, 8, 'PROTAGONIST', 7)]),
)


def _vid(conn, b, c, v):
    r = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
        (b, c, v)).fetchone()
    return r[0] if r else None


def _peri(conn, vid):
    r = conn.execute(
        "SELECT pericope_id FROM sys_pericope_asset WHERE peri_type='BODY'"
        " AND start_vid<=? AND end_vid>=? AND record_status='LIVE'",
        (vid, vid)).fetchone()
    return r[0] if r else None


def check(conn, verbose=True):
    """게이트 — 초안 무결. → 오류 목록."""
    err = []
    seen = set()
    for code, etype, ko, en, imp, dko, den, peris in DRAFT:
        if code in seen:
            err.append('중복 코드: ' + code)
        seen.add(code)
        if etype not in ('SYSTEM', 'OBJECT', 'FEAST'):
            err.append('%s: 유형 %s' % (code, etype))
        if not (ko and en):
            err.append('%s: 이름 빠짐' % code)
        for lang, d in (('KO', dko), ('EN', den)):
            if len(d) < 300:
                err.append('%s %s 설명문 %d자: 너무 짧다' % (code, lang, len(d)))
            if '\n\n' in d:
                err.append('%s %s: 빈 줄(이중 엔터)' % (code, lang))
        # 「—」 금지는 **한국어 문체 규칙**이다(§28-6) — 영어 대시는 정상 부호.
        if '—' in dko:
            err.append('%s KO: 「—」 수사 대시' % code)
        if not (400 <= len(dko) <= 1200):
            err.append('%s KO %d자 — 표준(절기 650~1000) 밖' % (code, len(dko)))
        for b, c, v, rel, pimp in peris:
            vid = _vid(conn, b, c, v)
            if vid is None:
                err.append('%s: 없는 절 %d %d:%d' % (code, b, c, v))
                continue
            if _peri(conn, vid) is None:
                err.append('%s: %d %d:%d 를 덮는 BODY 단락이 없다' % (code, b, c, v))
            if rel not in ('PROTAGONIST', 'MENTIONED'):
                err.append('%s: rel %s' % (code, rel))
    if verbose:
        for e in err:
            print('  ⚠', e)
        print('초안 %d개 · 오류 %d' % (len(DRAFT), len(err)))
    return err


def apply(conn, verbose=True):
    err = check(conn, verbose=False)
    if err:
        for e in err:
            print('  ⚠', e)
        print('오류 %d — 적재하지 않는다' % len(err))
        return 0
    n_e = n_t = n_p = 0
    for code, etype, ko, en, imp, dko, den, peris in DRAFT:
        row = conn.execute(
            "SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
            (code,)).fetchone()
        if row:
            eid = row[0]
        else:
            conn.execute(
                "INSERT INTO sys_entity_master (entity_code, entity_type,"
                " importance, record_status) VALUES (?,?,?, 'LIVE')",
                (code, etype, imp))
            eid = conn.execute(
                "SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
                (code,)).fetchone()[0]
            n_e += 1
            if verbose:
                print('  + %s %s' % (code, ko))
        for tt, lang, body in (('ENTITY_NAME', 'KO', ko),
                               ('ENTITY_NAME', 'EN', en),
                               ('ENTITY_DESC', 'KO', dko),
                               ('ENTITY_DESC', 'EN', den)):
            cur = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset"
                " WHERE text_type=? AND clicked_id=? AND lang_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (tt, eid, lang)).fetchone()
            if cur is None:
                conn.execute(
                    "INSERT INTO sys_text_asset (clicked_id, text_type,"
                    " lang_code, contents, record_status)"
                    " VALUES (?,?,?,?, 'LIVE')", (eid, tt, lang, body))
                n_t += 1
            elif cur[1] != body:
                conn.execute("UPDATE sys_text_asset SET contents=?"
                             " WHERE sys_text_id=?", (body, cur[0]))
                n_t += 1
        for b, c, v, rel, pimp in peris:
            pid = _peri(conn, _vid(conn, b, c, v))
            dup = conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_PERI'"
                " AND clicked_id=? AND target_id=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (eid, pid)).fetchone()
            if not dup:
                conn.execute(
                    "INSERT INTO sys_link_asset (link_type, clicked_id,"
                    " target_id, rel_code, importance, record_status)"
                    " VALUES ('ENTI_PERI', ?, ?, ?, ?, 'LIVE')",
                    (eid, pid, rel, pimp))
                n_p += 1
    conn.commit()
    print('엔티티 +%d · 텍스트 %d · 단락연결 +%d' % (n_e, n_t, n_p))
    return n_e


def status(conn):
    for et in ('SYSTEM', 'OBJECT'):
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_entity_master WHERE entity_type=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (et,)).fetchone()[0]
        print('%s LIVE %d' % (et, n))


def selftest():
    """게이트·탐지력 — **적재하지 않는다**(검사가 쓰기를 하면 안 된다)."""
    conn = appdb.connect(DB)
    ok = fail = 0

    def t(name, cond, e=''):
        nonlocal ok, fail
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', name, e))
        ok += cond
        fail += (not cond)

    err = check(conn, verbose=False)
    t('초안 전체가 게이트를 넘는다', not err, err[:3])
    t('초안 23개(제도 10·사물 11·절기 2)', len(DRAFT) == 23, len(DRAFT))
    # 탐지력
    g = globals()
    old = g['DRAFT']
    try:
        bad = list(old[:1])
        bad[0] = bad[0][:7] + ([(99, 1, 1, 'PROTAGONIST', 5)],)
        g['DRAFT'] = tuple(bad)
        t('★ 탐지력 — 없는 절을 잡는다', bool(check(conn, verbose=False)))
        bad[0] = old[0][:5] + ('짧다', old[0][6], old[0][7])
        g['DRAFT'] = tuple(bad)
        t('★ 탐지력 — 짧은 설명문을 잡는다', bool(check(conn, verbose=False)))
    finally:
        g['DRAFT'] = old
    # 멱등 재료 — 이미 적재된 것의 이름이 초안과 같은가(적재 뒤에만 의미)
    same = miss = 0
    for code, _t2, ko, _en, _i, _dk, _de, _p in DRAFT:
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            " AND lang_code='KO' AND clicked_id=(SELECT entity_id FROM"
            " sys_entity_master WHERE entity_code=?)", (code,)).fetchone()
        if r is None:
            miss += 1
        elif r[0] == ko:
            same += 1
    t('적재분 이름 일치(미적재 %d)' % miss, same + miss == len(DRAFT),
      (same, miss))
    conn.close()
    print('db_entity_expand selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--status', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if a.apply:
        apply(conn)
        status(conn)
    elif a.check:
        check(conn)
    else:
        status(conn)
    conn.close()


if __name__ == '__main__':
    main()
