# -*- coding: utf-8 -*-
"""db_person_relation.py — 인물 관계의 **정비·확충 단일 도구**
(2026-09-05 신설·영구 · `--selftest` 의무).

★★★ 왜 (2026-09-05 사용자 지시 `0.person.txt`):
  「지금 인물별 계층화 데이터에 **문제가 심각한 것 같다**. 이름이 잘못
   연결된 것들이 있다. **인물과 관계유형이 잘못 연결된 것들이 매우 많다.**」

실측이 그 지적을 받쳤다 —
  · 관계 **136건**인데 관계 설명문 **5건**, 그리고 **그 5건이 전부 미아**였다
    (`clicked_id` 62833~62839 인데 `relation_id` 는 1~136).
  · `CONFLICT_TEMP` 6건 중 **4건(67%)이 오분류**(사무엘→사울 · 다윗→우리아 ·
    다윗→압살롬 · 바울→스데반). 정의는 「목적 선한 **일시적** 갈등」인데
    셋은 죽음으로 끝났고 하나는 박해다.
  · 사용자가 든 다윗 관련 34명 중 **23명이 엔티티조차 없다**(후새·잇대·
    아비가일·시므이 — 예로 든 넷이 전부 없었다).
  · 부모 방향 25건은 **전부 정확**했다(`from`=부모). 「이름이 잘못 연결」로
    보였던 것은 §190차에 고친 **라벨 방향** 문제다.

★★★ **축을 바꾸지 않고 하나 더 얹는다** (설계 판단 · 사용자 4대 차원 제안).
  사용자가 제안한 넷(언약·구속사 / 영적 멘토링 / 갈등·대적 / 회복·중보)은
  **「신학적 의미」 축**이고, 지금 `relation_cat`(FAMILY·SOCIAL·SPIRITUAL)은
  **「관계의 종류」 축**이다. **다른 축이다** — 사용자 예시에서도 밧세바는
  ①언약, 압살롬은 ③갈등인데 **둘 다 가족**이다.
  ⚠⚠ **`relation_cat` 을 4차원으로 갈아 끼우면 메시아 가계도가 죽는다** —
    `figure_tree.py` 가 이 표를 읽어 144명 족보를 그린다. 4차원만 남기면
    「누가 누구의 아버지인가」를 물을 수 없다.
  ⇒ **`redemptive_axis` 칸을 신설**한다. 가계도는 종류 축을, 묵상 화면은
    의미 축을 쓴다. 한 표가 두 축을 함께 든다.

★★ **목록은 축 하나만 보인다 — 그것이 「길어진다」의 답이다**
  (사용자 물음 「그 유형을 결합하면 매우 길어질 것이다」).
  실측 지금 라벨은 최대 15자(`[예언/책망한 이·일시갈등]`)이고 겹치는 짝은
  11%뿐이라 아직 안 길다. **그런데 관계를 제대로 채우면 곧 길어진다.**
  ⚠ 게다가 길이보다 나쁜 것이 있다 — `[예언/책망한 이·일시갈등]` 은
    **읽어도 무슨 관계인지 모른다.** 두 조각이 서로 무관해 보인다.
  ⇒ **목록에는 축**(4자 이내 · 늘 하나) **· 상세에는 세부**. 축이 둘이면
    `AXIS_RANK` 가 무거운 쪽 하나를 고른다. 길이가 구조적으로 고정된다.

⚠⚠⚠ **표가 둘이다 — 고칠 때 반드시 양쪽을 함께 고친다** (2026-09-05 실측).
  §12차 연결 통합 때 인물 관계가 통합 표로 옮겨졌는데 **옛 표를 안 지웠다.**

    sys_person_relation        135건   ← `figure_tree`(메시아 가계도)만 읽는다
    sys_link_asset ENTI_ENTI   136건   ← **화면(`entity_browser`)이 읽는다**

  둘은 거울이다(실측 어긋남 3/3 = 이번 교정분뿐). ⇒ **정본은 통합 표**이고
  옛 표는 가계도가 남겨 둔 것이다.
  ⚠⚠ 처음에 옛 표만 고쳤더니 **화면에 하나도 반영되지 않았다** — 오류도 안
    났다. 「저장은 되는데 안 보인다」(§95차)의 그 자리다.
  ⏭ 옛 표 은퇴는 `figure_tree` 를 통합 표로 옮긴 뒤에(별도 과제).

★★ **축은 저장하지 않고 계산한다** — 관계가 136건뿐이라 비용이 0 이고,
  저장하면 **두 표 중 어디에 담을지**가 다시 문제가 된다(통합 표는 모든 연결이
  공유하므로 축 칸을 달 수 없다). `axis_for()` 한 문이 답을 낸다.
  ⚠ 옛 표의 `redemptive_axis` 칸은 **관리자 조회·진단용**이다(화면은 안 읽는다).

    python db_person_relation.py --selftest    (의무)
    python db_person_relation.py --check       진단만
    python db_person_relation.py --init        redemptive_axis 칸
    python db_person_relation.py --fix-desc    미아 설명문 재연결
    python db_person_relation.py --load        그룹·인물·관계·구절
    python db_person_relation.py --fill        있는 관계에 글·구절
    python db_person_relation.py --mirror      옛 표 → 통합 표 맞추기
    python db_person_relation.py --axis        축 배정(멱등)
"""
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb                                                  # noqa: E402

#: 4대 차원 — 사용자 확정 (0.person.txt §3)
#  ⚠ **네 개를 넘리지 않는다** — 다섯째가 생기는 순간 「어디에 넣지」가 다시
#    시작되고, 그것이 지금 24종이 겪는 병이다.
AXES = (
    ('COVENANT',    '언약',  '하나님의 언약 아래 묶이거나 구속사를 함께 이룬 관계'),
    ('MENTORSHIP',  '전수',  '신앙의 유산을 물려주거나 영적으로 이끄는 관계'),
    ('CONFLICT',    '대적',  '신앙·정치·윤리의 대척점에서 시험하고 연단하는 관계'),
    ('RESTORATION', '회복',  '책망하여 돌이키게 하거나 하나님께 중보하는 관계'),
)
AXIS_CODES = tuple(a[0] for a in AXES)
AXIS_KO = {a[0]: a[1] for a in AXES}

#: 축이 둘 이상 걸릴 때 **무거운 쪽 하나**를 고른다(목록 라벨용).
#  ⚠ 순서에 뜻이 있다 — 언약은 그 관계의 **바탕**이고, 회복은 한 사건이다.
#    바탕이 사건을 이긴다(다윗-나단은 회복이지만 다윗-요나단은 언약이다).
AXIS_RANK = {'COVENANT': 0, 'MENTORSHIP': 1, 'CONFLICT': 2, 'RESTORATION': 3}

#: 세부 유형 → 기본 축. **사람이 고칠 수 있는 초안**이다(`OVERRIDE` 가 이긴다).
#  ⚠ 가족은 축이 정해지지 않는다 — 밧세바(언약)와 압살롬(대적)이 둘 다
#    가족이다. **관계마다 사람이 정한다** ⇒ 여기서는 `None`.
TYPE_AXIS = {
    # 언약 — 하나님의 언약·구속사
    'SACRED_ENCOUNTER': 'COVENANT',
    'ALLY': 'COVENANT', 'FRIEND': 'COVENANT',
    # 전수
    'MENTOR': 'MENTORSHIP', 'FOLLOWER': 'MENTORSHIP',
    'SPIRITUAL_LEGACY': 'MENTORSHIP',
    # 대적
    'ENEMY': 'CONFLICT', 'RIVAL': 'CONFLICT', 'BETRAYAL': 'CONFLICT',
    'OCCULT_DECEPTION': 'CONFLICT',
    # 회복·중보
    'ORACLE': 'RESTORATION', 'SPIRITUAL_CATALYST': 'RESTORATION',
    # 축이 정해지지 않는 것 — 관계마다 다르다
    'FATHER': None, 'MOTHER': None, 'CHILD': None, 'SPOUSE': None,
    'SIBLING': None, 'KIN': None, 'IN_LAW': None,
    'CONCUBINE': None, 'INFORMAL_UNION': None,
    'CO_WORKER': None, 'AUTHORITY': None, 'STEWARDSHIP': None,
    'CONFLICT_TEMP': None,
}

#: ★★★ **사람이 정한 축** — 유형만으로 못 정하는 것. (from 이름, to 이름) 열쇠.
#  ⚠ **번호가 아니라 이름으로 적는다** — 번호는 재적재로 갈린다(§179차 사고).
OVERRIDE = {
    # 다윗
    ('이새', '다윗'):        'COVENANT',    # 기름부음이 시작된 집
    ('다윗', '솔로몬'):      'COVENANT',    # 언약이 이어진다(삼하 7)
    ('다윗', '밧세바'):      'COVENANT',    # 죄로 시작했으나 구속사를 잇는다
    ('다윗', '압살롬'):      'CONFLICT',    # 반역
    ('다윗', '미갈'):        'CONFLICT',    # 법궤 앞에서 업신여김(삼하 6:16)
    ('사울', '다윗'):        'CONFLICT',
    ('다윗', '요압'):        'CONFLICT',    # 충신이자 피를 부른 사령관
    ('다윗', '므비보셋'):    'COVENANT',    # 요나단과의 언약을 기억함
    ('다윗', '우리아'):      'CONFLICT',
    # 모세
    ('아므람', '모세'):      'COVENANT',
    ('요게벳', '모세'):      'COVENANT',
    ('모세', '아론'):        'COVENANT',    # 형제이자 사명의 동역
    ('이드로', '모세'):      'MENTORSHIP',
    # 족장
    ('아브라함', '이삭'):    'COVENANT',
    ('사라', '이삭'):        'COVENANT',
    ('이삭', '야곱'):        'COVENANT',
    ('리브가', '야곱'):      'COVENANT',
    ('야곱', '요셉'):        'COVENANT',
    ('라헬', '요셉'):        'COVENANT',
    ('야곱', '유다'):        'COVENANT',
    ('레아', '유다'):        'COVENANT',
    # 그 밖
    ('한나', '사무엘'):      'COVENANT',
    ('엘가나', '사무엘'):    'COVENANT',
    ('사울', '요나단'):      'COVENANT',
    ('요나단', '므비보셋'):  'COVENANT',
    ('아합', '이세벨'):      'CONFLICT',
    ('모르드개', '에스더'):  'MENTORSHIP',
    ('느부갓네살', '다니엘'): 'CONFLICT',
    ('솔로몬', '여로보암 1세'): 'CONFLICT',
    ('마노아', '삼손'):      'COVENANT',
    ('기드온', '아비멜렉'):  'CONFLICT',
    ('이드로', '십보라'):    None,          # 배경 — 축 없음
    ('사울', '미갈'):        None,

    # ── 나머지 46건 (2026-09-05) ──────────────────────────────────
    # ★ 잣대 — **그 관계가 성경에서 무엇을 하는가**이지 사이가 좋은가가 아니다.
    #   구속사를 잇거나 언약 안에 묶이면 언약, 신앙을 물려주면 전수,
    #   대척점에 서면 대적, 돌이키게 하거나 중보하면 회복이다.
    # ⚠ **억지로 넷에 밀어 넣지 않는다** — 배경 인물은 `None` 으로 둔다.
    #   축이 없으면 목록에 「관계」로만 뜬다(그것으로 충분한 관계가 있다).

    # 구속사를 잇는 혈통·혼인 — 언약
    ('아므람', '아론'):      'COVENANT',    # 제사장 가문의 시작
    ('아므람', '미리암'):    'COVENANT',
    ('요게벳', '아론'):      'COVENANT',
    ('요게벳', '미리암'):    'COVENANT',
    ('아브라함', '사라'):    'COVENANT',    # 언약의 씨가 약속된 부부(창 17:19)
    ('이삭', '리브가'):      'COVENANT',
    ('야곱', '레아'):        'COVENANT',    # 유다를 낳는다 — 메시아 혈통
    ('야곱', '라헬'):        'COVENANT',
    ('레아', '요셉'):        None,          # 배경(이모)
    ('룻', '보아스'):        'COVENANT',    # 고엘 — 기업을 무름(룻 4:13)
    ('나오미', '룻'):        'COVENANT',    # 「어머니의 하나님이 나의 하나님」
    ('엘리멜렉', '나오미'):  None,          # 배경
    ('엘리멜렉', '보아스'):  None,          # 배경(친족)
    ('나오미', '보아스'):    'RESTORATION', # 고엘을 일러 준 중보의 자리
    ('엘가나', '한나'):      'COVENANT',    # 사무엘이 태어나는 자리
    ('모세', '십보라'):      None,          # 배경
    ('이드로', '십보라'):    None,

    # 형제 — 대부분 배경이지만 사명을 함께 진 짝은 언약
    ('미리암', '아론'):      None,
    ('미리암', '모세'):      'COVENANT',    # 나일강가에서 지킨 누이(출 2:4)
    ('레아', '라헬'):        'CONFLICT',    # 시기와 다툼(창 30:1)
    ('베드로', '안드레'):    'COVENANT',    # 함께 부르심 받음(마 4:18)
    ('야고보', '요한'):      'COVENANT',    # 함께 부르심 받음(마 4:21)
    ('마르다', '나사로'):    None,
    ('마르다', '마리아'):    None,
    ('나사로', '마리아'):    None,
    ('유다', '요셉'):        'CONFLICT',    # 요셉을 판 형(창 37:26)

    # 동역 — 복음이 함께 나아간 짝은 언약, 그 밖은 배경
    ('바울', '바나바'):      'COVENANT',    # 1차 전도여행을 함께
    ('베드로', '바울'):      'COVENANT',    # 갈 2:9 기둥 — 오른손을 내밀다
    ('바울', '베드로'):      'CONFLICT',    # 안디옥 충돌(갈 2:11) — 다른 줄
    ('바나바', '요한 마가'): 'RESTORATION', # 버려진 마가를 다시 세운다(행 15:39)
    ('바울', '요한 마가'):   'RESTORATION', # 「나의 일에 유익하니라」(딤후 4:11)
    ('실라', '바울'):        'COVENANT',
    ('아볼로', '바울'):      'COVENANT',
    ('빌립', '안드레'):      None,          # 배경
    ('안드레', '야고보'):    None,          # 배경
    ('갈렙', '여호수아'):    'COVENANT',    # 열 정탐꾼과 달리 믿음으로 선 둘
    ('에스라', '느헤미야'):  'COVENANT',    # 성벽과 말씀 — 회복 공동체
    ('스가랴', '학개'):      'COVENANT',    # 성전 재건을 함께 촉구
    ('에스겔', '예레미야'):  None,          # 배경(동시대)

    # 권세 아래 선 자 — 대적
    ('느부갓네살', '예레미야'): 'CONFLICT',
    ('느부갓네살', '시드기야'): 'CONFLICT',
    ('느부갓네살', '에스겔'):   'CONFLICT',

    # 그 밖
    ('삼손', '들릴라'):      'CONFLICT',    # 유혹으로 무너뜨림(삿 16)
    ('아브라함', '롯'):      'RESTORATION', # 소돔 앞에서의 중보(창 18:23~33)
    ('아브라함', '하갈'):    'CONFLICT',    # 언약을 기다리지 못하고
    #                                       사람의 방법을 택한 자리
    #                                       (창 16:4~6 · 21:9~14)
    ('사울', '미갈'):        None,

    # ── `NEW_RELATIONS` 로 들인 짝 (2026-09-05) ────────────────────
    # ⚠⚠ **여기 안 넣으면 축이 없어 묶음 밖으로 떨어진다**(실측 `[동역자]
    #   사독`이 그랬다). `--load` 가 `redemptive_axis` 칸에 넣더라도 화면은
    #   `axis_for()` 를 부르므로 **사람이 정한 표가 단일 소스**여야 한다.
    ('다윗', '후새'):        'COVENANT',
    ('다윗', '잇대'):        'COVENANT',
    ('아비가일', '다윗'):    'RESTORATION',
    ('시므이', '다윗'):      'CONFLICT',
    ('바르실래', '다윗'):    'COVENANT',
    ('아브넬', '다윗'):      'CONFLICT',
    ('나발', '다윗'):        'CONFLICT',
    ('다윗', '사독'):        'COVENANT',
    ('아히멜렉', '다윗'):    'COVENANT',
    ('다윗', '아비아달'):    'COVENANT',
    ('아기스', '다윗'):      None,          # 배경 — 이방 왕의 그늘
    ('다윗', '시바'):        None,          # 배경 — 청지기
    ('멜기세덱', '아브라함'): 'COVENANT',
    ('가인', '아벨'):        'CONFLICT',
}

#: ★★★ **오분류 교정** — (from 이름, to 이름, **지금 유형**) → 새 (cat, type)
#  또는 `None`(= 그 줄을 걷는다).
#  ⚠⚠ **열쇠에 「지금 유형」이 반드시 든다** (2026-09-05 실측으로 잡았다).
#    처음에 이름쌍만 열쇠로 삼았더니 다윗↔압살롬의 **부자 관계 행(rid 11)까지**
#    ENEMY 로 바꾸려 했다 — 주석에 「부자 행은 그대로 둔다」고 적어 놓고 코드가
#    안 지킨 것이다. 한 짝에 관계가 여럿이면 **어느 줄인지 말해야 한다.**
#  ⚠ 근거를 주석에 남긴다 — 나중에 「왜 바꿨나」를 되짚을 수 있어야 한다.
RETYPE = {
    # `CONFLICT_TEMP` 의 정의는 「**목적 선한 일시적** 갈등(바울-마가)」이다.
    ('사무엘', '사울', 'CONFLICT_TEMP'): None,
    #   ↳ 일시적이 아니라 삼상 15 의 **버리심 선언**이다. 그런데 이 짝에는
    #     이미 `SPIRITUAL/ORACLE` 이 있으므로 **바꾸면 같은 유형이 둘**이 된다
    #     ⇒ 이 줄은 **걷는다**(HIDE). 남는 ORACLE 이 그 관계를 정확히 말한다.
    ('다윗', '우리아', 'CONFLICT_TEMP'): ('SOCIAL', 'BETRAYAL'),
    #   ↳ 갈등이 아니다. 우리야는 끝까지 충성했고 **다윗이 그를 죽였다.**
    ('다윗', '압살롬', 'CONFLICT_TEMP'): ('SOCIAL', 'ENEMY'),
    #   ↳ 반역·전쟁·죽음. 「일시적」이 아니다.
    #     ⚠ **부자 관계 행(FAMILY/FATHER)은 그대로 둔다** — 둘 다 사실이고,
    #       그 겹침이 이 관계의 비극을 말한다(아버지이면서 대적).
    ('바울', '스데반', 'CONFLICT_TEMP'): ('SPIRITUAL', 'SPIRITUAL_CATALYST'),
    #   ↳ 갈등이 아니라 박해다. 그리고 그 죽음이 회심의 배경이 된다(행 7~9).
    ('사울', '다윗', 'AUTHORITY'): None,
    #   ↳ **겹침 정리** — `[권위자·경쟁자] 사울` 은 읽어도 새 정보가 없다.
    #     축이 둘 다 대적이고, 이 관계의 본질은 시기와 추격이다(삼상 18:9).
    #     「사울이 다윗의 왕이었다」는 사실은 **관계 설명문(rid 2)이 이미
    #     담고 있다** — 라벨을 늘려 두 번 말하지 않는다.
    #   ⚠ 다른 겹침은 **정당하므로 안 건드린다** — 모세↔아론(형제이자 상하) ·
    #     아합↔이세벨(부부이자 동역) · 다윗↔압살롬(아버지이자 대적)은 그
    #     겹침이 곧 그 관계의 성격이다.
}

#: ★★★ **그룹 — 이름만 만들고 낱낱은 엔티티로 안 만든다**
#  (2026-09-05 사용자 지시 「아내들/30인 용사 => **그룹이름만 만들고 엔티티는
#   만들지 마라**」).
#  ⚠ 이름만 있는 껍데기 30개는 목록을 덮고 검색을 흐린다. 낱낱의 이름은
#    **그룹 설명문 안에 글로** 담는다 — 읽을 수 있고 검색도 걸린다.
#  (코드, KO, EN, 설명문 KO, 설명문 EN, json)
GROUPS = (
    ('G_DAVID_WIVES', '다윗의 아내들', "David's Wives",
     '다윗에게는 여러 아내가 있었습니다. 헤브론에서 맞이한 아히노암·아비가일·'
     '마아가·학깃·아비달·에글라와, 사울의 딸 미갈, 그리고 예루살렘에서 맞이한 '
     '밧세바입니다(삼하 3:2~5, 5:13).\n'
     '성경은 이 사실을 자랑으로 적지 않습니다. 왕이 아내를 많이 두지 말라는 '
     '규례가 이미 있었고(신 17:17), 실제로 이 집안에서 암논과 다말의 일, '
     '압살롬의 반역이 자라났습니다. 다윗의 집은 그가 받은 언약만큼이나 그가 '
     '뿌린 것을 함께 거둔 자리입니다.',
     'David had several wives: Ahinoam, Abigail, Maacah, Haggith, Abital and '
     'Eglah in Hebron, Michal the daughter of Saul, and Bathsheba in Jerusalem '
     '(2 Sam 3:2-5; 5:13).\n'
     'Scripture does not present this as a boast. The law had already warned '
     'the king not to multiply wives (Deut 17:17), and it was in this household '
     'that the tragedy of Amnon and Tamar and the revolt of Absalom grew.',
     {'members': '미갈 · 아히노암 · 아비가일 · 마아가 · 학깃 · 아비달 · '
                 '에글라 · 밧세바',
      'refs': '삼하 3:2~5 · 5:13 · 신 17:17'}),
    ('G_DAVID_MIGHTY', '다윗의 용사들', "David's Mighty Men",
     '다윗에게는 세 용사와 삼십인 용사가 있었습니다(삼하 23장, 대상 11장). '
     '요세브바셋·엘르아살·삼마 셋이 으뜸이었고, 아비새와 브나야가 그 다음이며, '
     '아사헬·엘하난·헬레스·이라·아비에셀 같은 이름들이 명단에 이어집니다.\n'
     '명단 맨 끝에 「헷 사람 우리아」가 있습니다(삼하 23:39). 다윗의 가장 '
     '빛나는 목록이 그가 가장 어두운 일을 저지른 사람의 이름으로 끝나는 것은 '
     '성경이 왕을 미화하지 않는다는 표입니다.',
     'David had three mighty men and a company of thirty (2 Sam 23; 1 Chr 11). '
     'Josheb-basshebeth, Eleazar and Shammah were the first three; Abishai and '
     'Benaiah followed.\n'
     'The list ends with "Uriah the Hittite" (2 Sam 23:39). That the roll of '
     "David's finest closes with the name of the man he wronged is a sign that "
     'Scripture does not flatter its kings.',
     {'members': '요세브바셋 · 엘르아살 · 삼마 · 아비새 · 브나야 · 아사헬 · '
                 '엘하난 · 헬레스 · 이라 · 우리아 등',
      'refs': '삼하 23:8~39 · 대상 11:10~47'}),
)

#: ★★★ **인물 — 구절이 약해도 관계의 의미가 크면 등록한다**
#  (2026-09-05 사용자 지시 「후새처럼 구절이 약하더라도 **관계의 의미가 큰
#   경우**에는 엔티티 등록하고 구절/설명문을 관리하자」 ·
#   「작은 것이 결코 가벼운 것은 아니다」).
#  ⚠ 사용자가 예로 든 넷(후새·시므이·잇대·아비가일)이 **하나도 없었다**(실측).
#  (코드, KO, EN, 설명문 KO, 설명문 EN, 지파, 역할, 시대, 성별, 중요도)
PEOPLE = (
    ('P_HUSHAI', '후새', 'Hushai',
     '압살롬이 반역하여 예루살렘을 차지했을 때, 다윗은 맨발로 감람산을 '
     '올라가며 울었습니다. 그때 아렉 사람 후새가 겉옷을 찢고 흙을 머리에 '
     '뒤집어쓴 채 그를 맞으러 왔습니다(삼하 15:32).\n'
     '다윗은 그를 데려가지 않고 도리어 성으로 돌려보냅니다. 아히도벨의 '
     '모략을 무너뜨리라는 것이었습니다. 후새는 적진 한가운데로 걸어 들어가 '
     '압살롬 앞에 서서 「왕 만세」라 인사했고, 아히도벨의 빠른 추격 계책을 '
     '늦추는 말로 다윗이 요단을 건널 시간을 벌어 주었습니다(삼하 17:14).\n'
     '후새의 이름이 나오는 대목은 몇 장에 지나지 않습니다. 그러나 그 몇 장이 '
     '다윗의 목숨과 왕위를 지켰습니다. 충성은 늘 무대 위에서만 드러나지 '
     '않습니다.',
     'When Absalom seized Jerusalem, David went up the Mount of Olives '
     'weeping and barefoot. There Hushai the Archite met him with his coat '
     'torn and earth on his head (2 Sam 15:32).\n'
     'David sent him back into the city to defeat the counsel of Ahithophel. '
     'Hushai walked into the enemy camp, greeted Absalom, and by slowing the '
     'pursuit bought David the time he needed to cross the Jordan '
     '(2 Sam 17:14).\n'
     'Hushai appears in only a few chapters. Those few chapters saved a '
     "king's life.",
     None, 'FRIEND', 'KINGDOM', 'M', 6),
    ('P_ITTAI', '잇대', 'Ittai',
     '잇대는 가드 사람, 곧 이방인이었고 다윗에게 온 지 얼마 되지 않은 '
     '사람이었습니다. 다윗이 도망하던 날 그에게 말합니다. 「너는 어찌하여 '
     '우리와 함께 가느냐 돌아가서 왕과 함께 있으라 너는 타국인이요 또한 '
     '고향에서 쫓겨난 자로다」(삼하 15:19).\n'
     '잇대의 대답은 이러했습니다. 「여호와의 살아 계심과 내 주 왕의 살아 '
     '계심으로 맹세하옵나니 진실로 내 주 왕께서 어느 곳에 계시든지 사나 '
     '죽으나 종도 그곳에 있겠나이다」(삼하 15:21).\n'
     '왕이 가장 약해졌을 때, 가장 이유가 적은 사람이 가장 굳게 남았습니다. '
     '뒷날 잇대는 다윗의 군대 삼분의 일을 맡습니다(삼하 18:2).',
     'Ittai was a Gittite, a foreigner, and newly come to David. On the day of '
     'flight David said to him, "Why do you also go with us? Return... for you '
     'are a foreigner and an exile" (2 Sam 15:19).\n'
     'Ittai answered, "As the LORD lives, and as my lord the king lives, '
     'wherever my lord the king shall be, whether for death or for life, there '
     'also will your servant be" (2 Sam 15:21).\n'
     'When the king was weakest, the man with the least reason to stay stood '
     'firmest. Later Ittai commanded a third of David\'s army (2 Sam 18:2).',
     None, 'SOLDIER', 'KINGDOM', 'M', 6),
    ('P_ABIGAIL', '아비가일', 'Abigail',
     '나발은 어리석은 부자였고, 아비가일은 「총명하고 용모가 아름다운」 그의 '
     '아내였습니다(삼상 25:3). 나발이 다윗의 부하들을 모욕하자 다윗은 칼을 '
     '차고 사백 명을 이끌고 내려옵니다.\n'
     '아비가일은 남편에게 알리지 않고 급히 음식을 싣고 나아가 다윗의 발 앞에 '
     '엎드렸습니다. 그리고 말합니다. 「내 주께서 무죄한 피를 흘리셨다든지 '
     '친히 보복하셨다든지 함으로 말미암아 슬퍼하실 것도 없고 마음에 걸리는 '
     '것도 없으시리니」(삼상 25:31).\n'
     '다윗은 그 자리에서 멈추고 하나님을 찬송합니다. 「오늘 너를 보내어 나를 '
     '영접하게 하신 이스라엘의 하나님 여호와를 찬송할지로다」(삼상 25:32). '
     '한 사람의 지혜로운 말이 왕이 될 사람의 손에서 피를 씻어 냈습니다.',
     'Nabal was a foolish rich man; Abigail was his wife, "discerning and '
     'beautiful" (1 Sam 25:3). When Nabal insulted David\'s men, David '
     'strapped on his sword and came down with four hundred.\n'
     'Abigail hurried out with food and fell at his feet: "my lord shall have '
     'no cause of grief, or of trouble of heart, for having shed blood without '
     'cause" (1 Sam 25:31).\n'
     'David stopped and blessed God: "Blessed be the LORD, the God of Israel, '
     'who sent you this day to meet me" (1 Sam 25:32). One wise word washed '
     'blood from the hands of a king-to-be.',
     None, 'OTHER', 'KINGDOM', 'F', 6),
    ('P_SHIMEI', '시므이', 'Shimei',
     '다윗이 압살롬을 피해 바후림을 지날 때, 사울 집안 사람 시므이가 나와 '
     '돌을 던지며 저주했습니다. 「피를 흘린 자여 사악한 자여 가거라 '
     '가거라」(삼하 16:7).\n'
     '아비새가 「이 죽은 개가 어찌 내 주 왕을 저주하리이까 청하건대 내가 '
     '건너가서 그의 머리를 베게 하소서」 하자 다윗이 막습니다. 「여호와께서 '
     '그에게 다윗을 저주하라 하신 것이니 … 혹시 여호와께서 나의 원통함을 '
     '감찰하시리니」(삼하 16:10~12).\n'
     '가장 낮아진 자리에서 다윗은 저주를 하나님의 손에서 오는 것으로 받았습니다. '
     '시므이는 뒤에 돌아와 엎드려 용서를 빌었고 다윗은 살려 주었습니다'
     '(삼하 19:23).',
     'As David fled past Bahurim, Shimei of the house of Saul came out '
     'throwing stones and cursing: "Get out, get out, you man of blood, you '
     'worthless man!" (2 Sam 16:7).\n'
     'When Abishai offered to take off his head, David refused: "the LORD has '
     'said to him, Curse David... it may be that the LORD will look on the '
     'wrong done to me" (2 Sam 16:10-12).\n'
     'At his lowest, David received the curse as from the hand of God. Shimei '
     'later came back and begged forgiveness, and David spared him '
     '(2 Sam 19:23).',
     'BENJAMIN', 'OTHER', 'KINGDOM', 'M', 5),
    ('P_BARZILLAI', '바르실래', 'Barzillai',
     '바르실래는 길르앗 로글림 사람으로, 다윗이 마하나임에 이르렀을 때 '
     '침상과 그릇과 밀과 보리와 꿀과 버터와 양을 가져와 먹였습니다. '
     '「백성이 들에서 시장하고 곤하고 목마르겠다」는 이유였습니다'
     '(삼하 17:27~29).\n'
     '왕이 돌아갈 때 함께 예루살렘으로 가자고 청하자 그는 사양합니다. '
     '「내 나이가 이제 팔십 세라 어떻게 좋고 흉한 것을 분간할 수 '
     '있사오리이까」(삼하 19:35). 그러고는 자기 대신 김함을 보냅니다.\n'
     '보답을 바라지 않은 도움이 무엇인지 이 노인이 보여 줍니다. 다윗은 '
     '죽기 전 솔로몬에게 그의 아들들을 잊지 말라고 당부했습니다(왕상 2:7).',
     'Barzillai the Gileadite brought beds, bowls, wheat, barley, honey, curds '
     'and sheep to David at Mahanaim, saying the people were "hungry and weary '
     'and thirsty in the wilderness" (2 Sam 17:27-29).\n'
     'When the king invited him to Jerusalem he declined: "I am this day '
     'eighty years old. Can I discern between good and bad?" (2 Sam 19:35), '
     'and sent Chimham in his place.\n'
     'Here is help that asks nothing back. Before he died David charged '
     'Solomon to remember his sons (1 Kgs 2:7).',
     None, 'OTHER', 'KINGDOM', 'M', 5),
    ('P_ABNER', '아브넬', 'Abner',
     '아브넬은 넬의 아들이며 사울 군대의 사령관이었습니다. 사울이 죽은 뒤 '
     '그는 이스보셋을 왕으로 세워 다윗과 맞섰고, 기브온에서 아사헬을 '
     '죽였습니다(삼하 2:23).\n'
     '뒤에 이스보셋과 틀어지자 다윗에게 사람을 보내 온 이스라엘을 돌리겠다고 '
     '언약합니다. 그러나 헤브론 성문에서 요압이 아우의 피를 갚는다며 그를 '
     '찔러 죽였습니다(삼하 3:27).\n'
     '다윗은 그 상여를 따라가며 울고 「오늘 이스라엘의 지도자요 큰 인물이 '
     '죽었도다」 했습니다(삼하 3:38). 대적이었으나 왕은 그의 죽음을 애도했습니다.',
     'Abner son of Ner commanded Saul\'s army. After Saul died he set up '
     'Ish-bosheth against David and killed Asahel at Gibeon (2 Sam 2:23).\n'
     'Later, falling out with Ish-bosheth, he covenanted to bring all Israel '
     'to David — and Joab stabbed him in the gate of Hebron for his brother\'s '
     'blood (2 Sam 3:27).\n'
     'David walked behind the bier weeping: "a prince and a great man has '
     'fallen this day in Israel" (2 Sam 3:38).',
     'BENJAMIN', 'SOLDIER', 'KINGDOM', 'M', 6),
    ('P_NABAL', '나발', 'Nabal',
     '나발은 마온 사람으로 갈멜에 재산이 있었고 양이 삼천, 염소가 천 '
     '마리였습니다. 성경은 그를 「완고하고 행실이 악하며」라 적습니다'
     '(삼상 25:2~3).\n'
     '광야에서 그의 양 떼를 지켜 준 다윗의 부하들이 양털 깎는 날 음식을 '
     '청하자 그는 「다윗은 누구며 이새의 아들은 누구냐」며 모욕했습니다'
     '(삼상 25:10).\n'
     '아내 아비가일이 급히 나서서 다윗을 막았고, 열흘 뒤 여호와께서 나발을 '
     '치시매 그가 죽었습니다(삼상 25:38). 그의 이름 자체가 「어리석은 자」라는 '
     '뜻입니다.',
     'Nabal of Maon had great property in Carmel — three thousand sheep and a '
     'thousand goats. Scripture calls him "harsh and badly behaved" '
     '(1 Sam 25:2-3).\n'
     "When David's men, who had guarded his flocks, asked for food at "
     'shearing time, he sneered, "Who is David? Who is the son of Jesse?" '
     '(1 Sam 25:10).\n'
     'His wife Abigail went out and stopped David; ten days later the LORD '
     'struck Nabal and he died (1 Sam 25:38). His very name means "fool."',
     None, 'OTHER', 'KINGDOM', 'M', 4),
    ('P_ZADOK', '사독', 'Zadok',
     '사독은 아히둡의 아들로 다윗 시대의 제사장이었습니다. 압살롬의 반역 때 '
     '레위인들과 함께 언약궤를 메고 왕을 따라 나섰으나, 다윗은 궤를 성으로 '
     '돌려보냅니다. 「만일 내가 여호와 앞에서 은혜를 입으면 도로 나를 '
     '인도하사」(삼하 15:25).\n'
     '사독은 성에 남아 아히마아스를 통해 다윗에게 소식을 전하는 자리가 '
     '되었습니다. 뒷날 아도니야가 스스로 왕이 되려 할 때 그는 나단과 함께 '
     '솔로몬에게 기름을 붓습니다(왕상 1:39).\n'
     '한 자리에 끝까지 서 있던 사람의 이름이 성전 제사장 계보로 이어집니다'
     '(겔 44:15).',
     'Zadok son of Ahitub was priest in David\'s day. During Absalom\'s '
     'revolt he carried the ark out after the king, but David sent it back: '
     '"If I find favour in the eyes of the LORD, he will bring me back" '
     '(2 Sam 15:25).\n'
     'Zadok stayed in the city and became David\'s channel of news through '
     'Ahimaaz. Later, when Adonijah grasped at the throne, he anointed Solomon '
     'with Nathan (1 Kgs 1:39).\n'
     'The name of the man who stood his ground carries on into the priestly '
     'line of the temple (Ezek 44:15).',
     'LEVI', 'PRIEST', 'KINGDOM', 'M', 6),
    ('P_AHIMELECH', '아히멜렉', 'Ahimelech',
     '아히멜렉은 놉의 제사장이었습니다. 사울을 피해 홀로 도망하던 다윗이 '
     '찾아오자 그는 거룩한 떡, 곧 진설병을 내어 주고 골리앗의 칼까지 '
     '건네주었습니다(삼상 21:6~9).\n'
     '그 일을 에돔 사람 도엑이 사울에게 알렸고, 사울은 아히멜렉과 놉의 '
     '제사장 여든다섯 명을 죽였습니다(삼상 22:18). 다윗은 뒤에 그 아들 '
     '아비아달에게 말합니다. 「네 아비 집의 모든 사람 죽은 것이 나의 '
     '연고로다」(삼상 22:22).\n'
     '누군가를 도운 일이 그 사람을 죽게 만드는 자리가 있습니다. 다윗의 '
     '도피는 그 자신만의 고난이 아니었습니다.',
     'Ahimelech was priest at Nob. When David came alone, fleeing Saul, he '
     'gave him the holy bread and even the sword of Goliath (1 Sam 21:6-9).\n'
     'Doeg the Edomite reported it, and Saul killed Ahimelech with eighty-five '
     'priests of Nob (1 Sam 22:18). Later David told his son Abiathar, "I have '
     'occasioned the death of all the persons of your father\'s house" '
     '(1 Sam 22:22).\n'
     "David's flight was not his own suffering alone.",
     'LEVI', 'PRIEST', 'KINGDOM', 'M', 5),
    ('P_ABIATHAR', '아비아달', 'Abiathar',
     '아비아달은 놉의 학살에서 홀로 살아남아 다윗에게 도망해 온 제사장입니다. '
     '다윗은 그에게 「내게 있으라 두려워하지 말라」 했습니다(삼상 22:23).\n'
     '그 뒤 그는 도피 시절 내내 에봇을 들고 다윗 곁에 있었고, 압살롬의 '
     '반역 때에도 사독과 함께 성에 남아 소식을 전했습니다.\n'
     '그러나 다윗의 말년에 아도니야가 스스로 왕이 되려 할 때 그는 그 편에 '
     '섰고, 솔로몬은 그를 아나돗으로 물러가게 했습니다(왕상 2:26). 오래 '
     '함께한 사람도 마지막 한 걸음에서 갈릴 수 있습니다.',
     'Abiathar alone escaped the slaughter at Nob and fled to David, who said, '
     '"Stay with me; do not be afraid" (1 Sam 22:23).\n'
     'He carried the ephod beside David through the years of flight, and in '
     "Absalom's revolt stayed in the city with Zadok to send word.\n"
     'But in David\'s last days he sided with Adonijah, and Solomon sent him '
     'back to Anathoth (1 Kgs 2:26). A man may walk long with another and part '
     'at the final step.',
     'LEVI', 'PRIEST', 'KINGDOM', 'M', 5),
    ('P_ACHISH', '아기스', 'Achish',
     '아기스는 가드의 블레셋 왕입니다. 다윗이 처음 그에게 갔을 때는 두려워 '
     '미친 체하며 침을 수염에 흘렸고, 아기스는 그를 내쫓았습니다'
     '(삼상 21:13~15).\n'
     '뒤에 다시 갔을 때 아기스는 그를 받아들여 시글락 성읍을 내주었습니다'
     '(삼상 27:6). 다윗은 그 그늘에서 열여섯 달을 지냈습니다.\n'
     '블레셋 방백들이 그를 의심해 전장에서 돌려보낸 덕에 다윗은 자기 백성과 '
     '싸우는 자리를 면했습니다(삼상 29:9~11). 기름부음 받은 자가 이방 왕의 '
     '그늘에 머문 시절이 있었고, 하나님은 그 자리에서도 그를 지키셨습니다.',
     'Achish was the Philistine king of Gath. The first time David came he '
     'feigned madness in fear, letting spittle run down his beard, and Achish '
     'drove him out (1 Sam 21:13-15).\n'
     'When he came again Achish received him and gave him Ziklag '
     '(1 Sam 27:6), where he stayed sixteen months.\n'
     'The Philistine lords distrusted him and sent him back from the battle, '
     'sparing him from fighting his own people (1 Sam 29:9-11). The anointed '
     'one once sheltered under a pagan king, and God kept him even there.',
     None, 'KING', 'KINGDOM', 'M', 4),
    ('P_ZIBA', '시바', 'Ziba',
     '시바는 사울 집안의 종이었습니다. 다윗이 요나단을 생각하여 은혜를 베풀 '
     '사람을 찾을 때 그가 므비보셋을 알렸고, 다윗은 시바에게 그 땅을 갈아 '
     '주인의 아들을 섬기라 했습니다(삼하 9:9~10).\n'
     '그러나 압살롬의 반역 때 그는 홀로 음식을 가지고 나아와 므비보셋이 '
     '배신했다고 고했고, 다윗은 그 말만 듣고 므비보셋의 소유를 그에게 '
     '주었습니다(삼하 16:1~4).\n'
     '뒤에 므비보셋이 나와 사정을 말했을 때 다윗은 땅을 반씩 나누라 했습니다'
     '(삼하 19:29). 한쪽 말만 듣고 내린 결정은 나중에도 온전히 바로잡히지 '
     '않았습니다.',
     'Ziba was a servant of the house of Saul. When David sought someone to '
     'show kindness to for Jonathan\'s sake, Ziba named Mephibosheth, and '
     'David set him to farm the land for his master\'s son (2 Sam 9:9-10).\n'
     "During Absalom's revolt he came alone with provisions and accused "
     'Mephibosheth of treachery; on that word alone David gave him all that '
     'was his (2 Sam 16:1-4).\n'
     'When Mephibosheth later explained himself, David divided the land '
     'between them (2 Sam 19:29). A judgment made on one side of a story was '
     'never fully undone.',
     None, 'OTHER', 'KINGDOM', 'M', 4),
    ('P_MELCHIZEDEK', '멜기세덱', 'Melchizedek',
     '멜기세덱은 살렘 왕이며 지극히 높으신 하나님의 제사장이었습니다. '
     '아브람이 그돌라오멜을 치고 돌아올 때 그가 떡과 포도주를 가지고 나와 '
     '축복했고, 아브람은 얻은 것의 십분의 일을 그에게 주었습니다'
     '(창 14:18~20).\n'
     '성경은 그가 어디서 왔는지, 언제 죽었는지 말하지 않습니다. 그래서 '
     '히브리서는 그를 「아비도 없고 어미도 없고 족보도 없고 시작한 날도 '
     '없고 생명의 끝도 없어」라 적으며 하나님의 아들과 방불하다 합니다'
     '(히 7:3).\n'
     '왕이면서 제사장인 자리는 이스라엘에 없었습니다. 그 빈 자리가 오래 '
     '뒤에 채워집니다.',
     'Melchizedek was king of Salem and priest of God Most High. As Abram '
     'returned from defeating Chedorlaomer he brought out bread and wine and '
     'blessed him, and Abram gave him a tenth of everything (Gen 14:18-20).\n'
     'Scripture does not say where he came from or when he died. So Hebrews '
     'writes that he is "without father or mother or genealogy, having neither '
     'beginning of days nor end of life," resembling the Son of God '
     '(Heb 7:3).\n'
     'No one in Israel was both king and priest. That empty place is filled '
     'long afterward.',
     None, 'PRIEST', 'PATRIARCH', 'M', 6),
)

#: 새 관계 — (from 이름, to 이름, cat, type, 축, 설명문 KO, 설명문 EN, 구절)
#  ⚠ 구절은 `(책약자, 장, 절[, 끝장, 끝절])` 목록. **관계에 붙는다**(PREL_VERS).
NEW_RELATIONS = (
    ('다윗', '후새', 'SOCIAL', 'ALLY', 'COVENANT',
     '후새는 다윗이 가장 낮아진 날 그를 찾아온 사람입니다. 다윗은 그를 곁에 '
     '두지 않고 오히려 적진으로 돌려보냈고, 후새는 그 자리에서 아히도벨의 '
     '모략을 무너뜨렸습니다. 함께 도망하는 것보다 남아서 위험을 지는 것이 '
     '더 큰 충성이 되는 자리가 있습니다.',
     'Hushai came to David on the day he was lowest. David did not keep him '
     'close but sent him back into danger, and there he broke the counsel of '
     'Ahithophel. Sometimes staying behind in peril is the greater loyalty.',
     (('삼하', 15, 32, 15, 37), ('삼하', 16, 16), ('삼하', 17, 14))),
    ('다윗', '잇대', 'SOCIAL', 'ALLY', 'COVENANT',
     '다윗은 잇대에게 돌아가라고 두 번 권했습니다. 이방인이고 온 지 얼마 되지 '
     '않았으니 이 싸움에 매일 이유가 없다는 것이었습니다. 잇대는 사나 죽으나 '
     '왕이 있는 곳에 있겠다고 답했습니다. 언약은 혈통이 아니라 이런 대답에서 '
     '맺어집니다.',
     'Twice David urged Ittai to turn back — a foreigner newly come had no '
     'stake in this fight. Ittai answered that he would be where the king was, '
     'in death or in life. Covenant is made in answers like this, not in blood.',
     (('삼하', 15, 19, 15, 22), ('삼하', 18, 2))),
    ('아비가일', '다윗', 'SPIRITUAL', 'SPIRITUAL_CATALYST', 'RESTORATION',
     '아비가일은 다윗을 칭찬하러 온 것이 아니라 막으러 왔습니다. 그가 든 이유는 '
     '「뒷날 마음에 걸리는 것이 없게 하시라」는 것이었습니다. 다윗은 그 말에서 '
     '멈추었고, 자기를 멈춰 세운 하나님을 찬송했습니다. 책망이 아니라 앞을 '
     '내다보게 하는 말이 사람을 돌이킵니다.',
     'Abigail came not to flatter David but to stop him, and her reason was '
     'that he would have no grief of heart afterwards. David stopped, and '
     'blessed the God who had sent her. What turned him was not rebuke but a '
     'word that made him look ahead.',
     (('삼상', 25, 23, 25, 35),)),
    ('시므이', '다윗', 'SOCIAL', 'ENEMY', 'CONFLICT',
     '시므이는 다윗이 도망하는 날 돌을 던지며 저주했습니다. 다윗은 그를 치겠다는 '
     '아비새를 막고 그 저주까지 하나님의 손에서 오는 것으로 받았습니다. '
     '가장 억울한 자리에서 자기 손으로 갚지 않는 것이 이 관계가 보여 주는 '
     '것입니다.',
     'Shimei cursed David and threw stones on the day of his flight. David '
     'restrained Abishai and received even that curse as from the hand of God. '
     'What this relationship shows is a man who would not avenge himself when '
     'he had most cause.',
     (('삼하', 16, 5, 16, 13), ('삼하', 19, 18, 19, 23))),
    ('바르실래', '다윗', 'SOCIAL', 'ALLY', 'COVENANT',
     '바르실래는 왕이 광야에서 굶주릴 때 먹였고, 왕이 돌아갈 때는 함께 가자는 '
     '청을 사양했습니다. 여든 살이라 이제 좋고 흉한 것을 분간하지 못한다는 '
     '것이었습니다. 보답을 받을 자리에서 물러설 줄 아는 도움이 있습니다.',
     'Barzillai fed the king when he was hungry in the wilderness, and when '
     'invited to come to Jerusalem he declined — at eighty he could no longer '
     'tell good from bad. There is a kind of help that steps back when reward '
     'is offered.',
     (('삼하', 17, 27, 17, 29), ('삼하', 19, 31, 19, 39))),
    ('아브넬', '다윗', 'SOCIAL', 'ENEMY', 'CONFLICT',
     '아브넬은 사울의 사령관으로 다윗과 맞섰으나, 마지막에는 온 이스라엘을 '
     '그에게 돌리려 했습니다. 요압의 칼에 죽었을 때 다윗은 그 상여를 따라가며 '
     '울었습니다. 대적이었던 사람의 죽음 앞에서도 왕은 애도할 줄 알았습니다.',
     'Abner opposed David as Saul\'s commander, yet at the last he set out to '
     'bring all Israel over to him. When Joab killed him, David walked behind '
     'the bier and wept. The king could mourn even an enemy.',
     (('삼하', 3, 12, 3, 21), ('삼하', 3, 31, 3, 39))),
    ('나발', '다윗', 'SOCIAL', 'ENEMY', 'CONFLICT',
     '나발은 자기 양 떼를 지켜 준 사람들을 모르는 체하며 「다윗은 누구냐」고 '
     '했습니다. 다윗은 칼을 차고 내려왔고, 그 사이에 선 것이 아비가일이었습니다. '
     '어리석음이 어디까지 갈 수 있는지, 그리고 한 사람이 그것을 어떻게 막는지 '
     '함께 보이는 자리입니다.',
     'Nabal pretended not to know the men who had guarded his flocks: "Who is '
     'David?" David came down with his sword, and Abigail stood between them. '
     'Here we see how far folly can go, and how one person can stop it.',
     (('삼상', 25, 4, 25, 13), ('삼상', 25, 36, 25, 38))),
    ('다윗', '사독', 'SOCIAL', 'CO_WORKER', 'COVENANT',
     '사독은 언약궤를 메고 왕을 따라 나섰으나 다윗은 궤를 성으로 돌려보냈습니다. '
     '「은혜를 입으면 도로 나를 인도하시리라」는 것이었습니다. 사독은 성에 '
     '남아 소식을 전하는 자리가 되었고, 뒷날 솔로몬에게 기름을 부었습니다.',
     'Zadok carried the ark out after the king, but David sent it back, saying '
     'that if he found favour the LORD would bring him home. Zadok stayed in '
     'the city as a channel of news, and later anointed Solomon.',
     (('삼하', 15, 24, 15, 29), ('왕상', 1, 38, 1, 40))),
    ('아히멜렉', '다윗', 'SOCIAL', 'ALLY', 'COVENANT',
     '아히멜렉은 쫓기는 다윗에게 거룩한 떡과 골리앗의 칼을 내주었습니다. '
     '그 일로 그와 놉의 제사장 여든다섯 명이 죽었고, 다윗은 「나의 연고로다」 '
     '하고 스스로 그 피를 짊어졌습니다. 도움을 받은 자리가 곧 빚이 되는 '
     '관계입니다.',
     'Ahimelech gave the hunted David holy bread and the sword of Goliath. For '
     'that he and eighty-five priests of Nob were killed, and David said, "I '
     'have occasioned it." Here help received became a debt carried.',
     (('삼상', 21, 1, 21, 9), ('삼상', 22, 16, 22, 23))),
    ('다윗', '아비아달', 'SOCIAL', 'CO_WORKER', 'COVENANT',
     '아비아달은 놉의 학살에서 홀로 살아남아 다윗에게 왔고, 다윗은 「내게 '
     '있으라 두려워하지 말라」 했습니다. 그는 도피 시절 내내 에봇을 들고 '
     '곁에 있었으나 마지막에 아도니야 편에 서서 갈라섰습니다. 오래 함께한 '
     '것이 끝까지 함께함을 보장하지는 않습니다.',
     'Abiathar alone escaped Nob and came to David, who told him, "Stay with '
     'me; do not be afraid." He carried the ephod through the years of flight, '
     'yet at the last sided with Adonijah. Long companionship does not '
     'guarantee a faithful end.',
     (('삼상', 22, 20, 22, 23), ('왕상', 2, 26, 2, 27))),
    ('아기스', '다윗', 'SOCIAL', 'AUTHORITY', None,
     '아기스는 다윗을 받아 시글락을 내준 이방 왕입니다. 다윗은 그 그늘에서 '
     '열여섯 달을 지냈고, 블레셋 방백들의 의심 덕에 자기 백성과 싸우는 자리를 '
     '면했습니다. 기름부음 받은 자가 이방 왕 아래 머문 시절이 있었습니다.',
     'Achish received David and gave him Ziklag, where he stayed sixteen '
     'months. The distrust of the Philistine lords spared him from fighting '
     'his own people. The anointed one once lived under a pagan king.',
     (('삼상', 27, 1, 27, 7), ('삼상', 29, 6, 29, 11))),
    ('다윗', '시바', 'SOCIAL', 'STEWARDSHIP', None,
     '시바는 므비보셋을 알려 다윗의 언약이 지켜지게 한 사람이면서, 반역의 '
     '날에는 한쪽 말로 그 주인의 소유를 가져간 사람이기도 합니다. 다윗은 '
     '뒤에 땅을 반씩 나누라 했으나 그 판단은 온전히 바로잡히지 않았습니다.',
     'Ziba both made possible the keeping of David\'s covenant, by naming '
     'Mephibosheth, and took his master\'s property on one side of a story. '
     'David later divided the land, but the judgment was never fully undone.',
     (('삼하', 9, 1, 9, 13), ('삼하', 16, 1, 16, 4), ('삼하', 19, 24, 19, 30))),
    ('멜기세덱', '아브라함', 'SPIRITUAL', 'SACRED_ENCOUNTER', 'COVENANT',
     '아브람이 전쟁에서 돌아오던 길에 살렘 왕이자 제사장인 멜기세덱이 떡과 '
     '포도주를 들고 나와 그를 축복했습니다. 아브람은 얻은 것의 십분의 일을 '
     '주었습니다. 믿음의 조상이 도리어 축복을 받고 십일조를 드린 자리입니다.\n'
     '히브리서는 이 짧은 만남을 붙들고 「레위도 아브라함으로 말미암아 '
     '십일조를 바쳤느니라」 합니다(히 7:9). 한 번의 만남이 뒷날의 신학이 '
     '되었습니다.',
     'As Abram returned from battle, Melchizedek, king of Salem and priest, '
     'brought out bread and wine and blessed him; Abram gave him a tenth. The '
     'father of faith was the one blessed, and the one who paid the tithe.\n'
     'Hebrews takes this brief meeting and says that "Levi himself paid tithes '
     'through Abraham" (Heb 7:9). One encounter became a theology.',
     (('창', 14, 18, 14, 20), ('히', 7, 1, 7, 10))),
    ('가인', '아벨', 'FAMILY', 'SIBLING', 'CONFLICT',
     '가인과 아벨은 처음 태어난 형제였고, 처음 일어난 살인의 두 사람이기도 '
     '합니다. 하나님이 아벨의 제물은 받으시고 가인의 것은 받지 않으시자 '
     '가인은 몹시 분하여 안색이 변했습니다(창 4:5).\n'
     '하나님은 그때 그를 찾아와 말씀하십니다. 「죄가 문에 엎드리느니라 '
     '죄의 소원은 네게 있으나 너는 죄를 다스릴지니라」(창 4:7). 경고는 '
     '분명히 주어졌습니다.\n'
     '그러나 가인은 들에서 동생을 쳐 죽였습니다. 시기가 어디까지 갈 수 '
     '있는지, 그리고 그 앞에 늘 돌이킬 자리가 있었다는 것을 함께 보입니다.',
     'Cain and Abel were the first brothers born, and also the two of the '
     'first murder. When God accepted Abel\'s offering and not his, Cain was '
     'very angry and his face fell (Gen 4:5).\n'
     'God came to him then: "sin is crouching at the door. Its desire is for '
     'you, but you must rule over it" (Gen 4:7). The warning was plainly '
     'given.\n'
     'Yet Cain rose up against his brother in the field. Here we see how far '
     'envy can go — and that there was always a place to turn.',
     (('창', 4, 3, 4, 12),)),
)

#: ★★★ **이미 있는 관계에 글과 구절만 채운다** (2026-09-05).
#  사용자가 0.person.txt §6 에서 4차원별로 든 대표 짝들이다. 관계는 이미
#  있었으나 **설명문 5 · 구절 0** 이었다 — 그릇만 있고 내용이 없었다.
#  ⚠ `NEW_RELATIONS` 와 달리 **관계를 만들지 않는다**(있는 것에 얹는다).
#  (from 이름, to 이름, 유형|None, 설명문 KO, 설명문 EN, 구절)
FILL = (
    ('보아스', '룻', None,
     '룻은 이방 모압 여인이었고 보아스는 기업을 무를 자, 곧 고엘이었습니다. '
     '그가 성문에서 「내가 무르리라」 한 말 한마디로 한 집안이 이어졌고, '
     '그 집안에서 다윗이 나고 그리스도가 나셨습니다.\n'
     '보아스는 마땅히 할 일을 했을 뿐이라 여겼겠지만, 성경은 그 자리를 '
     '구속사의 마디로 적습니다. 무를 자가 되어 준다는 것이 무엇인지 이 '
     '관계가 먼저 보여 줍니다.',
     'Ruth was a Moabite; Boaz was the kinsman-redeemer. His word at the gate '
     '— "I will redeem it" — carried a household forward, and out of that '
     'household came David, and Christ.\n'
     'Boaz likely thought he was only doing his duty. Scripture records it as '
     'a hinge of redemptive history. Here we first see what it means to be a '
     'redeemer.',
     (('룻', 3, 10, 3, 13), ('룻', 4, 9, 4, 17))),
    ('모세', '여호수아', None,
     '여호수아는 모세의 수종자로 회막을 떠나지 않았습니다(출 33:11). 사십 년 '
     '동안 그는 지도자가 아니라 곁에 선 사람이었습니다.\n'
     '모세가 죽기 전 그에게 안수하자 여호수아는 지혜의 영이 충만해졌고'
     '(신 34:9), 하나님은 그에게 「내가 모세와 함께 있던 것 같이 너와 함께 '
     '있을 것이라」 하셨습니다(수 1:5).\n'
     '전수는 하루에 일어나지 않습니다. 곁에 서 있던 사십 년이 그 하루를 '
     '떠받칩니다.',
     'Joshua was Moses\' assistant and did not depart from the tent '
     '(Ex 33:11). For forty years he was not the leader but the man who stood '
     'beside.\n'
     'When Moses laid hands on him, Joshua was filled with the spirit of '
     'wisdom (Deut 34:9), and God said, "As I was with Moses, so I will be '
     'with you" (Josh 1:5).\n'
     'Succession does not happen in a day. Forty years of standing near hold '
     'that day up.',
     (('출', 33, 11), ('신', 34, 9), ('수', 1, 1, 1, 9))),
    ('이드로', '모세', None,
     '이드로는 모세의 장인이며 미디안 제사장이었습니다. 사위가 아침부터 '
     '저녁까지 홀로 백성을 재판하는 것을 보고 그는 말합니다. 「그대의 하는 '
     '것이 선하지 못하도다 그대와 그대와 함께한 이 백성이 필연 기력이 '
     '쇠하리니」(출 18:17~18).\n'
     '그리고 천부장·백부장·오십부장·십부장을 세우라고 일러 줍니다. 모세는 '
     '그 말을 듣고 그대로 했습니다(출 18:24).\n'
     '멘토링이 늘 영적인 말로만 오지는 않습니다. 일을 나누라는 실무적인 '
     '조언 하나가 한 사람을 지켰습니다.',
     'Jethro, Moses\' father-in-law and priest of Midian, watched him judge '
     'the people alone from morning to evening and said, "What you are doing '
     'is not good. You and the people with you will certainly wear yourselves '
     'out" (Ex 18:17-18).\n'
     'He told him to appoint rulers of thousands, hundreds, fifties and tens; '
     'and Moses listened and did so (Ex 18:24).\n'
     'Mentoring does not always come in spiritual words. One practical '
     'counsel to share the load preserved a man.',
     (('출', 18, 13, 18, 24),)),
    ('바나바', '바울', None,
     '사울이 회심한 뒤 예루살렘의 제자들은 그를 두려워하여 믿지 않았습니다. '
     '그때 바나바가 그를 데리고 사도들에게 가서 어떻게 주를 보았는지 '
     '말해 주었습니다(행 9:26~27).\n'
     '그 뒤에도 바나바는 다소까지 가서 사울을 찾아 안디옥으로 데려왔습니다'
     '(행 11:25~26). 「권위자」라는 뜻의 이름 그대로입니다.\n'
     '아무도 믿어 주지 않을 때 한 사람이 곁에 서 주면 그 사람의 자리가 '
     '생깁니다. 교회는 그 자리에서 바울을 얻었습니다.',
     'After his conversion the disciples in Jerusalem were afraid of Saul and '
     'would not believe him. Barnabas took him to the apostles and told them '
     'how he had seen the Lord (Acts 9:26-27).\n'
     'Later he went to Tarsus to look for Saul and brought him to Antioch '
     '(Acts 11:25-26) — living up to his name, Son of Encouragement.\n'
     'When no one will believe a man, one person standing beside him makes a '
     'place for him. There the church gained Paul.',
     (('행', 9, 26, 9, 28), ('행', 11, 22, 11, 26))),
    ('아합', '엘리야', None,
     '아합이 엘리야를 보고 한 첫 말은 「이스라엘을 괴롭게 하는 자여 '
     '너냐」였습니다(왕상 18:17). 엘리야의 대답은 「내가 이스라엘을 괴롭게 한 '
     '것이 아니라 당신과 당신의 아비의 집이 괴롭게 하였으니」였습니다.\n'
     '갈멜산에서 하늘의 불이 내린 뒤에도 아합은 돌이키지 않았고, 나봇의 '
     '포도원을 빼앗은 뒤 엘리야가 다시 그를 찾아옵니다. 「네가 나를 '
     '찾았느냐 내 대적자여」(왕상 21:20).\n'
     '진실을 말하는 사람은 대개 문제를 일으키는 사람으로 불립니다.',
     'Ahab\'s first words to Elijah were, "Is it you, you troubler of '
     'Israel?" (1 Kgs 18:17). Elijah answered, "I have not troubled Israel, '
     'but you and your father\'s house have."\n'
     'Even after fire fell on Carmel, Ahab did not turn; and after he seized '
     "Naboth's vineyard Elijah came again: \"Have you found me, O my "
     'enemy?" (1 Kgs 21:20).\n'
     'The one who tells the truth is usually called the troublemaker.',
     (('왕상', 18, 17, 18, 19), ('왕상', 21, 17, 21, 24))),
    # ⚠ 이 짝은 관계가 **둘**이다(CO_WORKER · CONFLICT_TEMP) — 축도
    #   갈린다(언약 · 대적). **둘 다 사실이므로 각각 글을 준다** —
    #   화면에서 두 묶음에 나란히 서서 그 관계의 두 얼굴이 보인다.
    ('바울', '베드로', 'CO_WORKER',
     '갈라디아서는 야고보와 게바와 요한이 바울과 바나바에게 「친교의 '
     '악수」를 했다고 적습니다. 그들은 할례자에게로, 바울은 이방인에게로 '
     '가기로 한 것입니다(갈 2:9).\n'
     '베드로는 뒷날 바울의 편지를 두고 「우리가 사랑하는 형제 바울」의 '
     '글이며 「알기 어려운 것이 더러 있으나」 성경이라 했습니다'
     '(벧후 3:15~16).\n'
     '같은 복음을 다른 자리에서 전하는 것이 갈라섬은 아닙니다.',
     'Galatians records that James, Cephas and John gave Paul and '
     'Barnabas the right hand of fellowship — they to the circumcised, '
     'Paul to the Gentiles (Gal 2:9).\n'
     'Peter later spoke of "our beloved brother Paul," whose letters '
     'contain "some things hard to understand," yet are Scripture '
     '(2 Pet 3:15-16).\n'
     'To carry the same gospel to different places is not division.',
     (('갈', 2, 7, 2, 10), ('벧후', 3, 15, 3, 16))),
    ('바울', '베드로', 'CONFLICT_TEMP',
     '게바가 안디옥에 이르렀을 때 바울은 그를 면책했습니다. 야고보에게서 온 '
     '사람들이 오기 전에는 이방인과 함께 먹다가, 그들이 오자 물러가 '
     '떠났기 때문입니다(갈 2:11~13).\n'
     '바울은 「모든 자 앞에서」 말했습니다. 그러나 그것은 사람을 무너뜨리는 '
     '자리가 아니라 복음의 진리를 지키는 자리였고, 뒷날 베드로는 바울의 '
     '편지를 「우리가 사랑하는 형제 바울」의 글이라 부릅니다(벧후 3:15).\n'
     '바르게 부딪히고도 형제로 남을 수 있습니다.',
     'When Cephas came to Antioch, Paul opposed him to his face: before men '
     'came from James he ate with the Gentiles, but when they came he drew '
     'back (Gal 2:11-13).\n'
     'Paul spoke "before them all" — not to break a man but to guard the truth '
     'of the gospel. Later Peter called him "our beloved brother Paul" '
     '(2 Pet 3:15).\n'
     'Men may clash rightly and still remain brothers.',
     (('갈', 2, 11, 2, 14), ('벧후', 3, 15, 3, 16))),
    ('나단', '다윗', None,
     '나단은 비유로 시작했습니다. 부자가 가난한 자의 암양 새끼를 빼앗은 '
     '이야기였습니다. 다윗이 크게 노하여 「그 사람은 마땅히 죽을 자라」 하자 '
     '나단이 말합니다. 「당신이 그 사람이라」(삼하 12:7).\n'
     '왕 앞에서 그 한마디를 하는 데는 목숨이 걸립니다. 다윗은 「내가 '
     '여호와께 죄를 범하였노라」 했고, 그 자리에서 시편 51편이 나왔습니다.\n'
     '책망은 정죄가 아닙니다. 나단은 다윗을 무너뜨리려 한 것이 아니라 '
     '돌이키게 하려 했고, 실제로 그렇게 됐습니다.',
     'Nathan began with a parable — a rich man who took the poor man\'s ewe '
     'lamb. When David burned with anger and said, "The man who has done this '
     'deserves to die," Nathan said, "You are the man" (2 Sam 12:7).\n'
     'To say that before a king costs a life. David answered, "I have sinned '
     'against the LORD," and out of that hour came Psalm 51.\n'
     'Rebuke is not condemnation. Nathan sought not to break David but to turn '
     'him, and he did.',
     (('삼하', 12, 1, 12, 13),)),
    ('아브라함', '롯', None,
     '소돔의 심판을 앞두고 아브라함은 하나님 앞에 섰습니다. 「의인 오십 명이 '
     '있을지라도 주께서 그 곳을 멸하시고 용서하지 아니하시리이까」'
     '(창 18:24). 그는 오십에서 시작해 사십오, 사십, 삼십, 이십, 열까지 '
     '내려갑니다.\n'
     '조카 롯이 그 성에 있었습니다. 그러나 아브라함이 구한 것은 「롯을 '
     '건지소서」가 아니라 「그 성을 용서하소서」였습니다.\n'
     '중보는 내 사람을 빼내 달라는 기도가 아니라 그 자리 전체를 위해 서는 '
     '것입니다.',
     'Before the judgment of Sodom, Abraham stood before the LORD: "Will you '
     'indeed sweep away and not spare the place for the fifty righteous who '
     'are in it?" (Gen 18:24). He went down from fifty to forty-five, forty, '
     'thirty, twenty, ten.\n'
     'His nephew Lot was in that city. Yet Abraham did not pray "deliver Lot" '
     'but "spare the place."\n'
     'Intercession is not asking that my own be pulled out, but standing for '
     'the whole place.',
     (('창', 18, 22, 18, 33),)),
    ('예수', '베드로', None,
     '베드로는 세 번 부인했습니다. 부활하신 뒤 예수께서 그에게 세 번 '
     '물으십니다. 「요한의 아들 시몬아 네가 이 사람들보다 나를 더 '
     '사랑하느냐」(요 21:15).\n'
     '세 번째 물으실 때 베드로는 근심했습니다. 부인한 횟수만큼 물으신 '
     '것입니다. 그러나 물음마다 뒤따른 말은 책망이 아니라 사명이었습니다. '
     '「내 양을 먹이라.」\n'
     '회복은 잘못을 없던 일로 하는 것이 아니라, 그 자리에서 다시 일을 '
     '맡기는 것입니다.',
     'Peter denied him three times. After the resurrection Jesus asked him '
     'three times, "Simon, son of John, do you love me more than these?" '
     '(John 21:15).\n'
     'At the third asking Peter was grieved — once for each denial. Yet what '
     'followed each question was not rebuke but commission: "Feed my sheep."\n'
     'Restoration does not pretend the failure never happened; it hands the '
     'work back at that very place.',
     (('요', 21, 15, 21, 19),)),
    ('다윗', '요나단', None, None, None,
     (('삼상', 18, 1, 18, 4), ('삼상', 20, 12, 20, 17),
      ('삼하', 1, 25, 1, 27))),
    ('엘리야', '엘리사', None, None, None,
     (('왕상', 19, 19, 19, 21), ('왕하', 2, 9, 2, 14))),
    ('바울', '디모데', None, None, None,
     (('행', 16, 1, 16, 3), ('딤후', 1, 3, 1, 6), ('딤후', 4, 9, 4, 13))),
    ('사울', '다윗', 'RIVAL', None, None,
     (('삼상', 18, 6, 18, 12), ('삼상', 24, 8, 24, 20))),
    ('모세', '아론', 'SIBLING', None, None,
     (('출', 4, 14, 4, 16), ('출', 17, 8, 17, 13))),
)

#: ★★ **2차** — 의미가 큰 관계 24건 (2026-09-05).
#  ⚠ `FILL` 과 같은 문법이지만 **묶음을 갈라 둔다** — 한 덩이가 커지면
#    어디까지 손봤는지 알 수 없다. 다음 차수는 `FILL3` 로 잇는다.
FILL2 = (
    # ── 예수 계열 ────────────────────────────────────────────────
    ('세례 요한', '예수', None,
     '요한은 자기에게 오는 예수를 보고 「보라 세상 죄를 지고 가는 하나님의 '
     '어린 양이로다」 했습니다(요 1:29). 세례를 베풀어 달라는 청에는 '
     '「내가 당신에게서 세례를 받아야 할 터인데」 하며 말렸습니다'
     '(마 3:14).\n'
     '제자들이 「그에게로 가더이다」 하고 알렸을 때 요한의 대답은 이러했습니다. '
     '「그는 흥하여야 하겠고 나는 쇠하여야 하리라」(요 3:30).\n'
     '길을 예비하는 자리는 물러설 줄 아는 자리이기도 합니다.',
     'John saw Jesus coming and said, "Behold, the Lamb of God, who takes away '
     'the sin of the world!" (John 1:29). Asked to baptize him he objected, '
     '"I need to be baptized by you" (Matt 3:14).\n'
     'When his disciples reported that people were going to Jesus, John '
     'answered, "He must increase, but I must decrease" (John 3:30).\n'
     'To prepare the way is also to know how to step back.',
     (('요', 1, 29, 1, 34), ('마', 3, 13, 3, 17), ('요', 3, 27, 3, 30))),
    ('유다 이스카리옷', '예수', None,
     '유다는 열둘 가운데 하나였고 돈궤를 맡은 사람이었습니다. 은 삼십에 '
     '예수를 넘기기로 하고, 마지막에는 입맞춤을 신호로 삼았습니다.\n'
     '예수께서 그때 하신 말은 「친구여 네가 무엇을 하려고 왔는지 행하라」'
     '였습니다(마 26:50). 마지막 순간까지 그를 「친구」라 부르셨습니다.\n'
     '가장 가까운 자리에 있던 사람이 가장 깊이 배반할 수 있습니다. 그리고 '
     '배반당한 이는 그 순간에도 이름을 부르셨습니다.',
     'Judas was one of the Twelve and kept the money box. He agreed to hand '
     'Jesus over for thirty pieces of silver, and made a kiss the sign.\n'
     'Jesus said to him, "Friend, do what you came to do" (Matt 26:50). To '
     'the last he called him friend.\n'
     'The one nearest may betray most deeply — and the betrayed one still '
     'spoke his name.',
     (('마', 26, 14, 26, 16), ('마', 26, 47, 26, 50))),
    ('예수', '막달라 마리아', None,
     '막달라 마리아는 일곱 귀신이 나간 여자였고, 십자가 곁에 서 있었고, '
     '무덤까지 따라간 사람입니다.\n'
     '부활하신 아침 그가 무덤 밖에서 울 때 예수께서 「마리아야」 하고 '
     '부르셨습니다. 그 한마디에 그가 돌이켜 「랍오니」 했습니다'
     '(요 20:16).\n'
     '부활의 첫 증인이 이 여자였습니다. 성경은 그 소식을 가장 낮은 자리에 '
     '있던 사람의 입에 먼저 두었습니다.',
     'Mary Magdalene was the woman out of whom seven demons had gone. She '
     'stood by the cross and followed to the tomb.\n'
     'On the resurrection morning, as she wept outside, Jesus said, "Mary." '
     'At that one word she turned and said, "Rabboni" (John 20:16).\n'
     'She was the first witness of the resurrection. Scripture put that news '
     'first in the mouth of one who had been lowest.',
     (('요', 20, 11, 20, 18), ('눅', 8, 1, 8, 3))),
    ('예수', '니고데모', None,
     '니고데모는 바리새인이요 유대인의 관원이었고 밤에 찾아왔습니다. '
     '예수의 첫 말은 「사람이 거듭나지 아니하면 하나님 나라를 볼 수 '
     '없느니라」였습니다(요 3:3).\n'
     '그는 그 자리에서 알아듣지 못했습니다. 그러나 뒤에 공회에서 홀로 '
     '「우리 율법은 사람의 말을 듣기 전에 판단하느냐」 하고(요 7:51), '
     '마지막에는 몰약과 침향을 가지고 장사 지내러 왔습니다(요 19:39).\n'
     '한 번의 만남이 천천히 자랐습니다. 밤에 온 사람이 낮에 서게 됐습니다.',
     'Nicodemus was a Pharisee and a ruler of the Jews, and he came by night. '
     'Jesus\' first word was, "Unless one is born again he cannot see the '
     'kingdom of God" (John 3:3).\n'
     'He did not understand then. Yet later he alone asked in the council, '
     '"Does our law judge a man before it hears him?" (John 7:51), and at the '
     'end he brought myrrh and aloes for the burial (John 19:39).\n'
     'One meeting grew slowly. The man who came at night came to stand in day.',
     (('요', 3, 1, 3, 10), ('요', 7, 50, 7, 52), ('요', 19, 38, 19, 42))),
    ('예수', '나사로', None,
     '예수께서 나사로가 죽었다는 소식을 듣고도 이틀을 더 머무셨습니다. '
     '무덤에 이르렀을 때 마리아가 우는 것을 보시고 「심령에 비통히 여기시고 '
     '민망히 여기사」 눈물을 흘리셨습니다(요 11:35).\n'
     '곧 살리실 것을 아시면서도 우셨습니다. 그리고 큰 소리로 「나사로야 '
     '나오라」 부르셨습니다.\n'
     '고칠 수 있는 이가 먼저 함께 울었습니다. 그것이 이 관계가 남긴 그림입니다.',
     'Jesus stayed two days longer after hearing Lazarus was ill. At the tomb, '
     'seeing Mary weeping, he was deeply moved and wept (John 11:35).\n'
     'He wept knowing he would raise him. Then he cried with a loud voice, '
     '"Lazarus, come out."\n'
     'The one who could heal first wept with them. That is the picture this '
     'friendship leaves.',
     (('요', 11, 1, 11, 6), ('요', 11, 32, 11, 44))),
    ('예수', '도마', None,
     '도마는 다른 제자들의 말을 믿지 않았습니다. 「내가 그의 손의 못 자국을 '
     '보며 내 손가락을 그 못 자국에 넣으며 … 믿지 아니하겠노라」'
     '(요 20:25).\n'
     '여드레 뒤 예수께서 오셔서 그에게 손을 내미셨습니다. 「네 손가락을 '
     '이리 내밀어 내 손을 보고 … 믿음 없는 자가 되지 말고 믿는 자가 되라.」\n'
     '의심하는 사람을 꾸짖어 쫓아내지 않으시고 그 의심이 요구한 그대로 '
     '보여 주셨습니다. 도마의 대답은 「나의 주시며 나의 하나님이시니이다」였습니다.',
     'Thomas would not believe the others: "Unless I see in his hands the mark '
     'of the nails... I will never believe" (John 20:25).\n'
     'Eight days later Jesus came and held out his hands: "Put your finger '
     'here... Do not disbelieve, but believe."\n'
     'He did not drive the doubter away but gave him exactly what his doubt '
     'had asked. Thomas answered, "My Lord and my God!"',
     (('요', 20, 24, 20, 29),)),
    ('요한', '예수', None,
     '요한은 자기를 이름으로 부르지 않고 「예수께서 사랑하시는 그 제자」라 '
     '적습니다. 최후의 만찬에서 예수의 품에 의지하여 누웠고(요 13:23), '
     '십자가 아래에까지 남았습니다.\n'
     '거기서 예수께서 어머니를 가리켜 「보라 네 어머니라」 하시매 그때부터 '
     '그 제자가 자기 집에 모셨습니다(요 19:27).\n'
     '가장 마지막까지 남은 사람에게 가장 마지막 부탁이 주어졌습니다.',
     'John never names himself, writing instead "the disciple whom Jesus '
     'loved." He reclined at table close to Jesus (John 13:23) and stayed to '
     'the foot of the cross.\n'
     'There Jesus said of his mother, "Behold, your mother!" and from that '
     'hour the disciple took her into his home (John 19:27).\n'
     'To the one who stayed longest was given the last request.',
     (('요', 13, 21, 13, 26), ('요', 19, 25, 19, 27))),
    ('마르다', '예수', None,
     '마르다는 준비하는 일이 많아 마음이 분주했고, 마리아가 발치에 앉아 '
     '말씀만 듣는 것을 보고 「나를 도와주라 하소서」 했습니다.\n'
     '예수의 대답은 책망이면서 초대였습니다. 「마르다야 마르다야 네가 많은 '
     '일로 염려하고 근심하나 몇 가지만 하든지 혹 한 가지만이라도 '
     '족하니라」(눅 10:41~42).\n'
     '뒤에 나사로가 죽었을 때 「나는 부활이요 생명이니」를 들은 것도 '
     '마르다입니다(요 11:25). 분주하던 사람이 가장 큰 고백을 했습니다.',
     'Martha was distracted with much serving and said, "Tell her then to help '
     'me."\n'
     'Jesus\' answer was both rebuke and invitation: "Martha, Martha, you are '
     'anxious and troubled about many things, but one thing is necessary" '
     '(Luke 10:41-42).\n'
     'Later it was Martha who heard, "I am the resurrection and the life" '
     '(John 11:25). The busy one made the greatest confession.',
     (('눅', 10, 38, 10, 42), ('요', 11, 20, 11, 27))),
    # ── 다윗 계열 ────────────────────────────────────────────────
    ('이새', '다윗', None,
     '사무엘이 기름 부을 자를 찾아왔을 때 이새는 아들 일곱을 차례로 '
     '지나가게 했으나 다윗은 부르지도 않았습니다. 「아직 막내가 남았는데 '
     '그가 양을 지키나이다」(삼상 16:11).\n'
     '그때 여호와께서 하신 말씀이 이러합니다. 「사람은 외모를 보거니와 '
     '나 여호와는 중심을 보느니라」(삼상 16:7).\n'
     '자기 집에서조차 세어지지 않던 아들이 왕으로 세워졌습니다.',
     'When Samuel came to anoint, Jesse passed seven sons before him and did '
     'not even call David: "There remains yet the youngest, but he is keeping '
     'the sheep" (1 Sam 16:11).\n'
     'Then the LORD said, "Man looks on the outward appearance, but the LORD '
     'looks on the heart" (1 Sam 16:7).\n'
     'The son not counted in his own house was made king.',
     (('삼상', 16, 1, 16, 13),)),
    ('다윗', '솔로몬', None,
     '다윗은 성전을 짓고자 했으나 하나님은 「너는 피를 많이 흘렸은즉」 하시고 '
     '그 일을 아들에게 맡기셨습니다(대상 22:8).\n'
     '다윗은 재료를 준비하고 설계를 넘겨주며 당부합니다. 「내 아들 솔로몬아 '
     '너는 네 아비의 하나님을 알고 온전한 마음과 기쁜 뜻으로 섬길지어다」'
     '(대상 28:9).\n'
     '내가 못 이룰 일을 아들에게 넘기면서도 원망 없이 준비해 두는 자리가 '
     '있습니다.',
     'David wished to build the temple, but God said, "You have shed much '
     'blood," and gave the work to his son (1 Chr 22:8).\n'
     'David prepared the materials and handed over the plans: "Know the God of '
     'your father and serve him with a whole heart and a willing mind" '
     '(1 Chr 28:9).\n'
     'There is a place where a man prepares without resentment for what he '
     'himself will not finish.',
     (('대상', 22, 6, 22, 13), ('대상', 28, 9, 28, 10))),
    ('다윗', '밧세바', None,
     '이 관계는 죄로 시작했습니다. 왕이 왕궁 지붕에서 보고, 사람을 보내 '
     '데려오고, 그 남편을 최전선에서 죽게 했습니다(삼하 11장).\n'
     '나단의 책망 뒤 첫 아이는 죽었습니다. 그러나 성경은 거기서 끝내지 '
     '않습니다. 「다윗이 그의 아내 밧세바를 위로하고 … 아들을 낳으매 그의 '
     '이름을 솔로몬이라 하니라 여호와께서 그를 사랑하시어」(삼하 12:24).\n'
     '마태복음 족보는 그를 「우리야의 아내에게서」라 적습니다(마 1:6). '
     '성경은 이 일을 덮지 않으면서도 그 혈통을 통해 그리스도께로 갑니다.',
     'This began in sin — the king saw from the roof, sent and took her, and '
     'had her husband killed at the front (2 Sam 11).\n'
     'After Nathan\'s rebuke the first child died. Yet Scripture does not end '
     'there: "David comforted his wife Bathsheba... and she bore a son, and he '
     'called his name Solomon. And the LORD loved him" (2 Sam 12:24).\n'
     "Matthew's genealogy records him as born \"by the wife of Uriah\" "
     '(Matt 1:6). Scripture neither hides this nor stops the line to Christ.',
     (('삼하', 11, 2, 11, 5), ('삼하', 12, 24, 12, 25))),
    ('다윗', '므비보셋', None,
     '다윗이 물었습니다. 「사울의 집에 아직도 남은 사람이 있느냐 내가 '
     '요나단으로 말미암아 그 사람에게 은총을 베풀리라」(삼하 9:1).\n'
     '므비보셋은 두 발을 다 저는 사람이었고, 옛 왕가의 후손이라 위험한 '
     '존재이기도 했습니다. 그런데 다윗은 그를 왕의 상에서 늘 먹게 했습니다.\n'
     '요나단은 이미 죽었습니다. 죽은 친구와의 언약을 산 사람이 지킨 자리이고, '
     '그 언약이 한 사람의 삶을 통째로 바꾸었습니다.',
     'David asked, "Is there still anyone left of the house of Saul, that I '
     'may show him kindness for Jonathan\'s sake?" (2 Sam 9:1).\n'
     'Mephibosheth was lame in both feet and, as heir of the old house, a '
     'danger. Yet David had him eat at the king\'s table always.\n'
     'Jonathan was already dead. A living man kept covenant with a dead '
     'friend, and that covenant changed a whole life.',
     (('삼하', 9, 1, 9, 13),)),
    ('다윗', '골리앗', None,
     '사십 일 동안 아무도 나서지 못했습니다. 다윗이 나갈 때 사울은 자기 '
     '갑옷을 입혔으나 그는 벗었습니다. 익숙하지 않다는 것이었습니다'
     '(삼상 17:39).\n'
     '그가 든 것은 물맷돌 다섯과 이 말이었습니다. 「너는 칼과 창과 단창으로 '
     '내게 나아오거니와 나는 만군의 여호와의 이름으로 네게 나아가노라」'
     '(삼상 17:45).\n'
     '싸움의 승부는 무기에서 갈리지 않았습니다.',
     'For forty days no one would go out. When David went, Saul put his own '
     'armour on him, but David took it off — he was not used to it '
     '(1 Sam 17:39).\n'
     'He carried five smooth stones and these words: "You come to me with a '
     'sword and with a spear... but I come to you in the name of the LORD of '
     'hosts" (1 Sam 17:45).\n'
     'The battle was not decided by weapons.',
     (('삼상', 17, 32, 17, 40), ('삼상', 17, 45, 17, 50))),
    ('아히도벨', '다윗', None,
     '아히도벨의 모략은 「하나님의 말씀을 물음과 한가지라」 할 만큼 무거웠습니다'
     '(삼하 16:23). 그런 사람이 압살롬의 편에 섰습니다.\n'
     '다윗의 기도는 한 줄이었습니다. 「여호와여 원하옵건대 아히도벨의 모략을 '
     '어리석게 하옵소서」(삼하 15:31). 그리고 후새를 보냈습니다.\n'
     '자기 모략이 받아들여지지 않자 아히도벨은 고향으로 돌아가 집을 정리하고 '
     '스스로 목매어 죽었습니다(삼하 17:23). 가장 지혜롭던 사람의 끝이 '
     '그러했습니다.',
     'The counsel of Ahithophel was as if one consulted the word of God '
     '(2 Sam 16:23). Such a man went over to Absalom.\n'
     'David\'s prayer was one line: "O LORD, please turn the counsel of '
     'Ahithophel into foolishness" (2 Sam 15:31) — and he sent Hushai.\n'
     'When his counsel was not followed, Ahithophel went home, set his house '
     'in order, and hanged himself (2 Sam 17:23). So ended the wisest of men.',
     (('삼하', 15, 30, 15, 34), ('삼하', 17, 14, 17, 23))),
    ('사무엘', '다윗', None,
     '사무엘은 이새의 집에서 다윗에게 기름을 부었고, 「이 날 이후로 다윗이 '
     '여호와의 영에게 크게 감동되니라」 했습니다(삼상 16:13).\n'
     '뒤에 다윗이 사울을 피해 도망했을 때 찾아간 곳도 사무엘이 있는 '
     '라마 나욧이었습니다(삼상 19:18).\n'
     '기름 부어 준 사람이 도망할 때 숨을 곳이 되기도 합니다. 부르심과 '
     '피난처가 같은 손에서 나왔습니다.',
     'Samuel anointed David in his father\'s house, and "the Spirit of the '
     'LORD rushed upon David from that day forward" (1 Sam 16:13).\n'
     'Later, fleeing Saul, David went to Samuel at Ramah (1 Sam 19:18).\n'
     'The one who anointed him became his hiding place. Calling and refuge '
     'came from the same hand.',
     (('삼상', 16, 12, 16, 13), ('삼상', 19, 18, 19, 24))),
    # ── 모세·아브라함 계열 ───────────────────────────────────────
    ('아므람', '모세', None,
     '아므람과 요게벳은 아들을 낳고 석 달을 숨겼습니다. 더 숨길 수 없게 '
     '되자 갈대 상자에 역청과 나무 진을 칠하고 나일강 갈대 사이에 '
     '두었습니다(출 2:3).\n'
     '히브리서는 그 일을 이렇게 적습니다. 「믿음으로 모세가 났을 때에 그 '
     '부모가 아름다운 아이임을 보고 석 달 동안 숨겨 왕의 명령을 무서워 '
     '아니하였으며」(히 11:23).\n'
     '두려움 앞에서 내린 한 집안의 결정이 한 민족의 출애굽으로 이어졌습니다.',
     'Amram and Jochebed hid their son three months. When they could hide him '
     'no longer they made a basket of bulrushes, daubed it with bitumen and '
     'pitch, and placed it among the reeds by the Nile (Ex 2:3).\n'
     'Hebrews says, "By faith Moses, when he was born, was hidden three months '
     'by his parents... and they were not afraid of the king\'s edict" '
     '(Heb 11:23).\n'
     "One household's decision in the face of fear led to a nation's exodus.",
     (('출', 2, 1, 2, 10), ('히', 11, 23))),
    ('미리암', '모세', None,
     '미리암은 갈대 상자를 멀리서 지켜보다가 바로의 딸에게 나아가 「내가 '
     '가서 유모를 불러오리이까」 했습니다(출 2:7). 그렇게 어머니가 자기 '
     '아들을 젖 먹여 기르게 됐습니다.\n'
     '홍해를 건넌 뒤에는 소선택할 들고 앞서 노래했습니다(출 15:20~21).\n'
     '그러나 뒤에 아론과 함께 모세를 비방하다 나병에 걸렸고, 모세는 '
     '「하나님이여 그를 고쳐 주옵소서」 하고 부르짖었습니다(민 12:13). '
     '가까운 사이일수록 시기와 중보가 함께 있습니다.',
     'Miriam watched the basket from afar and said to Pharaoh\'s daughter, '
     '"Shall I go and call a nurse for you?" (Ex 2:7) — so the mother nursed '
     'her own son.\n'
     'After the sea she took a tambourine and led the singing (Ex 15:20-21).\n'
     'Yet later she spoke against Moses with Aaron and became leprous, and '
     'Moses cried, "O God, please heal her" (Num 12:13). Among the closest, '
     'envy and intercession live side by side.',
     (('출', 2, 4, 2, 9), ('출', 15, 20, 15, 21), ('민', 12, 1, 12, 15))),
    ('바로', '모세', None,
     '모세의 요구는 한 문장이었습니다. 「내 백성을 보내라 그러면 그들이 '
     '광야에서 내 앞에 절기를 지킬 것이니라」(출 5:1).\n'
     '바로의 대답도 한 문장이었습니다. 「여호와가 누구관대 내가 그 말을 '
     '듣고 이스라엘을 보내겠느냐 나는 여호와를 알지 못하니」(출 5:2).\n'
     '열 재앙은 그 물음에 대한 답이었습니다. 마지막에 그는 밤중에 사람을 '
     '불러 「나를 위하여 축복하라」 했습니다(출 12:32).',
     'Moses\' demand was one sentence: "Let my people go, that they may hold '
     'a feast to me in the wilderness" (Ex 5:1).\n'
     'Pharaoh\'s answer was one too: "Who is the LORD, that I should obey his '
     'voice? I do not know the LORD" (Ex 5:2).\n'
     'The ten plagues were the answer to that question. At the last he called '
     'them by night and said, "And bless me also" (Ex 12:32).',
     (('출', 5, 1, 5, 9), ('출', 12, 29, 12, 33))),
    ('아브라함', '사라', None,
     '사라는 아들을 주시겠다는 말을 장막 문 뒤에서 듣고 속으로 웃었습니다. '
     '「내가 노쇠하였고 내 주인도 늙었으니 내게 무슨 즐거움이 있으리요」'
     '(창 18:12).\n'
     '태어난 아들의 이름이 「웃음」, 곧 이삭입니다. 사라는 「하나님이 나를 '
     '웃게 하시니 듣는 자가 다 나와 함께 웃으리로다」 했습니다(창 21:6).\n'
     '못 믿어 웃던 웃음이 기뻐서 웃는 웃음으로 바뀌었습니다.',
     'Sarah laughed to herself behind the tent door when she heard she would '
     'have a son: "After I am worn out, and my lord is old, shall I have '
     'pleasure?" (Gen 18:12).\n'
     'The son was named Laughter — Isaac. Sarah said, "God has made laughter '
     'for me; everyone who hears will laugh over me" (Gen 21:6).\n'
     'Laughter of disbelief turned into laughter of joy.',
     (('창', 18, 9, 18, 15), ('창', 21, 1, 21, 7))),
    ('아브라함', '이삭', None,
     '「네 아들 네 사랑하는 독자 이삭을 데리고 모리아 땅으로 가라」'
     '(창 22:2). 사흘 길을 가는 동안 아버지가 무슨 생각을 했는지 성경은 '
     '적지 않습니다.\n'
     '이삭이 물었습니다. 「불과 나무는 있거니와 번제할 어린 양은 '
     '어디 있나이까.」 아브라함이 답했습니다. 「하나님이 자기를 위하여 '
     '친히 준비하시리라」(창 22:8).\n'
     '그 말이 그대로 되었습니다. 뒷날 다른 산에서 다시 한 번 그렇게 됩니다.',
     '"Take your son, your only son Isaac, whom you love, and go to the land '
     'of Moriah" (Gen 22:2). Scripture does not record what the father thought '
     'on that three-day road.\n'
     'Isaac asked, "Where is the lamb for a burnt offering?" Abraham answered, '
     '"God will provide for himself the lamb" (Gen 22:8).\n'
     'It happened as he said. On another mountain it happened again.',
     (('창', 22, 1, 22, 14),)),
    # ── 그 밖 ────────────────────────────────────────────────────
    ('바울', '요한 마가', 'CONFLICT_TEMP',
     '마가는 첫 전도여행 중에 돌아갔습니다. 둘째 여행을 앞두고 바나바는 '
     '다시 데려가려 했고 바울은 반대했습니다. 「서로 심히 다투어 피차 '
     '갈라서니」(행 15:39).\n'
     '그런데 바울이 마지막 편지에서 이렇게 씁니다. 「마가를 데리고 오라 '
     '그가 나의 일에 유익하니라」(딤후 4:11).\n'
     '한 번 갈라섰다고 끝이 아닙니다. 사람은 다시 쓰일 수 있고, 그 판단을 '
     '고칠 줄 아는 사람이 있습니다.',
     'Mark turned back during the first journey. Before the second, Barnabas '
     'wanted to take him again and Paul refused: "There arose a sharp '
     'disagreement, so that they separated" (Acts 15:39).\n'
     'Yet in his last letter Paul writes, "Get Mark and bring him with you, '
     'for he is very useful to me for ministry" (2 Tim 4:11).\n'
     'One parting is not the end. A man may be useful again, and some men can '
     'change their judgment.',
     (('행', 15, 36, 15, 41), ('딤후', 4, 11))),
    ('이사야', '히스기야', None,
     '히스기야가 병들어 죽게 되었을 때 이사야가 와서 「너는 집을 정리하라 '
     '네가 죽고 살지 못하리라」 했습니다. 왕은 얼굴을 벽으로 향하고 '
     '기도하며 심히 통곡했습니다(왕하 20:2~3).\n'
     '이사야가 성읍 가운데 이르기도 전에 여호와의 말씀이 그에게 임했습니다. '
     '「내가 네 기도를 들었고 네 눈물을 보았노라 내가 너를 낫게 하리니.」\n'
     '앗수르가 성을 에워쌌을 때도 이 둘이 함께 섰습니다. 왕이 편지를 펴 '
     '놓고 기도하고, 선지자가 응답을 전했습니다.',
     'When Hezekiah was sick to death, Isaiah came and said, "Set your house '
     'in order, for you shall die." The king turned his face to the wall and '
     'wept bitterly (2 Kgs 20:2-3).\n'
     'Before Isaiah had gone out of the middle court the word came: "I have '
     'heard your prayer; I have seen your tears; behold, I will heal you."\n'
     'When Assyria surrounded the city these two stood together again — the '
     'king spread the letter before the LORD, the prophet brought the answer.',
     (('왕하', 19, 14, 19, 20), ('왕하', 20, 1, 20, 6))),
    ('예레미야', '시드기야', None,
     '시드기야는 예레미야를 여러 번 몰래 불러 물었습니다. 「여호와께로부터 '
     '받은 말씀이 있느냐.」 예레미야의 대답은 늘 같았습니다. 바벨론 왕에게 '
     '항복하면 살고 그렇지 않으면 성이 불탄다는 것이었습니다.\n'
     '왕은 그 말이 옳은 줄 알면서도 방백들을 두려워하여 따르지 못했습니다'
     '(렘 38:19).\n'
     '듣기는 하는데 따르지 못하는 자리가 있습니다. 성은 불탔고 왕은 '
     '두 눈을 잃었습니다.',
     'Zedekiah repeatedly summoned Jeremiah in secret: "Is there any word from '
     'the LORD?" The answer was always the same — surrender to Babylon and '
     'live, refuse and the city burns.\n'
     'The king knew it was true yet feared the officials and could not obey '
     '(Jer 38:19).\n'
     'There is a place where a man hears and cannot follow. The city burned, '
     'and the king lost his eyes.',
     (('렘', 37, 16, 37, 21), ('렘', 38, 14, 38, 23))),
    ('갈렙', '모세', None,
     '열두 정탐꾼 가운데 갈렙과 여호수아만 다르게 보고했습니다. 갈렙이 '
     '백성을 조용히 시키고 말했습니다. 「우리가 곧 올라가서 그 땅을 취하자 '
     '능히 이기리라」(민 13:30).\n'
     '사십오 년 뒤 여든다섯에 그가 여호수아에게 말합니다. 「그 날에 '
     '여호와께서 말씀하신 이 산지를 지금 내게 주소서」(수 14:12).\n'
     '들은 말을 사십오 년 동안 붙들고 있던 사람이 있습니다.',
     'Of the twelve spies only Caleb and Joshua reported differently. Caleb '
     'quieted the people: "Let us go up at once and occupy it, for we are well '
     'able to overcome it" (Num 13:30).\n'
     'Forty-five years later, at eighty-five, he said to Joshua, "Give me this '
     'hill country of which the LORD spoke on that day" (Josh 14:12).\n'
     'Here is a man who held a word for forty-five years.',
     (('민', 13, 30, 13, 33), ('수', 14, 6, 14, 14))),
)

#: 미아 설명문 복구 — 실측 오프셋(§아래 `fix_desc` 주석)
DESC_OFFSET = 62832


def _conn(db=None):
    return appdb.connect(db) if db else appdb.connect()


def _name(conn, eid, lang='KO'):
    r = conn.execute("SELECT contents FROM sys_text_asset"
                     " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                     "   AND lang_code=? LIMIT 1", (eid, lang)).fetchone()
    return r[0].strip() if r and r[0] else None


def _has_col(conn, table, col):
    return any(r[1] == col for r in conn.execute('PRAGMA table_info(%s)' % table))


# ── ① 칸 신설 ────────────────────────────────────────────────────
def init(conn):
    """`redemptive_axis` 칸을 만든다(멱등). 기존 칸·데이터는 안 건드린다."""
    try:
        nv = conn.execute("SELECT COUNT(*) FROM sys_link_asset"
                          " WHERE link_type=? AND"
                          " COALESCE(record_status,'LIVE')='LIVE'",
                          (PREL_LT,)).fetchone()[0]
        nr = conn.execute("SELECT COUNT(DISTINCT clicked_id) FROM"
                          " sys_link_asset WHERE link_type=? AND"
                          " COALESCE(record_status,'LIVE')='LIVE'",
                          (PREL_LT,)).fetchone()[0]
        print('  관계 구절: %d건 (관계 %d개에 걸림)' % (nv, nr))
    except Exception as e:
        print('  관계 구절 못 셈: %s' % e)
    if _has_col(conn, 'sys_person_relation', 'redemptive_axis'):
        return False
    conn.execute('ALTER TABLE sys_person_relation ADD COLUMN'
                 ' redemptive_axis TEXT')
    conn.commit()
    return True


# ── ② 미아 설명문 복구 ───────────────────────────────────────────
def orphan_descs(conn):
    """주인이 없는 `RELATION_DESC` — (sys_text_id, clicked_id, 앞머리)."""
    return conn.execute(
        "SELECT sys_text_id, clicked_id, SUBSTR(contents,1,40)"
        "  FROM sys_text_asset t WHERE t.text_type='RELATION_DESC'"
        "   AND NOT EXISTS(SELECT 1 FROM sys_person_relation r"
        "     WHERE r.relation_id=t.clicked_id) ORDER BY clicked_id").fetchall()


def fix_desc(conn, apply_it=False):
    """★★★ **오프셋 62832 만큼 밀린 것**을 되돌린다.

    실측 — `clicked_id` 62833·62834·62837·62838·62839 이고 그 글이 말하는
    관계는 각각 rid **1·2·5·6·7** 이다(다윗-요나단 FRIEND · 다윗-사울 RIVAL ·
    바울-디모데 · 엘리야-엘리사 · 모세-아론). **차이가 정확히 62832 로 같다** —
    `relation_id` 자리에 다른 번호를 넣은 것이다.

    ⚠ **오프셋만 믿지 않는다** — 옮길 자리가 실재하는지 확인하고, 이미 글이
      있는 관계는 덮지 않는다. 하나라도 어긋나면 **아무것도 안 옮긴다**
      (반쯤 옮기면 어디까지 됐는지 알 수 없다).
    """
    moves, bad = [], []
    for tid, cid, head in orphan_descs(conn):
        new = cid - DESC_OFFSET
        ok = conn.execute("SELECT COUNT(*) FROM sys_person_relation"
                          " WHERE relation_id=?", (new,)).fetchone()[0]
        dup = conn.execute("SELECT COUNT(*) FROM sys_text_asset"
                           " WHERE text_type='RELATION_DESC' AND clicked_id=?",
                           (new,)).fetchone()[0]
        if not ok or dup:
            bad.append((tid, cid, new, '대상 없음' if not ok else '이미 글 있음'))
        else:
            moves.append((tid, cid, new, head))
    if bad:
        return moves, bad
    if apply_it and moves:
        for tid, _cid, new, _h in moves:
            conn.execute("UPDATE sys_text_asset SET clicked_id=?"
                         " WHERE sys_text_id=?", (new, tid))
        conn.commit()
    return moves, bad


# ── ③ 오분류 교정 ────────────────────────────────────────────────
def retype(conn, apply_it=False):
    """`RETYPE` 표대로 바로잡는다 → [(rid, 이름쌍, 전, 후)].

    ⚠ 값이 `None` 이면 **그 줄을 걷는다**(HIDE) — 지우지 않는다. 되돌릴 수
      있어야 하고, 그 판단이 틀렸을 때 근거가 남아야 한다.
    """
    out = []
    rows = conn.execute(
        "SELECT relation_id, from_person_id, to_person_id,"
        " relation_cat, relation_type FROM sys_person_relation"
        " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchall()
    for rid, f, t, c0, t0 in rows:
        key = (_name(conn, f), _name(conn, t), t0)
        if key not in RETYPE:
            continue
        new = RETYPE[key]
        if new is None:
            out.append((rid, '%s→%s' % (key[0], key[1]), '%s/%s' % (c0, t0),
                        '(걷음)'))
            if apply_it:
                conn.execute("UPDATE sys_person_relation"
                             " SET record_status='HIDE' WHERE relation_id=?",
                             (rid,))
                _mirror_hide(conn, f, t, t0)
            continue
        cat, typ = new
        if (c0, t0) == (cat, typ):
            continue
        out.append((rid, '%s→%s' % (key[0], key[1]), '%s/%s' % (c0, t0),
                    '%s/%s' % (cat, typ)))
        if apply_it:
            conn.execute("UPDATE sys_person_relation SET relation_cat=?,"
                         " relation_type=? WHERE relation_id=?",
                         (cat, typ, rid))
            _mirror_retype(conn, f, t, t0, cat, typ)
    if apply_it and out:
        conn.commit()
    return out


# ── ③-b 통합 표(거울) ────────────────────────────────────────────
#  ⚠⚠ **화면이 읽는 것은 이쪽이다.** 옛 표만 고치면 아무것도 안 바뀐다.
MIRROR_LT = 'ENTI_ENTI'


def _mirror_hide(conn, f, t, typ):
    """통합 표의 같은 줄을 걷는다(양방향으로 찾는다)."""
    return conn.execute(
        "UPDATE sys_link_asset SET record_status='HIDE'"
        " WHERE link_type=? AND rel_code=?"
        "   AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))",
        (MIRROR_LT, typ, f, t, t, f)).rowcount


def _mirror_retype(conn, f, t, old_typ, cat, typ):
    """통합 표의 `rel_code`·`relation_cat` 을 바로잡는다."""
    return conn.execute(
        "UPDATE sys_link_asset SET rel_code=?, relation_cat=?"
        " WHERE link_type=? AND rel_code=?"
        "   AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))",
        (typ, cat, MIRROR_LT, old_typ, f, t, t, f)).rowcount


def mirror_diff(conn):
    """두 표가 어긋난 곳 → (옛 표에만, 통합 표에만).

    ★ **거울이 깨지면 화면과 가계도가 다른 말을 한다** — 그것이 이 검사의 몫.
    """
    import entity_relation as _ER
    ph = ','.join("'%s'" % x for x in _ER.PERSON)
    a = conn.execute(
        "SELECT COUNT(*) FROM sys_person_relation r"
        " WHERE COALESCE(r.record_status,'LIVE')='LIVE'"
        "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
        "     WHERE l.link_type='%s' AND l.clicked_id=r.from_person_id"
        "       AND l.target_id=r.to_person_id AND l.rel_code=r.relation_type"
        "       AND COALESCE(l.record_status,'LIVE')='LIVE')" % MIRROR_LT
    ).fetchone()[0]
    b = conn.execute(
        "SELECT COUNT(*) FROM sys_link_asset l"
        " WHERE l.link_type='%s' AND l.rel_code IN (%s)"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND NOT EXISTS(SELECT 1 FROM sys_person_relation r"
        "     WHERE r.from_person_id=l.clicked_id AND r.to_person_id=l.target_id"
        "       AND r.relation_type=l.rel_code"
        "       AND COALESCE(r.record_status,'LIVE')='LIVE')" % (MIRROR_LT, ph)
    ).fetchone()[0]
    return a, b


def sync_mirror(conn, apply_it=False):
    """★★ **옛 표 → 통합 표** 로 어긋난 것을 맞춘다 → [(무엇, 짝, 전, 후)].

    ⚠ **이 방향인 까닭** — 사람이 고치는 도구(`RETYPE`·`--fix-desc`)가 옛
      표를 만지므로 그쪽이 더 새롭다. 화면이 읽는 것은 통합 표이니 **밀어
      넣어야 화면에 닿는다.**
    ⚠ **짝을 못 찾으면 만들지 않는다** — 통합 표에 없는 관계를 여기서 새로
      지으면 어느 쪽이 정본인지 영영 알 수 없게 된다. 이름을 대고 알린다.
    """
    import entity_relation as _ER
    out = []
    # ① 옛 표에서 걷힌 것 → 통합 표에서도 걷는다
    for f, t, typ in conn.execute(
            "SELECT from_person_id, to_person_id, relation_type"
            "  FROM sys_person_relation WHERE record_status='HIDE'"):
        rows = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset WHERE link_type=?"
            "  AND rel_code=? AND COALESCE(record_status,'LIVE')='LIVE'"
            "  AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))",
            (MIRROR_LT, typ, f, t, t, f)).fetchall()
        for (lid,) in rows:
            out.append(('걷기', '%s→%s' % (_name(conn, f), _name(conn, t)),
                        typ, '(걷음)'))
            if apply_it:
                conn.execute("UPDATE sys_link_asset SET record_status='HIDE'"
                             " WHERE sys_link_id=?", (lid,))
    # ② 옛 표에만 있는 유형 → 통합 표의 같은 짝에서 옛 유형을 찾아 갈아 끼운다
    for rid, f, t, cat, typ in conn.execute(
            "SELECT relation_id, from_person_id, to_person_id, relation_cat,"
            " relation_type FROM sys_person_relation"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        got = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type=?"
            "  AND rel_code=? AND COALESCE(record_status,'LIVE')='LIVE'"
            "  AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))",
            (MIRROR_LT, typ, f, t, t, f)).fetchone()[0]
        if got:
            continue
        # 그 짝의 다른 줄 중 **옛 표에 없는 유형**을 골라 갈아 끼운다
        cand = conn.execute(
            "SELECT sys_link_id, rel_code FROM sys_link_asset WHERE link_type=?"
            "  AND COALESCE(record_status,'LIVE')='LIVE'"
            "  AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))"
            "  AND rel_code IN (%s)" % ','.join("'%s'" % x for x in _ER.PERSON),
            (MIRROR_LT, f, t, t, f)).fetchall()
        pick = None
        for lid, rc in cand:
            if not conn.execute(
                    "SELECT COUNT(*) FROM sys_person_relation"
                    " WHERE from_person_id=? AND to_person_id=? AND relation_type=?"
                    "   AND COALESCE(record_status,'LIVE')='LIVE'",
                    (f, t, rc)).fetchone()[0]:
                pick = (lid, rc)
                break
        nm = '%s→%s' % (_name(conn, f), _name(conn, t))
        if pick is None:
            out.append(('⚠ 짝 없음', nm, typ, '(통합 표에 만들지 않는다)'))
            continue
        out.append(('유형', nm, pick[1], typ))
        if apply_it:
            conn.execute("UPDATE sys_link_asset SET rel_code=?, relation_cat=?"
                         " WHERE sys_link_id=?", (typ, cat, pick[0]))
    if apply_it and out:
        conn.commit()
    return out


# ── ④ 축 배정 ────────────────────────────────────────────────────
def axis_for(conn, rid, cat, typ, fid, tid):
    """그 관계의 축 — `OVERRIDE`(사람) 가 `TYPE_AXIS`(초안) 를 이긴다."""
    key = (_name(conn, fid), _name(conn, tid))
    if key in OVERRIDE:
        return OVERRIDE[key]
    rev = (key[1], key[0])
    if rev in OVERRIDE:
        return OVERRIDE[rev]
    return TYPE_AXIS.get(typ)


def assign_axis(conn, apply_it=False):
    """전 관계에 축을 매긴다(멱등) → (배정, 미배정)."""
    if not _has_col(conn, 'sys_person_relation', 'redemptive_axis'):
        raise RuntimeError('--init 을 먼저 돌리십시오')
    done, none = [], []
    for rid, cat, typ, f, t in conn.execute(
            "SELECT relation_id, relation_cat, relation_type,"
            " from_person_id, to_person_id FROM sys_person_relation"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        ax = axis_for(conn, rid, cat, typ, f, t)
        nm = '%s→%s' % (_name(conn, f) or f, _name(conn, t) or t)
        (done if ax else none).append((rid, nm, typ, ax))
        if apply_it:
            conn.execute("UPDATE sys_person_relation SET redemptive_axis=?"
                         " WHERE relation_id=?", (ax, rid))
    if apply_it:
        conn.commit()
    return done, none


def pick_axis(axes):
    """★ 축이 여럿이면 **무거운 쪽 하나** — 목록 라벨이 길어지지 않게."""
    got = [a for a in axes if a]
    if not got:
        return None
    return sorted(got, key=lambda a: AXIS_RANK.get(a, 99))[0]


# ── ⑤ 관계 ↔ 구절 (`PREL_VERS`) ──────────────────────────────────
#  ★★★ 사용자 설계(0.person.txt §2) — 「다윗-후새를 선택하면 **다윗과 후새의
#    관계유형에 따른 설명문 + 해당 구절들**을 연결한다」.
#  ★ **새 표를 만들지 않는다** — 통합 표에 유형 하나를 더한다(§coding.md §1-A).
#      link_type  'PREL_VERS'
#      clicked_id  relation_id       target_id  verse_id(시작)
#      end_id      verse_id(끝·구간)  note       (선택)
#  ⚠ **`link_picker.KINDS` 에는 안 올린다** — 인물 관계는 「연결 대상 자산」이
#    아니라 **그 자체가 연결**이다. 올리면 「관계를 다른 것에 연결」이 되어
#    축이 어긋난다. 여기와 관리자 화면이 다룬다.
PREL_LT = 'PREL_VERS'


def verses_of(conn, relation_id, lang='KO'):
    """그 관계에 걸린 구절 → [(link_id, start_vid, end_vid, 약명, 본문)]."""
    out = []
    for lid, sv, ev in conn.execute(
            "SELECT sys_link_id, target_id, end_id FROM sys_link_asset"
            "  WHERE link_type=? AND clicked_id=?"
            "    AND COALESCE(record_status,'LIVE')='LIVE'"
            "  ORDER BY target_id", (PREL_LT, relation_id)):
        out.append((lid, sv, ev, _ref(conn, sv, ev), _verse_text(conn, sv)))
    return out


def _ref(conn, sv, ev):
    """`창1:1` / `창1:1~3` — 표기는 `link_picker.scope_label` 에 위임한다."""
    try:
        import link_picker as LP
        return LP.scope_label(conn, sv, ev) or _ref_plain(conn, sv)
    except Exception:
        return _ref_plain(conn, sv)


def _ref_plain(conn, vid):
    r = conn.execute("SELECT bcode, chapter, verse FROM bible_index"
                     " WHERE verse_id=?", (vid,)).fetchone()
    if not r:
        return '#%s' % vid
    nm = conn.execute("SELECT book_name FROM book_names WHERE book_code=?"
                      "   AND lang_code='KO' LIMIT 1", (r[0],)).fetchone()
    return '%s%d:%d' % (nm[0] if nm else r[0], r[1], r[2])


def _verse_text(conn, vid, ver=None):
    r = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=?"
                     "  AND version_code=COALESCE(?,'KRV') LIMIT 1",
                     (vid, ver)).fetchone()
    return (r[0] if r else '') or ''


def add_verse(conn, relation_id, start_vid, end_vid=None, note=None):
    """관계에 구절(또는 구간)을 잇는다 — 멱등.

    ⚠ **없는 관계·없는 구절에는 안 붙인다**(§97차 유령 연결). 거짓이면 False.
    """
    if not conn.execute("SELECT COUNT(*) FROM sys_person_relation"
                        " WHERE relation_id=?", (relation_id,)).fetchone()[0]:
        return False
    for v in (start_vid, end_vid):
        if v and not conn.execute("SELECT COUNT(*) FROM bible_index"
                                  " WHERE verse_id=?", (v,)).fetchone()[0]:
            return False
    if conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type=?"
                    "  AND clicked_id=? AND target_id=?"
                    "  AND COALESCE(end_id,-1)=COALESCE(?,-1)",
                    (PREL_LT, relation_id, start_vid, end_vid)).fetchone()[0]:
        return True                      # 이미 있다 — 멱등
    conn.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                 " end_id, note, record_status)"
                 " VALUES(?,?,?,?,?,'LIVE')",
                 (PREL_LT, relation_id, start_vid, end_vid, note))
    conn.commit()
    return True


def relation_id_of(conn, from_id, to_id, rel_type=None):
    """★★ **번호 다리** — 화면(통합 표)이 든 값으로 옛 표 PK 를 찾는다.

    ⚠⚠ **번호 축이 둘이다.** 화면은 `sys_link_asset` 을 읽는데 관계
      설명문(`RELATION_DESC`)과 관계 구절(`PREL_VERS`)은 **옛 표의
      `relation_id`** 를 닻으로 삼는다(`db_link_migrate` 가 그렇게 적어 두었다).
      다리가 없으면 **글과 구절을 만들어 두고도 화면이 못 찾는다** —
      「저장은 되는데 안 보인다」(§95차)의 그 자리.
    ⚠ 양방향으로 찾는다(저장 방향이 짝마다 다르다).
    """
    q = ("SELECT relation_id FROM sys_person_relation"
         " WHERE COALESCE(record_status,'LIVE')='LIVE'"
         "   AND ((from_person_id=? AND to_person_id=?)"
         "     OR (from_person_id=? AND to_person_id=?))")
    a = [from_id, to_id, to_id, from_id]
    if rel_type:
        q += " AND relation_type=?"
        a.append(rel_type)
    r = conn.execute(q + " LIMIT 1", a).fetchone()
    return r[0] if r else None


def relation_view(conn, from_id, to_id, rel_type=None, lang='KO'):
    """그 관계의 **설명문 + 구절** → {'rid','desc','verses'} | None.

    ★ 화면 하나가 이 문만 부르면 된다 — 번호 축이 둘이라는 사실을 화면이
      알 필요가 없다.
    """
    rid = relation_id_of(conn, from_id, to_id, rel_type)
    if rid is None:
        return None
    d = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='RELATION_DESC'"
        "  AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
        "  ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0"
        "           WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1", (rid, lang)).fetchone()
    return {'rid': rid, 'desc': (d[0] if d else None),
            'verses': verses_of(conn, rid, lang)}


def find_relation(conn, a, b, rel_type=None):
    """이름 둘(+유형)로 관계를 찾는다 → relation_id | None.

    ⚠ **이름으로 찾는다** — 번호는 재적재로 갈린다(§179차).
    """
    for rid, f, t, typ in conn.execute(
            "SELECT relation_id, from_person_id, to_person_id, relation_type"
            "  FROM sys_person_relation"
            "  WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        if rel_type and typ != rel_type:
            continue
        nf, nt = _name(conn, f), _name(conn, t)
        if (nf, nt) == (a, b) or (nf, nt) == (b, a):
            return rid
    return None


# ── ⑥ 적재 (그룹 · 인물 · 관계 · 구절) ───────────────────────────
def _entity_by_code(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master"
                     " WHERE entity_code=?", (code,)).fetchone()
    return r[0] if r else None


def _entity_by_name(conn, nm, lang='KO'):
    r = conn.execute(
        "SELECT e.entity_id FROM sys_entity_master e"
        "  JOIN sys_text_asset t ON t.clicked_id=e.entity_id"
        "   AND t.text_type='ENTITY_NAME' AND t.lang_code=?"
        "   AND TRIM(t.contents)=?"
        " WHERE e.record_status='LIVE' LIMIT 1", (lang, nm)).fetchone()
    return r[0] if r else None


def _put_text(conn, ttype, cid, lang, body):
    """같은 자리에 글이 있으면 덮지 않는다(사람이 고친 것을 지우지 않는다)."""
    if conn.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type=?"
                    " AND clicked_id=? AND lang_code=?",
                    (ttype, cid, lang)).fetchone()[0]:
        return False
    conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code,"
                 " contents, record_status) VALUES(?,?,?,?,'LIVE')",
                 (cid, ttype, lang, body))
    return True


def _vid(conn, book_ko, ch, vs):
    """`('삼하', 15, 32)` → verse_id. 못 찾으면 None(지어내지 않는다)."""
    r = conn.execute(
        "SELECT bi.verse_id FROM bible_index bi"
        "  JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code='KO'"
        " WHERE (bn.full_name=? OR bn.short_name=?) AND bi.chapter=?"
        "   AND bi.verse=? LIMIT 1", (book_ko, book_ko, ch, vs)).fetchone()
    return r[0] if r else None


def load(conn, apply_it=False):
    """그룹·인물·관계·구절을 적재한다 → 로그 목록. **멱등**."""
    log = []

    # ① 그룹 — 이름만. 낱낱은 엔티티로 안 만든다(사용자 지시)
    import json
    for code, ko, en, dko, den, js in GROUPS:
        eid = _entity_by_code(conn, code)
        if eid is None:
            if not apply_it:
                log.append(('그룹', code, '새로 만듦'))
                continue
            conn.execute(
                "INSERT INTO sys_entity_master(entity_code, entity_type,"
                " importance, json_detail, record_status)"
                " VALUES(?,'GROUP',6,?,'LIVE')",
                (code, json.dumps(js, ensure_ascii=False)))
            eid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            log.append(('그룹', code, '만듦 #%d' % eid))
        else:
            log.append(('그룹', code, '이미 있음 #%d' % eid))
        if apply_it and eid:
            _put_text(conn, 'ENTITY_NAME', eid, 'KO', ko)
            _put_text(conn, 'ENTITY_NAME', eid, 'EN', en)
            _put_text(conn, 'ENTITY_DESC', eid, 'KO', dko)
            _put_text(conn, 'ENTITY_DESC', eid, 'EN', den)

    # ② 인물
    for code, ko, en, dko, den, tribe, role, era, sex, imp in PEOPLE:
        eid = _entity_by_code(conn, code)
        if eid is None:
            if not apply_it:
                log.append(('인물', ko, '새로 만듦'))
                continue
            conn.execute(
                "INSERT INTO sys_entity_master(entity_code, entity_type,"
                " importance, record_status) VALUES(?,'PERSON',?,'LIVE')",
                (code, imp))
            eid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            conn.execute(
                "INSERT OR IGNORE INTO sys_person(person_id, tribe_code,"
                " role_primary, time_context, gender) VALUES(?,?,?,?,?)",
                (eid, tribe, role, era, sex))
            log.append(('인물', ko, '만듦 #%d' % eid))
        else:
            log.append(('인물', ko, '이미 있음 #%d' % eid))
        if apply_it and eid:
            _put_text(conn, 'ENTITY_NAME', eid, 'KO', ko)
            _put_text(conn, 'ENTITY_NAME', eid, 'EN', en)
            _put_text(conn, 'ENTITY_DESC', eid, 'KO', dko)
            _put_text(conn, 'ENTITY_DESC', eid, 'EN', den)

    if apply_it:
        conn.commit()

    # ③ 관계 + 설명문 + 구절
    for a, b, cat, typ, axis, rko, ren, verses in NEW_RELATIONS:
        fa, fb = _entity_by_name(conn, a), _entity_by_name(conn, b)
        if not fa or not fb:
            log.append(('⚠ 관계', '%s→%s' % (a, b), '인물이 없다'))
            continue
        rid = find_relation(conn, a, b, typ)
        if rid is None:
            if not apply_it:
                log.append(('관계', '%s→%s' % (a, b), '%s 새로' % typ))
                continue
            conn.execute(
                "INSERT INTO sys_person_relation(from_person_id,"
                " to_person_id, relation_cat, relation_type, is_directed,"
                " record_status, redemptive_axis) VALUES(?,?,?,?,1,'LIVE',?)",
                (fa, fb, cat, typ, axis))
            rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            # ⚠⚠ **거울에도 넣는다** — 화면이 읽는 것은 통합 표다.
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " rel_code, relation_cat, is_directed, record_status)"
                " VALUES(?,?,?,?,?,1,'LIVE')",
                (MIRROR_LT, fa, fb, typ, cat))
            log.append(('관계', '%s→%s' % (a, b), '만듦 rid=%d' % rid))
        else:
            log.append(('관계', '%s→%s' % (a, b), '이미 있음 rid=%d' % rid))
        if not apply_it or not rid:
            continue
        _put_text(conn, 'RELATION_DESC', rid, 'KO', rko)
        _put_text(conn, 'RELATION_DESC', rid, 'EN', ren)
        for v in verses:
            sv = _vid(conn, v[0], v[1], v[2])
            ev = _vid(conn, v[0], v[3], v[4]) if len(v) > 4 else None
            if sv is None:
                log.append(('⚠ 구절', '%s %s:%s' % v[:3], '못 찾음'))
                continue
            add_verse(conn, rid, sv, ev)
        conn.commit()
    return log


def fill(conn, apply_it=False):
    """`FILL` — **있는 관계**에 설명문·구절만 얹는다 → 로그.

    ⚠ 관계를 만들지 않는다. 없으면 이름을 대고 알린다(§0-1 조용한 실패 금지).
    ⚠ 설명문이 `None` 이면 **구절만** 붙인다(글은 이미 있는 것).
    ⚠ `_put_text` 가 **있는 글을 안 덮는다** — 사람이 고친 것을 지우지 않는다.
    """
    log = []
    for row in FILL + FILL2:
        a, b, typ, dko, den, verses = row
        rid = find_relation(conn, a, b, typ)
        if rid is None:
            log.append(('⚠', '%s↔%s' % (a, b), '관계가 없다'))
            continue
        n = 0
        if apply_it:
            if dko:
                n += 1 if _put_text(conn, 'RELATION_DESC', rid, 'KO', dko) else 0
            if den:
                n += 1 if _put_text(conn, 'RELATION_DESC', rid, 'EN', den) else 0
        bad = 0
        for v in verses:
            sv = _vid(conn, v[0], v[1], v[2])
            ev = _vid(conn, v[0], v[3], v[4]) if len(v) > 4 else None
            if sv is None:
                bad += 1
                log.append(('⚠ 구절', '%s %s:%s' % v[:3], '못 찾음'))
                continue
            if apply_it:
                add_verse(conn, rid, sv, ev)
        log.append(('채움', '%s↔%s' % (a, b),
                    'rid=%d 글+%d 구절%d%s'
                    % (rid, n, len(verses) - bad,
                       ' ⚠못찾음%d' % bad if bad else '')))
        if apply_it:
            conn.commit()
    return log


# ── 진단 ─────────────────────────────────────────────────────────
def check(conn):
    print('=== 인물 관계 진단')
    n = conn.execute("SELECT COUNT(*) FROM sys_person_relation"
                     " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                     ).fetchone()[0]
    nd = conn.execute("SELECT COUNT(*) FROM sys_text_asset"
                      " WHERE text_type='RELATION_DESC'").fetchone()[0]
    print('  관계 %d건 · 관계 설명문 %d건' % (n, nd))
    orp = orphan_descs(conn)
    print('  ⚠ 주인 없는 설명문: %d건%s'
          % (len(orp), '' if not orp else ' — --fix-desc'))
    try:
        ma, mb = mirror_diff(conn)
        print('  %s 거울 어긋남: 옛 표에만 %d · 통합 표에만 %d%s'
              % ('⚠' if (ma or mb) else ' ', ma, mb,
                 '  — --retype 이 양쪽을 고칩니다' if (ma or mb) else ''))
    except Exception as e:
        print('  거울 대조 못 함: %s' % e)
    rt = retype(conn)
    print('  ⚠ 오분류(고칠 것): %d건%s'
          % (len(rt), '' if not rt else ' — --retype'))
    for r in rt:
        print('       rid=%-4s %-16s %s → %s' % r)
    if _has_col(conn, 'sys_person_relation', 'redemptive_axis'):
        done, none = assign_axis(conn)
        got = [d for d in done if d[3]]
        print('  축 배정 가능 %d · 사람이 정해야 함 %d' % (len(got), len(none)))
        for r in none[:12]:
            print('       rid=%-4s %-22s %s' % (r[0], r[1], r[2]))
        if len(none) > 12:
            print('       … 그 밖 %d건' % (len(none) - 12))
    else:
        print('  redemptive_axis 칸 없음 — --init')
    return len(orp) + len(rt)


# ── selftest ─────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[1] += 1
        ok[0] += 1 if c else 0
        print('  %s %-50s %s' % ('OK  ' if c else 'FAIL', n, e))

    print('=== db_person_relation selftest')
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_person_relation(relation_id INTEGER PRIMARY KEY,
        from_person_id INT, to_person_id INT, relation_cat TEXT,
        relation_type TEXT, is_directed INT, record_status TEXT);
      CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY,
        clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT,
        record_status TEXT);
      -- ⚠ **거울 표를 처음부터 만든다** — `retype` 이 통합 표도 고치므로
      --   나중에 만들면 `no such table` 로 죽는다(실측).
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,
        link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,
        relation_cat TEXT, end_id INT, note TEXT, record_status TEXT);
    """)
    for eid, nm in ((1, '다윗'), (2, '요나단'), (3, '우리아'), (4, '사울')):
        c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
                  "contents,record_status) VALUES(?,'ENTITY_NAME','KO',?,"
                  "'LIVE')", (eid, nm))
    c.execute("INSERT INTO sys_person_relation(relation_id,from_person_id,to_person_id,relation_cat,relation_type,is_directed,record_status) VALUES"
              "(1,1,2,'SOCIAL','FRIEND',1,'LIVE')")
    c.execute("INSERT INTO sys_person_relation(relation_id,from_person_id,to_person_id,relation_cat,relation_type,is_directed,record_status) VALUES"
              "(2,1,3,'SOCIAL','CONFLICT_TEMP',1,'LIVE')")
    c.commit()

    t('★ 축은 넷뿐이다', len(AXES) == 4, len(AXES))
    t('  축 코드가 겹치지 않는다', len(set(AXIS_CODES)) == 4)
    t('★ 목록 라벨은 4자 이내', all(len(a[1]) <= 4 for a in AXES),
      '/'.join(a[1] for a in AXES))

    t('★ 칸을 만든다', init(c) is True)
    t('  두 번 만들어도 안전(멱등)', init(c) is False)

    # 미아 설명문 — 오프셋
    c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
              "contents,record_status) VALUES(?,'RELATION_DESC','KO',"
              "'다윗과 요나단…','LIVE')", (1 + DESC_OFFSET,))
    c.commit()
    t('★ 미아를 찾는다', len(orphan_descs(c)) == 1)
    mv, bad = fix_desc(c, apply_it=True)
    t('★★ 오프셋대로 되돌린다', not bad and len(mv) == 1 and mv[0][2] == 1,
      str(mv[:1]))
    t('  옮긴 뒤 미아 0', len(orphan_descs(c)) == 0)

    # 탐지력 — 대상이 없으면 아무것도 안 옮긴다
    c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
              "contents,record_status) VALUES(?,'RELATION_DESC','KO','x',"
              "'LIVE')", (99999,))
    c.commit()
    mv2, bad2 = fix_desc(c, apply_it=True)
    t('★★ 대상이 없으면 **아무것도 안 옮긴다**', bool(bad2) and not mv2,
      str(bad2[:1]))
    c.execute("DELETE FROM sys_text_asset WHERE clicked_id=99999")
    c.commit()

    # 오분류 교정
    rt = retype(c)
    t('★★ 다윗→우리아 오분류를 잡는다',
      any('우리아' in x[1] for x in rt), str(rt))
    retype(c, apply_it=True)
    got = c.execute("SELECT relation_cat, relation_type FROM"
                    " sys_person_relation WHERE relation_id=2").fetchone()
    t('  고치면 BETRAYAL 이 된다', got == ('SOCIAL', 'BETRAYAL'), str(got))
    t('  두 번 돌려도 더 안 바뀐다(멱등)', not retype(c))

    # ★★★ 같은 짝의 **다른 유형 행은 안 건드린다** (실측으로 잡은 결함)
    c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
              "contents,record_status) VALUES(5,'ENTITY_NAME','KO','압살롬',"
              "'LIVE')")
    c.execute("INSERT INTO sys_person_relation(relation_id,from_person_id,to_person_id,relation_cat,relation_type,is_directed,record_status) VALUES"
              "(3,1,5,'FAMILY','FATHER',1,'LIVE')")
    c.execute("INSERT INTO sys_person_relation(relation_id,from_person_id,to_person_id,relation_cat,relation_type,is_directed,record_status) VALUES"
              "(4,1,5,'SOCIAL','CONFLICT_TEMP',1,'LIVE')")
    c.commit()
    retype(c, apply_it=True)
    fa = c.execute("SELECT relation_cat, relation_type FROM"
                   " sys_person_relation WHERE relation_id=3").fetchone()
    en = c.execute("SELECT relation_cat, relation_type FROM"
                   " sys_person_relation WHERE relation_id=4").fetchone()
    t('★★★ 부자 행은 그대로 (FAMILY/FATHER)', fa == ('FAMILY', 'FATHER'),
      str(fa))
    t('  갈등 행만 ENEMY 로', en == ('SOCIAL', 'ENEMY'), str(en))

    # ★★ 걷기(None) — 이미 같은 뜻의 행이 있는 경우
    c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
              "contents,record_status) VALUES(6,'ENTITY_NAME','KO','사무엘',"
              "'LIVE')")
    c.execute("INSERT INTO sys_person_relation(relation_id,from_person_id,to_person_id,relation_cat,relation_type,is_directed,record_status) VALUES"
              "(7,6,4,'SOCIAL','CONFLICT_TEMP',1,'LIVE')")
    c.commit()
    retype(c, apply_it=True)
    st = c.execute("SELECT record_status FROM sys_person_relation"
                   " WHERE relation_id=7").fetchone()[0]
    t('★★ 중복이 되는 줄은 **걷는다**(지우지 않는다)', st == 'HIDE', st)

    # 축
    done, none = assign_axis(c, apply_it=True)
    ax = {r[0]: r[3] for r in done}
    t('★ FRIEND 은 언약 축', ax.get(1) == 'COVENANT', ax)
    t('★★ 사람이 정한 것이 유형보다 세다',
      ax.get(2) == 'CONFLICT', ax)          # 다윗→우리아 OVERRIDE
    t('  다시 돌려도 같다(멱등)',
      {r[0]: r[3] for r in assign_axis(c, apply_it=True)[0]} == ax)

    t('★★★ 축이 여럿이면 **하나만** 선택한다',
      pick_axis(['RESTORATION', 'COVENANT']) == 'COVENANT')
    t('  빈 것은 None', pick_axis([None, None]) is None)
    t('  하나뿐이면 그것', pick_axis(['CONFLICT']) == 'CONFLICT')

    # 가족은 축이 안 정해진다 = 사람이 정한다
    # ★★★ 거울 — 화면이 읽는 표까지 닿는가
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,"
              "rel_code,relation_cat,record_status)"
              " VALUES('ENTI_ENTI',1,3,'CONFLICT_TEMP','SOCIAL','LIVE')")
    c.commit()
    a0, b0 = mirror_diff(c)
    t('★★ 거울이 어긋난 것을 잡는다', a0 > 0 or b0 > 0, (a0, b0))
    sync_mirror(c, apply_it=True)
    got = c.execute("SELECT rel_code FROM sys_link_asset"
                    " WHERE clicked_id=1 AND target_id=3").fetchone()
    t('★★★ **화면이 읽는 표까지 고친다**', got and got[0] == 'BETRAYAL',
      str(got))
    t('  맞춘 뒤 어긋남이 준다', sum(mirror_diff(c)) < a0 + b0,
      '%s → %s' % ((a0, b0), mirror_diff(c)))

    # ★★★ 관계 ↔ 구절
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT,
        chapter INT, verse INT);
      CREATE TABLE bible_content(verse_id INT, version_code TEXT,
        verse_text TEXT);
      CREATE TABLE book_names(book_code INT, lang_code TEXT, book_name TEXT);
    """)
    for vid, bc, ch, vs in ((100, 9, 18, 3), (101, 9, 18, 4)):
        c.execute("INSERT INTO bible_index VALUES(?,?,?,?)", (vid, bc, ch, vs))
        c.execute("INSERT INTO bible_content VALUES(?,'KRV','…')", (vid,))
    c.execute("INSERT INTO book_names VALUES(9,'KO','삼상')")
    c.commit()
    rid = find_relation(c, '다윗', '요나단')
    t('★ 이름으로 관계를 찾는다', rid == 1, rid)
    t('  없는 짝은 None', find_relation(c, '다윗', '없는사람') is None)
    t('★★ 구절을 붙인다', add_verse(c, rid, 100, 101) is True)
    t('  두 번 붙여도 안 는다(멱등)',
      add_verse(c, rid, 100, 101) is True and len(verses_of(c, rid)) == 1)
    t('★★ **없는 관계에는 안 붙인다**', add_verse(c, 99999, 100) is False)
    t('★★ **없는 구절에는 안 붙인다**', add_verse(c, rid, 88888) is False)
    vs = verses_of(c, rid)
    t('  구간을 그대로 돌려준다', vs[0][1] == 100 and vs[0][2] == 101, vs[0][:3])
    t('  약명을 만든다', '삼상' in vs[0][3], vs[0][3])

    # ★★★ 번호 다리 — 화면이 든 값으로 글·구절을 찾는가
    t('★★ 번호 다리(정방향)', relation_id_of(c, 1, 2) == 1)
    t('  역방향으로도 찾는다', relation_id_of(c, 2, 1) == 1)
    t('  유형까지 맞춘다',
      relation_id_of(c, 1, 2, 'FRIEND') == 1
      and relation_id_of(c, 1, 2, 'ENEMY') is None)
    # ⚠ **앞 단계 상태를 전제하지 않는다**(§0-5) — 위 `fix_desc` 시험이 이미
    #   rid=1 에 글을 붙여 두었다. 「무슨 글인가」가 아니라 **「글과 구절이
    #   함께 오는가」**를 잰다.
    v = relation_view(c, 1, 2)
    t('★★★ **화면이 든 값으로 글과 구절을 찾는다**',
      bool(v) and bool(v['desc']) and len(v['verses']) == 1, str(v)[:60])
    t('  없는 짝은 None', relation_view(c, 1, 99999) is None)

    t('★ 가족 유형은 초안 축이 없다(사람이 정한다)',
      TYPE_AXIS.get('FATHER') is None and TYPE_AXIS.get('SPOUSE') is None)
    t('★ 모든 세부 유형이 표에 있다',
      not (set(x[0] for x in c.execute(
          "SELECT DISTINCT relation_type FROM sys_person_relation"))
           - set(TYPE_AXIS)))
    c.close()
    print('  %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = _conn()
    try:
        if '--init' in a:
            print('칸 신설:', '만듦' if init(conn) else '이미 있음')
        if '--fix-desc' in a:
            mv, bad = fix_desc(conn, apply_it=True)
            for x in bad:
                print('  ⚠ 못 옮김 %s' % (x,))
            for x in mv:
                print('  %s → rid=%s  %s' % (x[1], x[2], x[3]))
            print('옮긴 설명문 %d건%s'
                  % (len(mv), ' · 막힌 것 %d' % len(bad) if bad else ''))
        if '--retype' in a:
            for x in retype(conn, apply_it=True):
                print('  rid=%-4s %-16s %s → %s' % x)
        if '--mirror' in a:
            for x in sync_mirror(conn, apply_it=True):
                print('  %-10s %-16s %s → %s' % x)
        if '--load' in a:
            for x in load(conn, apply_it=True):
                print('  %-8s %-16s %s' % x)
        if '--fill' in a:
            for x in fill(conn, apply_it=True):
                print('  %-8s %-14s %s' % x)
        if '--axis' in a:
            done, none = assign_axis(conn, apply_it=True)
            print('축 배정 %d · 사람이 정해야 함 %d'
                  % (len([d for d in done if d[3]]), len(none)))
        if '--check' in a or not a:
            sys.exit(1 if check(conn) else 0)
    finally:
        conn.close()
