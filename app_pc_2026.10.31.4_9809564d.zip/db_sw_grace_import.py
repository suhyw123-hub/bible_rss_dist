# -*- coding: utf-8 -*-
"""스펄전 도서 2권 적재 — The Soul Winner · All of Grace (영구 도구)

  python db_sw_grace_import.py --selftest          # 의무
  python db_sw_grace_import.py --fetch             # 원문 수집 (_swgrace_raw/, gitignore)
  python db_sw_grace_import.py --check             # 파싱 검사 (DB 무변경)
  python db_sw_grace_import.py --apply SW 1 8 15   # Soul Winner 표본 3장 (§0-1b 앞/중/끝)
  python db_sw_grace_import.py --apply SW          # 전량 (사용자 검수 후)
  python db_sw_grace_import.py --apply AOG         # All of Grace 전량

소스 (§0-1b 실측 — 2026-08-17):
  · Soul Winner  : CCEL 없음 · Gutenberg 없음(스펄전 6종뿐) →
    3순위 archive.spurgeon.org/misc/sw01~15.php (Treasury 와 같은 검증 사이트)
  · All of Grace : 1순위 CCEL cache/grace.txt (190KB 교정 텍스트, 20개 장)

⚠ 함정 (전부 실측):
  · Soul Winner 는 장 첫 글자가 **드롭캡 이미지**다(`<IMG SRC="images/i.gif">`) —
    태그만 벗기면 "I PURPOSE"가 "PURPOSE"로 첫 글자가 사라진다. 글자로 되살린다.
    (Treasury 26편에는 드롭캡이 없다 — grep 으로 확인, 적재본 무손상.)
  · 본문 끝 경계 = 「This book was transcribed …」 크레딧. 안 자르면 필사자
    이름·네비게이션이 본문에 붙는다.
  · 태그 대소문자 혼재 가능(Treasury 에서 실측) — 전부 대소문자 무관으로.
  · CCEL txt 는 75자 하드랩 + 문단 사이 빈 줄. 줄을 문단으로 되붙여야 한다.
  · 남의 글 — 문단·엠대시·고어체 보존(§28-11 이중 엔터 정리 대상 아님).
    출처는 §17-8 정책대로 본문 끝줄에 "— Author, Book (Year)".
"""
import io
import os
import re
import sys
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_swgrace_raw')
DB = os.path.join(HERE, 'bible_master.db')

SW_URL = 'https://archive.spurgeon.org/misc/sw%02d.php'
# ⚠ archive.spurgeon.org 의 sw13·sw14 는 **서버가 문장 중간에서 자른 채** 준다
#   (재수집해도 같은 바이트 — 2026-08-17 실측). romans45.org 미러가 완결본이고
#   앞 5,000자 대조로 같은 필사본임을 확인했다. 크레딧 문구("This book was
#   transcribed")가 없으면 절단본이다 — fetch 가 그걸로 판별해 미러로 넘어간다.
SW_MIRROR = 'http://www.romans45.org/spurgeon/misc/sw%02d.htm'
SW_END_MARK = 'This book was transcribed'
AOG_URL = 'https://ccel.org/ccel/s/spurgeon/grace/cache/grace.txt'
SW_N = 15

BOOKS = {
    'SW': dict(code='SPURGEON_SW', title='The Soul Winner',
               author='Charles H. Spurgeon', year=1895, category='SPIRITUALITY',
               src='https://archive.spurgeon.org/misc/soulwinr.php',
               desc='How to lead sinners to the Saviour. Lectures and addresses '
                    'on soul-winning, published posthumously in 1895. '
                    'Source: The Spurgeon Archive (archive.spurgeon.org).',
               attrib='— C. H. Spurgeon, The Soul Winner (1895)'),
    'AOG': dict(code='SPURGEON_AOG', title='All of Grace',
                author='Charles H. Spurgeon', year=1886, category='DOCTRINE',
                src='https://ccel.org/ccel/spurgeon/grace/grace',
                desc='An earnest word with those who are seeking salvation by '
                     'the Lord Jesus Christ (1886). CCEL edition, 20 chapters. '
                     'Source: Christian Classics Ethereal Library (ccel.org).',
                attrib='— C. H. Spurgeon, All of Grace (1886)'),
}

_ENT = {'&#151;': '—', '&mdash;': '—', '&#150;': '–',
        '&quot;': '"', '&amp;': '&', '&nbsp;': ' ', '&#146;': "’",
        '&#145;': "‘", '&#147;': '“', '&#148;': '”'}


def _fetch(url):
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


# ── Soul Winner (HTML) ────────────────────────────────────────────────────

def _clean_html(html):
    """태그 제거·실체참조 복원. <P>/<BR> 만 문단 개행으로. 하드랩은 공백으로."""
    s = html.replace('\r', ' ').replace('\n', ' ')
    # 드롭캡: <IMG SRC="images/x.gif"> → 대문자 글자 (첫 글자 소실 방지)
    s = re.sub(r'(?i)<IMG[^>]*SRC="[^"]*/([a-z])\.gif"[^>]*>',
               lambda m: m.group(1).upper(), s)
    s = re.sub(r'(?i)<IMG[^>]*>', ' ', s)   # indent.gif 등 장식 이미지
    s = re.sub(r'(?i)<P\b[^>]*>', '\n', s)
    s = re.sub(r'(?i)<BR\b[^>]*>', '\n', s)
    s = re.sub(r'<[^>]+>', ' ', s)
    for k, v in _ENT.items():
        s = s.replace(k, v)
    s = re.sub(r'&#\d+;', ' ', s)
    lines = [' '.join(ln.split()) for ln in s.split('\n')]
    return '\n'.join(ln for ln in lines if ln)


def parse_sw(path):
    """swNN.php → (title, body)"""
    h = io.open(path, encoding='utf-8', errors='replace').read()
    m = re.search(r'(?is)<H1[^>]*>(.*?)</H1>', h)
    if not m:
        raise ValueError('%s — H1 제목이 없다' % path)
    title = ' '.join(re.sub(r'<[^>]+>', ' ', m.group(1)).split())
    for k, v in _ENT.items():
        title = title.replace(k, v)
    # 본문 끝 = 필사 크레딧. 그 태그 시작까지 되감는다(Treasury 반쪽 태그 교훈).
    i_end = h.find('This book was transcribed')
    if i_end < 0:
        raise ValueError('%s — 끝 크레딧 경계가 없다' % path)
    i_end = h.rfind('<', 0, i_end)
    body = _clean_html(h[m.end():i_end])
    if not body or len(body) < 500:
        raise ValueError('%s — 본문이 너무 짧다(%d자)' % (path, len(body)))
    return title, body


# ── All of Grace (CCEL txt) ───────────────────────────────────────────────

def _is_sep(line):
    s = line.strip()
    return len(s) > 20 and set(s) == {'_'}


def parse_aog(path):
    """grace.txt → [(title, body)] — 구분선(____)으로 갈린 장 목록.

    앞 두 덩이(메타·표제지)와 끝 덩이(CCEL 꼬리)는 뺀다. 75자 하드랩을
    문단으로 되붙인다(빈 줄 = 문단 경계).
    """
    lines = io.open(path, encoding='utf-8', errors='replace').read().split('\n')
    seps = [i for i, l in enumerate(lines) if _is_sep(l)]
    if len(seps) < 5:
        raise ValueError('%s — 구분선이 %d개뿐' % (path, len(seps)))
    chapters = []
    for k in range(len(seps) - 1):
        seg = lines[seps[k] + 1:seps[k + 1]]
        # 제목 = 첫 비어있지 않은 줄
        ti = next((j for j, l in enumerate(seg) if l.strip()), None)
        if ti is None:
            continue
        title = seg[ti].strip()
        if title.startswith('Title:') or title.upper() in ('ALL OF GRACE',) \
                or 'Christian Classics' in title:
            continue        # 메타·표제지·CCEL 꼬리
        # 본문 — 하드랩 문단 되붙이기
        paras, cur = [], []
        for l in seg[ti + 1:]:
            t = l.strip()
            if t:
                cur.append(t)
            elif cur:
                paras.append(' '.join(cur)); cur = []
        if cur:
            paras.append(' '.join(cur))
        body = '\n'.join(paras)
        if len(body) < 200:
            continue        # 표제지 조각 등
        chapters.append((title.title(), body))
    return chapters


# ── 검사·적재 ─────────────────────────────────────────────────────────────

def check(verbose=True):
    bad, out = [], []
    for n in range(1, SW_N + 1):
        p = os.path.join(RAW, 'sw%02d.php' % n)
        if not os.path.exists(p):
            bad.append('sw%02d — 원문 없음(--fetch)' % n); continue
        try:
            title, body = parse_sw(p)
        except ValueError as e:
            bad.append(str(e)); continue
        if '<' in body or '<' in title:
            bad.append('sw%02d — 태그 잔재' % n)
        out.append('SW %2d — %-46s %6d자 · 문단 %d' %
                   (n, title[:46], len(body), body.count('\n') + 1))
    p = os.path.join(RAW, 'grace.txt')
    if not os.path.exists(p):
        bad.append('grace.txt — 원문 없음(--fetch)')
    else:
        chs = parse_aog(p)
        if len(chs) != 20:
            bad.append('AOG — 장이 20개가 아니라 %d개' % len(chs))
        for i, (t, b) in enumerate(chs, 1):
            if '<' in b:
                bad.append('AOG %d — 태그 잔재' % i)
            out.append('AOG %2d — %-45s %6d자 · 문단 %d' %
                       (i, t[:45], len(b), b.count('\n') + 1))
    if verbose:
        for ln in out:
            print(ln)
        for ln in bad:
            print('FAIL', ln)
    return bad


def _ensure_book(conn, b):
    row = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                       (b['code'],)).fetchone()
    if row:
        return row[0]
    conn.execute(
        """INSERT INTO sys_book_asset
           (book_code, title, author, lang_code, copyright_type, source_url,
            pub_year, description, record_status, book_category)
           VALUES (?,?,?,?,?,?,?,?,'LIVE',?)""",
        (b['code'], b['title'], b['author'], 'EN', 'PUBLIC_DOMAIN',
         b['src'], b['year'], b['desc'], b['category']))
    return conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                        (b['code'],)).fetchone()[0]


def _upsert_unit(conn, book_id, seq, label, body):
    """(book_id, sequence) 기준 멱등 — 재적재해도 unit_id 가 바뀌지 않는다."""
    row = conn.execute(
        'SELECT unit_id FROM sys_book_unit WHERE book_id=? AND sequence=?',
        (book_id, seq)).fetchone()
    if row:
        uid = row[0]
        conn.execute('UPDATE sys_book_unit SET unit_label=?, session_type=?, '
                     "record_status='LIVE' WHERE unit_id=?",
                     (label, 'CHAPTER', uid))
    else:
        conn.execute(
            """INSERT INTO sys_book_unit
               (book_id, sequence, session_type, unit_label, record_status)
               VALUES (?,?,?,?,'LIVE')""", (book_id, seq, 'CHAPTER', label))
        uid = conn.execute(
            'SELECT unit_id FROM sys_book_unit WHERE book_id=? AND sequence=?',
            (book_id, seq)).fetchone()[0]
    conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? "
                 "AND text_variant='ORIGINAL' AND UPPER(lang_code)='EN'", (uid,))
    conn.execute(
        """INSERT INTO sys_book_unit_text
           (unit_id, text_variant, lang_code, body_text, record_status)
           VALUES (?,'ORIGINAL','EN',?,'LIVE')""", (uid, body))
    return uid


def apply(which, units=None):
    if check(verbose=False):
        print('검사 실패 — --check 먼저'); return False
    b = BOOKS[which]
    if which == 'SW':
        chapters = []
        for n in range(1, SW_N + 1):
            t, body = parse_sw(os.path.join(RAW, 'sw%02d.php' % n))
            chapters.append((n, t, body))
    else:
        chs = parse_aog(os.path.join(RAW, 'grace.txt'))
        chapters = [(i, t, body) for i, (t, body) in enumerate(chs, 1)]
    if units:
        chapters = [c for c in chapters if c[0] in units]
    conn = appdb.connect(DB)
    try:
        book_id = _ensure_book(conn, b)
        for seq, t, body in chapters:
            _upsert_unit(conn, book_id, seq, t, body + '\n' + b['attrib'])
            print('%s %2d — %s' % (which, seq, t[:50]))
        conn.commit()
        print('적재 — %s(book_id %d) 유닛 %d' % (b['code'], book_id, len(chapters)))
    finally:
        conn.close()
    return True


# ── selftest ──────────────────────────────────────────────────────────────

_FIX_SW = """<HTML><CENTER><h1>What Is It to Win a Soul?</h1></CENTER><P>
<IMG SRC="images/i.gif" ALIGN=LEFT>  PURPOSE, dear brethren, to give
you a short course of lectures.<BR>
<IMG SRC="images/indent.gif" ALT="  ">Second paragraph here&#151;with a dash.<P>
""" + 'Filler sentence to pass the length gate. ' * 20 + """<P>
<CENTER><FONT SIZE="-1">This book was transcribed for the Archive by X.</FONT></CENTER>
</HTML>"""

_FIX_AOG = ("   x\n" + "_" * 60 + "\n\n   Title: All of Grace\n\n" + "_" * 60 +
            "\n\n   ALL of GRACE\n\n" + "_" * 60 + "\n\n   TO YOU\n\n" +
            ("   he who spoke and wrote this message will be greatly\n"
             "   disappointed if it does not lead many to the Lord Jesus.\n\n") * 8 +
            "_" * 60 + "\n\n   CLOSE\n\n" +
            ("   another paragraph of sufficient length to pass the gate\n"
             "   wrapped at seventy five columns like the source file.\n\n") * 8 +
            "_" * 60 + "\n\n  This document is from the Christian Classics\n")


def selftest():
    ok = True
    os.makedirs(RAW, exist_ok=True)
    p1 = os.path.join(RAW, 'sw99_fixture.php')
    p2 = os.path.join(RAW, 'grace_fixture.txt')
    io.open(p1, 'w', encoding='utf-8').write(_FIX_SW)
    io.open(p2, 'w', encoding='utf-8').write(_FIX_AOG)
    try:
        t, body = parse_sw(p1)
        if t != 'What Is It to Win a Soul?':
            print('FAIL SW 제목(소문자 h1): %r' % t); ok = False
        if not body.startswith('I PURPOSE'):
            print('FAIL SW 드롭캡 복원: %r' % body[:20]); ok = False
        if '—' not in body:
            print('FAIL SW 엠대시 실체참조'); ok = False
        if 'transcribed' in body or '<' in body:
            print('FAIL SW 크레딧·태그 침범'); ok = False
        chs = parse_aog(p2)
        titles = [t for t, _ in chs]
        if titles != ['To You', 'Close']:
            print('FAIL AOG 장 분리: %s' % titles); ok = False
        if chs and '\n' not in chs[0][1] and chs[0][1].count(' ') < 10:
            print('FAIL AOG 하드랩 되붙이기'); ok = False
        if any('Christian Classics' in b for _, b in chs):
            print('FAIL AOG CCEL 꼬리 침범'); ok = False
    finally:
        os.remove(p1); os.remove(p2)
    print('db_sw_grace_import selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--fetch', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', nargs='+', metavar=('SW|AOG', 'SEQ'))
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.fetch:
        os.makedirs(RAW, exist_ok=True)
        import time
        for n in range(1, SW_N + 1):
            p = os.path.join(RAW, 'sw%02d.php' % n)
            if os.path.exists(p) and SW_END_MARK in io.open(
                    p, encoding='utf-8', errors='replace').read():
                continue
            data = _fetch(SW_URL % n)
            src = 'archive'
            if SW_END_MARK not in data.decode('utf-8', 'replace'):
                data = _fetch(SW_MIRROR % n)      # 절단본 → 미러 완결본
                src = 'romans45 미러'
                if SW_END_MARK not in data.decode('utf-8', 'replace'):
                    print('sw%02d — 두 소스 다 절단본, 건너뜀' % n)
                    continue
            io.open(p, 'wb').write(data)
            print('sw%02d %d bytes (%s)' % (n, len(data), src))
            time.sleep(1)
        p = os.path.join(RAW, 'grace.txt')
        if not os.path.exists(p):
            data = _fetch(AOG_URL)
            io.open(p, 'wb').write(data)
            print('grace.txt %d bytes' % len(data))
        return
    if a.check:
        sys.exit(1 if check() else 0)
    if a.apply:
        which = a.apply[0].upper()
        if which not in BOOKS:
            print('SW 또는 AOG'); sys.exit(1)
        units = [int(x) for x in a.apply[1:]] or None
        sys.exit(0 if apply(which, units) else 1)
    ap.print_help()


if __name__ == '__main__':
    main()
