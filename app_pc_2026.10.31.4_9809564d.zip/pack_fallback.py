# -*- coding: utf-8 -*-
"""**안 받은 자산**을 「소개 + 받기」로 그리는 공용 부품.

★★★ 왜 (2026-09-04 사용자 확정 「방법 2」 — 「사용자가 다운로드 받지 않은
  자산과 연결된 것이 나타나면 **무조건 효과적인 방법으로 폴백 처리**한다」).
  코어팩이 **모든 연결과 모든 껍데기**를 담으므로, 본문을 안 받아도
  「멜기세덱 반차 — 스펄전 설교 선집」이라는 것은 **언제나 안다**.
  ⇒ 빈칸을 두지 않고 **읽을 것을 보이고 받는 길을 그 자리에 낸다.**

★★ **이것이 팩 쪼개기의 성패를 가른다** — 폴백이 어설프면 「안 받은 자산이
  있는 상태」가 고장처럼 보이고, 그러면 사용자가 결국 전부 받게 되어 쪼갠 뜻이
  사라진다.

**상황마다 답이 다르다** — 조용히 비우는 것이 가장 나쁘다(§0-1):
  · `MISSING`  본문을 안 받았다 → 소개 + 크기 + [받기]
  · `LANG`     그 언어만 없다   → 있는 언어로 보이고 「그 언어는 안 받았다」
  · `UNKNOWN`  껍데기도 없다    → 「목록을 갱신해야 합니다」(코어가 낡았다)
  · `OK`       있다             → 폴백 안 그린다

⚠ **지금은 폴백이 거의 안 걸린다** — 아직 DB 를 통째로 배포하므로 전부 갖고
  있다. 그래서 **시험이 「없는 척」을 만들어** 잰다(그러지 않으면 이 코드가
  도는지 알 수 없다).

`--selftest`(의무).
"""
import argparse
import io
import sys

OK, MISSING, LANG, UNKNOWN = 'OK', 'MISSING', 'LANG', 'UNKNOWN'

#: 자산 갈래 → (본문이 있는 표, 그 표의 열쇠 칸, 껍데기 조회).
#: ⚠ 갈래를 늘리면 **여기 한 줄** — 안 적으면 `UNKNOWN` 이 되어 화면이
#:   「목록 갱신」이라 말한다(조용히 비지는 않는다).
KINDS = ('BOOK', 'SERMON', 'DICT', 'BIBLE', 'COMM', 'DESC', 'CORE', 'LEX')


def _desc_range(key):
    """설명문 팩 열쇠 → `(첫 책, 끝 책)`.

    ★ 새 열쇠 = 성경책 묶음 코드(`PENT`) · 옛 열쇠 = 책 번호(`'1'`).
    ⚠ 모르면 **온 성경**을 낸다 — 0건으로 떨어뜨리면 「안 받았다」는 거짓말이
      된다(§0-1).
    """
    k = str(key or '').strip()
    if k.isdigit():
        return int(k), int(k)
    try:
        import db_pack_body as PB
        return PB.group_range(k)
    except Exception:                                        # noqa: BLE001
        return 1, 66


def _desc_name(conn, key):
    """설명문 팩 열쇠 → 사람이 읽는 이름."""
    k = str(key or '').strip()
    if k.isdigit():
        try:
            r = conn.execute("SELECT full_name FROM book_names"
                             " WHERE book_code=? AND lang_code='KO'",
                             (int(k),)).fetchone()
            if r:
                return r[0]
        except Exception:                                    # noqa: BLE001
            pass
        return '책 %s' % k
    try:
        import db_pack_body as PB
        return PB.group_name(k)
    except Exception:                                        # noqa: BLE001
        return k


_BOOK_LANGS = {'at': 0.0, 'set': None}


def _book_langs(conn):
    """{(책 코드, 언어)} — 본문이 있는 짝을 **한 번에** 센다(2초 기억).
    ★ 2026-10-13 — 책마다 따로 묻던 것(166번 · 1.8초)이 설정 ▸ 다운로드 탭을 붙들었다.
      한 번 묻는 데 0.02초다. 지우거나 받은 직후 화면이 다시 물을 때는 2초 안에 새로 센다."""
    import time
    now = time.time()
    if _BOOK_LANGS['set'] is None or now - _BOOK_LANGS['at'] > 2.0:
        _BOOK_LANGS['set'] = {(r[0], (r[1] or '').upper()) for r in conn.execute(
            "SELECT DISTINCT ba.book_code, UPPER(t.lang_code) FROM sys_book_unit_text t"
            " JOIN sys_book_unit u ON u.unit_id=t.unit_id"
            " JOIN sys_book_asset ba ON ba.book_id=u.book_id")}
        _BOOK_LANGS['at'] = now
    return _BOOK_LANGS['set']


def _has_book_text(conn, book_code, lang=None):
    have = _book_langs(conn)
    if lang:
        return int((book_code, lang.upper()) in have)
    return int(any(b == book_code for b, _l in have))


def _has_ref_text(conn, src_code, lang=None):
    """자료집 본문이 있나.

    ⚠⚠ **문답 자료집은 `sys_ref_text` 가 0행**이고 본문이 `sys_ref_unit.
      unit_answer` 에 있다(하이델베르크 129문 · 웨스트민스터 107문 실측).
      그것을 안 보면 **갖고 있는 것을 「안 받았다」고 말한다** — 실측으로 잡았다.
    """
    n = conn.execute(
        "SELECT COUNT(*) FROM (SELECT 1 FROM sys_ref_text t"
        " JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id"
        " JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
        " WHERE rs.src_code=?" + (' AND UPPER(t.lang_code)=?' if lang else '')
        + ' LIMIT 1)', [src_code] + ([lang.upper()] if lang else [])).fetchone()[0]
    if n:
        return n
    # 문답형 — 답이 유닛 안에 있다(언어 칸이 없어 언어로 못 가른다)
    return conn.execute(
        "SELECT COUNT(*) FROM sys_ref_unit u"
        " JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
        " WHERE rs.src_code=? AND COALESCE(u.unit_answer,'')<>''",
        (src_code,)).fetchone()[0]


def _base(key):
    """쪼갠 열쇠에서 **본디 자산 코드**만 → `SPURGEON_SERMONS#POET` → 앞부분.

    ⚠ 껍데기(제목·저자·소개)는 **자산 하나에 하나**다 — 묶음마다 따로 없다.
      이것을 안 벗기면 쪼갠 자산이 늘 `UNKNOWN`(목록에 없다)으로 뜬다.
    """
    return str(key or '').partition('#')[0]


def state(conn, kind, key, lang=None, strict=False):
    """그 자산을 **지금 갖고 있나** → `OK|MISSING|LANG|UNKNOWN`.

    ★ **실물을 센다** — 「받았다는 기록」이 아니라 본문 행이 있는지 본다.
      용량 때문에 지운 경우를 기록만으로는 못 잡는다(§pack_status 와 같은 원리).

    ★★ **잣대가 둘이다 — `strict` 가 그것을 가른다**(2026-09-04 실측으로 잡음):
      · `strict=False`(폴백 화면) = **읽을 것이 있나**. 문답 자료집은 답이
        `sys_ref_unit.unit_answer`(코어)에 있어 본문팩을 안 받아도 읽힌다.
      · `strict=True`(다운로드 목록) = **팩 본문을 받았나**. 여기서 관대하면
        **지웠는데 「설치됨」**이라 말한다 — 실제로 그랬다.
    """
    kind = (kind or '').upper()
    # ★ **코어는 앱 기본 자료다** — 연결이 있으면 갖고 있는 것이다.
    #   ⚠ 이것이 없으면 다운로드 목록에서 코어가 늘 UNKNOWN 으로 뜬다.
    if kind == 'CORE':
        try:
            n = conn.execute(
                "SELECT COUNT(*) FROM sys_link_asset"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
            return OK if n else MISSING
        except Exception:
            return UNKNOWN
    # ★★ **시작화면 사진 팩**(2026-09-05) — 껍데기가 없는 자산이라 판정 표에
    #   없었고 그래서 다운로드 목록에서 늘 `UNKNOWN`(「목록을 갱신하세요」)으로
    #   떴다. 실측으로 잡았다.
    #   ⚠ 열쇠가 **팩 코드**(BASIC·LAND…)라 그 팩의 사진이 실제로 있는지 센다.
    if kind == 'IMAGE':
        try:
            if (key or '').upper() == 'BASIC':
                n = conn.execute(
                    "SELECT COUNT(*) FROM sys_splash_image"
                    " WHERE COALESCE(basic,0)=1"
                    "   AND COALESCE(is_active,1)=1").fetchone()[0]
            else:
                n = conn.execute(
                    "SELECT COUNT(*) FROM sys_splash_image i"
                    "  JOIN sys_scene_pack p ON p.scene_code=i.scene"
                    " WHERE p.pack_code=?"
                    "   AND COALESCE(i.is_active,1)=1", (key,)).fetchone()[0]
            return OK if n else MISSING
        except Exception:
            return UNKNOWN
    if kind == 'LEX':
        tbl = {'STRONG': 'sys_lemma_master', 'BDB': 'sys_bdb_entry',
               'ABSMITH': 'sys_absmith_entry',
               'THAYER': 'sys_thayer_entry'}.get((key or '').upper())
        if not tbl:
            return UNKNOWN
        try:
            return OK if conn.execute(
                "SELECT COUNT(*) FROM %s" % tbl).fetchone()[0] else MISSING
        except Exception:
            return UNKNOWN
    # ★★ **껍데기도 없으면 UNKNOWN** — 「안 받았다」와 「목록에 없다」는 다르다.
    #   전자는 받으면 되고 후자는 **목록을 갱신해야** 한다(실측으로 갈랐다).
    if kind in KINDS and not shell(conn, kind, key, lang):
        return UNKNOWN
    try:
        if kind in ('BOOK', 'SERMON'):
            bk = _base(key)
            if not _has_book_text(conn, bk):
                return MISSING
            return OK if (not lang or _has_book_text(conn, bk, lang)) else LANG
        if kind == 'DICT':
            if strict:
                # 팩이 담는 표만 본다(`db_pack_body.PARTS['DICT']` 와 같은 곳)
                n = conn.execute(
                    "SELECT COUNT(*) FROM sys_ref_text t"
                    " JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id"
                    " JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
                    " WHERE rs.src_code=?" + (' AND UPPER(t.lang_code)=?'
                                              if lang else ''),
                    [key] + ([lang.upper()] if lang else [])).fetchone()[0]
                return OK if n else MISSING
            if not _has_ref_text(conn, key):
                return MISSING
            return OK if (not lang or _has_ref_text(conn, key, lang)) else LANG
        if kind == 'BIBLE':
            n = conn.execute("SELECT COUNT(*) FROM bible_content"
                             " WHERE version_code=?", (key,)).fetchone()[0]
            return OK if n else MISSING
        if kind == 'COMM':
            n = conn.execute(
                "SELECT COUNT(*) FROM sys_commentary_text t"
                " JOIN sys_commentary_entry e ON e.entry_id=t.entry_id"
                " JOIN sys_commentary_source cs"
                "   ON cs.commentary_id=e.commentary_id"
                " WHERE cs.commentary_code=?", (key,)).fetchone()[0]
            return OK if n else MISSING
        if kind == 'DESC':
            # ⚠⚠ **열쇠가 두 꼴이다**(286차) — 지금은 성경책 묶음 코드
            #   (`PENT`·`GOSP`…)이고 그전에는 책 번호였다. 옛 기록을 든
            #   사용자가 있으므로 **둘 다 읽는다**. `int(key)` 만 쓰면 새
            #   열쇠에서 터져 늘 `UNKNOWN`(「목록을 갱신하세요」)이 된다.
            a0, b0 = _desc_range(key)
            q = ("SELECT COUNT(*) FROM sys_text_asset t"
                 " JOIN bible_index bi ON bi.verse_id=t.clicked_id"
                 " WHERE bi.bcode BETWEEN ? AND ? AND t.record_status='LIVE'"
                 "   AND t.text_type='VERS_DESC'")
            a = [a0, b0]
            if lang:
                q += ' AND UPPER(t.lang_code)=?'
                a.append(lang.upper())
            return OK if conn.execute(q, a).fetchone()[0] else MISSING
    except Exception:
        return UNKNOWN
    return UNKNOWN


def shell(conn, kind, key, lang=None):
    """**껍데기** → `{title, sub, desc, bytes, kind, key, lang}`.

    ★ 코어팩이 담고 있으므로 **본문이 없어도 이것은 늘 있다** — 그것이 폴백을
      「빈칸」이 아니라 「읽을 것」으로 만든다.
    ⚠ 못 찾으면 **빈 dict** — 부르는 쪽이 `UNKNOWN` 으로 그린다.
    """
    kind = (kind or '').upper()
    key = _base(key)          # ⚠ 쪼갠 자산도 껍데기는 하나다
    try:
        if kind in ('BOOK', 'SERMON'):
            r = conn.execute(
                "SELECT title, author, COALESCE(description,''),"
                " COALESCE(body_chars,0) FROM sys_book_asset"
                " WHERE book_code=?", (key,)).fetchone()
            if r:
                return {'title': r[0], 'sub': r[1] or '', 'desc': r[2],
                        'bytes': int(r[3] or 0), 'kind': kind, 'key': key,
                        'lang': lang}
        elif kind == 'DICT':
            r = conn.execute(
                "SELECT title, COALESCE(author,''), COALESCE(src_type,'')"
                "  FROM sys_ref_source WHERE src_code=?", (key,)).fetchone()
            if r:
                return {'title': r[0], 'sub': r[1], 'desc': r[2],
                        'bytes': 0, 'kind': kind, 'key': key, 'lang': lang}
        elif kind == 'BIBLE':
            r = conn.execute(
                "SELECT COALESCE(version_name, version_code),"
                " COALESCE(lang_code,'') FROM bible_version"
                " WHERE version_code=?", (key,)).fetchone()
            if r:
                return {'title': r[0], 'sub': r[1], 'desc': '', 'bytes': 0,
                        'kind': kind, 'key': key, 'lang': lang}
        elif kind == 'COMM':
            r = conn.execute(
                "SELECT title, COALESCE(author,''), COALESCE(description,'')"
                "  FROM sys_commentary_source WHERE commentary_code=?",
                (key,)).fetchone()
            if r:
                return {'title': r[0], 'sub': r[1], 'desc': r[2], 'bytes': 0,
                        'kind': kind, 'key': key, 'lang': lang}
        elif kind in ('CORE', 'LEX'):
            return {'title': '앱 기본 자료' if kind == 'CORE' else (key or ''),
                    'sub': '', 'desc': '', 'bytes': 0, 'kind': kind,
                    'key': key, 'lang': lang}
        elif kind == 'DESC':
            return {'title': '%s 설명문' % _desc_name(conn, key),
                    'sub': lang or '', 'desc': '', 'bytes': 0,
                    'kind': kind, 'key': key, 'lang': lang}
    except Exception:
        pass
    return {}


def message(st, info=None, t=None):
    """상황에 맞는 **한 줄** → 글자. `t` 는 i18n 함수(없으면 한국어).

    ⚠ 상황마다 답이 다르다 — 하나로 뭉뚱그리면 「왜 안 보이나」를 못 답한다.
    """
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d
    if st == MISSING:
        return _('PACKFB_MISSING', '이 자료는 아직 받지 않았습니다.')
    if st == LANG:
        return _('PACKFB_LANG', '이 언어로는 아직 받지 않았습니다.')
    if st == UNKNOWN:
        return _('PACKFB_UNKNOWN',
                 '목록이 오래되었습니다. 자료 목록을 갱신해 주세요.')
    return ''


def as_text(conn, kind, key, lang=None, t=None, where=None):
    """폴백을 **글자로** → 여러 줄. 본문 자리가 Text 위젯인 화면이 쓴다.

    ★ 상자를 못 그리는 자리(도서 본문·자료집 본문)가 있다 — 거기서는 글로
      말한다. **빈 화면을 두지 않는 것**이 목적이지 상자가 목적이 아니다.
    `where` — 「어디서 받나」 한 줄(화면 이름). 없으면 기본 안내.
    """
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d
    st = state(conn, kind, key, lang)
    if st == OK:
        return ''
    info = shell(conn, kind, key, lang) or {}
    lines = []
    if info.get('title'):
        lines.append(info['title'])
        if info.get('sub'):
            lines.append(info['sub'])
        lines.append('')
    lines.append(message(st, info, t))
    if info.get('desc'):
        lines.append('')
        lines.append(info['desc'][:600])
    if st in (MISSING, LANG):
        lines.append('')
        # ⚠ **어디서 받는지 말한다** — 「없다」로 끝내면 무엇을 하라는지 모른다
        lines.append(where or _('PACKFB_WHERE',
                                '설정 ▸ 다운로드 에서 받을 수 있습니다.'))
    return '\n'.join(lines)


def clear_get_buttons(txt):
    """Text 안에 심어 둔 폴백 단추를 **파괴한다**.

    ⚠⚠ `Text.delete` 는 글자만 지우고 `window_create` 로 심은 **위젯은
      살려 둔다** — 다시 그릴 때마다 쌓이고, 본문이 돌아온 뒤에도 단추가
      남는다(실측으로 잡았다). ⇒ **본문을 비우는 자리에서 함께 걷는다.**
    """
    n = 0
    try:
        for w in list(txt.children.values()):
            if getattr(w, '_packfb', False):
                w.destroy()
                n += 1
    except Exception:
        pass
    return n


def taste_split(text):
    """맛보기 표식을 떼고 `(본문, 잘렸나)` — **표식은 화면에 안 보인다**.

    ★ 팩이 자른 글 끝에 `db_pack_taste.TASTE_MARK` 가 붙어 온다. 그것은
      **사람에게 보일 글자가 아니라 신호**다 — 떼어 내고, 대신 화면이
      「여기까지입니다 · 받으러 가기」를 낸다.
    ⚠ 표식을 그대로 두면 본문에 낯선 기호가 찍힌다.
    ⚠ 전체 팩을 받으면 그 글이 통째로 덮이므로 표식도 저절로 사라진다.
    """
    try:
        import db_pack_taste as _TA
        mark = _TA.TASTE_MARK
    except Exception:                                     # noqa: BLE001
        mark = '\u27e8\ub9db\ubcf4\uae30 \uc5ec\uae30\uae4c\uc9c0\u27e9'
    t = text or ''
    if mark not in t:
        return t, False
    return t.split(mark)[0].rstrip(), True


def taste_notice(t=None):
    """맛보기가 끊긴 자리에 적을 한 줄."""
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:                                 # noqa: BLE001
            return d
    return _('PF_TASTE_END',
             '맛보기는 여기까지입니다. 이어서 읽으시려면 이 자료를 받으세요.')


def attach_get_button(txt, kind, key, lang=None, on_get=None, t=None,
                      C=None, index='end'):
    """Text 위젯 **끝에 [지금 받기] 단추만** 심는다 → 심었나(bool).

    ★ 글은 이미 `as_text` 로 들어가 있고 **받는 길만** 그 자리에 낸다 —
      본문 흐름(각주·밑줄 처리)을 건드리지 않으려면 이 갈래가 필요하다.
    ⚠ `on_get` 이 없으면 안 심는다(누르면 아무 일도 없는 단추 금지 §0-1).
    """
    if not on_get:
        return False

    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d

    def col(role, dflt):
        try:
            return C(role) or dflt if C else dflt
        except Exception:
            return dflt

    import tkinter as tk
    was = str(txt.cget('state'))
    if was != 'normal':
        txt.config(state='normal')
    try:
        txt.insert(index, chr(10))
        b = tk.Button(txt, text=_('SET_DL_GET', '지금 받기'), bd=0,
                      padx=12, pady=4, cursor='hand2',
                      bg=col('accent', '#2E86C1'),
                      fg=col('fg_on_dark', '#FFFFFF'),
                      activebackground=col('accent', '#2E86C1'),
                      command=lambda: on_get(kind, key, lang))
        b._packfb = True          # `clear_get_buttons` 가 이것으로 가린다
        txt.window_create(index, window=b)
        txt.insert(index, chr(10))
    finally:
        if was != 'normal':
            txt.config(state=was)
    return True


def into_text(txt, conn, kind, key, lang=None, on_get=None, t=None,
              C=None, where=None, index='end'):
    """**Text 위젯 안에** 폴백을 넣는다 → 상태(`OK` 면 아무것도 안 넣음).

    ★★★ 왜 (2026-09-04 ⑪) — `as_text` 는 글만 낸다. 그러면 사용자가 읽고서
      **설정 화면까지 찾아가야** 하고, 그 사이에 무엇을 받으려 했는지 잊는다.
      ⇒ **받는 길을 읽던 그 자리에 낸다.** Tk 의 `window_create` 가 Text 흐름
        안에 위젯을 심어 주므로 상자를 못 그리는 자리에서도 단추가 선다.
    ⚠ **`on_get` 이 없으면 글만 넣는다** — 누르면 아무 일도 없는 단추를 만들지
      않는다(§0-1). 그때는 「설정 ▸ 다운로드에서」 안내가 그 자리를 맡는다.
    ⚠ **읽기 전용 Text 를 잠시 푼다** — `state='disabled'` 인 채로는 못 넣는다.
    """
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d

    def col(role, dflt):
        try:
            return C(role) or dflt if C else dflt
        except Exception:
            return dflt

    st = state(conn, kind, key, lang)
    if st == OK:
        return st
    import tkinter as tk
    was = str(txt.cget('state'))
    if was != 'normal':
        txt.config(state='normal')
    try:
        body = as_text(conn, kind, key, lang, t=t,
                       where='' if (on_get and st in (MISSING, LANG))
                       else where)
        txt.insert(index, body.rstrip() + '\n')
        if on_get and st in (MISSING, LANG):
            txt.insert(index, '\n')
            b = tk.Button(txt, text=_('SET_DL_GET', '지금 받기'), bd=0,
                          padx=12, pady=4, cursor='hand2',
                          bg=col('accent', '#2E86C1'),
                          fg=col('fg_on_dark', '#FFFFFF'),
                          activebackground=col('accent', '#2E86C1'),
                          command=lambda: on_get(kind, key, lang))
            txt.window_create(index, window=b)
            txt.insert(index, '\n')
    finally:
        if was != 'normal':
            txt.config(state=was)
    return st


def build(parent, conn, kind, key, lang=None, on_get=None, t=None, C=None,
          font_db=None):
    """폴백 화면을 그린다 → `(위젯|None, 상태)`.

    `on_get(kind, key, lang)` — [받기] 를 누르면 부른다. 없으면 단추를 안 만든다.
    ⚠ **상태가 `OK` 면 아무것도 안 그린다**(None 을 돌려준다) — 부르는 쪽이
      본문을 그대로 그린다.
    """
    st = state(conn, kind, key, lang)
    if st == OK:
        return None, st
    import tkinter as tk

    def col(role, dflt):
        try:
            return C(role) or dflt if C else dflt
        except Exception:
            return dflt

    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d

    info = shell(conn, kind, key, lang)
    if not info:
        st = UNKNOWN
    box = tk.Frame(parent, bg=col('panel', '#F4F6F7'), bd=0,
                   highlightthickness=1,
                   highlightbackground=col('border', '#D5D8DC'))
    pad = {'padx': 12, 'anchor': 'w'}
    ttl = tk.Label(box, text=info.get('title') or _('PACKFB_NONAME', '자료'),
                   bg=col('panel', '#F4F6F7'), fg=col('fg', '#000'),
                   anchor='w', justify='left')
    ttl.pack(fill='x', pady=(10, 0), **pad)
    if info.get('sub'):
        tk.Label(box, text=info['sub'], bg=col('panel', '#F4F6F7'),
                 fg=col('fg_dim', '#666'), anchor='w'
                 ).pack(fill='x', **pad)
    # ★ **왜 안 보이는지 먼저 말한다**
    tk.Label(box, text=message(st, info, t), bg=col('panel', '#F4F6F7'),
             fg=col('fg', '#333'), anchor='w', justify='left',
             wraplength=420).pack(fill='x', pady=(6, 0), **pad)
    if info.get('desc'):
        tk.Label(box, text=info['desc'][:400], bg=col('panel', '#F4F6F7'),
                 fg=col('fg_dim', '#666'), anchor='w', justify='left',
                 wraplength=420).pack(fill='x', pady=(6, 0), **pad)
    if on_get and st in (MISSING, LANG):
        tk.Button(box, text=_('SET_DL_GET', '지금 받기'), bd=0, padx=12,
                  pady=5, cursor='hand2',
                  command=lambda: on_get(kind, key, lang)
                  ).pack(anchor='w', padx=12, pady=(10, 12))
    else:
        tk.Frame(box, bg=col('panel', '#F4F6F7'), height=10).pack()
    if font_db:
        try:
            import theme_font
            theme_font.register(ttl, font_db, 'ui', size_delta=1)
        except Exception:
            pass
    return box, st


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t_(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import sqlite3
    # ⚠⚠ **「없는 척」을 만들어 잰다** — 지금은 DB 를 통째로 배포하므로 실 DB
    #   에서는 폴백이 거의 안 걸린다. 그러면 이 코드가 도는지 알 수 없다.
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_book_asset(book_id INTEGER, book_code TEXT, title TEXT,
                                  author TEXT, description TEXT,
                                  body_chars INTEGER);
      CREATE TABLE sys_book_unit(unit_id INTEGER, book_id INTEGER);
      CREATE TABLE sys_book_unit_text(unit_id INTEGER, lang_code TEXT,
                                      body_text TEXT);
      CREATE TABLE bible_version(version_code TEXT, version_name TEXT,
                                 lang_code TEXT);
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT);
      INSERT INTO sys_book_asset VALUES(1,'HAVE','가진 책','저자','소개문',1000);
      INSERT INTO sys_book_asset VALUES(2,'NOPE','안 가진 책','저자2','소개2',2000);
      INSERT INTO sys_book_unit VALUES(10,1),(20,2);
      INSERT INTO sys_book_unit_text VALUES(10,'KO','본문');
      INSERT INTO bible_version VALUES('KRV','개역한글','KO');
      INSERT INTO bible_content VALUES(1,'KRV');
    """)
    c.commit()

    t_('★ 가진 것은 OK', state(c, 'BOOK', 'HAVE') == OK)
    t_('★★ **안 가진 것은 MISSING**', state(c, 'BOOK', 'NOPE') == MISSING,
       state(c, 'BOOK', 'NOPE'))
    t_('★★ **언어만 없으면 LANG**(자산은 있다)',
       state(c, 'BOOK', 'HAVE', 'EN') == LANG,
       state(c, 'BOOK', 'HAVE', 'EN'))
    t_('  그 언어가 있으면 OK', state(c, 'BOOK', 'HAVE', 'KO') == OK)
    t_('  역본도 판정한다', state(c, 'BIBLE', 'KRV') == OK)
    # ⚠ 없는 역본은 **껍데기도 없으니 UNKNOWN** — 「안 받았다」가 아니라
    #   「목록에 없다」다. 코드가 옳고 옛 기대가 낡았다.
    t_('★ 목록에 없는 것은 UNKNOWN(MISSING 이 아니다)',
       state(c, 'BIBLE', 'X') == UNKNOWN, state(c, 'BIBLE', 'X'))
    c.execute("INSERT INTO bible_version VALUES('GONE','안 받은 역본','EN')")
    c.commit()
    t_('★★ **껍데기는 있고 본문만 없으면 MISSING**',
       state(c, 'BIBLE', 'GONE') == MISSING, state(c, 'BIBLE', 'GONE'))
    t_('★ 모르는 갈래는 UNKNOWN(조용히 OK 라 하지 않는다)',
       state(c, 'ZZZ', 'x') == UNKNOWN)

    sh = shell(c, 'BOOK', 'NOPE')
    t_('★★★ **본문이 없어도 껍데기는 있다**',
       sh.get('title') == '안 가진 책' and sh.get('desc') == '소개2', str(sh)[:60])
    t_('  껍데기가 없으면 빈 dict', shell(c, 'BOOK', 'GHOST') == {})

    t_('★ 상황마다 말이 다르다',
       len({message(MISSING), message(LANG), message(UNKNOWN)}) == 3)
    t_('  OK 면 말이 없다', message(OK) == '')

    # 화면 — 실제로 그려 본다
    try:
        import tkinter as tk
        r = tk.Tk()
        r.withdraw()
        w_ok, s_ok = build(r, c, 'BOOK', 'HAVE', 'KO')
        t_('★★ **있으면 아무것도 안 그린다**', w_ok is None and s_ok == OK)
        got = []
        w, s = build(r, c, 'BOOK', 'NOPE', on_get=lambda *a: got.append(a))
        t_('★ 없으면 상자를 그린다', w is not None and s == MISSING)
        texts = [x.cget('text') for x in w.winfo_children()
                 if hasattr(x, 'cget') and 'text' in x.keys()]
        t_('  제목·소개·안내가 다 있다',
           any('안 가진 책' in x for x in texts)
           and any('소개2' in x for x in texts)
           and any('받지 않았습니다' in x for x in texts), str(texts)[:70])
        btn = [x for x in w.winfo_children() if isinstance(x, tk.Button)]
        t_('★★ **받는 길이 그 자리에 있다**', len(btn) == 1)
        if btn:
            btn[0].invoke()
        t_('  누르면 무엇을 받을지 알려 준다',
           got == [('BOOK', 'NOPE', None)], str(got))
        w2, s2 = build(r, c, 'BOOK', 'GHOST')
        t_('★ 껍데기도 없으면 「목록 갱신」이라 말한다', s2 == UNKNOWN, s2)
        w3, _s3 = build(r, c, 'BOOK', 'NOPE')
        # ★★★ **맛보기 표식**(2026-09-25 · 1.txt 16-3 ⑤) — 양방향.
        #   글이 그냥 끊기면 사용자는 **글이 그렇게 끝난 줄** 안다(§0-1).
        _mk = None
        try:
            import db_pack_taste as _TA
            _mk = _TA.TASTE_MARK
        except Exception:
            pass
        if _mk:
            _b, _c = taste_split('본문입니다.' + chr(10) + chr(10) + _mk)
            t_('★★★ 맛보기 표식을 못 알아본다', _c)
            t_('  표식이 본문에 남는다', _mk not in _b, _b)
            t_('  본문까지 지운다', _b.strip() == '본문입니다.', _b)
        _b2, _c2 = taste_split('그냥 본문입니다.')
        t_('  표식이 없는데 잘렸다고 한다', not _c2)
        t_('  표식 없는 글을 건드린다', _b2 == '그냥 본문입니다.')
        t_('  빈 글에서 터진다', taste_split(None) == ('', False))
        t_('  안내 글이 비었다', len(taste_notice()) > 10)
        t_('  콜백이 없으면 단추를 안 만든다',
           not [x for x in w3.winfo_children() if isinstance(x, tk.Button)])
        r.destroy()
    except Exception as e:                              # noqa: BLE001
        t_('화면 시험이 돈다', False, str(e)[:60])
    c.close()
    print('pack_fallback selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
