import re
import i18n
import media_taxonomy as _tax
import sqlite3
import appdb
import tkinter as tk
import webbrowser
from tkinter import ttk

# ★★ **인라인 재생을 걷었다** (2026-09-09 사용자 「P2 탭에서 영상을 재생하는
#   것은 **좁아서 제거했다. 아직 코드가 남아있다면 제거해야 한다**」).
#   2026-08-15 에 화면에서는 걷혔는데 `media_player` import·`_embed_player`·
#   `_embed_play`·`_on_destroy_cleanup` 이 죽은 채 남아 있었다 — 전부 없앴다.
#   ⇒ 영상은 **유튜브** 또는 **P4 온라인 영상 탭** 둘 중 하나로 연다(콤보).

import media_list_view as mlv   # 미디어 목록 표준 표시(언어/형태/제목/채널/★)
import media_link               # 영상 연결 단일 소스(통합 표 이름·link_type)
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 아6:1~6:14 가 13,488절을 먹는다.
import verse_range as _vr

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)



def _yt_id(url: str):
    """YouTube URL → video_id (아니면 None)."""
    if not url or ('youtube.com' not in url and 'youtu.be' not in url):
        return None
    m = re.search(r'(?:v=|youtu\.be/|embed/|/v/|shorts/)([\w-]{11})', url)
    return m.group(1) if m else None

MEDIA_TYPE_LABEL = {
    'SERMON':       '설교/강해',
    'WORSHIP':      '찬양',
    'FILM':         '영화/애니메이션',
    'SERVICE':      '집회영상',
    'TEXT_SERMON':  '설교문',
    'TEXT_ARTICLE': '아티클',
    'AUDIO_SERMON': '음성 설교',
    'PDF_DOC':      'PDF 자료',
    'WIKI_SUMMARY': '위키 요약',
    'COMMENTARY':   '주석',
    'INFOGRAPHIC':  '인포그래픽',
    'MAP':          '지도',
    'TRAVEL':       '여행',
    'ART':          '예술작품',
    'LEXICON':      '원어사전',
    'INTERLINEAR':  '원문대조',
}

# B형 (URL 패턴형) 참조 사이트 표시용
# ⚠ 이 목록 하나가 단일 소스다. 예전에 조회 쿼리 3갈래 + 설정 팝업까지
#    네 곳에 같은 IN 절이 흩어져 있어 한 곳만 고치는 사고가 났다(2026-08-03).
# ★ 2026-08-26 2안(사용자 승인) — 주석 탭 [링크]가 갖고 있던 주석·원문대조·
#   사전 사이트를 **텍스트링크 갈래로 통합**. mode='TEXT' 가 아래 확장 목록을,
#   구모드('ALL')는 옛 둘(SERMON·WEB)만 쓴다.
REF_SITE_ORDER       = ['SERMON', 'WEB']
# ⚠⚠ **`mode='CLINK'` 은 2026-09-12 부터 부르는 곳이 없다**(옛 「주석링크」
#   갈래). 그 갈래가 보이던 셋이 저마다 제자리를 찾아갔다:
#     · 주석 사이트  → `commentary_panel` 의 **외부 링크 콤보**
#     · 원문대조     → **역본비교 탭 상단**(`version_compare_view`)
#     · 원어사전     → 구분을 걷었다(Mechon Mamre 내림 · Sefaria 는 주석으로)
#   ⚠ 코드는 남긴다 — 되돌릴 자리이고, 지우면 `_build_ui_clink` 가 쓰는
#     `_load_ref_sites` 를 TEXT 모드와 함께 손봐야 한다(위험이 값보다 크다).
REF_SITE_ORDER_TEXT  = ['SERMON', 'WEB']
REF_SITE_ORDER_CLINK = ['COMMENTARY', 'INTERLINEAR', 'LEXICON']
_REF_SITE_IN    = "('" + "','".join(REF_SITE_ORDER) + "')"
REF_SITE_LABEL  = {
    'COMMENTARY':  '주석',
    'INTERLINEAR': '원문 대조',
    'LEXICON':     '원어 사전',
    'SERMON':      '설교/강해',
    'WEB':         '웹',
}
REF_SITE_COLOR  = {
    'COMMENTARY':  '#AED6F1',   # 파스텔 블루 (주석 탭 [링크]의 색 그대로)
    'INTERLINEAR': '#A9DFBF',   # 파스텔 그린
    'LEXICON':     '#D7BDE2',   # 파스텔 퍼플
    'SERMON':      '#FAD7A0',   # 파스텔 오렌지
    'WEB':         '#D5DBDB',   # 파스텔 그레이
}
REF_SITE_TEXT_COLOR = {
    'COMMENTARY':  '#1A5276',
    'INTERLINEAR': '#1a7a4a',
    'LEXICON':     '#6c3483',
    'SERMON':      '#7e5109',
    'WEB':         '#4a4a4a',
}


def _is_text_row(media_id, media_type, format_type):
    """목록 한 줄이 「읽는 자료」인가 — 영상/텍스트 갈래를 가르는 단일 기준.

    RSS 수집 텍스트(media_id<0)·TEXT_* 유형·TEXT 형태 = 텍스트.
    나머지(영상·음성·찬양·집회영상 등 재생물) = 영상 갈래.
    ⚠ 내 링크 행은 media_id 가 ('U', uid) 튜플이다 — 수 비교 전에 거른다."""
    if isinstance(media_id, int) and media_id < 0:
        return True
    mt = (media_type or '').upper()
    ft = (format_type or '').upper()
    return (mt.startswith('TEXT_')
            or mt in ('PDF_DOC', 'WIKI_SUMMARY', 'COMMENTARY', 'INFOGRAPHIC')
            or ft == 'TEXT')
REF_HDR_COLOR  = '#F4F6F7'   # 참조 사이트 섹션 배경


def _C(role, fb):
    """역할색 — ui_theme 팔레트에서 읽고 없으면 폴백(§36 하드코딩 금지)."""
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb


def _hover_in(e):
    """마우스가 얹히면 **지금 색**을 적어 두고 살짝 어둡게."""
    w = e.widget
    try:
        w._hover_bg = str(w.cget('bg'))
        w.config(bg=_darken(w._hover_bg, 0.88))
    except Exception:
        pass


def _hover_out(e):
    w = e.widget
    c = getattr(w, '_hover_bg', None)
    if c:
        try:
            w.config(bg=c)
        except Exception:
            pass


def _darken(hex_color: str, factor: float = 0.75) -> str:
    h = hex_color.lstrip('#')
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return '#{:02x}{:02x}{:02x}'.format(
        int(r * factor), int(g * factor), int(b * factor))

FORMAT_ICON = {
    'VIDEO': '',
    'AUDIO': '',
    'TEXT':  '',
    'IMAGE': '',
}


#: ★★ **영상 유형 갈래** (2026-09-09 0.txt 1-4 사용자 지시 「상단에 필터링
#:   옵션 … 라디오 버튼 : 전체 / 설교강해 / 찬양 / 수화」 + 「FILM 도 적더라도
#:   표시할 의미는 있다」).
#: ⚠⚠ **「형태」(`format_type`)로는 못 가른다** — 실측 찬양 47편 중 VIDEO 46 ·
#:   전체로도 VIDEO 99%. 가르는 축은 **내용**(`media_type`)이다.
#: ⚠⚠ **설교와 강해는 안 가른다** — 실측으로 못 가른다: 「강해」 낱말이 든 것이
#:   설교 7,905편 중 **170편(2%)** 이고 67%는 아무 신호가 없다. 「한 채널이 한
#:   책의 여러 장을 이어서」라는 구조 신호(34%)로 잡아 보니 그 900편 중 「강해」
#:   는 **1편(0%)** 이고 실제 내용은 **큐티·묵상**이었다.
#: ⚠ **수화는 축이 다르다**(내용이 아니라 **대상**) — 한 줄에 섞되 그 사실을
#:   알고 쓴다. 지금 수화에 찬양이 0편이라 「수화 찬양」을 못 고르는 손해가 없다.
#: ⚠⚠ **수화를 뺐다** (2026-09-10 0.txt 1-2 사용자 목록 — 「전체/설교강해/
#:   성경공부/찬양/영화애니」). 수화는 **대상 축**이라 이 줄에 섞여 있었고,
#:   2번에서 **P4 특수기능**으로 자리를 옮기기로 했다. 뺀다고 안 보이지는
#:   않는다 — 「전체」에는 그대로 든다(실측 33편).
#: ★★★ **이름은 `media_type` 다섯 값 그대로 · 열쇠는 어린이 화면과 같은 `KV_KIND_*`**
#:   (2026-09-16 1.txt 19-3 사용자 「분류이름을 통일하라. 데이터 구조와 일치시키고
#:   성경듣기를 포함하라」). 그전에는 여기가 `LP_K_*`(영상물) · 어린이 화면이
#:   `KV_KIND_*`(영화애니) · 목록 칸이 `media_taxonomy.CONTENT_LABEL`(영상·강해)로
#:   **같은 값을 세 이름으로** 불렀고 성경듣기(READING)는 어디에도 없었다.
#:   ⇒ 이름표는 `media_taxonomy.content_label()` 한 문 — 세 자리가 그것을 쓴다.
#: ★★★ **갈래 목록은 `media_taxonomy.USER_KINDS` 한 표에서 온다**(2026-09-17
#:   사용자 「모든 것을 P4 상단 라디오 버튼으로 통일하라」). 여기에 다시 적지
#:   않는다 — 두 곳에 적으면 화면마다 이름과 갈래가 갈린다(§241차 ① 그 자리).
#:   `audience` 갈래(어린이·수화)도 함께 온다 — `_kind_ok` 가 그것도 본다.
LINK_KINDS = tuple((c, ik, ko, tuple(tys) or None)
                   for c, ik, ko, tys, _aud in _tax.USER_KINDS)
#: 코드 → audience (어린이·수화)
_KIND_AUD = {c: aud for c, _i, _k, _t, aud in _tax.USER_KINDS if aud}

#: 열기 방식 — 「목록을 누르면 어디서 열까」
#: ★★ **값을 짧게 두고 라벨이 뜻을 준다**(2026-09-10 사용자 「Play : In / Out
#:   처럼 흔하지 않지만 심플하게」). 라디오 둘은 요구폭이 **260px**(KO)·
#:   **311px**(RU)라 420px 패널에서 두 줄로 접혔다.
#: ★★★ **라벨은 「YouTube play」**(2026-09-10 0.txt 1번 사용자 —
#:   「마치 유투브 컨텐츠가 아닌 것처럼 오해 소지가 있다」). 콤보 값만 보면
#:   무엇을 트는지 알 수 없어서 라벨이 그것을 말한다.
#: ★★ 값은 **내부 / 팝업** — 「어디서 트나」다.
#:   `내부` = P4 「온라인 영상」 탭 · `팝업` = **유튜브 브라우저**
#:   (2026-09-10 사용자 — 「내가 말한 팝업은 유투브 브라우저다. 말이 길어서
#:   팝업이라고 했다」). 브라우저 창이 곧 팝업이다.
#:   ⚠ 유튜브가 아닌 주소는 **어느 쪽이든 브라우저**다 — P4 플레이어가
#:     못 연다. 조용히 아무 일도 안 하지 않는다.
#: ★★★ **2026-09-17 — 갈래가 셋이 되고 집이 `video_open` 으로 옮겨졌다**
#:   (사용자 「1)임베드 재생 2)스크롤 재생 3)브라우저로 실행 … 한번 저장하면 매번」).
#:   여기서 목록을 다시 적지 않는다 — 두 곳에 적으면 갈라진다.
import video_open as VO
OPEN_MODES = VO.MODES


class LinksPanel(tk.Frame):
    """구절 클릭 시 연결된 외부 링크를 표시하는 패널.

    load(verse_id) 호출로 갱신. P2 대시보드와 P4 연관대시보드가 각각 독립 인스턴스로 사용.
    """

    _hidden_site_ids: set = set()   # 클래스 공유 — 모든 인스턴스가 동일 설정 사용

    def __init__(self, parent, db_path, lang_getter=None,
                 on_video_open=None, mode='ALL', ext_bar=None, **kw):
        # on_video_open(video_id, title) — 주면 좁은 이 자리 대신 P4 자료 탭에서 재생한다.
        # mode (2026-08-26 2안) — 'VIDEO' 재생물만(참조 사이트 없음) /
        #   'TEXT' 읽는 자료 + 참조 사이트(설교/강해·웹·주석·원문대조·사전) /
        #   'ALL' 옛 동작(호환 — 기존 호출부 보호).
        # ext_bar (2026-09-16 · 1.txt 19-1) — 주면 **언어 콤보를 그 줄의 자식**으로
        #   만들되 pack 하지 않는다. 호스트(P2 갈래 줄)가 `lang_widget()` 로 받아
        #   지금 갈래일 때만 보인다. 없으면 종전대로 제 머리 줄 오른쪽 끝.
        super().__init__(parent, bg='white', **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._on_video_open = on_video_open
        self._mode = (mode or 'ALL').upper()
        self._ext_bar = ext_bar
        self._verse_id = None
        self._items = {}          # treeview iid → media_id
        self._rowmap = {}         # treeview iid → 원본 줄(층 정보)
        # ★ **언어 콤보 하나** (2026-09-09 0.txt 1-2 사용자 지시 「언어콤보 하나
        #   배치 : 전체언어, EN, KO,,,, **초기값은 사용자가 설정한 언어로**」).
        #   ⚠ 옛 라디오 둘([전체언어][내 언어])은 기본이 **전체언어**였다 —
        #     이제 기본이 **내 언어**다(배지도 그 기준이 된다, 1-3).
        self._lang_sel = None          # LangCombo — _build 에서 만든다
        self._build_ui()

    def _ref_order(self):
        if self._mode == 'CLINK':
            return REF_SITE_ORDER_CLINK
        return REF_SITE_ORDER_TEXT if self._mode == 'TEXT' else REF_SITE_ORDER

    def _ref_in(self):
        return "('" + "','".join(self._ref_order()) + "')"

    # ------------------------------------------------------------------ UI 구성
    def _build_ui_clink(self):
        """주석링크 갈래 (2026-09-03 0.txt 3번) — 구절 축 사이트 버튼만.

        목록이 필요 없다(사용자 확정 「이 화면에서는 별도의 목록 화면이
        필요 없다」) — 트리·링크추가·숨기기·언어 라디오를 만들지 않는다."""
        hdr = tk.Frame(self, bg='#EBF5FB', height=28)
        hdr.pack(fill='x', side='top')
        hdr.pack_propagate(False)
        tk.Button(hdr, text=i18n.t('LP_SITE_CFG', '표시대상 설정'),
                  command=self._open_settings, **_flat()).pack(
            side='left', padx=(6, 0), pady=2)
        self._tree = None
        self._ref_frame = tk.Frame(self, bg=REF_HDR_COLOR)
        self._ref_frame.pack(fill='both', expand=True, side='top')

    def _build_ui(self):
        if self._mode == 'CLINK':
            self._build_ui_clink()
            return
        # 헤더 바
        hdr = tk.Frame(self, bg='#EBF5FB', height=28)
        hdr.pack(fill='x', side='top')
        hdr.pack_propagate(False)

        # 설정 아이콘 버튼 (톱니바퀴)
        # ★ **글자 단추로** (2026-08-30 사용자 지시 0.txt 2)P2 「참조사이트
        #   표시설정 버튼 : "표시대상 설정"이라고 버튼으로 표시하자」).
        #   ⚠ `⚙`(U+2699)는 **맑은 고딕에 없어** Segoe 로 폴백해 그리고 있었다
        #     (§29 글리프 규칙) — 글자로 바꾸면 그 문제도 함께 사라진다.
        #   ⚠⚠ **텍스트링크에서만 보인다** (2026-08-30 사용자 지시 「표시대상설정
        #     버튼 : **텍스트 링크에서만 표시**하면 됨」). 이 단추가 고르는 것은
        #     **참조 사이트 목록**인데, 그 목록은 `_mode != 'VIDEO'` 일 때만
        #     그려진다(아래 `_refresh`). 영상 갈래에서는 **눌러도 아무것도
        #     안 달라지는 스위치**였다(§0-1 가짜 기능 금지).
        gear_btn = tk.Button(hdr, text=i18n.t('LP_SITE_CFG', '표시대상 설정'),
                             bg='#EBF5FB', relief='flat',
                             font=('Malgun Gothic', 8), fg='#555',
                             cursor='hand2', bd=0, padx=6,
                             activebackground='#D4E6F1',
                             command=self._open_settings)
        # ⚠⚠ **걷었다**(2026-09-17 · 1.txt 2 사용자 「표시대상설정 : 제거하자.
        #   대상 사이트가 많지 않다」) — 실측 텍스트 갈래가 그릴 수 있는 참조
        #   사이트는 **한 곳뿐**(Enduring Word)이라 고를 것이 없었다.
        #   위젯은 남긴다(되돌릴 자리) — 그리지만 않는다.
        self._gear_btn = gear_btn

        # ★ 내 링크 (2026-08-27 — 덮개 C 단계). 서핑하다 만난 것을 이 구절에
        #   붙인다 — 용어(MY 창)에만 있던 길을 구절에도 연다. 버튼은 상단(§0).
        # ★★ **[+ 내 링크] → [My Edit]** (2026-08-30 사용자 지시 — P2 다섯 자리
        #   통합. 0.txt 2)P2 「영상링크, 텍스트 링크 탭 내부의 +내링크, 내링크
        #   빼기 버튼을 제거하고 My Edit버튼을 배치해야 하는가?」).
        #   ⇒ **가르는 규칙대로**(사용자 동의한 기준): 「새로 만들어 잇는 일」은
        #     My Edit 으로, 「지금 고른 것 하나를 끄는 일」은 제자리에 남긴다.
        #     그래서 **[+ 내 링크]만** 통합하고 **[내 링크 빼기]는 남긴다** —
        #     한 줄을 고른 채 그 자리에서 빼는 것이 자연스럽고, 팝업까지 열게
        #     하면 오히려 멀어진다.
        self._my_add_btn = tk.Button(
            hdr, text=i18n.t('LP_ADD_LINK', '링크추가'),
            command=self._add_my_link, **_flat())
        # ★ **영상링크 갈래에서는 안 단다** (2026-09-03 0.txt 2번 — 「아직
        #   열어보지도 않고 숨기기 하는 것이 맞지 않다. 클릭하고 P4 화면에서
        #   조치하는 것이 맞다」). 추가·숨기기는 P4 온라인 영상 탭의 몫.
        # ⚠⚠ **[링크추가]·[링크 숨기기]를 [My Edit] 하나로**(1.txt 2 사용자
        #   「My Edit 버튼을 배치하면 해결되는 것 아닌가?」) — 그 창이 붙이기와
        #   가리기를 **한 자리에서** 한다. 둘을 따로 두면 입구가 셋이 된다.
        if self._mode == 'CLINK':
            self._my_add_btn.pack(side='left', padx=(8, 0), pady=2)
        elif self._mode == 'TEXT' and self._ext_bar is None:
            # ★★ **밖의 줄(1단)을 받았으면 여기서 안 그린다**(2026-09-17 사용자
            #   ⑥ 「텍스트 탭에서만 My Edit 버튼이 표시된다 … 1단에 항상배치
            #   하면 다른 곳에 따로 배치할 필요가 없을 것 같다」).
            #   ⇒ 밖의 줄을 준 화면은 그 줄이 맡고, 밖의 줄이 없는 자리
            #     (NodePanel 텍스트 갈래)에서만 제 줄에 남는다.
            #   ★ `RefUnifiedPanel` 이 쓰는 규칙과 **같다** — 두 패널이 서로
            #     다른 규칙을 쓰면 어디에 단추가 있는지 아무도 못 외운다.
            self._me_btn = tk.Button(
                hdr, text=i18n.t('OE_BTN', 'My Edit'),
                command=self._add_my_link, **_flat())
            self._me_btn.pack(side='left', padx=(6, 0), pady=2)
        # ★★★ **[유튜브에서 열기]** (2026-09-04 사용자 지시 — 「사용자가
        #   유투브를 조회하는 화면에서 **설명문을 볼 수가 없다. 영상화면만
        #   보이기 때문이다**」).
        #   ⚠⚠ **「설명문만 보여 주는」 방법은 없다** — ⓐ API 로 그때 받으려면
        #     사용자 앱에 키를 넣어야 하고 유출된다(쿼터도 사용자 수만큼)
        #     ⓑ 페이지에서 설명만 긁는 것은 약관 위반 소지에 구조가 바뀌면
        #     깨진다. ⇒ **유튜브 페이지를 그대로 연다** — 설명·댓글이 다
        #     보이고 **우리는 한 글자도 저장하지 않는다.**
        #   ★ 그래서 이름이 「설명 보기」가 아니라 **「유튜브에서 열기」**다 —
        #     설명만 나올 줄 알고 눌렀다가 페이지 전체가 열리면 거짓말이 된다.
        #   ⚠ 지금까지 **유튜브 영상은 브라우저로 여는 길이 아예 없었다**
        #     (비-유튜브만 `webbrowser.open` 으로 샜다).
        # ★★ **라디오 둘 — 목록을 누르면 어디서 열까** (2026-09-09 0.txt 1-2).
        #   ⚠ 옛 [유튜브에서 열기] 단추는 「고른 줄을 연다」라 **두 번 누르는**
        #     일이었다. 이제 **한 번 누르면 고른 방식대로** 열린다.
        #   ★ 직전값을 기억한다 — 사람마다 늘 같은 쪽을 쓴다.
        # ★★★ **라디오 → 콤보 둘 · 한 줄** (2026-09-10 0.txt 1번 사용자 지시
        #   「글자가 너무 길고 라디오 버튼이 너무 많아서 복잡하다 · 라디오버튼
        #   2가지를 제거하고 **콤보상자로 대체**한다」).
        #   실측 — 라디오 8개 요구폭 **635px** / 패널 **420px**.
        self._open_mode = tk.StringVar(value=self._load_open_mode())
        # ★★ **영상 갈래에서만 보인다** (2026-09-17 사용자 「텍스트 링크 : 유투브
        #   플레이 옵션이 어떤 것으로 정하든 **무조건 외부 링크로 나가는 것**이다」).
        #   텍스트 링크는 앱 안에서 열 길이 없으므로 고를 것이 없다 — 두면 거짓말이다.
        self._open_cb = None
        if self._mode == 'VIDEO':
            tk.Label(hdr, text=i18n.t('LP_PLAY_LBL', 'YouTube play'),
                     bg=_C('accent_bg', '#EBF5FB'),
                     fg=_C('fg_dim', '#5D6D7E')).pack(side='left', padx=(4, 2))
            self._open_cb = self._mk_combo(hdr, OPEN_MODES, self._open_mode,
                                           self._save_open_mode)
        # ⚠⚠ **[링크 숨기기] 단추를 걷었다** (2026-08-30 사용자 지시 「**묵상
        #   노트에 X표가 붙어 있는 것처럼** 링크자산 P2 화면에서 x 와 같은
        #   기능을 수행하도록 만들어야 한다」).
        #   ⇒ 가리기는 **줄의 ✕ 칸**이 한다 — 묵상노트 카드와 같은 문법이고,
        #     ★(즐겨찾기) 칸이 이미 그 방식이라 손이 배울 것이 없다.
        #   ★ 단추를 남기면 **같은 일에 입구가 둘**이고, 게다가 텍스트링크는
        #     줄을 고르는 순간 브라우저가 열려 고르는 것 자체가 방해였다.
        # ★★★ **[링크 숨기기] → 왼쪽 체크 칸 → [숨기기 확인]** (2026-08-30
        #   사용자 지시). 두 단계로 나눈 까닭이 곧 지시의 요지다 —
        #   **누르는 즉시 실행되면 실수하기 좋다.**
        self._pick_on = False
        self._picked = set()
        self._my_del_btn = tk.Button(
            hdr, text=i18n.t('LP_MY_DEL', '링크 숨기기'),
            command=self._toggle_pick_mode, **_flat())
        if self._mode == 'CLINK':
            self._my_del_btn.pack(side='left', padx=(4, 0), pady=2)
        self._ok_btn = tk.Button(
            hdr, text=i18n.t('LP_HIDE_OK', '숨기기 확인'),
            command=self._apply_hide, **_flat())
        self._cancel_btn = tk.Button(
            hdr, text=i18n.t('COMMON_CANCEL', '취소'),
            command=lambda: self._toggle_pick_mode(False), **_flat())
        self._tree_sel_bound = False

        # ★ 언어 콤보 하나 — 단일 소스(`lang_combo`). 「전체언어」가 맨 앞이고
        #   **처음 값은 환경설정 언어**다(0.txt 1-2).
        # ★★ 유형 갈래 라디오 — **둘째 줄**(P2 는 420px 라 한 줄에 못 넣는다).
        #   영상 갈래에서만 보인다(텍스트링크·주석링크에는 뜻이 없다).
        # ★★ **유형도 콤보로 — 둘째 줄(26px)이 통째로 없어졌다.**
        #   ⚠ 영상 갈래에서만 만든다(텍스트링크·주석링크에는 뜻이 없다).
        self._kind = tk.StringVar(value=self._load_kind())
        self._kind_cb = None
        if self._mode == 'VIDEO':
            self._kind_cb = self._mk_combo(
                hdr, [(c, k, d) for c, k, d, _t in LINK_KINDS],
                self._kind, self._on_kind)
        import lang_combo
        self._lang_sel = lang_combo.LangCombo(
            (self._ext_bar if self._ext_bar is not None else hdr),
            db_path=self.db_path, on_change=lambda *_: self._refresh(),
            side='right', width=13, key='LANGSEL_LINKS_%s' % (self._mode or 'ALL'),
            default_lang=(self.lang_getter() or 'KO'))
        self._lang_sel.set_items(lang_combo.lang_items(with_all=True))
        if self._ext_bar is not None:
            self._lang_sel.combo.pack_forget()     # 호스트가 갈래에 맞춰 편다

        # ★ **오른쪽 인라인 플레이어를 없앴다 (2026-08-15 사용자 지시).**
        #   이 화면에서만 작동하지 않았고(어린이 탭의 같은 플레이어는 정상),
        #   영상은 P4 「온라인 영상」 탭 한 곳으로 모은다. 목록이 폭을 다 쓴다.
        #   ★ **남아 있던 죽은 코드를 걷었다** (2026-09-09 사용자 「P2 탭에서
        #     영상을 재생하는 것은 좁아서 제거했다. **아직 코드가 남아있다면
        #     제거해야 한다**」). `media_player` import · `_embed_player` ·
        #     `_embed_play` · `_on_destroy_cleanup` 전부 없앴다.
        left = self

        # ── B형 참조 사이트 섹션
        # ★ **아래에서 위로 옮겼다 (2026-08-15 사용자 지시).**
        #   목록 밑에 깔려 있어 잘 보이지 않았다. 여러 개가 한 줄로 늘어선다(§0 버튼은 상단).
        # ⚠ VIDEO 갈래에는 참조 사이트가 없다(전부 읽는 자료라 텍스트링크 몫)
        # ⚠⚠ **띠를 안 그린다**(1.txt 2 「2개의 bar를 모두 제거하라」) —
        #   그 자리에 있던 줄은 **목록 안으로** 들어간다(`_site_rows`).
        #   위젯은 남긴다 — `CLINK` 갈래가 아직 쓴다(`_build_ui_clink`).
        self._ref_frame = tk.Frame(left, bg=REF_HDR_COLOR)

        # Treeview — 평면 목록(그룹헤더 없음), 깔끔한 유형·제목 표시
        tree_f = tk.Frame(left, bg='white')
        tree_f.pack(fill='both', expand=True)

        # 표준 5컬럼(언어/형태/제목/채널/★) — entity_browser Links 와 동일 모양
        self._tree = mlv.build_tree(tree_f, style_name='Links.Treeview')

        vsb = ttk.Scrollbar(tree_f, orient='vertical', command=self._tree.yview)
        self._tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._tree.pack(side='left', fill='both', expand=True)

        self._tree.bind('<ButtonRelease-1>',        self._on_click)
        self._tree.bind('<Double-ButtonRelease-1>', self._on_double_click)
        self._tree.bind('<<TreeviewSelect>>', lambda e: self._sync_my_btns(),
                        add='+')

    # ── 내 링크 (2026-08-27) ────────────────────────────────────────────
    def _sync_my_btns(self):
        """[내 링크 빼기]는 **내 줄을 골랐을 때만** 산다."""
        try:
            # ⚠ **잠그지 않는다** (2026-08-30) — 고른 줄이 없어도 팝업에서
            #   고를 수 있다. 회색으로 두면 「기능이 없다」로 읽힌다.
            pass
        except Exception:
            pass

    def _add_my_link(self):
        if not self._verse_id:
            return
        # ★★ **통합 연결팝업으로** — 구절이 출발지, 재고창고에서 「외부연결」
        #   갈래가 눌린 채. 거기서 URL 을 만들어 곧바로 잇는다.
        #   ⚠ 옛 전용 창은 **폴백으로 남긴다**(팝업이 안 뜨면 조용히 아무 일도
        #     안 하는 것보다 낫다).
        try:
            # ★★★ **P4 와 같은 창으로** (2026-08-30 사용자 지시 「모든 연결팝업
            #   화면을 P4 팝업화면으로 통일하라」) — 휴지통·크기 조절·크기 기억이
            #   함께 온다. 그전에는 여기만 맨 팝업이었다.
            # ★ 갈래 이름을 **이 탭 이름 그대로** 바꿔 단다 (사용자 지시
            #   「"외부연결"이라는 단어가 있다. 사용자는 알 수 없다」).
            import my_edit
            _nm = (i18n.t('LP_BR_VIDEO', '영상링크') if self._mode != 'TEXT'
                   else i18n.t('LP_BR_TEXT', '텍스트링크'))
            my_edit.open(self, 'VERSE', self._verse_id,
                         on_changed=lambda *_a: self._refresh(),
                         pick_kind='MEDIA', pick_label='＋ ' + _nm,
                         auto_create=True)
            return
        except Exception as e:
            print('[links my edit] %s' % e)
        win = tk.Toplevel(self)
        win.title(i18n.t('LP_MY_ADD_TITLE', '이 구절에 내 링크 붙이기'))
        win.transient(self.winfo_toplevel())
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        frm = tk.Frame(win)
        frm.pack(fill='both', expand=True, padx=10, pady=8)
        tk.Label(frm, text=i18n.t('LP_MY_URL', '주소(URL)'), anchor='w'
                 ).grid(row=0, column=0, sticky='w', pady=2)
        e_url = tk.Entry(frm, width=52)
        e_url.grid(row=0, column=1, sticky='ew', pady=2)
        tk.Label(frm, text=i18n.t('LP_MY_TITLE2', '제목'), anchor='w'
                 ).grid(row=1, column=0, sticky='w', pady=2)
        e_ttl = tk.Entry(frm, width=52)
        e_ttl.grid(row=1, column=1, sticky='ew', pady=2)
        frm.columnconfigure(1, weight=1)
        msg = tk.Label(frm, text='', anchor='w')
        msg.grid(row=3, column=0, columnspan=2, sticky='w')

        def save():
            url = e_url.get().strip()
            if not url:
                msg.config(text=i18n.t('LP_MY_NEEDURL', '주소를 넣어 주세요.'))
                return
            try:
                with appdb.connect(self.db_path) as conn:
                    uid, how = media_link.add_user_verse_media(
                        conn, self._verse_id, e_ttl.get(), url)
                if how == 'DUP':
                    msg.config(text=i18n.t('LP_MY_DUP',
                                           '이미 이 구절에 붙어 있는 주소입니다.'))
                    return
                win.destroy()
                self._refresh()
                if callable(getattr(self, 'on_changed', None)):
                    self.on_changed()
            except Exception as e2:
                print(f'LinksPanel._add_my_link: {e2}')

        # 버튼은 상단(§0) — 입력 칸 위 헤더 줄
        btn = tk.Frame(frm)
        btn.grid(row=2, column=0, columnspan=2, sticky='e', pady=(6, 0))
        tk.Button(btn, text=i18n.t('BTN_SAVE', '저장'), bd=1, padx=10,
                  command=save).pack(side='left', padx=(0, 4))
        tk.Button(btn, text=i18n.t('BTN_CANCEL', '취소'), bd=1, padx=10,
                  command=win.destroy).pack(side='left')
        e_url.focus_set()
        win.bind('<Return>', lambda e: save())

    # ── 고르기 모드 (2026-08-30) ──────────────────────────────────────
    def _toggle_pick_mode(self, on=None):
        """[링크 숨기기] — 왼쪽 선택하기 칸을 펴고 접는다.

        ⚠ 접을 때 **고른 것을 비운다** — 남겨 두면 다음에 열었을 때 이미
          체크된 채라 「나도 모르게 숨겼다」가 난다."""
        self._pick_on = (not self._pick_on) if on is None else bool(on)
        mlv.set_pick_col(self._tree, self._pick_on)
        if self._pick_on:
            self._ok_btn.pack(side='left', padx=(4, 0), pady=2)
            self._cancel_btn.pack(side='left', padx=(2, 0), pady=2)
        else:
            self._picked.clear()
            self._ok_btn.pack_forget()
            self._cancel_btn.pack_forget()
        self._refresh()

    def _toggle_pick(self, iid):
        """줄 하나를 골랐다 풀었다."""
        if iid in self._picked:
            self._picked.discard(iid)
            mark = mlv.PICK_OFF
        else:
            self._picked.add(iid)
            mark = mlv.PICK_ON
        try:
            vals = list(self._tree.item(iid, 'values'))
            vals[0] = mark
            self._tree.item(iid, values=vals)
        except Exception:
            pass

    def _apply_hide(self):
        """[숨기기 확인] — **이때 비로소** 실제로 가린다.

        ★★★ **연결팝업과 같은 범위로 가린다** (2026-08-30 사용자 지적 「사용자가
          P2 화면에서 링크숨기기 버튼 누르고 진행하는데 **그 자리에서 체크하고
          숨긴다. 따라서, 구절만 숨기는 것인지 경고가 없다**」).
          ⚠⚠ 실측 — 그전에는 `user_media_hide` 에 넣어 **그 영상이 걸린 모든
            절·단락·용어(최대 17곳)** 에서 지웠고 **주요용어 화면까지** 사라졌다.
            연결팝업의 [이 연결만 숨기기]보다 **훨씬 넓은데 경고가 없었다.**
          ⇒ `link_picker.veto` 로 **층을 골라** 가린다.
        ⚠ 고른 것이 없으면 아무 일도 안 하고 **왜 안 되는지 말한다**(§0-1).
        """
        from tkinter import messagebox
        import link_picker as _lp
        if not self._picked:
            messagebox.showinfo(
                i18n.t('LP_MY_DEL', '링크 숨기기'),
                i18n.t('LP_PICK_ROW_HIDE', '숨길 줄을 목록에서 먼저 선택하세요.'),
                parent=self)
            return
        # ── 고른 줄을 층으로 가른다 ──────────────────────────────
        mine, direct, viap = [], [], []
        for iid in list(self._picked):
            r = self._row_of(iid)
            if r is None:
                continue
            mid = r['media_id']
            if isinstance(mid, tuple):
                mine.append(mid)
            elif r.get('_via') == 'PERI' and r.get('_via_id'):
                viap.append(r)
            else:
                direct.append(r)
        pick = None
        if viap:
            # ★ **무엇이 함께 사라지는지 묻는다** — 연결팝업과 같은 상자다.
            pick = _lp.ask_via(self.winfo_toplevel(), self._via_info(viap[0]),
                               len(viap))
            if pick is None:
                return
        try:
            with appdb.connect(self.db_path) as conn:
                for uid in mine:
                    media_link.set_user_verse_media_hidden(conn, uid[1], True)
                for r in direct:
                    _lp.veto(conn, ('VERSE', self._verse_id),
                             self._asset_of(r))
                for r in viap:
                    if pick == 'HERE':
                        _lp.veto(conn, ('VERSE', self._verse_id),
                                 self._asset_of(r))
                    else:
                        _lp.veto(conn, ('PERICOPE', r['_via_id']),
                                 self._asset_of(r))
        except Exception as e:
            print(f'LinksPanel._apply_hide: {e}')
        self._toggle_pick_mode(False)      # 접으면서 목록을 다시 그린다
        if callable(getattr(self, 'on_changed', None)):
            try:
                self.on_changed()
            except Exception:
                pass

    def _row_of(self, iid):
        """그 줄의 원본 dict — `_refresh` 가 담아 둔다."""
        return (self._rowmap or {}).get(iid)

    @staticmethod
    def _asset_of(r):
        """목록 한 줄 → 연결 자산 `(종류, 번호)`.

        ⚠ **음수는 RSS 수집 자료**(`sys_ref_asset`)라 종류가 다르다 — 양수
          미디어와 같은 종류로 넘기면 엉뚱한 자산을 가린다."""
        mid = r['media_id']
        return (('RSSA', -mid) if mid < 0 else ('MEDIA', mid))

    def _via_info(self, r):
        """가림 상자에 넘길 층 정보 — 이름·범위·절 수."""
        import link_picker as _lp
        span, n = '', 0
        try:
            with appdb.connect(self.db_path) as c:
                pr = c.execute('SELECT start_vid, end_vid FROM '
                               'sys_pericope_asset WHERE pericope_id=?',
                               (r['_via_id'],)).fetchone()
            if pr:
                with appdb.connect(self.db_path) as c:
                    span = _lp._range_text(c, pr[0], pr[1],
                                           self.lang_getter() or 'KO')
                n = (pr[1] or pr[0]) - pr[0] + 1
        except Exception:
            pass
        return {'label': r.get('title') or '', 'via': 'PERI',
                'via_label': span, 'via_n': n}

    # ------------------------------------------------------------------ 공개 API
    def load(self, verse_id: int):
        self._verse_id = verse_id
        self._refresh()

    def clear(self):
        self._verse_id = None
        if self._tree is not None:
            self._tree.delete(*self._tree.get_children())
        self._items.clear()
        self._clear_ref_sites()

    # ------------------------------------------------------------------ 내부 갱신
    def _refresh(self):
        if self._mode == 'CLINK':
            if self._verse_id:
                self._load_ref_sites(self._verse_id)
            else:
                self._clear_ref_sites()
            return
        self._tree.delete(*self._tree.get_children())
        self._items.clear()
        self._rowmap = {}      # iid → 원본 dict (층 정보를 들고 있다)

        if not self._verse_id:
            self._clear_ref_sites()
            return

        if self._mode == 'CLINK':
            self._load_ref_sites(self._verse_id)

        rows = self._fetch(self._verse_id)
        # ★ 유형 갈래 (2026-09-09 0.txt 1-4) — **화면에서만 거른다.**
        #   ⚠ 배지는 안 따라온다 — 갈래는 「지금 무엇을 볼까」이고 배지는
        #     「이 구절에 무엇이 있나」다(언어와 같은 규칙 · 0.txt 1-3).
        if self._mode == 'VIDEO' and hasattr(self, '_kind'):
            rows = [r for r in rows if self._kind_ok(r)]
        # ★★ **내가 가린 줄** (2026-08-30) — 숨기는 문만 만들고 목록이 안
        #   걸러 주면 「눌러도 그대로」가 된다(§저장은 되는데 안 보인다).
        #   ★ **「가린 것도 보기」가 켜져 있으면 지우지 않고 표시만 한다**
        #     (`overlay_read.show_hidden` — 앱 전체가 쓰는 그 스위치 하나).
        #     그래야 **되돌릴 길**이 있다. 되돌릴 수 없는 가리기는 만들지 않는다.
        try:
            import media_pref, overlay_read
            _hid = media_pref.load(self.db_path).hide_m
            with appdb.connect(self.db_path) as _c:
                _show = overlay_read.show_hidden(_c)
            # ⚠⚠ `sqlite3.Row` 는 **값을 못 넣는다** — 표식을 달려면 dict 로
            #   바꿔야 한다(안 바꾸면 조용히 ↺ 가 안 붙는다).
            _pf = media_pref.load(self.db_path)
            # ★★★ **연결팝업과 같은 가림을 본다** (2026-08-30) — 그전에는 이
            #   화면만 `user_media_hide` 를 썼는데 그것은 **그 영상이 걸린 모든
            #   절·단락·용어**(최대 17곳)에서 지운다. 실측 — 주요용어 화면까지
            #   사라진다. 두 화면이 다른 범위로 가리고 있었다.
            #   ⇒ 이제 `link_picker.veto` 를 함께 읽는다. 옛 `user_media_hide`
            #     행도 계속 존중한다(이미 가린 것을 되살려 놓지 않는다).
            import link_picker as _lp
            with appdb.connect(self.db_path) as _c:
                _v_verse = _lp.vetoed(_c, 'VERSE', self._verse_id)
                _v_peri = {}
                for _r in rows:
                    _pid = (_r.get('_via_id') if isinstance(_r, dict)
                            else None)
                    if (_r.get('_via') if isinstance(_r, dict) else '') == 'PERI'                             and _pid and _pid not in _v_peri:
                        _v_peri[_pid] = _lp.vetoed(_c, 'PERICOPE', _pid)
            out = []
            for r in rows:
                r = r if isinstance(r, dict) else dict(r)
                _mi = r['media_id']
                # ⚠ 채널 가리기는 **되돌리는 자리가 딴 데(미디어 설정)** 라
                #   여기서는 스위치와 무관하게 늘 뺀다 — 줄에서 되살릴 수 없는
                #   것을 「가린 줄」로 보이면 ✓ 를 눌러도 안 돌아온다.
                if (isinstance(_mi, int)
                        and _pf.hidden(None, r.get('description'))):
                    continue
                _key = ('MEDIA' if (isinstance(_mi, int) and _mi > 0)
                        else 'RSSA', abs(_mi) if isinstance(_mi, int) else 0,
                        None)
                _h = (isinstance(_mi, int) and _mi in _hid)
                if isinstance(_mi, int):
                    if _key in _v_verse:
                        _h = True
                    _pid = r.get('_via_id')
                    if (r.get('_via') == 'PERI' and _pid
                            and _key in _v_peri.get(_pid, ())):
                        _h = True
                if _h and not _show:
                    continue
                r['_hidden'] = _h
                out.append(r)
            rows = out
        except Exception as e:
            print('[links hidden] %s' % e)
        # 갈래 거르기 (2026-08-26 2안) — 기준은 _is_text_row 하나
        if self._mode == 'VIDEO':
            rows = [r for r in rows if not _is_text_row(
                r['media_id'], r['media_type'], r['format_type'])]
        elif self._mode == 'TEXT':
            rows = [r for r in rows if _is_text_row(
                r['media_id'], r['media_type'], r['format_type'])]

        if not rows:
            return

        import overlay_mark as _om
        _om.configure_tree(self._tree)
        # ★★★ **범위를 줄마다 적는다** (2026-08-30 사용자 확정 — 「창1:1~3,
        #   창1장, 창세기 등으로 구분값 표시」).
        #   ⚠⚠ 그전에는 층을 **계산만 하고 화면에 안 냈다** — 실측 창1:20 의
        #     영상 4줄이 전부 단락 경유인데 「이 절의 영상」처럼 보였다.
        #   ⚠ 묶음(별도 레코드) 방식과 견주어 **칸**을 골랐다 — 묶음 머리는
        #     #0 에 190px 를 늘 먹고 줄도 하나씩 더 쓴다. 칸은 92px 이고
        #     **줄마다 제 범위**를 말해 훑기가 쉽다(좁은 P2 에서 차이가 크다).
        _sc = {}
        _self_sc = ''
        try:
            import link_picker as _lp
            with appdb.connect(self.db_path) as _c:
                # ★ 절 직접 줄도 **그 절 약명**을 적는다(2026-08-30 사용자 지시).
                _self_sc = _lp.scope_label(_c, self._verse_id, self._verse_id,
                                           self.lang_getter() or 'KO')
                for r in rows:
                    pid = r.get('_via_id') if r.get('_via') == 'PERI' else None
                    if pid is None or pid in _sc:
                        continue
                    pr = _c.execute('SELECT start_vid, end_vid FROM '
                                    'sys_pericope_asset WHERE pericope_id=?',
                                    (pid,)).fetchone()
                    _sc[pid] = (_lp.scope_label(_c, pr[0], pr[1],
                                                self.lang_getter() or 'KO')
                                if pr else '')
        except Exception as e:
            print('[links scope] %s' % e)
        # ★★ **참조 사이트도 한 줄이다**(1.txt 2) — 띠를 걷은 대신 목록 맨 위에
        #   넣는다. 누르면 브라우저로 나간다(띠의 칩이 하던 그대로).
        #   ⚠ 그 사이트는 **장 단위**라 범위 칸에 그 사실을 적는다 — 절 줄과
        #     섞이면 「이 절의 자료」로 읽힌다(§0-1).
        if self._mode == 'TEXT':
            try:
                for _sr in self._site_rows(self._verse_id):
                    _iid = self._tree.insert(
                        '', 'end', tags=('row',),
                        values=(mlv.PICK_OFF, _sr['scope_label'], '',
                                _sr['kind'], _sr['site_name'], '', ''))
                    self._items[_iid] = None
                    self._rowmap[_iid] = _sr
            except Exception as _e:
                print('[links site rows] %s' % _e)
        for r in rows:
            mid = r['media_id']
            is_fav = bool(r['is_fav'])
            title = r['title'] or ''
            tags = ('fav',) if is_fav else ('row',)
            mk = None
            if isinstance(mid, tuple):   # 내 링크 — N 표식 (덮개 문법)
                kind = i18n.t('EB_MY_LINK', '내 링크')
                channel = ''
                mk = _om.mark_of('NEW', for_reading=True)
                if _om.tag_name(mk):
                    tags = (_om.tag_name(mk),)
            elif mid < 0:      # sys_ref_asset(RSS 텍스트) — 형태=유형라벨, 채널 없음, 요약 부가
                kind = i18n.t('MEDIATYPE_'+str(r['media_type']), MEDIA_TYPE_LABEL.get(r['media_type'], r['media_type']))
                channel = ''
                if r['description']:
                    title += f"  · {r['description']}"
            else:              # 수집 미디어 — 형태=내용·형태 배지, 채널=description JSON
                kind = mlv.kind_label(r['media_type'], r['format_type'],
                                      (r['audience'] if 'audience' in r.keys() else 'GENERAL'))
                channel = mlv.channel_of(r['description'])
            # ⚠ 표식 자리는 전 줄 고정폭(SLOT) — 안 그러면 제목 시작선이 흔들린다
            # ★ 맨 앞 = **고르기 칸**(평소 폭 0). 가린 줄은 흐리게.
            _hid = bool(r.get('_hidden'))
            _scope = (_sc.get(r.get('_via_id'), '')
                      if r.get('_via') == 'PERI' else _self_sc)
            vals = (mlv.PICK_OFF, _scope, r['lang_code'], kind,
                    _om.prefix(title, mk), channel, mlv.fav_mark(is_fav))
            if _hid:
                tags = ('hidden',)
            iid = self._tree.insert('', 'end', values=vals, tags=tags)
            self._items[iid] = mid
            self._rowmap[iid] = r
        self._sync_my_btns()

    def _fetch(self, verse_id: int):
        # ★ 2026-10-13 (74-11) — 한 번의 구절 선택 안에서 같은 목록을 11번 지었다 → 한 번만(`appdb.memo`)
        try:
            lo = self._lang_only() if callable(getattr(self, '_lang_only', None)) else None
        except Exception:
            lo = None
        try:
            ui = self.lang_getter()
        except Exception:
            ui = None
        key = ('links_fetch', str(self.db_path), verse_id, ui, lo)
        return list(appdb.memo(key, lambda: LinksPanel._fetch_raw(self, verse_id)))

    def _fetch_raw(self, verse_id: int):
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row

                bi = conn.execute(
                    'SELECT bcode, chapter FROM bible_index WHERE verse_id=?',
                    (verse_id,)
                ).fetchone()
                if not bi:
                    return []

                bcode, chapter = bi['bcode'], bi['chapter']

                peri_rows = conn.execute(
                    'SELECT pericope_id FROM sys_pericope_asset p WHERE '
                    + _vr.covers_sql('p', 'start_vid', 'end_vid')
                    + ' AND p.record_status="LIVE"',
                    _vr.covers_args(verse_id)
                ).fetchall()
                peri_ids = [p['pericope_id'] for p in peri_rows]
                peri_id = peri_ids[0] if peri_ids else None

                # ⚠ 옛 `BOOK`·`CHAPTER` 갈래는 통합 표로 안 옮겼다 — 실측 0건이고
                #   `CHAPTER` 열쇠(`1_3`)는 애초에 숫자가 아니라 `target_id` 에
                #   들어가지 않는다. 아는 갈래만 묻는다(`media_link.CODE`).
                # ★★ **구절 연결은 구간으로 본다** (2026-09-03 사용자 지시
                #   「구절 구간 단위로 연결하도록 개선하라」). 설교 한 편이
                #   「창1:6~8」을 다루면 **그 세 절 어디를 눌러도** 뜬다.
                #   ⚠ 그전에는 `target_id=?` **정확 일치**라 구간을 만들어도
                #     시작 절에서만 보였다 — 바로 옆 RSS 자료(`RSSA_VERS`)는
                #     이미 범위로 보고 있었는데 미디어만 안 그랬다.
                #   ⚠ `end_id` 가 NULL 인 옛 행은 한 절로 본다(같은 규칙).
                conds, mparams = [], []
                _lt_v = media_link.lt('VERSE')
                if _lt_v:
                    # ⚠⚠ 구간 판정은 **`verse_range` 한 문**(§verse_range) —
                    #   번호로 재면 「아6:1~6:14」 한 편이 13,488절을 덮는다.
                    #   ⚠ 여기서 **지역 import 를 하지 말 것** — 모듈 레벨과
                    #     두 벌이 되어 다른 가지에서 `_vr` 이 안 잡힌다(실측).
                    conds.append("(l.link_type=? AND " + _vr.covers_sql('l') + ")")
                    mparams += [_lt_v] + _vr.covers_args(verse_id)
                _lt_p = media_link.lt('PERICOPE')
                _pk = media_link.key_int(peri_id) if peri_id else None
                if _lt_p and _pk is not None:
                    conds.append("(l.link_type=? AND l.target_id=?)")
                    mparams += [_lt_p, _pk]

                where = ' OR '.join(conds) or '0'
                # 첫 파라미터 = MEDIA_TITLE 현지어 서브쿼리용(SELECT 절이 WHERE 보다 앞)
                params = [self.lang_getter()] + mparams

                lang_filter = ''
                _lo = self._lang_only()
                if _lo:
                    lang_filter = f" AND m.lang_code='{_lo}'"

                media_sql = f"""
                    SELECT l.link_type AS via_lt, l.target_id AS via_id,
                           m.media_id AS media_id, m.media_type, m.format_type,
                           COALESCE(m.audience,'GENERAL') AS audience,
                           COALESCE((SELECT tx.contents FROM sys_text_asset tx
                                     WHERE tx.text_type='MEDIA_TITLE' AND tx.clicked_id=m.media_id
                                       AND tx.lang_code=? AND tx.record_status='LIVE' LIMIT 1),
                                    m.title) AS title,
                           m.description, m.url, m.lang_code,
                           m.sort_order,
                           CASE WHEN f.fav_id IS NOT NULL THEN 1 ELSE 0 END AS is_fav
                    FROM sys_media_asset m
                    JOIN {media_link.TBL} l ON l.clicked_id = m.media_id
                    {__import__('listen').join_sql('m')}
                    WHERE ({where})
                      AND l.record_status = 'LIVE'
                      AND m.is_active = 1
                      AND m.record_status = 'LIVE'
                      {lang_filter}
                    ORDER BY m.media_type, m.sort_order
                """
                media_rows = conn.execute(media_sql, params).fetchall()

                # sys_ref_asset (RSS 수집 텍스트) — 음수 ID로 구분.
                # 대표 컬럼(verse_id/pericope_id) ∪ sys_ref_asset_link(PERICOPE 다중 연결)
                peri_clause = f'OR pericope_id={int(peri_id)}' if peri_id else ''
                link_clause = ''
                if peri_ids:
                    ph = ','.join(str(int(p)) for p in peri_ids)
                    # ★ 2026-08-24 통합 표(`RSSA_PERI`)
                    link_clause = (f"OR ref_id IN (SELECT clicked_id FROM sys_link_asset "
                                   f"WHERE link_type='RSSA_PERI' "
                                   f"AND COALESCE(record_status,'LIVE')='LIVE' "
                                   f"AND target_id IN ({ph}))")
                # 절 범위 연결(2026-08-03) — 설교 한 편이 「마 5:3~12」를 다루면
                # 그 12절 어디를 눌러도 뜬다. end_id 가 NULL 인 옛 행은 한 절로 본다.
                # ★ 2026-08-24 통합 표(`RSSA_VERS`)
                # ⚠ 여기도 책 가드 — 이름 있는 인자라 조각을 손으로 적는다
                verse_clause = (
                    "OR ref_id IN (SELECT clicked_id FROM sys_link_asset la "
                    "WHERE la.link_type='RSSA_VERS' "
                    "AND COALESCE(la.record_status,'LIVE')='LIVE' "
                    "AND la.target_id<=:vid "
                    "AND COALESCE(la.end_id,la.target_id)>=:vid "
                    "AND (SELECT bcode FROM bible_index WHERE verse_id=la.target_id)"
                    "   =(SELECT bcode FROM bible_index WHERE verse_id=:vid))")
                ref_lang_filter = ''
                _lo2 = self._lang_only()
                if _lo2:
                    ref_lang_filter = f" AND lang_code='{_lo2}'"
                ref_sql = f"""
                    SELECT DISTINCT ref_id, COALESCE(media_type,'TEXT_ARTICLE'), 'TEXT',
                           title, SUBSTR(COALESCE(summary,''),1,80),
                           url, lang_code, 0, 0
                    FROM sys_ref_asset
                    WHERE is_active=1 AND record_status='LIVE'
                      AND (verse_id=:vid {peri_clause} {link_clause} {verse_clause})
                      {ref_lang_filter}
                    ORDER BY media_type, ref_id
                """
                ref_rows = conn.execute(ref_sql, {'vid': verse_id}).fetchall()

                # ⚠⚠ **여기서 거르지 않는다** (2026-08-30 사용자 신고 「텍스트
                #   링크는 삭제한 후 되살리기 가능한데 **영상링크에서는 그대로
                #   사라진다**」).
                #   ⇒ 원인이 바로 이 자리였다. 여기(2026-08-21)는 **「가린 것도
                #     보기」 스위치를 모른 채** 걸러 버려서, 영상(양수 media_id)은
                #     스위치를 켜도 목록에 **다시 나타날 길이 없었다.**
                #     텍스트(음수·RSS)는 이 훑기에 안 걸려 살아남았다 —
                #     **두 갈래의 동작이 갈린 것이 그 때문**이다.
                #   ⇒ 거르기는 `_refresh` 한 곳에서 한다(스위치를 아는 자리).
                #     채널 가리기도 함께 옮겼다.
                # ★★ **층을 함께 실어 준다** (2026-08-30) — 이 줄이 **이 절에**
                #   걸렸는지 **단락에** 걸렸는지가 숨길 때 결정을 가른다.
                #   ⚠ RSS(음수)는 표가 달라 층을 못 주므로 비워 둔다.
                results = []
                for r in media_rows:
                    d = dict(r)
                    _lt = (d.pop('via_lt', '') or '')
                    d['_via'] = ('PERI' if _lt.endswith('_PERI') else 'VERSE')
                    d['_via_id'] = d.pop('via_id', None)
                    results.append(d)
                # ★★ **링크 팩 합류** (2026-09-03 점검에서 검거) — 이 화면은
                #   구절·단락 축이라 `overlay_read.media`(엔티티 축)를 안 쓴다.
                #   그래서 팩의 `MEDI_VERS`·`MEDI_PERI`(실측 sys 링크의 36%)가
                #   여기서 통째로 안 보였다. **집이 달라도 화면은 같아야 한다.**
                #   ⚠ 같은 media_id 가 본체에도 있으면 **팩이 이긴다**(더 새 것) —
                #     `overlay_read.media` 와 같은 규칙이라야 화면이 안 갈린다.
                #   ⚠ 팩이 없으면 조용히 건너뛴다(수신 전 사용자).
                try:
                    import link_pack as _lp
                    #   ⚠⚠ **구간 규칙을 본체와 똑같이 쓴다** (2026-09-03) —
                    #     한쪽만 범위로 보면 같은 영상이 집에 따라 보였다 안
                    #     보였다 한다.
                    if _lp.attach(conn) and _lp.available(conn) and conds:
                        _pw = ' OR '.join(
                            c.replace('l.', 'pl.') for c in conds)
                        _pp = list(mparams)
                        # ⚠ 제목 덮개는 **overlay_read 한 문**으로 읽는다 —
                        #   화면이 sys 를 직접 뒤지면 검사기가 잡고, 집(본체·
                        #   팩)마다 규칙이 갈린다(2026-09-03 검거).
                        _pack_sql = (
                            "SELECT pl.link_type, pl.target_id, pm.media_id,"
                            " pm.media_type, COALESCE(pm.format_type,'VIDEO'),"
                            " pm.title,"
                            " COALESCE(pm.description,''), pm.url,"
                            " COALESCE(pm.lang_code,''), COALESCE(pm.sort_order,0),"
                            " CASE WHEN f.fav_id IS NOT NULL THEN 1 ELSE 0 END"
                            " FROM linkpack.pack_link pl"
                            " JOIN linkpack.pack_media pm"
                            "   ON pm.media_id=pl.clicked_id "
                            " LEFT JOIN userdb.user_favorite f ON f.fav_type='LISTEN' AND f.record_status='LIVE'"
                            " AND f.label=substr(pm.url,33,11)"   # ♥ 즐겨듣기(2026-10-11 · listen.join_sql 과 같은 글)
                            " WHERE (%s)"
                            "   AND COALESCE(pl.record_status,'LIVE')='LIVE'"
                            "   AND COALESCE(pm.record_status,'LIVE')='LIVE'"
                            "   AND pm.is_active=1"
                            " ORDER BY pm.media_type, pm.sort_order" % _pw)
                        _prows = conn.execute(_pack_sql, _pp).fetchall()
                        _ov = {}
                        if _prows:
                            import overlay_read as _or9
                            _ov = _or9.media_titles(
                                conn, [r[2] for r in _prows],
                                self.lang_getter())
                            _pids = {r[2] for r in _prows}
                            results = [d for d in results
                                       if not (isinstance(d.get('media_id'), int)
                                               and d['media_id'] in _pids)]
                        for r in _prows:
                            _lo3 = self._lang_only()
                            if _lo3 and r[8] and r[8] != _lo3:
                                continue          # 「내 언어만」 — sys 와 같은 규칙
                            results.append({
                                '_via': ('PERI' if str(r[0]).endswith('_PERI')
                                         else 'VERSE'),
                                '_via_id': r[1],
                                'media_id': r[2], 'media_type': r[3],
                                'format_type': r[4], 'audience': 'GENERAL',
                                'title': _ov.get(r[2], r[5]) or '',
                                'description': r[6] or '',
                                'url': r[7] or '', 'lang_code': r[8] or '',
                                'sort_order': r[9], 'is_fav': r[10]})
                except Exception as _e:
                    print('[LinksPanel pack] %s' % _e)
                for r in ref_rows:
                    results.append({
                        '_via': 'VERSE', '_via_id': verse_id,
                        'media_id':   -r[0],   # 음수 = sys_ref_asset
                        'media_type': r[1],
                        'format_type': r[2],
                        'title':      r[3] or '',
                        'description': r[4] or '',
                        'url':        r[5] or '',
                        'lang_code':  r[6] or '',
                        'sort_order': r[7],
                        'is_fav':     r[8],
                    })
                # ★ 내 링크 (2026-08-27 — 덮개 C 단계). 이 구절에 내가 붙인
                #   URL 을 sys 목록에 합친다 — 조회는 media_link 한 문.
                #   media_id = ('U', uid) — 음수는 sys_ref_asset 몫이라 겹친다.
                #   갈래는 유튜브 id 유무(format_type 으로 실어 _is_text_row
                #   하나가 그대로 가른다). 숨긴 것(H)은 읽는 목록이라 뺀다.
                for u in media_link.user_verse_media(conn, verse_id):
                    if u['status'] == 'HIDE':
                        continue
                    yt = media_link.yt_id(u['url'])
                    results.append({
                        '_via': 'VERSE', '_via_id': verse_id,
                        'media_id':   ('U', u['uid']),
                        'media_type': 'USER',
                        'format_type': 'VIDEO' if yt else 'TEXT',
                        'title':      u['title'],
                        'description': '',
                        'url':        u['url'],
                        'lang_code':  '',
                        'sort_order': 0,
                        'is_fav':     0,
                    })
                return results
        except Exception as e:
            print(f'LinksPanel._fetch: {e}')
            return []

    # ------------------------------------------------------------------ B형 참조 사이트
    def _clear_ref_sites(self):
        self._chip_items = []
        for w in self._ref_frame.winfo_children():
            w.destroy()

    def _load_ref_sites(self, verse_id: int):
        self._clear_ref_sites()
        rows = self._fetch_ref_sites(verse_id)
        if not rows:
            self._repaint_dynamic()
            return
        if LinksPanel._hidden_site_ids:
            rows = [r for r in rows if r['site_id'] not in LinksPanel._hidden_site_ids]
        if not rows:
            return

        # 그룹화
        grouped: dict[str, list] = {}
        for r in rows:
            grouped.setdefault(r['media_type'], []).append(r)

        pad_f = tk.Frame(self._ref_frame, bg=REF_HDR_COLOR)
        pad_f.pack(fill='x', padx=6, pady=4)

        # ★ 리사이즈 반응 줄바꿈 (2026-09-03 0.txt 3번 — 「라벨이 사라지지
        #   않고 다음줄로 연속 표시」). 옛 pack 한 줄 나열은 좁아지면 오른쪽
        #   칩이 잘려 사라졌다. 위젯을 grid 로 두고 폭이 바뀌면 다시 깐다.
        # ★ 색은 역할 한 쌍(dark_bg·fg_on_dark — 활성 탭과 같은 쌍)으로
        #   통일 (사용자 지시 「어떤 화면색 테마 모드에서도 잘 보이는 것만」).
        #   파스텔 다섯 벌을 골라 쓰면 다음 테마에서 또 깨진다 — 색 선별이
        #   아니라 하드코딩 제거가 답이다.
        chips = []          # (widget, 분류 머리인가)
        for mtype in self._ref_order():
            if mtype not in grouped:
                continue
            label = i18n.t('REFSITE_'+str(mtype), REF_SITE_LABEL.get(mtype, mtype))
            lb = tk.Label(pad_f, text=label,
                          bg=REF_HDR_COLOR, fg='#555',
                          font=('Malgun Gothic', 8), anchor='e')
            chips.append((lb, True))
            for site in grouped[mtype]:
                url = site['url']
                lbl = tk.Label(pad_f, text=site['site_name'],
                               bg=_C('dark_bg', '#5D6D7E'),
                               fg=_C('fg_on_dark', 'white'),
                               font=('Malgun Gothic', 8, 'bold'),
                               padx=7, pady=2,
                               cursor='hand2', relief='flat')
                lbl.bind('<Button-1>',
                         lambda e, u=url: webbrowser.open(u))
                # ⚠ 붙잡아 둔 색으로 되돌리지 않는다(2026-08-30) — 지금
                #   칠해져 있는 색을 그때 읽는 hover 를 그대로 쓴다.
                lbl.bind('<Enter>', _hover_in)
                lbl.bind('<Leave>', _hover_out)
                chips.append((lbl, False))
        self._chip_pad = pad_f
        self._chip_items = chips
        self._chip_w = -1
        pad_f.bind('<Configure>', self._on_chip_conf)
        self.after_idle(self._reflow_chips)

        # 구분선
        tk.Frame(self._ref_frame, bg='#b0c8e0', height=1).pack(fill='x')
        self._repaint_dynamic()

    def _on_chip_conf(self, _e=None):
        pad = getattr(self, '_chip_pad', None)
        if not pad or not pad.winfo_exists():
            return
        w = pad.winfo_width()
        if abs(w - getattr(self, '_chip_w', -1)) > 6:
            self._chip_w = w
            self._reflow_chips()

    def _reflow_chips(self):
        """칩을 폭에 맞게 다시 깐다 — 분류 머리는 늘 새 줄에서 시작."""
        pad = getattr(self, '_chip_pad', None)
        if not pad or not pad.winfo_exists():
            return
        avail = pad.winfo_width()
        if avail <= 1:
            avail = max(self.winfo_width() - 16, 240)
        row = col = x = 0
        for wdg, head in getattr(self, '_chip_items', []):
            if not wdg.winfo_exists():
                continue
            wd = wdg.winfo_reqwidth() + 6
            if (head and col) or (col and x + wd > avail):
                row += 1
                col = 0
                x = 0
            wdg.grid(row=row, column=col, sticky='w', padx=(0, 4), pady=2)
            col += 1
            x += wd

    def _repaint_dynamic(self):
        """★ 동적으로 새로 만든 위젯에 테마를 입힌다 (2026-08-19 — 0.txt ②).

        구절을 바꾸면 `_load_ref_sites` 가 설교/강해 버튼 줄을 새로 만드는데,
        `ui_theme.paint` 는 탭 열 때만 돌아서 **새 위젯이 기본색(흰 바탕)으로
        남았다**(사용자 재현: P1 에서 구절 연타 → 흰색, 다른 탭 갔다 오면 정상
        — 탭 전환 훅이 칠해 준 것). 렌즈 카드·구절노트에서 잡은 병과 같다(§36-5b).
        """
        try:
            import ui_theme
            if ui_theme.current() != ui_theme.DEFAULT:
                ui_theme.paint(self._ref_frame)
        except Exception:
            pass

    def _site_rows(self, verse_id):
        """참조 사이트를 **목록 줄**로 (2026-09-17 · 1.txt 2).

        ⚠ 실측 텍스트 갈래가 그릴 수 있는 사이트는 **한 곳**(Enduring Word ·
          장 단위)이다. 띠를 걷으면서 잃지 않으려고 줄로 옮겼다.
        """
        out = []
        for r in (self._fetch_ref_sites(verse_id) or []):
            if LinksPanel._hidden_site_ids and \
                    r['site_id'] in LinksPanel._hidden_site_ids:
                continue
            out.append({
                'site_name': r['site_name'], 'url': r['url'],
                'kind': i18n.t('REFSITE_' + str(r['media_type']),
                               REF_SITE_LABEL.get(r['media_type'],
                                                  r['media_type'])),
                'scope_label': i18n.t('LP_SITE_SCOPE', '사이트'),
                '_site': True})
        return out

    def _fetch_ref_sites(self, verse_id: int) -> list:
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                sql = """
                    SELECT m.url, s.site_name, s.media_type, s.sort_order, s.site_id
                    FROM sys_ref_verse_map m
                    JOIN sys_ref_site s ON s.site_id = m.site_id
                    WHERE s.scope = 'VERSE'
                      -- 주석·원문대조·사전은 주석 탭 [링크] 로 옮겼다(2026-08-03).
                      -- 여기 남기면 같은 버튼이 두 탭에 뜬다.
                      AND s.media_type IN {REF_IN}
                      AND m.verse_id = :vid
                      AND m.map_status != 'EXCLUDED'
                      AND (m.is_alive IS NULL OR m.is_alive = 1)
                      AND s.is_active = 1 AND s.record_status = 'LIVE'

                    UNION ALL

                    SELECT m.url, s.site_name, s.media_type, s.sort_order, s.site_id
                    FROM sys_ref_site s
                    JOIN bible_index bi ON bi.verse_id = :vid
                    JOIN sys_ref_verse_map m ON (
                        m.site_id = s.site_id
                        AND m.verse_id = (
                            SELECT MIN(bi2.verse_id) FROM bible_index bi2
                            WHERE bi2.bcode = bi.bcode AND bi2.chapter = bi.chapter
                        )
                    )
                    WHERE s.scope = 'CHAPTER'
                      -- 주석·원문대조·사전은 주석 탭 [링크] 로 옮겼다(2026-08-03).
                      -- 여기 남기면 같은 버튼이 두 탭에 뜬다.
                      AND s.media_type IN {REF_IN}
                      AND m.map_status != 'EXCLUDED'
                      AND (m.is_alive IS NULL OR m.is_alive = 1)
                      AND s.is_active = 1 AND s.record_status = 'LIVE'

                    UNION ALL

                    SELECT m.url, s.site_name, s.media_type, s.sort_order, s.site_id
                    FROM sys_ref_site s
                    JOIN bible_index bi ON bi.verse_id = :vid
                    JOIN sys_ref_verse_map m ON (
                        m.site_id = s.site_id
                        AND m.verse_id = (
                            SELECT MIN(bi3.verse_id) FROM bible_index bi3
                            WHERE bi3.bcode = bi.bcode
                        )
                    )
                    WHERE s.scope = 'BOOK'
                      -- 주석·원문대조·사전은 주석 탭 [링크] 로 옮겼다(2026-08-03).
                      -- 여기 남기면 같은 버튼이 두 탭에 뜬다.
                      AND s.media_type IN {REF_IN}
                      AND m.map_status != 'EXCLUDED'
                      AND (m.is_alive IS NULL OR m.is_alive = 1)
                      AND s.is_active = 1 AND s.record_status = 'LIVE'

                    ORDER BY sort_order
                """
                # 갈래별 목록 — TEXT 는 주석·원문대조·사전까지(2026-08-26 통합)
                sql = sql.replace('{REF_IN}', self._ref_in())
                return conn.execute(sql, {'vid': verse_id}).fetchall()
        except Exception:
            return []

    # ------------------------------------------------------------------ 설정 팝업
    def _open_settings(self):
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                sites = conn.execute("""
                    SELECT site_id, site_name, media_type, sort_order
                    FROM sys_ref_site
                    WHERE is_active = 1 AND record_status = 'LIVE'
                      AND media_type IN {REF_IN}
                    ORDER BY media_type, sort_order
                """.replace('{REF_IN}', self._ref_in())).fetchall()
        except Exception:
            sites = []

        popup = tk.Toplevel(self)
        popup.title(i18n.t('WIN_REFSITE_SETTINGS', '참조 사이트 표시 설정'))
        popup.resizable(False, False)
        popup.grab_set()

        # 스크롤 가능 영역
        outer = tk.Frame(popup)
        outer.pack(fill='both', expand=True, padx=12, pady=(10, 4))

        canvas = tk.Canvas(outer, highlightthickness=0, width=320, height=340)
        vsb = ttk.Scrollbar(outer, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)

        inner = tk.Frame(canvas)
        canvas_win = canvas.create_window((0, 0), window=inner, anchor='nw')

        def _on_configure(e):
            canvas.configure(scrollregion=canvas.bbox('all'))
            canvas.itemconfig(canvas_win, width=canvas.winfo_width())
        inner.bind('<Configure>', _on_configure)
        canvas.bind('<Configure>',
                    lambda e: canvas.itemconfig(canvas_win, width=e.width))

        # 카테고리별 체크박스
        grouped: dict[str, list] = {}
        for s in sites:
            grouped.setdefault(s['media_type'], []).append(s)

        vars_map: dict[int, tk.BooleanVar] = {}

        for mtype in self._ref_order():
            if mtype not in grouped:
                continue
            color = REF_SITE_COLOR.get(mtype, '#4a4a4a')
            label = i18n.t('REFSITE_'+str(mtype), REF_SITE_LABEL.get(mtype, mtype))

            cat_f = tk.Frame(inner)
            cat_f.pack(fill='x', pady=(8, 1))
            tk.Label(cat_f, text=label,
                     font=('Malgun Gothic', 9, 'bold'), fg=color
                     ).pack(side='left')
            tk.Frame(inner, bg='#ddd', height=1).pack(fill='x', pady=(0, 3))

            for s in grouped[mtype]:
                sid = s['site_id']
                var = tk.BooleanVar(value=(sid not in LinksPanel._hidden_site_ids))
                vars_map[sid] = var
                tk.Checkbutton(inner, text=s['site_name'], variable=var,
                               font=('Malgun Gothic', 9)
                               ).pack(anchor='w', padx=16, pady=1)

        if not vars_map:
            tk.Label(inner, text=i18n.t('LP_NOSITES','등록된 참조 사이트가 없습니다.'),
                     font=('Malgun Gothic', 9), fg='gray'
                     ).pack(pady=20)

        # 하단 버튼
        sep = tk.Frame(popup, bg='#ccc', height=1)
        sep.pack(fill='x', padx=0)

        btn_f = tk.Frame(popup)
        btn_f.pack(fill='x', padx=12, pady=8)

        def _select_all():
            for v in vars_map.values():
                v.set(True)

        def _deselect_all():
            for v in vars_map.values():
                v.set(False)

        def _on_ok():
            LinksPanel._hidden_site_ids = {
                sid for sid, v in vars_map.items() if not v.get()
            }
            popup.destroy()
            self._refresh()

        tk.Button(btn_f, text=i18n.t('LP_SELECTALL','전체선택'), command=_select_all,
                  font=('Malgun Gothic', 8), width=7
                  ).pack(side='left', padx=(0, 4))
        tk.Button(btn_f, text=i18n.t('LP_DESELECTALL','전체해제'), command=_deselect_all,
                  font=('Malgun Gothic', 8), width=7
                  ).pack(side='left')
        tk.Button(btn_f, text=i18n.t('COMMON_CANCEL','취소'), command=popup.destroy,
                  font=('Malgun Gothic', 9), width=6
                  ).pack(side='right', padx=(4, 0))
        tk.Button(btn_f, text=i18n.t('COMMON_CONFIRM','확인'), command=_on_ok,
                  font=('Malgun Gothic', 9, 'bold'), width=6
                  ).pack(side='right')

        # ⚠⚠ **다 짓고 칠한다** (2026-08-30 사용자 지시 「팝업 화면이 배경색
        #   테마에 맞도록 색상을 조정」). `ui_theme.paint` 는 **이미 있는 위젯**을
        #   칠하므로 지은 뒤에 불러야 한다 — 먼저 부르면 아무 일도 안 난다
        #   (연결 작업대·「다음 단계」 줄에서 겪은 것과 같은 병).
        try:
            import ui_theme
            ui_theme.adopt(popup)
            ui_theme.paint(popup)
        except Exception as e:
            print('[refsite popup theme] %s' % e)
        popup.update_idletasks()
        popup.minsize(popup.winfo_width(), popup.winfo_height())

    # ------------------------------------------------------------------ 이벤트
    def _on_click(self, event):
        region = self._tree.identify_region(event.x, event.y)
        if region != 'cell':
            return
        iid = self._tree.identify_row(event.y)
        if not iid or iid not in self._items:
            return
        # ★ 참조 사이트 줄(2026-09-17 · 띠를 걷고 줄로 옮긴 것) — 브라우저로.
        _row = self._rowmap.get(iid) or {}
        if isinstance(_row, dict) and _row.get('_site'):
            if _row.get('url'):
                webbrowser.open(_row['url'])
            return
        col = self._tree.identify_column(event.x)
        if self._pick_on:
            # ⚠ **고르는 동안에는 아무것도 열지 않는다** — 텍스트링크는 줄을
            #   누르면 브라우저가 열려, 고르다가 창이 열리면 방해가 된다.
            self._toggle_pick(iid)
            return
        if col == mlv.FAV_COL:   # fav 컬럼 → 즐겨찾기 토글
            self._toggle_fav(iid, self._items[iid])
        else:             # 그 외 셀 → 한 번 클릭으로 재생/열기
            self._play_or_open(self._items[iid])

    def _toggle_fav(self, iid: str, media_id: int):
        if not isinstance(media_id, int) or media_id < 0:
            return         # sys_ref_asset·내 링크 — fav 는 sys 미디어 전용
        try:
            import listen
            with appdb.connect(self.db_path) as conn:
                on = listen.toggle_media(conn, media_id)
                if on is None:
                    return
                mark, tags = ('♪', ('fav',)) if on else ('·', ('row',))

            vals = list(self._tree.item(iid, 'values'))
            vals[4] = mark            # fav 컬럼(5번째)
            self._tree.item(iid, values=vals, tags=tags)
        except Exception as e:
            print(f'LinksPanel._toggle_fav: {e}')

    def _on_double_click(self, event):
        iid = self._tree.identify_row(event.y)
        if not iid or iid not in self._items:
            return
        self._play_or_open(self._items[iid])

    def _title_of(self, mid):
        """P4 자료 탭 머리에 띄울 제목."""
        for iid, m in self._items.items():
            if m == mid:
                try:
                    return self._tree.item(iid, 'values')[2]
                except Exception:
                    break
        return ''

    def _url_of(self, mid):
        """그 줄의 주소 — **`media_link.asset_url` 한 문**에 맡긴다.

        ⚠ §121차에 「번호 하나로 주소를 찾는 단일 문」을 만들어 두었는데 이
          자리가 자기 SQL 을 그대로 쓰고 있었다(2026-09-05 검사기가 잡았다).
          세 표(내 링크·배포 미디어·RSS)가 갈리는 규칙이 두 곳에 있으면
          한쪽만 고쳐진다.
        """
        try:
            with appdb.connect(self.db_path) as conn:
                _u, _t = media_link.asset_url(conn, mid)
                row = (_u,) if _u else None
            return row[0] if row and row[0] else None
        except Exception as e:
            print('LinksPanel._url_of: %s' % e)
            return None

    # ⚠ 옛 `_open_in_youtube`(고른 줄을 브라우저로) 를 걷었다 —
    #   이제 **라디오가 정하고 한 번 누르면 그대로 열린다**(0.txt 1-2).
    #   그전에는 목록을 고르고 단추를 또 눌러야 했다.

    def _lang_only(self):
        """지금 선택한 언어 코드 — 「전체언어」면 `None`(안 가린다)."""
        try:
            import lang_combo
            cur = self._lang_sel.current() if self._lang_sel else None
            if not cur:
                return None
            lc = cur[1]
            return None if lc == lang_combo.ALL else lc
        except Exception:
            return None

    def _load_kind(self):
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM userdb.user_config"
                              " WHERE config_key='LP_KIND'").fetchone()
            ok = {k for k, _i, _d, _t in LINK_KINDS}
            v = (r[0] if r else '') or ''
            # ⚠ 옛 저장값을 옮긴다(2026-09-17 갈래 통합) — 안 옮기면 그 사람만
            #   목록에 없는 코드를 들고 있어 조용히 「전체」로 떨어진다.
            v = {'SERMON': 'WORD', 'STUDY': 'WORD',
                 'WORSHIP': 'WOR', 'READING': 'READ'}.get(v, v)
            return v if v in ok else 'ALL'
        except Exception:
            return 'ALL'

    def _on_kind(self):
        try:
            with appdb.connect(self.db_path) as c:
                c.execute("INSERT INTO userdb.user_config(config_key, config_val)"
                          " VALUES('LP_KIND',?)"
                          " ON CONFLICT(config_key) DO UPDATE"
                          "   SET config_val=excluded.config_val",
                          (self._kind.get(),))
                c.commit()
        except Exception:
            pass
        self._refresh()

    def _kind_ok(self, row):
        """지금 선택한 유형 갈래에 드는가 — **거르는 자리는 여기 하나**."""
        k = self._kind.get() if hasattr(self, '_kind') else 'ALL'
        if k == 'ALL':
            return True
        # ⚠ 옛 저장값 `SIGN` — 목록에서 뺐으므로 `_load_kind` 가 걸러 여기까지
        #   오지 않는다(그 표에 없는 코드는 ALL 로 떨어진다). 되살릴 때를 위해
        #   판정만 남긴다 — **대상 축**이라 `media_type` 이 아니라 `audience` 다.
        aud = _KIND_AUD.get(k)
        if aud:
            return (row.get('audience') or 'GENERAL') == aud
        for code, _i, _d, tys in LINK_KINDS:
            if code == k and tys:
                return (row.get('media_type') or '') in tys
        return True

    def lang_widget(self):
        """밖의 줄에 심을 언어 콤보(`ext_bar` 를 준 호스트가 pack 한다)."""
        ls = getattr(self, '_lang_sel', None)
        return ls.combo if ls is not None else None

    def _mk_combo(self, parent, items, var, on_change):
        """(코드, i18n열쇠, 폴백) 목록 → **읽기전용 콤보** 하나.

        ★★ **폭을 글자 수가 아니라 픽셀로 잰다** — `ttk.Combobox(width=)` 는
          평균 글자 너비 단위라 CJK·키릴에서 어긋난다. 가장 긴 값을 실제
          글꼴로 재서 그만큼 잡는다(§0 하드코딩 금지 · 글꼴은 설정을 따른다).
        ⚠ **라벨과 코드를 두 벌로 두지 않는다** — 화면은 라벨을 보이고 값은
          코드로 오간다. 언어를 바꾸면 라벨만 바뀌고 저장값은 그대로다.
        """
        import tkinter.font as _tkf
        from tkinter import ttk as _ttk
        labels, code_of, label_of = [], {}, {}
        for code, key, dflt in items:
            lb = i18n.t(key, dflt)
            while lb in code_of:            # 같은 글자가 둘이면 구별한다
                lb += ' '
            labels.append(lb)
            code_of[lb] = code
            label_of[code] = lb
        # ⚠ `theme_font.resolve` 는 **dict** 를 돌려준다(두 값으로 풀면 죽는다).
        try:
            import theme_font as _tf
            d = _tf.resolve(self.db_path, 'ui')
            fo = _tkf.Font(family=d.get('family'), size=int(d.get('size') or 10))
        except Exception:                                     # noqa: BLE001
            fo = _tkf.nametofont('TkDefaultFont')
        px = max((fo.measure(x) for x in labels), default=40)
        avg = max(fo.measure('0'), 1)
        cb = _ttk.Combobox(parent, state='readonly', values=labels,
                           width=int(px / avg) + 2)
        cb.set(label_of.get(var.get(), labels[0]))

        def _pick(_e=None):
            var.set(code_of.get(cb.get(), items[0][0]))
            on_change()
        cb.bind('<<ComboboxSelected>>', _pick)
        cb.pack(side='left', padx=(0, 6), pady=2)
        cb._code_of, cb._label_of = code_of, label_of
        return cb

    def _load_open_mode(self):
        """★ 저장·읽기는 `video_open` 한 문이다 — 옛 열쇠도 그것이 옮겨 읽는다."""
        return VO.get_mode(self.db_path)

    def _save_open_mode(self):
        VO.set_mode(self._open_mode.get(), self.db_path)

    def _play_or_open(self, mid):
        """YouTube → 우측 인라인 재생 / 비-YouTube → 브라우저."""
        try:
            with appdb.connect(self.db_path) as conn:
                if isinstance(mid, tuple):     # 내 링크
                    row = conn.execute(
                        'SELECT url FROM userdb.user_media_asset '
                        'WHERE user_media_id=?', (mid[1],)).fetchone()
                elif mid > 0:
                    row = conn.execute(
                        'SELECT url FROM sys_media_asset WHERE media_id=?', (mid,)
                    ).fetchone()
                else:
                    row = conn.execute(
                        'SELECT url FROM sys_ref_asset WHERE ref_id=?', (-mid,)
                    ).fetchone()
            if not (row and row[0]):
                return
            url = row[0]
            # ★★ **라디오가 정한다** (2026-09-09 0.txt 1-2) — 「유튜브로 열기」
            #   면 브라우저, 「온라인영상 탭에서 열기」면 P4 로 보낸다.
            #   ⚠ 유튜브가 아닌 주소는 어느 쪽이든 **브라우저**다(P4 플레이어가
            #     못 연다) — 조용히 아무 일도 안 하지 않는다.
            vid = _yt_id(url)
            mode = (self._open_mode.get() if hasattr(self, '_open_mode')
                    else VO.get_mode(self.db_path))
            # ★★ **앱 안에서 여는 갈래 둘은 P4 「온라인 영상」 탭이 맡는다** —
            #   거기가 저장값을 다시 읽어 임베드로 틀지 유튜브 쪽을 열지 정한다.
            #   여기서 또 정하면 판단하는 자리가 둘이 된다.
            if vid and mode in ('EMBED', 'PAGE') and self._on_video_open:
                self._on_video_open(vid, self._title_of(mid))
                return
            # ★ 브라우저 — 앱 안에 또 다른 플레이어 창을 띄우지 않는다.
            webbrowser.open(url)
        except Exception as e:
            print(f'LinksPanel._play_or_open: {e}')


def count_split(db_path, verse_id, lang='KO', ui_lang=None):
    """영상/텍스트 갈래 배지용 분리 개수 {'lvideo': n, 'ltext': n} (2026-08-26 2안).

    ★ 목록과 같은 코드(`_fetch` 셔틀)와 같은 기준(`_is_text_row`)으로 센다 —
      갈라지면 「배지는 3인데 목록은 2」가 된다."""
    out = {'lvideo': 0, 'ltext': 0}
    if not verse_id:
        return out
    try:
        from types import SimpleNamespace
        # ★ `lang` = 거를 언어(None = 전체) · `ui_lang` = 제목을 읽을 언어
        #   (2026-10-09 1.txt 59-1 — 배지는 그 갈래 콤보가 고른 언어로 센다).
        shim = SimpleNamespace(
            db_path=db_path,
            lang_getter=lambda: (ui_lang or lang or 'KO'),
            _lang_sel=None, _lang_only=lambda: lang)
        for r in (LinksPanel._fetch(shim, int(verse_id)) or []):
            if _is_text_row(r['media_id'], r['media_type'], r['format_type']):
                out['ltext'] += 1
            else:
                out['lvideo'] += 1
    except Exception:
        pass
    return out


def count_for(db_path, verse_id, lang='KO'):
    """P2 탭 배지용 개수 (2026-08-19 0.txt ①).

    ★ 패널의 `_fetch` **그 코드를 그대로** 셔틀 객체로 재사용한다 — 세는 기준이
      목록과 갈라지면(드리프트) 「3인데 탭에는 2개」가 된다."""
    if not verse_id:
        return 0
    try:
        from types import SimpleNamespace
        # ⚠ `_fetch` 가 읽는 속성 전부를 채운다 — lang_getter 를 빠뜨리면
        #   예외→0 으로 조용히 죽는다(실측으로 잡음). 언어 필터는 패널 기본값
        #   (전체언어)과 같게 둔다.
        shim = SimpleNamespace(
            db_path=db_path,
            lang_getter=lambda: (lang or 'KO'),
            # ★ 배지는 **설정 언어 기준**(0.txt 1-3 사용자 지시 —
            #   「이미 설정된 언어코드를 기준으로 필터링 된 갯수만」).
            _lang_sel=None, _lang_only=lambda: lang)
        return len(LinksPanel._fetch(shim, int(verse_id)) or [])
    except Exception:
        return 0
