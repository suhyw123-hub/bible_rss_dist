#!/usr/bin/env python3
"""
collect_channels.py — 등록 채널 자동수집 CLI 스크립트
Windows Task Scheduler 에서 직접 호출되거나 수동으로 실행합니다.
(자동크롤러 화면의 「자동수집 설정」이 이 파일을 등록한다 — 매일 03:00)

★★★ **RSS 를 먼저 쓴다** (2026-09-05 사용자 확정 — 「유투브 RSS를 통해서 한
  채널당 15개 최신 자료를 가져온다면 좋다. **API 사용한도가 매우 부담스럽다**」).
  차례 = **① RSS(쿼터 0) → ② 남은 채널만 API**.
  ⚠ **스케줄러를 하나 더 만들지 않는다** — 이미 등록된 이 작업이 그대로 돈다.

  | | RSS | API(playlistItems) |
  |---|---|---|
  | 쿼터 | **0** | 채널당 1 unit |
  | 한 번에 | 최신 15개 | max_results |
  | 설명문 | **전문**(실측 816~1,670자) | snippet |
  | 못 하는 것 | `@handle`·과거 영상 | — |

  ⇒ `@handle` 이거나 RSS 가 실패한 채널만 ②로 내려간다.

⚠⚠ **API 경로가 `link_media` 를 안 부르고 있었다**(2026-09-05 실측으로 잡았다).
  관리자 화면(`panel_media_channel`)은 부르는데 **스케줄러가 부르는 이 파일에는
  없어서**, 03:00 에 들어온 것은 구간·용어 연결이 하나도 없는 채로 보관함에
  쌓였다. 설명문(`yt_desc`)도 안 담고 있었다. 둘 다 채웠다.

사용법:
  python collect_channels.py           # 기한 초과 채널만 (기본)
  python collect_channels.py --force   # 기한 무시, 전체 활성 채널
  python collect_channels.py --api-only  # RSS 를 건너뛴다(옛 동작)
  python collect_channels.py --rss-only  # API 를 아예 안 쓴다(쿼터 0)
"""
import sys
import os
import json
import argparse
import sqlite3
import appdb
import media_link
import media_exclude
import db_media_crawler as _crawler
from datetime import date, datetime

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

_DEFAULT_WORSHIP_KW = [
    '찬양', '찬송', 'ccm', '워십', '경배와찬양', '경배',
    'worship', 'praise', 'hymn', ' song', 'anthem', 'live worship',
    'hillsong', 'bethel', 'elevation worship', 'maverick city', 'passion',
    'chris tomlin', 'kari jobe', 'lauren daigle',
]
_DEFAULT_SERMON_KW = [
    '설교', '강해', '강의', '묵상', '성경공부', '큐티', '말씀',
    'sermon', 'teaching', 'bible study', 'expository', 'commentary',
    'preaching', 'message', 'devotional', 'exposition', 'exegesis',
]


def _db():
    return appdb.connect(DB)


def _get_yt_keys():
    try:
        conn = _db()
        row = __import__('secret_store').row('YOUTUBE_API_KEYS')  # 열쇠는 배포 DB 밖(2026-10-11)
        conn.close()
        return [k.strip() for k in row[0].split(',') if k.strip()] if row else []
    except Exception:
        return []


# ⚠⚠ **옛 두 갈래 분류(`_load_classify_kw`·`_classify`)를 걷었다**(2026-09-08).
#   SERMON/WORSHIP 만 냈고 언어를 안 봐서 **STUDY·FILM 이 나올 수 없었다.**
#   분류는 `media_intake` → `media_taxonomy.classify_content` 하나가 한다.
#   ★ 죽은 코드를 남겨 두면 다음에 누가 다시 쓴다(§199차 그 자리).


def _save_config(conn, key, val):
    conn.execute(
        "INSERT OR REPLACE INTO sys_config (config_key, config_val) VALUES (?,?)",
        (key, str(val))
    )


def _rss_phase(force):
    """① RSS 로 먼저 훑는다 → (탈 없이 끝낸 채널 번호, 저장 건수).

    ⚠ **여기서 예외가 나도 API 경로를 막지 않는다** — RSS 가 안 되면 옛 길로
      그대로 간다(조용히 아무것도 안 하는 것이 가장 나쁘다).
    """
    try:
        import db_yt_rss_collect as RSS
    except Exception as e:
        print('[알림] RSS 수집기를 못 불러왔습니다 — API 로만 진행: %s' % e)
        return set(), 0
    conn = _db()
    try:
        print('── ① RSS 수집 (쿼터 0)')
        r = RSS.collect(conn, ignore_due=force, on_step=lambda s: print('  ' + s))
        print('  RSS: 채널 %d · 본 것 %d · **신규 %d** · 이미있음 %d'
              ' · 무관 %d · 쇼츠 %d'
              % (r['channels'], r['seen'], r['new'], r['dup'],
                 r['off'], r['short']))
        for nm, msg in r['err'][:5]:
            print('    ⚠ %s — %s' % (nm, msg))
        if len(r['err']) > 5:
            print('    … 그 밖 %d건' % (len(r['err']) - 5))
        # ★★★ **`saved`(정말 담은 것)를 돌려준다 — `new` 가 아니다.**
        #   `new` 는 쇼츠·이미있음을 못 빼서 부푼다(2026-09-12 실측으로 잡았다).
        #   ⚠ 옛 판이 `new` 를 돌려주어 화면 「수집 건수」가 실제보다 컸다.
        return r['done'], r.get('saved', r['new'])
    except Exception as e:
        print('[알림] RSS 수집 중단 — API 로 이어갑니다: %s' % e)
        return set(), 0
    finally:
        conn.close()


#: 찬양·성경듣기 특수검색 한 바퀴를 **어떻게** 다루나 (2026-09-16 · 1.txt 16번) —
#:   'BOTH' 옛 동작(매일 작업 끝에 함께) · 'SKIP' 일반 작업만(`--no-worship`) ·
#:   'ONLY' 특수검색만(`--worship-only`). 두 작업을 다른 요일에 두어 쿼터를 나눈다.
WORSHIP_MODE = 'BOTH'
#: ★ 채널 자동 발굴(2026-09-16 · 1.txt 17-1 (3)) — 제 작업으로만 돈다(`--discover-only`).
#:   일반 작업에 안 붙인 까닭 = 검색 한 번 100 units 라 요일을 갈라 쿼터를 나눈다(사용자
#:   「수집날자를 서로 구분해서 운영하면 토큰 사용한도 문제 해결」).
DISCOVER_MODE = 'SKIP'
#: ★ 기도 특수검색(2026-10-12 사용자 「기도 채널 수집 일정 — 별도로 등록하는 것이 좋다면 추가로」) —
#:   'BOTH' 옛 동작(특수 한 바퀴에 함께) · 'SKIP' 특수 작업에서 뺀다(제 작업이 따로 돈다) ·
#:   'ONLY' 기도만(`--prayer-only`). 특수 작업(`--worship-only`)은 이제 기도를 안 돈다.
PRAYER_MODE = 'BOTH'


#: 채널 수집에서 `playlistItems`(1 unit)가 실패했을 때 `search`(100 units)로 대신할 상한(2026-09-17).
FALLBACK_MAX = 5


def collect(force=False, use_rss=True, use_api=True):
    # ★ 구글 클라우드 일시 중단(2026-09-16 · `gcloud_gate`) — API 수집은 건너뛰고 RSS·자동 승인만 돈다.
    import gcloud_gate as _GG
    if _GG.paused() and use_api:
        print('[일시 중단] ' + _GG.MSG + ' — API 수집(②)은 건너뛰고 RSS 만 돕니다.')
        use_api = False
    if DISCOVER_MODE == 'ONLY':
        print('── 채널 자동 발굴만 돕니다(씨앗 낱말 → 후보 + 심사 · 등록은 사람이)')
        _discover_round()
        return
    if PRAYER_MODE == 'ONLY':
        print('── 기도 자동수집(기도 특수검색어)만 돕니다')
        _prayer_round()
        return
    if WORSHIP_MODE == 'ONLY':
        print('── 특수 자동수집(성경듣기 · 찬양 특수검색어)만 돕니다')
        _worship_round()
        return
    rss_done, rss_saved = (_rss_phase(force) if use_rss else (set(), 0))

    if not use_api:
        print('\n완료: RSS 로 %d건 저장. (API 안 씀)' % rss_saved)
        # ⚠ **여기서도 자동 승인을 부른다** — 이른 반환이 그 걸음을 건너뛰면
        #   `--rss-only` 로 돌린 날만 대기줄이 쌓인다.
        _auto_approve()
        _artist_link()
        _link_check()
        _worship_round()
        _skip_sweep()
        return

    keys = _get_yt_keys()
    if not keys:
        print('[오류] API 키 없음. 관리자 앱에서 YouTube API 키를 먼저 등록하세요.')
        return

    try:
        from googleapiclient.discovery import build as yt_build
    except ImportError:
        print('[오류] google-api-python-client 미설치. pip install google-api-python-client')
        return

    conn = _db()
    # ⚠ 옛 두 갈래 분류 낱말은 **더 안 읽는다** — 공통 문이 11언어 규칙을 쓴다.

    try:
        excl_channels = {
            r[0].lower()
            for r in conn.execute(
                "SELECT channel_name FROM sys_media_excluded_channel "
                "WHERE record_status='LIVE'"
            ).fetchall()
        }
    except Exception:
        excl_channels = set()

    where = "WHERE c.enabled=1 AND c.record_status='LIVE'"
    if not force:
        today_s = date.today().isoformat()
        where += (
            " AND (c.last_checked IS NULL"
            f" OR date(c.last_checked, '+' || c.check_interval_days || ' days') <= '{today_s}')"
        )

    import media_intake as _MI
    _MI.ensure_channel_audience(conn)
    channels = conn.execute(f"""
        SELECT c.channel_id, c.channel_ext_id, c.channel_name,
               c.lang_code, c.scope, c.entity_id,
               c.last_checked, c.max_results,
               -- ★ 채널이 정한 대상(GENERAL·KIDS·SIGN) — 2026-09-08 수화 축.
               --   ⚠ 그전(is_kids)엔 스케줄러 경로가 어린이 표시를 유실했었다.
               {_MI.channel_aud_sql('c')}, {_MI.channel_sign_sql('c', conn)}
        FROM sys_media_channel c
        {where}
        ORDER BY c.last_checked ASC NULLS FIRST
    """).fetchall()

    # ★ RSS 가 이미 끝낸 채널은 **API 로 다시 긁지 않는다**(쿼터를 아끼는 자리).
    if rss_done:
        before = len(channels)
        channels = [c for c in channels if c[0] not in rss_done]
        print('── ② API 수집 — RSS 가 끝낸 %d개를 뺀다 (%d → %d)'
              % (len(rss_done), before, len(channels)))
    else:
        print('── ② API 수집')

    started_at = datetime.now().strftime('%Y-%m-%d %H:%M')
    _fallback = [0]                      # search 폴백을 몇 번 썼나(100 units 씩)
    print(f'[{started_at}] 수집 시작 — 대상 채널 {len(channels)}개 (force={force})')

    if not channels:
        print('API 로 더 볼 채널이 없습니다.')
        _save_config(conn, 'CHANNEL_COLLECT_LAST_RUN', started_at)
        _save_config(conn, 'CHANNEL_COLLECT_LAST_COUNT', rss_saved)
        conn.commit()
        conn.close()
        print(f'\n완료: 총 {rss_saved}건 저장 (RSS {rss_saved} · API 0). ({started_at})')
        _auto_approve()
        _artist_link()
        _link_check()
        _worship_round()
        _skip_sweep()
        return

    key_idx = [0]
    def get_key():
        return keys[key_idx[0] % len(keys)]
    def rotate_key():
        key_idx[0] += 1

    total_saved = 0
    total_off = 0
    today_s = date.today().isoformat()
    # ★★★ **공통 품질관리 문**(2026-09-08 사용자 지시) — 문지기·분류·저장·연결을
    #   한 차례로 한다. 제외 낱말·분류 규칙·언어별 컨텍스트를 **한 번만** 읽어
    #   돌려 쓰므로 채널마다 다시 읽지 않는다.
    _gate = _MI.Gate(conn)

    for ch in channels:
        (cid, ext_id, name, lang, scope, entity_id, last_checked, max_r,
         ch_aud, ch_sign) = ch
        print(f'\n[{name}]  {ext_id}')

        actual_id = ext_id
        if ext_id.startswith('@'):
            try:
                yt  = yt_build('youtube', 'v3', developerKey=get_key(), cache_discovery=False)
                res = yt.channels().list(part='id', forHandle=ext_id[1:]).execute()
                items = res.get('items', [])
                if items:
                    actual_id = items[0]['id']
                    conn.execute(
                        "UPDATE sys_media_channel SET channel_ext_id=? WHERE channel_id=?",
                        (actual_id, cid))
                    print(f'  핸들 해석: {actual_id}')
                else:
                    print(f'  [경고] 핸들 {ext_id} 해석 실패. 건너뜀.')
                    continue
            except Exception as e:
                print(f'  [오류] 핸들 해석: {e}')
                continue

        upload_pl = 'UU' + actual_id[2:]
        try:
            yt   = yt_build('youtube', 'v3', developerKey=get_key(), cache_discovery=False)
            resp = yt.playlistItems().list(
                playlistId=upload_pl, part='snippet', maxResults=max_r
            ).execute()
        except Exception as e:
            print(f'  [오류] playlistItems: {e}')
            # ⚠⚠⚠ **폴백은 100배 비싸다**(playlistItems 1 · search 100) — 2026-09-17 점검.
            #   ⓐ 없는 채널·쿼터 소진이면 **폴백해도 헛돈다** ⓑ 한 바퀴에 몇 번까지만 쓴다.
            #   안 그러면 전송 오류가 번지는 날 하루 쿼터가 폴백으로 통째로 날아간다.
            _msg = str(e)
            if any(w in _msg for w in ('404', 'playlistNotFound', 'quota', '403')):
                print('  폴백 안 함(없는 채널·쿼터) — 1 unit 자리에 100 units 를 쓰지 않는다')
                rotate_key()
                continue
            if _fallback[0] >= FALLBACK_MAX:
                print(f'  폴백 상한({FALLBACK_MAX}회) — 건너뜀')
                rotate_key()
                continue
            _fallback[0] += 1
            rotate_key()
            try:
                resp2 = yt.search().list(
                    channelId=actual_id, part='snippet', type='video',
                    order='date', maxResults=max_r
                ).execute()
                resp = {'items': []}
                for it in resp2.get('items', []):
                    vid = it['id'].get('videoId', '')
                    if vid:
                        snip = it['snippet']
                        resp['items'].append({'snippet': {
                            'resourceId': {'videoId': vid},
                            'title': snip.get('title', ''),
                            'channelTitle': snip.get('channelTitle', ''),
                            'publishedAt': snip.get('publishedAt', ''),
                        }})
                print(f'  search.list 폴백 사용')
            except Exception as e2:
                print(f'  [오류] 폴백도 실패: {e2}')
                continue

        saved = 0
        skipped_off = 0
        off_ex = []
        for item in resp.get('items', []):
            snip    = item.get('snippet', {})
            vid_id  = snip.get('resourceId', {}).get('videoId', '')
            if not vid_id:
                continue
            title     = snip.get('title', '')
            ch_title  = snip.get('channelTitle', '')
            published = (snip.get('publishedAt') or '')[:10]
            vdesc     = snip.get('description') or ''

            if last_checked and published and published < last_checked:
                continue
            if ch_title.lower() in excl_channels:
                continue

            url_v  = f'https://www.youtube.com/watch?v={vid_id}'
            exists = conn.execute(
                "SELECT media_id FROM sys_media_asset WHERE url=?", (url_v,)
            ).fetchone()  # status-ok: 주소 중복 확인 — 상태로 거르면 사용자가 숨긴 영상이 새 줄로 되살아난다

            # ⚠ URL 중복 판정·오프토픽 문지기도 **공통 문이 한다** —
            #   여기서 미리 보면 규칙이 두 곳이 된다.

            # ★★★ **공통 품질관리 문**(2026-09-08 사용자 지시 — 「어떤 방법으로
            #   수집했던지 공통적으로 거쳐야 할 품질관리는 반드시 거치도록」).
            #   ⚠⚠ 그전에는 여기서 `_classify`(SERMON/WORSHIP **두 갈래**)를
            #     썼다 — **STUDY·FILM 이 나올 수 없고** 언어도 안 봤다. 그리고
            #     `audience` 를 아예 안 담아 어린이 채널 표시가 유실됐다.
            #   ★ 이 경로가 **매일 자동으로 도는 자리**라 가장 값이 크다.
            _out = _MI.admit(_gate, {
                'title': title, 'url': url_v, 'lang_code': lang,
                'channel': ch_title, 'published': published,
                'yt_desc': vdesc, 'audience': ch_aud, 'sign_code': ch_sign,
                'allow_short': scope == 'PRAYER',          # 기도 채널 — 1분 기도도 담는다
            }, domain='CHANNEL')     # 등록 채널 — 찬양 면제 낱말이 듣는다(2026-09-16)
            if _out['action'] == _MI.SKIP_OFFTOPIC:
                skipped_off += 1
                if len(off_ex) < 3:
                    off_ex.append(title[:70])
                continue
            if _out['action'] in (_MI.SKIP_CHANNEL, _MI.SKIP_NO_URL, _MI.SKIP_CHANNEL_KW):
                print('  [%s] %s' % (_out['action'], title[:40]))
                continue
            mid = _out['media_id']
            if _out['action'] == _MI.ACT_NEW:
                saved += 1
                if scope == 'PRAYER' and mid:     # ★ 기도 채널(기도 수집기 ③)이 올린 것은 기도다
                    conn.execute("UPDATE sys_media_asset SET media_type='PRAYER' WHERE media_id=?", (mid,))

            # ⚠⚠⚠ **채널 단위 용어 연결(`scope='ENTITY'`)을 걷었다**
            #   (2026-09-11 사용자 「지금 이런 구분이 의미가 있는가? 필요
            #   없다면 … 제거하라」). 실측 등록 채널 **269개가 전부 `GENERAL`**
            #   이고 `entity_id` 가 있는 채널이 **0개**라 이 가지는 한 번도
            #   돈 적이 없다.
            #   ★★★ 그리고 **돌았다면 해로웠다** — 그 채널의 영상이 내용과
            #     상관없이 **전부 한 용어에 걸린다.** 그것이 사용자가 손으로
            #     264건을 뗀 바로 그 꼴이다. 용어는 **제목·설명문을 읽어**
            #     영상마다 거는 것이 맞다(`media_intake.connect`).

        conn.execute(
            "UPDATE sys_media_channel SET last_checked=? WHERE channel_id=?",
            (today_s, cid))
        conn.commit()
        total_saved += saved
        total_off += skipped_off
        print(f'  → {saved}건 저장')
        # ⚠ **조용히 버리지 않는다** — 몇 건을 왜 안 받았는지 말한다.
        if skipped_off:
            print(f'  → 본문과 무관해 안 받음 {skipped_off}건')
            for _e in off_ex:
                print(f'       {_e}')

    # ⚠⚠ **시각과 건수의 시점을 맞춘다**(2026-09-12 사용자 「오늘 12시
    #   자동수집한 갯수가 2만개가 넘는다」로 잡았다). 그전에는 시각이
    #   **시작**(12:43)이고 건수는 **끝났을 때**(14시)라 두 값이 다른 때를
    #   가리켰다 — 사람이 「12시에 2만」으로 읽는다.
    _ended_at = datetime.now().strftime('%Y-%m-%d %H:%M')
    _save_config(conn, 'CHANNEL_COLLECT_LAST_RUN',
                 '%s~%s' % (started_at, _ended_at[11:]))
    _save_config(conn, 'CHANNEL_COLLECT_LAST_COUNT', total_saved + rss_saved)
    conn.commit()
    conn.close()

    print(f'\n완료: 총 {total_saved + rss_saved}건 저장'
          f' (RSS {rss_saved} · API {total_saved}). ({started_at})')
    _auto_approve()
    _artist_link()
    _link_check()
    _worship_round()
    _skip_sweep()
    # ⚠⚠ **여기서 자동 배포를 돌리지 않는다**(2026-09-29 사용자 「매일 수집작업이
    #   끝난 직후 즉시 점검하면 안된다. **6시간 정도 시차**를 두어야 한다. 관리자가
    #   수작업 심사해야 하기 때문이다」). 자동 배포는 **독립 작업**
    #   `BibleMatrix_AutoDeploy`(`db_auto_publish.py --run`)이고 시각은 배포 센터 ▸
    #   자동 배포 탭에서 정한다(권장 = 수집 시각 + 6시간).


def _auto_approve():
    """③ **확실한 것을 자동 승인한다** (2026-09-06 사용자 지시 「미검토 건을
    네가 처리하라. **확실한 것을 우선 승인하라**」).

    ★ 매일 수집으로 바꾸면 실측 하루 **90~140편**이 들어온다 — 사람이 다 보면
      대기줄이 다시 쌓인다. **제목이 말하는 구절과 링크가 맞는 것**만 기계가
      승인하고 나머지는 사람에게 남긴다(`db_media_autoapprove`).
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다** — 수집은 이미 끝났다.
    """
    try:
        import db_media_autoapprove as AA
        conn = _db()
        try:
            print()
            print('── ③ 확실한 것 자동 승인')
            AA.run(conn)
            # ★ 예배 실황 보관함(2026-09-16) — 마디를 맞추고, 교회·설교 중심 채널 것은 승인
            try:
                import db_media_range as _MR
                _MR.sync_live_service_pending(conn)
                # ★ 교회 공식 채널의 설교(2026-09-17) — 보관함만이 아니라 **그 채널의 설교 전부**.
                #   `run_live_service` 는 이 문의 좁은 판이라 따로 안 부른다.
                AA.run_church_sermon(conn)
                AA.run_term(conn)          # 제목 근거 용어 연결이 살아 있는 것
            except Exception as _e:
                print('[알림] 채널 신뢰 승인 건너뜀: %s' % str(_e)[:90])
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 자동 승인 건너뜀: %s' % str(e)[:90])


def _skip_sweep():
    """⑦ **갈래 규칙 다시 걸기**(2026-09-12) — 분류가 바뀐 영상의 잘못된 용어
    연결을 걷는다.

    ★★★ `_ins_link` 는 **담을 때** 갈래를 본다. 분류가 나중에 찬양으로 바뀌면
      그때 걸린 「가사」 연결이 그대로 남는다(실측 5건이 다시 생겨 있었다).
    ⚠ 쿼터 0 · 사람이 이은 것은 안 건드린다.
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다.**
    """
    try:
        import media_text_linker as TL
        conn = _db()
        try:
            print()
            print('── ⑦ 갈래 규칙 다시 걸기')
            TL.sweep_skip(conn)
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 갈래 규칙 건너뜀: %s' % str(e)[:90])


def _artist_link():
    """⑤ **찬양 사역자 잇기**(2026-09-09) — 공식 채널의 새 영상을 그 사역자에.

    ★ 손으로 돌리면 잊는다 — 매일 작업에 붙어야 실제로 돈다(`_auto_approve` 와
      같은 자리). 쿼터 0(DB 만 본다).
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다.**
    """
    try:
        import db_worship_artist as WA
        conn = _db()
        try:
            print()
            print('── ⑤ 찬양 사역자 잇기')
            n = WA.autolink(conn)
            print('  영상 %d편을 사역자에 이었습니다.' % n)
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 사역자 잇기 건너뜀: %s' % str(e)[:90])


def _worship_round():
    """⑥ **찬양 검색어 한 바퀴**(2026-09-11 사용자 「이 기능도 **자동설정**하자」).

    ★★★ 언어마다 검색어 하나씩 — **갈래 셋**(연속듣기 · 일반 찬양 ·
      **사역자**)을 함께 돈다. `WC.KINDS` 를 그대로 돌므로 갈래를 늘리면
      **여기는 안 고쳐도 따라온다**.
      ✅ 실측이 이 걸음의 까닭을 받쳤다 — 찬양 검색어 75개 중 **59개(79%)가
        한 번도 안 돌았고** 돈 것은 **한국어 16개뿐**이었다. 사람이 콤보를
        일일이 골라야 했기 때문이다.
    ⚠ **쿼터를 쓴다** — 검색 한 번에 100 units 라 한 바퀴 ≈ **갈래마다**
      언어 수 × 100(실측 2026-09-26 — 연속듣기 1,100 · 일반 찬양 1,100 ·
      사역자 200 = **2,400 units**).
      끄려면 `sys_config['WORSHIP_ROUND_ON'] = '0'`.
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다.**
    """
    if WORSHIP_MODE == 'SKIP':
        return                       # 특수 자동수집 작업이 따로 돈다
    import gcloud_gate as _GG
    if _GG.paused():
        print('\n── ⑥ 찬양·성경듣기 한 바퀴 — 건너뜀: ' + _GG.MSG)
        return
    try:
        import db_worship_collect as WC
        conn = _db()
        try:
            row = conn.execute("SELECT config_val FROM sys_config"
                               " WHERE config_key='WORSHIP_ROUND_ON'").fetchone()
            if row and str(row[0]).strip() in ('0', 'off', 'OFF'):
                return
            keys = _get_yt_keys()
            if not keys:
                return
            print()
            print('── ⑥ 찬양 검색어 한 바퀴 (모든 언어)')
            # ★ **결과를 남긴다**(2026-09-25 · 1.txt 16-4 (3)) — 셋 가운데 특수
            #   자동수집만 기록이 없어 자동실행 화면이 「돌긴 돌았는데 무엇을
            #   건졌는지」를 말하지 못했다.
            _tot = {'new': 0, 'seen': 0}
            _at = datetime.now().strftime('%Y-%m-%d %H:%M')
            for code, ko in WC.KINDS:
                pl = WC.plan(conn, code)
                if not pl['rows']:
                    print('  [%s] 지정된 검색어가 없습니다 — ⑤ 설정에서 지정하세요.'
                          % ko)
                    continue
                print('  [%s] 검색어 %d개 중 안 돈 것 %d개 · 이번 %d개(%s) · %d units'
                      % (ko, pl['total'], pl['never'], len(pl['rows']),
                         ','.join(pl['langs']), pl['units']))
                out = WC.run(conn, keys, code,
                             log=lambda m: print('  ' + m))
                _tot['new'] += int(out['new'] or 0)
                _tot['seen'] += int(out['seen'] or 0)
                print('  [%s] 본 것 %d · **새것 %d** · 걸러짐 %d · 쓴 것 %d units'
                      % (ko, out['seen'], out['new'], out['skip'],
                         out['units']))
            # ★ 성경듣기도 한 바퀴 (2026-09-16 · 1.txt 16번) — 그전에는 찬양만 돌아
            #   성경듣기 검색어 14개가 이 걸음에 한 번도 안 들었다.
            # ★ 기도도 한 바퀴 (2026-10-12 사용자 「기도 유투브 채널 수집 — 다른 것들과 동일한 방식」)
            # ★ 2026-10-23 성지·유적(SITE)도 한 바퀴(사용자 「성지유적 유투브 수집분야를 열어야 한다」)
            for _dom in (('READING', 'SITE') if PRAYER_MODE in ('SKIP', 'SEPARATE') else ('READING', 'PRAYER', 'SITE')):
                _dko = WC.DOMAIN_LABEL.get(_dom, _dom)
                pl = WC.plan(conn, None, domain=_dom)
                if not pl['rows']:
                    continue
                print('  [%s] 검색어 %d개 중 안 돈 것 %d개 · 이번 %d개(%s) · %d units'
                      % (_dko, pl['total'], pl['never'], len(pl['rows']),
                         ','.join(pl['langs']), pl['units']))
                out = WC.run(conn, keys, None, domain=_dom,
                             log=lambda m: print('  ' + m))
                _tot['new'] += int(out['new'] or 0)
                _tot['seen'] += int(out['seen'] or 0)
                print('  [%s] 본 것 %d · **새것 %d** · 걸러짐 %d · 쓴 것 %d units'
                      % (_dko, out['seen'], out['new'], out['skip'], out['units']))
            # ⚠ **한 바퀴를 실제로 돈 때만 적는다** — 검색어가 하나도 지정되지
            #   않아 아무것도 안 돌았으면 옛 기록을 0 으로 덮지 않는다(§0-1
            #   「안 돈 것」과 「0건」은 다른 사실이다).
            if _tot['seen'] or _tot['new']:
                _save_config(conn, 'WORSHIP_ROUND_LAST_RUN', _at)
                _save_config(conn, 'WORSHIP_ROUND_LAST_COUNT',
                             '%d/%d' % (_tot['new'], _tot['seen']))
                conn.commit()
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 찬양 한 바퀴 건너뜀: %s' % str(e)[:90])


def _prayer_round():
    """⑦ **기도 검색어 한 바퀴**(2026-10-12 · 제 작업 `BibleMatrix_PrayerCollect`).

    찬양·성경듣기 한 바퀴(⑥)에 섞여 돌던 것을 떼어 냈다 — 요일을 따로 정해 쿼터를 나눈다
    (사용자 「수집날자를 서로 구분해서 운영하면 토큰 사용한도 문제 해결」).
    검색어 = 기도 수집기 ③(`sys_mine_keyword` domain PRAYER) · 숏츠도 담는다(1분 기도).
    결과 = `PRAYER_ROUND_LAST_RUN`·`_COUNT`(새것/본 것) — 자동실행 화면이 읽는다.
    ⚠ 여기서 터져도 수집을 실패로 만들지 않는다.
    """
    import gcloud_gate as _GG
    if _GG.paused():
        print()
        print('── ⑦ 기도 한 바퀴 — 건너뜀: ' + _GG.MSG)
        return
    try:
        import db_worship_collect as WC
        conn = _db()
        try:
            keys = _get_yt_keys()
            if not keys:
                return
            pl = WC.plan(conn, None, domain='PRAYER')
            print()
            print('── ⑦ 기도 검색어 한 바퀴 (모든 언어)')
            if not pl['rows']:
                print('  [기도] 지정된 검색어가 없습니다 — 기도 수집기 ③에서 지정하세요.')
                return
            print('  [기도] 검색어 %d개 중 안 돈 것 %d개 · 이번 %d개(%s) · %d units'
                  % (pl['total'], pl['never'], len(pl['rows']), ','.join(pl['langs']), pl['units']))
            out = WC.run(conn, keys, None, domain='PRAYER', log=lambda m: print('  ' + m))
            print('  [기도] 본 것 %d · **새것 %d** · 걸러짐 %d · 쓴 것 %d units'
                  % (out['seen'], out['new'], out['skip'], out['units']))
            if out['seen'] or out['new']:
                _save_config(conn, 'PRAYER_ROUND_LAST_RUN', datetime.now().strftime('%Y-%m-%d %H:%M'))
                _save_config(conn, 'PRAYER_ROUND_LAST_COUNT', '%d/%d' % (out['new'], out['seen']))
                conn.commit()
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 기도 한 바퀴 건너뜀: %s' % str(e)[:90])


def _discover_round():
    """⑧ **채널 자동 발굴 한 바퀴**(2026-09-16 · 1.txt 17-1 (3)) — 지정한 씨앗 낱말
    몇 개로 새 채널을 찾아 후보에 담고 심사까지 한다. **등록은 사람이**(후보 표에
    `자동:낱말` · `자동심사 등급` 으로 남는다 — ① 채널 ▸ 기존 수집분 재심사).

    ✅ 실측이 까닭이다 — COMMON 씨앗 305개 중 **296개가 한 번도 안 돌았다**(사람이 씨앗을
      골라 [발굴 실행]을 눌러야 돌았다). 찬양 한 바퀴(⑥)가 79% 미실행을 푼 그 자리다.
    ⚠ 쿼터 — 씨앗 하나 100 units · 기본 5개. `sys_config[CHANNEL_DISCOVER_KW]` 로 조절.
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다.**
    """
    import gcloud_gate as _GG
    if _GG.paused():
        print('\n── ⑧ 채널 자동 발굴 — 건너뜀: ' + _GG.MSG)
        return
    try:
        import db_channel_mine as CM
        conn = _db()
        try:
            keys = _get_yt_keys()
            print()
            print('── ⑧ 채널 자동 발굴 한 바퀴')
            out = CM.auto_discover(conn, keys, log=print, db_path=DB)
            _save_config(conn, 'CHANNEL_DISCOVER_LAST_RUN',
                         datetime.now().strftime('%Y-%m-%d %H:%M'))
            _save_config(conn, 'CHANNEL_DISCOVER_LAST_COUNT',
                         '%s/%s' % (out.get('new', 0), out.get('seen', 0)))
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 채널 자동 발굴 건너뜀: %s' % str(e)[:90])


def _link_check():
    """④ **링크 점검**(2026-09-08 사용자 지시 「링크점검은 하나만 · 휴면 →
    재점검 → 그래도 죽어 있으면 제거」).

    ★ 실측 18,380건 중 **1.5%** 만 점검돼 있었다 — 사람이 눌러야 돌았기
      때문이다. 매일 작업에 붙어야 실제로 돈다. 하루 예산은
      `db_media_linkcheck.DAILY_MAX`(API 50개당 1 unit).
    ⚠ **여기서 터져도 수집을 실패로 만들지 않는다.**
    """
    import gcloud_gate as _GG
    if _GG.paused():
        print('\n── ④ 링크 점검 — 건너뜀(videos.list 도 API 다): ' + _GG.MSG)
        return
    try:
        import db_media_linkcheck as LC
        conn = _db()
        try:
            print()
            print('── ④ 링크 점검(휴면 재점검 → 미점검·오래된 것)')
            LC.run(conn)
            # ★ 등록 채널 주소도 함께(2026-09-16 · 1.txt 17-3) — 50개당 1 unit · 2,434곳 ≈ 49
            print('── ④-2 등록 채널 주소 점검(channels.list)')
            LC.check_channels(conn, keys=_get_yt_keys() or None)
        finally:
            conn.close()
    except Exception as e:
        print('[알림] 링크 점검 건너뜀: %s' % str(e)[:90])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='등록 채널 YouTube 수집')
    parser.add_argument('--force', action='store_true',
                        help='기한 무시하고 전체 활성 채널 수집')
    parser.add_argument('--api-only', action='store_true',
                        help='RSS 를 건너뛴다(옛 동작)')
    parser.add_argument('--rss-only', action='store_true',
                        help='API 를 아예 안 쓴다(쿼터 0)')
    parser.add_argument('--no-worship', action='store_true',
                        help='찬양·성경듣기 특수검색 한 바퀴를 건너뛴다(일반 자동수집 작업)')
    parser.add_argument('--worship-only', action='store_true',
                        help='찬양·성경듣기 특수검색 한 바퀴만 돈다(특수 자동수집 작업)')
    parser.add_argument('--prayer-only', action='store_true',
                        help='기도 특수검색 한 바퀴만 돈다(기도 자동수집 작업)')
    parser.add_argument('--with-prayer', action='store_true',
                        help='특수 자동수집 한 바퀴에 기도도 함께 돈다(옛 동작 · 기도 작업을 따로 안 둘 때)')
    parser.add_argument('--discover-only', action='store_true',
                        help='채널 자동 발굴 한 바퀴만 돈다(씨앗 낱말 → 후보+심사 · 등록은 사람이)')
    args = parser.parse_args()
    if args.discover_only:
        DISCOVER_MODE = 'ONLY'
    if args.prayer_only:
        PRAYER_MODE = 'ONLY'
    elif args.worship_only and not args.with_prayer:
        PRAYER_MODE = 'SEPARATE'          # ★ 특수 작업은 기도를 안 돈다(제 작업이 돈다)
    if args.worship_only:
        WORSHIP_MODE = 'ONLY'
    elif args.no_worship:
        WORSHIP_MODE = 'SKIP'
    collect(force=args.force,
            use_rss=not args.api_only,
            use_api=not args.rss_only)
