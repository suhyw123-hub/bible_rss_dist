"""
miracle_builder.py
------------------
기적묵상 플랜 빌더 (MiraclePlanBuilderDialog).

필터 선택 → 유닛 미리보기 → sys_bible_plan 생성.
데이터 원본: miracle_pool / miracle_unit_pool (db_miracle_schema.py, db_miracle_units.py 로 구축).

사용:
    python miracle_builder.py          # 독립 실행
    from miracle_builder import MiraclePlanBuilderDialog
"""

import json
import i18n
import re
import sqlite3
import appdb
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from plan_builder import (FilterRow, check_plan_name,   # 두 만들기 화면의 단일 소스
                          unique_sibling_name)

DB_PATH = "bible_master.db"

# 기적묵상 사용자 플랜의 기원 sys 플랜 (§8 `MIRACLE_PLAN`)
MIRACLE_ANCHOR = 30

# ────────────────────────────────────────────────────────────────────
# 마스터 상수
# ────────────────────────────────────────────────────────────────────

PERIODS = ['OT', 'NT_JESUS', 'NT_APOSTLE']
PERIOD_KO = {
    'OT':          '구약',
    'NT_JESUS':    '신약(예수님)',
    'NT_APOSTLE':  '신약(사도)',
}

AGENTS = ['GOD_DIRECT', 'PROPHET_OT', 'JESUS', 'APOSTLE']
AGENT_KO = {
    'GOD_DIRECT':  '하나님 직접',
    'PROPHET_OT':  '구약 선지자',
    'JESUS':       '예수 그리스도',
    'APOSTLE':     '사도/제자',
}

MIRACLE_TYPES = [
    'NATURE', 'HEAL', 'EXORCISM', 'PROVISION',
    'RESURRECTION', 'JUDGMENT', 'TRANSFORM', 'DELIVERANCE',
]
MTYPE_KO = {
    'NATURE':       '자연 주권',
    'HEAL':         '치유',
    'EXORCISM':     '영적 해방',
    'PROVISION':    '공급',
    'RESURRECTION': '부활',
    'JUDGMENT':     '심판',
    'TRANSFORM':    '변환',
    'DELIVERANCE':  '구출',
}
# 유형별 정렬 우선순위
MTYPE_ORDER = {t: i for i, t in enumerate(MIRACLE_TYPES)}

# DB 저장값 (내부용)
TYPOLOGIES_DB = ['TYPE', 'FULFILL_SURPASS', 'UNIQUE_OT', 'UNIQUE_NT']
# 필터 UI 표시값 (UNIQUE_OT + UNIQUE_NT → 'UNIQUE' 통합)
TYPOLOGIES_UI = ['TYPE', 'FULFILL_SURPASS', 'UNIQUE']
TYPO_KO = {
    'TYPE':            '예표(구약)',
    'FULFILL_SURPASS': '성취+초월(신약)',
    'UNIQUE':          '예표성취 무관',
    # 트리뷰 표시용 (DB값 → 한국어)
    'UNIQUE_OT':       '예표성취 무관',
    'UNIQUE_NT':       '예표성취 무관',
}

# 기독론: 필터 UI 제거. DB 컬럼은 expand 슬롯 신학 주석으로만 사용.
CHRISTO_KO = {
    'GT_CREATOR':  '창조주',
    'GT_MOSES':    '모세보다 크신 이',
    'GT_ELIJAH':   '엘리야보다 크신 이',
    'GT_PRIEST':   '대제사장',
    'KINGDOM_EXT': '왕국 확장',
    'ESCHATOLOGY': '종말 표적',
}

ORDER_MODES = [
    ('CHRONO',        '연대기 순'),
    ('BY_TYPE',       '기적 유형별'),
    ('TYPOLOGY_PAIR', '예표-성취 쌍'),
]


# ────────────────────────────────────────────────────────────────────
# 플랜명 자동 생성
# ────────────────────────────────────────────────────────────────────


def _readable(name, dflt):
    """사용자가 만든 플랜 이름을 사람이 읽는 말로 (2026-08-16).

    ⚠ 자동 이름이 `기적_3수행자_4유형_쌍순_26` 처럼 **코드**였다.
      밑줄을 공백으로, 끝의 두 자리 연도를 뗀다. 비면 기본 이름.
    """
    import re
    s = (name or '').replace('_', ' ')
    s = re.sub(r"\s*'?\d{2}\s*$", '', s)      # 끝의 `_26` · `'26`
    s = ' '.join(s.split())
    return s or dflt


def generate_miracle_plan_name(
    agents:     list[str],
    mtypes:     list[str],
    typologies: list[str],   # UI값: 'TYPE' / 'FULFILL_SURPASS' / 'UNIQUE'
    order_mode: str,
) -> str:
    parts = []
    yr = str(datetime.now().year)[-2:]

    all_a = set(agents)     == set(AGENTS)
    all_t = set(mtypes)     == set(MIRACLE_TYPES)
    all_y = set(typologies) == set(TYPOLOGIES_UI)

    if not all_a:
        ag = set(agents)
        if ag <= {'GOD_DIRECT', 'PROPHET_OT'}:  parts.append('구약')
        elif ag == {'JESUS'}:                    parts.append('예수기적')
        elif ag == {'APOSTLE'}:                  parts.append('사도기적')
        elif ag <= {'JESUS', 'APOSTLE'}:         parts.append('신약기적')
        else:                                    parts.append(f'{len(agents)}수행자')

    if not all_t:
        if len(mtypes) == 1:
            parts.append(MTYPE_KO[mtypes[0]])
        elif len(mtypes) <= 3:
            parts.append('·'.join(MTYPE_KO[t][:2] for t in mtypes))
        else:
            parts.append(f'{len(mtypes)}유형')

    if not all_y:
        pair = frozenset(typologies)
        labels = {
            frozenset(['TYPE']):                         '예표',
            frozenset(['FULFILL_SURPASS']):               '성취',
            frozenset(['TYPE', 'FULFILL_SURPASS']):       '예표+성취',
            frozenset(['UNIQUE']):                        '예표무관',
            frozenset(['TYPE', 'UNIQUE']):                '예표+무관',
            frozenset(['FULFILL_SURPASS', 'UNIQUE']):     '성취+무관',
        }
        parts.append(labels.get(pair, f'{len(typologies)}예표유형'))

    order_sh = {'CHRONO': '', 'BY_TYPE': '_유형순', 'TYPOLOGY_PAIR': '_쌍순'}
    #  ★ **앞에 붙던 `기적_` 를 뗐다** (2026-08-16 서브트리 도입).
    #    트리에서 이 플랜은 **「기적 묵상」 마디 아래**에 놓이므로 갈래말을 이름이
    #    또 말할 필요가 없다. 「기적 기적전체」 같은 겹침이 구조적으로 사라진다.
    base = '_'.join(parts) if parts else '전체'
    suffix = order_sh.get(order_mode, '')
    return f"{base}{suffix}_{yr}"


# ────────────────────────────────────────────────────────────────────
# 필터 한 줄 — plan_builder 와 **같은 것을 쓴다** (2026-08-16)
# ────────────────────────────────────────────────────────────────────
#  ⚠ 예전에는 `FilterGroup` 을 이 파일에 **베껴 두 벌**로 갖고 있었다. 한쪽만
#    고치면 두 만들기 화면의 배치가 갈린다 — 실제로 배치를 바꿀 때마다 두 번
#    고쳐야 했다. 이제 한 곳(`plan_builder.FilterRow`)만 고친다.

# ────────────────────────────────────────────────────────────────────
# 정렬 로직
# ────────────────────────────────────────────────────────────────────

def sort_units(units: list[dict], mode: str) -> list[dict]:
    if mode == 'CHRONO':
        return sorted(units, key=lambda u: u.get('chrono_order', 9999))

    if mode == 'BY_TYPE':
        return sorted(units, key=lambda u: (
            MTYPE_ORDER.get(u.get('miracle_type', ''), 99),
            u.get('chrono_order', 9999)
        ))

    if mode == 'TYPOLOGY_PAIR':
        type_units = [u for u in units if u.get('typology') == 'TYPE']
        fs_units   = [u for u in units if u.get('typology') == 'FULFILL_SURPASS']
        uniq_ot    = [u for u in units if u.get('typology') == 'UNIQUE_OT']
        uniq_nt    = [u for u in units if u.get('typology') == 'UNIQUE_NT']

        # OT TYPE 기적 → 짝 NT FULFILL_SURPASS 순서로 묶음
        result   = []
        used_fs  = set()

        for tu in sorted(type_units, key=lambda u: u.get('chrono_order', 9999)):
            result.append(tu)
            tu_id    = tu['miracle_id']
            for fsu in sorted(fs_units, key=lambda u: u.get('chrono_order', 9999)):
                if fsu['miracle_id'] in used_fs:
                    continue
                fsu_pairs = set((fsu.get('ot_pair_codes') or '').split(','))
                if tu_id in fsu_pairs:
                    result.append(fsu)
                    used_fs.add(fsu['miracle_id'])

        # 짝 없는 FULFILL_SURPASS
        for fsu in sorted(fs_units, key=lambda u: u.get('chrono_order', 9999)):
            if fsu['miracle_id'] not in used_fs:
                result.append(fsu)

        # 독자 기적
        result += sorted(uniq_ot, key=lambda u: u.get('chrono_order', 9999))
        result += sorted(uniq_nt, key=lambda u: u.get('chrono_order', 9999))
        return result

    return units


# ────────────────────────────────────────────────────────────────────
# MiraclePlanBuilderDialog
# ────────────────────────────────────────────────────────────────────

class MiraclePlanBuilderDialog(tk.Toplevel):
    """
    기적묵상 플랜 빌더.

    좌) 필터 패널 (시대·수행자·유형·예표·기독론) — 수직 스크롤
    우상) 순서 모드 라디오
    우중) 플랜명·버튼·유닛수
    우하) 매칭 유닛 미리보기 트리뷰
    """

    def __init__(self, parent, db_path=DB_PATH):
        super().__init__(parent)
        self.db_path    = db_path
        self.title(i18n.t('MB_WIN', '성경의 기적 만들기'))
        self.geometry('1040x700')
        self.resizable(True, True)
        self.minsize(860, 540)

        self._all_units: list[dict] = []
        self._filtered:  list[dict] = []
        self._order_var  = tk.StringVar(value='CHRONO')

        self._build_ui()
        self._load_units()
        self._refresh()
        self.grab_set()

    # ── UI 구성 ──────────────────────────────────────────────────────

    def _build_ui(self):
        """상단에 수행자·기적유형·예표관계·묵상순서를 좌우로 (2026-08-16 사용자 지시).

        ⚠ 필터를 전부 위로 올리면 **왼쪽 기둥이 빈다** — 좌우 분할을 없애고 한 기둥으로.
          인물묵상과 달리 여기에는 목록 기둥이 없다.
        """
        cb = self._refresh

        # ── 상단: 수행자 / 기적유형 / 예표관계 / 묵상순서 — 한 줄씩 ────────
        #  ⚠ 인물묵상과 **같은 배치**다(사용자 지시 2026-08-16). 위아래로 쌓고
        #    항목은 좌→우 한 줄. 묵상순서만 고르는 것이 하나라 라디오다.
        # ★ 2026-10-20 docs/1.txt 5-2 — 세 창 공통 틀(`builder_shell`)
        import builder_shell
        self._shell = builder_shell.Shell(self, self._create_plan)
        self._name_var = self._shell.name_var
        self._name_entry = self._shell.name_entry
        top = self._shell.filters
        self._fg_agent = FilterRow(top, 0, i18n.t('MB_AGENT', '수행자'), AGENTS,
                                   display=AGENT_KO, on_change=cb)
        self._fg_mtype = FilterRow(top, 1, i18n.t('MB_MTYPE', '기적유형'),
                                   MIRACLE_TYPES, display=MTYPE_KO, on_change=cb)
        self._fg_typo  = FilterRow(top, 2, i18n.t('MB_TYPOREL', '예표관계'),
                                   TYPOLOGIES_UI, display=TYPO_KO, on_change=cb)

        #  ⚠ 열 번호를 위 세 줄과 **똑같이** 맞춘다(라벨 0 · 구분선 2 · 항목 3).
        #    `columnspan` 으로 1번 칸부터 채우면 이 줄만 왼쪽으로 튀어나온다.
        #    「전체」가 없는 것은 고르는 것이 하나뿐이라 그렇다.
        ttk.Label(top, text=i18n.t('MB_MEDORDER2', '묵상순서')).grid(
            row=3, column=0, sticky='w', padx=(2, 8), pady=2)
        ttk.Separator(top, orient='vertical').grid(
            row=3, column=2, sticky='ns', padx=6, pady=1)
        order_box = ttk.Frame(top)
        order_box.grid(row=3, column=3, sticky='w')
        for val, label in ORDER_MODES:
            ttk.Radiobutton(order_box, text=label, variable=self._order_var,
                            value=val, command=self._refresh).pack(
                side='left', padx=(0, 8))

        # ── 아래: 목록 하나 ─────────────────────────────────────────
        right_f = ttk.Frame(self._shell.body)
        right_f.pack(fill='both', expand=True)
        right_f.grid_columnconfigure(0, weight=1)
        right_f.grid_rowconfigure(1, weight=1)

        # 유닛 미리보기 트리뷰
        tree_f = ttk.LabelFrame(right_f, text=i18n.t('PB_MATCHUNITS',' 매칭 유닛 목록 '), padding=4)
        tree_f.grid(row=1, column=0, sticky='nsew')
        tree_f.grid_rowconfigure(0, weight=1)
        tree_f.grid_columnconfigure(0, weight=1)

        cols = ('period', 'agent', 'mtype', 'typology', 'christo', 'ref', 'title')
        hdrs = [
            ('period',   '시대',     62),
            ('agent',    '수행자',   82),
            ('mtype',    '유형',     68),
            ('typology', '예표관계', 80),
            ('christo',  '기독론',   90),
            ('ref',      '성경구절', 100),
            ('title',    '유닛 제목', 0),
        ]
        self._tree = ttk.Treeview(tree_f, columns=cols,
                                   show='headings', selectmode='browse')
        for cid, hd, w in hdrs:
            self._tree.heading(cid, text=hd)
            self._tree.column(cid, width=w, anchor='w', stretch=(cid == 'title'))

        tree_vsb = ttk.Scrollbar(tree_f, orient='vertical', command=self._tree.yview)
        self._tree.configure(yscrollcommand=tree_vsb.set)
        tree_vsb.grid(row=0, column=1, sticky='ns')
        self._tree.grid(row=0, column=0, sticky='nsew')

        # 행 색상 구분 (시대별)
        self._tree.tag_configure('OT',         background='#FDFEFE')
        self._tree.tag_configure('NT_JESUS',   background='#EBF5FB')
        self._tree.tag_configure('NT_APOSTLE', background='#EAFAF1')
        self._tree.tag_configure('PAIR_NT',    foreground='#1A5276')

    # ── DB 로드 ──────────────────────────────────────────────────────

    def _load_units(self):
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                self._all_units = [dict(r) for r in conn.execute("""
                    SELECT
                        m.miracle_id,  m.title_kr,    m.scripture_ref,
                        m.period,      m.agent_type,  m.miracle_type,
                        m.typology,    m.christology, m.ot_pair_codes,
                        m.chrono_order,
                        u.unit_id,
                        u.psa_intro_ref,  u.ot_type_ref,
                        u.core_ref,
                        u.expand_ref,     u.expand_svid,    u.expand_evid,
                        u.confirm_ref,    u.confirm_svid,   u.confirm_evid,
                        u.psa_outro_ref,  u.key_question,
                        u.start_vid,      u.end_vid,
                        u.psa_intro_svid, u.psa_intro_evid,
                        u.ot_type_svid,   u.ot_type_evid,
                        u.psa_outro_svid, u.psa_outro_evid
                    FROM miracle_pool m
                    LEFT JOIN miracle_unit_pool u
                           ON u.miracle_id = m.miracle_id
                    WHERE m.record_status = 'LIVE'
                    ORDER BY m.chrono_order
                """).fetchall()]
        except sqlite3.OperationalError as e:
            messagebox.showerror(i18n.t('MSG_T_DBERR', 'DB 오류'), str(e), parent=self)
            self._all_units = []

    # ── 필터 적용 + 화면 갱신 ────────────────────────────────────────

    def _refresh(self):
        sel_a    = set(self._fg_agent.get_selected())
        sel_t    = set(self._fg_mtype.get_selected())
        sel_y_ui = set(self._fg_typo.get_selected())

        # UI의 'UNIQUE' → DB의 UNIQUE_OT + UNIQUE_NT 로 확장
        sel_y: set[str] = set()
        for v in sel_y_ui:
            if v == 'UNIQUE':
                sel_y.add('UNIQUE_OT')
                sel_y.add('UNIQUE_NT')
            else:
                sel_y.add(v)

        filtered = [
            u for u in self._all_units
            if u['agent_type']    in sel_a
            and u['miracle_type'] in sel_t
            and u['typology']     in sel_y
        ]

        self._filtered = sort_units(filtered, self._order_var.get())
        self._update_tree()
        self._auto_name()

    def _update_tree(self):
        self._tree.delete(*self._tree.get_children())
        for u in self._filtered:
            period   = u.get('period', '')
            typology = u.get('typology', '')
            tag = period
            if typology == 'FULFILL_SURPASS': tag = 'PAIR_NT'

            self._tree.insert('', 'end', tags=(tag,), values=(
                i18n.t('MB_PERIOD_'+str(period), PERIOD_KO.get(period, period)),
                i18n.t('MB_AGENT_'+str(u.get('agent_type','')), AGENT_KO.get(u.get('agent_type',''), '')),
                i18n.t('MB_MTYPE_'+str(u.get('miracle_type','')), MTYPE_KO.get(u.get('miracle_type',''), '')),
                i18n.t('MB_TYPO_'+str(typology), TYPO_KO.get(typology, '')),
                i18n.t('MB_CHRISTO_'+str(u.get('christology','')), CHRISTO_KO.get(u.get('christology',''), '')) if u.get('christology') else '',
                u.get('scripture_ref',''),
                u.get('title_kr',''),
            ))

        n = len(self._filtered)
        self._shell.set_count(n, n)

    # ── 플랜명 자동생성 ──────────────────────────────────────────────

    def _auto_name(self):
        name = generate_miracle_plan_name(
            self._fg_agent.get_selected(),
            self._fg_mtype.get_selected(),
            self._fg_typo.get_selected(),
            self._order_var.get(),
        )
        self._name_var.set(name)

    # ── 플랜 생성 ────────────────────────────────────────────────────

    def _create_plan(self):
        if not self._filtered:
            messagebox.showwarning(i18n.t('COMMON_WARNING', '경고'), i18n.t('MSG_NO_UNIT_SELECTED', '선택된 유닛이 없습니다.'), parent=self)
            return
        # ⚠ 자동 이름이 코드였다 — `기적_3수행자_4유형_쌍순_26`(2026-08-16 사용자 지적).
        #   사람이 읽는 말로 다듬는다(밑줄·꼬리 숫자 제거).
        plan_code = _readable(self._name_var.get().strip(), '내 기적 묵상')
        plan_code = check_plan_name(plan_code, self)
        if plan_code is None:
            return

        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 겹침은 **같은 앵커(30) 아래 형제끼리만** 본다 (2026-08-16).
                #   ⚠ 예전에는 `sys_bible_plan` 까지 봤다 — 이 화면은 sys 에 쓰지
                #     않으므로(§0-6 C-2) 그 검사는 남은 흔적이었다.
                plan_code = unique_sibling_name(conn, plan_code, MIRACLE_ANCHOR)
                self._name_var.set(plan_code)

                # 필터 메타데이터 저장
                config = {
                    'filter': {
                        'agent_type':   self._fg_agent.get_selected(),
                        'miracle_type': self._fg_mtype.get_selected(),
                        'typology':     self._fg_typo.get_selected(),
                    },
                    'order_mode': self._order_var.get(),
                    'unit_ids':   [u['miracle_id'] for u in self._filtered],
                    'total_units': len(self._filtered),
                    'note': '기적플랜 — vid 연결 후 완전 작동',
                }

                cur = conn.execute(
                    "INSERT INTO user_bible_plan "
                    "(origin_plan_id, plan_code, plan_type, plan_category, "
                    " duration_days, track_count, plan_config) "
                    "VALUES (?, ?, 'THEMATIC', 'THEMATIC', ?, 1, ?)",
                    (MIRACLE_ANCHOR, plan_code, len(self._filtered),
                     json.dumps(config, ensure_ascii=False)),
                )
                user_plan_id = cur.lastrowid

                # user_plan_schedule: vid가 실제로 해결된 슬롯만 등록
                schedule_rows = 0
                for day, u in enumerate(self._filtered, start=1):
                    week = (day - 1) // 7 + 1
                    uk   = u.get('unit_id') or f"MU-{u['miracle_id']}"

                    slots = [
                        # (svid_key, evid_key, stage_type, conn_level, sort_order, focus_key)
                        ('psa_intro_svid', 'psa_intro_evid', 'PSA',     'EXPANSION', 1, 'psa_intro_ref'),
                        ('ot_type_svid',   'ot_type_evid',   'OT_TYPE', 'EXPANSION', 2, 'ot_type_ref'),
                        ('start_vid',      'end_vid',        'MIRACLE', 'CORE',      3, 'core_ref'),
                        ('expand_svid',    'expand_evid',    'EXPAND',  'EXPANSION', 4, 'expand_ref'),
                        ('confirm_svid',   'confirm_evid',   'CONFIRM', 'EXPANSION', 5, 'confirm_ref'),
                        ('psa_outro_svid', 'psa_outro_evid', 'PSA',     'EXPANSION', 6, 'psa_outro_ref'),
                    ]

                    for svid_k, evid_k, stage, conn_lv, sort_ord, focus_k in slots:
                        svid  = u.get(svid_k)
                        evid  = u.get(evid_k)
                        focus = u.get(focus_k) or ''
                        if svid and evid:
                            conn.execute("""
                                INSERT INTO user_plan_schedule
                                (user_plan_id,week,day,start_vid,end_vid,
                                 stage_type,connection_level,sort_order,
                                 meditation_focus,unit_key)
                                VALUES (?,?,?,?,?,?,?,?,?,?)
                            """, (user_plan_id, week, day, svid, evid,
                                  stage, conn_lv, sort_ord,
                                  focus, f"{uk}_{stage}"))
                            schedule_rows += 1

            self.created_user_plan_id = user_plan_id
            if schedule_rows == 0:
                status_msg = (
                    "플랜 메타데이터만 저장되었습니다.\n"
                    "구절 ID(vid) 연결 스크립트 실행 후\n"
                    "스케줄이 자동 완성됩니다."
                )
            else:
                status_msg = f"스케줄 {schedule_rows}항목 등록 완료"
            # ★ 「'등록하기' 버튼을 눌러 시작하세요」 → **여기서 묻는다** (2026-08-16).
            self.enroll_now = messagebox.askyesno(
                i18n.t('COMMON_DONE', '완료'),
                i18n.t('MSG_PLAN_CREATED_ASK2',
                       "플랜을 만들었습니다 — {code} ({days}일)\n{status}\n\n지금 등록할까요?"
                       ).format(code=plan_code, days=len(self._filtered),
                                status=status_msg),
                parent=self,
            )
            self.destroy()

        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e), parent=self)


# ────────────────────────────────────────────────────────────────────
# 독립 실행
# ────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    dlg = MiraclePlanBuilderDialog(root)
    root.wait_window(dlg)
    root.destroy()
