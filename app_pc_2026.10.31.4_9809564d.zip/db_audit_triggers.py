# -*- coding: utf-8 -*-
"""db_audit_triggers.py — DB 트리거 기반 감사 로그 (영구 도구, 반복 실행·멱등)

CLAUDE.md §10 의 "모든 변경은 admin_manager 가 스냅샷으로 로깅" 은 2026-03-06 이후
실제로는 미작동이었다(엔진 계층 폐기, §2). 앱 코드 468곳의 쓰기를 일일이 고치는 대신
DB 트리거로 복구한다 — 우회 불가, 앱 코드 변경 0.

설계 원칙
---------
1. **"테이블에서 더 이상 읽을 수 없게 된 것"만 저장한다.**
   - UPDATE / DELETE → 이전 행(OLD) 전체를 JSON 으로 기록
   - INSERT          → PK 만 기록 (현재 값은 테이블에 그대로 있으므로 중복 저장 안 함)
   덕분에 sys_text_asset(15만행) 같은 대용량에서도 DB 가 배로 불어나지 않는다.

2. **로그 테이블은 감사 대상과 같은 DB 에 둔다.**
   SQLite 트리거 본문은 다른 스키마를 참조할 수 없다. main 의 트리거가 userdb 를
   가리키면 userdb 미연결 상태(raw sqlite3.connect 로 여는 1회성 스크립트)에서
   **정상 쓰기까지 실패**한다. 그래서 main→sys_audit_log, userdb→user_audit_log.

3. **스위치로 켜고 끈다.** 대량 적재 중에는 --off 로 잠시 끈다.
   트리거를 지웠다 다시 만드는 것보다 안전하다(중간에 죽어도 트리거가 남는다).

사용법
------
  python db_audit_triggers.py              # 설치 / 갱신 (멱등)
  python db_audit_triggers.py --status     # 현재 상태
  python db_audit_triggers.py --off        # 잠시 중단 (대량 적재 전)
  python db_audit_triggers.py --on         # 재개
  python db_audit_triggers.py --test       # 자가 검증 (트랜잭션 롤백, 흔적 없음)
  python db_audit_triggers.py --prune 180  # 180일 지난 로그 삭제
  python db_audit_triggers.py --uninstall  # 트리거 제거 (로그는 보존)
  python db_audit_triggers.py --history sys_text_asset 12345   # 특정 행 이력

주의: bible_master.db 를 통째 교체 배포하면 sys_audit_log 도 함께 나간다.
배포 전 --prune 0 으로 비우거나, 그대로 내보내도 무방한지 판단할 것.
"""
import argparse
import json
import sys

import appdb

DB = 'bible_master.db'

# 감사 대상 — 손으로 쌓아 올린 콘텐츠 자산 위주
TARGETS = {
    'main': [
        'sys_text_asset', 'sys_unit_asset', 'sys_link_asset', 'sys_tag_asset',
        'sys_pericope_asset', 'sys_entity_master', 'sys_entity_pericope',
        'sys_person_relation', 'sys_commentary_text', 'sys_book_unit_text',
        'sys_bible_plan', 'sys_plan_schedule',
        # ⚠ 2026-08-25 추가 — **여기만 빠져 있었다.** 사전·교리문답·연구 글이
        #   사는 표인데 트리거가 0개라 관리자 화면에서 덮으면 **되돌릴 수 없었다**
        #   (도서·주석은 3개씩 있어 복구 가능했다). `ORIGINAL` 잠금과 함께 채운다.
        'sys_ref_text',
        # ⚠⚠⚠ 2026-09-04 추가 — **실제로 당하고 나서 넣는다.** selftest 가
        #   실 DB 에 쓰려다 실패한 뒤, 같은 번호의 **진짜 미디어 5행을 「시험
        #   잔재」로 오인해 지웠다.** 트리거가 없어 감사 로그로 못 되살렸고
        #   백업도 없었으며 미승인분이라 팩에도 없었다 — 지우기 직전 SELECT 로
        #   우연히 찍어 둔 제목·URL 이 없었으면 통째로 잃을 뻔했다.
        #   ⚠ 수집기가 하루 수백~수천 행을 INSERT 하지만 **INSERT 는 PK 만**
        #     남기므로(§10-1 설계 원칙 ①) 부담이 작다. 대량 적재 때는
        #     `--off` 로 끄면 된다.
        'sys_media_asset',
        # 보관함 대기표 — 같은 사고에서 1행이 함께 지워졌다(추론으로 되살렸다).
        'sys_media_pending',
        # ★★★ 2026-09-25 추가 — **다시 쓰면 덮어쓰는 자리**(사용자 「맛보기
        #   소개문 되돌릴 수 있도록 하라」). 적재가 (자리·언어)를 지우고
        #   넣으므로 기록이 없으면 **옛 글이 그냥 사라진다.**
        #   「이미 완료된 것도 포함」 스위치를 여는 날 날마다 일어날 일이라
        #   그 스위치보다 **먼저** 막는다.
        'sys_book_taste', 'sys_book_asset_text',
        # ★ 317차-18 — 연구/설교노트의 표(ref_doc · 워드 왕복·번역이 칸을 덮어쓴다)
        'sys_ref_table', 'sys_ref_table_text',
        # ★ 2026-10-13 (docs/1.txt 71) — AI 프롬프트 층·게이트 세기. 기록이 없어 「누가 언제 어느 줄을 고쳤나」를
        #   못 따졌고, 자가검증이 341줄의 고친 시각을 덮었을 때 되살릴 길이 없었다.
        'sys_ai_prompt', 'sys_ai_gate_cfg',
    ],
    'userdb': [
        'user_text_asset', 'user_unit_asset', 'user_link_asset', 'user_tag_asset',
        # 2026-08-26 덮개 2단계 — 엔티티 가림 표(overlay.ensure_schema 가 만든다)
        'user_entity_asset',
        # ★ 317차-18 — 내 연구/설교노트의 표
        'user_ref_table', 'user_ref_table_text',
    ],
}
NAMES = {                       # 스키마별 로그/스위치 테이블 이름
    'main':   ('sys_audit_log', 'sys_audit_switch'),
    'userdb': ('user_audit_log', 'user_audit_switch'),
}
TS = "strftime('%Y-%m-%d %H:%M:%f','now','localtime')"


def q(name):
    return '"' + name.replace('"', '""') + '"'


def table_info(conn, schema, tbl):
    rows = list(conn.execute(f'PRAGMA {schema}.table_info({q(tbl)})'))
    if not rows:
        return None, []
    cols = [r[1] for r in rows]
    pk = next((r[1] for r in rows if r[5]), None)
    return pk, cols


def json_expr(alias, cols):
    """OLD/NEW 행 전체 → json_object(...) 표현식"""
    parts = []
    for c in cols:
        parts.append("'" + c.replace("'", "''") + "'")
        parts.append(f'{alias}.{q(c)}')
    return 'json_object(' + ', '.join(parts) + ')'


def ensure_infra(conn, schema):
    log, sw = NAMES[schema]
    conn.execute(f'''CREATE TABLE IF NOT EXISTS {schema}.{q(log)} (
        audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts       TEXT    NOT NULL,
        tbl      TEXT    NOT NULL,
        pk       INTEGER,
        action   TEXT    NOT NULL,
        old_json TEXT
    )''')
    conn.execute(f'CREATE INDEX IF NOT EXISTS {schema}.ix_{log}_ts ON {q(log)}(ts)')
    conn.execute(f'CREATE INDEX IF NOT EXISTS {schema}.ix_{log}_tbl ON {q(log)}(tbl, pk)')
    conn.execute(f'''CREATE TABLE IF NOT EXISTS {schema}.{q(sw)} (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        enabled INTEGER NOT NULL DEFAULT 1
    )''')
    conn.execute(f'INSERT OR IGNORE INTO {schema}.{q(sw)}(id, enabled) VALUES (1, 1)')


def trigger_names(tbl):
    return [f'trg_audit_{tbl}_{sfx}' for sfx in ('ai', 'au', 'ad')]


def install(conn, verbose=True):
    total = 0
    for schema, tables in TARGETS.items():
        ensure_infra(conn, schema)
        log, sw = NAMES[schema]
        guard = f'WHEN (SELECT enabled FROM {q(sw)} WHERE id = 1) = 1'
        for tbl in tables:
            pk, cols = table_info(conn, schema, tbl)
            if not cols:
                if verbose:
                    print(f'  건너뜀 {schema}.{tbl} — 테이블 없음')
                continue
            if not pk:
                if verbose:
                    print(f'  건너뜀 {schema}.{tbl} — 단일 PK 없음')
                continue
            ins = f'INSERT INTO {q(log)}(ts, tbl, pk, action, old_json) VALUES'
            lit = "'" + tbl.replace("'", "''") + "'"
            old_j = json_expr('OLD', cols)
            ai, au, ad = trigger_names(tbl)
            for name in (ai, au, ad):
                conn.execute(f'DROP TRIGGER IF EXISTS {schema}.{q(name)}')
            # INSERT: PK 만 (현재 값은 테이블에 있음)
            conn.execute(f'''CREATE TRIGGER {schema}.{q(ai)} AFTER INSERT ON {q(tbl)}
                {guard}
                BEGIN {ins} ({TS}, {lit}, NEW.{q(pk)}, 'INSERT', NULL); END''')
            # UPDATE: 사라지는 이전 행
            conn.execute(f'''CREATE TRIGGER {schema}.{q(au)} AFTER UPDATE ON {q(tbl)}
                {guard}
                BEGIN {ins} ({TS}, {lit}, OLD.{q(pk)}, 'UPDATE', {old_j}); END''')
            # DELETE: 사라지는 행
            conn.execute(f'''CREATE TRIGGER {schema}.{q(ad)} AFTER DELETE ON {q(tbl)}
                {guard}
                BEGIN {ins} ({TS}, {lit}, OLD.{q(pk)}, 'DELETE', {old_j}); END''')
            total += 3
            if verbose:
                print(f'  OK {schema}.{tbl:24s} (컬럼 {len(cols)}, PK {pk})')
    conn.commit()
    print(f'\n트리거 {total}개 설치/갱신 완료 (대상 테이블 {total // 3}개)')


def uninstall(conn):
    n = 0
    for schema, tables in TARGETS.items():
        for tbl in tables:
            for name in trigger_names(tbl):
                cur = conn.execute(
                    f"SELECT 1 FROM {schema}.sqlite_master WHERE type='trigger' AND name=?",
                    (name,)).fetchone()
                if cur:
                    conn.execute(f'DROP TRIGGER {schema}.{q(name)}')
                    n += 1
    conn.commit()
    print(f'트리거 {n}개 제거 (로그 테이블은 보존)')


def switch(conn, on):
    for schema in TARGETS:
        log, sw = NAMES[schema]
        try:
            conn.execute(f'UPDATE {schema}.{q(sw)} SET enabled=? WHERE id=1', (1 if on else 0,))
        except Exception as e:
            print(f'  {schema}: {e}')
    conn.commit()
    print('감사 로그 ' + ('ON' if on else 'OFF (대량 적재용 — 끝나면 --on 잊지 말 것)'))


def status(conn):
    for schema, tables in TARGETS.items():
        log, sw = NAMES[schema]
        print(f'[{schema}]')
        try:
            en = conn.execute(f'SELECT enabled FROM {schema}.{q(sw)} WHERE id=1').fetchone()
            n = conn.execute(f'SELECT COUNT(*) FROM {schema}.{q(log)}').fetchone()[0]
            rng = conn.execute(f'SELECT MIN(ts), MAX(ts) FROM {schema}.{q(log)}').fetchone()
        except Exception as e:
            print(f'  미설치 ({e})')
            continue
        print(f'  스위치      : {"ON" if en and en[0] else "OFF"}')
        print(f'  {log:12s}: {n}행   기간 {rng[0]} ~ {rng[1]}')
        have = {r[0] for r in conn.execute(
            f"SELECT name FROM {schema}.sqlite_master WHERE type='trigger' AND name LIKE 'trg_audit_%'")}
        want = {t for tbl in tables for t in trigger_names(tbl)}
        print(f'  트리거      : {len(have & want)}/{len(want)} 설치됨')
        missing = sorted(want - have)
        if missing:
            print(f'  누락        : {missing[:6]}{" ..." if len(missing) > 6 else ""}')
        if n:
            print('  최근 활동:')
            for r in conn.execute(
                    f'SELECT ts, tbl, pk, action FROM {schema}.{q(log)} ORDER BY audit_id DESC LIMIT 5'):
                print(f'    {r[0]}  {r[3]:6s} {r[1]}#{r[2]}')
        print()


def prune(conn, days):
    for schema in TARGETS:
        log, _ = NAMES[schema]
        try:
            if days <= 0:
                n = conn.execute(f'SELECT COUNT(*) FROM {schema}.{q(log)}').fetchone()[0]
                conn.execute(f'DELETE FROM {schema}.{q(log)}')
            else:
                cur = conn.execute(
                    f"DELETE FROM {schema}.{q(log)} WHERE ts < date('now', ?)", (f'-{days} days',))
                n = cur.rowcount
            print(f'  {schema}.{log}: {n}행 삭제')
        except Exception as e:
            print(f'  {schema}: {e}')
    conn.commit()


def history(conn, tbl, pk):
    schema = next((s for s, ts in TARGETS.items() if tbl in ts), None)
    if not schema:
        print(f'감사 대상이 아닌 테이블: {tbl}')
        return
    log, _ = NAMES[schema]
    rows = list(conn.execute(
        f'SELECT ts, action, old_json FROM {schema}.{q(log)} WHERE tbl=? AND pk=? ORDER BY audit_id',
        (tbl, pk)))
    if not rows:
        print(f'{tbl}#{pk} — 기록 없음')
        return
    print(f'=== {tbl}#{pk} 변경 이력 {len(rows)}건 ===')
    for ts, act, oj in rows:
        print(f'\n[{ts}] {act}')
        if oj:
            d = json.loads(oj)
            for k, v in d.items():
                sv = str(v)
                print(f'    {k:20s}= {sv[:120]}{"..." if len(sv) > 120 else ""}')


def selftest(conn):
    """실제 테이블에 넣었다 지우고 롤백 — DB 에 흔적을 남기지 않는다."""
    schema, tbl = 'main', 'sys_tag_asset'
    log, _ = NAMES[schema]
    pk, cols = table_info(conn, schema, tbl)
    ok = True
    conn.execute('BEGIN')
    try:
        base = conn.execute(f'SELECT COALESCE(MAX(audit_id),0) FROM {schema}.{q(log)}').fetchone()[0]
        cur = conn.execute(
            f'INSERT INTO {q(tbl)}({q("tag_name_sid")}, {q("record_status")}) VALUES (?, ?)',
            ('__AUDIT_SELFTEST__', 'LIVE'))
        new_pk = cur.lastrowid
        conn.execute(f'UPDATE {q(tbl)} SET {q("record_status")}=? WHERE {q(pk)}=?', ('HIDE', new_pk))
        conn.execute(f'DELETE FROM {q(tbl)} WHERE {q(pk)}=?', (new_pk,))
        got = list(conn.execute(
            f'SELECT action, old_json FROM {schema}.{q(log)} WHERE audit_id>? ORDER BY audit_id', (base,)))
        acts = [g[0] for g in got]
        print('  기록된 동작:', acts)
        if acts != ['INSERT', 'UPDATE', 'DELETE']:
            print('  FAIL: INSERT/UPDATE/DELETE 3건이 기록되지 않음'); ok = False
        if got and got[0][1] is not None:
            print('  FAIL: INSERT 인데 old_json 이 채워짐'); ok = False
        if len(got) > 1:
            d = json.loads(got[1][1])
            if d.get('record_status') != 'LIVE':
                print(f'  FAIL: UPDATE 의 old_json 이 변경 전 값이 아님 -> {d.get("record_status")}'); ok = False
            else:
                print("  UPDATE old_json.record_status = 'LIVE'  (변경 전 값 정확)")
        if len(got) > 2:
            d = json.loads(got[2][1])
            if d.get('record_status') != 'HIDE':
                print(f'  FAIL: DELETE 의 old_json 이 직전 값이 아님 -> {d.get("record_status")}'); ok = False
            else:
                print("  DELETE old_json.record_status = 'HIDE'  (직전 값 정확)")
    finally:
        conn.rollback()
    left = conn.execute(
        f'SELECT COUNT(*) FROM {q(tbl)} WHERE {q("tag_name_sid")}=?', ('__AUDIT_SELFTEST__',)).fetchone()[0]
    print(f'  롤백 후 잔여 테스트행: {left} (0 이어야 정상)')
    if left:
        ok = False
    print('\n자가 검증 ' + ('통과' if ok else '실패'))
    return ok


def main():
    ap = argparse.ArgumentParser(description='DB 트리거 기반 감사 로그')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--on', action='store_true')
    ap.add_argument('--off', action='store_true')
    ap.add_argument('--test', action='store_true')
    ap.add_argument('--uninstall', action='store_true')
    ap.add_argument('--prune', type=int, metavar='DAYS')
    ap.add_argument('--history', nargs=2, metavar=('TABLE', 'PK'))
    a = ap.parse_args()

    conn = appdb.connect(DB)
    try:
        if a.status:
            status(conn)
        elif a.on:
            switch(conn, True)
        elif a.off:
            switch(conn, False)
        elif a.uninstall:
            uninstall(conn)
        elif a.prune is not None:
            prune(conn, a.prune)
        elif a.history:
            history(conn, a.history[0], int(a.history[1]))
        elif a.test:
            sys.exit(0 if selftest(conn) else 1)
        else:
            install(conn)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
