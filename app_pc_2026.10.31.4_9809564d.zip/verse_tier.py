# -*- coding: utf-8 -*-
"""verse_tier.py — 구절 설명 2티어(전문가/일반인) 선택 헬퍼.

저장: sys/user_text_asset.text_variant = 'EXPERT' | 'LAY' | NULL(레거시/단일).
사용자 선택: **표시 모드**(user_config['DESC_MODE'])가 티어를 겸한다 — 2026-08-09 개편.
      [장 설명][단락설명][Lay][Expert] 네 버튼 하나로 정한다. 예전의 DESC_TIER(전역 티어)와
      DESC_SECTIONS(섹션 체크박스)는 폐기했다 — 티어를 정하는 곳이 둘이라 혼란스러웠다.
읽기: 요청 티어 우선 → 레거시(NULL) → 다른 티어 순으로 1건. 기존 쿼리의 ORDER BY에
      TIER_ORDER 조각을 맨 앞에 끼우고 tier 파라미터를 첫 번째로 바인딩하면 됨.
대상 text_type: VERS_DESC · VERS_QUESTION · VERS_VERS_DESC. (VERS_PRAYER 등은 NULL 단일.)
"""

# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr

# 요청 티어 우선 정렬 조각(파라미터 1개: 요청 티어). ORDER BY 맨 앞에 삽입.
TIER_ORDER = "(CASE WHEN text_variant=? THEN 0 WHEN text_variant IS NULL THEN 1 ELSE 2 END)"


def get_version(conn_or_path, default='KRV'):
    """현재 성경버전 = user_config['v1_code'] (**단일 소스**, 2026-07-30).

    P1 버전 콤보와 '지원/설정 ▸ 성경버전'의 기본 버전이 같은 키를 쓴다. 구절을 표시하는
    모든 화면은 이 값을 따라야 한다 — 언어→버전 하드코딩 맵을 새로 만들지 말 것.
    conn(열린 커넥션) 또는 db_path(문자열) 둘 다 받는다. 실패 시 default.
    """
    try:
        if isinstance(conn_or_path, str):
            import appdb
            with appdb.connect(conn_or_path) as c:
                r = c.execute(
                    "SELECT config_val FROM user_config WHERE config_key='v1_code'").fetchone()
        else:
            r = conn_or_path.execute(
                "SELECT config_val FROM user_config WHERE config_key='v1_code'").fetchone()
        if r and r[0]:
            return str(r[0])
    except Exception:
        pass
    return default


def tier_for_mode(mode):
    """표시 모드 -> 읽을 text_variant. LAY 모드가 기본이다."""
    return 'EXPERT' if str(mode).upper() == 'EXPERT' else 'LAY'


# ── 표시 섹션 ──────────────────────────────────────────────────────────
# **모드가 섹션을 정한다** (2026-08-09). 사용자가 체크박스로 고르던 것을 없앴다 —
# 티어(전문/일반)를 정하는 곳이 체크박스와 전역 설정 둘이라 무엇을 눌러야 할지 몰랐다.
# 이 리스트 하나가 화면 배치 순서의 단일 소스다 → P2 탭1 · P4 트리뷰 탭1 ·
# 캔버스 슬라이딩 탭1 세 곳이 같은 순서로 그려진다.
SECTION_CODES = ['DESC_LAY', 'Q_DEV', 'PRAYER',
                 'DESC_EXP', 'VIEW', 'VIEWMAP', 'Q_RES', 'ROLE']

# 모드 → 그 모드에서 보이는 섹션. **여기만 고치면 세 화면이 함께 따라온다.**
MODE_SECTIONS = {
    # ★★★ 2026-09-23 사용자 지시 — 「**전문 버튼을 제거**하라 …
    #   **전문 버튼에 있는 연구질문을 묵상기도 아래에 추가**하라」.
    #   ⇒ 잎사귀는 이제 **한 층**이고 연구질문이 그 끝에 선다.
    # ★ 2026-10-13 (docs/1.txt 76-2 사용자 「연구질문을 이동배치한다」) — 연구질문은 [전문] 에만(전문 설명 아래).
    #   [일반] = 설명 · 묵상질문 · 묵상기도.
    # ★ 2026-10-26 사용자 「일반 설명문의 묵상기도 아래에 전문설명문과 마찬가지로 AI 콤보버튼을 배치」 —
    #   [일반] 에도 묵상기도 아래 **분야별 도움말**(머리 줄 [분야 ▾][AI 분석] · 전문과 같은 문).
    'LAY':    ['DESC_LAY', 'Q_DEV', 'PRAYER', 'ROLE'],
    # ⚠ 2026-10-13 실측 — 이 지시는 쓰이지 않던 옛 도구 줄(make_desc_toolbar · 그날 걷음)에만 반영됐고,
    #   실제 화면 부품 `desc_comm_group.DescCommGroup` 에는 [전문] 단추가 그대로 있다(P2 · P4 오른쪽 칸).
    #   전문 설명 구성은 사용자와 다시 협의하기로 했다(docs/1.txt 75-2) — 그때 함께 정한다.
    # ★ 2026-10-13 (76-3) — 연구질문 아래 **분야별 도움말**(`role_tips` · 고른 분야만).
    'EXPERT': ['DESC_EXP', 'VIEW', 'VIEWMAP', 'Q_RES', 'ROLE'],
}

# 코드 → (기본 라벨, ui_strings 키)
SECTION_LABELS = {
    'DESC_EXP': ('전문 설명', 'SEC_DESC_EXP'),
    # ★ 2026-09-23 — 단추가 [설명] 하나뿐이므로 「일반」이라는 구분이
    #   필요 없다(전문 설명 단추를 걷었다). 단추와 본문 머리는 **같은
    #   말**이라야 한다 — 다르면 같은 것을 가리키는지 알 수 없다.
    'DESC_LAY': ('설명', 'SEC_DESC_LAY'),
    'VIEW':     ('관점',      'SEC_VIEW'),
    'VIEWMAP':  ('관점 정리', 'SEC_VIEWMAP'),
    'Q_RES':    ('연구질문',  'SEC_Q_RES'),
    'ROLE':     ('분야별 도움말', 'SEC_ROLE'),
    'Q_DEV':    ('묵상질문',  'SEC_Q_DEV'),
    'PRAYER':   ('묵상기도',  'SEC_PRAYER'),
}


def sections_for_mode(mode):
    """그 모드에서 그릴 섹션 코드 리스트. 장·단락 모드는 절 자산을 안 쓰므로 빈 리스트."""
    return list(MODE_SECTIONS.get(str(mode).upper(), []))


# ── 표시 언어(전역 공유) ────────────────────────────────────────────────
# 설명문(페리코프·연결·전문·일반·묵상질문·묵상기도)을 어느 언어로 볼지. 데이터 없으면
# fetch 계층이 EN→KO 폴백(요청→EN→KO). 저장: user_config['LANGSEL_DESC'] = 대문자 코드.
#
# ★ **이름을 `DESC_LANG` → `LANGSEL_DESC` 로 바꿨다** (2026-08-14 사용자 제안).
#   화면마다 언어를 따로 기억하게 되면서 열쇠가 열 개가 됐는데(`LANGSEL_*`),
#   이것 하나만 이름이 달라 「다른 장치인가」를 묻게 됐다. 실제로 그래서 여러 차례
#   설명이 꼬였다. `_migrate` 가 옛 값을 한 번 옮긴다.
# ⚠ **이 한 열쇠를 「설명」 패널 두 곳이 함께 쓴다**(P2 탭1 · P4 구절연결).
#   그 둘은 같은 부품(`desc_comm_group.DescCommGroup`)이고, 본문을 읽어 오는 `_fetch_combined_desc`
#   가 **누가 물었는지 모른 채** 이 값을 본다. 갈라 두려면 fetch 계층에 「누가」를
#   넘겨야 해서 일이 커진다 — CLAUDE.md §3-1 의 설계대로 **한 값으로 둔다.**
_KEY = 'LANGSEL_DESC'
_OLD_KEY = 'DESC_LANG'


def _migrate(conn):
    """옛 이름으로 저장돼 있으면 새 이름으로 한 번 옮긴다."""
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?",
                         (_OLD_KEY,)).fetchone()
        if not r:
            return
        if not conn.execute("SELECT 1 FROM user_config WHERE config_key=?",
                            (_KEY,)).fetchone():
            conn.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?)",
                         (_KEY, r[0]))
        conn.execute("DELETE FROM user_config WHERE config_key=?", (_OLD_KEY,))
        conn.commit()
    except Exception:
        pass
def get_desc_lang(conn, default='KO'):
    """설명문 표시 언어(전역). 미설정 시 default(보통 UI 언어)."""
    try:
        _migrate(conn)
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?",
                         (_KEY,)).fetchone()
        if r and r[0]:
            return str(r[0]).upper()
    except Exception:
        pass
    return (default or 'KO').upper()


def set_desc_lang(conn, lang):
    lg = str(lang).upper()
    try:
        cur = conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?",
                           (lg, _KEY))
        if cur.rowcount == 0:
            conn.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?)",
                         (_KEY, lg))
        conn.commit()
    except Exception:
        pass
    return lg


# ── 표시 모드(전역 공유) ───────────────────────────────────────────────
# 설명 탭 안에서 세 층을 전환한다 — 숲(장) → 나무(단락) → 잎사귀(구절).
#   CHAP  장 설명   그 구절이 속한 장의 CHAP_DESC (흐름·주제·배경)
#   PERI  단락설명  그 구절이 속한 BODY 페리코프의 PERI_DESC
#   LAY   Lay       그 절의 일반 설명 + 묵상질문 + 묵상기도
#   EXPERT Expert    그 절의 전문 설명 + 관점들 + 관점 정리 + 연구질문
# 최상위 탭을 늘리지 않으려고 모드 전환으로 했다 — 캔버스 슬라이딩 패널(NodePanel)이
# 이미 7탭·420px 라 8번째 탭을 감당하지 못한다.
# 저장: user_config['DESC_MODE'] = 'BOOK' | 'CHAP' | 'PERI' | 'LAY' | 'EXPERT'.
# ⚠ 구버전은 'VERSE' + DESC_TIER 두 값으로 나뉘어 있었다 — get_desc_mode 가 옮겨 준다.
# 'BOOK' = 책 개요(BOOK_DESC, clicked_id=bcode) — 2026-08-26 2안(사용자 승인):
#   숲(책)→장→단락→절 계층의 맨 위 층. 주석 두 갈래는 「주석/링크」 탭으로 갔다.
DESC_MODES = ('BOOK', 'CHAP', 'PERI', 'LAY', 'EXPERT')


# ── 장 설명문(CHAP_DESC) 키 ────────────────────────────────────────────
# sys_text_asset.clicked_id 는 정수 하나뿐인데 장에는 자연 PK 가 없다(장 테이블 자체가
# 없다). 그래서 **bcode*1000 + chapter** 를 키로 쓴다 — 시편 150장이 최대라 1000 이면
# 겹치지 않고, clicked_id 의 뜻은 text_type 이 갈라 주므로 다른 자산과 충돌하지 않는다.
# ⚠ 이 두 함수 밖에서 키를 직접 계산하지 말 것. 계산식이 흩어지면 나중에 못 바꾼다.
CHAP_KEY_UNIT = 1000


def chap_key(bcode, chapter):
    return int(bcode) * CHAP_KEY_UNIT + int(chapter)


def chap_of_key(key):
    """chap_key 의 역 — (bcode, chapter)."""
    return divmod(int(key), CHAP_KEY_UNIT)


def count_for(db_path, verse_id):
    """설명 탭 배지용 개수 (2026-08-19 사용자 「모든 탭에 개수 — 빈칸 금지」).

    뜻 = **이 절이 가진 설명 자산의 종류 수** — 절 자산(VERS_DESC LAY/EXPERT ·
    VERS_QUESTION LAY/EXPERT · VERS_PRAYER — 언어 무관, 종류로 센다)
    + 단락설명(감싸는 BODY 페리코프의 PERI_DESC) + 장 설명(CHAP_DESC).
    탭의 네 모드([장][단락][Lay][Expert])가 보여 줄 재료가 몇 종류인가다.
    """
    if not verse_id:
        return 0
    try:
        import appdb
        with appdb.connect(db_path) as conn:
            kinds = set()
            for tbl in ('sys_text_asset', 'user_text_asset'):
                try:
                    rows = conn.execute(
                        f"SELECT DISTINCT text_type, COALESCE(text_variant,'') "
                        f"FROM {tbl} WHERE clicked_id=? "
                        "AND text_type IN ('VERS_DESC','VERS_QUESTION','VERS_PRAYER') "
                        "AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT')",
                        (int(verse_id),)).fetchall()
                    kinds.update((r[0], r[1]) for r in rows)
                except Exception:
                    pass
            n = len(kinds)
            bc = conn.execute("SELECT bcode, chapter FROM bible_index "
                              "WHERE verse_id=?", (int(verse_id),)).fetchone()
            if bc:
                r = conn.execute(
                    "SELECT 1 FROM sys_text_asset WHERE text_type='CHAP_DESC' "
                    "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE' "
                    "LIMIT 1", (chap_key(bc[0], bc[1]),)).fetchone()
                if r:
                    n += 1
            pr = conn.execute(
                "SELECT 1 FROM sys_text_asset t JOIN sys_pericope_asset p "
                "ON t.clicked_id=p.pericope_id "
                "WHERE t.text_type='PERI_DESC' "
                "AND COALESCE(t.record_status,'LIVE')='LIVE' "
                "AND p.peri_type='BODY' AND "
                + _vr.covers_sql('p', 'start_vid', 'end_vid')
                + " LIMIT 1", _vr.covers_args(int(verse_id))).fetchone()
            if pr:
                n += 1
            return n
    except Exception:
        return 0


def get_desc_mode(conn, default='LAY'):
    """현재 표시 모드. 구버전 값 'VERSE' 는 옛 DESC_TIER 를 보고 LAY/EXPERT 로 옮긴다."""
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key='DESC_MODE'").fetchone()
        if r and r[0]:
            m = str(r[0]).upper()
            # ★ 2026-10-13 (docs/1.txt 76-2) — [전문] 을 되살렸다(전문 설명 + 연구질문). 9/23 에 넣은
            #   「EXPERT → LAY 바꿔치기」가 남아 [전문] 단추가 일반 글만 보이고 있었다 — 걷었다.
            if m in DESC_MODES:
                return m
            if m == 'VERSE':                      # 구버전 — 티어로 갈라 준다
                t = conn.execute(
                    "SELECT config_val FROM user_config WHERE config_key='DESC_TIER'").fetchone()
                return 'EXPERT' if (t and str(t[0]).upper() == 'EXPERT') else 'LAY'
    except Exception:
        pass
    return default


def set_desc_mode(conn, mode):
    m = str(mode).upper()
    if m not in DESC_MODES:
        m = 'LAY'
    try:
        cur = conn.execute("UPDATE user_config SET config_val=? WHERE config_key='DESC_MODE'", (m,))
        if cur.rowcount == 0:
            conn.execute("INSERT INTO user_config(config_key,config_val) VALUES('DESC_MODE',?)", (m,))
        conn.commit()
    except Exception:
        pass
    return m




