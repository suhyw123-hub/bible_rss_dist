# -*- coding: utf-8 -*-
"""book_refs.py — **저자가 본문에 적어 둔 성구 약명을 찾아 번호로 읽는다**
(2026-08-31 신설 · 영구 · `--selftest` 의무).

★★★ 왜 — 122차에 「저자가 적어 둔 약명을 제자리에서 누르게」 했지만 그것은
  **그 편의 기준 구절 하나**뿐이었다(`_keyref_alts` 가 아는 번호로 글자를
  지어 찾는 방식). 본문 안에 두 번째·세 번째로 나오는 약명은 못 걸었다 —
  실측 표본 600편 중 8편(1.3%)이 그 상태로 남아 있었다.
  ⇒ 이 모듈은 **반대 방향**이다. 글자에서 번호를 읽는다.

★★★ **판정은 여기 한 곳** — 화면마다 정규식을 흩으면 책마다 다르게 걸린다
  (`book_blocks` 와 같은 문법).

⚠⚠ **지어내지 않는다** — 못 읽으면 **그냥 둔다**. 실측으로 걸린 것들:
  · `Sanh. x. 3`(미쉬나 산헤드린) · `Anti. viii. 3`(요세푸스 유대고대사) —
    성경 책이 아니다
  · `2 Macc. xv. 1`(마카베오) — 우리 66권에 없다
  · `Joun i. 1` — **OCR 오류**(MILLER_CYA 145건). 고칠 것은 데이터이지
    이 모듈이 짐작으로 `John` 이라 읽을 일이 아니다.
  넷 다 **이름이 안 풀려서 저절로 걸러진다** — 특례를 적지 않았다.

⚠ **장·절이 실제로 있는지 본다**(`bible_index`). 이름이 풀려도 그 책에 없는
  장이면 안 건다 — 「그럴듯한데 엉뚱한 곳으로 가는 링크」가 가장 나쁘다.

⚠ **본문을 고치지 않는다** — 자리(start, end)만 돌려주고 그리는 것은 화면의
  몫이다(§123차 「저자의 글을 고치는 것이 아니다」).

쓰는 꼴 (전부 실측에서 나온 것)
    Joshua 5:12 · Matt. 28:18 · Eph. 1:19-21 · Song of Solomon 1:4
    Song iv. 8 · 1 Thess. ii. 20 · Judg. xiv. 5-8 · Psalm xciv. 12
    Deut. xxx. 13 · 창1:1 · 요한복음 3:16

사용법
    python -X utf8 book_refs.py --selftest
    python -X utf8 book_refs.py --scan          # 전 도서 걸림/못 읽음 실측
"""
import re
import sys

#: 앞머리를 잘라 쓰지 **않는** 약명 — 이름의 앞글자로는 못 찾는다.
#: ⚠ 여기 없는 것은 **정식명의 앞머리**로 찾는다(`Deut.`→Deuteronomy).
#:   표를 길게 쓰지 말 것 — 앞머리 규칙이 대부분을 덮는다.
#: ⚠ 오른쪽은 **DB 에 실제로 있는 정식명**이어야 한다 — 우리가 부르는 이름
#:   (`Song of Solomon`)을 적으면 조용히 0건이 된다. 실측 `book_names` 는
#:   `Song of Songs` 다(2026-08-31 그렇게 새고 있었다).
ALIAS = {
    'jas': 'james', 'cant': 'song of songs', 'canticles': 'song of songs',
    'sol': 'song of songs',
    'apoc': 'revelation', 'apocalypse': 'revelation',
    'psalter': 'psalms',
}

#: 서수 — `1 Cor.` · `I Cor.` 둘 다 쓴다.
_ORD = {'1': 1, '2': 2, '3': 3, 'i': 1, 'ii': 2, 'iii': 3}

_ROMAN = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100}

#: 이름 뒤에 붙는 잇는 낱말(`Song of Solomon` · `1 Kings`)
_JOIN = ('of', 'the')

_RE = re.compile(
    r'(?<![0-9A-Za-z가-힣])'
    # ① 서수 (1 · 2 · 3 · I · II · III) — 있어도 없어도 된다
    # ⚠⚠ **로마 서수는 뒤에 공백이나 점을 요구한다** — 안 그러면 `Isaiah` 의
    #   첫 글자 `I` 를 서수로 먹고 `saiah` 만 이름으로 남는다(실측 260건이
    #   그렇게 새고 있었다). 숫자 서수(`1Co`)는 붙여 쓰기도 하므로 그대로 둔다.
    r'(?:(?:([123])\s*\.?\s*)|(?:(I{1,3})\s*(?:\.\s*|\s+)))?'
    # ② 책 이름 — 한 낱말 + (of/the + 낱말)*  또는 한글
    r'((?:[A-Z][A-Za-z]{1,13}(?:\s+(?:of|the)\s+[A-Z][A-Za-z]{1,13})*)'
    r'|(?:[가-힣]{1,7}))'
    # ⚠⚠ **이름 뒤에 글자가 더 오면 안 된다** — 없으면 정규식이 이름을 되물려
    #   `Rev. 3` 을 **`Re` + 로마숫자 `v`** 로 읽어 「계 5:3」을 만든다
    #   (2026-08-31 실측으로 잡았다. 두 글자 앞머리를 허용하면서 생긴 자리다).
    r'(?![A-Za-z])'
    r'\.?\s*'
    # ③ 장 — 아라비아 또는 로마숫자
    r'(\d{1,3}|[ivxlc]{1,7})'
    # ④ 가름 — `:` 또는 `.` 또는 (로마숫자 뒤) 공백
    r'\s*[:.]\s*'
    # ⑤ 절
    r'(\d{1,3})'
    r'(?![0-9])')


def _roman(s):
    """로마숫자 → 수. 못 읽으면 None."""
    s = s.lower()
    if not s or any(ch not in _ROMAN for ch in s):
        return None
    tot = 0
    for i, ch in enumerate(s):
        v = _ROMAN[ch]
        nxt = _ROMAN[s[i + 1]] if i + 1 < len(s) else 0
        tot += -v if v < nxt else v
    return tot or None


def _num(s):
    """장 글자 → 수. 아라비아든 로마든."""
    if s.isdigit():
        n = int(s)
        return n if n > 0 else None
    return _roman(s)


def names(conn, lang='KO'):
    """이름 표를 짓는다 → `{(서수, 정규화한 이름): bcode}`.

    ★ **정식명과 약명을 다 담고, 정식명은 앞머리로도 찾게 한다**
      (`Deut` → Deuteronomy). 앞머리가 **여럿에 걸리면 안 담는다** —
      `Jo` 로는 John·Job·Joel·Jonah·Joshua 를 가를 수 없다(§지어내지 않는다).
    """
    full = {}      # (ord, 이름) → set(bcode)
    pref = {}      # (ord, 앞머리) → set(bcode)

    def _split(nm):
        """`1 Corinthians` → (1, 'corinthians') · `Genesis` → (None, 'genesis')"""
        t = (nm or '').strip().lower().replace('.', '')
        m = re.match(r'^([123]|i{1,3})\s+(.+)$', t)
        if m:
            return _ORD.get(m.group(1)), m.group(2).strip()
        return None, t

    for lg in (str(lang or 'KO').upper(), 'EN'):
        for bc, fn, sn in conn.execute(
                "SELECT book_code, COALESCE(full_name,''),"
                "       COALESCE(short_name,'') FROM book_names"
                " WHERE UPPER(lang_code)=?", (lg,)):
            for nm in (fn, sn):
                if not nm:
                    continue
                o, t = _split(nm)
                if not t:
                    continue
                full.setdefault((o, t), set()).add(bc)
                # 앞머리 — 라틴 이름만(한글은 이미 짧다)
                if t[0].isascii():
                    # ⚠ **첫 낱말 통째까지** 담는다 — `Song of Songs` 를 저자는
                    #   `Song iv. 8` 이나 `Song of Solomon 1:4` 로 적는다.
                    #   `range(3, len(core))` 로 두면 `song` 이 빠져 둘 다 못 읽는다.
                    # ⚠ **두 글자부터** — 저자는 `Ps. xxiii. 1` 이라 적는다
                    #   (실측 420건). 애매한 두 글자는 아래 `len(v)==1` 이
                    #   저절로 걷어 낸다(`Jo` 는 다섯 책에 걸려 안 담긴다).
                    core = t.split(' ')[0]
                    for i in range(2, len(core) + 1):
                        pref.setdefault((o, core[:i]), set()).add(bc)
    for k, v in ALIAS.items():
        o, t = _split(v)
        got = full.get((o, t))
        if got and len(got) == 1:
            full.setdefault((None, k), set()).update(got)
    out = {k: next(iter(v)) for k, v in full.items() if len(v) == 1}
    for k, v in pref.items():
        # ⚠ **정식·약명이 이긴다** — 앞머리는 못 찾았을 때만 쓴다.
        if k not in out and len(v) == 1:
            out[k] = next(iter(v))
    return out


def _book(tbl, ordn, word):
    """이름 글자 → bcode. 못 읽으면 None."""
    t = (word or '').strip().lower().replace('.', '')
    # `Song of Solomon` 처럼 잇는 낱말이 붙은 꼴은 그대로 · 아니면 첫 낱말
    o = _ORD.get((ordn or '').lower()) if ordn else None
    for key in ((o, t), (None, t)):
        if key in tbl:
            return tbl[key]
    head = t.split(' ')[0]
    if head != t and head not in _JOIN:
        for key in ((o, head), (None, head)):
            if key in tbl:
                return tbl[key]
    return None


#: 직전 참조에 이어지는 꼴 — **바로 뒤에 붙었을 때만** 읽는다.
#:   ① `, 15`      같은 장의 다른 절
#:   ② `; i. 19`   책 이름 생략(앞 책을 잇는다)
#: ⚠⚠ **`^` 를 쓰지 않는다** — `pattern.match(text, pos)` 에서 `^` 는
#:   **문자열 시작**만 가리켜 pos 에서는 절대 안 맞는다(실측으로 잡았다).
#: ⚠⚠ **틈에 다른 글자가 있으면 안 잇는다** — 산문 한가운데의 숫자를 절로
#:   읽으면 「그럴듯한데 엉뚱한 데로 가는 링크」가 된다(§123차).
_CONT_VS = re.compile(r'\s*,\s*(\d{1,3})(?![0-9:.])')
_CONT_CH = re.compile(r'\s*;\s*([ivxlc]{1,7}|\d{1,3})\s*[:.]\s*(\d{1,3})(?![0-9])')


def _cont(text, pos, bc, ch=None):
    """`pos` 부터 이어지는 참조를 읽는다 → `[(start, end, bc, ch, vs)]`.

    ★ **`bc`·`ch`(앞에서 확정된 책·장)를 물려받는다** — 그것이 없으면
      `, 15` 가 어느 장의 15절인지 알 수 없다. 책을 모르면 잇지 않는다.
    ⚠ 이어 읽기는 **연쇄**한다(`14, 15, 16`). 다만 한 번에 12개까지 —
      목록 번호가 늘어선 자리에서 폭주하지 않게.
    """
    out = []
    for _ in range(12):
        m = _CONT_CH.match(text, pos)
        if m:
            ch = _num(m.group(1))
            vs = _num(m.group(2))
            if not ch or not vs:
                break
            out.append((m.start(1), m.end(), bc, ch, vs))
            pos = m.end()
            continue
        m = _CONT_VS.match(text, pos)
        if m and ch:
            vs = _num(m.group(1))
            if not vs:
                break
            out.append((m.start(1), m.end(), bc, ch, vs))
            pos = m.end()
            continue
        break
    return out


def find(text, tbl):
    """본문에서 성구 약명을 찾는다 → `[(start, end, bcode, 장, 절)]`.

    ⚠ **겹치지 않는다** — 정규식이 왼쪽부터 한 번만 훑는다.
    ⚠ 장·절이 실제로 있는지는 여기서 **안 본다**(DB 를 모른다).
      `resolve` 가 마저 거른다.
    ★★ **이어지는 참조도 읽는다**(2026-09-06) — 신앙고백의 증거 구절이
      `Rom. ii. 14, 15 ; i. 19, 20` 꼴이라 그전에는 **첫 하나만** 걸렸다
      (실측 웨스트민스터가 실제의 56% 만 읽고 있었다). 화면에서도
      `Rom. ii. 14` 만 파랗고 `, 15` 는 검게 남아 있었다.
    """
    out = []
    text = text or ''
    for m in _RE.finditer(text):
        ordn = m.group(1) or m.group(2)
        word, ch_s, vs_s = m.group(3), m.group(4), m.group(5)
        # 로마숫자 장은 `.` 로 가른다 — `Luke 24:49` 처럼 아라비아면 `:` 다.
        #   ⚠ `Rev. 3` 같은 장만 표기에는 절이 없으므로 안 걸린다(정규식이
        #     절을 요구한다). **장 단위 표기에는 안 붙인다**(§123차).
        bc = _book(tbl, ordn, word)
        if not bc:
            continue
        ch, vs = _num(ch_s), _num(vs_s)
        if not ch or not vs:
            continue
        out.append((m.start(), m.end(), bc, ch, vs))
        # ⚠ 이어지는 참조는 **바로 뒤**에서만 읽는다. `_RE` 는 책 이름을
        #   요구하므로 이 자리를 스스로 못 잡는다.
        out.extend(_cont(text, m.end(), bc, ch))
    return out


def resolve(conn, text, lang='KO', tbl=None, limit=400):
    """본문 → `[(start, end, verse_id, bcode, 장, 절)]` — **있는 절만**.

    ⚠ **없는 장·절은 뺀다** — 그럴듯한데 엉뚱한 데로 가는 링크를 안 만든다.
    ⚠ `limit` — 넘으면 앞에서 자른다.
      ⚠⚠ **200 이던 것을 400 으로 올렸다**(2026-09-06). 「한 편에 200개를
        넘길 일은 없다」던 전제가 **신앙고백에서 깨졌다** — 웨스트민스터
        21장(예배와 안식일)의 증거 구절이 실측 **300개 넘는다**. 200 이면
        화면에서 조용히 잘리고 사용자는 그것을 모른다(§0-1).
    """
    tbl = names(conn, lang) if tbl is None else tbl
    got = find(text, tbl)[:limit]
    if not got:
        return []
    want = sorted({(b, c, v) for _s, _e, b, c, v in got})
    have = {}
    for i in range(0, len(want), 400):
        chunk = want[i:i + 400]
        q = " OR ".join(["(bcode=? AND chapter=? AND verse=?)"] * len(chunk))
        args = [x for t in chunk for x in t]
        for bc, ch, vs, vid in conn.execute(
                "SELECT bcode, chapter, verse, verse_id FROM bible_index"
                " WHERE " + q, args):
            have[(bc, ch, vs)] = vid
    out = []
    for s, e, b, c, v in got:
        vid = have.get((b, c, v))
        if vid:
            out.append((s, e, vid, b, c, v))
    return out


def selftest(db_path='bible_master.db'):
    import appdb
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))

    # ── 이어지는 참조 (2026-09-06) ──────────────────────────────
    # 신앙고백 증거 구절이 `Rom. ii. 14, 15 ; i. 19, 20` 꼴이라 그전에는
    # **첫 하나만** 걸렸다(실측 웨스트민스터가 실제의 56% 만 읽었다).
    _t2 = names(appdb.connect(db_path), 'KO')

    def _got(txt):
        return [txt[a:b] for a, b, *_ in find(txt, _t2)]

    def _vs(txt):
        return [(bc, ch, v) for _a, _b, bc, ch, v in find(txt, _t2)]

    t('★ 같은 장의 추가 절 `, 15`',
      _vs('Rom. ii. 14, 15') == [(45, 2, 14), (45, 2, 15)])
    t('★ 책을 생략한 이어짐 `; i. 19`',
      _vs('Rom. ii. 14 ; i. 19') == [(45, 2, 14), (45, 1, 19)])
    t('★ 연쇄 — 장을 물려받는다',
      _vs('Rom. ii. 14, 15 ; i. 19, 20')
      == [(45, 2, 14), (45, 2, 15), (45, 1, 19), (45, 1, 20)])
    t('★ 자리는 숫자부터(;·, 는 링크 밖)',
      _got('Rom. ii. 14, 15') == ['Rom. ii. 14', '15'])
    # ⚠ **틈에 다른 글자가 있으면 안 잇는다** — 산문의 숫자를 절로 읽으면
    #   「그럴듯한데 엉뚱한 데로 가는 링크」가 된다(§123차).
    t('★ 낱말이 끼면 안 잇는다',
      _vs('Rom. ii. 14, and 15 men') == [(45, 2, 14)])
    t('★ 네 자리 수는 안 잇는다', _vs('Rom. ii. 14, 2026') == [(45, 2, 14)])
    t('★ 앞에 책이 없으면 안 잇는다', _vs('; ii. 1') == [])
    t('★ 장을 모르면 절만으로는 안 잇는다', _vs(', 15') == [])
    # ⚠ 이어 읽기가 **끝없이 물리면** 목록 번호에서 폭주한다 — 12개에서 멈춘다
    t('★ 연쇄 상한 12',
      len(_vs('Rom. ii. 1' + ', 2' * 30)) <= 13)

    t('로마숫자 xciv', _roman('xciv') == 94)
    t('로마숫자 xxxiii', _roman('xxxiii') == 33)
    t('로마숫자 iv', _roman('iv') == 4)
    t('★ 로마숫자가 아니면 None', _roman('joun') is None)

    conn = appdb.connect(db_path)
    tbl = names(conn, 'KO')
    t('★ 앞머리로 찾는다 Deut→신명기', _book(tbl, None, 'Deut.') == 5)
    t('★ Matt→마태복음', _book(tbl, None, 'Matt.') == 40)
    t('★ 서수 1 Thess→살전', _book(tbl, '1', 'Thess.') == 52)
    t('★ 서수 2 Cor→고후', _book(tbl, '2', 'Cor.') == 47)
    t('★ 여러 낱말 Song of Solomon', _book(tbl, None, 'Song of Solomon') == 22)
    t('★ 별명 Jas→야고보서', _book(tbl, None, 'Jas.') == 59)
    t('★ 한글 창', _book(tbl, None, '창') == 1)
    t('★ 한글 요한복음', _book(tbl, None, '요한복음') == 43)
    # ⚠ **탐지력** — 못 읽어야 할 것들
    t('★★ 성경 아닌 것은 안 읽는다 Sanh', _book(tbl, None, 'Sanh.') is None)
    t('★★ Anti(요세푸스) 안 읽는다', _book(tbl, None, 'Anti.') is None)
    t('★★ Macc(외경) 안 읽는다', _book(tbl, '2', 'Macc.') is None)
    t('★★ OCR 오류 Joun 안 읽는다', _book(tbl, None, 'Joun') is None)
    t('★★ 애매하면 안 읽는다 Jo', _book(tbl, None, 'Jo') is None)

    g = find('as it is written (Song iv. 8), and also 1 Thess. ii. 20 says', tbl)
    t('★ 로마숫자 두 건', len(g) == 2, [(x[2], x[3], x[4]) for x in g])
    t('  아가 4:8', g and g[0][2:] == (22, 4, 8), g[0][2:] if g else None)
    t('  살전 2:20', len(g) > 1 and g[1][2:] == (52, 2, 20))
    g2 = find('Luke 24:49; Acts 1:8 and Matt. 28:18', tbl)
    t('★ 아라비아 세 건', len(g2) == 3, [(x[2], x[3], x[4]) for x in g2])
    g3 = find('Sanh. x. 3 and Anti. viii. 3 and 2 Macc. xv. 1', tbl)
    t('★★ 성경 아닌 것 0건', len(g3) == 0, g3)
    g4 = find('the train arrives at 3:15 and again at 10:40', tbl)
    t('★★ 시각은 안 걸린다', len(g4) == 0, g4)
    g5 = find('Rev. 3 has seven letters', tbl)
    t('★★ 장 단위 표기는 안 걸린다(§123차)', len(g5) == 0, g5)

    r = resolve(conn, 'see Joshua 5:12 and Genesis 99:1 here', 'KO', tbl)
    t('★★ 없는 장은 뺀다', len(r) == 1 and r[0][3] == 6, r)
    r2 = resolve(conn, '창1:1 을 보라', 'KO', tbl)
    t('★ 한글 약명도 푼다', len(r2) == 1 and r2[0][2] == 1, r2)
    r3 = resolve(conn, 'Joshua 5:12', 'KO', tbl)
    if r3:
        s, e = r3[0][0], r3[0][1]
        t('★ 자리가 정확하다', 'Joshua 5:12'[0:] == 'Joshua 5:12'[s:e],
          repr('Joshua 5:12'[s:e]))
    else:
        t('★ 자리가 정확하다', False)
    t('★ 빈 글은 빈 목록', resolve(conn, '', 'KO', tbl) == [])
    conn.close()
    print('book_refs selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def _scan(db_path='bible_master.db', top=14):
    """전 도서 실측 — 몇 건이 걸리고 몇 건이 못 읽히나."""
    import appdb
    conn = appdb.connect(db_path)
    tbl = names(conn, 'KO')
    # ⚠ 분모도 **같은 서수 규칙**을 써야 정직하다 — `I{1,3}` 를 붙여 쓰게 두면
    #   `Isaiah` 가 「못 읽은 saiah」로 세어져 분모가 부풀고 비율이 낮게 나온다.
    rough = re.compile(
        r'(?<![0-9A-Za-z])(?:(?:[123]\s*\.?\s*)|(?:I{1,3}\s*(?:\.\s*|\s+)))?'
        r'[A-Z][A-Za-z]{1,13}(?![A-Za-z])\.?\s*'
        r'(?:\d{1,3}|[ivxlc]{1,7})\s*[:.]\s*\d{1,3}(?![0-9])')
    agg = {}
    for bc, ti, body in conn.execute(
            "SELECT ba.book_code, ba.title, t.body_text"
            "  FROM sys_book_asset ba"
            "  JOIN sys_book_unit u ON u.book_id=ba.book_id"
            "  JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
            "   AND t.text_variant='ORIGINAL'"):
        d = agg.setdefault(bc, {'t': ti, 'hit': 0, 'raw': 0, 'miss': {}})
        body = body or ''
        d['raw'] += len(rough.findall(body))
        for s, e, b, c, v in find(body, tbl):
            d['hit'] += 1
        for m in rough.finditer(body):
            w = re.match(r'\s*(?:([123])\s*\.?\s*|(I{1,3})\s*(?:\.\s*|\s+))?'
                         r'([A-Za-z]+)', m.group(0))
            w = (w.group(1) or w.group(2), w.group(3)) if w else None
            if w and _book(tbl, w[0], w[1]) is None:
                d['miss'][w[1]] = d['miss'].get(w[1], 0) + 1
    tot_h = sum(d['hit'] for d in agg.values())
    tot_r = sum(d['raw'] for d in agg.values())
    print('전 도서 — 약명 꼴 %d건 중 **%d건(%.1f%%) 읽힘**'
          % (tot_r, tot_h, 100.0 * tot_h / max(tot_r, 1)))
    print()
    for bc, d in sorted(agg.items(), key=lambda x: -x[1]['hit'])[:top]:
        ms = sorted(d['miss'].items(), key=lambda x: -x[1])[:3]
        print('  %-18s %-26s 읽힘 %5d / %5d   못 읽음: %s'
              % (bc, d['t'][:26], d['hit'], d['raw'],
                 ', '.join('%s×%d' % m for m in ms) or '-'))
    print()
    allmiss = {}
    for d in agg.values():
        for k, n in d['miss'].items():
            allmiss[k] = allmiss.get(k, 0) + n
    print('못 읽은 이름 상위 20 (전부 성경 책이 아니거나 OCR 오류여야 한다):')
    for k, n in sorted(allmiss.items(), key=lambda x: -x[1])[:20]:
        print('   %-14s %d' % (k, n))
    conn.close()


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--scan' in a:
        _scan()
    else:
        sys.exit(0 if selftest() else 1)
