# -*- coding: utf-8 -*-
"""db_media_drift.py — 미디어 분류 어긋남 지표의 자가 검증 (영구, 2026-09-07).

사용자 물음: 「이런 상황이 발생했는지 **어떤 지표를 통해서 미리 알 수 없다**.
지표를 통해서 관리자가 알 수 있는 장치를 만들 수 있는가? 아니면 **매일 재분류
실행을 눌러야 하는가**」 · 지시: 「**키워드 규칙을 바꾼 경우에는 무조건 재분류
실행을 눌러야 하도록 자동 프로세스로 등록**해야 할 것 같다」.

★★★ **매일 누를 일이 아니다 — 어긋나는 자리는 둘뿐이다.**
    ① **키워드 규칙을 고쳤을 때** — 옛 규칙으로 찍힌 유형이 그대로 남는다
    ② **수집 경로가 딴 문을 쓸 때** — 2026-09-07 에 실제로 났다(RSS 가
       `classify_media_type` 을 불러 11언어 380낱말을 한 번도 못 썼다)
  ⇒ ①은 **저장할 때 묻고 「밀린 재분류」를 남긴다**, ②는 **지표가 잡는다.**
  ★ 새로 수집되는 것은 수집·재분류·지표가 **같은 문·같은 재료**를 쓰므로
    저절로 안 어긋난다 — 그 불변식을 이 파일이 잰다.

★★ **이 검사가 지키는 것 넷**
  ⓐ 세 경로가 같은 분류 문을 부른다(`classify_content`)
  ⓑ 세 경로가 같은 재료를 쓴다(제목 + 채널명 · **설명문 없음**)
  ⓒ 지표(`drift`)와 재분류가 **같은 행**을 본다 — 아니면 「N건 어긋남」이라
    말해 놓고 눌러도 안 없어져 지표가 죽는다
  ⓓ 「규칙 고침 → 재분류」 밀림 표식이 양방향으로 돈다

⚠ **실 DB 에 한 글자도 안 쓴다** — 시각 열쇠는 시험 전 값을 적어 두고 되돌린다
  (§0-5 · 실전 사고 다섯 번).

사용:  python db_media_drift.py --selftest | --status | --reclass
  ⚠ `--reclass` 는 **화면 [재분류 실행]과 똑같은 문**(`tax.reclassify`)을 부른다 —
    두 벌이 아니다. 규칙을 코드로 고친 뒤 마무리할 때 쓴다.
"""
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')


def status(conn):
    import media_taxonomy as tax
    h = tax.health(conn)
    out = ['영상 %s건 · 어긋남 %s건 · 연결 없는 것 %s건'
           % (f"{h['total']:,}", f"{h['drift']:,}", f"{h['unlinked']:,}")]
    if h['pending']:
        out.append('⚠ 규칙을 고친 뒤 재분류를 안 했습니다 (고친 때 %s · 재분류 %s)'
                   % (h['kw_at'] or '-', h['run_at'] or '없음'))
    elif h['kw_at']:
        out.append('규칙 고친 때 %s · 재분류 %s' % (h['kw_at'], h['run_at'] or '없음'))
    if h['drift']:
        _n, ex = tax.drift(conn, limit=5)
        for mid, cur, new, title in ex:
            out.append('   %s %s → %s  %s' % (mid, cur, new, (title or '')[:46]))
    return '\n'.join(out)


def selftest():
    import io
    import re
    import appdb
    import media_taxonomy as tax
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    conn = appdb.connect('bible_master.db')

    # ── ⓐ 세 경로가 같은 분류 문을 부르는가 ────────────────────────────
    # ⚠⚠ **찾는 글자를 검사 코드에 그대로 적으면 자기가 걸린다**(§199차) —
    #   조립해서 만든다.
    _old = 'CR.' + 'classify_media_type('
    srcs = {}
    for f in ('db_yt_rss_collect.py', 'db_media_crawler.py',
              'admin/panel_media_classify.py'):
        srcs[f] = io.open(f, encoding='utf-8').read()
    t('★★★ 세 수집·재분류 경로가 같은 분류 문을 쓴다',
      all('classify_content' in s for s in srcs.values()),
      [f for f, s in srcs.items() if 'classify_content' not in s])
    t('  두 갈래짜리 옛 문을 아무도 안 부른다',
      not any(_old in s for s in srcs.values()),
      [f for f, s in srcs.items() if _old in s])

    # ── ⓑ 재료가 같은가 ──────────────────────────────────────────────
    # ⚠⚠ **설명문을 넣었다가 실측으로 뺐다**(2026-09-07) — 넣으면 RSS
    #   수집분 어긋남이 50 → 91로 늘고 판정이 나빠졌다(설교가 찬양으로).
    _desc = 'de' + "sc or ''"
    # ⚠ **소스 글자가 아니라 「무엇을 넘기는가」로 잰다** — 세 파일의 코드
    #   모양이 달라도(인라인 f-string / 헬퍼) 재료는 같아야 한다.
    _bad = []
    for f, src in srcs.items():
        for m in re.finditer(r'classify_content\(', src):
            seg = src[m.end():m.end() + 140]
            # `_row_text(title, desc_json)` 는 그 안에서 **채널만** 뽑으므로
            # 설명문을 섞는 것이 아니다 — 예외로 둔다.
            if '_row_text(' in seg:
                continue
            if re.search(r'\bdesc|description|yt_desc', seg):
                _bad.append('%s:%s' % (f, seg.split(chr(10))[0][:40]))
    t('★★ 분류에 넘기는 재료에 설명문이 안 섞인다', not _bad, _bad)
    t('  RSS 경로가 설명문을 안 섞는다',
      _desc not in srcs['db_yt_rss_collect.py'].replace("'de' + ", ''))
    # ⚠ **결정이 바뀌면 그것을 잠근 시험도 함께 뒤집는다**(§203차 ㉑) —
    #   화면은 이제 `tax.reclassify` 한 문에 위임하고, 재료·대상은 그 안에
    #   있다. 그러니 **몸통 쪽에서** 잰다.
    _mt = io.open('media_taxonomy.py', encoding='utf-8').read()
    t('  재분류 몸통이 재료 문(`_row_text`)을 쓴다',
      '_row_text(title, dj)' in _mt)

    # ── ⓒ 지표와 재분류가 같은 행을 보는가 ──────────────────────────
    t('★★★ 재분류 몸통이 대상 문(`reclass_rows`)을 쓴다',
      'reclass_rows(conn, scope=scope' in _mt)
    t('  몸통이 채널을 넘긴다(교회 판정이 돈다)',
      'channel=ch' in _mt)
    n_all = len(tax.reclass_rows(conn))
    n_lnk = len(tax.reclass_rows(conn, linked_only=True))
    t('★★ 기본 대상이 「연결 없는 것」을 포함한다', n_all >= n_lnk,
      '%d ≥ %d (차 %d)' % (n_all, n_lnk, n_all - n_lnk))
    # ⚠ 그 차이가 0 이면 이 검사가 헛돈다 — 실제로 연결 없는 영상이 있어야 한다
    t('  실제로 연결 없는 영상이 있다(검사가 헛돌지 않는다)', n_all > n_lnk,
      n_all - n_lnk)
    # ★★★ 갈래 라디오가 실제로 대상을 낸다 — 글자를 갈래로 읽어 0건이 되던 것
    n_peri = len(tax.reclass_rows(conn, scope='PERICOPE', linked_only=True))
    n_enti = len(tax.reclass_rows(conn, scope='ENTITY', linked_only=True))
    t('★★★ 「구절단락만」 대상이 0 이 아니다', n_peri > 0, n_peri)
    t('★★★ 「주요용어만」 대상이 0 이 아니다', n_enti > 0, n_enti)
    t('  두 갈래가 「연결된 것만」 안에 든다', n_peri <= n_lnk and n_enti <= n_lnk)
    t('  축 표가 하나다(현황 탭이 같은 것을 쓴다)',
      'tax.SCOPE_AXIS' in io.open('admin/panel_media_classify.py', encoding='utf-8').read())

    # 판정이 실제로 도는가 — 한 건을 일부러 뒤집어 잡히는지
    d0, _ = tax.drift(conn)
    row = None
    for mid, title, dj, lang, cur in tax.reclass_rows(conn):
        new = tax.classify_content(tax._row_text(title, dj), lang,
                                   tax.load_classify_sets(conn))
        if new == cur:
            row = (mid, cur, new)
            break
    if row:
        other = 'WORSHIP' if row[1] != 'WORSHIP' else 'STUDY'
        conn.execute("UPDATE sys_media_asset SET media_type=? WHERE media_id=?",
                     (other, row[0]))
        d1, _ = tax.drift(conn)
        conn.execute("UPDATE sys_media_asset SET media_type=? WHERE media_id=?",
                     (row[1], row[0]))
        conn.commit()
        d2, _ = tax.drift(conn)
        t('★★★ 어긋남 탐지력 — 하나 뒤집으면 하나 는다', d1 == d0 + 1,
          '%d → %d' % (d0, d1))
        t('  되돌리면 원래대로', d2 == d0, '%d' % d2)
    else:
        t('★ 탐지력 시험 표본을 못 찾았다', False)
        t('  (건너뜀)', False)

    # ── ⓔ 교회 채널의 「예배」는 찬양이 아니다 ────────────────────────
    # ★★★ 2026-09-07 사용자 확정 — 「**"교회" 채널에서 올린 "예배"라는 단어가
    #   들어가 있다면 비록 찬양이더라도 마커스 등의 찬양사역자들의 영상이
    #   아니다. 찬양 카테고리에서 제외하라. 아마 다른 언어권에서도 마찬가지**」.
    _s = tax.load_classify_sets(conn)

    def _cls(t, ch, lg='KO'):
        return tax.classify_content('%s %s' % (t, ch), lg, _s, channel=ch)

    t('★★★ 교회 채널의 찬양예배는 찬양이 아니다',
      _cls('주일1부예배 드림찬양대', '대구은천교회예배실황') != 'WORSHIP',
      _cls('주일1부예배 드림찬양대', '대구은천교회예배실황'))
    t('★★ 찬양사역 채널은 그대로 찬양이다',
      _cls('내 안에 있는 것 Everything I am', 'MARKERS WORSHIP') == 'WORSHIP')
    t('  영어 church 도 잡는다',
      _cls('Sunday Worship Service', 'Worship House Church') != 'WORSHIP')
    t('  다른 언어권도 잡는다(iglesia·igreja·교회·教会)',
      all(_cls('culto de adoración', x) != 'WORSHIP'
          for x in ('Iglesia Bautista', 'Igreja Batista', '중부명성교회')))
    # ⚠ **찬양만 물리고 나머지 판정은 그대로 둔다** — 성경공부가 SERMON 으로
    #   뭉개지면 안 된다.
    t('★★ 찬양을 물려도 성경공부는 살아난다',
      _cls('[ 찬양 | 수요성경공부 ] 여성 성가대', '100주년기념교회') == 'STUDY',
      _cls('[ 찬양 | 수요성경공부 ] 여성 성가대', '100주년기념교회'))
    # ⚠ **채널을 안 주면 옛 동작 그대로** — 옛 호출부가 안 깨진다
    t('  채널을 안 주면 지금까지와 같다',
      tax.classify_content('찬양예배 대구은천교회', 'KO', _s) == 'WORSHIP')
    # 실데이터로 — 교회 채널이 WORSHIP 에 남아 있으면 안 된다
    import json as _j
    bad_ch = []
    for _t, _d in conn.execute(
            "SELECT title, description FROM sys_media_asset WHERE "
            "COALESCE(record_status,'LIVE')='LIVE' AND format_type='VIDEO' "
            "AND media_type='WORSHIP'"):
        try:
            _c = (_j.loads(_d or '{}') or {}).get('channel') or ''
        except Exception:
            _c = ''
        if tax.is_church_channel(_c):
            bad_ch.append(_c)
    t('★★★ 실데이터 — 찬양에 교회 채널이 남아 있지 않다', not bad_ch,
      len(bad_ch))

    # ── ⓕ 재분류 몸통이 하나인가 ────────────────────────────────────
    t('★★★ 화면이 재분류 몸통(`reclassify`)을 쓴다',
      'tax.reclassify(' in srcs['admin/panel_media_classify.py'])
    _upd = 'UPD' + 'ATE sys_media_asset'
    t('  화면이 유형을 직접 UPDATE 하지 않는다',
      _upd not in srcs['admin/panel_media_classify.py'].replace("'UPD' + ", ''))

    # ── ⓓ 밀림 표식이 양방향으로 도는가 ─────────────────────────────
    # ⚠ **시험 전 값을 적어 두고 되돌린다** — 실 설정을 안 남긴다(§0-5).
    keep = {k: tax._cfg_get(conn, k)
            for k in (tax.KW_CHANGED_KEY, tax.RECLASS_RUN_KEY)}
    try:
        tax.mark_kw_changed(conn, '2000-01-01 00:00:00')
        tax.mark_reclass_run(conn, '2000-01-01 00:00:01')
        t('★ 재분류가 규칙보다 뒤면 밀리지 않는다',
          tax.reclass_pending(conn)[0] is False)
        tax.mark_kw_changed(conn, '2000-01-02 00:00:00')
        t('★★ 규칙을 고치면 밀린다', tax.reclass_pending(conn)[0] is True)
        tax.mark_reclass_run(conn, '2000-01-02 00:00:01')
        t('  재분류를 돌리면 풀린다', tax.reclass_pending(conn)[0] is False)
    finally:
        for k, v in keep.items():
            if v:
                tax._cfg_set(conn, k, v)
            else:
                conn.execute("DELETE FROM sys_config WHERE config_key=?", (k,))
        conn.commit()
    t('★ 시험 전 상태로 원복',
      all(tax._cfg_get(conn, k) == v for k, v in keep.items()),
      {k: tax._cfg_get(conn, k) for k in keep})

    # ── 화면이 지표를 실제로 그리는가 ────────────────────────────────
    s = srcs['admin/panel_media_classify.py']
    t('★★ 현황 화면이 지표를 그린다',
      '_refresh_health' in s and 'tax.health(' in s)
    t('★★★ 규칙을 저장하면 재분류를 묻는다',
      'mark_kw_changed' in s and 'askyesno' in s and '_goto_reclass' in s)
    t('  재분류를 돌리면 그 때를 남긴다', 'mark_reclass_run' in s)
    # ⚠ **탭 번호를 박지 않는다** — 탭이 늘면 엉뚱한 화면으로 간다
    t('  재분류 탭을 이름으로 찾는다',
      "'재분류' in" in s and 'select(i)' in s)

    conn.close()
    print('db_media_drift selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    import media_taxonomy as tax
    c = appdb.connect('bible_master.db')
    if '--reclass' in sys.argv:
        n, sk, dist = tax.reclassify(c, on_log=lambda m: print('  ' + m))
        print('  바뀐 것 %d · 건너뜀 %d' % (n, sk))
        print('  분포 %s' % ' · '.join('%s:%d' % x for x in dist.most_common()))
        print()
    print(status(c))
    c.close()
