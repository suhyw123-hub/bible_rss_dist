# -*- coding: utf-8 -*-
"""주석 항목의 **단위**(`entry_level`)를 실제에 맞게 고친다 (2026-09-12 신설·영구).

★★★ **왜 필요한가**(실측) — 적힌 단위와 진짜 단위가 다르다.
  **매튜 헨리가 `VERSE` 라고 적혀 있는데 한 항목이 장 전체다** — 평균
  **32,994자** · 요 3:16 에 94,598자가 붙고 **시 1:1 과 시 1:3 에 글자 수까지
  똑같은 19,476자**가 붙는다. JFB·칼빈 시편도 절이 아니라 **단락**이다.
  화면이 [절]·[단락]·[장] 으로 가르려면 **이 칸이 참이어야** 한다.

★★★ **판정은 「항목 수 ÷ 덮는 장 수」다** — 깨끗하게 갈린다(실측):
  | 항목/장 | 소스 | 진짜 |
  |---|---|---|
  | **1.00** | 매튜 헨리 · 어거스틴 · 매클라렌 · 각 CHAPTER 항목 | **장** |
  | 1.68 · 4.13 | JFB · 칼빈 시편 | **단락** |
  | 11.8 ~ 25.1 | 반스 · 클라크 · 존 길 · 풀핏 · 스펄전 3종 | **절** |
  ⚠ **글자 수로 재면 안 된다** — 긴 절 주석과 짧은 장 주석이 섞인다
    (GILL 의 CHAPTER 항목이 1,086자, CALVIN 의 절 항목이 6,961자다).
  ⚠ **덮는 절 수로도 안 된다** — JFB 가 15.2절이라 장으로 잘못 나온다.

⚠ **사람이 고친 것을 안 덮는다** — `note` 에 표식을 남기고 `--undo` 로 되돌린다.
⚠ **쿼터 0** — DB 만 읽는다.

    python db_commentary_level.py --selftest   (의무)
    python db_commentary_level.py --check      지금과 무엇이 다른가
    python db_commentary_level.py --apply      고친다
    python db_commentary_level.py --undo       되돌린다
"""
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb                                                  # noqa: E402

#: 단위 이름 — 스키마가 정한 값(§8)
LV_VERSE, LV_PERI, LV_CHAP, LV_BOOK = 'VERSE', 'PERICOPE', 'CHAPTER', 'BOOK'
#: 화면에 뜨는 이름. ★ **여기가 단일 소스다** — 화면이 따로 적지 않는다.
LV_LABEL = {LV_VERSE: '절', LV_PERI: '단락', LV_CHAP: '장', LV_BOOK: '책'}
#: 화면이 늘어놓는 차례(사용자 확정 2026-09-12 — 「배치순서 절 단락 장」)
LV_ORDER = (LV_VERSE, LV_PERI, LV_CHAP)
#: 판정 문턱 — 항목 수 ÷ 덮는 장 수
CHAP_MAX = 1.3       # 이하면 장
VERSE_MIN = 6.0      # 이상이면 절 (그 사이는 단락)
#: 되돌릴 수 있게 남기는 표식
NOTE = 'LEVEL_FIX'


def judge(n_entry, n_chapter):
    """항목 수와 덮는 장 수 → 진짜 단위."""
    if not n_chapter:
        return LV_VERSE
    per = n_entry / float(n_chapter)
    if per <= CHAP_MAX:
        return LV_CHAP
    if per >= VERSE_MIN:
        return LV_VERSE
    return LV_PERI


def survey(conn):
    """소스·적힌단위마다 진짜 단위를 잰다 → [dict]."""
    out = []
    for code, cid, lv, n, nch in conn.execute("""
      SELECT s.commentary_code, e.commentary_id, e.entry_level, COUNT(*),
             COUNT(DISTINCT b.bcode*1000+b.chapter)
        FROM sys_commentary_entry e
        JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
        JOIN bible_index b ON b.verse_id=e.start_vid
       WHERE COALESCE(e.record_status,'LIVE')='LIVE'
         AND COALESCE(s.record_status,'LIVE')='LIVE'
       GROUP BY 1,2,3"""):
        out.append({'code': code, 'commentary_id': cid, 'level': lv,
                    'n': n, 'n_chapter': nch,
                    'per': n / float(max(nch, 1)),
                    'real': judge(n, nch)})
    return sorted(out, key=lambda r: (r['code'], -r['n']))


def ensure(conn):
    """비고 칸 — 멱등 ALTER. 고친 자국을 여기에 적는다."""
    cols = {r[1] for r in conn.execute("PRAGMA table_info(sys_commentary_entry)")}
    if 'note' not in cols:
        conn.execute("ALTER TABLE sys_commentary_entry ADD COLUMN note TEXT")
        conn.commit()


def apply_fix(conn, rows=None, dry=False, log=print):
    """어긋난 항목의 `entry_level` 을 고친다 → 고친 수.

    ⚠ **표식을 남긴다** — 무엇을 무엇으로 바꿨는지 적어야 되돌릴 수 있다.
    """
    ensure(conn)
    rows = rows if rows is not None else survey(conn)
    n = 0
    for r in rows:
        if r['real'] == r['level']:
            continue
        mark = '%s:%s>%s' % (NOTE, r['level'], r['real'])
        cnt = conn.execute(
            "SELECT COUNT(*) FROM sys_commentary_entry"
            "  WHERE commentary_id=? AND entry_level=?"
            "    AND COALESCE(record_status,'LIVE')='LIVE'",
            (r['commentary_id'], r['level'])).fetchone()[0]
        if not dry:
            conn.execute(
                "UPDATE sys_commentary_entry"
                "   SET entry_level=?,"
                "       note=CASE WHEN COALESCE(note,'')='' THEN ?"
                "                 ELSE note || ' ' || ? END"
                " WHERE commentary_id=? AND entry_level=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'",
                (r['real'], mark, mark, r['commentary_id'], r['level']))
        n += cnt
        log('  %-16s %-8s → %-8s  %5d항목 (항목/장 %.2f)'
            % (r['code'], r['level'], r['real'], cnt, r['per']))
    if not dry:
        conn.commit()
    log('  [단위] 고친 항목 %d개%s' % (n, ' (미리보기)' if dry else ''))
    return n


def undo(conn, log=print):
    """표식이 있는 항목을 옛 단위로 되돌린다 → 되돌린 수."""
    import re
    ensure(conn)
    rows = conn.execute(
        "SELECT entry_id, note FROM sys_commentary_entry"
        # status-ok: 가린 항목도 되돌린다 — 상태로 거르면 되살리는 날
        #            옛 단위가 그대로 남는다(§241차 ⑥ 그 까닭)
        "  WHERE note LIKE ?", ('%' + NOTE + '%',)).fetchall()
    n = 0
    for eid, note in rows:
        m = re.search(NOTE + r':([A-Z]+)>([A-Z]+)', note or '')
        if not m:
            continue
        clean = re.sub(r'\s*' + NOTE + r':[A-Z]+>[A-Z]+', '', note or '').strip()
        conn.execute("UPDATE sys_commentary_entry SET entry_level=?, note=?"
                     "  WHERE entry_id=?", (m.group(1), clean or None, eid))
        n += 1
    conn.commit()
    log('  [단위] 되돌린 항목 %d개' % n)
    return n


def selftest():
    import sqlite3
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    # ① 판정 — 실측한 값 그대로
    t('매튜 헨리(1,186/1,186)는 장', judge(1186, 1186) == LV_CHAP)
    t('어거스틴(150/150)은 장', judge(150, 150) == LV_CHAP)
    t('JFB(1,973/1,173)는 단락', judge(1973, 1173) == LV_PERI)
    t('칼빈 시편(620/150)은 단락', judge(620, 150) == LV_PERI)
    t('클라크(20,076/1,187)는 절', judge(20076, 1187) == LV_VERSE)
    t('존 길(21,769/928)은 절', judge(21769, 928) == LV_VERSE)
    t('풀핏(3,422/289)은 절', judge(3422, 289) == LV_VERSE)
    t('장 수를 모르면 절로 둔다', judge(10, 0) == LV_VERSE)
    # ⚠ 문턱 앞뒤
    t('문턱 위는 장', judge(13, 10) == LV_CHAP)
    t('문턱 넘으면 단락', judge(14, 10) == LV_PERI)
    t('절 문턱 아래는 단락', judge(59, 10) == LV_PERI)
    t('절 문턱 위는 절', judge(60, 10) == LV_VERSE)
    # ★ 차례와 이름이 한 곳에 있다
    t('차례가 절·단락·장', LV_ORDER == (LV_VERSE, LV_PERI, LV_CHAP))
    t('이름이 있다', LV_LABEL[LV_VERSE] == '절' and LV_LABEL[LV_PERI] == '단락')

    # ② 고치기·되돌리기 왕복
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_commentary_source(commentary_id INTEGER PRIMARY KEY,
        commentary_code TEXT, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_commentary_entry(entry_id INTEGER PRIMARY KEY,
        commentary_id INT, entry_level TEXT, start_vid INT, end_vid INT,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT,
        chapter INT, verse INT);
    """)
    c.execute("INSERT INTO sys_commentary_source VALUES(1,'FAKE','LIVE')")
    for i in range(1, 31):
        c.execute("INSERT INTO bible_index VALUES(?,1,?,?)",
                  (i, (i - 1) // 10 + 1, (i - 1) % 10 + 1))
    # 장 하나에 항목 하나 = 장 단위인데 VERSE 라 적혀 있다
    for ch in (1, 2, 3):
        c.execute("INSERT INTO sys_commentary_entry(commentary_id, entry_level,"
                  " start_vid, end_vid) VALUES(1,'VERSE',?,?)",
                  ((ch - 1) * 10 + 1, ch * 10))
    t('note 칸이 없다', 'note' not in {r[1] for r in
                                   c.execute("PRAGMA table_info(sys_commentary_entry)")})
    sv = survey(c)
    t('진짜 단위를 장으로 본다', sv and sv[0]['real'] == LV_CHAP, sv)
    t('미리보기는 안 고친다',
      apply_fix(c, dry=True, log=lambda *a: None) == 3
      and c.execute("SELECT entry_level FROM sys_commentary_entry"
                    "  WHERE entry_id=1").fetchone()[0] == 'VERSE')
    t('고친다', apply_fix(c, log=lambda *a: None) == 3)
    t('값이 바뀌었다', c.execute(
        "SELECT entry_level FROM sys_commentary_entry"
        "  WHERE entry_id=1").fetchone()[0] == LV_CHAP)
    t('표식을 남긴다', NOTE in (c.execute(
        "SELECT note FROM sys_commentary_entry WHERE entry_id=1").fetchone()[0] or ''))
    t('두 번 걸어도 한 번만(멱등)', apply_fix(c, log=lambda *a: None) == 0)
    t('되돌린다', undo(c, log=lambda *a: None) == 3)
    t('옛 값으로 돌아온다', c.execute(
        "SELECT entry_level FROM sys_commentary_entry"
        "  WHERE entry_id=1").fetchone()[0] == 'VERSE')
    t('표식이 걷힌다', not (c.execute(
        "SELECT note FROM sys_commentary_entry WHERE entry_id=1").fetchone()[0] or ''))
    t('항목을 지우지 않는다', c.execute(
        "SELECT COUNT(*) FROM sys_commentary_entry").fetchone()[0] == 3)
    # ⚠ 남의 비고를 지우지 않는다
    c.execute("UPDATE sys_commentary_entry SET note='사람이 적은 말' WHERE entry_id=1")
    apply_fix(c, log=lambda *a: None)
    undo(c, log=lambda *a: None)
    t('남의 비고는 남는다', c.execute(
        "SELECT note FROM sys_commentary_entry WHERE entry_id=1").fetchone()[0]
        == '사람이 적은 말')
    c.close()

    # ③ 본문을 지우는 SQL 을 여기서 쓰지 않는다
    src = io.open(__file__, encoding='utf-8').read()
    body = src.split('def selftest')[0]
    t('항목을 지우지 않는다(소스)',
      ('DELETE FROM ' + 'sys_commentary_entry') not in body)
    t('본문을 안 건드린다',
      'sys_commentary_text' not in body)

    print('db_commentary_level selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    conn.execute("PRAGMA busy_timeout=60000")
    try:
        if '--undo' in a:
            undo(conn)
            return
        rows = survey(conn)
        print('%-16s %-8s %6s %6s %7s  %s'
              % ('코드', '적힌단위', '항목', '덮는장', '항목/장', '진짜'))
        for r in rows:
            mark = '  ⚠ 어긋남' if r['real'] != r['level'] else ''
            print('%-16s %-8s %6d %6d %7.2f  %-8s%s'
                  % (r['code'], r['level'], r['n'], r['n_chapter'],
                     r['per'], r['real'], mark))
        print()
        apply_fix(conn, rows, dry=('--apply' not in a))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
