"""중앙 DB 연결 헬퍼 — sys 레퍼런스(bible_master.db) + user 개인데이터(user_data.db) 분리.

`appdb.connect(path)` 는 bible_master.db 를 열고 user_data.db 를 `userdb` 로 ATTACH 한다.
테이블 이름이 충돌하지 않으므로(sys_/bible_/ui_ vs user_) unqualified 참조가 자동 해석되고,
PRAGMA table_info·트리거·cross-DB UNION 모두 정상 동작한다(검증 완료).

- :memory: / 다른 DB 파일 → ATTACH 안 함(그대로 sqlite3.connect 처럼 동작).
- user_data.db 가 없으면 ATTACH 생략(sys_ 만 쓰는 일회성 스크립트 안전).
- 기존 코드 호환: 시그니처는 sqlite3.connect 와 동일하게 (path, *args, **kwargs).
"""
import sqlite3
import os
import threading
from contextlib import contextmanager

# ── 설치 경로 독립 (2026-07-30) ────────────────────────────────────────────
# DB 경로를 상대명으로 두면 **현재 작업 디렉터리(CWD)** 기준으로 해석된다.
# 바로가기의 '시작 위치'가 비었거나, 작업 스케줄러·다른 폴더에서 실행하면
# 빈 DB 가 그 자리에 새로 만들어지고 앱이 텅 빈 채 뜬다(실제 발생 이력 §34).
# → 모든 기본 경로는 **이 모듈이 있는 폴더(=앱 폴더)** 기준으로 해석한다.
#   앱을 어느 드라이브·폴더에 설치하든, 어디서 실행하든 동일하게 동작한다.
APP_DIR = os.path.dirname(os.path.abspath(__file__))

MAIN_DB_NAME = 'bible_master.db'
USER_DB_NAME = 'user_data.db'
USER_DB = USER_DB_NAME  # 하위호환(파일명 — user_db_path 의 join 용)


def app_path(*parts):
    """앱 폴더 기준 절대경로. 리소스 참조는 전부 이걸로.

    예) appdb.app_path('bible_master.db') / appdb.app_path('data', 'tiles')
    """
    return os.path.join(APP_DIR, *parts)


MAIN_DB = app_path(MAIN_DB_NAME)


def resolve_db(path):
    """DB 인자 경로 정규화.

    ⚠⚠ **`None`·빈 값은 기본 DB 로 돌린다** (2026-08-27 — 실제로 데었다).
      그전에는 `str(None)` 이 되어 **`<앱폴더>/None` 이라는 빈 파일**을 만들어
      열었다. 표가 하나도 없고 `userdb` 도 안 붙으므로 화면에는
      **「unknown database userdb」** 만 뜬다 — 어디가 틀렸는지 알 수 없다.
      실제 사고: `panel_std.link_tab(db_path=None)` 을 **호출부 넷이 아무도
      안 넘겨** [연결 편집…] 이 처음부터 안 열렸다(사용자: 「이전부터 계속 이
      모양이다. 테스트 불가」).
      ⇒ 조용히 엉뚱한 파일을 만드는 대신 **기본 DB 로 돌린다.**

    'bible_master.db' / 'user_data.db' 처럼 **폴더 없는 파일명**만 준 경우는
    CWD 가 아니라 **앱 폴더** 기준으로 푼다(기존 호출부 수백 곳을 무수정 구제).
    절대경로·폴더 포함 경로·':memory:' 는 그대로 둔다.
    """
    if path is None or (isinstance(path, str) and not path.strip()):
        path = MAIN_DB
    p = str(path)
    if p == ':memory:' or os.path.isabs(p) or os.path.dirname(p):
        return p
    if p.lower() in (MAIN_DB_NAME, USER_DB_NAME):
        return app_path(p)
    return p


def user_db_path(main_path):
    """main DB 경로 기준 같은 폴더의 user_data.db 절대경로."""
    d = os.path.dirname(os.path.abspath(str(resolve_db(main_path)))) or '.'
    return os.path.join(d, USER_DB_NAME)


def connect(database=MAIN_DB, *args, **kwargs):
    """bible_master.db 연결 + user_data.db ATTACH(userdb). sqlite3.connect 드롭인 대체."""
    database = resolve_db(database)
    sh = _scope_conn(database, args, kwargs)
    if sh is not None:
        return sh
    conn = sqlite3.connect(database, *args, **kwargs)
    try:
        # 다중 프로세스(사용자앱+관리자앱) 동시 접근 시 'database is locked' 방지:
        # 잠금 시 즉시 실패하지 말고 대기 후 재시도(쓰기는 보통 수 ms). 명시 timeout 은 줄이지 않음.
        if 'timeout' not in kwargs:
            conn.execute("PRAGMA busy_timeout=20000")
    except Exception:
        pass
    try:
        p = str(database)
        if p != ':memory:' and os.path.basename(p).lower() == MAIN_DB_NAME:
            udb = user_db_path(p)
            if os.path.exists(udb):
                conn.execute("ATTACH DATABASE ? AS userdb", (udb,))
                # 사용자 개인 DB(빈번한 RSS 캐시 쓰기)는 WAL — 읽기/쓰기 동시성 향상(배포 DB 아님)
                try:
                    conn.execute("PRAGMA userdb.journal_mode=WAL")
                except Exception:
                    pass
    except Exception:
        # ATTACH 실패해도 메인 연결은 반환(분리 전 상태나 권한 문제에서도 앱 가동)
        pass
    return conn


# ── 한 번의 화면 갱신 동안만 연결 하나·계산 한 번 (2026-10-13 docs/1.txt 74-11) ─────────────────────────
# 실측 — 구절 하나를 누르면 `connect` 가 109번(한 번에 ~40ms: 배포 DB 구조 591개 읽기 + 내 자료 ATTACH)
#   불리고 같은 계산(링크 목록)이 11번 돌아 **7.8~10초**가 걸렸다.
# ★ `with appdb.scope():` 안에서는 **그 스레드의** `connect()` 가 연결 하나를 나눠 쓰고(`_Shared`),
#   `appdb.memo(열쇠, 함수)` 가 같은 계산을 한 번만 한다. 범위가 끝나면 **둘 다 버린다** — 오래된 수가 안 남는다.
# ⚠ 범위는 짧게(구절 선택 처리 한 번) — 그 안에서 쓴 것은 같은 연결이라 바로 보인다.
# ⚠ `row_factory` 는 **커서마다** 따로 건다 — 한 쪽이 Row 로 바꿔도 다른 쪽은 튜플을 받는다.
# ⚠ `close()` 는 아무것도 안 한다(범위가 닫는다). `with` 는 sqlite3 와 같이 커밋/되돌림.
_TL = threading.local()


class _Shared:
    def __init__(self, real):
        self._c = real
        self.row_factory = None

    def _cur(self):
        cur = self._c.cursor()
        cur.row_factory = self.row_factory
        return cur

    def execute(self, sql, params=()):
        return self._cur().execute(sql, params)

    def executemany(self, sql, seq):
        return self._cur().executemany(sql, seq)

    def executescript(self, sql):
        return self._c.executescript(sql)

    def cursor(self, *a, **k):
        cur = self._c.cursor(*a, **k)
        cur.row_factory = self.row_factory
        return cur

    def commit(self):
        self._c.commit()

    def rollback(self):
        self._c.rollback()

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, et, ev, tb):
        if et is None:
            self._c.commit()
        else:
            self._c.rollback()
        return False

    def __getattr__(self, n):
        return getattr(self._c, n)


def _scope_conn(database, args, kwargs):
    if getattr(_TL, 'depth', 0) <= 0 or args or kwargs or str(database) != str(MAIN_DB):
        return None
    if getattr(_TL, 'conn', None) is None:
        _TL.depth -= 1                      # 진짜 연결을 만든다(재귀 방지)
        try:
            _TL.conn = connect(database)
        finally:
            _TL.depth += 1
    return _Shared(_TL.conn)


@contextmanager
def scope(memo_dict=None):
    """이 스레드에서 짧은 화면 갱신 한 번 동안 연결 하나·계산 한 번(겹쳐 써도 된다).
    `memo_dict` 를 주면 그 dict 에 계산을 기억한다 — 나뉘어 도는 두 단계(바로 · 조금 뒤)가 같은 계산을 나눠 쓴다."""
    _TL.depth = getattr(_TL, 'depth', 0) + 1
    if _TL.depth == 1:
        _TL.conn, _TL.memo = None, (memo_dict if memo_dict is not None else {})
    try:
        yield
    finally:
        _TL.depth -= 1
        if _TL.depth == 0:
            c, _TL.conn, _TL.memo = getattr(_TL, 'conn', None), None, {}
            if c is not None:
                try:
                    c.commit()
                    c.close()
                except Exception:
                    pass


def memo(key, fn):
    """범위 안이면 같은 열쇠의 계산을 한 번만 한다. 범위 밖이면 그냥 부른다."""
    if getattr(_TL, 'depth', 0) <= 0:
        return fn()
    m = _TL.memo
    if key not in m:
        m[key] = fn()
    return m[key]
