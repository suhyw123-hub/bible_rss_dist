# -*- coding: utf-8 -*-
"""말씀카드 세부마다 추천 구절 — 배포 자료(2026-10-21 · docs/1.txt 9-2 · docs/사진테마분류.txt).

★ 사용자 결정 — 「이 정도 체계를 잡아 놓고 내가 PC 화면에서 수정하겠다 · 구절 본문이 표시되어야 한다」.
  · 갈래·세부 = 프롬프트 라이브러리(ai_lib) 의 자리 CARD:<갈래> · Pick 열쇠(CC_1 …). 여기는 **세부 열쇠에 매인 구절**.
  · 구절은 언어 중립 좌표 「책:장:절[-끝절]」 — 본문은 보는 쪽 역본으로 읽는다(다국어 그대로).
  · 한 줄 설명(왜 이 상황에 맞나)은 언어마다 한 줄(`sys_card_verse_text`) · 한국어 먼저.
  · 카드 한 장에 담기므로 **한두 절**만(긴 구간은 핵심 절) · 결과를 약속하는 구절은 뺀다(병 · 기도 응답).

표 둘(CORE · 폰 공통팩에도 실린다)
  sys_card_verse       cv_id · sub_key · sort_order · ref · record_status
  sys_card_verse_text  cv_id · lang_code · note                     PK(cv_id, lang_code)

  python db_card_verse.py --selftest | --seed [--force] | --list
"""
import re
import sys

#: 세부 열쇠 → [(좌표, 한 줄 설명)] — 처음 판(docs/사진테마분류.txt 를 카드 길이에 맞춰 골랐다)
SEED = {
    # ── 축하 ──
    'CC_1': [('19:139:14', '하나님의 놀라운 지으심에 대한 감사'),
             ('19:20:4', '마음의 소원과 계획을 이루어 주시기를 비는 축복'),
             ('4:6:24-26', '보호와 은혜와 평강을 비는 축복'),
             ('19:118:24', '하나님이 주신 오늘을 기뻐함'),
             ('19:65:11', '한 해를 은혜로 관 씌우시는 하나님'),
             ('59:1:17', '모든 좋은 선물이 위로부터 옴'),
             ('25:3:22-23', '아침마다 새로운 하나님의 긍휼')],
    'CC_2': [('1:2:24', '부부가 한 몸을 이루는 연합'),
             ('21:4:12', '세 겹 줄 — 함께할 때의 힘'),
             ('22:8:7', '많은 물도 끄지 못하는 사랑'),
             ('46:13:4', '오래 참고 온유한 사랑'),
             ('49:4:2', '겸손과 온유와 오래 참음으로 서로 용납함'),
             ('51:3:14', '모든 것을 온전하게 매는 띠인 사랑'),
             ('45:12:10', '서로 사랑하고 존경하기를 먼저 함'),
             ('6:24:15', '우리 집은 여호와를 섬기겠노라는 결단')],
    'CC_3': [('19:127:3', '자녀는 여호와의 기업'),
             ('1:33:5', '하나님이 은혜로 주신 자식'),
             ('9:1:27', '기도로 얻은 아이에 대한 감사'),
             ('41:10:16', '어린아이를 안고 축복하시는 예수님'),
             ('23:54:13', '자녀가 여호와의 가르침을 받고 평강을 누림'),
             ('59:1:17', '새 생명이라는 좋은 선물')],
    'CC_4': [('6:1:9', '두려워하지 말고 담대하라는 격려'),
             ('20:3:5-6', '하나님을 신뢰하고 길을 맡김'),
             ('19:32:8', '갈 길을 가르치고 인도하시는 하나님'),
             ('19:37:5', '너의 길을 여호와께 맡기라'),
             ('5:31:8', '앞서 가시며 함께하시는 하나님'),
             ('50:1:6', '시작하신 선한 일을 이루실 하나님')],
    'CC_5': [('19:90:17', '손으로 하는 일을 견고하게 해 주시기를 구함'),
             ('20:16:3', '행사를 여호와께 맡김'),
             ('51:3:23', '무슨 일이든 주께 하듯 마음을 다함'),
             ('19:121:8', '출입을 지키시는 하나님'),
             ('46:15:58', '주 안에서의 수고가 헛되지 않음')],
    'CC_6': [('47:5:17', '그리스도 안에서 새로운 피조물'),
             ('45:6:4', '새 생명 가운데서 행하게 하심'),
             ('48:2:20', '그리스도께서 내 안에 사심'),
             ('60:2:9', '택하신 족속, 하나님의 소유된 백성'),
             ('50:1:6', '시작하신 선한 일을 이루실 하나님')],
    # ── 위로 ──
    'CO_1': [('19:41:3', '병상에서 붙드시는 하나님'),
             ('19:147:3', '상심한 자를 고치시고 상처를 싸매심'),
             ('23:41:10', '두려워하지 말라, 내가 너를 붙들리라'),
             ('60:5:7', '모든 염려를 주께 맡김'),
             ('19:46:1', '환난 중에 만날 큰 도움'),
             ('23:40:29', '피곤한 자에게 능력을 주심'),
             ('40:11:28', '수고하고 무거운 짐 진 자에게 주시는 쉼')],
    'CO_2': [('19:34:18', '마음이 상한 자에게 가까이하시는 하나님'),
             ('40:5:4', '애통하는 자에게 주시는 위로'),
             ('43:11:25', '부활이요 생명이신 예수님'),
             ('47:1:3-4', '모든 환난 중에 위로하시는 하나님'),
             ('5:33:27', '영원하신 팔로 붙드시는 하나님'),
             ('66:21:4', '모든 눈물을 씻기실 날')],
    'CO_3': [('20:24:16', '의인은 일곱 번 넘어져도 다시 일어남'),
             ('33:7:8', '엎드러질지라도 일어나리라는 소망'),
             ('19:37:24', '넘어져도 아주 엎드러지지 않게 붙드심'),
             ('47:4:8-9', '우겨쌈을 당해도 싸이지 않음'),
             ('19:42:11', '낙심한 영혼아 하나님을 바라라'),
             ('23:43:19', '새 일을 행하시는 하나님')],
    'CO_4': [('19:121:8', '출입을 영원까지 지키시는 하나님'),
             ('4:6:24-26', '떠나는 이에게 비는 은혜와 평강'),
             ('5:31:8', '앞서 가시며 떠나지 않으시는 하나님'),
             ('1:28:15', '어디로 가든지 지키시는 하나님'),
             ('40:28:20', '세상 끝날까지 함께하시는 예수님'),
             ('19:139:9-10', '바다 끝에서도 붙드시는 하나님')],
    # ── 격려 ──
    'CH_1': [('6:1:9', '강하고 담대하라'),
             ('59:1:5', '지혜가 부족하면 하나님께 구하라'),
             ('50:4:6-7', '염려를 기도로 맡길 때 주시는 평강'),
             ('55:1:7', '두려움이 아니라 능력과 사랑과 절제의 영'),
             ('23:41:10', '함께하시고 붙드시는 하나님'),
             ('19:56:3', '두려워하는 날에 주를 의지함')],
    'CH_2': [('23:43:19', '새 일을 행하시는 하나님'),
             ('25:3:22-23', '아침마다 새로운 긍휼'),
             ('47:5:17', '그리스도 안에서 새로운 피조물'),
             ('50:3:13-14', '뒤엣것을 잊고 푯대를 향해 나아감'),
             ('20:16:9', '사람이 계획해도 걸음을 인도하시는 하나님'),
             ('45:15:13', '소망의 하나님이 기쁨과 평강으로 채우심')],
    'CH_3': [('46:15:58', '주의 일에 힘쓰는 수고가 헛되지 않음'),
             ('48:6:9', '선을 행하다가 낙심하지 말라'),
             ('58:6:10', '섬긴 사랑을 잊지 않으시는 하나님'),
             ('51:3:23', '주께 하듯 마음을 다해 일함'),
             ('13:28:20', '맡겨진 일 앞에서 두려워하지 말라'),
             ('52:5:11', '서로 권면하고 피차 덕을 세움')],
    'CH_4': [('40:11:28', '수고하고 무거운 짐 진 자에게 주시는 쉼'),
             ('23:40:31', '여호와를 앙망하는 자가 새 힘을 얻음'),
             ('19:23:2-3', '쉴 만한 물가로 인도하시고 영혼을 소생시키심'),
             ('2:33:14', '내가 친히 가리라, 너를 쉬게 하리라'),
             ('41:6:31', '한적한 곳에서 잠깐 쉬어라'),
             ('19:62:1', '내 영혼이 잠잠히 하나님만 바람'),
             ('58:12:3', '피곤하여 낙심하지 않도록 예수님을 생각함')],
    # ── 감사 ──
    'CT_1': [('50:1:3', '생각할 때마다 하나님께 감사함'),
             ('52:5:18', '범사에 감사하라'),
             ('19:107:1', '선하시고 인자하심이 영원하신 하나님께 감사'),
             ('51:3:15', '그리스도의 평강과 감사하는 마음'),
             ('57:1:7', '너의 사랑으로 기쁨과 위로를 얻음'),
             ('47:9:15', '말할 수 없는 은사로 인한 감사')],
    'CT_2': [('50:1:3', '생각할 때마다 하나님께 감사함'),
             ('52:5:12-13', '수고하고 가르치는 이를 귀히 여김'),
             ('58:13:7', '말씀을 일러 준 인도자를 기억함'),
             ('55:1:5', '할머니와 어머니에게 이어진 거짓 없는 믿음'),
             ('20:23:24-25', '자녀로 인해 기뻐하는 부모'),
             ('20:31:28', '자식들이 일어나 감사하는 어머니')],
    'CT_3': [('58:6:10', '섬긴 사랑을 잊지 않으시는 하나님'),
             ('57:1:7', '성도들의 마음이 너로 평안함을 얻음'),
             ('46:15:58', '주 안에서의 수고가 헛되지 않음'),
             ('40:25:21', '착하고 충성된 종에 대한 칭찬'),
             ('52:5:12-13', '수고하는 이를 사랑 안에서 귀히 여김')],
    # ── 기도 ──
    'CP_1': [('50:1:3-4', '너희를 생각하며 기쁨으로 간구함'),
             ('51:1:9', '하나님의 뜻을 아는 지식으로 채워지기를'),
             ('49:3:16-17', '속사람이 강건해지기를 비는 기도'),
             ('53:1:11', '선을 기뻐하는 마음을 이루시기를'),
             ('45:15:13', '소망의 하나님이 기쁨과 평강으로 채우시기를'),
             ('49:1:16', '기도할 때 너희를 기억함')],
    'CP_2': [('64:1:2', '강건하기를 비는 인사'),
             ('19:147:3', '상처를 싸매시는 하나님'),
             ('19:41:3', '병상에서 붙드시는 하나님'),
             ('60:5:7', '염려를 주께 맡김'),
             ('23:40:29', '피곤한 자에게 능력을 주심')],
    'CP_3': [('4:6:24-26', '은혜와 평강을 비는 축복'),
             ('43:14:27', '세상이 주는 것과 다른 예수님의 평안'),
             ('50:4:6-7', '모든 지각에 뛰어난 하나님의 평강'),
             ('53:3:16', '평강의 주께서 때마다 평강을 주시기를'),
             ('23:26:3', '심지가 견고한 자를 평강으로 지키심'),
             ('19:4:8', '평안히 눕고 자게 하시는 하나님'),
             ('19:29:11', '자기 백성에게 평강의 복을 주심')],
    # ── 절기 ──
    'CF_1': [('25:3:22-23', '아침마다 새로운 긍휼'),
             ('19:90:12', '날 계수함을 가르쳐 지혜로운 마음을'),
             ('4:6:24-26', '새해의 축복과 평강'),
             ('23:43:19', '새 일을 행하시는 하나님'),
             ('19:65:11', '한 해를 은혜로 관 씌우심'),
             ('66:21:5', '만물을 새롭게 하시는 하나님'),
             ('19:143:8', '아침에 주의 인자하심을 듣고 길을 알게 하소서')],
    'CF_2': [('43:11:25', '부활이요 생명이신 예수님'),
             ('40:28:6', '그가 살아나셨느니라'),
             ('46:15:20', '잠자는 자들의 첫 열매가 되신 그리스도'),
             ('60:1:3', '부활로 말미암은 산 소망'),
             ('46:15:57', '사망을 이기게 하시는 하나님께 감사'),
             ('45:6:4', '새 생명 가운데서 행함'),
             ('66:1:18', '죽었었으나 세세토록 살아 계신 주')],
    'CF_3': [('19:100:4-5', '감사함으로 그 문에 들어감'),
             ('19:107:1', '선하시고 인자하심이 영원하심'),
             ('52:5:18', '범사에 감사하라'),
             ('19:65:11', '한 해를 은혜로 관 씌우심'),
             ('19:103:2', '그 모든 은택을 잊지 말지어다'),
             ('5:8:10', '배불리 먹고 아름다운 땅을 주심을 찬송함'),
             ('19:145:15-16', '때를 따라 먹을 것을 주시는 하나님')],
    'CF_4': [('42:2:10-11', '온 백성에게 미칠 큰 기쁨의 좋은 소식'),
             ('42:2:14', '하늘에는 영광, 땅에는 평화'),
             ('43:1:14', '말씀이 육신이 되어 우리 가운데 거하심'),
             ('23:9:6', '한 아기가 우리에게 나셨다'),
             ('40:1:23', '임마누엘 — 하나님이 우리와 함께 계심'),
             ('43:3:16', '독생자를 주신 하나님의 사랑'),
             ('48:4:4-5', '때가 차매 아들을 보내심'),
             ('56:2:11', '모든 사람에게 나타난 구원의 은혜')],
}

REF_RE = re.compile(r'^(\d+):(\d+):(\d+)(?:-(\d+))?$')


def init(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS sys_card_verse (cv_id INTEGER PRIMARY KEY AUTOINCREMENT,"
                 " sub_key TEXT NOT NULL, sort_order INTEGER DEFAULT 0, ref TEXT NOT NULL,"
                 " record_status TEXT DEFAULT 'LIVE')")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_card_verse_sub ON sys_card_verse(sub_key, sort_order)")
    conn.execute("CREATE TABLE IF NOT EXISTS sys_card_verse_text (cv_id INTEGER NOT NULL, lang_code TEXT NOT NULL,"
                 " note TEXT, PRIMARY KEY(cv_id, lang_code))")


def parse(ref):
    """「책:장:절[-끝]」 → (책, 장, 절, 끝절) · 꼴이 틀리면 None"""
    m = REF_RE.match((ref or '').strip())
    if not m:
        return None
    v = int(m.group(3))
    return int(m.group(1)), int(m.group(2)), v, int(m.group(4) or v)


def seed(conn, force=False):
    """세부마다 처음 판을 심는다 — **그 세부에 줄이 이미 있으면 안 덮는다**(관리자가 고친 것) · force 면 갈아 끼움."""
    init(conn)
    n = 0
    for sub, rows in SEED.items():
        have = conn.execute("SELECT COUNT(*) FROM sys_card_verse WHERE sub_key=?", (sub,)).fetchone()[0]
        if have and not force:
            continue
        if have:
            conn.execute("DELETE FROM sys_card_verse_text WHERE cv_id IN (SELECT cv_id FROM sys_card_verse WHERE sub_key=?)",
                         (sub,))
            conn.execute("DELETE FROM sys_card_verse WHERE sub_key=?", (sub,))
        for i, (ref, note) in enumerate(rows):
            cur = conn.execute("INSERT INTO sys_card_verse(sub_key, sort_order, ref) VALUES(?,?,?)", (sub, (i + 1) * 10, ref))
            conn.execute("INSERT INTO sys_card_verse_text(cv_id, lang_code, note) VALUES(?, 'KO', ?)", (cur.lastrowid, note))
            n += 1
    conn.commit()
    return n


def rows(conn, sub, lang='KO'):
    """그 세부의 구절 → [(cv_id, ref, note)] · 설명은 그 언어 → KO → EN"""
    init(conn)
    out = []
    for cv, ref in conn.execute("SELECT cv_id, ref FROM sys_card_verse WHERE sub_key=? AND COALESCE(record_status,'LIVE')='LIVE'"
                                " ORDER BY sort_order, cv_id", (sub,)):
        note = ''
        for lg in (lang.upper(), 'KO', 'EN'):
            r = conn.execute("SELECT note FROM sys_card_verse_text WHERE cv_id=? AND lang_code=?", (cv, lg)).fetchone()
            if r and (r[0] or '').strip():
                note = r[0].strip()
                break
        out.append((cv, ref, note))
    return out


def add(conn, sub, ref, note='', lang='KO'):
    if not parse(ref):
        raise ValueError('구절 좌표 꼴이 틀렸습니다: %s' % ref)
    init(conn)
    mx = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM sys_card_verse WHERE sub_key=?", (sub,)).fetchone()[0]
    cur = conn.execute("INSERT INTO sys_card_verse(sub_key, sort_order, ref) VALUES(?,?,?)", (sub, mx + 10, ref))
    if note.strip():
        conn.execute("INSERT INTO sys_card_verse_text(cv_id, lang_code, note) VALUES(?,?,?)", (cur.lastrowid, lang, note.strip()))
    conn.commit()
    return cur.lastrowid


def set_note(conn, cv_id, note, lang='KO'):
    v = (note or '').strip()
    conn.execute("DELETE FROM sys_card_verse_text WHERE cv_id=? AND lang_code=?", (cv_id, lang))
    if v:
        conn.execute("INSERT INTO sys_card_verse_text(cv_id, lang_code, note) VALUES(?,?,?)", (cv_id, lang, v))
    conn.commit()


def set_ref(conn, cv_id, ref):
    if not parse(ref):
        raise ValueError('구절 좌표 꼴이 틀렸습니다: %s' % ref)
    conn.execute("UPDATE sys_card_verse SET ref=? WHERE cv_id=?", (ref, cv_id))
    conn.commit()


def remove(conn, cv_id):
    """지우지 않고 HIDE(되돌릴 수 있다)"""
    conn.execute("UPDATE sys_card_verse SET record_status='HIDE' WHERE cv_id=?", (cv_id,))
    conn.commit()


def move(conn, cv_id, step):
    """한 칸 위(-1)·아래(+1) — 차례를 10 간격으로 다시 매긴다"""
    r = conn.execute("SELECT sub_key FROM sys_card_verse WHERE cv_id=?", (cv_id,)).fetchone()
    if not r:
        return
    ids = [x[0] for x in conn.execute("SELECT cv_id FROM sys_card_verse WHERE sub_key=? AND COALESCE(record_status,'LIVE')='LIVE'"
                                      " ORDER BY sort_order, cv_id", (r[0],))]
    i = ids.index(cv_id)
    j = i + step
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
    for k, x in enumerate(ids):
        conn.execute("UPDATE sys_card_verse SET sort_order=? WHERE cv_id=?", ((k + 1) * 10, x))
    conn.commit()


def label(conn, ref, lang='KO'):
    """좌표 → 「시 139:14」(그 언어 약명)"""
    p = parse(ref)
    if not p:
        return ref
    b, c, v, w = p
    r = conn.execute("SELECT short_name FROM book_names WHERE book_code=? AND UPPER(lang_code)=?", (b, lang.upper())).fetchone()
    nm = (r[0] if r else '') or str(b)
    return '%s %d:%d%s' % (nm, c, v, ('-%d' % w) if w != v else '')


def body(conn, ref, version='KRV'):
    """좌표 → 본문(그 역본 · 없으면 BSB)"""
    p = parse(ref)
    if not p:
        return ''
    b, c, v, w = p
    parts = []
    for vv in range(v, w + 1):
        r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?", (b, c, vv)).fetchone()
        if not r:
            continue
        t = None
        for ver in (version, 'BSB'):
            x = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?", (r[0], ver)).fetchone()
            if x and (x[0] or '').strip():
                t = x[0].strip()
                break
        if t:
            parts.append(t)
    return ' '.join(parts)


def selftest():
    import sqlite3
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)

    for sub, rs in SEED.items():
        ck(all(parse(r) for r, _ in rs), '좌표 꼴 %s' % sub)
        ck(all(n.strip() for _, n in rs), '설명 %s' % sub)
        ck(all(parse(r)[3] - parse(r)[2] <= 2 for r, _ in rs), '세 절 이하(카드 길이) %s' % sub)
    c = sqlite3.connect(':memory:')
    n = seed(c)
    ck(n == sum(len(v) for v in SEED.values()), '심기 %d' % n)
    ck(seed(c) == 0, '두 번째는 안 덮는다')
    cv = rows(c, 'CC_1')[0][0]
    set_note(c, cv, '고친 설명')
    ck(seed(c) == 0 and rows(c, 'CC_1')[0][2] == '고친 설명', '관리자가 고친 것은 그대로')
    x = add(c, 'CC_1', '19:1:1', '복 있는 사람')
    ck(rows(c, 'CC_1')[-1][0] == x, '더한 것은 맨 뒤')
    move(c, x, -1)
    ck(rows(c, 'CC_1')[-2][0] == x, '한 칸 위로')
    remove(c, x)
    ck(all(r[0] != x for r in rows(c, 'CC_1')), '지운 것은 안 보인다(HIDE)')
    try:
        add(c, 'CC_1', '시 1:1')
        ck(False, '틀린 꼴 거부')
    except ValueError:
        ck(True, '틀린 꼴 거부')
    print('db_card_verse %d/%d' % (sum(ok), len(ok)))
    return all(ok)


def main(argv):
    if not argv or argv[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if argv[0] == '--seed':
        print('심음', seed(conn, force='--force' in argv))
    elif argv[0] == '--list':
        init(conn)
        for sub in SEED:
            for cv, ref, note in rows(conn, sub):
                print(sub, label(conn, ref), '·', note, '·', body(conn, ref)[:40])


if __name__ == '__main__':
    main(sys.argv[1:])
