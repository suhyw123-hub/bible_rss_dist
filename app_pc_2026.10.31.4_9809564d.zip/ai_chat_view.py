"""ai_chat_view — 사용자의 AI 도우미 화면 (P4 「AI 도우미」 탭).

★★★ 317차 3단계 재배치(docs/1.txt 2 · 사용자 확정)
  1열  [Free] [선택하기] 닻 ✕ · AI ▾ [설정] … ⚠ 외부 전송 · [사용방법]
  2열  좌 28% = 프롬프트 창고 — 업무 · 함께 다룰 것(Pick) · 묻는 사람(상태·신앙 배경·관점) ·
             내용과 형식(자유·문체·반드시·성경 인용·분량·예시·하지 말 것·답의 모양) / 아래 = 고치는 칸
       중 50% = 요구사항(늘 위) + [전송] · [채팅]/[프롬프트] 갈래
       우 22% = [새 채팅] · [이 채팅을 한 글로] · [저장 ▾] · [이 채팅 삭제] · 채팅목록(구분 단추)
★★★ 보이는 것 = 보내는 것 — [프롬프트] 갈래가 `UA.compose_parts` 의 칸을 그대로 그리고,
  전송은 같은 칸을 머리말과 함께 잇는다(`compose_text`). 빈 칸은 화면에 「(없음)」 · 글에서는 뺀다.
★ Free — 닻 없는 채팅. 이번 실행에서 P1·캔버스를 아직 안 눌렀으면 Free 로 시작한다(`user_main`).
★ 고친 글은 **다른 곳을 누를 때** 저장한다(docs/1.txt 3-3 · 0.7초 타이머를 걷었다).
⚠ 저장은 전부 개인 DB(`user_ai`) — 이 화면은 sys 표에 쓰는 SQL 이 한 줄도 없다.
"""
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk

import appdb
import i18n
import user_ai as UA
import ai_chat_sync as ACS

try:
    import ui_theme
    import theme_font
except Exception:                                         # noqa: BLE001
    ui_theme = theme_font = None

BTN_COLS = 6          # 프롬프트 갈래 단추 한 줄에 몇 개


def _C(role, fallback):
    try:
        v = ui_theme.C(role) if ui_theme else ''
        return v or fallback
    except Exception:                                     # noqa: BLE001
        return fallback


def _kw(on):
    """갈래 단추 — 켜진 것은 **진한 바탕**(P2 갈래 단추와 같은 문법).

    ⚠⚠ **글꼴을 주지 않는다**(306차 사용자 「크기 하드코딩된 것을 제거하라」) —
      `_refont` 가 한 구역 글꼴로 입힌다.
    ⚠ **굵기도 안 쓴다** — 진한 바탕 + 흰 글자가 이미 강하게 가르고, 굵기를 바꾸면
      글자 폭이 달라져 그 줄이 눌린 것처럼 흔들린다.
    """
    # ⚠ `pady=0` — 사용자 「버튼의 높이가 너무 커서 공간을 차지한다」(308차).
    #   실측 한 줄 24 → 20px(프롬프트가 열 개 넘게 쌓이는 칸이라 값이 크다).
    return dict(relief='flat', bd=1, padx=5, pady=0,
                bg=(_C('select_bg', '#5D6D7E') if on else _C('panel', '#FFFFFF')),
                fg=(_C('fg_on_dark', '#FFFFFF') if on else _C('fg', '#1B2631')),
                activebackground=_C('select_bg', '#5D6D7E'), cursor='hand2')


def _btn(parent, text, cmd, **kw):
    # ⚠ **글꼴을 안 넘긴다**(306차) — `_refont` 가 한 구역으로 입힌다.
    try:
        opts = ui_theme.flat_btn() if ui_theme else {}
    except Exception:                                     # noqa: BLE001
        opts = {}
    opts.pop('font', None)
    opts.update(kw)
    return tk.Button(parent, text=' %s ' % text, command=cmd, **opts)


def T(key, ko):
    return i18n.t(key, ko)


#: 성격 라벨 — **영어 한 낱말**(2026-09-30 사용자 「라벨 제목은 네가 적절히 짧게
#: 정하라. **영어 한 단어도 좋다**」).
#: ★★★ 11언어에서 값이 같아 **언어를 바꿔도 배치가 안 흔들린다** — 실측 옛 라벨은
#:   KO 60px · RU 145px 로 갈려 러시아어에서 칸이 창을 넘었다. 지금은 40px 고정.
#: ⚠ 뜻은 **툴팁**(`AI_G_*` 11언어)과 [사용방법]이 말한다(§0-1 — 화면이 말해야 한다).
#: ★ 308차 — `Ask` 가 **주관식**(자유 질문) · `Pick` 이 **객관식**(골라 묻는다).
#:   ⚠ 사용자가 개념을 바로잡았다 — 「확인형이 아니라 주관식 질문형」.
GENRE_TAG = {'QUEST': 'Ask', 'CHAT': 'Pick', 'ANAL': 'Study',
             'MERGE': 'Merge', 'TEACH': 'Tutor'}
#: 라벨 칸 — 글자 수가 아니라 **가장 넓은 라벨**이 정한다(`Check`·`Study`·`Tutor`)
GENRE_TAG_W = 6
#: 한 줄에 놓는 항목 수의 **상한** — 실제 열 수는 **칸 폭에서 정한다**
#: (`_item_cols`). 사용자가 세 칸을 리사이즈하므로 고정 값은 맞지 않다.
ITEM_COLS = 4
#: [선택하기] 팝업 후보 상한 — ⚠ **잘렸으면 화면이 말한다**(§0-1).
#:   실측 연구자료 191 + 내 것 17 = 208 이라 다 든다. 용어는 11,000개가 넘으므로
#:   여기서 끊기고 그때 「더 있습니다」를 적는다.
PICK_CAP = 300
#: 이 화면의 글꼴 단계 — 설정 크기에 이 값을 더한다(음수면 작다).
#: ⚠⚠ **449px 예산에 맞춰 실측으로 정했다**(P4 몸통이 449px 뿐이다):
#:   | delta | 크기 | 2열 | 대화 글 |
#:   |---|---|---|---|
#:   | 0 | 12pt | 222 | **35px** ✗ 무너진다 |
#:   | −1 | 11pt | 211 | 54 ✗ |
#:   | **−2** | **10pt** | **182** | **105px** ✅ 고른 값 |
#:   | −3 | 9pt | 160 | 143 |
#: ★ **−2 를 골랐다** — 예산을 지키면서 글자가 가장 크다(사용자가 「글자가 작아진다」를
#:   지적했으므로 큰 쪽이 맞다).
FONT_DELTA = 0      # ★ 2026-10-21 (AI도우미.txt 5) 표준 서식 그대로(공간이 넉넉해졌다 · 옛 −2)


def _tip(widget, text):
    """작은 툴팁 — 라벨이 짧아진 만큼 뜻을 여기서 말한다.

    ⚠ 창을 하나 더 만드는 일이라 **떠 있는 것은 하나만** 두고 떠날 때 지운다.
    """
    if not text:
        return widget

    def _show(_e=None):
        _hide()
        try:
            tw = tk.Toplevel(widget)
            tw.wm_overrideredirect(True)
            tk.Label(tw, text=text, bg='#FFFFE0', fg='#1B2631', bd=1,
                     relief='solid', padx=4, pady=1).pack()
            tw.wm_geometry('+%d+%d' % (widget.winfo_rootx() + 4,
                                       widget.winfo_rooty() + widget.winfo_height() + 2))
            widget._tipwin = tw
        except Exception:                                 # noqa: BLE001
            pass

    def _hide(_e=None):
        tw = getattr(widget, '_tipwin', None)
        if tw is not None:
            try:
                tw.destroy()
            except Exception:                             # noqa: BLE001
                pass
            widget._tipwin = None

    widget.bind('<Enter>', _show, add='+')
    widget.bind('<Leave>', _hide, add='+')
    widget.bind('<Destroy>', _hide, add='+')
    return widget

#: ★ 317차 — 갈래 넷(Free 가 처음)
SCOPES = ('FREE', 'VERSE', 'TERM', 'REF')
#: 내용과 형식 단추 차례(보낼 차례와 같다 — `UA.SLOTS` 의 그 칸들)
PART_ORDER = ['FREE', 'STYLE', 'MUST', 'CITE', 'LENGTH', 'EXAMPLE', 'BAN', 'FORMAT']
#: 채팅 글에 남기는 「함께 보낸 자료」 줄의 표식 — AI 에게는 안 간다(`send` 가 user/ai 만 싣는다)
ATT_MARK = '[[ATT]]'
#: 채팅목록 구분 단추
CHAT_FILTERS = [('ALL', 'COMMON_ALL', '전체'), ('FREE', 'AIG_FREE_WORLD', 'Free·세상'),
                ('VERSE', 'AIG_WORD', '말씀'), ('TERM', 'AI_SCOPE_TERM', '용어'),
                ('REF', 'AI_SCOPE_REF', '연구자료'), ('BOOK', 'AI_CF_BOOK', '도서')]

class AIChatView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None, on_saved=None, on_open=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_saved = on_saved
        #: 저장 뒤 [열어 보기] — (갈래, 번호) → 그 화면으로(user_main 이 건다)
        self.on_open = on_open
        self._open_to = None
        self._cmp_f = None
        self._scope = 'FREE'           # ★ 317차 — Free 로 시작한다
        self._world = False            # ★ 2026-10-31 FREE 갈래 안의 「세상」 그룹(사회현상·뉴스)
        self._mat_scope = 'TERM'       # 「자료」 그룹이 마지막에 본 갈래(용어 · 연구/설교노트)
        self._start = self._end = None
        self._eid = None
        self._ref = None
        self._link = None        # ★ 2026-10-14 연결 하나를 닻으로 연 대화('LINK:<번호>') — 연결 살펴보기
        self._chat_id = None
        self._prompts = []
        self._task = ''
        self._edit = None
        self._edit_dirty = False
        self._in_job = None
        self._th = None
        self._q = queue.Queue()
        self._draft_auto = ''
        self._pending_user = ''
        self._sent_text = ''
        self._t0 = 0.0
        self._sent_to = ''
        self._acc_rows = []
        self._last_merge = False
        try:
            # ★ 2026-10-15 출력서식 견본(설명식·요약식 …) — 처음 한 번만 심는다
            with self._conn() as c:
                UA.ensure_format_presets(c, self._lang())
        except Exception:                                 # noqa: BLE001
            pass
        self._build()

    # ── DB ──────────────────────────────────────────────────────────
    def _conn(self):
        c = appdb.connect(self.db_path)
        UA.init(c)
        return c

    def _lang(self):
        return (self.lang_getter() or 'KO').upper()

    _AUTOSAVE_MS = 700

    # ══════════════════════════════════════════════════════════════════
    #  짓기 — 317차 3단계 재배치(docs/1.txt 2 · 사용자 확정 배치)
    #    1열   [Free] [선택하기] 닻 ✕ · AI ▾ [설정] … ⚠ 외부 전송 [사용방법]
    #    2열   좌 = 프롬프트 창고(조회·수정) · 중 = 요구사항 + [채팅]/[프롬프트]
    #          우 = 명령 단추 + 채팅목록(구분 단추)
    # ══════════════════════════════════════════════════════════════════
    def _build(self):
        bg = _C('bg', '#E3E6E8')
        self._bg = bg
        bar = tk.Frame(self, bg=bg)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        self._bar = bar
        # ★ Free — 닻 없이 묻는다(이번 실행에서 P1·캔버스를 아직 안 눌렀으면 여기서 시작)
        # ★ 317차-5 — 「Free / 구절 / 용어 / 연구자료」(docs/1.txt 2-1)(1) 그대로).
        #   팝업에서 고르면 그 단추에 포커스가 온다(set_scope 가 칠한다).
        self._sc_btn = {}
        # ★ 2026-10-31 그룹 넷(사용자 확정 · 폰과 같은 이름·차례) — Free · 세상 · 자료 · 말씀.
        #   TERM·REF 는 「자료」를 눌렀을 때만 보이는 작은 갈래 단추다. 내부 갈래 VERSE = 말씀.
        for k, nk, ko in (('FREE', 'AIG_FREE', 'Free'), ('WORLD', 'AIG_WORLD', '세상'), ('MAT', 'AIG_MAT', '자료'),
                          ('TERM', 'AI_SCOPE_TERM', '용어'), ('REF', 'AI_SCOPE_REF', '연구/설교노트'), ('VERSE', 'AIG_WORD', '말씀')):
            b = tk.Button(bar, text=' %s ' % T(nk, ko), command=lambda k=k: self._scope_click(k),
                          **_kw(k == 'FREE'))
            if k not in ('TERM', 'REF'):
                b.pack(side='left', padx=(0, 2))
            self._sc_btn[k] = b
        self._free_btn = self._sc_btn['FREE']
        # ★ 2026-10-15 77 — 폰 기도 노트의 AI 프롬프트(사용자 「AI 도우미 최상단 · 연구설교노트 오른쪽에 여백을 두고」)
        self._pr_btn = _btn(bar, T('AI_PR_PROMPTS', '기도 프롬프트'), self._open_prayer_prompts)
        # ★ 2026-10-21 (AI도우미.txt 1-1) 기도 프롬프트 단추는 **라이브러리 안**으로 옮겼다(만들되 안 놓는다)
        # ★ 317차-13 — [선택하기] 걷음(docs/1.txt 2-1)(1) · 갈래 단추가 그 일을 한다 — 고른 것이 없으면 팝업이 열리고,
        #   **이미 고른 갈래 단추를 다시 누르면** 팝업이 열려 다른 것으로 바꾼다(`_scope_click`). 만들되 안 놓는다.
        self._pick_btn = _btn(bar, T('AI_PICK_ANCHOR', '선택하기'), self._open_pick)
        # ★ 317차-13 — 고른 구절·용어·연구자료 표시 라벨 = **연녹색 바탕**(2-1)(2) · 테마 역할 `success_bg`
        self._anchor_lbl = tk.Label(bar, text='', bg=bg, fg=_C('fg_title', '#2C3E50'), padx=6)
        self._anchor_lbl.pack(side='left', padx=(8, 4))
        # ★ 2026-10-21 (AI도우미.txt 1-1 · 시안 ①) — 고르는 팝업을 걷고 **같은 줄에서** 고른다:
        #   구절 = 책·장·절·끝 콤보 · 용어 / 연구·설교노트 = 검색칸(치면 목록) · 고르는 즉시 닻이 된다
        self._inl = tk.Frame(bar, bg=bg)
        self._inl.pack(side='left', padx=(0, 4))
        self._build_inline(self._inl, bg)
        self._x_btn = tk.Button(bar, text='✕', bd=0, bg=bg, cursor='hand2',
                                command=self._to_verse)
        self._ai_row = bar
        self._ai_btn = tk.Button(bar, text='AI', command=self._open_ai_menu, **_kw(False))
        self._ai_vars = []
        self._ai_menu = None
        self._set_btn = _btn(bar, T('AI_SETTINGS', '설정'), self._open_settings)
        self._help_btn = _btn(bar, T('AI_HELP', '사용방법'), self._open_help)
        self._help_btn.pack(side='right', padx=2)
        # ★ 317차-13 — AI 단추 둘을 **오른쪽으로**(2-1)(4) · [AI][설정] … [사용방법]
        self._set_btn.pack(side='right', padx=(0, 12))
        self._ai_btn.pack(side='right', padx=(0, 4))
        # ★ 2026-10-21 [프롬프트 라이브러리]는 맨 윗줄(왼쪽 칸 단추 줄을 걷었다)
        self._lib_btn_top = _btn(bar, T('AI_LIB_BTN', '프롬프트 라이브러리'), self.open_library)
        self._lib_btn_top.pack(side='right', padx=(0, 6))
        # ★ 317차-21 (docs/1.txt 50-2) — 「⚠ 외부 전송」 라벨과 노란 풍선을 걷었다(사용방법에 있다).
        #   **키 없음은 기능 표시**라 맨 윗줄에 남긴다(사용자 「단순한 라벨이 아니다 · 맨 윗줄에」) —
        #   키가 없을 때만 보이고 누르면 [설정] 창이 열린다.
        self._notice = tk.Label(bar, text='', anchor='e', bg=_C('warning_bg', '#FDEBD0'),
                                fg=_C('warning', '#B9770E'), padx=6, cursor='hand2')
        self._notice.bind('<Button-1>', lambda _e: self._open_settings())

        pw = tk.PanedWindow(self, orient='horizontal', bg=bg, sashwidth=4,
                            sashrelief='flat', bd=0)
        pw.pack(fill='both', expand=True, padx=6, pady=(2, 6))
        self._pw = pw
        self._build_left(pw, bg)
        self._build_center(pw, bg)
        self._build_right(pw, bg)

        self._set_win = None
        self._title_win = None
        self._notes_win = None
        self._title_var = None
        self._pick_win = None
        self._pick_rows = []
        self._fit_job = None
        self._pr_left.bind('<Configure>', self._fit_later, add='+')
        self._load_settings()
        self._load_prompts()
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        self._refont()

    # ── 좌 : 프롬프트 창고 ─────────────────────────────────────────────
    def _build_left(self, pw, bg):
        """프롬프트 창고(docs/1.txt 2-6)(2) 배치 그대로).

        1열 [새 채팅] (공백) [채팅 보내기] · 2열 [조회][수정] · 3열 업무 유형별 프롬프트 + 공통 프롬프트.
        ★ 조회·수정 어느 쪽이든 이 칸은 **100% 같다** — 가운데 화면만 갈린다(결합 / 개별 수정).
        """
        lcol = tk.Frame(pw, bg=bg)
        pw.add(lcol, minsize=230, stretch='always')
        self._pr = lcol
        r1 = tk.Frame(lcol, bg=bg)
        r1.pack(fill='x', pady=(0, 2))
        # ★ 317차-13 — 한 줄 [새 채팅][프롬프트 조회][프롬프트 수정][채팅 보내기](docs/1.txt 2-2)(1))
        #   ⚠ 칸이 좁으면 단추가 잘리지 않게 줄을 감는다(`_wrap_r1`).
        self._r1 = r1
        self._newchat_btn = _btn(r1, T('AI_NEWCHAT2', '새 채팅'), self._new_chat)
        self._mode = 'VIEW'                     # ★ 초기값 = 조회
        self._mode_btn = {}
        for k, nk, ko in (('VIEW', 'AI_MODE_VIEW', '프롬프트 조회'), ('EDIT', 'AI_MODE_EDIT', '프롬프트 수정')):
            b = tk.Button(r1, text=' %s ' % T(nk, ko), command=lambda k=k: self._set_mode(k),
                          **_kw(k == 'VIEW'))
            self._mode_btn[k] = b
        self._sendchat_btn = _btn(r1, T('AI_SENDCHAT', '채팅 보내기'), self._send_click)
        # ★ 2026-10-20 프롬프트 라이브러리(docs/1.txt B2) — Pick 한 벌을 자리들이 같이 쓴다(ai_lib_view)
        self._lib_btn = _btn(r1, T('AI_LIB_BTN', '프롬프트 라이브러리'), self.open_library)
        # ★ 2026-10-20 (docs/1.txt 8-1) 프롬프트를 글로 복사 — API 가 없는 AI 브라우저에 붙여 넣는다
        self._copyp_btn = _btn(r1, T('AI_COPY_PROMPT', '프롬프트 복사'), self.copy_prompt)
        # ★ 2026-10-21 사용자 「채팅 보내기 제거」 — 오른쪽 [전송]과 같은 일이었다(둘 다 _send_click) · 단추는 놓지 않는다
        self._r1_btns = [self._newchat_btn, self._mode_btn['VIEW'], self._mode_btn['EDIT'], self._lib_btn,
                         self._copyp_btn]
        self._r1_cols = 0
        r1.bind('<Configure>', self._wrap_r1, add='+')
        self._wrap_r1()
        # ★ 2026-10-21 (시안) 왼쪽 칸 = **질문 전용** — 새 채팅·조회·수정·라이브러리·복사 줄은 걷었다
        #   (새 채팅·보낼 글 보기·복사는 가운데 작은 줄 · 라이브러리는 맨 윗줄 · 수정은 고른 질문의 ✎)
        r1.pack_forget()
        self._lib_btn = self._lib_btn_top
        # ★ 2026-10-31 말씀 그룹 재료 — 구절(위 줄) 또는 내용(여기) · 하나나 둘 · 앱을 다시 켜도 남는다
        self._word_f = tk.Frame(lcol, bg=bg)
        _wh = tk.Frame(self._word_f, bg=bg)
        _wh.pack(fill='x')
        tk.Label(_wh, text=T('M_AIW_TEXT2', '내용을 자유롭게 적어 주세요(구절은 위에서 선택)'), bg=bg, fg=_C('fg_label', '#566573')).pack(side='left')
        self._word_x = tk.Button(_wh, text='✕', bd=0, bg=bg, cursor='hand2', command=self._word_clear)
        self._word_x.pack(side='right')
        self._word_txt = tk.Text(self._word_f, height=3, width=1, wrap='word')
        self._word_txt.pack(fill='x')
        self._word_txt.bind('<FocusOut>', lambda _e: self._word_save(), add='+')
        try:
            with self._conn() as c:
                self._word_txt.insert('1.0', UA.get_setting(c, 'AI_WORD_TEXT', '') or '')
        except Exception:                                 # noqa: BLE001
            pass
        _cw = tk.Frame(lcol, bg=bg)
        _cw.pack(fill='both', expand=True)
        self._pcv_host = _cw
        self._pcv = tk.Canvas(_cw, bg=bg, highlightthickness=0, bd=0, width=180)
        _pvs = ttk.Scrollbar(_cw, orient='vertical', command=self._pcv.yview)
        self._pcv.configure(yscrollcommand=_pvs.set)
        _pvs.pack(side='right', fill='y')
        self._pcv.pack(side='left', fill='both', expand=True)
        pmid = tk.Frame(self._pcv, bg=bg)
        self._pcv_win = self._pcv.create_window(0, 0, window=pmid, anchor='nw')
        self._pcv.bind('<Configure>', self._pcv_fit, add='+')
        pmid.bind('<Configure>', self._pcv_fit, add='+')
        self._pr_left = pmid
        for _w in (self._pcv, pmid):
            _w.bind('<Enter>', self._wheel_on, add='+')
            _w.bind('<Leave>', self._wheel_off, add='+')

        def head(txt, parent=None):
            f = tk.Frame(parent or pmid, bg=bg)
            lb = tk.Label(f, text=txt, bg=bg, anchor='w', fg=_C('accent', '#1A5276'))
            lb.pack(side='left', padx=2)
            self._heads.append(lb)
            return f
        self._heads = []
        # ★ 2026-10-21 (시안 ②③) 질문프롬프트 하나를 고르면 나머지는 숨기고 맨 위에 이 단추 하나
        self._tasks_open = True
        self._more_btn = tk.Button(pmid, text='', anchor='w', justify='left', relief='flat', bd=1, cursor='hand2',
                                   bg=_C('panel_alt', '#F4F6F8'), fg=_C('accent', '#1A5276'),
                                   command=self._toggle_tasks)
        self._curq = tk.Label(pmid, text='', bg=_C('panel_alt', '#F4F6F8'), fg=_C('fg_dim', '#4A5A6A'),
                              anchor='w', justify='left', padx=6, pady=4, cursor='hand2')
        self._curq.bind('<Button-1>', lambda _e: self._toggle_tasks())
        # ① 업무 유형별 프롬프트 — 갈래마다 다르다 · Free 면 줄째 걷는다(예제 없음)
        self._task_f = tk.Frame(pmid, bg=bg)
        _th = head(T('AI_SEC2_TASK', '질문프롬프트'))
        self._task_head = _th                    # 놓는 일은 `_relayout_left`(늘 맨 위)
        # ★ 2026-10-21 고른 질문프롬프트 고치기(옛 [프롬프트 수정]의 자리)
        self._task_edit_btn = tk.Button(_th, text=T('AI_TASK_EDIT', '✎ 고치기'), relief='flat', bd=0, cursor='hand2',
                                        bg=bg, fg=_C('fg_dim', '#5D6D7E'), command=self._edit_task_now)
        self._task_box = tk.Frame(self._task_f, bg=bg)
        self._task_box.pack(fill='x')
        self._task_btns = {}
        # 연구하자 — 셋 가운데 하나 · 질문과 이해 확인은 입력창이 붙는다
        self._rm_f = tk.Frame(self._task_box, bg=bg)
        self._rm_var = tk.StringVar(value=UA.RESEARCH_MODES[0])
        self._rm_btns = {}
        self._rq_ent = {}
        for m in UA.RESEARCH_MODES:
            b = tk.Radiobutton(self._rm_f, text='', value=m, variable=self._rm_var, bg=bg, anchor='w',
                               justify='left', command=self._pick_rmode)
            b.pack(fill='x', padx=(10, 2))
            self._rm_btns[m] = b
            if m in ('ASK', 'CHECK'):
                e = ttk.Entry(self._rm_f)
                e.pack(fill='x', padx=(28, 4), pady=(0, 2))
                e.bind('<KeyRelease>', self._rq_touched, add='+')
                e.bind('<FocusOut>', lambda _e: self._save_unit(), add='+')
                self._rq_ent[m] = e
        self._notes_var = tk.BooleanVar(value=False)
        self._notes_f = tk.Frame(self._task_box, bg=bg)
        # ★ 317차-15 — 범위 = **라디오 [절][단락][장]** + 오른쪽 숫자 배지(그 범위의 내 묵상노트 편수)
        #   (사용자 「콤보상자 보다는 라디오버튼 · 클릭하면 오른쪽에 숫자 배지 · 팝업 대신」 · 「책」은 뺐다)
        self._ns_var = tk.StringVar(value=UA.NOTE_SCOPES[0])
        self._ns_badge = {}
        for k, nk, ko in (('RANGE', 'AI_NS_VERSE', '절'), ('PERI', 'AI_NS_PERI', '단락'),
                          ('CHAPTER', 'AI_NS_CHAPTER', '장')):
            rb = tk.Radiobutton(self._notes_f, text=T(nk, ko), value=k, variable=self._ns_var, bg=bg,
                                command=self._after_prompt)
            rb.pack(side='left', padx=(10 if k == 'RANGE' else 2, 0))
            bd = tk.Label(self._notes_f, text='', bg=_C('accent_bg', '#AED6F1'), fg=_C('accent', '#1A5276'),
                          padx=4)
            bd.pack(side='left', padx=(0, 4))
            self._ns_badge[k] = bd
        self._nscope = None
        # ② Pick — 맨 위에 안내 · [+ 추가] 는 이름 바로 옆
        self._pick_f = tk.Frame(pmid, bg=bg)
        ph = head('Pick', self._pick_f)
        ph.pack(fill='x')
        self._new_btn = _btn(ph, T('AI_ADD2', '+ 추가'), self._new_pick_lib)
        self._new_btn.pack(side='left', padx=(6, 0))
        self._pick_box = tk.Frame(self._pick_f, bg=bg)
        self._pick_box.pack(fill='x')
        self._pbtns = []
        self._pvars = {}
        self._witems = {}
        self._checked = []                       # ★ 고른 차례 = 보낼 차례
        # ③ 공통 프롬프트 — 묻는 사람 · 내용과 형식
        # ★ 317차-14 — 「공통 프롬프트」 머리를 걷고 「묻는 사람」 → 「사용자」(사용자 지시)
        self._common_f = tk.Frame(pmid, bg=bg)
        self._ask_f = tk.Frame(self._common_f, bg=bg)
        head(T('AI_SEC_USER', '사용자'), self._ask_f).pack(fill='x')
        self._axcb = {}
        self._axrows = {}
        self._axlab = {}
        for ax, nk, ko in (('STATE', 'AI_AX_STATE', '상태'), ('FAITH', 'AI_AX_FAITH', '신앙 배경'),
                           ('VIEW', 'AI_AX_VIEW2', '관점')):
            r = tk.Frame(self._ask_f, bg=bg)
            r.pack(fill='x', pady=0)
            # ★ 317차-14 — 이름을 누르면 [수정]으로 그 목록을 가운데에서 관리한다(나뭇잎 ✎ 걷음)
            lb = tk.Label(r, text=T(nk, ko), bg=bg, anchor='w', width=9, cursor='hand2')
            lb.pack(side='left', padx=(6, 2))
            pass                         # ★ 2026-10-21 이름을 눌러 고치기 걷음(라이브러리에서만)
            cb = ttk.Combobox(r, state='readonly', width=14, values=[])
            cb.pack(side='left', fill='x', expand=True, padx=(0, 2))
            cb.bind('<<ComboboxSelected>>', lambda _e, a=ax: self._pick_axis_cb(a))
            self._axcb[ax] = cb
            self._axlab[ax] = lb
        # ★ 2026-10-28 docs/1.txt 4-2 — 상태가 평신도·초신자·선택 안 함이면 「분야」(사업가·직장인 …) — 일반 설명문 분야의 처음 값
        self._field_row = tk.Frame(self._ask_f, bg=bg)
        tk.Label(self._field_row, text=T('AI_AX_FIELD', '분야'), bg=bg, anchor='w', width=9).pack(side='left', padx=(6, 2))
        self._field_cb = ttk.Combobox(self._field_row, state='readonly', width=14, values=[])
        self._field_cb.pack(side='left', fill='x', expand=True, padx=(0, 2))
        self._field_cb.bind('<<ComboboxSelected>>', lambda _e: self._pick_field())
        self._field_codes = []
        self._parts_f = tk.Frame(self._common_f, bg=bg)
        head(T('AI_SEC_PARTS', '내용과 형식'), self._parts_f).pack(fill='x')
        self._part_box = tk.Frame(self._parts_f, bg=bg)
        self._part_box.pack(fill='x')
        self._part_btns = {}
        for i, p in enumerate(PART_ORDER):
            b = tk.Button(self._part_box, text='', anchor='w', justify='left',
                          command=lambda p=p: self._item_click(('PART', p)), **_kw(False))
            b.grid(row=i // 2, column=i % 2, sticky='ew', padx=2, pady=1)
            self._part_btns[p] = b
        for i in range(2):
            self._part_box.columnconfigure(i, weight=1, uniform='pt')
        for f in (self._ask_f, self._parts_f):
            f.pack(fill='x', pady=(1, 2))
        # ★ 2026-10-21 (시안) 이어서 묻기(2회차부터) — 가운데에서 옮겨 왔다
        self._bm_f = tk.Frame(pmid, bg=bg)
        head(T('AI_FU_HEAD', '이어서 묻기'), self._bm_f).pack(fill='x')
        self._bm_stage = tk.Frame(self._bm_f, bg=bg)
        self._bm_stage.pack(fill='x')
        self._bm_next = tk.Frame(self._bm_f, bg=bg)
        self._bm_next.pack(fill='x')
        self._fu_row = tk.Frame(self._bm_f, bg=bg)
        self._fu_row.pack(fill='x')
        self._fu_menus = {}
        self._fu_key = None
        self._bm_key = None
        self._fu_show = False
        # 이 대화의 질문 이력
        self._hist_f = tk.Frame(pmid, bg=bg)
        head(T('AI_HIST_HEAD', '이 대화의 질문 이력'), self._hist_f).pack(fill='x')
        self._hist_box = tk.Frame(self._hist_f, bg=bg)
        self._hist_box.pack(fill='x')
        # ★ 사용자·출력서식 등은 **제목 한 줄씩** — 누르면 펼친다(라이브러리에서 정하면 거의 안 바꾼다)
        self._common_open = False
        self._sum_f = tk.Frame(pmid, bg=bg)
        self._sum_rows = {}
        for k, nk, ko in (('USER', 'AI_SUM_USER', '사용자'), ('FMT', 'AI_SUM_FMT', '출력서식'),
                          ('ETC', 'AI_SUM_ETC', '금지사항 · 성경인용')):
            r = tk.Frame(self._sum_f, bg=bg, cursor='hand2')
            r.pack(fill='x', pady=0)
            a = tk.Label(r, text=T(nk, ko), bg=bg, fg=_C('fg_dim', '#4A5A6A'), anchor='w', cursor='hand2')
            a.pack(side='left', padx=(4, 2))
            b = tk.Label(r, text='', bg=bg, fg=_C('fg_dim', '#4A5A6A'), anchor='e', cursor='hand2')
            b.pack(side='right', padx=(2, 4))
            for w in (r, a, b):
                w.bind('<Button-1>', lambda _e: self._toggle_common())
            self._sum_rows[k] = b
        self._edit = None
        self._edit_dirty = False

    # ── 중 : 요구사항 + 채팅/프롬프트 ───────────────────────────────────
    def _build_center(self, pw, bg):
        """가운데 = 채팅제목 · 요구사항(왼쪽에 라벨과 [전송]) · 이중 화면.

        이중 화면(docs/1.txt 2-4)) — 채팅 내용 / [조회] 결합 프롬프트 / [수정] 개별 프롬프트.
        """
        rf = tk.Frame(pw, bg=bg)
        pw.add(rf, minsize=280, stretch='always')
        self._center = rf
        # ★ 가운데 맨 위 한 줄 — 왼쪽 필수 지침 안내 · 그 오른쪽 정보 수집 안내(사용자 지시)
        # ★ 317차-21 (docs/1.txt 50-2) — 이 두 줄은 **걷었다**(만들되 안 놓는다) · 사용자 「사용방법 버튼에 이미
        #   추가되어 있다. 제거하라」 — [사용방법]의 「⚠ 밖으로 나가는 글」·「신앙 관점」 절이 같은 말을 한다.
        gr = tk.Frame(rf, bg=bg)
        self._guard_lbl = tk.Label(gr, text=T('AI_GUARD_NOTICE2',
                                              'AI와의 대화는 기독교 복음주의적 입장을 중심으로 진행된다.'),
                                   bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', justify='left')
        self._guard_lbl.pack(side='left', anchor='n', padx=2)
        self._collect_lbl = tk.Label(gr, text=T('AI_COLLECT_NOTICE',
                                     'AI 도우미 기능은 사용자 PC에서 직접 AI와 데이터를 교환하므로 이 앱은 아무런 정보를 수집하지 않습니다.'),
                                     bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', justify='left')
        self._collect_lbl.pack(side='left', anchor='n', fill='x', expand=True, padx=(12, 2))
        gr.bind('<Configure>', lambda e: self._collect_lbl.configure(
            wraplength=max(120, e.width - self._guard_lbl.winfo_reqwidth() - 30)), add='+')
        sf = tk.Frame(rf, bg=bg)
        sf.pack(fill='x')
        self._open_btn = _btn(sf, T('AI_OPEN_SAVED', '열어 보기'), self._open_saved)
        self._status = tk.Label(sf, text='', bg=bg, fg=_C('accent', '#1A5276'), anchor='w', justify='left')
        self._status.pack(side='left', fill='x', expand=True, padx=2, pady=(2, 2))
        self._status.bind('<Configure>', self._fit_status, add='+')
        th = tk.Frame(rf, bg=bg)
        th.pack(fill='x')
        self._th_row = th
        tk.Label(th, text=T('AI_CHAT_TITLE3', '채팅제목'), bg=bg,
                 fg=_C('fg_title', '#2C3E50')).pack(side='left', padx=(2, 4))
        self._title_ent = ttk.Entry(th)
        self._title_ent.pack(side='left', fill='x', expand=True, padx=(0, 2))
        self._title_job = None
        self._title_ent.bind('<FocusOut>', lambda _e: self._save_chat_title(), add='+')
        # ★★★ 317차-8 — **맨 아래 띠** = 이 채팅의 상태 한 줄 + [AI결과 창 열기](사용자 「대화 상태표시 기능
        #   매우 좋다 … 프롬프트 표시기능과 절대로 충돌하면 안된다」). 띠를 먼저 바닥에 붙여
        #   요구사항·프롬프트 칸이 그 위의 남는 높이를 쓴다(겹칠 수 없다).
        sb = tk.Frame(rf, bg=bg)
        self._state_bar = sb             # ★ 2026-10-21 화면에 안 놓는다 — 위 진행 줄 한 줄이 맡는다
        self._res_btn = _btn(sb, T('AI_RES_OPEN', 'AI결과 창 열기'), self.open_results)   # ★ 2026-10-21 가운데 작은 줄로 옮김(안 놓는다)
        self._state_lbl = tk.Label(sb, text='', bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', justify='left')
        self._state_lbl.pack(side='left', fill='x', expand=True, padx=2)
        # ★ 요구사항(4~5줄 · 리사이즈) — 왼쪽에 라벨, 그 바로 아래 [전송]
        # ★ 2026-10-13 docs/1.txt 81·82 — **도서 묵상 띠**(도서 편 닻일 때만 보인다):
        #   ① 단계 단추(핵심·본문·돌아보기·기도·실천·다른 관점·요약 — 업무 Pick 이 정한다 · 누르면 곧바로 보낸다)
        #   ② AI 가 답 끝에 「▷ 」로 적은 다음 질문 2~3개를 단추로 ③ [묵상 기록을 도서노트로]
        # ★ 2026-10-21 (시안) 이어서 묻기는 **왼쪽 칸**으로 옮겼다(`_build_left`) · 가운데는 대화 중심 —
        #   입력칸 위 작은 단추 줄: [새 채팅][보낼 글 보기][복사][저장 ▾][AI결과 창]
        tl = tk.Frame(rf, bg=bg)
        tl.pack(fill='x', pady=(0, 2))
        self._tools_f = tl
        self._newchat_btn = _btn(tl, T('AI_NEWCHAT2', '새 채팅'), self._new_chat)
        self._newchat_btn.pack(side='left', padx=(2, 2))
        self._peek_btn = _btn(tl, T('AI_PEEK', '보낼 글 보기'), self._toggle_peek)
        self._peek_btn.pack(side='left', padx=2)
        # ★ 2026-10-21 (AI도우미.txt 4-3) 「AI입력용 복사」 — 누르는 그때 왼쪽에서 정한 대로 지어 복사한다 ·
        #   답을 받은 뒤로는 흐리게(이어지는 말은 이 대화의 앞 내용이 있어야 뜻이 있다)
        self._copyp_btn2 = _btn(tl, T('AI_COPY_FOR_AI', 'AI입력용 복사'), self.copy_prompt)
        self._copyp_btn2.pack(side='left', padx=2)
        # ★ 2026-10-21 사용자 「대화를 진행하고 마지막 저장까지 이 화면에서 · 복잡한 대화만 팝업에서」 —
        #   오른쪽 끝 [저장 ▾] · 그 왼쪽 [대화통합화면](옛 AI결과 창 · 누를 때만 뜬다)
        self._save_mb = _btn(tl, T('AI_SAVE_MENU', '저장 ▾'), self._open_save_menu)
        self._save_mb.pack(side='right', padx=2)
        self._res_btn2 = _btn(tl, T('AI_RES_OPEN3', '대화통합화면'), self.open_results)
        self._res_btn2.pack(side='right', padx=2)
        # 채팅제목 줄은 이 단추 줄 **아래**(위에서 먼저 지어 졌으므로 여기서 다시 놓는다)
        self._th_row.pack_forget()
        self._th_row.pack(fill='x', after=tl)
        cp = tk.PanedWindow(rf, orient='vertical', bg=bg, sashwidth=4, sashrelief='flat', bd=0)
        cp.pack(fill='both', expand=True)
        self._cpw = cp
        inp = tk.Frame(cp, bg=bg)
        cp.add(inp, minsize=60, height=96, stretch='never')
        self._inp_pane = inp
        lc = tk.Frame(inp, bg=bg)
        lc.pack(side='left', fill='y', padx=(2, 4))
        self._in_lbl = tk.Label(lc, text=T('AI_IN_LBL3', '요구사항'), bg=bg,
                                fg=_C('fg_title', '#2C3E50'), anchor='w')
        self._in_lbl.pack(side='top', anchor='w')
        # ★ 2026-10-21 (AI도우미.txt 4-3) [전송]은 위 작은 줄 [저장 ▾] 왼쪽 · Ctrl+Enter 그대로
        self._send_btn = _btn(self._tools_f, T('AI_SEND2', '전송'), self._send_click)
        self._send_btn.pack(side='left', padx=(10, 2))
        self._teach_btn = None
        self._in = tk.Text(inp, height=5, wrap='word', undo=True, relief='solid', bd=1,
                           highlightthickness=1, highlightbackground=_C('accent', '#1A5276'))
        _isb = ttk.Scrollbar(inp, orient='vertical', command=self._in.yview)
        self._in.configure(yscrollcommand=_isb.set)
        _isb.pack(side='right', fill='y')
        self._in.pack(side='left', fill='both', expand=True)
        self._in.bind('<Control-Return>', lambda _e: (self._send_click(), 'break')[1])
        self._in.bind('<KeyRelease>', self._in_touched, add='+')
        self._in_job = None
        self._vw_btn = {}
        self._view = 'CHAT'
        body = tk.Frame(cp, bg=bg)
        cp.add(body, minsize=120, stretch='always')
        self._body_f = body
        self._out = tk.Text(body, wrap='word', state='disabled', bg=_C('view_bg', '#FFFFFF'), height=5)
        self._out_sb = ttk.Scrollbar(body, orient='vertical', command=self._out.yview)
        self._out.configure(yscrollcommand=self._out_sb.set)
        self._ptxt = tk.Text(body, wrap='word', state='disabled', bg=_C('view_bg', '#FFFFFF'), height=5)
        self._ptxt_sb = ttk.Scrollbar(body, orient='vertical', command=self._ptxt.yview)
        self._ptxt.configure(yscrollcommand=self._ptxt_sb.set)
        # [수정] — 개별 프롬프트를 넉넉히(docs/1.txt 2-6)(6))
        ed = tk.Frame(body, bg=bg)
        self._edf = ed
        self._pr_right = ed
        self._tpl_f = ed
        et = tk.Frame(ed, bg=bg)
        et.pack(fill='x')
        self._ed_lbl = tk.Label(et, text='', bg=bg, anchor='w', fg=_C('accent', '#1A5276'))
        self._ed_lbl.pack(side='left', padx=2)
        self._del_btn = _btn(et, T('AI_DEL_PROMPT_SHORT', '지우기'), self._del_prompt)
        # ★ 2026-10-21 [프롬프트 수정] 단추를 걷어서 — 고치기 화면에서 대화로 돌아가는 문
        _btn(et, T('AI_ED_CLOSE', '대화로 돌아가기'), self._edit_close).pack(side='right', padx=2)
        # ★★★ 317차-14 — **관리 화면**(사용자 「업무 프롬프트·콤보 목록·내용과 형식 프롬프트 자체도
        #   가운데 화면에서 추가/수정/삭제」) — 고른 갈래의 목록 + [+ 추가][삭제][기본으로] · 아래는 고치는 칸
        lf = tk.Frame(ed, bg=bg)
        lf.pack(fill='x', pady=(2, 2))
        self._ed_lf = lf
        lbtn = tk.Frame(lf, bg=bg)
        lbtn.pack(fill='x')
        self._ed_add = _btn(lbtn, T('AI_ADD2', '+ 추가'), self._ed_add_click)
        self._ed_add.pack(side='left', padx=(0, 2))
        self._ed_delb = _btn(lbtn, T('AI_ED_DEL', '삭제'), self._ed_del_click)
        self._ed_delb.pack(side='left', padx=(0, 2))
        self._ed_reset = _btn(lbtn, T('AI_ED_RESET', '기본으로'), self._ed_reset_click)
        self._ed_reset.pack(side='left', padx=(0, 2))
        self._ed_msg = tk.Label(lbtn, text='', bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w')
        self._ed_msg.pack(side='left', fill='x', expand=True, padx=6)
        # ★ 2026-10-20 출력서식 두 갈래 — [하나 선택](답의 꼴) [복수 선택](어떤 꼴과도 함께) 탭(출력서식일 때만 보인다)
        self._fmt_tab = 'ONE'
        self._fmt_tabs_f = tk.Frame(lf, bg=bg)
        self._fmt_tab_btn = {}
        for k, nk, ko in (('ONE', 'AI_FMT_ONE', '하나 선택'), ('MULTI', 'AI_FMT_MULTI', '복수 선택')):
            b = tk.Button(self._fmt_tabs_f, text=' %s ' % T(nk, ko), command=lambda k=k: self._set_fmt_tab(k),
                          **_kw(k == 'ONE'))
            b.pack(side='left', padx=(0, 2))
            self._fmt_tab_btn[k] = b
        lbx = tk.Frame(lf, bg=bg)
        lbx.pack(fill='x')
        self._ed_lbx = lbx
        self._ed_list = tk.Listbox(lbx, height=5, activestyle='none', exportselection=False)
        _lsb = ttk.Scrollbar(lbx, orient='vertical', command=self._ed_list.yview)
        self._ed_list.configure(yscrollcommand=_lsb.set)
        _lsb.pack(side='right', fill='y')
        self._ed_list.pack(side='left', fill='x', expand=True)
        self._ed_list.bind('<<ListboxSelect>>', self._ed_list_pick)
        self._ed_rows = []
        self._ed_sec = None
        self._tpl_title_lbl = tk.Label(ed, text=T('AI_ED_TITLE', '이름'), bg=bg, anchor='w',
                                       fg=_C('fg_title', '#2C3E50'))
        self._tpl_title = ttk.Entry(ed, width=10)
        self._ed_role_lbl = tk.Label(ed, text=T('AI_ED_ROLE', '역할'), bg=bg, anchor='w',
                                     fg=_C('fg_title', '#2C3E50'))
        self._tpl_role = tk.Text(ed, height=4, width=1, wrap='word', undo=True)
        self._ed_task_lbl = tk.Label(ed, text=T('AI_ED_TASK', '할일'), bg=bg, anchor='w',
                                     fg=_C('fg_title', '#2C3E50'))
        self._tpl_txt = tk.Text(ed, height=5, width=1, wrap='word', undo=True)
        self._tpl_hint = tk.Label(ed, text=T('AI_ED_HINT', '수정한 글은 다른 곳을 누르면 저장됩니다'),
                                  bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w')
        self._tpl_hint.pack(side='bottom', fill='x')
        self._tpl_txt.pack(side='bottom', fill='both', expand=True, pady=(1, 1))
        for w in (self._tpl_title, self._tpl_txt, self._tpl_role):
            w.bind('<FocusOut>', lambda _e: self._edit_save(), add='+')
            w.bind('<KeyRelease>', self._ed_touched, add='+')
        _bd = _C('border', '#D5DBDB')
        self._out.tag_configure('me', foreground=_C('fg_title', '#2C3E50'), spacing1=8)
        self._out.tag_configure('qbody', lmargin1=6, lmargin2=6, rmargin=6, spacing1=1, spacing3=2)
        self._out.tag_configure('ai', foreground=_C('fg', '#1B2631'), lmargin1=18, lmargin2=18,
                                spacing1=1, spacing3=10)
        self._out.tag_configure('sys', foreground=_C('fg_dim', '#7F8C8D'), spacing1=4)
        self._out.tag_configure('h', foreground=_C('accent', '#1A5276'), lmargin1=18, lmargin2=18, spacing1=6)
        self._out.tag_configure('rule', foreground=_bd, spacing1=2, spacing3=2)
        # ★ 2026-10-15 — 검증하지 못한 답(원본)이라는 표시
        self._out.tag_configure('vfail', foreground=_C('warning', '#B7770D'), lmargin1=18, lmargin2=18, spacing1=2)
        self._out.tag_configure('next', foreground=_C('accent', '#1A5276'), lmargin1=18, lmargin2=34, spacing1=1)
        self._ptxt.tag_configure('h', foreground=_C('accent', '#1A5276'), spacing1=6)
        self._ptxt.tag_configure('v', lmargin1=10, lmargin2=10)
        self._ptxt.tag_configure('none', foreground=_C('fg_dim', '#7F8C8D'), lmargin1=10, lmargin2=10)
        self._ptxt.tag_configure('att', foreground=_C('fg_dim', '#7F8C8D'), lmargin1=10, lmargin2=10)
        self.set_view('CHAT')

    # ── 우 : 명령 · 채팅목록 ──────────────────────────────────────────
    def _build_right(self, pw, bg):
        """명령 단추 + 채팅목록(docs/1.txt 2-3)).

        ★ 「새 채팅」은 왼쪽 창고 1열로 옮겼다(사용자 지시) — 그 자리는 공백으로 남긴다.
        """
        ccol = tk.Frame(pw, bg=bg)
        pw.add(ccol, minsize=170, stretch='always')
        nr = tk.Frame(ccol, bg=bg)
        nr.pack(fill='x')
        self._nr = nr
        tk.Frame(nr, bg=bg, height=22).pack(fill='x')            # ★ 한 칸의 공백
        self._merge_btn = _btn(nr, T('AI_ONE_TEXT2', '이 대화를 한 글로'), self._one_text)
        self._merge_btn.pack(fill='x', padx=2, pady=(0, 2))
        # ★ 317차-6 — 원본과 AI 답들을 나란히(답이 있을 때만 눌린다)
        self._cmpans_btn = _btn(nr, T('AI_CMP_ANS', 'AI결과 비교'), self.answers_compare)
        self._cmpans_btn.pack(fill='x', padx=2, pady=(0, 2))
        self._save_btn = _btn(nr, T('AI_SAVE_REF2', '연구/설교노트 저장'), lambda: self._save_click('REF'))
        self._save_btn.pack(fill='x', padx=2, pady=(0, 1))
        self._save_menu = None
        mqf = tk.Frame(nr, bg=bg)
        mqf.pack(fill='x')
        self._mq_f = mqf
        self._mq_var = tk.BooleanVar(value=False)
        self._mq_chk = tk.Checkbutton(mqf, text=T('AI_MERGE_Q2', '요구사항도 함께 저장'), variable=self._mq_var,
                                      bg=bg, command=self._save_mq)
        self._mq_chk.pack(side='left', padx=12)
        smf = tk.Frame(nr, bg=bg)
        smf.pack(fill='x')
        self._smode_var = tk.StringVar(value='ALL')
        for k, nk, ko in (('ALL', 'AI_SM2_ALL', '대화목록 전체 저장'), ('LAST', 'AI_SM2_LAST', '최종 통합자료만 저장')):
            tk.Radiobutton(smf, text=T(nk, ko), value=k, variable=self._smode_var, bg=bg, anchor='w',
                           command=self._sync_smode).pack(fill='x', padx=2)
        self._note_btn = _btn(nr, T('AI_SAVE_NOTE2', '묵상노트로 저장'), lambda: self._save_click('NOTE'))
        self._note_btn.pack(fill='x', padx=2, pady=(2, 1))
        self._delchat_btn = _btn(nr, T('AI_DEL_CHAT2', '이 채팅 삭제'), self._del_chat)
        self._delchat_btn.pack(fill='x', padx=2, pady=(4, 2))
        # ★ 2026-10-20 대화 함께 쓰기(폰 ↔ PC · 대화마다 사용자가 정한다) · 대화 정리(휴지통 30일)
        self._share_var = tk.BooleanVar(value=False)
        self._share_chk = tk.Checkbutton(nr, text=T('AI_SHARE_CHAT', '폰과 함께 쓰기'), variable=self._share_var,
                                         bg=bg, anchor='w', command=self._share_click)
        # ★ 2026-10-21 「폰과 함께 쓰기」 걷음 — 모든 대화가 동기화 때 오간다(사용자) · 위젯은 만들되 안 놓는다
        self._clean_btn = _btn(nr, T('AI_CLEAN', '대화 정리'), self._open_clean)
        self._clean_btn.pack(fill='x', padx=2, pady=(2, 2))
        self._clean_win = None
        self._nr_btns = [self._merge_btn, self._cmpans_btn, self._save_btn, self._note_btn, self._delchat_btn,
                         self._clean_btn]
        # ★★★ 317차-8 — 저장·통합·비교는 **AI결과 창 하나로** 모았다(사용자 「오른쪽 대화목록 화면은
        #   삭제 / 필터링 기능 이외에 필요할 것이 없을 것 같다」). 옛 단추는 문(메서드)이 남아 있어
        #   만들되 **화면에 안 놓는다** — 되돌릴 자리.
        for _w in (self._merge_btn, self._cmpans_btn, self._save_btn, mqf, smf, self._note_btn):
            _w.pack_forget()
        self._copy_btn = None
        lh = tk.Frame(ccol, bg=bg)
        lh.pack(fill='x', pady=(4, 0))
        self._list_lbl = tk.Label(lh, text=T('AI_CHATS2', '채팅목록'), bg=bg,
                                  fg=_C('fg_title', '#2C3E50'), anchor='w')
        self._list_lbl.pack(side='left', padx=2)
        cf = tk.Frame(ccol, bg=bg)
        cf.pack(fill='x')
        self._cf_btn = {}
        self._cfilter = 'ALL'
        for i, (k, nk, ko) in enumerate(CHAT_FILTERS):
            b = tk.Button(cf, text=T(nk, ko), command=lambda k=k: self.set_chat_filter(k),
                          **_kw(k == 'ALL'))
            b.grid(row=i // 3, column=i % 3, sticky='ew', padx=1, pady=1)
            self._cf_btn[k] = b
        for i in range(3):
            cf.columnconfigure(i, weight=1, uniform='cf')
        self._all_var = tk.BooleanVar(value=False)        # 옛 이름(전체 대화 체크)
        lf = tk.Frame(ccol, bg=bg)
        lf.pack(fill='both', expand=True)
        self._list = tk.Listbox(lf, exportselection=False, activestyle='none', height=5)
        _lsb = ttk.Scrollbar(lf, orient='vertical', command=self._list.yview)
        self._list.configure(yscrollcommand=_lsb.set)
        _lsb.pack(side='right', fill='y')
        self._list.pack(fill='both', expand=True)
        self._list.bind('<<ListboxSelect>>', lambda _e: self._pick_chat())
        self._list_ids = []

    def _fit_later(self, _e=None):
        try:
            if self._fit_job:
                self.after_cancel(self._fit_job)
        except Exception:                                 # noqa: BLE001
            pass
        self._load_mq()
        self._fit_job = self.after(60, self._fit_wrap)
        if not getattr(self, '_panes_done', False):
            self.after(140, self._init_panes)

    def _fit_wrap(self):
        """창고 단추가 칸 폭 안에서 감기게 — **폭이 24px 넘게 바뀔 때만** 다시 건다(§256차 ⑰)."""
        try:
            room = self._pr_left.winfo_width()
            if room <= 1:
                return
            w = max(80, room - 40)
            if abs(w - getattr(self, '_wrap_used', -999)) <= 24:
                return
            self._wrap_used = w
            for b in self._pbtns:
                b.configure(wraplength=w)
            for b in self._task_btns.values():
                b.configure(wraplength=max(60, room - 20))
            for b in getattr(self, '_rm_btns', {}).values():
                b.configure(wraplength=max(60, room - 40))
            for b in self._part_btns.values():
                b.configure(wraplength=max(60, room // 2 - 20))
            self._pcv_fit()
        except Exception:                                 # noqa: BLE001
            pass

    def _init_panes(self):
        """세 칸 처음 폭 — **좌 28 · 중 50 · 우 22**(사용자 확정 · 처음 한 번만)."""
        if getattr(self, '_panes_done', False):
            return
        try:
            w = self._pw.winfo_width()
            if w < 400:
                self.after(180, self._init_panes)
                return
            self._pw.sash_place(1, int(w * 0.78), 0)
            self._pw.sash_place(0, int(w * 0.28), 0)
            self._panes_done = True
            self._fit_later()
        except Exception:                                 # noqa: BLE001
            self._panes_done = True

    def _pcv_fit(self, _e=None):
        try:
            w = self._pcv.winfo_width()
            if w > 1 and self._pcv.itemcget(self._pcv_win, 'width') != str(w):
                self._pcv.itemconfigure(self._pcv_win, width=w)
            bb = self._pcv.bbox('all')
            if bb and self._pcv.cget('scrollregion') != '%d %d %d %d' % bb:
                self._pcv.configure(scrollregion=bb)
        except Exception:                                 # noqa: BLE001
            pass

    #: 굵게 둘 위젯 — 이름으로 고른다(칸 머리글은 `_heads` 가 따로 담는다)
    _BOLD = ('_anchor_lbl', '_status', '_in_lbl', '_list_lbl', '_ed_lbl')

    # ── 갈래 ─────────────────────────────────────────────────────────
    def set_scope(self, scope, world=False):
        scope = str(scope or '').upper()
        if scope not in SCOPES:
            scope = 'VERSE'
        self._close_lib()
        world = bool(world) and scope == 'FREE'
        if scope != self._scope or world != self._world:
            self._edit_save()
            self._save_unit()
            self._scope = scope
            self._world = world
            self._chat_id = None
            self._checked = []
            self._clear_draft()
            self._tasks_open = True
        self._paint_groups()
        try:
            self._note_btn.configure(state=('normal' if self._scope == 'VERSE' else 'disabled'))
        except Exception:                                 # noqa: BLE001
            pass
        # ★ 317차-13 — 상태 줄의 「연구자료를 먼저 고르세요」를 걷었다(2-5)(3) · 닻 라벨이 이미 그 말을 한다)
        # ★ 채팅목록 구분 단추가 갈래를 따라간다(사용자 확정)
        self.set_chat_filter(self._scope, _load=False)
        self._load_prompts()
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()

    def _scope_click(self, k):
        """1열 갈래 단추 — 선택한 것이 없으면 선택하는 팝업을 연다 · **이미 선택한 갈래를 다시 누르면** 팝업을 열어
        다른 것으로 바꾼다(317차-13 · [선택하기] 를 걷은 자리)."""
        # ★ 2026-10-21 (AI도우미.txt 1-1) 팝업을 걷었다 — 같은 줄의 콤보·검색칸에서 고른다
        if k == 'WORLD':
            self.set_scope('FREE', world=True)
        elif k == 'MAT':
            self.set_scope(self._mat_scope)
        else:
            self.set_scope(k)

    def _paint_groups(self):
        """그룹 단추 칠하기 · 「자료」일 때만 용어/연구설교노트 작은 단추 · 말씀일 때만 내용 칸."""
        sc = self._scope
        if sc in ('TERM', 'REF'):
            self._mat_scope = sc
        on = {'FREE': sc == 'FREE' and not self._world, 'WORLD': sc == 'FREE' and self._world,
              'MAT': sc in ('TERM', 'REF'), 'TERM': sc == 'TERM', 'REF': sc == 'REF', 'VERSE': sc == 'VERSE'}
        for k, b in self._sc_btn.items():
            try:
                b.configure(**_kw(on.get(k, False)))
            except Exception:                             # noqa: BLE001
                pass
        try:
            for k, prev in (('REF', 'MAT'), ('TERM', 'MAT')):     # 차례: 자료 · 용어 · 연구/설교노트
                b = self._sc_btn[k]
                if on['MAT'] and not b.winfo_manager():
                    b.pack(side='left', padx=(0, 2), after=self._sc_btn[prev])
                elif not on['MAT'] and b.winfo_manager():
                    b.pack_forget()
            if sc == 'VERSE' and not self._word_f.winfo_manager():
                self._word_f.pack(fill='x', pady=(0, 4), before=self._pcv_host)
            elif sc != 'VERSE' and self._word_f.winfo_manager():
                self._word_f.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass

    def word_text(self):
        """말씀 그룹 내용 칸의 글."""
        try:
            self._commit_ime(self._word_txt)
            return self._word_txt.get('1.0', 'end').strip()
        except Exception:                                 # noqa: BLE001
            return ''

    def _word_save(self):
        try:
            with self._conn() as c:
                UA.set_setting(c, 'AI_WORD_TEXT', self.word_text())
                c.commit()
        except Exception:                                 # noqa: BLE001
            pass

    def _word_clear(self):
        self._word_txt.delete('1.0', 'end')
        self._word_save()

    def _word_prefix(self, text):
        """첫 말 앞에 내용 칸의 글(말씀 그룹 프롬프트만)."""
        w = self.word_text() if self._scope == 'VERSE' and self._task in UA.WORD_TASKS else ''
        if not w:
            return text
        return '[%s]%s%s%s%s' % (UA.WORD_MAT_NAME, chr(10), w, chr(10) * 2, text)

    def scope(self):
        return self._scope

    def _close_lib(self):
        """★ 2026-10-21 라이브러리가 덮고 있으면 걷는다 — 위 줄 단추를 눌렀는데 화면이 그대로면 돌아갈 길이 없다(사용자)."""
        if getattr(self, '_cmp_kind', '') == 'LIB' and getattr(self, '_cmp_f', None) is not None:
            self._compare_close()

    def set_view(self, view):
        """가운데 이중 화면 — CHAT 채팅 내용 · PROMPT [조회] 결합 · EDIT [수정] 개별."""
        self._close_lib()
        v = str(view or 'CHAT').upper()
        v = v if v in ('CHAT', 'PROMPT', 'EDIT') else 'CHAT'
        self._view = v
        for w in (self._out, self._out_sb, self._ptxt, self._ptxt_sb, self._edf):
            if w.winfo_manager():
                w.pack_forget()
        # ★ 317차-13 — [수정]은 **고른 프롬프트의 제목과 내용만**(채팅제목·요구사항을 숨긴다 · 2-5)(2))
        self._show_req(v != 'EDIT')
        try:
            self._peek_btn.configure(text=T('AI_PEEK_BACK', '대화 보기') if v == 'PROMPT' else T('AI_PEEK', '보낼 글 보기'))
        except Exception:                                 # noqa: BLE001
            pass
        if v == 'CHAT':
            self._out_sb.pack(side='right', fill='y')
            self._out.pack(side='left', fill='both', expand=True)
        elif v == 'PROMPT':
            self._ptxt_sb.pack(side='right', fill='y')
            self._ptxt.pack(side='left', fill='both', expand=True)
            self._paint_prompt()
        else:
            self._edf.pack(fill='both', expand=True)

    def _wrap_r1(self, _e=None):
        """2열 단추 넷 — 한 줄에 들면 한 줄, 좁으면 두 줄(2×2). ⚠ 열 수가 바뀔 때만 다시 깐다(고리 없음)."""
        try:
            w = self._r1.winfo_width()
            need = sum(b.winfo_reqwidth() + 4 for b in self._r1_btns)
            n = len(self._r1_btns)
            cols = n if (w <= 1 or w >= need) else (n + 1) // 2      # 다섯이면 셋·둘
        except Exception:                                 # noqa: BLE001
            cols = len(self._r1_btns)
        if cols == self._r1_cols:
            return
        self._r1_cols = cols
        for i, b in enumerate(self._r1_btns):
            b.grid(row=i // cols, column=i % cols, sticky='w', padx=2, pady=(0, 1))

    def _set_mode(self, m, toggle=True):
        """[조회]/[수정] — 이미 선택한 단추를 또 누르면 채팅 내용으로 돌아간다."""
        m = 'EDIT' if m == 'EDIT' else 'VIEW'
        if toggle and m == self._mode and m == 'EDIT' and self._view != 'CHAT':
            self.set_view('CHAT')
            return
        if self._mode == 'EDIT' and m != 'EDIT':
            self._edit_save()
        self._mode = m
        for k, b in self._mode_btn.items():
            b.configure(**_kw(k == m))
        if m == 'EDIT' and not self._edit:
            self._edit_open(None)
        # ★ 317차-13 — [조회] = 채팅제목 + 요구사항(결합 프롬프트가 거기 다 있다) · 아래 칸은 채팅 내용
        #   (사용자 「하단에 역할/할일 프롬프트를 또 표시하고 있다. 제거하라」)
        self.set_view('CHAT' if m == 'VIEW' else 'EDIT')

    def _item_click(self, target):
        """창고 항목을 눌렀다 — 조회면 결합 프롬프트, 수정이면 그 프롬프트를 가운데에."""
        if self._mode == 'EDIT':
            self._edit_open(target)
            self.set_view('EDIT')
        else:
            self.set_view('CHAT')

    def view(self):
        return self._view

    def _show_req(self, on):
        """채팅제목 줄 · 요구사항 칸을 보이거나 감춘다."""
        try:
            panes = [str(x) for x in self._cpw.panes()]
            has = str(self._inp_pane) in panes
            if on and not has:
                self._cpw.add(self._inp_pane, before=self._body_f, minsize=60, height=96, stretch='never')
            elif not on and has:
                self._cpw.forget(self._inp_pane)
            if on and not self._th_row.winfo_manager():
                self._th_row.pack(fill='x', after=self._tools_f)
            elif not on and self._th_row.winfo_manager():
                self._th_row.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass

    # ── 창고 그리기 ──────────────────────────────────────────────────
    def _load_prompts(self, keep=None):
        """창선택할 다시 그린다 — 업무 · Pick · 묻는 사람 · 내용과 형식."""
        lang = self._lang()
        with self._conn() as c:
            # ★★ 2026-10-27 사용자 「항상 초기 화면은 질문프롬프트가 모두 열거되고 아직 선택하지 않은 상태 · 직전값을 저장하지 말고
            #   Pick화면을 표시하지 마라 · PC에서도」 — 저장된 업무를 안 되살린다(이 화면 안에서 고른 것만 · 갈래에 없으면 비운다)
            if self._task not in self._scope_tasks(c):
                self._task = ''
            if self._task and self._scope != 'FREE' and self._task != getattr(self, '_fmt_for', None):
                UA.apply_task_fmt(c, self._task, lang)    # ★ 2026-10-16 업무마다 제 출력서식(업무가 바뀐 때만 —
                self._fmt_for = self._task                #   그 자리에서 사람이 선택한 벌을 다시 그릴 때 덮지 않는다)
            self._rm_var.set(UA.get_rmode(c))
            self._prompts = (UA.pick_prompts(c, lang, self._scope, self._task, place=self._place_ov() or (
                UA.HOME_PLACE.get(self._task) if (self._scope == 'FREE' or self._task.startswith('HOME_')) else None)) if self._task else [])
            axes = {ax: (UA.axis_rows(c, ax, lang), UA.get_axis(c, ax)) for ax in self._axcb}
        self._by_genre = {}
        self._rm_prev = self._rm_var.get()
        self._restore_unit()
        self._paint_tasks()
        self._paint_picks()
        for ax, (rows, cur) in axes.items():
            cb = self._axcb[ax]
            self._axrows[ax] = rows
            cb.configure(values=[t for _k, t, _b in rows])
            for i, (k, _t, _b) in enumerate(rows):
                if k == cur:
                    cb.current(i)
        self._paint_field(axes.get('STATE', ([], ''))[1])
        self._paint_parts()
        if keep:
            # ★ 새 Pick 은 이름·글을 바로 적게 수정 화면으로
            self._set_mode('EDIT', toggle=False)
            self._edit_open(('PICK', keep))
            self.set_view('EDIT')
        self._after_prompt()
        self._refont()                           # ★ 새로 그린 업무·Pick 단추도 한 구역 글꼴로

    def _paint_tasks(self):
        # ★ 2026-10-21 사용자 「프롬프트 클릭할 때마다 깜빡거린다」 — 누를 때마다 단추를 **지우고 다시 지어** 깜빡였다.
        #   같은 업무 목록이면 있는 단추의 글자·색만 바꾼다(아래 `reuse`).
        for f in (self._rm_f, self._notes_f):
            if f.winfo_manager():
                f.pack_forget()
        with self._conn() as c:
            ts = self._scope_tasks(c)
            # ★ 2026-10-14 연결 살펴보기는 연결 하나를 닻으로 연 대화에서만(폰 연결구절 [AI 분석]) — PC 구절 업무에는 안 보인다
            ts = [t for t in ts if t not in UA.LINK_TASKS or self._link]
            # ★ 2026-10-21 분야 도움말 업무는 「분야 ▾ ▸ AI 에게 묻기」로 연 채팅에서 **그 분야 하나만**
            ra = UA.ROLE_TASK_OF.get(getattr(self, '_role_ask', '') or '')
            ts = [t for t in ts if t not in UA.ROLE_TASKS or t == ra]
            if self._scope == 'REF':
                # ★ 2026-10-28 (docs/1.txt 6-1) 도서 편 닻 = 도서 묵상 + 내가 더한 도서 질문프롬프트(라이브러리 「도서/설교집」)
                ts = ([t for t in ts if t in UA.BOOK_TASKS] + [u['key'] for u in UA.user_tasks(c)
                                                                if 'BOOK' in u.get('scopes', [])]
                      if self._book_unit() else [t for t in ts if t not in UA.BOOK_TASKS])
            lang = self._lang()
            labels = {}
            for t in ts:
                nk = 'AI_T2_%s_%s' % (t, 'T' if self._scope == 'TERM' else 'V') \
                    if t in ('DESC', 'RESEARCH', 'ASK', 'STUDY') else 'AI_T2_' + t
                labels[t] = nk
            # ★ 2026-10-21 (AI도우미.txt 5) 이름은 한 문 — 라이브러리·폰과 같은 글자
            self._task_lbl_cache = {t: (UA.home_title(c, t, lang) if self._scope == 'FREE'
                                        else UA.word_title(c, t, lang) if self._scope == 'VERSE' and t in UA.WORD_TASKS
                                        else UA.task_title(c, self._scope, t, lang))
                                    for t in ts}
            self._rm_lbl_cache = {m: UA.kind_label(c, UA.task_kind(self._scope, 'RESEARCH', m), lang, '')
                                  for m in UA.RESEARCH_MODES}
        if not ts:
            # ★ Free — 프롬프트 예제를 전혀 주지 않는다(docs/1.txt 2-6)(4)나) a.) · 놓는 일은 `_relayout_left`
            self._relayout_left()
            return
        vt = 'T' if self._scope == 'TERM' else 'V'
        w = '용어' if vt == 'T' else '구절'
        ko = {'DESC': ('이 %s의 설명문을 작성해줘' % w) if vt == 'T' else '이 구절의 일반설명문을 작성해줘',
              'XDESC': '이 구절의 전문설명문을 작성해줘', 'LINKAN': '이 연결을 살펴보자', 'RESEARCH': '이 %s%s 연구하자' % (w, '를' if vt == 'T' else '을'),
              'NOTE': '나의 묵상노트를 분석해줘', 'REFAN': '내 연구노트를 분석해줘',
              'SERMAN': '내 설교노트를 분석해줘', 'SERMWR': '설교노트로 다시 쓰기', 'TEACH': 'AI 성경교사', 'BOOKMEDI': '도서 묵상',
              'SERMON': '설교작성을 도와줘',
              # ★ 2026-10-16 「연구하자」를 둘로 · 용어 설명문 분석
              'ASK': '이 %s에 대해 질문하기' % w, 'STUDY': '이 %s%s 성경공부 자료 만들기' % (w, '로' if vt == 'T' else '로'),
              'TERMAN': '이 용어의 설명문 분석',
              'RT_PASTOR': '목회 도움말', 'RT_MISSION': '선교 도움말', 'RT_PWIFE': '사모 도움말'}
        rko = {'ASK': '%s 질문' % w, 'CHECK': '내가 이 %s%s 이해한 것이 맞는가?' % (w, '를' if vt == 'T' else '을'),
               'STUDY': '이 %s에 대한 성경공부 자료를 만들어줘' % w}
        wrap = max(80, getattr(self, '_wrap_used', 220))
        reuse = list(self._task_btns) == list(ts)
        if not reuse:
            for b in self._task_btns.values():
                b.destroy()
            self._task_btns = {}
        for t in ts:
            nk = 'AI_T2_%s_%s' % (t, vt) if t in ('DESC', 'RESEARCH', 'ASK', 'STUDY') else 'AI_T2_' + t
            txt = self._task_lbl_cache.get(t) or T(nk, ko.get(t, t))
            if reuse:
                b = self._task_btns[t]
                want = dict(text=txt, wraplength=wrap, **_kw(t == self._task))
                cur = {k: str(b.cget(k)) for k in want}
                diff = {k: v for k, v in want.items() if cur.get(k) != str(v)}
                if diff:
                    b.configure(**diff)
            else:
                b = tk.Button(self._task_box, text=txt, justify='left', anchor='w', wraplength=wrap,
                              font=self._std_font(), command=lambda t=t: self._pick_task(t), **_kw(t == self._task))
                self._task_btns[t] = b
            if t == 'RESEARCH':
                self._rm_anchor = b
        for m, b in self._rm_btns.items():
            b.configure(text=self._rm_lbl_cache.get(m) or T('AI_RM2_%s_%s' % (m, vt), rko.get(m, m)),
                        wraplength=max(60, wrap - 20))
        # 연구 갈래·노트 범위 줄을 놓는 일은 `_relayout_left`(보이는 단추만 놓으므로 여기서 놓으면 어긋난다)
        self._notes_var.set(self._task == 'NOTE')
        self._relayout_left()

    def _scope_tasks(self, c):
        """이 갈래의 질문 프롬프트 — 홈 AI 대화(옛 Free)는 묵상·성경공부·사회현상·뉴스·Free(2026-10-27)."""
        if self._scope == 'FREE':
            # ★ 2026-10-28 docs/1.txt 6-1 — 라이브러리에서 더한 내 홈 질문프롬프트(UT_ · 갈래 HOME)도 함께
            # ★ 2026-10-31 세상 = 사회현상·뉴스 · Free = Free + 내 질문프롬프트
            if self._world:
                return list(UA.WORLD_TASKS)
            return ['FREE'] + [u['key'] for u in UA.user_tasks(c) if 'HOME' in u.get('scopes', [])]
        ts = UA.tasks_for(self._scope, c)
        if self._scope == 'VERSE':
            # ★ 2026-10-31 말씀 = 프롬프트 여섯이 먼저 · 그 자리 전용 업무(설명문·노트 분석 …)는 그 아래
            ts = list(UA.WORD_TASKS) + [t for t in ts if t not in UA.WORD_TASKS]
        if self._scope == 'TERM':
            # ★ 2026-10-28 폰과 같은 규칙 — 인물 살펴보기는 인물에만 · 장소 조사는 장소에만 · 설명문 분석은 설명문이 있을 때만
            et, has_desc = '', True
            if self._eid:
                try:
                    r = c.execute("SELECT entity_type FROM sys_entity_master WHERE entity_id=?", (self._eid,)).fetchone()
                    et = (r[0] if r else '') or ''
                    has_desc = bool(c.execute(
                        "SELECT 1 FROM sys_text_asset WHERE text_type='ENTITY_DESC' AND clicked_id=?"
                        " AND COALESCE(record_status,'LIVE')<>'HIDE' AND TRIM(COALESCE(contents,''))<>'' LIMIT 1",
                        (self._eid,)).fetchone()) or bool(c.execute(
                        "SELECT 1 FROM user_text_asset WHERE text_type='ENTITY_DESC' AND clicked_id=?"
                        " AND COALESCE(record_status,'LIVE')<>'HIDE' AND TRIM(COALESCE(contents,''))<>'' LIMIT 1",
                        (self._eid,)).fetchone())
                except Exception:                         # noqa: BLE001
                    et, has_desc = '', True
            ts = [t for t in ts if (t != 'FIGURE' or et == 'PERSON') and (t != 'PLACEAN' or et == 'PLACE')
                  and (t != 'TERMAN' or has_desc)]
        return ts

    def _paint_picks(self):
        # ★ 2026-10-21 깜빡임 — 같은 Pick 목록이면 다시 짓지 않고 체크만 맞춘다
        sig = [(p[0], p[2], any(tok in (p[3] or '') for tok in UA.TEACH_N_TOKENS)) for p in self._prompts]
        if sig and sig == getattr(self, '_pick_sig', None) and self._pvars:
            for pid, var in self._pvars.items():
                on = pid in self._checked
                if bool(var.get()) != on:
                    var.set(on)
            return
        self._pick_sig = sig
        for w in self._pbtns:
            w.destroy()
        self._pbtns, self._pvars, self._witems = [], {}, {}
        wrap = getattr(self, '_wrap_used', 220)
        for i, p in enumerate(self._prompts):
            pid, _kind, title = p[0], p[1], p[2]
            var = tk.BooleanVar(value=(pid in self._checked))
            w = tk.Checkbutton(self._pick_box, text=title, variable=var, bg=self._bg, anchor='w',
                               justify='left', wraplength=wrap, font=self._std_font(),
                               command=lambda pid=pid: self._toggle_check(pid))
            w.grid(row=i, column=0, sticky='w', padx=2)
            # ★ 2026-10-21 오른쪽 클릭으로 고치기 걷음(고치기는 라이브러리에서만)
            self._pvars[pid] = var
            self._pbtns.append(w)
            self._witems[pid] = w
            if any(tok in (p[3] or '') for tok in UA.TEACH_N_TOKENS):
                # ★ 2026-10-20 (docs/1.txt 9-8) 성경교사 질문 횟수 — 적은 수가 보낼 글의 자리표에 들어간다
                f = tk.Frame(self._pick_box, bg=self._bg)
                f.grid(row=i, column=1, sticky='w')
                with self._conn() as c:
                    n0 = UA.teach_n(c)
                self._teach_var = tk.StringVar(value=str(n0))
                sb = tk.Spinbox(f, from_=1, to=20, width=3, textvariable=self._teach_var,
                                command=self._teach_n_changed)
                sb.pack(side='left')
                sb.bind('<KeyRelease>', lambda _e: self._teach_n_changed(), add='+')
                tk.Label(f, text=T('AI_TEACH_N_UNIT', '회'), bg=self._bg).pack(side='left')
                self._teach_sb = sb
                self._pbtns.append(f)

    def _teach_n_changed(self):
        try:
            n = int(self._teach_var.get())
        except (ValueError, AttributeError):
            return
        n = max(1, min(20, n))
        with self._conn() as c:
            UA.set_setting(c, UA.TEACH_N_KEY, str(n))
            c.commit()
        self._after_prompt()

    def _paint_parts(self):
        """내용과 형식 단추 — 적힌 칸은 ✓(성경 인용은 비어도 역본으로 저절로 채운다)."""
        head = UA.slot_head(self._lang())
        with self._conn() as c:
            for p, b in self._part_btns.items():
                got = bool(self._part_get(c, p, raw=True))
                d = UA.part_sets(c, p)
                nm = (d['items'][d['on']].get('name') or '') if len(d['items']) > 1 else ''
                b.configure(text=('✓ ' if got else '') + head[p] + ((' · ' + nm) if nm else ''))
        if hasattr(self, '_sum_rows'):
            self._paint_summary()                 # ★ 2026-10-21 접힌 「출력서식」 줄도 함께

    # ── 고르기 ───────────────────────────────────────────────────────
    def _pick_task(self, task):
        self._edit_save()
        self._save_unit()
        with self._conn() as c:
            # ★ 2026-10-27 직전값으로 저장하지 않는다(사용자) — 업무마다 제 출력서식만
            if self._scope != 'FREE':
                UA.apply_task_fmt(c, task, self._lang())
        self._task = self._fmt_for = task
        self._tasks_open = False                 # ★ 2026-10-21 하나를 고르면 나머지는 숨긴다
        self._place_over = None                  # ★ 2026-10-21 사람이 질문을 고르면 도서노트 자리는 풀린다
        with self._conn() as c:                  # ★ 317차-5 — 업무마다 제 Pick
            self._prompts = UA.pick_prompts(c, self._lang(), self._scope, task,
                                            place=UA.HOME_PLACE.get(task) if (self._scope == 'FREE' or task.startswith('HOME_')) else None)
        self._checked = []
        self._restore_unit()
        self._paint_tasks()
        self._paint_picks()
        self._item_click(('TASK', task))
        self._after_prompt()
        self._refont()
        self._kind_note(task)

    def _kind_note(self, task):
        """★ 2026-10-27 (docs/1.txt 6-1(4)) 글 갈래와 업무가 어긋나면 진행 줄에 한 줄 — 막지는 않는다(폰과 같은 글)."""
        try:
            ref = str(self._ref or '')
            if self._scope != 'REF' or not ref.startswith('USER_REF:'):
                return
            with self._conn() as c:
                r = c.execute("SELECT ref_type FROM user_ref_asset WHERE ref_id=?", (int(ref.split(':')[1]),)).fetchone()
            k = (r[0] if r else '') or 'STUDY'
            msg = ''
            if task == 'SERMAN' and k != 'SERMON':
                msg = T('M_AI_KIND_STUDY', '이 글은 연구노트입니다 — 설교 분석으로 봅니다.')
            elif task == 'REFAN' and k == 'SERMON':
                msg = T('M_AI_KIND_SERMON', '이 글은 설교노트입니다 — 연구 분석으로 봅니다.')
            if msg and getattr(self, '_status', None) is not None:
                self._status.config(text=msg)
        except Exception:
            pass

    # ── 2026-10-21 왼쪽 칸 = 질문 전용(시안) ─────────────────────────
    def _toggle_tasks(self):
        self._tasks_open = not self._tasks_open
        self._relayout_left()

    def _toggle_common(self):
        self._common_open = not self._common_open
        self._relayout_left()

    def _edit_task_now(self):
        if self._task:
            self._set_mode('EDIT', toggle=False)
            self._item_click(('TASK', self._task))

    def _edit_close(self):
        self._edit_save()
        self._set_mode('VIEW', toggle=False)
        self.set_view('CHAT')

    def _toggle_peek(self):
        self.set_view('CHAT' if self._view == 'PROMPT' else 'PROMPT')

    def _left_phase(self):
        """FREE · FIRST(첫 질문 전) · FOLLOW(답이 하나라도 왔다)."""
        # ★ 2026-10-28 홈 AI 대화(FREE)에도 질문프롬프트가 있다(317차-133 HOME_TASKS) — 그런데 이 단계가 늘 'FREE' 라
        #   단추는 지어 놓고 왼쪽 칸에 한 번도 안 놓았다(사용자 「PC 에 질문프롬프트 버튼 표시 안 된다」).
        #   업무 목록이 비었을 때만 옛 FREE 모양(Pick 칸만)이다.
        if self._scope == 'FREE' and not self._task_btns:
            return 'FREE'
        return 'FOLLOW' if (self._chat_id and self._last_ai()) else 'FIRST'

    def _relayout_left(self):
        """왼쪽 칸 차례를 단계에 맞춘다 — 시안 ① 질문프롬프트만 ② 고른 하나 + Pick ③ 이어서 묻기 + 이력.
        사용자·출력서식 등은 늘 맨 아래 제목 한 줄씩(누르면 펼침).
        ⚠ 깜빡임 — 보일 것이 지난번과 같으면 다시 놓지 않는다(글자만 고친다)."""
        try:
            ph = self._left_phase()
            ts = list(self._task_btns)
            n_other = max(0, len(ts) - 1)
            has = bool(self._task) and self._task in self._task_btns
            show_all = self._tasks_open or not has
            vis = [t for t in ts if show_all or t == self._task]
            sub = None
            if self._task == 'RESEARCH' and 'RESEARCH' in vis:
                sub = ('RESEARCH', self._rm_f)
            elif self._task == 'NOTE' and 'NOTE' in vis:
                sub = ('NOTE', self._notes_f)
            want_t = [self._task_btns[t] for t in vis]
            if sub:
                want_t.insert(vis.index(sub[0]) + 1, sub[1])
            if list(self._task_box.pack_slaves()) != want_t:      # 실제로 놓인 것과 견준다
                for b in self._task_btns.values():
                    if b.winfo_manager():
                        b.pack_forget()
                for f in (self._rm_f, self._notes_f):
                    if f.winfo_manager():
                        f.pack_forget()
                for t in vis:
                    self._task_btns[t].pack(fill='x', padx=2, pady=1)
                if sub:
                    sub[1].pack(fill='x', pady=(0, 2), after=self._task_btns[sub[0]])
            # ★ 2026-10-21 (AI도우미.txt 4-2) 고치기는 라이브러리에서만 — 이 칸은 쓰기만(✎ 걷음)
            #   고른 뒤에는 「질문프롬프트」 제목 줄도 걷는다(맨 위 [다른 질문프롬프트들 보기] 아래에 고른 것 하나)
            # ★ 2026-10-21 (AI도우미.txt 2) 「질문프롬프트」 제목은 **늘 맨 위**(구절·용어·연구/설교노트) — 아래 `order` 맨 앞
            head = self._task_head
            self._copyp_btn2.configure(state='disabled' if (self._chat_id and self._last_ai()) else 'normal')
            if show_all and has:
                more_txt = T('AI_TASKS_FOLD', '▴ 선택한 질문프롬프트만 보기')
            else:
                more_txt = T('AI_TASKS_MORE', '▸ 다른 질문프롬프트들 보기 (%d)') % n_other
            if str(self._more_btn.cget('text')) != more_txt:
                self._more_btn.configure(text=more_txt)
            order = []
            fk = self._free_keys() if self._scope == 'FREE' else ['USER', 'FORMAT', 'ETC']
            want_rows = [k for k, ok in (('USER', 'USER' in fk), ('FMT', 'FORMAT' in fk),
                                         ('ETC', bool(set(fk) - {'USER', 'FORMAT'}))) if ok]
            cur_rows = [k for k in ('USER', 'FMT', 'ETC') if self._sum_rows[k].master.winfo_manager()]
            if cur_rows != want_rows:
                for k in ('USER', 'FMT', 'ETC'):
                    self._sum_rows[k].master.pack_forget()
                for k in want_rows:
                    self._sum_rows[k].master.pack(fill='x', pady=0)
            if ph == 'FREE':
                order.append(self._pick_f)
                if self._fu_show:
                    order.append(self._bm_f)
                if self._chat_id and self._last_ai():
                    order.append(self._hist_f)
            elif ph == 'FIRST':
                order.append(head)
                if has:
                    if n_other:
                        order.append(self._more_btn)
                    order += [self._task_f, self._pick_f]
                else:
                    order.append(self._task_f)
                if self._fu_show:                         # 도서 묵상 단계 단추(첫 말부터)
                    order.append(self._bm_f)
            else:
                tname = self._task_btns[self._task].cget('text') if has else ''
                self._curq.configure(text=T('AI_CURQ', '지금 질문: %s · Pick %d ▸') % (tname, len(self._checked)))
                order.append(head)
                if n_other or not has:
                    order.append(self._more_btn)
                if show_all:
                    order += [self._task_f, self._pick_f]
                else:
                    order.append(self._curq)
                if self._fu_show:
                    order.append(self._bm_f)
                order.append(self._hist_f)
            if self._hist_f in order:
                self._paint_hist()
            if want_rows:
                order.append(self._sum_f)
                if self._common_open:
                    order.append(self._common_f)
            mine = {id(w) for w in (head, self._more_btn, self._curq, self._task_f, self._pick_f, self._bm_f,
                                    self._hist_f, self._sum_f, self._common_f)}
            cur = [w for w in self._pr_left.pack_slaves() if id(w) in mine]
            if cur != order:
                for w in (head, self._more_btn, self._curq, self._task_f, self._pick_f, self._bm_f, self._hist_f,
                          self._sum_f, self._common_f):
                    if w.winfo_manager():
                        w.pack_forget()
                for w in order:
                    w.pack(fill='x', pady=(2, 4), padx=(0, 2))
            self._paint_summary()
            self._pcv_fit()
        except Exception as e:                            # noqa: BLE001
            print('[left relayout] %s' % e)

    def left_order(self):
        """시험용 — 지금 왼쪽 칸에 놓인 것의 이름(위→아래)."""
        nm = {id(self._task_head): 'HEAD', id(self._more_btn): 'MORE', id(self._curq): 'CURQ', id(self._task_f): 'TASKS',
              id(self._pick_f): 'PICK', id(self._bm_f): 'FOLLOW', id(self._hist_f): 'HIST',
              id(self._sum_f): 'SUMMARY', id(self._common_f): 'COMMON'}
        return [nm[id(w)] for w in self._pr_left.pack_slaves() if id(w) in nm]

    def _paint_hist(self):
        qs = [b for r, b in self.messages() if r == 'user'] if self._chat_id else []
        if (self._chat_id, qs) == getattr(self, '_hist_sig', None):
            return
        self._hist_sig = (self._chat_id, qs)
        for w in self._hist_box.winfo_children():
            w.destroy()
        wrap = max(120, getattr(self, '_wrap_used', 220))
        for i, q in enumerate(qs, 1):
            one = ' '.join((q or '').split())
            if i == 1 and self._task in self._task_btns:
                # 첫 말은 결합 프롬프트 전문이라 — 질문프롬프트 이름 + Pick 수로 적는다
                one = '%s · Pick %d' % (self._task_btns[self._task].cget('text'), len(self._checked))
            tk.Label(self._hist_box, text='%d%s · %s' % (i, T('AI_HIST_TURN', '회'), one[:60] + ('…' if len(one) > 60 else '')),
                     bg=self._bg, fg=_C('fg_dim', '#4A5A6A'), anchor='w', justify='left',
                     wraplength=wrap).pack(fill='x', padx=4)

    def _paint_summary(self):
        try:
            us = ' · '.join(cb.get() for cb in self._axcb.values() if (cb.get() or '').strip())
            self._sum_rows['USER'].configure(text=(us or '-') + ' ▸')
            ft = self._part_btns['FORMAT'].cget('text') if 'FORMAT' in self._part_btns else ''
            ft = ft.split(' · ', 1)[1] if ' · ' in ft else ft.replace('✓ ', '')
            self._sum_rows['FMT'].configure(text=(ft or '-') + ' ▸')
            self._sum_rows['ETC'].configure(text=(T('AI_SUM_OPEN', '접기 ▾') if self._common_open
                                                  else T('AI_SUM_LIB', '라이브러리대로 ▸')))
        except Exception:                                 # noqa: BLE001
            pass

    # ── 2026-10-21 1단 인라인 고르기(팝업 대신) ──────────────────────
    def _build_inline(self, box, bg):
        self._inl_v = tk.Frame(box, bg=bg)
        self._pick_msg = tk.Label(box, text='', bg=bg, fg=_C('fg_dim', '#7F8C8D'))
        self._build_pick_verse(self._inl_v, bg)
        try:
            self._pk_text.pack_forget()                   # 미리보기 글은 이 줄에서는 안 보인다
        except Exception:                                 # noqa: BLE001
            pass
        for w in (self._pk_vs, self._pk_evs):
            w.bind('<<ComboboxSelected>>', lambda _e: self._inline_apply_verse(), add='+')
        self._pk_ch.bind('<<ComboboxSelected>>', lambda _e: self._inline_apply_verse(), add='+')
        self._pk_book.bind('<<ComboboxSelected>>', lambda _e: self._inline_apply_verse(), add='+')
        self._inl_s = {}
        self._pk = {}
        for key in ('TERM', 'REF'):
            f = tk.Frame(box, bg=bg)
            cb = ttk.Combobox(f, width=28, values=[])
            cb.pack(side='left')
            cb.bind('<KeyRelease>', lambda e, k=key: self._inline_search_soon(k, e), add='+')
            cb.bind('<Return>', lambda _e, k=key: self._inline_search(k), add='+')
            cb.bind('<<ComboboxSelected>>', lambda _e, k=key: self._inline_pick(k), add='+')
            self._inl_s[key] = {'frame': f, 'cb': cb, 'rows': [], 'job': None}
        self._inline_sync()

    def _inline_sync(self):
        """갈래에 맞는 칸만 보인다 · 구절이면 지금 닻을 콤보에 맞춘다."""
        try:
            for w in (self._inl_v, self._inl_s['TERM']['frame'], self._inl_s['REF']['frame']):
                if w.winfo_manager():
                    w.pack_forget()
            if self._scope == 'VERSE':
                self._inl_v.pack(side='left')
                if self._start and not getattr(self, '_inl_busy', False):
                    with self._conn() as c:
                        r = c.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                                      (self._start,)).fetchone()
                        e = c.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?",
                                      (self._end,)).fetchone() if (self._end and self._end != self._start) else None
                    if r:
                        for i, (bc, _nm) in enumerate(self._pk_books):
                            if bc == r[0]:
                                self._pk_book.current(i)
                        self._pk_fill_ch()
                        self._pk_ch.set(str(r[1]))
                        self._pk_fill_vs()
                        self._pk_vs.set(str(r[2]))
                        self._pk_fill_ech()
                        if e:
                            self._pk_ech.set(str(e[0]))
                            self._pk_fill_evs()
                            self._pk_evs.set(str(e[1]))
                        else:
                            self._pk_ech.set('')
                            self._pk_evs.set('')
            elif self._scope in ('TERM', 'REF'):
                self._inl_s[self._scope]['frame'].pack(side='left')
                if not self._inl_s[self._scope]['rows']:
                    self._inline_search(self._scope)
        except Exception as e:                            # noqa: BLE001
            print('[inline sync] %s' % e)

    def _inline_apply_verse(self):
        """콤보를 고르면 곧바로 닻 — 시작 절(+ 끝 장:절이 있으면 구간)."""
        try:
            i = self._pk_book.current()
            ch = (self._pk_ch.get() or '').strip()
            vs = (self._pk_vs.get() or '').strip()
            if i < 0 or not ch or not vs:
                return
            with self._conn() as c:
                r = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                              (self._pk_books[i][0], int(ch), int(vs))).fetchone()
            if not r:
                return
            ech, evs = (self._pk_ech.get() or '').strip(), (self._pk_evs.get() or '').strip()
            if evs and not ech:                  # ★ 끝 절만 고르면 끝 장 = 시작 장
                ech = ch
                self._pk_ech.set(ch)
            self._inl_busy = True
            try:
                self.set_anchor(int(r[0]))
                if ech and evs:
                    self.set_range(ech, evs)
            finally:
                self._inl_busy = False
        except Exception as e:                            # noqa: BLE001
            print('[inline verse] %s' % e)

    def _inline_search_soon(self, key, e=None):
        if e is not None and e.keysym in ('Up', 'Down', 'Return', 'Escape', 'Tab'):
            return
        d = self._inl_s[key]
        if d['job']:
            try:
                self.after_cancel(d['job'])
            except Exception:                             # noqa: BLE001
                pass
        d['job'] = self.after(350, lambda: self._inline_search(key))

    def _inline_search(self, key):
        """검색칸 글로 찾는다 — 찾는 문은 팝업과 같다(`_pk_search`)."""
        d = self._inl_s[key]
        d['job'] = None

        class _Q:
            def __init__(self, s):
                self.s = s

            def get(self):
                return self.s
        src = tk.StringVar(master=self, value='ALL')
        lb = tk.Listbox(self)
        self._pk[key] = {'q': _Q(d['cb'].get()), 'src': src, 'list': lb, 'rows': []}
        try:
            self._pk_search(key)
            d['rows'] = list(self._pk[key]['rows'])
        finally:
            lb.destroy()
        d['cb'].configure(values=[nm for _v, nm in d['rows']])

    def _inline_pick(self, key):
        d = self._inl_s[key]
        i = d['cb'].current()
        if i < 0 or i >= len(d['rows']):
            return
        val = d['rows'][i][0]
        if key == 'TERM':
            self.set_term(val)
        else:
            self.set_ref(val)

    def _pick_rmode(self):
        self._save_unit(mode=getattr(self, '_rm_prev', None))
        with self._conn() as c:
            UA.set_rmode(c, self._rm_var.get())
        self._restore_unit()
        self._paint_picks()
        self._rm_prev = self._rm_var.get()
        if self._task == 'RESEARCH':
            self._item_click(('TASK', 'RESEARCH'))
        self._after_prompt()

    def _toggle_check(self, pid):
        var = self._pvars.get(pid)
        if var is not None and var.get():
            if pid not in self._checked:
                self._checked.append(pid)
        elif pid in self._checked:
            self._checked.remove(pid)
        self._save_unit()
        self._item_click(('PICK', pid))
        self._after_prompt()

    def _paint_field(self, state):
        """「분야」 줄 — 평신도 갈래 상태일 때만 보인다(사역자는 상태가 곧 분야)."""
        try:
            import role_tips as RT
        except Exception:                                 # noqa: BLE001
            return
        on = (state or '').upper() in RT.LAY_STATES or not state
        if not on:
            self._field_row.pack_forget()
            return
        lang = self._lang()
        with self._conn() as c:
            cur = (UA.get_setting(c, RT.FIELD_KEY, '') or '').upper()
            names = []
            for code, key, ko, en in RT.roles('LAY'):
                names.append(UA._ui_label(c, key, lang) or (ko if lang == 'KO' else en))
        self._field_codes = [r[0] for r in RT.roles('LAY')]
        self._field_cb.configure(values=[T('AI_FIELD_NONE', '선택 안 함')] + names)
        self._field_cb.current(self._field_codes.index(cur) + 1 if cur in self._field_codes else 0)
        if not self._field_row.winfo_manager():
            self._field_row.pack(fill='x', pady=0)

    def _pick_field(self):
        try:
            import role_tips as RT
        except Exception:                                 # noqa: BLE001
            return
        i = self._field_cb.current()
        code = self._field_codes[i - 1] if 1 <= i <= len(self._field_codes) else ''
        with self._conn() as c:
            UA.set_setting(c, RT.FIELD_KEY, code)
            c.commit()

    def _pick_axis_cb(self, ax):
        cb = self._axcb[ax]
        i = cb.current()
        rows = self._axrows.get(ax) or []
        if 0 <= i < len(rows):
            with self._conn() as c:
                UA.set_axis(c, ax, rows[i][0])
            if ax == 'STATE':
                self._paint_field(rows[i][0])
            if self._mode == 'EDIT':
                self._item_click(('AXIS', rows[i][0]))
            else:
                self.set_view('CHAT')
        self._after_prompt()

    def _pick_axis(self, axis, kind):
        """옛 이름 — 축 값을 선택한다(하네스가 부른다)."""
        with self._conn() as c:
            UA.set_axis(c, axis, kind)
        self._load_prompts()

    def _edit_axis(self, ax):
        cb = self._axcb[ax]
        i = cb.current()
        rows = self._axrows.get(ax) or []
        if rows:
            self._set_mode('EDIT', toggle=False)
            self._item_click(('AXIS', rows[i if 0 <= i < len(rows) else 0][0]))

    # ── 317차-14 — 관리 목록(가운데 [수정] 위) ───────────────────────────
    def _task_item_label(self, target):
        t = target[1]
        if t == 'RESEARCH':
            m = target[2] if len(target) > 2 else self._rm_var.get()
            b = self._rm_btns.get(m)
            return '%s · %s' % (getattr(self, '_rm_anchor', None).cget('text') if getattr(self, '_rm_anchor', None)
                                else t, b.cget('text') if b is not None else m)
        b = self._task_btns.get(t)
        return b.cget('text') if b is not None else t

    def _ed_section_rows(self, target):
        """그 대상이 속한 갈래의 목록 — `(갈래, [(이름, 대상)])`."""
        if not target:
            return None, []
        kind = target[0]
        lang = self._lang()
        rows = []
        with self._conn() as c:
            if kind in ('TASK', 'ROLE'):
                for t in UA.tasks_for(self._scope, c):
                    if t == 'RESEARCH':
                        for m in UA.RESEARCH_MODES:
                            rows.append((self._task_item_label(('TASK', t, m)), ('TASK', t, m)))
                    else:
                        rows.append((self._task_item_label(('TASK', t)), ('TASK', t)))
                return 'TASK', rows
            if kind == 'PICK':
                return 'PICK', [(p[2], ('PICK', p[0])) for p in (self._prompts or [])]
            if kind == 'AXIS':
                ax = UA.axis_of_kind(target[1])
                return ('AXIS', ax), [(t, ('AXIS', k)) for k, t, _b in UA.axis_rows(c, ax, lang)]
            if kind == 'PART':
                d = UA.part_sets(c, target[1])
                none = T('AI_PSET_DEFAULT', '기본')
                if target[1] == 'FORMAT':
                    # ★ 2026-10-20 탭 갈래만 — 하나 선택(●) · 복수 선택(☑ 켬 / ☐ 끔)
                    multi = self._fmt_tab == 'MULTI'
                    ck = set(d.get('checked') or [])
                    return ('PART', 'FORMAT'), [
                        ((('☑ ' if i in ck else '☐ ') if multi else ('● ' if i == d['on'] else '   ')) + (it.get('name') or none),
                         ('PART', 'FORMAT', i))
                        for i, it in enumerate(d['items']) if bool(it.get('multi')) == multi]
                return ('PART', target[1]), [(('● ' if i == d['on'] else '   ') + (it.get('name') or none),
                                              ('PART', target[1], i)) for i, it in enumerate(d['items'])]
        return None, []

    def _ed_same(self, a, b):
        if not a or not b or a[0] != b[0]:
            return False
        if a[0] == 'TASK':
            ma = a[2] if len(a) > 2 else (self._rm_var.get() if a[1] == 'RESEARCH' else None)
            mb = b[2] if len(b) > 2 else (self._rm_var.get() if b[1] == 'RESEARCH' else None)
            return a[1] == b[1] and (a[1] != 'RESEARCH' or ma == mb)
        if a[0] == 'PART':
            with self._conn() as c:
                on = UA.part_sets(c, a[1])['on']
            return a[1] == b[1] and (a[2] if len(a) > 2 else on) == (b[2] if len(b) > 2 else on)
        return a[1:2] == b[1:2]

    def _set_fmt_tab(self, k):
        """출력서식 탭 — 그 갈래 목록만 보인다."""
        self._edit_save()
        self._fmt_tab = k
        for kk, b in self._fmt_tab_btn.items():
            b.configure(**_kw(kk == k))
        self._ed_fill(('PART', 'FORMAT'))

    def _ed_fill(self, target):
        """관리 목록을 채우고 지금 고친 것을 선택해 둔다 · 단추 상태(삭제는 지울 수 있는 것만)."""
        if target and target[0] == 'PART' and target[1] == 'FORMAT' and len(target) > 2:
            with self._conn() as c:                       # 고치는 벌의 갈래 탭으로
                _it = UA.part_sets(c, 'FORMAT')['items']
            if 0 <= target[2] < len(_it):
                want = 'MULTI' if _it[target[2]].get('multi') else 'ONE'
                if want != self._fmt_tab:
                    self._fmt_tab = want
                    for kk, b in self._fmt_tab_btn.items():
                        b.configure(**_kw(kk == want))
        sec, rows = self._ed_section_rows(target)
        try:
            show = isinstance(sec, tuple) and sec == ('PART', 'FORMAT')
            if show and not self._fmt_tabs_f.winfo_manager():
                self._fmt_tabs_f.pack(fill='x', before=self._ed_lbx)
            elif not show and self._fmt_tabs_f.winfo_manager():
                self._fmt_tabs_f.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass
        self._ed_sec = sec
        self._ed_rows = rows
        lbx = self._ed_list
        lbx.delete(0, 'end')
        sel = None
        for i, (nm, tg) in enumerate(rows):
            lbx.insert('end', nm)
            if sel is None and self._ed_same(tg, target):
                sel = i
        if sel is not None:
            lbx.selection_set(sel)
            lbx.see(sel)
        if not rows:
            if self._ed_lf.winfo_manager():
                self._ed_lf.pack_forget()
            return
        if not self._ed_lf.winfo_manager():
            self._ed_lf.pack(fill='x', pady=(2, 2), after=self._ed_lbl.master)
        can_del = can_reset = False
        s0 = sec[0] if isinstance(sec, tuple) else sec
        if s0 == 'PICK':
            can_del = target[0] == 'PICK'
        elif s0 == 'TASK':
            can_del = target[0] == 'TASK' and str(target[1]).startswith('UT_')
            can_reset = target[0] == 'TASK' and not str(target[1]).startswith('UT_')
        elif s0 == 'AXIS':
            can_del = target[1] != UA.AXIS_DEFAULT.get(sec[1])
            can_reset = True
        elif s0 == 'PART':
            can_del = len(rows) > 1
        self._ed_delb.configure(state=('normal' if can_del else 'disabled'))
        self._ed_reset.configure(state=('normal' if can_reset else 'disabled'))
        self._ed_add.configure(state=('normal' if s0 in ('PICK', 'TASK', 'AXIS', 'PART') else 'disabled'))

    def _ed_list_pick(self, _e=None):
        sel = self._ed_list.curselection()
        if not sel or not 0 <= sel[0] < len(self._ed_rows):
            return
        tg = self._ed_rows[sel[0]][1]
        if tg[0] == 'PART':
            self._edit_save()
            with self._conn() as c:
                _is_multi = tg[1] == 'FORMAT' and UA.part_sets(c, 'FORMAT')['items'][tg[2]].get('multi')
                UA.part_select(c, tg[1], tg[2])        # ★ 고른 벌이 곧 보내는 글(복수 서식은 켜고 끈다)
                if tg[1] == 'FORMAT' and self._task and self._scope != 'FREE' and not _is_multi:
                    UA.remember_task_fmt(c, self._task, tg[2])   # ★ 2026-10-16 이 업무에서 쓸 서식으로 기억
            self._paint_parts()
            self._after_prompt()
            if _is_multi:
                self._ed_fill(tg)                       # ☑/☐ 를 다시 그린다
        if self._ed_same(tg, self._edit):
            return
        self._edit_open(tg)

    def _ed_add_click(self):
        """[+ 추가] — 그 갈래에 새것 하나를 만들고 고치는 칸에 올린다(이름 칸에 커서)."""
        self._edit_save()
        sec = self._ed_sec
        s0 = sec[0] if isinstance(sec, tuple) else sec
        lang = self._lang()
        tg = None
        with self._conn() as c:
            if s0 == 'TASK':
                key = UA.add_user_task(c, self._scope, lang, T('AI_NEW_TASK', '새 질문프롬프트'), '')
                tg = ('TASK', key) if key else None
            elif s0 == 'AXIS':
                k = UA.add_axis_item(c, sec[1], lang, T('AI_NEW_ITEM', '새 항목'), '')
                tg = ('AXIS', k) if k else None
            elif s0 == 'PART':
                _multi = sec[1] == 'FORMAT' and self._fmt_tab == 'MULTI'
                i = UA.part_add(c, sec[1], T('AI_NEW_SET', '새 서식'), multi=_multi)
                tg = ('PART', sec[1], i)
                if sec[1] == 'FORMAT' and self._task and self._scope != 'FREE' and not _multi:
                    self._fmt_new = self._task                # 이름을 적고 나면 이 업무의 서식으로 기억(_edit_save)
        if s0 == 'PICK':
            pid = self._new_prompt()
            tg = ('PICK', pid)
        if tg is None:
            return
        self._load_prompts()
        self._edit_open(tg)
        self._ed_msg.config(text=T('AI_ED_ADDED', '만들었습니다 — 이름과 내용을 적으세요'))
        try:
            self._tpl_title.focus_set()
            self._tpl_title.select_range(0, 'end')
        except Exception:                                 # noqa: BLE001
            pass

    def _ed_del_click(self):
        tg = self._edit
        if not tg:
            return
        self._edit_dirty = False
        nxt = None
        with self._conn() as c:
            if tg[0] == 'PICK':
                UA.hide_prompt(c, tg[1], place=self._lib_place())
            elif tg[0] == 'TASK' and str(tg[1]).startswith('UT_'):
                UA.hide_user_task(c, tg[1])
                if self._task == tg[1]:
                    self._task = UA.get_task(c, self._scope)
            elif tg[0] == 'AXIS':
                ax = UA.axis_of_kind(tg[1])
                if UA.hide_axis_item(c, tg[1]):
                    nxt = ('AXIS', UA.AXIS_DEFAULT.get(ax))
            elif tg[0] == 'PART':
                d = UA.part_sets(c, tg[1])
                i = tg[2] if len(tg) > 2 else d['on']
                if UA.part_del(c, tg[1], i):
                    nxt = ('PART', tg[1])
            else:
                return
        self._edit = None
        self._load_prompts()
        if nxt is None and tg[0] == 'TASK' and self._task:
            nxt = ('TASK', self._task)
        self._edit_open(nxt)
        self._paint_parts()
        self._after_prompt()
        self._ed_msg.config(text=T('AI_ED_DELETED', '지웠습니다'))

    def _ed_reset_click(self):
        """[기본으로] — 앱 업무는 이름·내용을 처음 글로 · 사용자 목록은 숨긴 항목을 되살리고 선택한 항목 글을 처음으로."""
        tg = self._edit
        if not tg:
            return
        self._edit_dirty = False
        lang = self._lang()
        with self._conn() as c:
            if tg[0] == 'TASK' and not str(tg[1]).startswith('UT_'):
                _m = tg[2] if len(tg) > 2 else self._rm_var.get()
                UA.reset_task(c, UA.task_kind(self._scope, tg[1], _m), lang)
                if UA.role_kind(tg[1]):
                    UA.reset_task(c, UA.role_kind(tg[1]), lang)
            elif tg[0] == 'AXIS':
                UA.restore_axis(c, UA.axis_of_kind(tg[1]), tg[1], lang)
            else:
                return
        self._load_prompts()
        self._edit_open(tg)
        self._after_prompt()
        self._ed_msg.config(text=T('AI_ED_RESET_DONE', '처음 글로 되돌렸습니다'))

    # ── 고치는 칸(조회·수정) ───────────────────────────────────────────
    def _part_get(self, c, p, raw=False):
        if p == 'FREE':
            return UA.get_free(c)
        if p == 'BAN':
            return UA.get_ban(c)
        if p == 'FORMAT':
            return UA.get_fmt(c)
        if raw:
            return (UA.get_setting(c, UA.PART_KEY[p], '') or '').strip()
        return UA.get_part(c, p)

    def _part_set(self, c, p, text):
        if p == 'FREE':
            UA.set_free(c, text)
        elif p == 'BAN':
            UA.set_ban(c, text)
        elif p == 'FORMAT':
            UA.set_fmt(c, text)
        else:
            UA.set_part(c, p, text)

    def _ed_touched(self, _e=None):
        self._edit_dirty = True
        try:
            if self._in_job:
                self.after_cancel(self._in_job)
        except Exception:                                 # noqa: BLE001
            pass
        self._in_job = self.after(400, self._paint_prompt)

    def _edit_open(self, target):
        """고치는 칸에 그것을 올린다 — 앞엣것을 먼저 저장한다(3-3 다른 곳을 누를 때)."""
        self._edit_save()
        self._edit = target
        lang = self._lang()
        title, body, lbl, has_title, can_del = '', '', T('AI_ED_NONE', '왼쪽에서 고칠 것을 누르세요'), False, False
        head = UA.slot_head(lang)
        with self._conn() as c:
            if target and target[0] == 'PICK':
                p = self._cur_by_id(target[1])
                if p:
                    title, body = p[2], p[3]
                    lbl = '%s · %s' % ('Pick', p[2])
                    has_title, can_del = True, True
            elif target and target[0] == 'TASK':
                _m = target[2] if len(target) > 2 else self._rm_var.get()
                k = UA.task_kind(self._scope, target[1], _m)
                _pid, title, body = UA.task_row(c, k, lang)
                role = UA.task_row(c, UA.role_kind(target[1]), lang)[2] or UA.task_row(c, UA.ROLE_KIND, lang)[2]
                lbl = self._task_item_label(target)
                # ★ 이름 칸 = 화면 단추 이름(사람이 고친 이름이 있으면 그것) — 안 고치면 저장하지 않는다
                if not str(target[1]).startswith('UT_'):
                    if target[1] == 'RESEARCH':
                        _b = self._rm_btns.get(_m)
                        title = _b.cget('text') if _b is not None else title
                    else:
                        _b = self._task_btns.get(target[1])
                        title = _b.cget('text') if _b is not None else title
                has_title = True
            elif target and target[0] == 'ROLE':
                _pid, title, body = UA.task_row(c, UA.ROLE_KIND, lang)
                lbl = head['ROLE']
            elif target and target[0] == 'AXIS':
                pid = UA.axis_prompt_id(c, target[1], lang)
                r = c.execute("SELECT title, body FROM user_ai_prompt WHERE prompt_id=?",
                              (pid,)).fetchone() if pid else None
                title, body = (r[0], r[1]) if r else ('', '')
                lbl = '%s · %s' % (head['ASKER'], title)
                has_title = True
            elif target and target[0] == 'PART':
                d = UA.part_sets(c, target[1])
                i = target[2] if len(target) > 2 else d['on']
                if not 0 <= i < len(d['items']):
                    i = d['on']
                title = d['items'][i].get('name') or ''
                body = d['items'][i].get('body') or '' if i != d['on'] else self._part_get(c, target[1], raw=True)
                lbl = head[target[1]]
                has_title = True
        self._ed_lbl.config(text=lbl)
        self._ed_title0 = title or ''
        self._ed_fill(target)
        is_task = bool(target and target[0] == 'TASK')
        for w in (self._ed_role_lbl, self._tpl_role, self._ed_task_lbl):
            if w.winfo_manager():
                w.pack_forget()
        self._tpl_role.delete('1.0', 'end')
        if is_task:
            # ★ 업무마다 역할과 할일(docs/1.txt 2-6)(4)가))
            self._ed_role_lbl.pack(fill='x', before=self._tpl_txt)
            self._tpl_role.pack(fill='x', before=self._tpl_txt, pady=(0, 2))
            self._ed_task_lbl.pack(fill='x', before=self._tpl_txt)
            self._tpl_role.insert('1.0', role or '')
        self._tpl_txt.configure(state='normal')
        self._tpl_title.delete(0, 'end')
        self._tpl_txt.delete('1.0', 'end')
        _first = self._ed_role_lbl if is_task else self._tpl_txt
        if has_title:
            if not self._tpl_title.winfo_manager():
                self._tpl_title_lbl.pack(fill='x', before=_first)
                self._tpl_title.pack(fill='x', before=_first)
            self._tpl_title.insert(0, title or '')
        elif self._tpl_title.winfo_manager():
            self._tpl_title_lbl.pack_forget()
            self._tpl_title.pack_forget()
        # ★ 317차-14 — 지우기는 위 관리 줄의 [삭제] 하나로(옛 [지우기] 단추는 안 놓는다)
        if self._del_btn.winfo_manager():
            self._del_btn.pack_forget()
        self._tpl_txt.insert('1.0', body or '')
        self._tpl_txt.configure(state=('normal' if target else 'disabled'))
        self._edit_dirty = False

    def _edit_save(self):
        """고치던 것을 저장한다 — **바뀐 것이 있을 때만**(다른 곳을 누를 때 · 3-3)."""
        tgt = getattr(self, '_edit', None)
        if tgt:
            self._commit_ime(self._tpl_txt)
            if tgt[0] == 'TASK':
                self._commit_ime(self._tpl_role)
        if not tgt or not getattr(self, '_edit_dirty', False):
            return
        self._edit_dirty = False
        try:
            body = self._tpl_txt.get('1.0', 'end').strip()
            title = (self._tpl_title.get() or '').strip()
        except Exception:                                 # noqa: BLE001
            return
        lang = self._lang()
        with self._conn() as c:
            if tgt[0] == 'PICK':
                p = self._cur_by_id(tgt[1])
                if p:
                    UA.save_prompt(c, p[0], title or p[2], body)
            elif tgt[0] in ('TASK', 'ROLE'):
                _m = tgt[2] if len(tgt) > 2 else self._rm_var.get()
                k = UA.ROLE_KIND if tgt[0] == 'ROLE' else UA.task_kind(self._scope, tgt[1], _m)
                _nt = title if (tgt[0] == 'TASK' and title and title != getattr(self, '_ed_title0', '')) else None
                UA.put_task_text(c, k, lang, body=body, title=_nt)
                if tgt[0] == 'TASK' and UA.role_kind(tgt[1]):
                    UA.put_task_text(c, UA.role_kind(tgt[1]), lang,
                                     body=self._tpl_role.get('1.0', 'end').strip())
            elif tgt[0] == 'AXIS':
                pid = UA.axis_prompt_id(c, tgt[1], lang)
                if pid:
                    r = c.execute("SELECT title FROM user_ai_prompt WHERE prompt_id=?", (pid,)).fetchone()
                    UA.save_prompt(c, pid, title or (r[0] if r else tgt[1]), body)
            elif tgt[0] == 'PART':
                d = UA.part_sets(c, tgt[1])
                i = tgt[2] if len(tgt) > 2 else d['on']
                UA.part_write(c, tgt[1], i, name=title, body=body)
                # ★ 2026-10-16 지금 쓰는 서식 벌을 고치거나 새로 만들었으면 이 업무의 서식으로 기억(이름이 바뀌어도 따라간다)
                if (tgt[1] == 'FORMAT' and self._task and self._scope != 'FREE'
                        and (i == d['on'] or getattr(self, '_fmt_new', None) == self._task)):
                    UA.remember_task_fmt(c, self._task, i)
                    self._fmt_new = None
            c.commit()
        if tgt[0] == 'PICK':
            with self._conn() as c:
                self._prompts = UA.pick_prompts(c, lang, self._scope, self._task, place=self._place_ov())
            self._paint_picks()
        if tgt[0] in ('TASK', 'AXIS'):
            self._load_prompts()
        self._paint_parts()
        self._ed_fill(tgt)
        self._status.config(text=T('AI_TPL_SAVED', '프롬프트를 저장했습니다(내 것으로).'))
        self._after_prompt()

    @staticmethod
    def _save_task_text(c, kind, lang, body):
        """업무 글을 그 언어 줄에 적는다 — 그 언어 줄이 없으면 만든다(영어 줄을 안 덮는다)."""
        r = c.execute("SELECT prompt_id FROM user_ai_prompt WHERE kind=? AND lang_code=? AND scope='TASK'"
                      " AND record_status='LIVE' ORDER BY prompt_id LIMIT 1", (kind, lang)).fetchone()
        if r:
            c.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", (body, r[0]))
            return
        sd = UA.SEED_TASK.get(kind) or UA.SEED_ROLE.get(kind) or {}
        seed = sd.get(lang) or sd.get('EN') or (kind, '')
        c.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre)"
                  " VALUES(?,?,?,?,?,'TASK','ANAL')", (lang, kind, seed[0], body,
                                                       (UA.TASK_ALL.index(kind) if kind in UA.TASK_ALL else 50) * 10))

    def _cur_by_id(self, pid):
        if pid is None:
            return None
        for p in (self._prompts or []):
            if p[0] == pid:
                return p
        return None

    def _cur_prompt(self):
        t = getattr(self, '_edit', None)
        return self._cur_by_id(t[1]) if t and t[0] == 'PICK' else None

    def prompt_titles(self):
        return [p[2] for p in self._prompts]

    def pick_prompt_by_title(self, part):
        """이름 조각으로 Pick 을 체크한다(하네스가 부른다)."""
        for p in self._prompts:
            if part in p[2]:
                v = self._pvars.get(p[0])
                if v is not None:
                    v.set(True)
                self._toggle_check(p[0])
                return True
        return False

    def _new_pick_lib(self):
        """Pick [+ 추가] — 라이브러리 그 질문 자리에서 새 Pick 을 더하고 이름 칸에 올린다([◀ AI 도우미로]·Esc 로 돌아온다)."""
        lf = self.open_library()
        try:
            return lf.add_item()
        except Exception:                                 # noqa: BLE001
            return None

    def _new_prompt(self, genre=None):
        """[+] — 빈 Pick 을 만들고 고치는 칸에 올린다."""
        with self._conn() as c:
            sc, tk = UA.pick_key(self._scope, self._task)      # ★ 317차-5 — 지금 업무에만
            pid = UA.add_prompt(c, self._lang(), sc,
                                T('AI_NEW_PROMPT_TITLE', '새 프롬프트'), '', genre=UA.PICK_GENRE, task=tk)
        self._load_prompts(keep=pid)
        self._tpl_title.focus_set()
        return pid

    def _del_prompt(self):
        p = self._cur_prompt()
        if not p:
            return
        self._edit_dirty = False
        with self._conn() as c:
            UA.hide_prompt(c, p[0], place=self._lib_place())
        self._edit = None
        self._load_prompts()
        self._edit_open(None)
        self._status.config(text=T('AI_PROMPT_DELETED', '프롬프트를 지웠습니다.'))

    # ── 보낼 글 — 고정 칸(보이는 것 = 보내는 것) ──────────────────────────
    def _in_touched(self, _e=None):
        try:
            if self._in_job:
                self.after_cancel(self._in_job)
        except Exception:                                 # noqa: BLE001
            pass
        self._in_job = self.after(400, self._paint_prompt)

    def _rq_touched(self, _e=None):
        """연구하자 입력창 — 고치면 결합 프롬프트와 요구사항 초안이 따라온다."""
        try:
            if self._in_job:
                self.after_cancel(self._in_job)
        except Exception:                                 # noqa: BLE001
            pass
        self._in_job = self.after(400, self._after_prompt)

    _place_over = None      # ★ 2026-10-21 도서노트 [AI 분석] — 묵상노트 분석 글 + 도서노트 분석 자리의 Pick(라이브러리 1:1)

    def _place_ov(self):
        return self._place_over if (self._place_over and self._scope == 'VERSE' and self._task == 'NOTE') else None

    def _lib_place(self):
        """지금 질문의 라이브러리 자리 — 도서노트에서 연 분석이면 `BOOK:NOTE`."""
        return self._place_ov() or UA.pick_place(self._scope, self._task)

    def _unit_key(self, mode=None):
        """직전값 단위 — Free · 갈래+업무(연구하자는 갈래까지)."""
        if self._scope == 'FREE':
            return 'FREE'
        if self._place_ov():
            return 'BOOK_NOTE'
        k = '%s_%s' % (self._scope, self._task or '')
        if self._task == 'RESEARCH':
            k += '_' + (mode or self._rm_var.get())
        return k

    def _save_unit(self, mode=None):
        """★ 317차-5 — 프롬프트 직전값을 단위마다 따로 적는다(사용자 「Free / 구절 설명문 /
        구절 성경공부 / … / 연구자료 단위별로 직전값을 따로 저장」)."""
        try:
            import json
            d = {'checked': list(self._checked)}
            m = mode or self._rm_var.get()
            if self._task == 'RESEARCH' and m in self._rq_ent:
                d['q'] = self._rq_ent[m].get()
            with self._conn() as c:
                UA.set_setting(c, 'AI_LAST_' + self._unit_key(mode), json.dumps(d, ensure_ascii=False))
        except Exception:                                 # noqa: BLE001
            pass

    def _restore_unit(self):
        """그 단위의 직전값을 되살린다 — 지금 Pick 목록에 있는 것만."""
        try:
            import json
            with self._conn() as c:
                raw = UA.get_setting(c, 'AI_LAST_' + self._unit_key(), '')
            d = json.loads(raw) if raw else {}
        except Exception:                                 # noqa: BLE001
            d = {}
        # ★ 2026-10-27 Pick 직전값은 되살리지 않는다(사용자) — 이 화면 안에서 고른 것만
        ids = {p[0] for p in (self._prompts or [])}
        self._checked = [x for x in (self._checked or []) if x in ids]
        m = self._rm_var.get()
        if self._task == 'RESEARCH' and m in self._rq_ent:
            e = self._rq_ent[m]
            e.delete(0, 'end')
            e.insert(0, d.get('q') or '')

    def _links_on(self):
        """설교 작성의 「관련 인용구절」 Pick 을 체크했나 — 체크하면 연결구절 목록이 재료로 간다."""
        if self._task != 'SERMON' or self._scope != 'VERSE':
            return False
        for pid in self._checked:
            p = self._cur_by_id(pid)
            if p and str(p[1] or '') == UA.LINK_PICK_KIND:
                return True
        return False

    def _picked_bodies(self):
        """체크한 Pick 글 — **선택한 차례**. 지금 고치는 칸의 글이 그 Pick 이면 그 글을 쓴다."""
        if self._task in UA.SOLO_TASKS:
            return []
        out = []
        cur = self._cur_prompt()
        edited = self._tpl_txt.get('1.0', 'end').strip() if cur else ''
        for pid in self._checked:
            p = self._cur_by_id(pid)
            if not p:
                continue
            # ★ 2026-10-24 (이름, 글) — 둘 이상이면 「1. [이름] 글」로 실어 답의 머리가 Pick 이름과 1:1 로 맞는다
            out.append((p[2] or '', edited if (cur and cur[0] == pid and edited) else (p[3] or '')))
        return out

    def _slot_rows(self, question=None):
        """지금 선택한 것으로 칸을 짓는다 — 자리표까지 채운 `[(칸, 머리말, 글)]`."""
        lang = self._lang()
        q = self._question() if question is None else question
        with self._conn() as c:
            role, task = UA.task_texts(c, self._scope, self._task, self._rm_var.get(), lang)
            tgt = getattr(self, '_edit', None)
            if tgt and self._edit_dirty and tgt[0] in ('TASK', 'ROLE'):
                ed = self._tpl_txt.get('1.0', 'end').strip()
                if tgt[0] == 'ROLE':
                    role = ed
                else:
                    task = ed
                    role = self._tpl_role.get('1.0', 'end').strip() or role
            parts = {}
            if tgt and self._edit_dirty and tgt[0] == 'PART' and tgt[1] not in ('FREE', 'BAN', 'FORMAT'):
                parts[tgt[1]] = self._tpl_txt.get('1.0', 'end').strip()
            free = ban = fmt = None
            if tgt and self._edit_dirty and tgt[0] == 'PART':
                ed = self._tpl_txt.get('1.0', 'end').strip()
                free = ed if tgt[1] == 'FREE' else None
                ban = ed if tgt[1] == 'BAN' else None
                fmt = ed if tgt[1] == 'FORMAT' else None
            rows = UA.compose_parts(c, task=task, role=role, question=q, picks=self._picked_bodies(),
                                    free=free, ban=ban, fmt=fmt, lang=lang, parts=parts or None)
            out = []
            groups = None
            if self._task == 'NOTE' and self._scope == 'VERSE' and self._start:
                groups = UA.note_groups(c, self._start, self._end, self.nscope_key(), lang)
            for s, h, v in rows:
                if v and s == 'TASK' and groups:
                    # ★ 317차-15 — [구절] = 노트가 있는 구절들 · 구절마다 따로 쓰라는 규칙(보이는 것 = 보내는 것)
                    v = UA.note_task_text(c, v, groups, lang)
                if v:
                    v = UA.fill_prompt(c, v, self._scope, self._start, self._end, self._eid, lang, self._ref)
                if self._task in UA.ROLE_TASKS and s in UA.ROLE_DROP_SLOTS:
                    v = ''                            # ★ 2026-10-21 분야 업무 — 제 꼴만
                out.append((s, h, v))
        return out

    def _question(self):
        """물음 칸 — Free 는 요구사항 · 연구하자(질문·이해 확인)는 그 입력창."""
        if self._scope == 'FREE':
            return self._in.get('1.0', 'end').strip()
        m = self._rm_var.get()
        if self._task == 'RESEARCH' and m in self._rq_ent:
            return (self._rq_ent[m].get() or '').strip()
        return ''

    def compose_text(self, question=None):
        """보낼 글 전문 — 칸 머리말을 붙이고 빈 칸은 뺀다(`UA.compose` 와 같은 꼴)."""
        return (chr(10) * 2).join('[%s]%s%s' % (h, chr(10), v) for _s, h, v in self._slot_rows(question) if v)

    def _attach_titles(self):
        """함께 보내는 자료의 **제목만**(3-4) — 재료 칸 이름 + 내 묵상노트 편수."""
        try:
            with self._conn() as c:
                if self._scope == 'FREE' or not self._has_anchor():
                    return []
                if self._scope == 'VERSE' and not self._start:
                    return [UA.WORD_MAT_NAME]
                if self._scope == 'REF':
                    mat = UA.materials_ref(c, self._ref, self._lang())
                elif self._scope == 'TERM':
                    mat = (UA.materials_lemma(c, self._lemma(), self._lang()) if self._lemma()
                           else UA.materials_term(c, self._eid, self._lang()))
                else:
                    mat = UA.materials(c, self._start, self._end, self._lang())
                out = list(mat.keys())
                if self._task == 'NOTE' and self._scope == 'VERSE':
                    gs = UA.note_groups(c, self._start, self._end, self.nscope_key(), self._lang())
                    out.append('%s (%d)' % (T('AI_NOTES_LBL', '내 묵상노트'), sum(len(g[2]) for g in gs)))
                if self._links_on():
                    out.append('%s (%d)' % (T('AI_LINKS_LBL', '연결구절'),
                                            UA.link_count_for(c, self._start, self._end, self._lang())))
                return out
        except Exception:                                 # noqa: BLE001
            return []

    def _paint_prompt(self):
        """[프롬프트] 갈래 — 고정 칸을 차례대로 · 빈 칸은 흐리게 「(없음)」."""
        self._in_job = None
        if getattr(self, '_view', 'CHAT') != 'PROMPT':
            return
        t = self._ptxt
        t.configure(state='normal')
        t.delete('1.0', 'end')
        follow = bool(self._chat_id and self.messages())
        none = T('AI_SLOT_NONE', '(없음)')
        for s, h, v in self._slot_rows():
            if follow and s != 'QUESTION':
                continue
            t.insert('end', '[%s]%s' % (h, chr(10)), 'h')
            t.insert('end', (v if v else none) + chr(10), 'v' if v else 'none')
        att = self._attach_titles()
        if att and not follow:
            t.insert('end', '[%s]%s' % (T('AI_ATTACH', '함께 보내는 자료'), chr(10)), 'h')
            t.insert('end', ' · '.join(att) + chr(10), 'att')
        t.configure(state='disabled')

    def _after_prompt(self):
        """창고가 바뀐 뒤 — 결합 화면을 다시 그리고 요구사항 초안을 맞춘다."""
        if self._task == 'NOTE':
            self._paint_note_badges()
        self._paint_prompt()
        self._sync_send_btn()
        self._draft()

    def _draft(self):
        """★ 구절·용어·연구자료 — 프롬프트를 선택하면 **결합된 프롬프트를 요구사항에** 보인다(고칠 수 있다).

        ⚠ 사람이 고친 글은 안 덮는다 — 비었거나 지난 자동 초안 그대로일 때만 바꾼다.
        ⚠ Free 는 요구사항에 직접 쓴다(초안 없음) · 채팅이 이미 이어지면 안 넣는다.
        """
        if self._scope == 'FREE' or self._th is not None:
            return
        if self._chat_id and self.messages():
            return
        try:
            cur = self._in.get('1.0', 'end').strip()
            if cur and cur != (self._draft_auto or '').strip():
                return
            new = self.compose_text()
            if new.strip() == cur:
                return
            self._in.delete('1.0', 'end')
            self._in.insert('1.0', new)
            self._draft_auto = new
        except Exception:                                 # noqa: BLE001
            pass

    def _clear_draft(self):
        """자동 초안만 걷는다(사람이 고친 글은 남긴다)."""
        try:
            cur = self._in.get('1.0', 'end').strip()
            if not cur or cur == (self._draft_auto or '').strip():
                self._in.delete('1.0', 'end')
        except Exception:                                 # noqa: BLE001
            pass
        self._draft_auto = ''

    def _set_draft(self, force=False):
        """옛 이름 — 이제 초안을 입력 칸에 넣지 않는다(보낼 글은 [프롬프트] 갈래가 보인다)."""
        self._after_prompt()

    def draft_text(self):
        """보낼 글(하네스가 읽는다)."""
        return self.compose_text()

    def prompt_body(self):
        return self.compose_text()

    def _sync_send_btn(self):
        teach = self._task == 'TEACH' and not (self._chat_id and self.messages())
        try:
            self._send_btn.config(text=T('AI_TEACH', '교사 시작') if teach else T('AI_SEND2', '전송'))
        except Exception:                                 # noqa: BLE001
            pass

    def _is_teach(self, _p=None):
        return self._task == 'TEACH'

    # ── 닻 ──────────────────────────────────────────────────────────
    def set_anchor(self, start_vid, end_vid=None):
        had_link = bool(self._link)
        self._link = None        # 구절을 옮기면 연결 닻은 풀린다
        if had_link:
            try:
                self._paint_tasks()          # 「연결 살펴보기」 업무를 걷는다
            except Exception:                             # noqa: BLE001
                pass
        self._start = int(start_vid) if start_vid else None
        self._end = int(end_vid) if end_vid else self._start
        self._chat_id = None
        if self._scope != 'VERSE':
            self.set_scope('VERSE')
            return
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        self._after_prompt()

    def set_lemma(self, strong):
        """★ 2026-10-14 승격 안 된 원어 낱말을 닻으로(용어 갈래 · 용어 업무 그대로) — 저장은 「원어 설명으로」."""
        self._eid = None
        self._ref = UA.LEMMA_PFX + str(strong)
        self._chat_id = None
        if self._scope != 'TERM':
            self.set_scope('TERM')
            self._ref = UA.LEMMA_PFX + str(strong)
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        self._after_prompt()

    def _lemma(self):
        """지금 닻이 원어 낱말이면 그 스트롱 번호 · 아니면 ''."""
        r = str(self._ref or '')
        return r[len(UA.LEMMA_PFX):] if self._scope == 'TERM' and r.startswith(UA.LEMMA_PFX) else ''

    def set_term(self, entity_id):
        if str(self._ref or '').startswith(UA.LEMMA_PFX):
            self._ref = None
        self._eid = int(entity_id) if entity_id else None
        self._chat_id = None
        if self._scope != 'TERM':
            self.set_scope('TERM')
            return
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        self._after_prompt()

    def set_ref(self, anchor):
        self._ref = str(anchor or '') or None
        self._chat_id = None
        if self._scope != 'REF':
            self.set_scope('REF')
            self._ref_task_follow()
            return
        if self._ref_task_follow():
            return
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        self._after_prompt()

    def _ref_task_follow(self):
        """★ 317차-16 — 연구/설교노트 닻의 갈래가 업무를 정한다(설교노트 → 설교 분석 · 그 밖 → 연구 분석).

        사람이 그 뒤에 업무를 바꾸면 그대로 둔다 — 닻을 새로 고를 때만 따라간다. 업무를 바꿨으면 True.
        """
        if self._scope != 'REF' or not self._ref:
            return False
        with self._conn() as c:
            want = UA.ref_task_of(c, self._ref)
        if want == self._task or self._task not in ('REFAN', 'SERMAN', 'BOOKMEDI'):
            return False
        self._pick_task(want)
        self._paint_anchor()
        self._load_chats()
        self._paint_transcript()
        return True

    def anchor(self):
        if self._scope == 'REF':
            return (self._ref, None)
        if self._scope == 'FREE':
            return (None, None)
        return (self._start, self._end) if self._scope == 'VERSE' else (self._eid, None)

    def _paint_anchor(self):
        self._paint_anchor_text()
        if hasattr(self, '_inl_v'):
            self._inline_sync()
        try:
            has = bool(self._anchor_lbl.cget('text')) and self._has_anchor() and self._scope != 'FREE'
            self._anchor_lbl.config(bg=_C('success_bg', '#D5F5E3') if has else self._bg)
        except Exception:                                 # noqa: BLE001
            pass

    def _paint_anchor_text(self):
        if self._scope == 'FREE':
            self._anchor_lbl.config(text='')
            self._show_x(False)
            return
        with self._conn() as c:
            if self._scope == 'REF':
                self._anchor_lbl.config(text=UA.ref_name(c, self._ref, self._lang()) if self._ref
                                        else T('AI_REF_NO_ANCHOR', '연구/설교노트를 먼저 선택하세요'))
                self._show_x(False)
                return
            if self._scope == 'TERM':
                self._anchor_lbl.config(text=UA.term_name(c, self._eid, self._lang()) if self._eid
                                        else UA.lemma_label(c, self._lemma()) if self._lemma()
                                        else T('AI_TERM_NO_ANCHOR', '주요용어를 먼저 선택하세요'))
                self._show_x(False)
                return
            if not self._start:
                self._anchor_lbl.config(text=T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                self._show_x(False)
                return
            self._anchor_lbl.config(text=UA.range_label(c, self._start, self._end, self._lang()))
        self._show_x(bool(self._end) and self._end != self._start)

    def _has_anchor(self):
        if self._scope == 'FREE':
            return True
        if self._scope == 'REF':
            return bool(self._ref)
        if self._scope == 'TERM':
            return bool(self._eid or self._lemma())
        # ★ 2026-10-31 말씀 그룹 — 구절이 없어도 내용 칸에 글이 있으면 된다
        return bool(self._start) or (self._task in UA.WORD_TASKS and bool(self.word_text()))

    # ── 채팅목록 ───────────────────────────────────────────────────────
    def set_chat_filter(self, key, _load=True):
        k = str(key or 'ALL').upper()
        if k not in [x[0] for x in CHAT_FILTERS]:
            k = 'ALL'
        self._cfilter = k
        for kk, b in self._cf_btn.items():
            b.configure(**_kw(kk == k))
        if _load:
            self._load_chats()

    def _task_label(self, kind):
        k = str(kind or '')
        if k.startswith('T:'):
            bits = k.split(':')
            if len(bits) > 2 and bits[1] == 'RESEARCH':      # 옛 채팅 — 갈래 이름만(질문 · 성경공부)
                return T('AI_T_' + ('STUDY' if bits[2] == 'STUDY' else 'ASK'), '성경공부' if bits[2] == 'STUDY' else '질문')
            return T('AI_T_' + bits[1], bits[1]) if len(bits) > 1 else k
        if k == 'FREE':
            return T('AI_FREE_BTN', 'Free')
        return (getattr(self, '_kl', {}).get(k) or k or '?').split(' (')[0]

    def _load_chats(self):
        self._list.delete(0, 'end')
        self._list_ids = []
        f = getattr(self, '_cfilter', 'ALL')
        with self._conn() as c:
            rows = UA.chats_for(c, limit=200, scope=(None if f == 'ALL' else f))
            kl = {}
            for sc in ('VERSE', 'TERM', 'REF'):
                for row in UA.prompts(c, self._lang(), sc):
                    kl.setdefault(row[1], row[2])
            self._kl = kl
            # ★ 317차-8 — 「통합」 꼬리표(이어지는 대화인지 통합 자료가 있는지 목록에서 갈린다)
            integ_ids = {r[0] for r in c.execute("SELECT DISTINCT chat_id FROM user_ai_msg WHERE mkind='INTEG'")}
            here = set()
            if f in ('VERSE', 'ALL') and self._scope == 'VERSE' and self._start:
                # ★ 2026-10-16 — P4 「AI (n)」 배지와 같은 문(그 절을 덮는 채팅 · 업무 무관)
                here = {r[0] for r in UA.chats_covering(c, self._start, limit=200)}
                here |= {r[0] for r in UA.chats_for(c, self._start, self._end, limit=200)}
            elif f == 'TERM' and self._eid:
                here = {r[0] for r in UA.chats_for(c, entity_id=self._eid, limit=200)}
            elif f == 'REF' and self._ref:
                here = {r[0] for r in UA.chats_for(c, ref_anchor=self._ref, limit=200)}
        # ★ 지금 자리의 채팅이 맨 위(진하게) — 그다음 나머지
        rows = [r for r in rows if r[0] in here] + [r for r in rows if r[0] not in here]
        for row in rows:
            cid, title, _s, _e, upd, n = row[:6]
            kind = row[6] if len(row) > 6 else ''
            self._list.insert('end', '%s · %s · %d · %s%s'
                              % (title or '?', self._task_label(kind), n, (upd or '')[:10],
                                 (' · ' + T('AI_ST_INTEG_TAG', '통합')) if cid in integ_ids else ''))
            if cid in here:
                self._list.itemconfig('end', foreground=_C('accent', '#1A5276'))
            self._list_ids.append(cid)
        if self._chat_id in self._list_ids:
            self._list.selection_set(self._list_ids.index(self._chat_id))

    def _pick_chat(self):
        sel = self._list.curselection()
        if not sel:
            return
        self._chat_id = self._list_ids[sel[0]]
        with self._conn() as c:
            ch = UA.chat(c, self._chat_id)
        if ch:
            sc = ch.get('scope') or 'VERSE'
            sc = sc if sc in SCOPES else 'VERSE'
            moved = sc != self._scope
            self._scope = sc
            if sc == 'TERM':
                self._eid = ch['entity_id']
                if str(ch.get('ref_anchor') or '').startswith(UA.LEMMA_PFX):
                    self._ref = ch.get('ref_anchor')
            elif sc == 'REF':
                self._ref = ch.get('ref_anchor')
            elif sc == 'VERSE':
                self._start, self._end = ch['start_vid'], ch['end_vid']
                # ★ 연결 닻 채팅을 다시 열면 연결 닻도 돌아온다
                self._link = ch.get('ref_anchor') if str(ch.get('ref_anchor') or '').startswith(UA.LINK_PFX) else None
            self._paint_groups()
            self._paint_anchor()
            if moved:
                self._load_prompts()
        self._paint_transcript()
        self._after_prompt()
        self.set_view('CHAT')
        # ★ 2026-10-21 채팅목록을 누르면 가운데에 그 대화(통합화면은 [대화통합화면]을 누를 때만)
        self._sync_save_btn()

    def _new_chat(self):
        """새 채팅 — **이전 프롬프트 세팅을 바꾸고 새롭게 진행한다**(사용자 정의).

        앞 채팅을 놓고 요구사항을 비운 뒤 지금 창고 세팅으로 초안을 다시 짓는다 · 가운데는
        결합 프롬프트(조회) 또는 수정 화면 — 세팅을 고치고 [채팅 보내기]를 누르면 그 결합
        내용이 채팅 내용에 그대로 나간다.
        """
        self._role_ask = ''                  # 분야 묻기는 그 채팅 하나에만(ask_role_now 가 다시 건다)
        self._edit_save()
        self._chat_id = None
        self._last_merge = False
        self._merge_body = ''
        try:
            self._smode_var.set('ALL')
            self._sync_smode()
            self._show_open(None)
        except Exception:                                 # noqa: BLE001
            pass
        self._list.selection_clear(0, 'end')
        try:
            self._in.delete('1.0', 'end')
        except Exception:                                 # noqa: BLE001
            pass
        self._draft_auto = ''
        self._paint_transcript()
        self._paint_chat_title()
        self._status.config(text=T('AI_NEWCHAT2', '새 채팅'))
        self._after_prompt()
        self.set_view('CHAT' if self._mode == 'VIEW' else 'EDIT')
        try:
            self._in.focus_set()
        except Exception:                                 # noqa: BLE001
            pass

    def _del_chat(self):
        if not self._chat_id:
            return
        # ★ 2026-10-22 숨기기 → 휴지통(대화 정리와 같은 문) — 숨기면 폰에 전해지지 않고, 폰이 이어 쓰면 되살아났다
        with self._conn() as c:
            ACS.trash(c, [self._chat_id])
        self._chat_id = None
        self._load_chats()
        self._paint_transcript()
        self._changed()
        self._status.config(text=T('AI_TRASHED_SYNC', '휴지통으로 옮겼습니다 — 다음 동기화 때 폰에서도 휴지통으로 옮겨집니다. '
                                   '30일 안에 되살릴 수 있습니다.'))

    on_changed = None        # 채팅이 늘거나 줄면(호스트가 P4 「AI (n)」 배지를 다시 센다)

    def _changed(self):
        if callable(self.on_changed):
            try:
                self.on_changed()
            except Exception as e:                        # noqa: BLE001
                print('[ai changed] %s' % e)

    def _ask_free_ctx(self):
        """업무 없이 보낼 때 — True 이 자리와 이어서 · False 자유롭게 · None 그만(창 닫기)."""
        if getattr(self, 'free_answer', None) is not None:   # 시험·자동화가 미리 정해 둔 답(창을 띄우지 않는다)
            return self.free_answer
        name = ''
        try:
            name = self._anchor_lbl.cget('text')
        except Exception:                                 # noqa: BLE001
            name = ''
        name = name or (self.chat_title() or '')
        win = tk.Toplevel(self)
        win.title(T('M_AI_FREE_ASK', '어떤 답을 원하세요?'))
        win.transient(self.winfo_toplevel())
        win.resizable(False, False)
        res = {'v': None}

        def pick(v):
            res['v'] = v
            win.destroy()
        tk.Label(win, text=T('M_AI_FREE_ASK', '어떤 답을 원하세요?'), font=self._std_font(), padx=14, pady=8).pack(anchor='w')
        tk.Button(win, text=T('M_AI_FREE_CTX', '「%s」와 이어서 답하기').replace('%s', name), font=self._std_font(),
                  command=lambda: pick(True)).pack(fill='x', padx=14, pady=2)
        tk.Button(win, text=T('M_AI_FREE_ANY', '상관없이 자유롭게 답하기'), font=self._std_font(),
                  command=lambda: pick(False)).pack(fill='x', padx=14, pady=(2, 12))
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        win.grab_set()
        self.wait_window(win)
        return res['v']

    def _chat_kind(self):
        if self._scope == 'FREE' or getattr(self, '_free_once', False):
            return 'FREE'
        if not self._task:
            return 'T:FREE'                          # ★ 2026-10-27 업무 없이 「이 자리와 이어서」 보낸 물음
        if self._task == 'RESEARCH':
            return 'T:RESEARCH:%s' % self._rm_var.get()
        if self._place_ov():                     # ★ 2026-10-21 도서노트 분석 — 채팅목록 「도서」 갈래
            return 'T:%s:BOOK' % self._task
        return 'T:%s' % self._task

    def prompt_text(self):
        """[프롬프트 복사]가 복사하는 글 — 보낼 때와 같은 문(user_ai.copy_prompt)."""
        self._commit_ime(self._in)
        q = self._in.get('1.0', 'end').strip()
        teach = self._task == 'TEACH' and self._scope != 'FREE'
        if self._scope == 'FREE':
            user, body = self.compose_text(question=q), ''
        elif teach:
            user, body = '', self._word_prefix(q or self.compose_text())
        else:
            user, body = self._word_prefix(q or self.compose_text()), ''
        anchor = self._ref if (self._scope == 'REF' or (self._scope == 'TERM' and self._lemma())) else (self._link or None)
        ch = {'scope': self._scope, 'start_vid': self._start, 'end_vid': self._end, 'entity_id': self._eid,
              'lang': self._lang(), 'ref_anchor': anchor}
        with self._conn() as c:
            return UA.copy_prompt(c, ch, user, body, with_notes=self._task == 'NOTE' and self._scope == 'VERSE',
                                  notes_scope=self.nscope_key(), with_links=self._links_on(), teach=teach)

    def copy_prompt(self):
        if self._scope != 'FREE' and not self._has_anchor():
            self._status.config(text=T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
            return ''
        txt = self.prompt_text()
        try:
            self.clipboard_clear()
            self.clipboard_append(txt)
        except Exception:                                 # noqa: BLE001
            pass
        self._status.config(text=T('AI_COPIED_PROMPT', '프롬프트를 복사했습니다(%d자) — AI 브라우저 대화창에 붙여 넣으세요.') % len(txt))
        return txt

    def _ensure_chat(self):
        if self._chat_id:
            return self._chat_id
        if not self._has_anchor():
            return None
        with self._conn() as c:
            k = self._chat_kind()
            if self._scope == 'FREE' or getattr(self, '_free_once', False):
                self._free_once = False              # ★ 2026-10-27 「상관없이 자유롭게」 — 닻 없는 대화 한 번
                self._chat_id = UA.new_chat(c, lang=self._lang(), kind=k, free=True)
            elif self._scope == 'REF':
                self._chat_id = UA.new_chat(c, lang=self._lang(), kind=k, ref_anchor=self._ref)
            elif self._scope == 'TERM' and self._lemma():
                self._chat_id = UA.new_chat(c, lang=self._lang(), kind=k, ref_anchor=self._ref)
            elif self._scope == 'TERM':
                self._chat_id = UA.new_chat(c, entity_id=self._eid, lang=self._lang(), kind=k)
            elif self._link:
                self._chat_id = UA.new_chat(c, self._start, self._end, self._lang(), kind=k, ref_anchor=self._link)
            elif not self._start:
                self._chat_id = UA.new_chat(c, None, None, self._lang(), title=T('M_AIW_TEXT_TITLE', UA.WORD_MAT_NAME), kind=k)
            else:
                self._chat_id = UA.new_chat(c, self._start, self._end, self._lang(), kind=k)
            t = self.chat_title()
            if t:
                c.execute("UPDATE user_ai_chat SET title=? WHERE chat_id=?", (t, self._chat_id))
                c.commit()
        self._load_chats()
        return self._chat_id

    # ── 대화 글 ─────────────────────────────────────────────────────
    on_book_note = None      # (unit_id, 글) → 도서노트로 저장(호스트 — 도서 화면의 노트 문을 쓴다)

    def _book_unit(self):
        """도서 편 닻이면 그 편 번호."""
        k, rid = UA.ref_split(self._ref) if (self._scope == 'REF' and self._ref) else (None, None)
        return rid if k == 'BOOK_UNIT' else None

    @staticmethod
    def next_questions(text):
        """AI 답 끝의 「▷ 」 줄 → 다음 질문 목록(최대 3) — 형식을 안 지켰으면 빈 목록(단추만 안 생긴다)."""
        return UA.split_next(text)[1]

    def _last_ai(self):
        for role, body in reversed(self.messages()):
            if role == 'ai':
                return body or ''
        return ''

    def suggestions(self):
        """지금 채팅 마지막 AI 답의 제안 질문(1·2·3 차례)."""
        return self.next_questions(self._last_ai()) if self._chat_id else []

    def _unpicked(self):
        """아직 선택하지 않은 Pick — `[(제목, 채운 글)]`."""
        out = []
        try:
            with self._conn() as c:
                for p in self._prompts:
                    if p[0] in self._checked or not (p[3] or '').strip():
                        continue
                    out.append((p[2] or '', UA.fill_prompt(c, p[3], self._scope, self._start, self._end,
                                                           self._eid, self._lang(), self._ref)))
        except Exception:                                 # noqa: BLE001
            pass
        return out

    def _fu_add(self, text, title=''):
        """이어서 묻기 항목 — 요구사항 칸 끝에 덧붙인다(여럿 고른 뒤 [전송]).
        ★ 2026-10-24 둘 이상 고르면 「1. [이름] 글」 + 항목별로 답하라는 한 줄로 다시 짓는다(Pick 칸과 같은 문 `UA.each_block`) —
          칸에 보이는 것이 곧 보내는 것이다. 사람이 그 덩어리를 지웠으면 새로 시작한다."""
        try:
            cur = self._in.get('1.0', 'end').strip()
            if cur == (getattr(self, '_draft_auto', '') or '').strip():
                self._in.delete('1.0', 'end')
                cur = ''
            items = list(getattr(self, '_fu_items', []) or [])
            block = getattr(self, '_fu_block', '') or ''
            if not (block and block in cur):
                items, block = [], ''
            items.append((title, text))
            new = UA.each_block(items, self._lang())
            if block:
                cur = cur.replace(block, new)
            else:
                cur = (cur + chr(10) if cur else '') + new
            self._in.delete('1.0', 'end')
            self._in.insert('1.0', cur)
            self._fu_items, self._fu_block = items, new
            self._in.see('end')
            self._in.focus_set()
        except Exception:                                 # noqa: BLE001
            pass

    def _fu_build(self):
        """[방향 바꾸기 ▾][더 깊이 ▾][아직 선택하지 않은 Pick ▾] — 메뉴는 만들기만(띄우는 것은 단추)."""
        r = self._fu_row
        for w in r.winfo_children():
            w.destroy()
        self._fu_menus = {}
        groups = [(g, T('AI_FU_' + g, {'TURN': '방향 바꾸기', 'DEEP': '더 깊이'}[g]),
                   [(t, b) for _k, t, b in UA.follow_items(self._lang())[g]]) for g in UA.FOLLOW_GROUPS]
        up = self._unpicked()
        if up:
            groups.append(('PICK', T('AI_FU_PICK', '아직 선택하지 않은 Pick'), up))
        line = None
        for g, name, items in groups:
            if g == 'PICK' or line is None:              # ★ 2026-10-21 왼쪽 좁은 칸 — Pick 메뉴는 제 줄
                line = tk.Frame(r, bg=self._bg)
                line.pack(fill='x')
            mb = tk.Menubutton(line, text=' %s ▾ ' % name, relief='flat', bg=self._bg,
                               fg=_C('fg_title', '#2C3E50'), activebackground=_C('panel_alt', '#EAF2FB'))
            m = tk.Menu(mb, tearoff=0)
            for title, body in items:
                m.add_command(label=title, command=lambda b=body, t=title: self._fu_add(b, t))
            mb.configure(menu=m)
            mb.pack(side='left', padx=(0, 4))
            self._fu_menus[g] = m

    def _sync_book_bar(self):
        """도서 묵상 띠를 지금 닻·대화에 맞춘다(도서 편 닻 + 도서 묵상 업무일 때만)."""
        uid = self._book_unit()
        book = bool(uid) and self._task == 'BOOKMEDI'
        last = self._last_ai() if self._chat_id else ''
        follow = bool(last) and self._th is None and self._task != 'TEACH'
        f = self._bm_f
        self._fu_show = bool(book or follow)
        if not (book or follow):
            self._relayout_left()
            return
        lang = self._lang()
        if book:
            if not self._bm_stage.winfo_manager():
                self._bm_stage.pack(fill='x', before=self._bm_next)
        elif self._bm_stage.winfo_manager():
            self._bm_stage.pack_forget()
            self._bm_key = None
        if follow:
            if not self._fu_row.winfo_manager():
                self._fu_row.pack(fill='x')
            fk = (lang, self._scope, self._task, tuple(self._checked), tuple(p[0] for p in self._prompts))
            if self._fu_key != fk:
                self._fu_key = fk
                self._fu_build()
        elif self._fu_row.winfo_manager():
            self._fu_row.pack_forget()
        if book and self._bm_key != (uid, lang):
            self._bm_key = (uid, lang)
            for w in self._bm_stage.winfo_children():
                w.destroy()
            with self._conn() as c:
                rows = UA.pick_prompts(c, lang, 'REF', 'BOOKMEDI')
            for r in rows:
                title, body = r[2] or '', r[3] or ''
                _btn(self._bm_stage, title, lambda b=body: self._book_stage(b), anchor='w').pack(fill='x', padx=2, pady=1)
            _btn(self._bm_stage, T('AI_BM_SAVE', '묵상 기록을 도서노트로'), self._book_save_note, anchor='w').pack(fill='x', padx=2, pady=(1, 4))
        for w in self._bm_next.winfo_children():
            w.destroy()
        qs = self.next_questions(last) if self._th is None else []
        if qs:
            # ★ 2026-10-16 사용자 「AI가 질문할 때 사용자는 1,2,3 형식으로 쉽게 선택」 — 번호 단추(누르면 곧바로)
            #   · 요구사항에 숫자 하나만 적어도 그 질문(`_send`)
            tk.Label(self._bm_next, text=T('AI_FU_SUGGEST', 'AI 제안:'), bg=self._bg, anchor='w',
                     fg=_C('fg_dim', '#7F8C8D')).pack(fill='x', padx=2)
            wrap = max(120, getattr(self, '_wrap_used', 220))
            for i, q in enumerate(qs, 1):
                b = _btn(self._bm_next, '%d. %s' % (i, q), lambda t=q: self._book_stage(self._fu_ask(t)), anchor='w')
                b.configure(justify='left', wraplength=wrap)
                b.pack(fill='x', padx=2, pady=1)
        try:
            ui_theme.paint(f)
        except Exception:                                 # noqa: BLE001
            pass
        self._relayout_left()

    @staticmethod
    def _fu_ask(q):
        """AI 제안(「…을 더 설명해 드릴까요?」)을 누르면 — 그 제안을 받아 이어서 설명해 달라는 내 말로 보낸다."""
        return T('AI_FU_SEND', '이어서 설명해 주세요: %s') % q

    def _book_stage(self, text):
        """단계·다음 질문 단추 — 첫 말이면 결합 프롬프트로 열고, 아니면 그 글을 곧바로 보낸다."""
        if self._th is not None:
            return
        if not (self._chat_id and self.messages()):
            self._send()
            return
        self._send(raw=text)

    def ask_book_now(self, unit_id):
        """도서 화면 [AI 묵상] — 그 편을 닻으로 새 채팅을 열고 **첫 걸음을 곧바로 보낸다**(81)."""
        if not unit_id:
            return
        self.set_ref('BOOK_UNIT:%d' % int(unit_id))
        if self._task != 'BOOKMEDI':
            self._pick_task('BOOKMEDI')
        self._new_chat()
        try:
            self._in.delete('1.0', 'end')
            txt = self.compose_text()
            self._in.insert('1.0', txt)
            self._draft_auto = txt
        except Exception:                                 # noqa: BLE001
            pass
        self._send()

    def _book_save_note(self):
        uid = self._book_unit()
        if not uid:
            return
        txt = ''
        for role, body in reversed(self.messages()):
            if role == 'ai':
                txt = body or ''
                break
        # 다음 질문 줄(▷)은 기록에 안 남긴다
        txt = chr(10).join(ln for ln in txt.splitlines() if not ln.strip().startswith("▷")).strip()
        if not txt:
            self._status.config(text=T('AI_BM_NOTHING', '저장할 AI 답이 없습니다 — [요약]을 누른 뒤 저장하세요.'))
            return
        ok = False
        if callable(self.on_book_note):
            try:
                ok = bool(self.on_book_note(uid, txt))
            except Exception as e:                        # noqa: BLE001
                print('[book note] %s' % e)
        self._status.config(text=T('AI_BM_SAVED', '마지막 답을 이 편의 도서노트로 저장했습니다.') if ok
                            else T('AI_BM_FAIL', '도서노트로 저장하지 못했습니다.'))

    def _sync_share(self):
        try:
            on = False
            if self._chat_id:
                with self._conn() as c:
                    ACS.init(c)
                    r = c.execute("SELECT COALESCE(share,0) FROM user_ai_chat WHERE chat_id=?", (self._chat_id,)).fetchone()
                    on = bool(r and r[0])
            self._share_var.set(on)
            self._share_chk.configure(state='normal' if self._chat_id else 'disabled')
        except Exception:                                 # noqa: BLE001
            pass

    def _share_click(self):
        if not self._chat_id:
            self._share_var.set(False)
            return
        on = bool(self._share_var.get())
        with self._conn() as c:
            ACS.set_share(c, self._chat_id, on)
        self._status.config(text=T('AI_SHARE_ON', '이 대화는 다음 동기화 때 폰과 주고받습니다') if on
                            else T('AI_SHARE_OFF', '이 대화는 이제 폰과 주고받지 않습니다'))

    def _open_clean(self):
        """대화 정리 — 기간(○개월 이전) · 저장하지 않은 대화만 → [휴지통으로] / 휴지통 · 되살리기 · 비우기.
        일회성 관리 창이라 팝업(설정 팝업과 같은 문법 · 단추는 위)."""
        if self._clean_win is not None:
            try:
                if self._clean_win.winfo_exists():
                    self._clean_win.lift()
                    return
            except Exception:                             # noqa: BLE001
                pass
        win = tk.Toplevel(self)
        self._clean_win = win
        win.title(T('AI_CLEAN', '대화 정리'))
        win.transient(self.winfo_toplevel())
        win.geometry('620x520')
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        bg = self._bg
        win.configure(bg=bg)
        top = tk.Frame(win, bg=bg)
        top.pack(fill='x', padx=8, pady=(8, 2))
        months = tk.IntVar(value=6)
        unsaved = tk.BooleanVar(value=True)
        mode = tk.StringVar(value='CLEAN')
        tk.Label(top, text=T('AI_CLEAN_OLDER', '마지막 대화가'), bg=bg).pack(side='left')
        mcb = ttk.Combobox(top, state='readonly', width=10,
                           values=[T('AI_CLEAN_MONTHS', '%d개월 이전') % m for m in (1, 3, 6, 12)])
        mcb.current(2)
        mcb.pack(side='left', padx=(4, 8))
        tk.Checkbutton(top, text=T('AI_CLEAN_UNSAVED', '저장하지 않은 대화만'), variable=unsaved, bg=bg,
                       command=lambda: fill()).pack(side='left')
        bar = tk.Frame(win, bg=bg)
        bar.pack(fill='x', padx=8, pady=(2, 2))
        go = _btn(bar, T('AI_CLEAN_GO', '휴지통으로'), lambda: act())
        go.pack(side='left')
        sw = _btn(bar, '', lambda: switch())
        sw.pack(side='left', padx=(6, 0))
        _btn(bar, T('AI_CLOSE', '닫기'), win.destroy).pack(side='right')
        info = tk.Label(win, text='', bg=bg, fg=_C('accent', '#1A5276'), anchor='w', justify='left', wraplength=580)
        info.pack(fill='x', padx=8)
        lf = tk.Frame(win, bg=bg)
        lf.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        lb = tk.Listbox(lf, activestyle='none', selectmode='extended')
        sb = ttk.Scrollbar(lf, orient='vertical', command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        lb.pack(fill='both', expand=True)
        rows = []
        arm = {'empty': False}
        say = {'t': ''}

        def kb(chars):
            b = chars * 3
            return '%dKB' % max(1, -(-b // 1024)) if b < 1048576 else '%.1fMB' % (b / 1048576)

        def fill():
            m = (1, 3, 6, 12)[max(0, mcb.current())]
            with self._conn() as c:
                ACS.purge(c)
                cur = ACS.candidates(c, m, bool(unsaved.get())) if mode.get() == 'CLEAN' else ACS.trashed(c)
            rows[:] = cur
            lb.delete(0, 'end')
            for cid, t, at, n in cur:
                lb.insert('end', '%s   ·   %s   ·   %s' % (t or '#%d' % cid, (at or '')[:10], kb(n)))
            tot = kb(sum(x[3] for x in cur)) if cur else '0KB'
            if mode.get() == 'CLEAN':
                go.configure(text=T('AI_CLEAN_GO', '휴지통으로'), state='normal' if cur else 'disabled')
                sw.configure(text=T('AI_TRASH', '휴지통') + ' ▸')
                txt = T('AI_CLEAN_FOUND', '해당하는 대화 %d개 · 약 %s') % (len(cur), tot)
            else:
                go.configure(text=T('AI_TRASH_RESTORE', '되살리기') + T('AI_TRASH_SEL', ' (목록에서 선택한 것)'),
                             state='normal' if cur else 'disabled')
                sw.configure(text='◂ ' + T('AI_CLEAN', '대화 정리'))
                txt = (T('AI_TRASH_NOTE', '휴지통에 들어간 지 30일이 지나면 저절로 완전히 지웁니다.')
                       + '  ' + T('AI_TRASH_N', '휴지통 %d개') % len(cur))
                if cur:
                    txt += '  ·  ' + (T('AI_TRASH_EMPTY_ASK2', '한 번 더 누르면 비웁니다(되살릴 수 없습니다) — '
                                        '이 PC 에서만 지웁니다 · 폰은 제 휴지통에서 30일 뒤에 지웁니다')
                                      if arm['empty'] else '')
            info.configure(text=(say['t'] + '\n' if say['t'] else '') + txt)
            mcb.configure(state='readonly' if mode.get() == 'CLEAN' else 'disabled')

        def act():
            say['t'] = ''
            with self._conn() as c:
                if mode.get() == 'CLEAN':
                    n = ACS.trash(c, [x[0] for x in rows])
                    say['t'] = T('AI_CLEAN_DONE2', '%d개를 휴지통으로 옮겼습니다 — 다음 동기화 때 폰에서도 휴지통으로 옮겨집니다. '
                                 '30일 안에 되살릴 수 있습니다.') % n
                else:
                    sel = [rows[i][0] for i in lb.curselection()]
                    if not sel:
                        say['t'] = T('AI_TRASH_PICK', '되살릴 대화를 목록에서 선택하세요.')
                    else:
                        n = ACS.restore(c, sel)
                        say['t'] = T('AI_TRASH_BACK2', '%d개를 되살렸습니다 — 다음 동기화 때 폰에서도 되살아납니다.') % n
            fill()
            self._load_chats()
            self._changed()

        def switch():
            arm['empty'] = False
            say['t'] = ''
            mode.set('TRASH' if mode.get() == 'CLEAN' else 'CLEAN')
            emp.pack_forget()
            if mode.get() == 'TRASH':
                emp.pack(side='left', padx=(6, 0), after=sw)
            fill()

        def empty():
            if not arm['empty']:
                arm['empty'] = True
                fill()
                return
            with self._conn() as c:
                n = ACS.purge(c, ids=[x[0] for x in rows])
            arm['empty'] = False
            say['t'] = T('AI_TRASH_EMPTIED2', '이 PC 휴지통의 대화 %d개를 완전히 지웠습니다(폰은 제 휴지통에서 30일 뒤에).') % n
            fill()

        emp = _btn(bar, T('AI_TRASH_EMPTY', '지금 휴지통 비우기'), empty)
        mcb.bind('<<ComboboxSelected>>', lambda _e: fill())
        win._clean_fill = fill            # 시험용
        win._clean_act = act
        win._clean_switch = switch
        win._clean_rows = rows
        fill()

    def _paint_transcript(self):
        self._paint_chat_title()
        self._sync_share()
        try:
            self._sync_book_bar()
        except Exception as e:                            # noqa: BLE001
            print('[book bar] %s' % e)
        self._sync_cmp_btn()          # ★ 317차-6 — [답 비교] 는 답이 있을 때만
        self._retag_fonts()
        self._relayout_left()         # ★ 2026-10-21 단계(첫 질문 · 이어서 묻기)가 바뀌었을 수 있다
        t = self._out
        t.configure(state='normal')
        t.delete('1.0', 'end')
        if self._chat_id:
            with self._conn() as c:
                rows = UA.msg_rows(c, self._chat_id)
            me, ai = T('AI_ME', '나'), T('AI_AI', 'AI')
            _rl = self._rule_line()
            att = ''
            # ★ 317차-8 — 그 AI 에게만 간 말 · 통합본은 이름표로 갈라 보인다(섞여 읽히지 않게)
            _mk = {'INTEG': T('AI_INTEG_COL', '통합본'), 'SELF': T('AI_SELF_DONE', '대화 통합본')}
            for m in rows:
                role, body, model = m['role'], m['body'] or '', m['model']
                if role == 'user' and m['target']:
                    me_l = '%s → %s' % (me, m['target'].split('|', 1)[-1])
                else:
                    me_l = me
                if role == 'ai' and m['mkind'] in _mk:
                    model = (model + ' · ' if model else '') + _mk[m['mkind']]
                if role == 'system' and (body or '').startswith(ATT_MARK):
                    att = body[len(ATT_MARK):]
                    continue
                if role == 'user':
                    t.insert('end', '%s%s' % (me_l, chr(10)), 'me')
                    t.insert('end', body + chr(10), 'qbody')
                    if att:
                        t.insert('end', '[%s] %s%s' % (T('AI_ATTACH', '함께 보내는 자료'), att, chr(10)), 'sys')
                        att = ''
                    t.insert('end', _rl + chr(10), 'rule')
                elif role == 'ai':
                    t.insert('end', '%s%s%s' % (ai, (' · ' + model) if model else '', chr(10)), 'h')
                    if m.get('verify') == 'FAIL':
                        # ★ 2026-10-15 사용자 「검증하지 못한 답변 원본이라고 말하고 보여주면 된다.
                        #   그리고 다시 검증을 시도할 기회를 주어라」
                        t.insert('end', '⚠ ' + T('AI_VFAIL', '검증하지 못한 답변 원본입니다') + '  ', 'vfail')
                        self._vfail_btn(t, m['msg_id'])
                        t.insert('end', chr(10), 'vfail')
                    _bd, _qs = UA.split_next(body)
                    t.insert('end', _bd + chr(10), 'ai')   # ★ 2026-10-21 제안 질문은 왼쪽 「이어서 묻기」에
                else:
                    t.insert('end', body + chr(10), 'sys')
        else:
            t.insert('end', T('AI_EMPTY2', '구절·용어·연구/설교노트를 선택하거나 Free 로 두고, 요구사항을 적어 [전송]을 누르면 AI가 답합니다.'), 'sys')
        if self._th is not None:
            if self._pending_user:
                t.insert('end', '%s%s' % (T('AI_ME', '나'), chr(10)), 'me')
                t.insert('end', self._pending_user + chr(10), 'qbody')
                if getattr(self, '_pending_att', ''):
                    t.insert('end', '[%s] %s%s' % (T('AI_ATTACH', '함께 보내는 자료'), self._pending_att, chr(10)), 'sys')
                t.insert('end', self._rule_line() + chr(10), 'rule')
            t.insert('end', T('AI_WAIT_LINE', '… %s 에 보냈습니다. 답을 기다리는 중입니다.') % self._sent_to + chr(10), 'sys')
            if getattr(self, '_sent_vmode', 'SAVE') == 'ALWAYS':
                t.insert('end', T('AI_WAIT_VERIFY', '답이 오면 같은 AI 로 한 번 더 검증한 뒤에 보여 드립니다.') + chr(10), 'sys')
        t.configure(state='disabled')
        t.see('end')

    def _vfail_btn(self, t, msg_id):
        """[다시 검증] — 대화 글 안에 심는다(그 답 바로 위)."""
        busy = msg_id in getattr(self, '_reverifying', set())
        b = tk.Button(t, text=T('AI_REVERIFY_ING', '검증하는 중…') if busy else T('AI_REVERIFY', '다시 검증'),
                      relief='groove', bd=1, padx=6, pady=0, cursor='hand2',
                      bg=_C('panel', '#F4F6F7'), fg=_C('fg', '#1B2631'),
                      activebackground=_C('select_bg', '#D6EAF8'),
                      state='disabled' if busy else 'normal',
                      command=lambda: self._reverify(msg_id))
        t.window_create('end', window=b)

    def _reverify(self, msg_id):
        """검증을 다시 시도한다(망을 쓰므로 일꾼 스레드 · 끝나면 다시 그린다)."""
        rs = getattr(self, '_reverifying', None)
        if rs is None:
            rs = self._reverifying = set()
        if msg_id in rs:
            return
        rs.add(msg_id)
        q = queue.Queue()
        self._status.config(text=T('AI_REVERIFY_ING', '검증하는 중…'))
        self._paint_transcript()

        def _work():
            try:
                with appdb.connect(self.db_path) as c2:
                    r = UA.reverify(c2, msg_id)
            except Exception as e:                        # noqa: BLE001
                r = {'state': 'FAIL', 'why': str(e)}
            q.put(r)

        def _poll():
            try:
                r = q.get_nowait()
            except queue.Empty:
                try:
                    self.after(200, _poll)
                except Exception:                         # noqa: BLE001
                    pass
                return
            rs.discard(msg_id)
            ok = r.get('state') in ('OK', 'SKIP')
            try:
                self._status.config(text=T('AI_REVERIFY_OK', '검증했습니다 — 완성본으로 바꿨습니다.') if ok
                                    else T('AI_REVERIFY_FAIL', '이번에도 검증하지 못했습니다 — 잠시 뒤 다시 누르세요.'))
                self._paint_transcript()
            except Exception:                             # noqa: BLE001
                pass

        threading.Thread(target=_work, daemon=True).start()
        self.after(200, _poll)

    # ── 보내기 ───────────────────────────────────────────────────────
    def _send(self, teach=False, raw=None):
        """보낸다 — 첫 말은 **고정 칸 전문**, 이어지는 말은 요구사항만.

        ★ 성경교사(첫 말)는 칸 전문을 **시스템 지시**로 싣고 AI 가 먼저 묻는다.
        ★ 묵상노트 분석만 내 묵상노트를 싣는다(개인 글이 밖으로 나가는 문 · 업무가 정한다).
        """
        self._edit_save()
        if self._th is not None:
            return
        q = self._in.get('1.0', 'end').strip()
        with self._conn() as c:
            en = UA.enabled_accounts(c)
        if not en:
            self._status.config(text=T('AI_NO_ACCOUNT', '⚠ 체크된 AI 계정이 없습니다 — [설정]에서 키를 넣고 [사용]을 체크하세요.'))
            self._open_settings()
            return
        if not self._has_anchor():
            self._status.config(text=T('AI_TERM_NO_ANCHOR', '주요용어를 먼저 선택하세요') if self._scope == 'TERM'
                                else T('M_AIW_NEED', '구절이나 내용을 먼저 넣어 주세요.') if self._scope == 'VERSE' and self._task in UA.WORD_TASKS
                                else T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
            return
        self._word_save()
        first = not (self._chat_id and self.messages())
        # ★★ 2026-10-27 질문 프롬프트를 고르지 않고 물음만 적었으면 — 「이 자리와 이어서 / 상관없이 자유롭게」 작은 창(폰과 같은 글)
        self._free_once = False
        if first and raw is None and not teach and not self._task:
            if not q:
                self._status.config(text=T('M_AI_PICK_OR_ASK', '질문 프롬프트를 고르거나 물음을 적어 주세요.'))
                return
            if self._scope != 'FREE':
                ans = self._ask_free_ctx()
                if ans is None:
                    return
                self._free_once = not ans
        if first and raw is None and self._task == 'NOTE' and self._scope == 'VERSE' and not self.note_groups():
            # ★ 317차-15 — 분석할 노트가 없으면 보내지 않는다(노트 없는 구절에 분석이 남던 자리)
            self._status.config(text=T('AI_NOTE_NONE2', '이 범위에 내 묵상노트가 없습니다 — 범위를 넓히거나 노트를 먼저 쓰세요'))
            return
        body = ''
        merging = bool(raw is None and getattr(self, '_merge_body', '') and q == self._merge_body.strip())
        if raw is None and not merging:
            try:
                self._smode_var.set('ALL')          # 보통 말이 마지막이면 「대화목록 전체 저장」으로
                self._sync_smode()
            except Exception:                             # noqa: BLE001
                pass
        if raw is not None:
            text = raw
        elif teach and first:
            # ★ 교사 — 요구사항의 결합 프롬프트를 시스템 지시로 · AI 가 먼저 묻는다
            text, body = '', self._word_prefix(q or self.compose_text())
        elif first and self._scope == 'FREE':
            text = self.compose_text(question=q)
        elif first:
            # ★ 요구사항 = 결합 프롬프트(고친 그대로) — 보낸 그 글이 채팅 내용에 그대로 보인다
            text = self._word_prefix(q or self.compose_text())
        else:
            # ★ 2026-10-16 요구사항에 「1」「2」「3」 하나만 적으면 그 제안 질문을 보낸다
            text = UA.number_pick(q, self.suggestions()) or q
        if not teach and not (text or '').strip():
            return
        cid = self._ensure_chat()
        if not cid:
            return
        with_notes = self._task == 'NOTE' and self._scope == 'VERSE'
        with_links = self._links_on()
        nscope = self.nscope_key()
        only = None
        if first and self._task == 'SERMAN' and str(self._ref or '').startswith('USER_REF:'):
            # ★ 2026-10-15 사용자 「AI 가 2개 이상이면 설교작성 후 분석은 우선적으로 다른 AI 에게」
            try:
                with self._conn() as c:
                    only = UA.other_ais_for_ref(c, int(str(self._ref).split(':', 1)[1])) or None
            except Exception:                             # noqa: BLE001
                only = None
            if only:
                en = [a for a in en if UA.acct_key(a) in only]
        # ★ docs/1.txt 3-4 — 함께 보내는 자료는 **제목만** 채팅 내용에 남긴다(첫 말일 때)
        att = self._attach_titles() if first and raw is None else []
        self._pending_att = ' · '.join(att)
        self._sent_text = q
        try:
            self._in.config(state='disabled')
        except Exception:                                 # noqa: BLE001
            pass
        self._pending_user = text
        self._sent_vmode = self._vmode()
        self._sent_to = ' · '.join('%s %s' % (UA.PROVIDER[a['provider']]['name'], a['model']) for a in en)
        self._t0 = time.time()
        self._busy(True)
        self._status.config(text=T('AI_SENT', '%s 에 보냈습니다 · 답을 기다리는 중 … %d초') % (self._sent_to, 0))

        att_line = self._pending_att

        def _work():
            try:
                with appdb.connect(self.db_path) as c2:
                    if att_line:
                        UA.add_msg(c2, cid, 'system', ATT_MARK + att_line)
                    r = UA.send(c2, cid, text, prompt_body=body, teach_start=bool(teach and first and raw is None),
                                with_notes=with_notes, notes_scope=nscope, only=only,
                                with_links=with_links)
            except Exception as e:                        # noqa: BLE001
                r = {'ok': False, 'why': str(e), 'text': ''}
            self._q.put(r)

        self._th = threading.Thread(target=_work, daemon=True)
        self._th.start()
        try:
            import usage_stats      # 이용통계 — AI 에 실제로 보낸 횟수(2026-10-20)
            usage_stats.bump('ai_send')
        except Exception:
            pass
        self.set_view('CHAT')
        self._paint_transcript()
        self._pump()

    def _commit_ime(self, w):
        """조합 중인 한글을 **읽기 전에** 확정한다(docs/1.txt 3-1 「마지막 글자가 잘린다」).

        ⚠ 확정된 글자는 창 메시지로 들어오므로 이벤트를 한 번 돌린 뒤 읽는다.
        """
        try:
            import ime_hint
            if ime_hint.commit(w.winfo_id()):
                self.update()
        except Exception:                                 # noqa: BLE001
            pass

    def _send_click(self):
        self._commit_ime(self._in)
        for e in self._rq_ent.values():
            self._commit_ime(e)
        self._save_unit()
        self._send(teach=self._task == 'TEACH' and self._scope != 'FREE')

    def _teach(self):
        self._send(teach=True)

    def _one_text(self):
        """[이 채팅을 한 글로] — 지금 채팅을 AI 가 한 편으로 묶게 한다(옛 통합형 글)."""
        if not self._chat_id or not self.messages():
            self._status.config(text=T('AI_NO_CHAT', '합칠 대화가 없습니다.'))
            return
        with self._conn() as c:
            body = UA.fill_prompt(c, UA.merge_prompt_body(c, self._lang()), self._scope, self._start,
                                  self._end, self._eid, self._lang(), self._ref)
        # ★ docs/1.txt 2-3)(3)나) — 요구사항에 통합 프롬프트를 표시한다(고칠 수 있다) · [전송]으로 보낸다
        self._last_merge = True
        self._merge_body = body
        self._in.delete('1.0', 'end')
        self._in.insert('1.0', body)
        self._draft_auto = ''
        try:
            self._smode_var.set('LAST')        # ★ 통합했으면 「최종 통합자료만 저장」
            self._sync_smode()
        except Exception:                                 # noqa: BLE001
            pass
        self.set_view('CHAT')
        try:
            self._in.focus_set()
        except Exception:                                 # noqa: BLE001
            pass

    # ══════════════════════════════════════════════════════════════════
    #  317차 4단계 — 저장 넷 + 2열을 덮는 비교 화면
    # ══════════════════════════════════════════════════════════════════
    SAVE_NAMES = {'REF': ('AI_SAVE_REF', '연구자료로'), 'VDESC': ('AI_SAVE_VDESC', '구절 설명문으로'),
                  'TDESC': ('AI_SAVE_TDESC', '용어 설명문으로'), 'NOTE': ('AI_SAVE_NOTE', '묵상노트로'),
                  'ROLE': ('AI_SAVE_ROLE', '분야 도움말로'), 'LDESC': ('M_AI_SAVE_LDESC', '연결설명문으로'),
                  'LEMMA': ('M_AI_SAVE_LEMMA', '원어 설명으로')}

    def _saves(self):
        """이 채팅의 저장 갈래 — 연결설명문은 **연결 닻으로 연 채팅에서만**(2026-10-14)."""
        out = [k for k in UA.saves_for(self._scope) if k != 'LDESC' or self._link]
        if self._lemma():
            out = ['LEMMA' if k == 'TDESC' else k for k in out]
        return out

    def save_mode(self):
        """「마지막 답만(LAST) / 채팅 전체(ALL)」."""
        try:
            return self._smode_var.get()
        except Exception:                                 # noqa: BLE001
            return 'ALL'

    def _sync_smode(self):
        """「요구사항도 함께 저장」은 **채팅 전체일 때만** 켤 수 있다."""
        try:
            self._mq_chk.configure(state=('normal' if self.save_mode() == 'ALL' else 'disabled'))
        except Exception:                                 # noqa: BLE001
            pass

    def _build_save_menu(self):
        """저장 메뉴를 **만든다**(띄우지 않는다 — tk_popup 모달 함정 §304차 ㊅).
        ★ 그 갈래에 맞는 것만(`UA.saves_for`) — 사용자 확정."""
        m = tk.Menu(self, tearoff=0)
        for k in self._saves():
            nk, ko = self.SAVE_NAMES[k]
            m.add_command(label=T(nk, ko), command=lambda k=k: self._save_click(k))
        self._save_menu = m
        return m

    def _open_save_menu(self):
        """[저장 ▾] — 메뉴를 단추 아래에 편다(만드는 문과 띄우는 문을 가른다)."""
        try:
            m = self._build_save_menu()
            b = self._save_btn
            m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())
        except Exception:                                 # noqa: BLE001
            pass
        finally:
            try:
                self._save_menu.grab_release()
            except Exception:                             # noqa: BLE001
                pass

    def _answer(self):
        with self._conn() as c:
            return UA.answer_text(c, self._chat_id, self.save_mode(), self._lang(), with_q=self.merge_q())

    def save_as(self, kind, text=None):
        """[저장 ▾] 한 갈래 — 지금 글이 있으면 **비교 화면**을 먼저 연다(신규면 바로 담는다).

        `text` 를 주면 그 글을 담는다(답 비교 화면에서 고른 답).
        """
        if not self._chat_id or not self.messages():
            self._status.config(text=T('AI_NO_CHAT', '합칠 대화가 없습니다.'))
            return None
        txt = text if text is not None else self._answer()
        if not txt.strip():
            self._status.config(text=T('AI_NO_ANSWER', '담을 답이 없습니다.'))
            return None
        lang = self._lang()
        if kind == 'REF':
            return self._save_ref_flow(txt)
        if kind == 'NOTE':
            if self._scope != 'VERSE' or not self._start:
                self._status.config(text=T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                return None
            return self._do_save('NOTE', txt)
        if kind == 'ROLE':
            if self._scope != 'VERSE' or not self._start:
                self._status.config(text=T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                return None
            return self._do_save('ROLE', txt)
        if kind == 'VDESC':
            vids = self._desc_verses(txt)
            if not vids:
                self._status.config(text=T('AI_NO_VERSE_IN', '글에서 구절을 찾지 못했습니다 — 구절을 선택하고 다시 저장하세요.'))
                return None
            sp, _why = UA.split_desc(txt, lang)
            new = UA.desc_join(sp, lang) if sp else txt
            self._cmp_vids = vids
            return self._compare_desc(vids[0], new)
        if kind == 'LEMMA':
            # ★ 2026-10-14 원어 설명 — [설명문] 칸이 있으면 그 칸만 · 지금 글이 있으면 비교 화면
            sp, _w = UA.split_desc(txt, lang)
            new = ((sp or {}).get('DESC') or (sp or {}).get('XDESC') or txt).strip()
            with self._conn() as c:
                cur = UA.lemma_note(c, self._lemma(), lang)
                lbl = UA.lemma_label(c, self._lemma())
            if not cur.strip():
                return self._do_save('LEMMA', new)
            return self._compare_open('LEMMA', T('AI_CMP_NOW', '지금 글') + ' · ' + lbl, cur,
                                      T('AI_CMP_NEW', '새 글 — 고쳐서 저장할 수 있습니다'), new)
        if kind == 'LDESC':
            # ★ 2026-10-14 연결설명문 — 답의 [연결설명] 칸만(없으면 통째로) · 지금 글이 있으면 비교 화면
            import re as _re
            lid = int(str(self._link or '').split(':')[-1] or 0)
            if not lid:
                return None
            new = txt
            for nm in set(UA.LINK_MARKS.values()):
                m = _re.search(r'(?m)^\[\s*' + _re.escape(nm) + r'\s*\]\s*$', txt)
                if m:
                    new = txt[m.end():].strip()
                    nxt = _re.search(r'(?m)^\[[^\]\n]{1,24}\]\s*$', new)
                    if nxt:
                        new = new[:nxt.start()].strip()
                    break
            import overlay_edit as _OE
            with self._conn() as c:
                _v, st, cur = _OE.target_state(c, 'VERS_VERS_DESC', lid, lang, '')
                lbl = UA.link_title(c, lid, lang)
            if not (cur or '').strip() or st not in ('SYS', 'EDIT', 'NEW'):
                return self._do_save('LDESC', new)
            return self._compare_open('LDESC', T('AI_CMP_NOW', '지금 글') + ' · ' + lbl, cur,
                                      T('AI_CMP_NEW', '새 글 — 고쳐서 저장할 수 있습니다'), new)
        if kind == 'TDESC':
            new = txt
            if self._scope == 'TERM' and self._eid:
                return self._compare_term(self._eid, new)
            return self._compare_term(None, new)
        return None

    def _desc_verses(self, txt):
        """구절 설명문을 붙일 구절 — 구절 갈래면 닻 · Free 면 **글 속 약명**(여럿이면 선택한다)."""
        if self._scope == 'VERSE' and self._start:
            return [self._start]
        try:
            import scripture_ref as SR
            with self._conn() as c:
                got = SR.find(c, txt or '', self._lang(), limit=20)
            out = []
            for a, _b, _m, _k in got:
                if a not in out:
                    out.append(a)
            return out
        except Exception:                                 # noqa: BLE001
            return []

    # ── 연구자료 ─────────────────────────────────────────────────────
    def _save_ref_flow(self, txt):
        with self._conn() as c:
            had = UA.ref_of(c, self._chat_id)
            title = self.chat_title() or UA.default_ref_title(c, self._chat_id, self._lang())
            clash = UA.ref_title_clash(c, title, self._chat_id)
            old = ''
            if had:
                import db_user_ref_schema as U
                old = U.fetch_text(c, had, self._lang())[1] or ''
        if clash:
            self._status.config(text=T('AI_TITLE_CLASH', '제목 「%s」은 다른 채팅이 만든 연구/설교노트(#%s)가 이미 씁니다 — 채팅 제목을 바꾸고 다시 저장하세요.')
                                % (title, clash))
            return None
        if had and old.strip():
            return self._compare_open('REF', T('AI_CMP_NOW', '지금 글') + ' (#%s)' % had, old,
                                      T('AI_CMP_NEW', '새 글 — 고쳐서 저장할 수 있습니다'), txt)
        return self._do_save('REF', txt)

    # ── 구절·용어 설명문 ──────────────────────────────────────────────
    def _compare_desc(self, vid, new):
        self._cmp_vid = vid
        # ★ 2026-10-14 — 지금 글도 **새 글이 쓴 칸만** 보인다(전문설명문을 담을 때 일반 칸이 「지워질 것」처럼 보이지 않게)
        sp, _w = UA.split_desc(new, self._lang())
        keys = set(sp or {})
        with self._conn() as c:
            curp = UA.desc_current(c, vid, self._lang())
            if keys:
                curp = {k: v for k, v in curp.items() if k in keys}
            cur = UA.desc_join(curp, self._lang())
            lbl = UA.range_label(c, vid, vid, self._lang())
        if not cur.strip() and len(getattr(self, '_cmp_vids', [])) <= 1:
            return self._do_save('VDESC', new)
        return self._compare_open('VDESC', T('AI_CMP_NOW', '지금 글') + ' · ' + lbl, cur or '',
                                  T('AI_CMP_NEW', '새 글 — 고쳐서 저장할 수 있습니다'), new)

    def _compare_term(self, eid, new):
        self._cmp_eid = eid
        cur = ''
        lbl = ''
        if eid:
            with self._conn() as c:
                cur = UA.term_desc_current(c, eid, self._lang())
                lbl = UA.term_name(c, eid, self._lang())
            if not cur.strip():
                return self._do_save('TDESC', new)
        return self._compare_open('TDESC', T('AI_CMP_NOW', '지금 글') + (' · ' + lbl if lbl else ''), cur,
                                  T('AI_CMP_NEW', '새 글 — 고쳐서 저장할 수 있습니다'), new)

    # ── 비교 화면 ─────────────────────────────────────────────────────
    def _compare_open(self, kind, left_lbl, left, right_lbl, right):
        """**2열 전체를 덮는** 비교 화면 — 왼쪽 지금 글(읽기) · 오른쪽 새 글(고칠 수 있다) ·
        바뀐 곳에 색 · 두 칸이 함께 굴러간다. 단추는 위(§0)."""
        self._compare_close()
        bg = self._bg
        f = tk.Frame(self, bg=bg)
        f.place(in_=self._pw, relx=0, rely=0, relwidth=1, relheight=1)
        f.lift()
        self._cmp_f = f
        self._cmp_kind = kind
        top = tk.Frame(f, bg=bg)
        top.pack(fill='x', pady=(2, 2))
        nk, ko = self.SAVE_NAMES[kind]
        tk.Label(top, text=T('AI_CMP_TITLE', '저장 전 비교') + ' — ' + T(nk, ko), bg=bg,
                 fg=_C('accent', '#1A5276')).pack(side='left', padx=4)
        _btn(top, T('AI_SAVE', '저장'), self._compare_ok).pack(side='left', padx=(8, 2))
        _btn(top, T('AI_CANCEL', '취소'), self._compare_close).pack(side='left')
        self._cmp_pick = None
        if kind == 'VDESC' and len(getattr(self, '_cmp_vids', [])) > 1:
            with self._conn() as c:
                names = [UA.range_label(c, v, v, self._lang()) for v in self._cmp_vids]
            tk.Label(top, text=T('AI_CMP_WHICH', '붙일 구절'), bg=bg).pack(side='left', padx=(12, 2))
            cb = ttk.Combobox(top, state='readonly', width=14, values=names)
            cb.current(max(0, self._cmp_vids.index(self._cmp_vid)) if self._cmp_vid in self._cmp_vids else 0)
            cb.pack(side='left')
            cb.bind('<<ComboboxSelected>>', lambda _e: self._cmp_repick_verse())
            self._cmp_pick = cb
        if kind == 'TDESC' and not getattr(self, '_cmp_eid', None):
            tk.Label(top, text=T('AI_CMP_TERM', '붙일 용어'), bg=bg).pack(side='left', padx=(12, 2))
            q = ttk.Entry(top, width=12)
            q.pack(side='left')
            cb = ttk.Combobox(top, state='readonly', width=18, values=[])
            cb.pack(side='left', padx=(2, 0))
            self._cmp_term_rows = []
            q.bind('<Return>', lambda _e: self._cmp_term_find(q.get(), cb))
            _btn(top, T('AI_PICK_FIND', '찾기'), lambda: self._cmp_term_find(q.get(), cb)).pack(side='left', padx=2)
            cb.bind('<<ComboboxSelected>>', lambda _e: self._cmp_term_pick(cb))
            self._cmp_pick = cb
        self._cmp_msg = tk.Label(top, text='', bg=bg, fg=_C('warning', '#B9770E'))
        self._cmp_msg.pack(side='left', padx=8)
        body = tk.Frame(f, bg=bg)
        body.pack(fill='both', expand=True)
        cols = []
        for i, (lbl, txt, edit) in enumerate(((left_lbl, left, False), (right_lbl, right, True))):
            box = tk.Frame(body, bg=bg)
            box.place(relx=0.5 * i, rely=0, relwidth=0.5, relheight=1)
            tk.Label(box, text=lbl, bg=bg, anchor='w', fg=_C('fg_title', '#2C3E50')).pack(fill='x', padx=2)
            t = tk.Text(box, wrap='word', undo=True, bg=_C('view_bg', '#FFFFFF'))
            t.pack(fill='both', expand=True, padx=2)
            t.insert('1.0', txt or '')
            t.tag_configure('chg', background=_C('success_bg', '#D5F5E3'))   # ★ 2026-10-21 형광 노랑 → 녹색(눈부시지 않게 · 어두운 화면도 역할 색)
            if not edit:
                t.configure(state='disabled')
            cols.append(t)
        self._cmp_left, self._cmp_right = cols
        self._cmp_paint_diff()
        self._cmp_right.bind('<KeyRelease>', lambda _e: self._cmp_paint_diff(), add='+')

        # ★ 두 칸이 **함께 굴러간다**
        def _sync(*a):
            for t in cols:
                t.yview_moveto(a[0])
        for t in cols:
            t.configure(yscrollcommand=lambda first, _last: _sync(first))
            t.bind('<MouseWheel>', lambda e: ([x.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                              'units') for x in cols], 'break')[1])
        self._refont()
        return f

    # ══════════════════════════════════════════════════════════════════
    #  317차-6 — 답 비교(원본 | AI 답 1 | AI 답 2 …)
    # ══════════════════════════════════════════════════════════════════
    def _sync_cmp_btn(self):
        """가운데 아래 상태 한 줄 + [AI결과 창 열기] — 답이 있을 때만 눌린다(317차-8)."""
        txt, n = '', 0
        try:
            if self._chat_id:
                with self._conn() as c:
                    st = UA.chat_state(c, self._chat_id)
                parts = [T('AI_ST_ANS', '%s 답 %d') % (nm, k) for nm, k in st['ais']]
                n = sum(k for _nm, k in st['ais'])
                lf = getattr(self, '_last_fails', None)
                if lf and lf[0] == self._chat_id:
                    parts += ['%s %s' % (UA.short_name({'provider': p_, 'model': md}) or md,
                                         T('AI_GOT_FAIL', '못 받음')) for p_, md, _w in lf[1]]
                if st['selfs']:
                    parts.append(T('AI_ST_SELF', '대화 통합본 %d') % st['selfs'])
                if st['integ']:
                    parts.append(T('AI_ST_INTEG', '통합본 있음'))
                txt = ' · '.join(parts)
        except Exception:                                 # noqa: BLE001
            pass
        try:
            self._state_lbl.config(text=txt)
            self._res_btn.config(state=('normal' if n else 'disabled'))
            self._cmpans_btn.config(state=('normal' if n else 'disabled'))
        except Exception:                                 # noqa: BLE001
            pass

    def open_results(self):
        """AI결과 창 — 한 번에 하나 · 이미 떠 있으면 다시 그리고 앞으로."""
        if not self._chat_id or not self._last_ai():
            # ★ 2026-10-21 (AI도우미.txt 4-6) 「눌러도 반응이 없다」 — 받은 답이 없으면 말없이 돌아갔다
            self._status.config(text=T('AI_RES_NONE', 'AI결과 창은 답을 받은 채팅에서 열립니다'))
            return None
        w = getattr(self, '_result_win', None)
        try:
            if w is not None and w.winfo_exists():
                w.refresh()
                w.deiconify()                     # 내려 두었거나 뒤에 숨은 창도 앞으로
                w.lift()
                w.focus_force()
                return w
        except Exception:                                 # noqa: BLE001
            pass
        import ai_result_win as RW
        self._result_win = RW.AIResultWin(self)
        return self._result_win

    def _orig_text(self):
        """원본(지금 글) — 구절 설명문 · 용어 설명문 · 연구자료 갈래. 없으면 ('', '')."""
        lang = self._lang()
        try:
            with self._conn() as c:
                if self._scope == 'VERSE' and self._start and self._task in ('DESC', ''):
                    cur = UA.desc_join(UA.desc_current(c, self._start, lang), lang)
                    return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글') + ' · '
                            + UA.range_label(c, self._start, self._start, lang),
                            cur or T('AI_CMP_ORIG_NONE', '(아직 없음)'))
                if self._scope == 'TERM' and self._eid:
                    return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글') + ' · ' + UA.term_name(c, self._eid, lang),
                            UA.term_desc_current(c, self._eid, lang) or T('AI_CMP_ORIG_NONE', '(아직 없음)'))
                if self._scope == 'REF' and self._ref:
                    m = UA.materials_ref(c, self._ref, lang) if hasattr(UA, 'materials_ref') else {}
                    body = ''
                    if isinstance(m, dict):
                        body = next((v for k, v in m.items() if '본문' in str(k) or 'body' in str(k).lower()), '')
                    return (T('AI_CMP_ORIG', '원본 (지금 글)'), body or '')
        except Exception as e:                            # noqa: BLE001
            print('[ai_chat orig] %s' % e)
        return ('', '')

    def _chat_task(self):
        """이 채팅을 연 업무(`prompt_kind` 'T:<업무>') — 목록에서 다시 연 채팅은 화면의 업무와 다를 수 있다."""
        if not self._chat_id:
            return self._task
        try:
            with self._conn() as c:
                ch = UA.chat(c, self._chat_id) or {}
            k = str(ch.get('kind') or '')
            if k.endswith(':BOOK'):
                k = k[:-5]
            return k[2:] if k.startswith('T:') else self._task
        except Exception:                                 # noqa: BLE001
            return self._task

    def _role_of_chat(self, c=None):
        """★ 2026-10-21 이 채팅의 분야 — 그 채팅의 업무(RT_*)가 정한다(목록에서 다시 연 채팅은 `_role_ask` 가 비어 있다)."""
        ct = self._chat_task()
        for code, t in UA.ROLE_TASK_OF.items():
            if ct == t:
                return code
        import role_tips as RT
        if getattr(self, '_role_ask', ''):
            return self._role_ask
        return (RT.my_role(c) if c is not None else '') or RT.CODES[0]

    def _default_save_kind(self):
        if self._chat_task() in UA.ROLE_TASKS:
            return 'ROLE'
        if self._task == 'DESC' and self._scope == 'VERSE':
            return 'VDESC'
        if self._task == 'DESC' and self._scope == 'TERM':
            return 'TDESC'
        if self._task == 'NOTE':
            return 'NOTE'
        return 'REF'

    def answers_compare(self):
        """옛 이름 — 이제 **AI결과 창**을 연다(317차-8)."""
        return self.open_results()

    def _answers_compare_overlay(self):
        """(317차-6 의 덮는 판 — 되돌릴 자리 · 부르는 곳 0)"""
        if not self._chat_id:
            self._status.config(text=T('AI_NO_CHAT', '합칠 대화가 없습니다.'))
            return None
        with self._conn() as c:
            ans = UA.last_answers(c, self._chat_id)
            names = [UA.short_name({'provider': p_, 'model': md}) if hasattr(UA, 'short_name') else md
                     for _m, p_, md, _b in ans]
        if not ans:
            self._status.config(text=T('AI_NO_ANSWER', '담을 답이 없습니다.'))
            return None
        self._compare_close()
        olbl, otxt = self._orig_text()
        bg = self._bg
        f = tk.Frame(self, bg=bg)
        f.place(in_=self._pw, relx=0, rely=0, relwidth=1, relheight=1)
        f.lift()
        self._cmp_f = f
        top = tk.Frame(f, bg=bg)
        top.pack(fill='x', pady=(2, 2))
        tk.Label(top, text=T('AI_CMP_ANS_TITLE2', 'AI결과 비교 — 원본과 AI 답을 나란히, AI 답끼리도'), bg=bg,
                 fg=_C('accent', '#1A5276')).pack(side='left', padx=4)
        tk.Label(top, text=T('AI_CMP_SAVE_AS', '저장할 곳'), bg=bg).pack(side='left', padx=(12, 2))
        kinds = list(self._saves())
        dk = self._default_save_kind()
        if dk not in kinds:
            dk = kinds[0] if kinds else 'REF'
        self._ans_kinds = kinds
        cb = ttk.Combobox(top, state='readonly', width=16,
                          values=[T(*self.SAVE_NAMES[k]) for k in kinds])
        if dk in kinds:
            cb.current(kinds.index(dk))
        cb.pack(side='left')
        self._ans_kind_cb = cb
        if len(ans) >= 2:
            _btn(top, T('AI_MERGE_ANS', '두 답을 한 글로'), self._answers_merge).pack(side='left', padx=(12, 2))
        _btn(top, T('AI_CLOSE', '닫기'), self._compare_close).pack(side='left', padx=(8, 0))
        self._cmp_msg = tk.Label(top, text='', bg=bg, fg=_C('warning', '#B9770E'))
        self._cmp_msg.pack(side='left', padx=8)
        body = tk.Frame(f, bg=bg)
        body.pack(fill='both', expand=True)
        cols_spec = []
        if olbl:
            cols_spec.append((olbl, otxt, False, None))
        for (mid, p_, md, b), nm in zip(ans, names):
            cols_spec.append((T('AI_RESULT_OF', '%s 답') % (nm or md or p_ or 'AI'), b, True, mid))
        # ★ 317차-7 — 이번 전송에서 **못 받은 AI 도 칸으로**(칸 수가 곧 보낸 AI 수다)
        lf = getattr(self, '_last_fails', None)
        if lf and lf[0] == self._chat_id:
            for p_, md, why in lf[1]:
                nm = UA.short_name({'provider': p_, 'model': md}) if hasattr(UA, 'short_name') else md
                cols_spec.append((T('AI_RESULT_OF', '%s 답') % (nm or md or p_),
                                  T('AI_GOT_FAIL', '못 받음') + ' — ' + self._why_short(why), False, -1))
        n = len(cols_spec)
        texts = []
        self._ans_cols = []
        for i, (lbl, txt, edit, mid) in enumerate(cols_spec):
            box = tk.Frame(body, bg=bg)
            box.place(relx=float(i) / n, rely=0, relwidth=1.0 / n, relheight=1)
            hd = tk.Frame(box, bg=bg)
            hd.pack(fill='x')
            tk.Label(hd, text=lbl, bg=bg, anchor='w', fg=_C('fg_title', '#2C3E50')).pack(side='left', padx=2)
            t = tk.Text(box, wrap='word', undo=True, bg=_C('view_bg', '#FFFFFF'))
            if mid is not None and mid != -1:
                _btn(hd, T('AI_USE_THIS', '이것으로 저장'),
                     lambda t=t: self.gated(lambda: self._answers_use(t),
                                            on_changed=lambda _r: (self._compare_close(), self.answers_compare()))).pack(side='right', padx=2)
            t.pack(fill='both', expand=True, padx=2)
            t.insert('1.0', txt or '')
            t.tag_configure('chg', background=_C('success_bg', '#D5F5E3'))   # ★ 2026-10-21 형광 노랑 → 녹색(눈부시지 않게 · 어두운 화면도 역할 색)
            if not edit:
                t.configure(state='disabled')
            texts.append(t)
            if mid is not None and mid != -1:
                self._ans_cols.append(t)
        self._ans_texts = texts
        self._ans_fail_cols = [texts[i] for i, x in enumerate(cols_spec) if x[3] == -1]
        # ★ 기준 = 원본(글이 있을 때) · 없으면 첫 답
        _has_orig = bool(olbl) and otxt and otxt != T('AI_CMP_ORIG_NONE', '(아직 없음)')
        self._ans_base = texts[0] if _has_orig or not self._ans_cols else self._ans_cols[0]
        self._ans_paint()
        for t in self._ans_cols:
            t.bind('<KeyRelease>', lambda _e: self._ans_paint(), add='+')

        # ★ 칸이 **함께 굴러간다**
        def _sync(*a):
            for t in texts:
                t.yview_moveto(a[0])
        for t in texts:
            t.configure(yscrollcommand=lambda first, _last: _sync(first))
            t.bind('<MouseWheel>', lambda e: ([x.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1),
                                                              'units') for x in texts], 'break')[1])
        self._refont()
        return f

    def _ans_paint(self):
        """답마다 **기준 칸(원본, 없으면 답 1)과 다른 곳**을 칠한다 — 낱말 단위."""
        import difflib
        import re as _re
        base = self._ans_base
        a = base.get('1.0', 'end-1c')
        ta = [m.group() for m in _re.finditer(r'\S+', a)]
        for t in self._ans_cols:
            if t is base:
                continue
            b = t.get('1.0', 'end-1c')
            tb = [m for m in _re.finditer(r'\S+', b)]
            t.tag_remove('chg', '1.0', 'end')
            sm = difflib.SequenceMatcher(None, ta, [m.group() for m in tb], autojunk=False)
            for op, _i1, _i2, j1, j2 in sm.get_opcodes():
                if op != 'equal' and j2 > j1:
                    t.tag_add('chg', '1.0+%dc' % tb[j1].start(), '1.0+%dc' % tb[j2 - 1].end())

    def _answers_kind(self):
        try:
            return self._ans_kinds[self._ans_kind_cb.current()]
        except Exception:                                 # noqa: BLE001
            return self._default_save_kind()

    def _answers_use(self, t):
        """[이것으로 저장] — 선택한 답(고친 글 그대로)을 선택한 곳에 담는다.

        ★ 원본은 이미 이 화면에 나란히 있었으므로 **닻이 있으면 바로 담는다**(비교를 두 번 하지 않는다).
        """
        txt = t.get('1.0', 'end').strip()
        if not txt:
            return None
        kind = self._answers_kind()
        if kind == 'VDESC' and self._scope == 'VERSE' and self._start:
            self._cmp_vid = self._start
            self._cmp_vids = [self._start]
            r = self._do_save('VDESC', txt)
        elif kind == 'TDESC' and self._scope == 'TERM' and self._eid:
            self._cmp_eid = self._eid
            r = self._do_save('TDESC', txt)
        elif kind == 'NOTE':
            r = self.save_as('NOTE', text=txt)
        else:
            self._compare_close()
            return self.save_as(kind, text=txt)
        if r is not None:
            self._compare_close()
        return r

    def _answers_merge(self):
        """[두 답을 한 글로] — 답들을 **함께 실은** 통합 요청을 요구사항에 넣는다([전송]은 사람이).

        ⚠ AI 마다 제 앞 답만 받으므로(299차) 다른 AI 의 답은 **요청 글 안에 실어야** 본다.
        """
        with self._conn() as c:
            ans = UA.last_answers(c, self._chat_id)
        lbl = (lambda p_, md: UA.short_name({'provider': p_, 'model': md})) if hasattr(UA, 'short_name') else None
        body = (T('AI_MERGE_ANS_BODY', '아래 답들의 좋은 점을 합쳐 한 편의 글로 다시 써 주세요. 겹치는 말은 한 번만 쓰고, '
                                       '서로 다른 점은 둘 다 살리고, 틀린 것은 고쳐 주세요.')
                + chr(10) + chr(10) + UA.answers_block(ans, lbl))
        self._compare_close()
        self._last_merge = True
        self._in.delete('1.0', 'end')
        self._in.insert('1.0', body)
        self._draft_auto = ''
        try:
            self._smode_var.set('LAST')
            self._sync_smode()
        except Exception:                                 # noqa: BLE001
            pass
        self.set_view('CHAT')
        self._status.config(text=T('AI_MERGE_ANS_HINT', '통합 요청을 요구사항에 넣었습니다 — [설정]에서 AI 하나만 켜고 [전송]을 누르세요.'))

    def _cmp_paint_diff(self):
        """바뀐 곳을 칠한다 — 낱말 단위(difflib). 왼쪽은 빠진 것 · 오른쪽은 새로 든 것."""
        import difflib
        import re as _re
        L, R = self._cmp_left, self._cmp_right
        a, b = L.get('1.0', 'end-1c'), R.get('1.0', 'end-1c')
        ta = [m for m in _re.finditer(r'\S+', a)]
        tb = [m for m in _re.finditer(r'\S+', b)]
        sm = difflib.SequenceMatcher(None, [m.group() for m in ta], [m.group() for m in tb], autojunk=False)
        st = L.cget('state')
        L.configure(state='normal')
        for t in (L, R):
            t.tag_remove('chg', '1.0', 'end')
        for op, i1, i2, j1, j2 in sm.get_opcodes():
            if op == 'equal':
                continue
            if i2 > i1:
                L.tag_add('chg', '1.0+%dc' % ta[i1].start(), '1.0+%dc' % ta[i2 - 1].end())
            if j2 > j1:
                R.tag_add('chg', '1.0+%dc' % tb[j1].start(), '1.0+%dc' % tb[j2 - 1].end())
        L.configure(state=st)

    def _cmp_repick_verse(self):
        i = self._cmp_pick.current()
        if 0 <= i < len(self._cmp_vids):
            self._cmp_vid = self._cmp_vids[i]
            with self._conn() as c:
                cur = UA.desc_join(UA.desc_current(c, self._cmp_vid, self._lang()), self._lang())
            L = self._cmp_left
            L.configure(state='normal')
            L.delete('1.0', 'end')
            L.insert('1.0', cur)
            L.configure(state='disabled')
            self._cmp_paint_diff()

    def _cmp_term_find(self, q, cb):
        try:
            import asset_pick as AP
            with self._conn() as c:
                self._cmp_term_rows = list(AP.candidates(c, 'ENTITY', (q or '').strip(), self._lang(), 40))
        except Exception:                                 # noqa: BLE001
            self._cmp_term_rows = []
        cb.configure(values=[nm for _e, nm in self._cmp_term_rows])
        if self._cmp_term_rows:
            cb.current(0)
            self._cmp_term_pick(cb)

    def _cmp_term_pick(self, cb):
        i = cb.current()
        if 0 <= i < len(self._cmp_term_rows):
            self._cmp_eid = int(self._cmp_term_rows[i][0])
            with self._conn() as c:
                cur = UA.term_desc_current(c, self._cmp_eid, self._lang())
            L = self._cmp_left
            L.configure(state='normal')
            L.delete('1.0', 'end')
            L.insert('1.0', cur)
            L.configure(state='disabled')
            self._cmp_paint_diff()

    def open_library(self):
        """프롬프트 라이브러리 — 2열 전체를 덮는다(비교 화면과 같은 자리). 지금 업무의 자리가 골라져 연다."""
        self._compare_close()
        self._edit_save()
        import ai_lib_view
        place = self._lib_place() if self._scope != 'FREE' else 'VERSE:FREE'
        f = ai_lib_view.LibView(self, db_path=self.db_path, lang=self._lang(), place=place,
                                on_close=self._compare_close, on_changed=self._lib_changed,
                                on_prayer=self._open_prayer_prompts)
        f.place(in_=self._pw, relx=0, rely=0, relwidth=1, relheight=1)
        f.lift()
        self._cmp_f = f
        self._cmp_kind = 'LIB'
        self._lib_view = f
        try:
            self._refont()
            if ui_theme:
                ui_theme.paint(f)
        except Exception:                                 # noqa: BLE001
            pass
        return f

    def _lib_changed(self):
        """라이브러리에서 고치면 지금 업무의 Pick 목록을 다시 읽는다(보이는 것 = 보내는 것)."""
        self._free_keys_c = None                      # Free 화면 표시 칸을 다시 읽는다
        try:
            self._load_prompts()
        except Exception:                                 # noqa: BLE001
            pass

    def _free_keys(self):
        """★ 2026-10-21 (AI도우미.txt 1-2) Free 화면에 보일 공통 칸 — 라이브러리 「Free 화면에도 보이기」."""
        v = getattr(self, '_free_keys_c', None)
        if v is None:
            try:
                import ai_lib_view
                with self._conn() as c:
                    v = ai_lib_view.free_show(c)
            except Exception:                             # noqa: BLE001
                v = ['USER']
            self._free_keys_c = v
        return v

    def _compare_close(self):
        f = getattr(self, '_cmp_f', None)
        if f is not None and getattr(self, '_cmp_kind', '') == 'LIB':
            try:
                f.save()                                  # 라이브러리에서 고치던 것을 먼저 적는다
            except Exception:                             # noqa: BLE001
                pass
            self._lib_view = None
        if f is not None:
            try:
                f.destroy()
            except Exception:                             # noqa: BLE001
                pass
        self._cmp_f = None

    def _compare_ok(self):
        kind = self._cmp_kind
        txt = self._cmp_right.get('1.0', 'end').strip()
        if kind == 'TDESC' and not getattr(self, '_cmp_eid', None):
            self._cmp_msg.config(text=T('AI_CMP_TERM_NEED', '붙일 용어를 먼저 선택하세요'))
            return None
        r = self._do_save(kind, txt)
        if r is not None:
            self._compare_close()
        return r

    def _do_save(self, kind, txt, title=None):
        """실제로 담는다 — 뒤에 진행 줄이 무엇을 했는지 말하고 [열어 보기] 를 띄운다.
        `title` — AI결과 창의 제목 칸(연구자료·묵상분석 · 317차-10). 비면 옛 규칙."""
        try:
            import usage_stats
            usage_stats.engage_hit('ai:step:save')
        except Exception:
            pass
        lang = self._lang()
        open_to = None
        with self._conn() as c:
            if kind == 'REF':
                title = title or self.chat_title() or UA.default_ref_title(c, self._chat_id, lang)
                # ★ 2026-10-21 사용자 — 구절은 **저절로 잇지 않는다**: 담은 뒤 연구/설교노트 화면을 열어
                #   그 화면의 추천 줄(체크하면 연결 · ✕ 다시 안 뜸)에서 사람이 확정한다
                rid = UA.save_as_ref(c, self._chat_id, text=txt, lang=lang, title=title, link=False)
                msg = T('AI_SAVED_REF4', '연구/설교노트 「%s」에 담았습니다 — 그 화면의 추천 줄에서 구절 연결을 확정하세요') % title
                open_to = ('USER_REF', rid)
                self.after(80, lambda r=rid: self._open_ref_now(r))
                if callable(self.on_saved):
                    try:
                        self.on_saved(rid)
                    except Exception:                     # noqa: BLE001
                        pass
                res = rid
            elif kind == 'VDESC':
                vid = getattr(self, '_cmp_vid', None) or self._start
                sp, _w = UA.split_desc(txt, lang)
                parts = sp or {'DESC': txt}
                n = UA.desc_save(c, vid, lang, parts)
                msg = T('AI_SAVED_VDESC', '%s 설명문 %d칸을 내 버전으로 담았습니다') % (
                    UA.range_label(c, vid, vid, lang), n)
                open_to = ('VERSE', vid)
                res = n
            elif kind == 'ROLE':
                import role_tips as RT
                role = self._role_of_chat(c)
                RT.save_mine(c, self._start, role, lang, txt)
                # ★ 2026-10-21 저장한 그 분야가 화면에 보이게(분야는 하나만 보인다 — 다른 분야면 저장해도 안 보였다)
                if role not in RT.get_show(c, RT.tier_of(role)):
                    RT.set_show(c, [role])
                msg = T('AI_SAVED_ROLE', '%s 「%s」 도움말을 내 도움말로 담았습니다') % (
                    UA.range_label(c, self._start, self._start, lang), RT.label(role))
                open_to = ('VERSE', self._start)
                res = role
            elif kind == 'LEMMA':
                UA.lemma_save(c, self._lemma(), lang, txt)
                msg = T('AI_SAVED_LEMMA', '「%s」 원어 설명을 내 글로 담았습니다') % UA.lemma_label(c, self._lemma())
                open_to = None
                res = self._lemma()
            elif kind == 'LDESC':
                import overlay_edit as _OE
                lid = int(str(self._link or '').split(':')[-1] or 0)
                _OE.save_mine(c, 'VERS_VERS_DESC', lid, lang, None, txt)
                msg = T('AI_SAVED_LDESC', '「%s」 연결설명문을 내 버전으로 담았습니다') % UA.link_title(c, lid, lang)
                open_to = ('VERSE', self._start)
                res = lid
            elif kind == 'TDESC':
                eid = getattr(self, '_cmp_eid', None) or self._eid
                UA.term_desc_save(c, eid, lang, txt)
                msg = T('AI_SAVED_TDESC', '「%s」 설명문을 내 버전으로 담았습니다') % UA.term_name(c, eid, lang)
                open_to = ('ENTITY', eid)
                res = eid
            elif kind == 'NOTE':
                # ★★★ 317차-15 — **구절마다 따로**(사용자 「분석은 한꺼번에 하지만, 분석 내용과 연결작업은 각
                #   구절단위 독립적」) — 답을 [약명] 머리로 나눠 **그 구절에** 새 노트로 담는다.
                #   붙이는 자리는 **사람이 쓴 노트가 있는 구절만**(묻지 않은 구절·노트 없는 구절에는 안 붙인다).
                import medi_note
                heads = UA.split_note_analysis(c, txt, lang)
                ok_v = UA.noted_verses(c, [v for v, _b in heads])
                parts = [(v, b) for v, b in heads if v in ok_v]
                if not parts:
                    if heads or not UA.noted_verses(c, [self._start]):
                        self._status.config(text=T('AI_NOTE_SPLIT_NONE',
                                                   '구절마다 나눌 수 없습니다 — 각 분석 앞에 [약명 장:절] 줄이 있어야 하고, '
                                                   '그 구절에 내 묵상노트가 있어야 합니다'))
                        return None
                    parts = [(self._start, txt)]
                res = []
                for v, b in parts:
                    res.append(medi_note.save_new(self.db_path, v, v, b, src_label=UA.AI_NOTE_SRC, lang=lang,
                                                  title=title or T('AI_NOTE_TITLE', 'AI 묵상분석')))
                names = ', '.join(UA.range_label(c, v, v, lang) for v, _b in parts)
                msg = T('AI_SAVED_NOTE2', '묵상노트 %d곳에 AI 분석을 새 노트로 담았습니다: %s') % (len(parts), names)
                skipped = [v for v, _b in heads if v not in ok_v]
                if skipped:
                    msg += ' · ' + T('AI_NOTE_SKIP', '노트가 없는 구절 %d곳은 건너뛰었습니다') % len(skipped)
                open_to = ('VERSE', parts[0][0])
            else:
                return None
        self._status.config(text=msg)
        self._show_open(open_to)
        # ★ 2026-10-21 사용자 「처음 한번 최종본 저장한 후에는 p2에서 표시되지 않고 한번 더 하면 성공」 —
        #   설명문·분야 도움말·묵상노트를 담아도 P2·P4 설명을 다시 그리지 않았다(다른 일로 다시 그려질 때만 보였다).
        if kind in ('ROLE', 'VDESC', 'NOTE') and callable(getattr(self, 'on_desc_saved', None)):
            try:
                self.on_desc_saved()
            except Exception as e:                        # noqa: BLE001
                print('[desc saved] %s' % e)
        if self._chat_id:
            try:
                with self._conn() as c:
                    ACS.mark_saved(c, self._chat_id)
            except Exception:                             # noqa: BLE001
                pass
        return res

    def _show_open(self, target):
        """★ 2026-10-21 [열어 보기] 걷음(사용자) — 저장하면 P2·P4 가 저절로 다시 그려진다."""
        self._open_to = target
        return
        try:
            if target and callable(self.on_open):
                if not self._open_btn.winfo_manager():
                    self._open_btn.pack(side='right', padx=2, before=self._status)
            elif self._open_btn.winfo_manager():
                self._open_btn.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass

    def _open_ref_now(self, rid):
        """연구/설교노트로 담았으면 그 화면을 연다(P4 연구/설교노트 · 추천 줄로 연결 확정)."""
        if callable(self.on_open):
            try:
                self.on_open('USER_REF', int(rid))
            except Exception as e:                        # noqa: BLE001
                print('[open ref] %s' % e)

    def _open_saved(self):
        t = getattr(self, '_open_to', None)
        if t and callable(self.on_open):
            try:
                self.on_open(*t)
            except Exception:                             # noqa: BLE001
                pass

    _popup_saved = {}      # 채팅 → 통합화면에서 저장했을 때의 말 수

    def mark_popup_saved(self):
        """통합화면에서 저장했다 — 가운데 [저장 ▾]를 감춘다(같은 것을 또 누르지 않게)."""
        if self._chat_id:
            self._popup_saved = dict(self._popup_saved)
            self._popup_saved[self._chat_id] = len(self.messages())
        self._sync_save_btn()

    def _sync_save_btn(self):
        try:
            n = self._popup_saved.get(self._chat_id) if self._chat_id else None
            hide = n is not None and len(self.messages()) <= n
            if hide and self._save_mb.winfo_manager():
                self._save_mb.pack_forget()
            elif not hide and not self._save_mb.winfo_manager():
                self._save_mb.pack(side='right', padx=2, before=self._res_btn2)
        except Exception:                                 # noqa: BLE001
            pass

    def _merge(self):
        """옛 이름 — 연구자료로 저장."""
        return self.save_as('REF')

    def _fill_integ_set(self):
        """통합 담당 콤보 — 저장된 켠 계정들 · 지금 선택한 것."""
        try:
            with self._conn() as c:
                en = UA.enabled_accounts(c)
                cur = UA.integ_account(c)
            self._integ_opts = [UA.acct_key(a) for a in en]
            self._integ_set_cb.configure(values=[UA.short_name(a) or a.get('model') for a in en])
            if cur in self._integ_opts:
                self._integ_set_cb.current(self._integ_opts.index(cur))
        except Exception:                                 # noqa: BLE001
            pass

    def _save_vmode(self):
        try:
            with self._conn() as c:
                UA.set_verify_mode(c, self._vmode_var.get())
            self._status.config(text=T('AI_SAVED', '저장했습니다 — 이 PC 의 개인 DB 에만'))
        except Exception as e:                            # noqa: BLE001
            print('[vmode] %s' % e)

    # ── 저장/공유 전 검증(2026-10-16) ──────────────────────────────
    def _vmode(self):
        try:
            with self._conn() as c:
                return UA.verify_mode(c)
        except Exception:                                 # noqa: BLE001
            return UA.VERIFY_MODE_DEFAULT

    def gated(self, cont, on_changed=None, say=None):
        """저장 단추 앞의 문 — 「검증 없이」가 아니면 그 채팅의 검증 안 된 답을 먼저 검증하고 `cont()`.

        · 이미 다 검증했으면 곧바로 `cont()`(두 번 부르지 않는다)
        · 검증이 답을 고쳤고 `on_changed` 가 있으면 저장하지 않고 그것을 부른다(사람이 고른 글이 옛 글일 때 —
          AI결과 창 최종본 · 답 비교) · 없으면 고친 글로 다시 지어 `cont()`
        · 검증하지 못한 답이 있으면 묻는다 — [원본 그대로 저장] / [취소]
        """
        say = say or (lambda m: self._status.config(text=m))
        if not self._chat_id or self._vmode() == 'OFF':
            return cont()
        with self._conn() as c:
            todo = UA.unverified_ids(c, self._chat_id)
        if not todo:
            return cont()
        if getattr(self, '_vg_th', None) is not None:
            return None
        cid = self._chat_id
        say(T('AI_VSAVE_ING', '저장하기 전에 같은 AI 로 검증하는 중… (%d개)') % len(todo))
        q = queue.Queue()

        def _work():
            try:
                with appdb.connect(self.db_path) as c2:
                    r = UA.ensure_verified(c2, cid)
            except Exception as e:                        # noqa: BLE001
                r = {'checked': 0, 'changed': [], 'failed': list(todo), 'why': str(e)}
            q.put(r)

        self._vg_th = threading.Thread(target=_work, daemon=True)
        self._vg_th.start()

        def _poll():
            try:
                r = q.get_nowait()
            except queue.Empty:
                self.after(150, _poll)
                return
            self._vg_th = None
            self._paint_transcript()
            if r.get('failed'):
                self._vfail_ask(len(r['failed']), cont, say)
                return
            # ★ 2026-10-21 사용자 「같은 저장 버튼을 두번씩 누르라는 것이 이상하다 · 무엇을 수정했는지 비교해주고 새 저장 버튼으로 확정」 —
            #   고친 것이 있으면 **비교 화면**(원래 글 ↔ 고친 글 · 바뀐 낱말 녹색)에서 [고친 글로 저장]/[원래 글로 저장] 한 번으로 끝낸다.
            if r.get('changed') and on_changed is not None:
                on_changed(r)                             # AI결과 창 — 최종본으로 비교(그 창이 연다)
                return
            if r.get('changed'):
                pairs = [(T('AI_VCMP_ANS', 'AI 답'), o, n) for _m, o, n in r.get('diffs') or []]

                def _old(ids=list(r['changed'])):
                    with self._conn() as c3:
                        UA.keep_original(c3, ids)
                    self._paint_transcript()
                    cont()
                self.verify_compare(pairs, on_new=cont, on_old=_old, say=say)
                return
            cont()

        self.after(150, _poll)
        return None

    def verify_compare(self, pairs, on_new, on_old, say=None):
        """★ 2026-10-21 검증 비교 창 — 위 원래 글 · 아래 고친 글(바뀐 낱말 녹색 · 빠진 낱말 줄 긋기) · 단추는 위.
        [고친 글로 저장] → on_new() · [원래 글로 저장] → on_old() · [취소]는 저장하지 않는다(말한다)."""
        import difflib
        say = say or (lambda m: self._status.config(text=m))
        w = tk.Toplevel(self)
        w.title(T('AI_VCMP_TITLE', '검증이 고친 곳 확인'))
        try:
            w.geometry('760x560')
            w.transient(self.winfo_toplevel())
        except Exception:                                 # noqa: BLE001
            pass
        bg = _C('bg', '#FDFEFE')
        w.configure(bg=bg)
        top = tk.Frame(w, bg=bg)
        top.pack(fill='x', padx=8, pady=6)
        done = {'v': False}

        def _go(fn):
            done['v'] = True
            w.destroy()
            fn()

        def _cancel():
            done['v'] = True
            w.destroy()
            say(T('AI_VCMP_CANCEL', '저장하지 않았습니다.'))
        tk.Button(top, text=T('AI_VCMP_NEW', '고친 글로 저장'), command=lambda: _go(on_new), **_kw(True)).pack(side='left', padx=2)
        tk.Button(top, text=T('AI_VCMP_OLD', '원래 글로 저장'), command=lambda: _go(on_old), **_kw(False)).pack(side='left', padx=2)
        tk.Button(top, text=T('COMMON_CANCEL', '취소'), command=_cancel, **_kw(False)).pack(side='right', padx=2)
        tk.Label(top, text=T('AI_VCMP_HINT', '같은 AI 로 검증해서 고친 곳입니다 — 녹색 = 새로 들어간 낱말 · 줄 그은 것 = 빠진 낱말'),
                 bg=bg, fg=_C('fg_dim', '#5D6D7E')).pack(side='left', padx=10)
        txt = tk.Text(w, wrap='word', relief='flat', bg=_C('view_bg', '#FFFFFF'), fg=_C('fg', '#1B2631'))
        sb = ttk.Scrollbar(w, orient='vertical', command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        txt.pack(fill='both', expand=True, padx=(8, 0), pady=(0, 8))
        txt.tag_configure('head', foreground=_C('accent', '#1A5276'), spacing1=6)
        txt.tag_configure('add', background=_C('success_bg', '#D5F5E3'))
        txt.tag_configure('del', overstrike=1, foreground=_C('fg_dim', '#7F8C8D'))
        for title, old, new in pairs:
            ow, nw = (old or '').split(' '), (new or '').split(' ')
            sm = difflib.SequenceMatcher(None, ow, nw, autojunk=False)
            txt.insert('end', '▶ %s — %s%s' % (title, T('AI_VCMP_OLDH', '원래 글'), chr(10)), 'head')
            for op, i1, i2, j1, j2 in sm.get_opcodes():
                seg = ' '.join(ow[i1:i2])
                if seg:
                    txt.insert('end', seg + ' ', () if op == 'equal' else ('del',))
            txt.insert('end', chr(10) * 2 + '▶ %s — %s%s' % (title, T('AI_VCMP_NEWH', '고친 글'), chr(10)), 'head')
            for op, i1, i2, j1, j2 in sm.get_opcodes():
                seg = ' '.join(nw[j1:j2])
                if seg:
                    txt.insert('end', seg + ' ', () if op == 'equal' else ('add',))
            txt.insert('end', chr(10) * 2)
        txt.configure(state='disabled')
        try:
            self._refont()
        except Exception:                                 # noqa: BLE001
            pass
        w.protocol('WM_DELETE_WINDOW', _cancel)
        self._vcmp_win = w
        say(T('AI_VCMP_ASK', '검증이 고친 곳이 있습니다 — 비교 창에서 저장할 글을 고르세요.'))
        return w

    def _vfail_ask(self, n, cont, say):
        """검증하지 못한 답이 있을 때 — [원본 그대로 저장] / [취소](모달 아님 · 한 번에 하나)."""
        say(T('AI_VSAVE_FAIL', '답 %d개를 검증하지 못했습니다(한도·망) — 원본 그대로 저장할까요?') % n)
        old = getattr(self, '_vfail_win', None)
        try:
            if old is not None and old.winfo_exists():
                old.destroy()
        except Exception:                                 # noqa: BLE001
            pass
        win = tk.Toplevel(self)
        win.title(T('AI_VMODE', '답 검증'))
        win.transient(self.winfo_toplevel())
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        win.configure(bg=self._bg)
        top = tk.Frame(win, bg=self._bg)
        top.pack(fill='x', padx=10, pady=(10, 4))

        def _yes():
            win.destroy()
            cont()
        _btn(top, T('AI_VSAVE_ORIG', '원본 그대로 저장'), _yes).pack(side='left')
        _btn(top, T('AI_CANCEL', '취소'), win.destroy).pack(side='left', padx=(6, 0))
        tk.Label(win, text=T('AI_VSAVE_FAIL', '답 %d개를 검증하지 못했습니다(한도·망) — 원본 그대로 저장할까요?') % n,
                 bg=self._bg, anchor='w', justify='left', wraplength=420).pack(fill='x', padx=10, pady=(0, 10))
        self._vfail_win = win
        return win

    def _save_click(self, kind):
        return self.gated(lambda: self.save_as(kind))

    def _save_settings(self):
        with self._conn() as c:
            UA.set_accounts(c, self.accounts_ui())
            try:
                i = self._integ_set_cb.current()
                if 0 <= i < len(getattr(self, '_integ_opts', [])):
                    UA.set_integ_account(c, self._integ_opts[i])
            except Exception:                             # noqa: BLE001
                pass
        self._fill_integ_set()
        w = getattr(self, '_result_win', None)
        try:
            if w is not None and w.winfo_exists():
                w._paint_integ_who()
        except Exception:                                 # noqa: BLE001
            pass
        self._load_settings()
        self._status.config(text=T('AI_SAVED', '저장했습니다 — 이 PC 의 개인 DB 에만'))

    def _paint_notice(self):
        with self._conn() as c:
            en = UA.enabled_accounts(c)
        if en:
            self._notice.pack_forget()                    # ★ 317차-21 — 키가 있으면 아무것도 안 보인다
        else:
            self._notice.config(text=T('AI_NOKEY_SHORT', '⚠ API 키가 없습니다 — [설정]'))
            if not self._notice.winfo_manager():
                self._notice.pack(side='right', padx=(8, 6), after=self._ai_btn)

    def _help_rows(self):
        return [
            (T('AI_H1', '이 화면이 하는 일'),
             T('AI_H1B2', 'AI 에게 구절·용어·연구/설교노트를 두고, 또는 Free 로 자유롭게 묻습니다. 왼쪽에서 업무와 '
                          '함께 다룰 것을 선택하고 가운데 요구사항을 적어 [전송]합니다. 보낼 글 전체는 [프롬프트] '
                          '갈래에서 칸마다 볼 수 있습니다.')),
            (T('AI_H2', '⚠ 밖으로 나가는 글'),
             T('AI_NOTICE_SHORT2', '질문과 자료는 이 PC에서 선택한 AI 회사(%s)로 바로 갑니다. 하가 앱은 그 내용을 받거나 모으지 않습니다.')
             % T('AI_H2_CO', '설정의 회사')),
            (T('AI_H8', '신앙 관점'),
             T('AI_GUARD_NOTICE', 'AI 도우미는 성경과 개신교 신앙의 관점에서 답하도록 설정되어 있습니다.')),
            (T('AI_H4', '성경교사'),
             T('AI_H4B2', '성경교사 업무를 선택하고 [교사 시작]을 누르면 AI 가 한 번에 질문 하나씩 먼저 묻습니다.')),
            (T('AI_H5', '프롬프트'),
             T('AI_H5B2', '왼쪽 항목을 누르면 아래 칸에서 그 글을 고칠 수 있고, 다른 곳을 누르면 저장됩니다. '
                          '함께 다룰 것은 오른쪽 클릭으로 고칩니다.')),
            (T('AI_H7', '못 받았을 때'),
             T('AI_H7B', '답이 오기 전에는 입력 글이 그대로 있습니다 — [보내기]를 다시 누르면 됩니다.')),
        ]

    # ── 통합 선택 팝업 — 위 구절 · 아래 왼쪽 용어 · 아래 오른쪽 연구자료 ──────
    def _open_pick(self):
        """★ 2026-10-21 (AI도우미.txt 1-1) 고르는 팝업을 걷었다 — 맨 윗줄의 콤보·검색칸으로 보낸다.
        옛 팝업은 `_open_pick_popup`(부르는 곳 없음 · 같은 `_pk_*` 이름을 쓰므로 띄우면 윗줄 칸이 끊긴다)."""
        try:
            if self._scope == 'VERSE':
                self._pk_book.focus_set()
            elif self._scope in ('TERM', 'REF'):
                self._inl_s[self._scope]['cb'].focus_set()
        except Exception:                                 # noqa: BLE001
            pass
        return None

    def _open_pick_popup(self):
        """[선택하기] — 한 창에서 구절·용어·연구자료를 선택한다(목록은 **두 번 눌러** 선택한다)."""
        if self._pick_win is not None:
            try:
                if self._pick_win.winfo_exists():
                    self._pick_win.lift()
                    return self._pick_win
            except Exception:                             # noqa: BLE001
                pass
        win = tk.Toplevel(self)
        win.title(T('AI_PICK_WIN', '닻 선택하기'))
        win.transient(self.winfo_toplevel())
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        bg = self._bg
        win.configure(bg=bg)
        top = tk.Frame(win, bg=bg)
        top.pack(fill='x', padx=8, pady=(8, 4))
        _btn(top, T('AI_CLOSE', '닫기'), win.destroy).pack(side='left')
        self._pick_msg = tk.Label(top, text='', bg=bg, fg=_C('fg_dim', '#7F8C8D'))
        self._pick_msg.pack(side='left', padx=8)
        self._pick_win = win
        vf = tk.LabelFrame(win, text=T('AI_SCOPE_VERSE', '구절'), bg=bg)
        vf.pack(fill='x', padx=8, pady=(0, 6))
        self._build_pick_verse(vf, bg)
        _btn(vf, T('AI_PICK_OK', '이 자리로'), lambda: self._pick_ok('VERSE')).pack(anchor='w', pady=(4, 2))
        low = tk.Frame(win, bg=bg)
        low.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        tf = tk.LabelFrame(low, text=T('AI_SCOPE_TERM', '용어'), bg=bg)
        tf.pack(side='left', fill='both', expand=True, padx=(0, 4))
        rf = tk.LabelFrame(low, text=T('AI_SCOPE_REF', '연구/설교노트'), bg=bg)
        rf.pack(side='left', fill='both', expand=True, padx=(4, 0))
        self._pk = {}
        for key, box in (('TERM', tf), ('REF', rf)):
            r1 = tk.Frame(box, bg=bg)
            r1.pack(fill='x')
            q = ttk.Entry(r1, width=18)
            q.pack(side='left', fill='x', expand=True)
            _btn(r1, T('AI_PICK_FIND', '찾기'), lambda k=key: self._pk_search(k)).pack(side='left', padx=(4, 0))
            q.bind('<Return>', lambda _e, k=key: self._pk_search(k))
            src = tk.StringVar(value='ALL')
            if key == 'REF':
                r2 = tk.Frame(box, bg=bg)
                r2.pack(fill='x', pady=(2, 0))
                # ★ 317차-17 — 전체 / 연구노트 / 설교노트(사용자 「user / sys 구분을 제거하라」)
                for val, lbl in (('ALL', T('COMMON_ALL', '전체')), ('STUDY', T('AI_REF_STUDYN', '연구노트')),
                                 ('SERMON', T('AI_REF_SERMN', '설교노트'))):
                    tk.Radiobutton(r2, text=lbl, value=val, variable=src, bg=bg,
                                   command=lambda k=key: self._pk_search(k)).pack(side='left', padx=(0, 6))
            lf = tk.Frame(box, bg=bg)
            lf.pack(fill='both', expand=True, pady=(2, 0))
            lb = tk.Listbox(lf, height=12, activestyle='none', exportselection=False)
            sb = ttk.Scrollbar(lf, orient='vertical', command=lb.yview)
            lb.configure(yscrollcommand=sb.set)
            sb.pack(side='right', fill='y')
            lb.pack(side='left', fill='both', expand=True)
            lb.bind('<Double-Button-1>', lambda _e, k=key: self._pick_ok(k))
            self._pk[key] = {'q': q, 'src': src, 'list': lb, 'rows': []}
            self._pk_search(key)
        win.protocol('WM_DELETE_WINDOW', win.destroy)
        return win

    def _pk_search(self, key='TERM'):
        d = (getattr(self, '_pk', None) or {}).get(key)
        if not d:
            return
        q = (d['q'].get() or '').strip()
        rows = []
        try:
            import asset_pick as AP
            with self._conn() as c:
                if key == 'REF':
                    # ★ 317차-17 — 갈래 = 연구노트 / 설교노트(내 글이 설교 갈래면 설교노트 · 공용 연구 글은 연구노트)
                    #   ⚠ 내 글·공용 글을 가르는 꼬리표는 걷었다(사용자 지시) — 닻 접두는 그대로 둔다(어느 표인가)
                    want = d['src'].get()
                    lbl_of = {'STUDY': T('AI_REF_STUDYN', '연구노트'), 'SERMON': T('AI_REF_SERMN', '설교노트')}
                    got = []
                    for k, anc in (('USER_REF', 'USER_REF'), ('REF_STUDY', 'REF_UNIT')):
                        for rid, nm in AP.candidates(c, k, q, self._lang(), PICK_CAP):
                            got.append((anc, int(rid), nm))
                    uids = [rid for anc, rid, _n in got if anc == 'USER_REF']
                    serm = set()
                    if uids:
                        serm = {r[0] for r in c.execute(
                            "SELECT ref_id FROM user_ref_asset WHERE UPPER(COALESCE(ref_type,''))='SERMON'"
                            " AND ref_id IN (%s)" % ','.join('?' * len(uids)), uids)}
                    for anc, rid, nm in got:
                        kind = 'SERMON' if (anc == 'USER_REF' and rid in serm) else 'STUDY'
                        if want not in ('ALL', kind):
                            continue
                        rows.append(('%s:%d' % (anc, rid), '[%s] %s' % (lbl_of[kind], nm) if want == 'ALL' else nm))
                    rows = rows[:PICK_CAP]
                else:
                    for eid, nm in AP.candidates(c, 'ENTITY', q, self._lang(), PICK_CAP):
                        rows.append((int(eid), nm))
        except Exception as e:                            # noqa: BLE001
            self._pick_msg.config(text=str(e)[:60])
        d['rows'] = rows
        d['list'].delete(0, 'end')
        for _v, nm in rows:
            d['list'].insert('end', nm)
        msg = (T('AI_PICK_N', '%d개') % len(rows)) if rows else T('AI_PICK_NONE', '찾은 것이 없습니다')
        if len(rows) >= PICK_CAP:
            msg += '  ' + T('AI_PICK_MORE', '— 더 있습니다. 찾기로 좁히세요')
        self._pick_msg.config(text=msg)

    def _build_pick_verse(self, box, bg):
        r1 = tk.Frame(box, bg=bg)
        r1.pack(fill='x')
        self._pk_book = ttk.Combobox(r1, state='readonly', width=16, values=[])
        self._pk_book.pack(side='left')
        self._pk_ch = ttk.Combobox(r1, state='readonly', width=5, values=[])
        self._pk_ch.pack(side='left', padx=(4, 0))
        self._pk_vs = ttk.Combobox(r1, state='readonly', width=5, values=[])
        self._pk_vs.pack(side='left', padx=(4, 0))
        tk.Label(r1, text=' ~ ', bg=bg).pack(side='left')
        self._pk_ech = ttk.Combobox(r1, state='readonly', width=5, values=[])
        self._pk_ech.pack(side='left')
        tk.Label(r1, text=':', bg=bg).pack(side='left')
        self._pk_evs = ttk.Combobox(r1, state='readonly', width=5, values=[])
        self._pk_evs.pack(side='left')
        tk.Label(r1, text=T('AI_RANGE_OPT', '(비우면 구절 하나)'), bg=bg,
                 fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=(6, 0))
        self._pk_ech.bind('<<ComboboxSelected>>', lambda _e: (self._pk_fill_evs(), self._pk_preview()))
        # ★ 317차-13 — 고른 구절 본문(사용자 「구절 본문이 표시되어야 제대로 선택했는지 확인 가능」)
        self._pk_text = tk.Label(box, text='', bg=_C('view_bg', '#FFFFFF'), fg=_C('fg', '#000000'),
                                 anchor='w', justify='left', wraplength=560, padx=6, pady=4)
        self._pk_text.pack(fill='x', pady=(4, 0))
        with self._conn() as c:
            rows = c.execute(
                "SELECT b.bcode, COALESCE(n.full_name, CAST(b.bcode AS TEXT)) FROM"
                " (SELECT DISTINCT bcode FROM bible_index) b"
                " LEFT JOIN book_names n ON n.book_code=b.bcode AND n.lang_code=?"
                " ORDER BY b.bcode", (self._lang(),)).fetchall()
        self._pk_books = [(int(r[0]), str(r[1])) for r in rows]
        self._pk_book.configure(values=[x[1] for x in self._pk_books])
        self._pk_book.bind('<<ComboboxSelected>>', lambda _e: self._pk_fill_ch())
        self._pk_ch.bind('<<ComboboxSelected>>', lambda _e: (self._pk_fill_vs(), self._pk_preview()))
        self._pk_book.bind('<<ComboboxSelected>>', lambda _e: self._pk_preview(), add='+')
        self._pk_vs.bind('<<ComboboxSelected>>', lambda _e: self._pk_preview(), add='+')
        self._pk_evs.bind('<<ComboboxSelected>>', lambda _e: self._pk_preview(), add='+')
        self.after_idle(self._pk_preview)
        i0 = 0
        if self._start:
            with self._conn() as c:
                r = c.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                              (self._start,)).fetchone()
            if r:
                for i, (bc, _nm) in enumerate(self._pk_books):
                    if bc == r[0]:
                        i0 = i
                self._pk_book.current(i0)
                self._pk_fill_ch()
                self._pk_ch.set(str(r[1]))
                self._pk_fill_vs()
                self._pk_vs.set(str(r[2]))
                self._pk_fill_ech()
                return
        self._pk_book.current(i0)
        self._pk_fill_ch()

    def _pk_preview(self):
        """구절 선택하기 팝업 — 지금 선택한 구절(구간이면 앞 몇 절)의 본문을 보인다.

        역본 = 그 언어의 기준 역본(`db_cite_gate.version_for` — 프롬프트·인용 대조와 같은 표) · 없으면 BSB.
        """
        lb = getattr(self, '_pk_text', None)
        if lb is None:
            return
        try:
            if not lb.winfo_exists():
                return
            i = self._pk_book.current()
            ch, vs = (self._pk_ch.get() or '').strip(), (self._pk_vs.get() or '').strip()
            if i < 0 or not ch or not vs:
                lb.config(text='')
                return
            bc = self._pk_books[i][0]
            ech, evs = (self._pk_ech.get() or '').strip(), (self._pk_evs.get() or '').strip()
            try:
                import db_cite_gate as CG
                ver = CG.version_for(self._lang()) or 'BSB'
            except Exception:                             # noqa: BLE001
                ver = 'BSB'
            with self._conn() as c:
                a = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                              (bc, int(ch), int(vs))).fetchone()
                if not a:
                    lb.config(text='')
                    return
                b = None
                if ech and evs:
                    b = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                                  (bc, int(ech), int(evs))).fetchone()
                hi = max(a[0], b[0]) if b else a[0]
                rows = c.execute(
                    "SELECT i.verse, x.verse_text FROM bible_index i JOIN bible_content x"
                    " ON x.verse_id=i.verse_id AND x.version_code=? WHERE i.verse_id BETWEEN ? AND ?"
                    " ORDER BY i.verse_id LIMIT 4", (ver, a[0], hi)).fetchall()
                if not rows and ver != 'BSB':
                    rows = c.execute(
                        "SELECT i.verse, x.verse_text FROM bible_index i JOIN bible_content x"
                        " ON x.verse_id=i.verse_id AND x.version_code='BSB' WHERE i.verse_id BETWEEN ? AND ?"
                        " ORDER BY i.verse_id LIMIT 4", (a[0], hi)).fetchall()
            txt = '  '.join('%s %s' % (v, (t or '').strip()) for v, t in rows)
            if hi - a[0] >= len(rows) and rows:
                txt += ' …'
            lb.config(text=txt)
        except Exception:                                 # noqa: BLE001
            pass

    def _pick_ok(self, key=None):
        """선택한 것을 닻으로 — 구절은 [이 자리로] · 용어·연구자료는 목록을 **두 번** 누른다."""
        key = key or ('VERSE' if self._scope in ('VERSE', 'FREE') else self._scope)
        try:
            if key == 'VERSE':
                i = self._pk_book.current()
                ch = (self._pk_ch.get() or '').strip()
                vs = (self._pk_vs.get() or '').strip()
                if i < 0 or not ch or not vs:
                    self._pick_msg.config(text=T('AI_PICK_NONE', '찾은 것이 없습니다'))
                    return None
                with self._conn() as c:
                    r = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                                  (self._pk_books[i][0], int(ch), int(vs))).fetchone()
                if not r:
                    self._pick_msg.config(text=T('AI_PICK_NONE', '찾은 것이 없습니다'))
                    return None
                val = int(r[0])
                end = ((self._pk_ech.get() or '').strip(), (self._pk_evs.get() or '').strip())
            else:
                d = self._pk[key]
                sel = d['list'].curselection()
                if not sel:
                    self._pick_msg.config(text=T('AI_PICK_PICK', '목록에서 하나 선택하세요'))
                    return None
                val = d['rows'][sel[0]][0]
        except Exception as e:                            # noqa: BLE001
            self._pick_msg.config(text=str(e)[:60])
            return None
        try:
            if self._pick_win is not None:
                self._pick_win.destroy()
        except Exception:                                 # noqa: BLE001
            pass
        self._pick_win = None
        if key == 'VERSE':
            self.set_anchor(val)
            if end[0] and end[1]:
                self.set_range(end[0], end[1])
        elif key == 'TERM':
            self.set_term(val)
        else:
            self.set_ref(val)
        return val

    # ── 옛 파일에서 그대로 옮긴 것 ─────────────────────────────────────
    def _title_touched(self, *_a):
        """대화 제목 — **0.7초 뒤 저절로 적는다**(프롬프트와 같은 문법).

        ⚠ 대화가 없으면 적을 곳이 없다 — 첫 전송 때 이 글자가 제목이 된다.
        """
        try:
            if self._title_job:
                self.after_cancel(self._title_job)
        except Exception:                                 # noqa: BLE001
            pass
        self._title_job = self.after(self._AUTOSAVE_MS, self._save_chat_title)

    def _save_chat_title(self):
        """지금 대화에 제목을 적는다(대화가 없으면 아무 일도 안 한다)."""
        self._title_job = None
        if not self._chat_id:
            return
        try:
            t = (self._title_ent.get() or '').strip()
        except Exception:                                 # noqa: BLE001
            return
        try:
            with self._conn() as c:
                c.execute("UPDATE user_ai_chat SET title=? WHERE chat_id=?",
                          (t, int(self._chat_id)))
                c.commit()
        except Exception:                                 # noqa: BLE001
            return
        self._load_chats()

    def chat_title(self):
        """지금 제목 칸의 글자(하네스가 읽는다)."""
        try:
            return (self._title_ent.get() or '').strip()
        except Exception:                                 # noqa: BLE001
            return ''

    def _paint_chat_title(self):
        """대화를 선택하면 그 제목을 칸에 올린다(사람이 쓰던 글은 안 덮는다)."""
        try:
            cur = (self._title_ent.get() or '').strip()
            t = ''
            if self._chat_id:
                with self._conn() as c:
                    r = c.execute("SELECT title FROM user_ai_chat WHERE chat_id=?",
                                  (int(self._chat_id),)).fetchone()
                t = (r[0] or '') if r else ''
            if cur == t:
                return
            self._title_ent.delete(0, 'end')
            if t:
                self._title_ent.insert(0, t)
        except Exception:                                 # noqa: BLE001
            pass

    def _fit_status(self, _e=None):
        """진행 라벨이 **칸 폭 안에서** 감기게 한다.

        ⚠ 옛 값 `wraplength=1` 은 좁은 가운데 칸을 전제했다 — 넓은 오른쪽 칸으로
          옮긴 뒤에는 낱말마다 줄이 바뀐다.
        ⚠⚠ **값이 같으면 손대지 않는다** — `configure` 가 `<Configure>` 를 다시
          내어 끝없는 고리가 된다(§256차 ⑰ 에서 앱이 통째로 멎던 자리).
        """
        try:
            w = max(80, self._status.winfo_width() - 8)
            if abs(int(self._status.cget('wraplength') or 0) - w) > 4:
                self._status.configure(wraplength=w)
        except Exception:                                 # noqa: BLE001
            pass

    def _refont(self):
        """화면 안 **모든 글자를 한 구역(ui) 글꼴**로 입힌다.

        ★★★ 306차 사용자 「모든 글자를 한 가지 표준서식으로 통일하라. 지금 크기
          하드코딩된 것을 제거하라」 — 실측 `font=(...)` 21곳이 9·10·12pt 로
          섞여 있었다.
        ⚠ `theme_font.register` 와 **함께 쓰지 않는다** — 두 문이 싸우면 갈린다.
        ⚠ **굵기는 이름으로** 고른다(`_BOLD`) · 성격 라벨은 따로 굵게 한다.
        ⚠ `font` 옵션이 없는 위젯(ttk 일부)은 건너뛴다 — 오류를 내지 않는다.
        """
        fam, size = '', 12
        if theme_font:
            try:
                r = theme_font.resolve(self.db_path, 'ui')
                fam, size = r.get('family') or '', int(r.get('size') or 12)
            except Exception:                             # noqa: BLE001
                pass
        # ★★★ **이 화면만 한 단계 낮춘다**(`FONT_DELTA`) — P4 몸통이 449px 뿐이라
        #   설정 크기(실측 12pt)를 그대로 쓰면 **대화 글이 35px 로 무너진다**(실측).
        #   ⚠ 「한 가지로 통일」은 지킨다 — 화면 안 모든 글자가 같은 크기이고,
        #     설정 기본을 키우면 **함께** 커진다(§36 표준서식).
        size = max(7, size + FONT_DELTA)
        plain, bold = (fam, size), (fam, size, 'bold')
        want_bold = set()
        for nm in self._BOLD:
            w = getattr(self, nm, None)
            if w is not None:
                want_bold.add(str(w))
        # ★ 317차 — 창고 칸 머리글(업무 · 함께 다룰 것 · 묻는 사람 · 내용과 형식)이 굵다
        for w in getattr(self, '_heads', []):
            want_bold.add(str(w))
        # ★ 317차-11 — AI결과 창의 칸 이름·프롬프트 단추도 굵게(그 창은 이 화면의 자식이라 함께 돈다)
        _rw = getattr(self, '_result_win', None)
        for w in (list(getattr(_rw, '_heads', [])) + [getattr(_rw, '_fq_btn', None), getattr(_rw, '_integ_tg', None)]
                  if _rw is not None else []):
            if w is not None:
                want_bold.add(str(w))

        def walk(w0):
            yield w0
            try:
                kids = w0.winfo_children()
            except Exception:                             # noqa: BLE001
                return
            for ch in kids:
                for x in walk(ch):
                    yield x

        skipped = []
        for w in walk(self):
            try:
                if 'font' not in w.keys():
                    # ⚠ **글꼴 옵션이 없는 위젯을 조용히 넘기지 않는다** — 그것이
                    #   307차에 「체크상자만 크기가 다르다」를 놓친 자리다.
                    # ⚠ **글자가 없는 위젯**은 글꼴을 입힐 것이 없다 — 흠이 아니다.
                    if w.winfo_class() not in ('Frame', 'TFrame', 'TPanedwindow',
                                               'TScrollbar', 'Toplevel', 'AIChatView',
                                               'TSeparator', 'Canvas', 'Panedwindow',
                                               'Scrollbar'):
                        skipped.append(w.winfo_class())
                    continue
                fnt = bold if str(w) in want_bold else plain
                # ★ 2026-10-21 깜빡임 — 같은 글꼴을 다시 입히면 칸이 다시 재여 출렁인다(누를 때마다 화면 전체를 돌았다)
                if getattr(w, '_hg_font', None) != fnt:
                    w.configure(font=fnt)
                    w._hg_font = fnt
                # ★★★ **`scale()` 이 이 위젯을 건드리지 못하게 표식을 남긴다**
                #   (`theme_font.MANAGED` — 그 모듈이 스스로 적어 둔 규칙이다).
                #   ⚠⚠ 이것이 없으면 `user_main._scale_new_tab` 이 **탭을 누를 때마다**
                #     10pt 를 base 단계로 재계산해 **12pt 로 되돌린다** — 「처음은 큰
                #     글자, 누르면 작아진다」의 정체다(실측으로 잡았다).
                if theme_font:
                    setattr(w, theme_font.MANAGED, True)
            except Exception:                             # noqa: BLE001
                pass
        #: 글꼴을 못 입힌 위젯 종류 — 하네스가 **0 인가**를 잰다
        self._font_skipped = sorted(set(skipped))
        self._retag_fonts()

    def _std_font(self):
        """이 화면 표준 글꼴 — `_refont` 와 같은 값(새로 짓는 단추가 잠깐이라도 다른 글꼴로 뜨지 않게)."""
        fam, size = '', 12
        if theme_font:
            try:
                r = theme_font.resolve(self.db_path, 'ui')
                fam, size = r.get('family') or '', int(r.get('size') or 12)
            except Exception:                             # noqa: BLE001
                pass
        return (fam, max(7, size + FONT_DELTA))

    def _retag_fonts(self):
        """대화 글 태그 글꼴 — **위젯 글꼴과 같은 크기**로 굵기만 바꿔 다시 건다.

        ★★★ 크기를 태그에 박으면 한 화면에 크기가 여럿이 된다(사용자 신고). 글꼴
          설정(`theme_font`)이 크기를 정하고 여기서는 **굵게/보통**만 가른다.
        ⚠ **그릴 때마다 다시 건다** — `theme_font` 가 위젯 글꼴을 바꿔도 태그는
          따라오지 않는다(§36-5b 「태그 색·글꼴은 paint 가 못 본다」 그 자리).
        """
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(font=self._out.cget('font'))
            fam, size = f.actual('family'), int(f.actual('size'))
            self._out.tag_configure('me', font=(fam, size, 'bold'))
            self._out.tag_configure('h', font=(fam, size, 'bold'))
            self._out.tag_configure('ai', font=(fam, size))
            self._out.tag_configure('qbody', font=(fam, size))
            self._out.tag_configure('sys', font=(fam, size))
            self._out.tag_configure('next', font=(fam, size))
        except Exception:                                 # noqa: BLE001
            pass

    def _load_settings(self):
        """계정을 읽어 **AI 단추 이름**을 짧게 적고 체크 변수를 만든다.

        ★★★ 겉모습은 콤보 하나(`flash-lite ▾` · `AI 2곳 ▾`)이고 누르면 목록이
          펴져 **체크를 여럿** 단다(304차 사용자 「콤보상자」 + 「복수선택 살려야
          한다」). 실측 폭 계정 둘 200px → **90px**.
        ⚠ 체크 변수는 **여기서** 만든다 — 드롭다운을 열기 전에도 계정 수와 같아야
          밖(하네스)에서 잴 수 있고, 메뉴를 닫아도 값이 살아 있다.
        """
        with self._conn() as c:
            accts = UA.accounts(c)
        self._accts = accts
        self._ai_vars = [tk.BooleanVar(value=bool(a.get('on', 1))) for a in accts]
        self._paint_ai_btn()
        self._paint_notice()

    def _paint_ai_btn(self):
        """AI 단추 글자 — **켠 것을 짧게** 말한다(이름은 `short_name` 한 문)."""
        accts = getattr(self, '_accts', None) or []
        en = [a for a, v in zip(accts, self._ai_vars) if v.get() and a.get('key')]
        if not accts:
            txt = T('AI_NO_ACCOUNT_BTN', 'AI 없음')
        elif len(en) == 1:
            txt = UA.short_name(en[0])
        elif en:
            txt = T('AI_N_ON', 'AI %d곳') % len(en)
        else:
            txt = T('AI_NONE_ON', 'AI 꺼짐')
        try:
            self._ai_btn.config(text=' %s ▾ ' % txt)
        except Exception:                                 # noqa: BLE001
            pass

    def _build_ai_menu(self):
        """AI 선택 메뉴를 **만들어 돌려준다**(띄우지 않는다).

        ⚠⚠⚠ **띄우는 일과 만드는 일을 갈랐다** — `tk_popup` 은 메뉴가 닫힐 때까지
          **모달 그랩**을 잡아 이벤트 루프를 멈춘다. 하네스가 그것을 부르면
          그 자리에서 영영 멎는다(실측으로 당했다 · §241차 ⑤-2 모달 함정 그 자리).
        """
        accts = getattr(self, '_accts', None) or []
        m = tk.Menu(self, tearoff=0)
        if not accts:
            m.add_command(label=T('AI_NO_ACCOUNT_SHORT', '계정 없음 — [설정]에서 넣으세요'),
                          command=self._open_settings)
        for idx, a in enumerate(accts):
            if idx >= len(self._ai_vars):
                break
            txt = UA.short_name(a) + ('' if a.get('key')
                                      else ' (' + T('AI_KEY_MISSING', '키 없음') + ')')
            m.add_checkbutton(label=txt, variable=self._ai_vars[idx],
                              command=lambda i=idx: self._toggle_account(i))
        self._ai_menu = m
        return m

    def _open_ai_menu(self):
        """AI 선택 — 누르면 목록이 펴지고 **체크를 여럿** 단다(복수 전송 그대로).

        ⚠ 계정이 하나도 없으면 [설정]으로 보낸다 — 빈 목록을 내지 않는다(§0-1).
        """
        m = self._build_ai_menu()
        try:
            m.tk_popup(self._ai_btn.winfo_rootx(),
                       self._ai_btn.winfo_rooty() + self._ai_btn.winfo_height())
        finally:
            try:
                m.grab_release()
            except Exception:                             # noqa: BLE001
                pass
        return m

    def _toggle_account(self, idx):
        """체크 하나를 바꾸면 그 계정의 on 만 바꿔 저장한다."""
        with self._conn() as c:
            accts = UA.accounts(c)
            if 0 <= idx < len(accts) and idx < len(self._ai_vars):
                accts[idx]['on'] = 1 if self._ai_vars[idx].get() else 0
                UA.set_accounts(c, accts)
                self._accts = accts
        self._paint_ai_btn()
        self._paint_notice()

    def _open_help(self):
        """[사용방법] — 고지와 쓰는 법을 한 자리에서 자세히(팝업 하나).

        ★ docs/1.txt 1번 「보내는 글은 … 저장됩니다 … 이 글 대신에 맨 오른쪽에
          **사용방법 버튼**을 배치하고 **자세히 설명**하는 것이 더 좋다」.
        ⚠ 고지 자체는 1열에 **짧은 한 마디로 늘 남는다**(298차 약속).
        """
        win = tk.Toplevel(self)
        win.title(T('AI_HELP', '사용방법'))
        win.geometry('640x520')
        try:
            ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        t = tk.Text(win, wrap='word', padx=10, pady=8)
        t.pack(fill='both', expand=True)
        for head, body in self._help_rows():
            t.insert('end', head + chr(10), 'h')
            t.insert('end', body + chr(10) + chr(10))
        t.tag_configure('h',
                        foreground=_C('accent', '#1A5276'), spacing1=6)
        t.configure(state='disabled')

    def _pk_fill_ch(self):
        i = self._pk_book.current()
        if i < 0 or i >= len(self._pk_books):
            return
        bc = self._pk_books[i][0]
        with self._conn() as c:
            chs = [str(x[0]) for x in c.execute(
                "SELECT DISTINCT chapter FROM bible_index WHERE bcode=? ORDER BY chapter", (bc,))]
        self._pk_ch.configure(values=chs)
        if chs:
            self._pk_ch.current(0)
        self._pk_fill_vs()

    def _pk_fill_vs(self):
        i = self._pk_book.current()
        ch = (self._pk_ch.get() or '').strip()
        if i < 0 or not ch:
            return
        bc = self._pk_books[i][0]
        with self._conn() as c:
            vs = [str(x[0]) for x in c.execute(
                "SELECT verse FROM bible_index WHERE bcode=? AND chapter=? ORDER BY sort_order",
                (bc, int(ch)))]
        self._pk_vs.configure(values=vs)
        if vs:
            self._pk_vs.current(0)
        self._pk_fill_ech()

    def _pk_fill_ech(self):
        """끝 장 목록 — **시작 장 이후만**(거꾸로 된 구간을 만들 수 없게)."""
        w = getattr(self, '_pk_ech', None)
        if w is None:
            return
        i = self._pk_book.current()
        ch = (self._pk_ch.get() or '').strip()
        if i < 0 or not ch:
            return
        bc = self._pk_books[i][0]
        with self._conn() as c:
            chs = [str(x[0]) for x in c.execute(
                "SELECT DISTINCT chapter FROM bible_index WHERE bcode=? AND chapter>=?"
                " ORDER BY chapter", (bc, int(ch)))]
        keep = (w.get() or '').strip()
        w.configure(values=chs)
        # ⚠ 사람이 고른 끝 장은 **지운다** — 시작이 바뀌면 그 끝이 뜻을 잃는다
        #   (그전 1열 콤보와 같은 규칙 · 2026-08-29 결정).
        if keep not in chs:
            w.set('')
            self._pk_evs.set('')
        self._pk_fill_evs()                  # 끝 장이 비어도 시작 장의 절 목록(끝 절만 골라도 된다)

    def _pk_fill_evs(self):
        """끝 절 목록 — 끝 장이 시작 장과 같으면 **시작 절 이후만**."""
        i = self._pk_book.current()
        ch = (self._pk_ch.get() or '').strip()
        vs0 = (self._pk_vs.get() or '').strip()
        ech_set = (self._pk_ech.get() or '').strip()
        ech = ech_set or ch                  # ★ 2026-10-21 (AI도우미.txt 4-1) 끝 장을 비우면 시작 장
        if i < 0 or not ch:
            return
        bc = self._pk_books[i][0]
        with self._conn() as c:
            if ech == ch and vs0:
                rows = c.execute(
                    "SELECT verse FROM bible_index WHERE bcode=? AND chapter=? AND verse>=?"
                    " ORDER BY sort_order", (bc, int(ech), int(vs0)))
            else:
                rows = c.execute(
                    "SELECT verse FROM bible_index WHERE bcode=? AND chapter=? ORDER BY sort_order",
                    (bc, int(ech)))
            evs = [str(x[0]) for x in rows]
        self._pk_evs.configure(values=evs)
        if (self._pk_evs.get() or '') not in evs:
            self._pk_evs.set(evs[-1] if (evs and ech_set) else '')

    def _open_settings(self):
        """[설정] — **팝업**(일회성 · 사용자 지시). 계정 줄을 늘리고 키를 넣고 [저장]."""
        if self._set_win is not None:
            try:
                if self._set_win.winfo_exists():
                    self._set_win.lift()
                    return
            except Exception:                             # noqa: BLE001
                pass
        win = tk.Toplevel(self)
        win.title(T('AI_ACCOUNTS', 'AI 계정 — 체크한 것 전부에 보냅니다'))
        win.transient(self.winfo_toplevel())
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        bg = self._bg
        win.configure(bg=bg)
        top = tk.Frame(win, bg=bg)
        top.pack(fill='x', padx=8, pady=(8, 4))
        _btn(top, T('AI_ADD_ACCOUNT', '+ 계정'), self._add_acc_row).pack(side='left')
        _btn(top, T('AI_SAVE', '저장'), self._save_settings).pack(side='left', padx=(4, 0))
        _btn(top, T('AI_CLOSE', '닫기'), win.destroy).pack(side='left', padx=(4, 0))
        self._key_hint = tk.Label(top, text='', bg=bg, fg=_C('fg_dim', '#7F8C8D'), cursor='hand2')
        self._key_hint.pack(side='left', padx=8)
        self._key_hint.bind('<Button-1>', lambda _e: self._open_key_site())
        tk.Label(win, text=T('AI_ACCOUNTS_HINT', '줄마다 회사 · 모델 · API 키. 키는 이 PC 의 개인 DB 에만 저장됩니다.'),
                 bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w').pack(fill='x', padx=8)
        # ★ 모델 안내 줄(299차-3) — 후보는 본보기라 그 키에서 404 일 수 있다. [모델 불러오기]가 정답.
        self._acc_status = tk.Label(win, text=T('AI_MODEL_HINT', '모델 칸의 목록은 본보기입니다 — 키를 넣고 [모델 불러오기]를 누르면 그 키가 실제로 쓸 수 있는 모델을 받아옵니다.'),
                                    bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', wraplength=700, justify='left')
        self._acc_status.pack(fill='x', padx=8)
        # ★ 317차-9 — **통합 담당 AI** 를 여기서 정한다(사용자 「통합담당 AI를 설정 팝업에서 세팅하도록」)
        ir = tk.Frame(win, bg=bg)
        ir.pack(fill='x', padx=8, pady=(4, 0))
        tk.Label(ir, text=T('AI_INTEG_WHO', '통합 담당'), bg=bg).pack(side='left')
        self._integ_set_cb = ttk.Combobox(ir, state='readonly', width=24)
        self._integ_set_cb.pack(side='left', padx=(4, 0))
        tk.Label(ir, text=T('AI_INTEG_WHO_HINT', '모든 AI 통합을 맡을 AI — 켠 계정 가운데 하나 · [저장]하면 적용됩니다'),
                 bg=bg, fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=8)
        # ★ 2026-10-16 답 검증 — 검증 없이 · 항상 검증 · 저장/공유할 때(기본)
        vr = tk.Frame(win, bg=bg)
        vr.pack(fill='x', padx=8, pady=(4, 0))
        tk.Label(vr, text=T('AI_VMODE', '답 검증'), bg=bg).pack(side='left')
        with self._conn() as c:
            self._vmode_var = tk.StringVar(value=UA.verify_mode(c))
        for k, ko in (('OFF', '검증 없이'), ('ALWAYS', '항상 검증'), ('SAVE', '저장/공유할 때 자동 검증')):
            tk.Radiobutton(vr, text=T('AI_VMODE_' + k, ko), value=k, variable=self._vmode_var, bg=bg,
                           command=self._save_vmode).pack(side='left', padx=(6, 0))
        tk.Label(win, text=T('AI_VMODE_HINT', '같은 AI 에게 한 번 더 물어 지어낸 이름·오탈자·없는 장절을 고칩니다(답 하나에 호출 한 번 더). '
                                              '없는 장절을 걷는 기계 검사는 늘 합니다.'),
                 bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', wraplength=700, justify='left').pack(fill='x', padx=8)
        # ★ 2026-10-21 사용자 「언어코드와 다를 경우에만 국가 입력」 — 비우면 언어로 정한 나라([국가] 자리표)
        cr = tk.Frame(win, bg=bg)
        cr.pack(fill='x', padx=8, pady=(4, 0))
        tk.Label(cr, text=T('AI_COUNTRY', '사는 나라'), bg=bg).pack(side='left')
        with self._conn() as c:
            _own = (UA.get_setting(c, 'AI_COUNTRY', '') or '').strip()
        _auto = UA.COUNTRY_OF.get(self._lang().upper()) or UA.COUNTRY_OF['EN']
        self._country_ent = ttk.Entry(cr, width=24)
        self._country_ent.insert(0, _own)
        self._country_ent.pack(side='left', padx=(4, 0))
        _hint = (T('AI_COUNTRY_AR', '아랍어는 나라가 여럿입니다 — 사는 나라를 적어 주세요') if self._lang().upper() == 'AR'
                 else T('AI_COUNTRY_HINT', '비워 두면 언어로 정합니다(%s) — 사는 나라가 다를 때만 적으세요') % _auto)
        tk.Label(cr, text=_hint, bg=bg, fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=8)

        def _save_country(_e=None):
            v = (self._country_ent.get() or '').strip()
            with self._conn() as c:
                if v and v != _auto:
                    UA.set_setting(c, 'AI_COUNTRY', v)
                else:
                    c.execute("DELETE FROM user_config WHERE config_key='AI_COUNTRY'")
                    c.commit()
        self._country_ent.bind('<FocusOut>', _save_country, add='+')
        self._country_ent.bind('<Return>', _save_country, add='+')
        self._save_country = _save_country
        # ★ 2026-10-21 「새 대화는 폰과 함께 쓰기」 걷음 — 모든 대화가 동기화 때 오간다(사용자)
        self._acc_f = tk.Frame(win, bg=bg)
        self._acc_f.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        self._acc_rows = []
        with self._conn() as c:
            accts = UA.accounts(c)
            # ★★★ **배포로 받은 목록을 읽는다**(299차-3) — 코드 상수가 아니다.
            #   회사가 판을 물리면 관리자가 고쳐 보내고 사용자는 날마다 받는다.
            self._prov = UA.providers(c)
        for a in accts or [{'provider': 'GEMINI', 'model': self._prov['GEMINI']['model'],
                            'key': '', 'on': 1}]:
            self._add_acc_row(a)
        self._fill_integ_set()
        self._set_win = win
        win.protocol('WM_DELETE_WINDOW', win.destroy)
        return win

    def _open_prayer_prompts(self):
        """기도 노트 AI 프롬프트 — 업무 여섯을 선택해 이름·글을 수정한다(지금 화면 언어 · 다른 업무로 옮기거나 닫으면 저장).

        ★ 사용자 「프롬프트는 PC 에서도 수정할 수 있어야 하고 모바일과 교환」 — 집은 `user_ai_prompt`(T_PR_*) 하나다.
        """
        w0 = getattr(self, '_pr_win', None)
        try:
            if w0 is not None and w0.winfo_exists():
                w0.lift()
                return w0
        except Exception:                                 # noqa: BLE001
            pass
        L = self._lang()
        win = tk.Toplevel(self)
        win.title(T('AI_PR_PROMPTS', '기도 프롬프트'))
        win.transient(self.winfo_toplevel())
        bg = self._bg
        win.configure(bg=bg)
        top = tk.Frame(win, bg=bg)
        top.pack(fill='x', padx=8, pady=(8, 4))
        with self._conn() as c:
            pb = UA.prayer_bundle(c, L)
        keys = [t['kind'] for t in pb['tasks']]
        cb = ttk.Combobox(top, state='readonly', width=28, values=[t['title'] for t in pb['tasks']])
        cb.pack(side='left')
        _btn(top, T('AI_SAVE', '저장'), lambda: self._pr_save()).pack(side='left', padx=(6, 0))
        _btn(top, T('AI_PR_ADD', '+ 추가'), lambda: self._pr_add()).pack(side='left', padx=(4, 0))
        self._pr_del_btn = _btn(top, T('AI_PR_DEL', '삭제'), lambda: self._pr_del())
        self._pr_del_btn.pack(side='left', padx=(4, 0))
        self._pr_reset_btn = _btn(top, T('AI_RESET', '기본으로'), lambda: self._pr_reset())
        self._pr_reset_btn.pack(side='left', padx=(4, 0))
        _btn(top, T('AI_CLOSE', '닫기'), lambda: (self._pr_save(), win.destroy())).pack(side='left', padx=(4, 0))
        tk.Label(top, text=L, bg=bg, fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=8)
        tk.Label(win, text=T('AI_PR_HINT', '폰 기도 노트의 AI 도우미가 이 글을 기도 내용·지금 상태와 함께 보냅니다(이름은 보내지 않습니다). 폰과 동기화하면 서로 바뀐 것이 오갑니다.'),
                 bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w', wraplength=640, justify='left').pack(fill='x', padx=8)
        title = ttk.Entry(win)
        title.pack(fill='x', padx=8, pady=(6, 2))
        body = tk.Text(win, height=10, wrap='word', undo=True)
        body.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        self._pr_win, self._pr = win, {'keys': keys, 'cb': cb, 'title': title, 'body': body, 'cur': None, 'lang': L}

        def _load(_e=None):
            self._pr_save()
            i = cb.current()
            if i < 0:
                return
            with self._conn() as c:
                _pid, t, b = UA.task_row(c, self._pr['keys'][i], L)
            title.delete(0, 'end')
            title.insert(0, t)
            body.delete('1.0', 'end')
            body.insert('1.0', b)
            self._pr['cur'] = (self._pr['keys'][i], t, b)
            mine = self._pr['keys'][i].startswith('T_PR_U')
            try:                                          # 내가 더한 것만 지운다 · 앱 업무만 [기본으로]
                self._pr_del_btn.config(state='normal' if mine else 'disabled')
                self._pr_reset_btn.config(state='disabled' if mine else 'normal')
            except Exception:                             # noqa: BLE001
                pass
        self._pr['load'] = _load
        cb.bind('<<ComboboxSelected>>', _load)
        cb.current(0)
        _load()
        win.protocol('WM_DELETE_WINDOW', lambda: (self._pr_save(), win.destroy()))
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        return win

    def _pr_save(self):
        """바뀐 것만 적는다(사람이 안 고쳤으면 줄을 만들지 않는다)."""
        pr = getattr(self, '_pr', None)
        if not pr or not pr.get('cur'):
            return False
        try:
            k, t0, b0 = pr['cur']
            t, b = pr['title'].get().strip(), pr['body'].get('1.0', 'end-1c').strip()
        except Exception:                                 # noqa: BLE001
            return False
        if (t, b) == (t0.strip(), b0.strip()) or not b:
            return False
        with self._conn() as c:
            UA.put_prayer_prompt(c, k, pr['lang'], title=t, body=b)
        pr['cur'] = (k, t, b)
        try:
            vals = list(pr['cb']['values'])
            vals[pr['keys'].index(k)] = t
            pr['cb'].config(values=vals)
        except Exception:                                 # noqa: BLE001
            pass
        return True

    def _pr_reload(self, kind=None):
        """목록을 다시 읽고 `kind`(없으면 첫 줄)를 고른다."""
        pr = getattr(self, '_pr', None)
        if not pr:
            return
        with self._conn() as c:
            pb = UA.prayer_bundle(c, pr['lang'])
        pr['keys'] = [t['kind'] for t in pb['tasks']]
        pr['cb'].config(values=[t['title'] for t in pb['tasks']])
        pr['cur'] = None
        pr['cb'].current(pr['keys'].index(kind) if kind in pr['keys'] else 0)
        pr['load']()

    def _pr_add(self):
        """내 기도 프롬프트를 더한다(이름·내용은 그 자리에서 고친다)."""
        pr = getattr(self, '_pr', None)
        if not pr:
            return
        self._pr_save()
        with self._conn() as c:
            k = UA.add_prayer_prompt(c, pr['lang'], T('AI_PR_NEW', '새 기도 프롬프트'),
                                     T('AI_PR_NEW_BODY', '이 기도에 대해 …를 해 주세요. 붙들 성경 구절 두세 개를 약명 장:절로 추천해 주세요.'))
        self._pr_reload(k)

    def _pr_del(self):
        pr = getattr(self, '_pr', None)
        if not pr or not pr.get('cur') or not pr['cur'][0].startswith('T_PR_U'):
            return
        with self._conn() as c:
            UA.hide_prayer_prompt(c, pr['cur'][0])
        self._pr_reload()

    def _pr_reset(self):
        """고른 업무를 처음 글(씨앗)로 되돌린다 — 칸에 넣기만 하고 저장은 [저장]·옮길 때."""
        pr = getattr(self, '_pr', None)
        if not pr or not pr.get('cur'):
            return
        k = pr['cur'][0]
        sd = UA.SEED_TASK.get(k, {})
        t, b = sd.get(pr['lang']) or sd.get('EN') or ('', '')
        pr['title'].delete(0, 'end')
        pr['title'].insert(0, t)
        pr['body'].delete('1.0', 'end')
        pr['body'].insert('1.0', b)

    def _open_key_site(self):
        import webbrowser
        try:
            keys = [p[0] for p in UA.PROVIDERS]
            r = self._acc_rows[-1] if self._acc_rows else None
            p = keys[r['prov'].current()] if r else 'GEMINI'
            webbrowser.open(UA.PROVIDER[p]['url'])
        except Exception:                                 # noqa: BLE001
            pass

    def _prov_of(self):
        """지금 쓸 회사·모델 표 — 팝업을 열 때 읽어 둔 것(없으면 코드 씨앗)."""
        return getattr(self, '_prov', None) or UA.PROVIDER

    def _add_acc_row(self, a=None):
        PV = self._prov_of()
        a = a or {'provider': 'GEMINI', 'model': PV['GEMINI']['model'], 'key': '', 'on': 1}
        if getattr(self, '_acc_f', None) is None or not self._acc_f.winfo_exists():
            return None
        row = tk.Frame(self._acc_f, bg=self._bg)
        row.pack(fill='x', pady=1)
        on = tk.BooleanVar(value=bool(a.get('on', 1)))
        tk.Checkbutton(row, text=T('AI_ON', '사용'), variable=on,
                       bg=self._bg).pack(side='left')
        keys = [p[0] for p in UA.PROVIDERS]
        prov = ttk.Combobox(row, state='readonly', width=18, values=[p[1] for p in UA.PROVIDERS])
        prov.current(keys.index(a['provider']) if a.get('provider') in keys else 0)
        prov.pack(side='left', padx=(4, 0))
        # ★ 모델 = 고르거나 적는 콤보(299차-3) — 후보는 회사마다 다르고 본보기일 뿐이다.
        #   사람이 적은 이름을 지키려고 읽기전용으로 잠그지 않는다(flash-lite 처럼 목록 밖 이름도 된다).
        p0 = keys[prov.current()]
        model = ttk.Combobox(row, width=24, values=list(PV[p0]['models']))
        model.insert(0, a.get('model') or '')
        model.pack(side='left', padx=(4, 0))
        key = ttk.Entry(row, width=34, show='•')
        key.insert(0, a.get('key') or '')
        key.pack(side='left', padx=(4, 0))
        # ★★★ **짧은 이름**(304차 사용자 「AI 이름을 짧게 표시하는 기능이 설정
        #   팝업에 필요하다」) — 비우면 모델 이름을 깎아서 쓴다(`short_name`).
        tk.Label(row, text=T('AI_LABEL', '짧은 이름'), bg=self._bg).pack(side='left', padx=(8, 2))
        lab = ttk.Entry(row, width=10)
        lab.insert(0, a.get('label') or '')
        lab.pack(side='left')
        prov.bind('<<ComboboxSelected>>', lambda _e, p=prov, m=model: (
            m.config(values=list(self._prov_of()[keys[p.current()]]['models'])),
            m.delete(0, 'end'), m.insert(0, self._prov_of()[keys[p.current()]]['model']),
            self._key_hint.config(text=T('AI_KEY_WHERE', '키 받는 곳: ')
                                  + UA.PROVIDER[keys[p.current()]]['url'])))
        rec = {'row': row, 'on': on, 'prov': prov, 'model': model, 'key': key, 'label': lab}
        rec['fetch'] = _btn(row, T('AI_MODEL_FETCH', '모델 불러오기'), lambda r=rec: self._fetch_models(r))
        # ★ 2026-10-30 키를 넣고 칸을 나가면 저절로 불러온다(docs/1.txt 4 — 모델 이름을 사람이 적지 않게)
        rec['key_seen'] = (a.get('key') or '').strip()

        def _key_out(_e=None, r=rec):
            k = r['key'].get().strip()
            if len(k) >= 20 and k != r.get('key_seen'):
                r['key_seen'] = k
                self._fetch_models(r, auto=True)
        key.bind('<FocusOut>', _key_out)
        rec['fetch'].pack(side='left', padx=(4, 0))
        tk.Button(row, text='✕', bd=0, cursor='hand2', bg=self._bg,
                  command=lambda r=rec: self._del_acc_row(r)).pack(side='left', padx=(4, 0))
        self._acc_rows.append(rec)
        # ★ 317차-12 — [+ 계정]으로 뒤에 더한 줄도 테마를 입힌다(창을 띄울 때 한 번 칠한 뒤라 안 닿았다)
        try:
            ui_theme.paint(row)
        except Exception:                                 # noqa: BLE001
            pass
        return rec

    def _fetch_models(self, rec, auto=False):
        """[모델 불러오기] — **그 줄의 키로** 회사 서버에 물어 실제로 쓸 수 있는 모델을 콤보에 담는다.

        ⚠ 일꾼 스레드가 묻고 결과는 **메인이 `after` 로 거둔다**(§279차 ⑭ — 스레드에서 Tk 를 만지지 않는다).
        ⚠ 사람이 적어 둔 모델 이름은 안 덮는다 — 목록에 없으면 그렇다고 말할 뿐이다(고르는 것은 사람).
        """
        keys = [p[0] for p in UA.PROVIDERS]
        try:
            prov = keys[rec['prov'].current()]
            key = rec['key'].get().strip()
        except Exception:                                 # noqa: BLE001
            return
        lbl = getattr(self, '_acc_status', None)
        if not key:
            if lbl is not None:
                lbl.config(text=T('AI_MODEL_FAIL', '모델 목록을 못 받았습니다: %s') % T('AI_NOKEY_SHORT', 'API 키가 없습니다'))
            return
        if lbl is not None:
            lbl.config(text=T('AI_MODEL_FETCHING', '이 키로 쓸 수 있는 모델을 불러오는 중…'))
        try:
            rec['fetch'].config(state='disabled')
        except Exception:                                 # noqa: BLE001
            pass
        box = []
        threading.Thread(target=lambda: box.append(UA.list_models(prov, key)), daemon=True).start()
        rec['auto'] = auto
        self._poll_models(rec, box, 0)

    def _poll_models(self, rec, box, n):
        if not box:
            if n < 300:                                   # 45초까지 기다린다(list_models 타임아웃 30초)
                self.after(150, lambda: self._poll_models(rec, box, n + 1))
                return
            box.append({'ok': False, 'models': [], 'why': 'timeout'})
        r = box[0]
        lbl = getattr(self, '_acc_status', None)
        try:
            rec['fetch'].config(state='normal')
        except Exception:                                 # noqa: BLE001
            pass
        try:
            if not rec['row'].winfo_exists():
                return
        except Exception:                                 # noqa: BLE001
            return
        if not r.get('ok'):
            if lbl is not None:
                lbl.config(text=T('AI_MODEL_FAIL', '모델 목록을 못 받았습니다: %s') % r.get('why', ''))
            return
        models = list(r['models'])
        rec['model'].config(values=models)
        cur = rec['model'].get().strip()
        # 저절로 불러온 때 — 모델 칸이 비었거나 그 키의 목록에 없으면 알맞은 것을 넣어 준다(사람이 적은 바른 이름은 안 덮는다)
        if rec.get('auto') and (not cur or cur not in models):
            keys = [p[0] for p in UA.PROVIDERS]
            pick = UA.best_model(keys[rec['prov'].current()], models)
            rec['model'].delete(0, 'end')
            rec['model'].insert(0, pick)
            cur = pick
        if lbl is not None:
            msg = T('AI_MODEL_GOT', '이 키로 쓸 수 있는 모델 %d개 — 모델 칸의 ▾ 에서 선택하세요.') % len(models)
            if cur and cur not in models:
                msg += '  ' + T('AI_MODEL_MISSING', '지금 적힌 「%s」은 이 키의 목록에 없습니다(보내면 404).') % cur
            lbl.config(text=msg)

    def _del_acc_row(self, rec):
        try:
            rec['row'].destroy()
        except Exception:                                 # noqa: BLE001
            pass
        self._acc_rows = [r for r in self._acc_rows if r is not rec]

    def accounts_ui(self):
        keys = [p[0] for p in UA.PROVIDERS]
        out = []
        for r in self._acc_rows:
            try:
                if not r['row'].winfo_exists():
                    continue
                out.append({'provider': keys[r['prov'].current()], 'model': r['model'].get().strip(),
                            'key': r['key'].get().strip(), 'on': 1 if r['on'].get() else 0,
                            'label': r['label'].get().strip()})
            except Exception:                             # noqa: BLE001
                pass
        return out

    def _wheel_on(self, _e=None):
        """좌 칸 위에 포인터가 오면 휠을 그 칸에 건다.

        ⚠⚠ **`bind_all` 을 늘 걸어 두면 안 된다** — 대화 글·대화목록의 스크롤까지
          이 칸이 먹는다. 들고 날 때만 걸고 뗀다.
        """
        try:
            self.bind_all('<MouseWheel>', self._wheel, add='+')
        except Exception:                                 # noqa: BLE001
            pass

    def _wheel_off(self, e=None):
        """칸을 벗어나면 휠을 뗀다.

        ⚠⚠⚠ **자식 위젯으로 들어갈 때도 `<Leave>` 가 난다** — Tk 의
          `NotifyInferior` 다(실측). 그것까지 떼면 **단추·라디오·체크상자 위에서
          휠이 안 듣는다** — 그리고 이 칸은 거의 전부가 그 위젯들이라, 사실상
          캔버스 빈 자리에서만 굴러갔다. 사용자가 「마우스 스크롤 작동하도록
          하라」를 **두 판에 걸쳐 두 번** 적은 까닭이 이것이다.
        ★ 거꾸로 `<Enter>` 의 `NotifyInferior` 는 그냥 받아도 된다(다시 걸 뿐이다).
        """
        try:
            if getattr(e, 'detail', None) == 'NotifyInferior':
                return
        except Exception:                                 # noqa: BLE001
            pass
        try:
            self.unbind_all('<MouseWheel>')
        except Exception:                                 # noqa: BLE001
            pass

    def _wheel(self, e):
        """휠 — 굴릴 것이 없으면 아무 일도 안 한다."""
        try:
            first, last = self._pcv.yview()
            if first <= 0.0 and last >= 1.0:
                return
            self._pcv.yview_scroll(int(-1 * (e.delta / 120)) or
                                   (-1 if e.delta > 0 else 1), 'units')
        except Exception:                                 # noqa: BLE001
            pass

    def ref_anchor(self):
        return self._ref

    def range_text(self):
        """지금 닻 글자(하네스가 읽는다)."""
        return self._anchor_lbl.cget('text')

    def _show_x(self, on):
        """✕ — **구간일 때만** 보인다(구절 하나로 되돌리는 문).

        ⚠ 팝업을 열지 않고도 되돌릴 수 있어야 한다 — 그것이 이 단추를 1열에
          남긴 까닭이다(구간 콤보는 팝업으로 갔다).
        """
        try:
            if on and self._scope == 'VERSE':
                if not self._x_btn.winfo_manager():
                    self._x_btn.pack(side='left', after=self._anchor_lbl, padx=(0, 4))
            elif self._x_btn.winfo_manager():
                self._x_btn.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass

    def _end_vid(self, c, end_ch, end_vs):
        """끝 장:절 → verse_id(시작과 같은 책 안에서) — 없으면 None."""
        if not self._start:
            return None
        b = c.execute("SELECT bcode FROM bible_index WHERE verse_id=?", (self._start,)).fetchone()
        if not b:
            return None
        r = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                      (b[0], int(end_ch), int(end_vs))).fetchone()
        return int(r[0]) if r else None

    def set_range(self, end_ch, end_vs):
        """끝 장:절로 구간을 만든다 — **위젯 없이 돈다**(구간 콤보는 팝업에 있다).

        ★ 밖(하네스·팝업)에서 부르는 **공개 문 하나**다. 그전에는 1열 콤보를
          눌러야만 되었고 그래서 팝업으로 옮기는 순간 길이 끊길 자리였다.
        ⚠ 거꾸로 된 구간은 만들지 않는다 — 차례는 `sort_order` 가 안다(§236차).
        """
        if not self._start:
            return None
        with self._conn() as c:
            e = self._end_vid(c, end_ch, end_vs)
            if e is None:
                return None
            o1 = c.execute("SELECT sort_order FROM bible_index WHERE verse_id=?", (self._start,)).fetchone()
            o2 = c.execute("SELECT sort_order FROM bible_index WHERE verse_id=?", (e,)).fetchone()
        if o1 and o2 and o2[0] < o1[0]:
            return None
        self.set_anchor(self._start, e)
        return e

    def _to_verse(self):
        if self._start:
            self.set_anchor(self._start, self._start)

    def _rule_line(self):
        """질문과 답을 가르는 **긴 가로줄** — 칸 폭·글꼴에서 글자 수를 잰다.

        ⚠⚠ `window_create` 로 진짜 선을 넣는 길은 **버렸다** — Text 안 embedded
          window 는 제 요구폭만 쓰고 `fill` 개념이 없어 칸 폭을 못 따라간다.
        ⚠ **0.94 배로 줄인다** — 꽉 채우면 감겨서 두 줄이 되어 보기 나쁘다.
        ⚠ 폭을 못 재면(아직 안 그려졌으면) 옛 값 40 으로 물러선다.
        """
        try:
            import tkinter.font as _tkf
            w = self._out.winfo_width()
            cw = _tkf.Font(font=self._out.cget('font')).measure('\u2500') or 0
            if w > 40 and cw > 0:
                return '\u2500' * max(8, int(w / cw * 0.94))
        except Exception:                                 # noqa: BLE001
            pass
        return '\u2500' * 40

    def messages(self):
        if not self._chat_id:
            return []
        with self._conn() as c:
            return [(r, b) for _i, r, b, _t in UA.msgs(c, self._chat_id)]

    def _busy(self, on):
        st = 'disabled' if on else 'normal'
        for b in (self._send_btn, self._teach_btn, getattr(self, '_sendchat_btn', None)):
            if b is not None:
                try:
                    b.config(state=st)
                except Exception:                         # noqa: BLE001
                    pass

    def ask_role_now(self, vid, role):
        """[전문] 「분야 ▾ ▸ AI 에게 … 관점으로 묻기」 — 그 구절을 닻으로 새 채팅을 열고 **요구사항을 채워 둔다**(보내지는 않는다).
        받은 답은 [저장 ▾] ▸ 「분야 도움말로」 가 그 분야의 내 도움말로 담는다(`role_tips.save_mine`)."""
        if not vid:
            return
        import role_tips as RT
        if self._scope != 'VERSE':
            self.set_scope('VERSE')
        self.set_anchor(int(vid))
        self._role_ask = role
        task = UA.ROLE_TASK_OF.get(role)
        if task and self._task != task:
            self._pick_task(task)                 # ★ 2026-10-21 그 분야 업무(역할 + 할 일)
        self._new_chat()
        self._role_ask = role                     # _new_chat 이 비운다 — 다시 건다
        try:
            self._paint_tasks()
        except Exception:                                 # noqa: BLE001
            pass
        try:
            txt = self.compose_text() if task else RT.ask_text(role, '')
            self._in.delete('1.0', 'end')
            self._in.insert('1.0', txt)
            self._draft_auto = txt
            self._status.config(text=T('AI_ROLE_READY', '「%s」 관점 요구사항을 채웠습니다 — 고쳐서 보내고, 답은 [저장 ▾] ▸ 「분야 도움말로」') % RT.label(role))
        except Exception as e:                            # noqa: BLE001
            print('[ask role] %s' % e)

    def analyze_link_now(self, link_id, vid):
        """★ 2026-10-14 구절 연결의 [AI 분석] — 그 연결을 닻으로 「연결 살펴보기」를 열고 바로 보낸다.

        재료 = 두 구절 · 연결 갈래 뜻 · 지금 연결설명문(`UA.materials_link`). 답의 [연결설명] 칸은
        [저장 ▾] 「연결설명문」으로 담는다(비교 화면을 거친다).
        """
        if not link_id or not vid:
            return False
        if self._scope != 'VERSE':
            self.set_scope('VERSE')
        self.set_anchor(int(vid))
        self._link = '%s%d' % (UA.LINK_PFX, int(link_id))
        try:
            self._paint_tasks()
        except Exception:                                 # noqa: BLE001
            pass
        self._pick_task('LINKAN')
        self._new_chat()
        try:
            self._in.delete('1.0', 'end')
            txt = self.compose_text()
            self._in.insert('1.0', txt)
            self._draft_auto = txt
        except Exception:                                 # noqa: BLE001
            pass
        self._send_click()
        return True

    # ★ 2026-10-21 (docs/1.txt 15번 · 사용자 「PC 설명문 : AI 분석 배치하라. 각 항목별로 따로」) —
    #   설명 칸 머리마다 [AI 분석]: 그 칸 하나만 살피게 한다. 업무 = 그 칸을 쓰는 설명문 업무(폰 설명 판 [AI 분석]과 같다)
    #   · 답의 그 칸은 [저장 ▾] 「구절 설명문으로」가 비교 화면을 거쳐 그 칸에만 담는다(다른 칸은 안 건드린다).
    DESC_ONE = {'DESC_LAY': ('DESC', 0), 'Q_DEV': ('DESC', 1), 'PRAYER': ('DESC', 2),
                'Q_RES': ('XDESC', 3), 'DESC_EXP': ('XDESC', 4)}

    def analyze_desc_now(self, vid, code, label, text):
        if not vid or code not in self.DESC_ONE or not (text or '').strip():
            return False
        task, idx = self.DESC_ONE[code]
        if self._scope != 'VERSE':
            self.set_scope('VERSE')
        self.set_anchor(int(vid))
        if self._task != task:
            self._pick_task(task)
        self._new_chat()
        lang = self._lang()
        marks = UA.DESC_MARKS.get((lang or 'KO').upper()) or UA.DESC_MARKS['EN']
        req = T('AI_DESC_ONE', '[지금 %s]\n%s\n\n위 「%s」만 살펴 주세요. 잘 짚은 점과 빠졌거나 치우친 점을 짧게 짚은 뒤, '
                               '다듬은 글을 [%s] 칸 하나로 써 주세요.') % (label, text.strip(), label, marks[idx])
        try:
            self._in.delete('1.0', 'end')
            txt = self.compose_text(question=req)
            self._in.insert('1.0', txt)
            self._draft_auto = txt
        except Exception:                                 # noqa: BLE001
            pass
        self._send_click()
        return True

    def analyze_notes_now(self, vid, end_vid=None, book=False):
        """P2 묵상노트 [AI묵상분석] — 그 구절(절 범위) · 묵상노트 분석 · Pick 은 직전값으로 맞추고 **바로 보낸다**.

        ⚠ 개인 글이 밖으로 나가는 자리다 — 부른 쪽(P2 단추)이 처음 한 번 묻는다. 여기서는 막지 않는다.
        반환 = 보낸 노트 편수(0 이면 안 보냈다).
        """
        if not vid:
            return 0
        if self._scope != 'VERSE':
            self.set_scope('VERSE')
        self.set_anchor(int(vid), end_vid)
        if self._task != 'NOTE':
            self._pick_task('NOTE')
        if bool(book) != bool(self._place_over):          # ★ 2026-10-21 도서노트 분석 = 제 자리의 Pick
            self._save_unit()
            self._place_over = 'BOOK:NOTE' if book else None
            self._load_prompts()
        self._ns_var.set('RANGE')
        self._new_chat()
        n = sum(len(g[2]) for g in self.note_groups())
        if not n:
            self._status.config(text=T('AI_NOTE_NONE2', '이 범위에 내 묵상노트가 없습니다 — 범위를 넓히거나 노트를 먼저 쓰세요'))
            return 0
        try:
            self._in.delete('1.0', 'end')
            txt = self.compose_text()
            self._in.insert('1.0', txt)
            self._draft_auto = txt
        except Exception:                                 # noqa: BLE001
            pass
        self._send_click()
        return n

    def nscope_key(self):
        """지금 선택한 묵상노트 범위 열쇠 — **보낼 때·배지·할 일 글이 같은 문을 쓴다**(§219차 ⑤)."""
        try:
            v = self._ns_var.get()
        except Exception:                                 # noqa: BLE001
            v = ''
        return v if v in UA.NOTE_SCOPES else UA.NOTE_SCOPES[0]

    def note_groups(self, scope=None):
        """그 범위에서 노트가 있는 구절마다 — `[(vid, 약명, [본문…])]`(구절 갈래·닻이 있을 때만)."""
        if self._scope != 'VERSE' or not self._start:
            return []
        try:
            with self._conn() as c:
                return UA.note_groups(c, self._start, self._end, scope or self.nscope_key(), self._lang())
        except Exception:                                 # noqa: BLE001
            return []

    def _paint_note_badges(self):
        """라디오 오른쪽 숫자 배지 — 그 범위의 내 묵상노트 편수(AI 분석 노트는 안 센다)."""
        for k, bd in getattr(self, '_ns_badge', {}).items():
            try:
                n = sum(len(g[2]) for g in self.note_groups(k)) if self._task == 'NOTE' else 0
                bd.configure(text=str(n))
            except Exception:                             # noqa: BLE001
                pass

    def notes_where(self):
        """그 범위에 노트가 있는 자리 — `[(verse_id, 약명, 편수)]`(닻이 없으면 `None`)."""
        if self._scope != 'VERSE' or not self._start:
            return None
        try:
            with self._conn() as c:
                return UA.notes_where(c, self._start, self._end, self.nscope_key(),
                                      self._lang())
        except Exception:                                 # noqa: BLE001
            return []

    def _notes_pop(self):
        """범위를 선택하면 **어느 구절에 내 묵상노트가 있는지** 보인다.

        ⚠ `messagebox` 를 쓰지 않는다 — selftest 가 「팝업을 쓰지 않는다」로 그
          이름을 잰다. 게다가 노트가 많으면 그 창은 목록을 잘라 먹는다.
        ★ 세는 잣대는 `UA.notes_where` 하나 — 실제로 실리는 것과 **같은 문**이다.
        """
        rows = self.notes_where()
        if self._notes_win is not None:
            try:
                if self._notes_win.winfo_exists():
                    self._notes_win.destroy()
            except Exception:                             # noqa: BLE001
                pass
            self._notes_win = None
        win = tk.Toplevel(self)
        win.title(T('AI_NW_WIN', '내 묵상노트가 있는 곳'))
        win.transient(self.winfo_toplevel())
        try:
            if ui_theme:
                ui_theme.adopt(win)
        except Exception:                                 # noqa: BLE001
            pass
        bg = self._bg
        win.configure(bg=bg)
        top = tk.Frame(win, bg=bg)                        # ★ 단추는 늘 위(§0)
        top.pack(fill='x', padx=8, pady=(8, 4))
        _btn(top, T('AI_CLOSE', '닫기'), win.destroy).pack(side='left')
        names = {'RANGE': T('AI_NOTES_RANGE', '이 구절·구간'),
                 'CHAPTER': T('AI_NOTES_CHAPTER', '이 장'),
                 'BOOK': T('AI_NOTES_BOOK', '이 책')}
        tk.Label(win, text=names.get(self.nscope_key(), ''), bg=bg, anchor='w',
                 fg=_C('accent', '#1A5276')).pack(fill='x', padx=8)
        if rows is None:
            # ⚠ 용어·연구자료 갈래에는 구절 축이 없다 — 그렇다고 **말한다**(§0-1).
            tk.Label(win, text=T('AI_NW_NOANCHOR', '구절을 먼저 선택하세요.'),
                     bg=bg, anchor='w', wraplength=360, justify='left').pack(
                fill='x', padx=8, pady=(2, 8))
        elif not rows:
            tk.Label(win, text=T('AI_NW_NONE', '이 범위에 내 묵상노트가 없습니다.'),
                     bg=bg, anchor='w', wraplength=360, justify='left').pack(
                fill='x', padx=8, pady=(2, 8))
        else:
            box = tk.Frame(win, bg=bg)
            box.pack(fill='both', expand=True, padx=8, pady=(2, 2))
            lb = tk.Listbox(box, height=min(14, max(3, len(rows))), width=34,
                            activestyle='none')
            sb = ttk.Scrollbar(box, orient='vertical', command=lb.yview)
            lb.configure(yscrollcommand=sb.set)
            lb.pack(side='left', fill='both', expand=True)
            sb.pack(side='left', fill='y')
            for _v, lbl, cnt in rows:
                lb.insert('end', ('%s  (%d)' % (lbl, cnt)) if cnt > 1 else lbl)
            tk.Label(win, text=T('AI_NW_N', '보낼 때 %d편을 함께 싣습니다.')
                     % sum(c for _v, _l, c in rows),
                     bg=bg, fg=_C('fg_dim', '#7F8C8D'), anchor='w',
                     wraplength=360, justify='left').pack(fill='x', padx=8, pady=(2, 8))
        self._notes_win = win
        win.protocol('WM_DELETE_WINDOW', win.destroy)
        return win

    def _pump(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:                                 # noqa: BLE001
            return
        try:
            r = self._q.get_nowait()
        except queue.Empty:
            try:
                self._status.config(text=T('AI_SENT', '%s 에 보냈습니다 · 답을 기다리는 중 … %d초')
                                    % (self._sent_to, int(time.time() - self._t0)))
            except Exception:                             # noqa: BLE001
                pass
            self.after(120, self._pump)
            return
        self._th = None
        self._pending_user = ''
        self._pending_att = ''
        self._busy(False)
        why = str(r.get('why', '') or '')
        n_got = sum(1 for x in (r.get('results') or []) if x.get('ok'))
        # ★★★ 317차-6 — **하나라도 받았으면 받은 것이다**(사용자 「gpt 가 오류이면 제미나이도 안되는
        #   것 같다 · 정상은 작동하고 비정상만 오류메시지」). 옛 판은 `not why` 를 함께 걸어
        #   한 계정만 실패해도 통째로 실패로 보였다(받은 답은 저장돼 있었는데 상태 줄이 실패라 했다).
        got = n_got > 0
        fails = [x for x in (r.get('results') or []) if not x.get('ok')]
        # ★★★ **성공했을 때만 입력 칸을 비운다** — 실패면 글을 그대로 둔다.
        try:
            self._in.config(state='normal')
            if got:
                self._in.delete('1.0', 'end')
                self._draft_auto = ''
                self._sent_text = ''
        except Exception:                                 # noqa: BLE001
            pass
        self._paint_transcript()
        self._load_chats()
        self._changed()
        n_ok = sum(1 for x in (r.get('results') or []) if x.get('ok'))
        secs = int(time.time() - self._t0)
        # ★ 300차 — 404 로 모델을 **스스로 바꿨으면 그렇다고 말한다**(조용히 안 고친다).
        #   되돌리려면 [설정] 콤보에 이미 새 이름이 들어 있다.
        tail = ''.join(' · ' + (T('AI_SWITCHED', '모델을 %s 에서 %s 로 바꿨습니다') % (o, nm))
                       for _p, o, nm in (r.get('switched') or []))
        tail += ''.join(' · ' + (T('AI_BUSY_SW', '%s 가 붐벼서 %s 로 답을 받았습니다') % (o, nm))
                        for _p, o, nm in (r.get('busy') or []))
        # ★ 317차-7 — 실패한 AI 도 비교 화면에 칸으로 보인다(「GPT 칸이 없어 셋으로 나뉘는지 모르겠다」)
        self._last_fails = (self._chat_id, [(x.get('provider', ''), x.get('model', ''), x.get('why', ''))
                                            for x in fails])
        if got:
            # ★ 2026-10-21 사용자 — 답이 와도 **팝업을 저절로 띄우지 않는다**(이 화면에서 저장까지 ·
            #   여러 AI 를 견줄 때만 [대화통합화면]). 저장 단추를 다시 보인다(새 답이 왔다).
            #   ★ **AI 둘 이상이 답했을 때만** 대화통합화면을 띄운다 — `send` 는 켠 AI 모두를 기다렸다가
            #   한꺼번에 돌려주므로 이 결과 목록의 「받음」 수가 곧 도착한 답의 수다.
            self._sync_save_btn()
            if n_ok >= 2:
                self.after(60, self.open_results)
        self._sync_cmp_btn()
        if got:
            ftxt = ''
            if fails:
                # ★ 실패한 AI 만 그 까닭을 사람 말로 — 받은 답은 그대로 쓴다
                ftxt = ' · ' + T('AI_GOT_FAIL', '못 받음') + ': ' + ' / '.join(
                    '%s(%s)' % (x.get('model') or x.get('provider') or '?', self._why_short(x.get('why', '')))
                    for x in fails)
            self._status.config(text=T('AI_GOT', '답 %d개 받음 · %d초') % (n_ok, secs) + ftxt + tail)
        else:
            # ★ 429 는 **사람 말로** — 「HTTP 429 {…}」를 그대로 보이면 무엇을
            #   해야 하는지 알 수 없다(§0-1). 한도는 **키마다가 아니라 구글
            #   프로젝트마다**라 키를 더 넣어도 같은 프로젝트면 안 늘어난다.
            msg = why
            if '429' in why or 'quota' in why.lower():
                msg = T('AI_QUOTA',
                        '오늘 쓸 수 있는 양을 다 썼습니다 — 잠시 뒤에 다시 '
                        '누르거나 [설정]에서 다른 모델을 선택하세요. (한도는 키마다가 '
                        '아니라 구글 프로젝트마다입니다)')
            self._status.config(
                text=T('AI_FAILED', '못 받았습니다: ') + msg + tail + ' · '
                + T('AI_KEPT', '입력한 글은 그대로 있습니다 — [보내기] 를 다시 누르세요'))
        self._after_prompt()      # ★ 첫 말이 나갔으면 [교사 시작] → [전송] · 프롬프트 칸은 「이어지는 말」
        try:
            self._in.focus_set()
        except Exception:                                 # noqa: BLE001
            pass

    def _why_short(self, why):
        """실패 까닭을 짧은 사람 말로 — 「HTTP 401 {…}」를 그대로 보이지 않는다."""
        w = str(why or '')
        lw = w.lower()
        if '429' in w or 'quota' in lw:
            return T('AI_WHY_QUOTA', '오늘 한도')
        if '401' in w or '403' in w or 'api key' in lw or 'invalid' in lw:
            return T('AI_WHY_KEY', '키 오류')
        if '404' in w:
            return T('AI_WHY_MODEL', '모델 이름')
        if '연결' in w or 'timed out' in lw or 'timeout' in lw or 'urlopen' in lw:
            return T('AI_WHY_NET', '연결 실패')
        return (w[:40] + '…') if len(w) > 40 else w

    def merge_q(self):
        """연구자료에 **물음(프롬프트)도 담을까** — 기본은 아니다(312차)."""
        try:
            return bool(self._mq_var.get())
        except Exception:                                 # noqa: BLE001
            return False

    def _save_mq(self):
        """체크를 바꾸는 순간 저장한다 — 매번 다시 켜게 하면 아무도 안 쓴다."""
        try:
            with self._conn() as c:
                UA.set_setting(c, 'AI_MERGE_Q', '1' if self.merge_q() else '')
        except Exception:                                 # noqa: BLE001
            pass

    def _load_mq(self):
        """저장해 둔 체크를 올린다(화면을 열 때 한 번)."""
        try:
            with self._conn() as c:
                v = (UA.get_setting(c, 'AI_MERGE_Q', '') or '').strip()
            self._mq_var.set(bool(v))
        except Exception:                                 # noqa: BLE001
            pass

    def _save_ref(self, title=None):
        """실제로 담는 자리 — 제목을 물은 뒤(또는 기존 편일 때) 한 번.

        ⚠ 프롬프트(사용자 말)는 **기본으로 안 담는다** — 체크가 그것을 정한다(312차).
        """
        if not self._chat_id:
            return None
        with self._conn() as c:
            had = UA.ref_of(c, self._chat_id)
            rid = UA.save_as_ref(c, self._chat_id, lang=self._lang(), title=title,
                                 with_q=self.merge_q())
            name = UA.ref_title(c, rid)
        # ★★★ **두 번 눌러도 한 편이다** — 덮었으면 그렇다고 말한다(조용히 안 고친다).
        if had and rid == had:
            self._status.config(text=T('AI_SAVED_REF_UPD',
                                       '「내 자료」 #%s 를 지금 대화로 **고쳤습니다** (새 편을 만들지 않습니다)') % rid)
        else:
            self._status.config(text=T('AI_SAVED_REF2',
                                       '「%s」 한 편으로 「내 자료」에 담았습니다 (#%s)') % (name, rid))
        if callable(self.on_saved):
            try:
                self.on_saved(rid)
            except Exception:                             # noqa: BLE001
                pass
        return rid

    def _copy(self):
        if not self._chat_id:
            return
        with self._conn() as c:
            txt = UA.merge_text(c, self._chat_id, self._lang())
        try:
            self.clipboard_clear()
            self.clipboard_append(txt)
            self._status.config(text=T('AI_COPIED', '대화를 복사했습니다.'))
        except Exception:                                 # noqa: BLE001
            pass

    def _lock_row2(self):
        """2열 높이를 **성격 다섯 줄 기준으로 못 박는다**.

        ★★★ 306차 사용자 「구절/용어/연구자료 클릭할 때마다 **아래에 버튼 위치가
          서로 달라지는** 너무 황당한 배치방식 당장 수정하라」.
        ⚠⚠⚠ 실측 성격 줄이 **구절 5 · 용어 3 · 연구자료 2** 라 2열이 136 → 90 →
          68px 로 오르내렸고 그 아래가 통째로 움직였다.
        ★ 높이 = **한 줄 × (성격 수 + AI 줄)** 과 지금 요구 높이 중 큰 값.
          ⚠ 항목이 두 줄로 감기면 더 높아야 하므로 **줄지 않게 최대치를 기억**한다.
        ⚠ **빈 줄을 그리지 않는다**(§0-1) — 자리만 예약하고 단추는 안 만든다.
        """
        # ⚠⚠ **308차부터 할 일이 없다** — 2열을 **좌/중/우 세 칸**으로 나누어
        #   칸마다 전체 높이를 쓰므로 프롬프트와 대화 글이 높이를 다투지 않는다.
        #   그전에는 네 줄을 쌓느라 갈래마다 높이가 오르내렸다(그 자리를 못 박던 문).
        #   ★ 이름은 남긴다 — 부르는 자리가 둘이고 되돌릴 자리다.
        return


def selftest():
    """화면 없이 재는 것 — 부품 이름·흐름은 하네스(`temp_code_p317_aichat.py`)가 잰다."""
    ok = [0, 0]

    def ck(c, m):
        ok[0 if c else 1] += 1
        if not c:
            print('  FAIL', m)
    ck(callable(AIChatView.set_anchor) and callable(AIChatView.set_term) and callable(AIChatView.set_range), '진입 문이 있다')
    ck('messagebox' not in globals() and 'simpledialog' not in globals(), '팝업을 쓰지 않는다(외부 전송은 늘 보이는 글로)')
    ck(all(not (n.startswith('sys_') or n == 'sqlite3') for n in globals()), 'sys 표를 직접 다루는 이름이 없다')
    ck(SCOPES[0] == 'FREE' and set(PART_ORDER) <= set(UA.SLOTS), '갈래 넷(Free 처음) · 내용 칸은 보낼 칸 안에서')
    ck(all(callable(getattr(AIChatView, n, None)) for n in ('compose_text', 'set_view', 'set_chat_filter',
                                                           '_one_text', '_build_save_menu', '_edit_open')),
       '317차 문이 있다')
    print('%d/%d PASS' % (ok[0], ok[0] + ok[1]))
    return 0 if not ok[1] else 1


if __name__ == '__main__':
    import sys
    sys.exit(selftest())
