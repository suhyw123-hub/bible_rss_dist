import tkinter as tk
import i18n
import sqlite3
import appdb

class BibleP4TreeCanvas(tk.Canvas):
    def __init__(self, master, db_path, lang, ver, **kwargs):
        # 🎯 [수정] 메인에서 넘겨준 모든 커스텀 콜백을 kwargs에서 제거하여 TclError를 방지합니다.
        bg_color = kwargs.pop('bg', "#F7F9F9")
        self.on_node_click = kwargs.pop('on_node_click', None)
        self.on_node_double_click = kwargs.pop('on_node_double_click', None)
        self.on_node_release = kwargs.pop('on_node_release', None)
        # [2026-06-04] on_peri_click 제거 — P 마커 폐기 (탭 직접 클릭으로 대체)
        self.on_chain_click = kwargs.pop('on_chain_click', None)  # C 마커 클릭 핸들러 (vid, [chain_codes])

        super().__init__(master, bg=bg_color, highlightthickness=0, **kwargs)

        self.db_path = db_path
        self.lang = lang
        self.ver = ver
        self.expand_callback = None
        self._chain_cache = {}  # vid → [chain_codes] 메모리 캐시 (1회 조회 후 재사용)
        self.config(scrollregion=(-5000, -5000, 5000, 5000))
        self.bind("<ButtonPress-1>", self._on_pan_start)
        self.bind("<B1-Motion>", self._on_pan_drag)
        # ── 리사이즈 재중심 (2026-08-20 사용자 지시 — 「리사이즈에 관계없이
        #    항상 루트가 상하 폭의 중간에」). focus_on_coordinate 가 마지막
        #    초점을 기억해 두고, 창 크기가 바뀌면 같은 초점으로 다시 맞춘다.
        #    ⚠ 사용자가 손으로 팬·휠 스크롤한 뒤에는 되돌리지 않는다 —
        #      멀리 있는 노드를 보다가 창만 줄였는데 시점이 루트로 튀면
        #      그것이 더 나쁘다. 다음 focus 호출이 깃발을 다시 내린다.
        # 캔버스 설정(글꼴·크기·굵기) 마지막 값 — 다시 그릴 때 이것을 쓴다
        self.style_defaults = {}
        self._last_focus = None       # (x, y, margin_x)
        self._user_moved = False      # 팬·휠 이후 True
        self._refocus_job = None      # <Configure> 폭주 방지 디바운스
        self.bind("<Configure>", self._on_canvas_resize, add='+')

    def _get_chain_codes(self, vid):
        """vid가 멤버인 chain_code 리스트 반환 (PRG/DEP만 — 흐름 chain).
        INC/REV는 pair 단위라 슬라이드 패널 의미 없음 → 제외.
        메모리 캐시 사용."""
        try:
            vid_i = int(vid)
        except (TypeError, ValueError):
            return []
        if vid_i in self._chain_cache:
            return self._chain_cache[vid_i]
        try:
            with appdb.connect(self.db_path) as c:
                rows = c.execute(
                    "SELECT DISTINCT chain_code FROM sys_link_asset "
                    " WHERE chain_code IS NOT NULL AND record_status='LIVE' "
                    "   AND link_type='VERS_VERS' "
                    "   AND rel_code IN ('PRG', 'DEP') "
                    "   AND (clicked_id=? OR target_id=?) "
                    " ORDER BY chain_code", (vid_i, vid_i)).fetchall()
            codes = [r[0] for r in rows]
        except Exception:
            codes = []
        self._chain_cache[vid_i] = codes
        return codes

    def invalidate_chain_cache(self):
        """chain 데이터가 갱신됐을 때 캐시 비움."""
        self._chain_cache.clear()

    # 배지 판 농도 — 0 = 박스색 그대로, 1 = 완전히 흰(밝은 테마)/검은(어두운 테마).
    # ⚠ **캔버스 바탕색과 섞으면 안 된다**(2026-08-21 실측). 바탕이 청회색인데
    #   노드 박스는 노란색이라, 섞으면 **색상만 돌고 밝기는 그대로**여서
    #   (213.4 → 212.0) 「옅어졌다」가 눈에 안 보였다. 흰/검정 쪽으로 섞어야
    #   같은 색이 **연해진다.**
    BADGE_TINT = 0.45

    def _mix(self, c1, c2, t):
        """두 색을 t 만큼 섞는다. ⚠ `winfo_rgb` 는 **16비트**를 준다(÷257)."""
        try:
            a = self.winfo_rgb(c1)
            b = self.winfo_rgb(c2)
        except Exception:
            return c1
        return '#%02x%02x%02x' % tuple(
            max(0, min(255, int((a[i] * (1 - t) + b[i] * t) / 257))) for i in range(3))

    def _tint_target(self):
        """옅게 만들 방향 — 밝은 테마면 흰 쪽, 어두운 테마면 검은 쪽.
        판정은 **캔버스 바탕의 밝기**로 한다(테마 이름에 기대지 않는다)."""
        try:
            r, g, b = self.winfo_rgb(self.cget('bg') or '#FFFFFF')
            return '#FFFFFF' if (0.299 * r + 0.587 * g + 0.114 * b) / 257 > 128 else '#000000'
        except Exception:
            return '#FFFFFF'

    def _draw_badge(self, view_id, count, c, fam, size, bg, text=None,
                    plus=False, minus=False, faint=False):
        """배지 = **넓은 클릭 판 + 숫자**. `c` = 박스 실좌표 [x1,y1,x2,y2].

        ★ 숫자 글자만 누를 수 있으면 「조금만 벗어나도 인식이 안 된다」
          (2026-08-20 사용자). 숫자 좌우로 **두 칸씩 더** 잡은 투명 판을
          깔고 거기에 바인딩한다 — 보이는 것은 그대로, 누르기만 쉬워진다.
        ⚠ 판을 **숫자보다 먼저** 그린다(나중에 그린 것이 위에 온다).
        ⚠ 판 색은 박스와 같게(테두리 없음) — 「공간 색상을 다르게 하면
          혼란스럽다」는 지시를 지킨다.
        text — 숫자 대신 그릴 글(2026-08-26 ③ 표시 상한: 「10/42」·「11~20/42」).
          박스 폭이 모자라면(스냅샷 복원 등 예약 없이 지어진 박스) 숫자로
          물러난다 — 이름을 덮는 것(§51 「빛이 있으」 사고)보다 낫다.
        plus/minus — 박스 **바깥** 위 ＋ / 아래 − (2026-09-02 사용자 확정).
          ＋ = 다음 묶음을 아래에 추가(`on_plus_click`) ·
          − = 마지막 묶음 걷기(`on_minus_click`).
        """
        badge_tag = f"bdg_{view_id.replace(':', '_')}"
        disp = str(text) if text else str(int(count or 0))
        # ★ 2026-10-07 (docs/1.txt 51-1) — 배지 수를 장부에도 적는다. 트리뷰가 이 값으로
        #   「아직 안 펼친 자녀가 있는 줄」에 ▸ 를 단다(DB 를 다시 안 센다 — 세는 문이 둘이면
        #   캔버스 배지와 트리 ▸ 가 갈린다).
        if view_id in self.nodes:
            self.nodes[view_id]['badge'] = int(count or 0)
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(family=(fam or ''), size=int(size or 9), weight='bold')
            # ⚠ **두 칸으로 줄였다** (2026-08-21 사용자 「구절번호 근처에서
            #   클릭해도 배지로 인식한다. 줄여라」). 49차에 네 칸으로 넓혔는데,
            #   짧은 약명은 박스가 최소폭(120)으로 늘어나면서 판이 이름 쪽으로
            #   깊이 들어왔다.
            pad2 = f.measure('  ')
            _nx2 = (self.nodes.get(view_id, {}) or {}).get('name_x2')
            # 두 줄 표기(「10↵/38」)는 **조금 작은 글자**로 (2026-08-26 사용자)
            bf = f
            if '\n' in disp:
                bf = tkfont.Font(family=(fam or ''),
                                 size=max(7, int(size or 9) - 2), weight='bold')
            if text:
                # 글이 자리를 침범하면 숫자로 물러난다(§51 덮개 사고 방지).
                # 폭은 이름 끝까지, **높이는 박스 안**을 잰다 — 예약 없이
                # 지어진 박스(스냅샷 복원)에서 두 줄이 밖으로 새면 안 된다.
                _lines = disp.split('\n')
                _avail = c[2] - self.BOX_PAD_X - ((_nx2 + self.BOX_GAP)
                                                  if _nx2 is not None else (c[0] + 2))
                _havail = (c[3] - c[1]) - 2
                if (max(bf.measure(x) for x in _lines) > _avail
                        or bf.metrics('linespace') * len(_lines) > _havail):
                    disp = str(int(count or 0))
                    bf = f
            w2 = max(f.measure('88'),
                     max(bf.measure(x) for x in disp.split('\n')))
            plus_w = f.measure('＋') + pad2
        except Exception:
            bf = (fam, size, 'bold')
            pad2, w2, plus_w = 8, 16, 20
        y = (c[1] + c[3]) / 2
        x2 = c[2]                                  # 오른쪽 끝까지 (틈 없이)
        x1 = max(c[0] + 2, c[2] - self.BOX_PAD_X - w2 - pad2)
        # ★ **이름 자리를 절대 침범하지 않는다** — 박스가 최소폭으로 늘어나도
        #   판은 이름 끝에서 BOX_GAP 만큼 떨어진 곳에서 시작한다. 이 한 줄이
        #   없으면 짧은 약명(계3:13)에서 판이 번호 바로 옆까지 왔다(실측).
        nx2 = (self.nodes.get(view_id, {}) or {}).get('name_x2')
        if nx2 is not None:
            x1 = max(x1, nx2 + self.BOX_GAP)
        # ★ **두 단계 농도** (2026-08-21 사용자 채택) — 왼쪽(이름)은 박스색
        #   그대로, 오른쪽(배지)은 배경 쪽으로 섞어 **옅게**. 「누르면 펼쳐지는
        #   곳」이 눈에 보인다.
        #   ⚠ 다른 색이 아니라 **같은 색의 옅은 단계**다 — 49차 「공간 색상을
        #     다르게 하면 혼란스럽다」와 어긋나지 않는다.
        #   ⚠ 그라데이션(띠 20~30개)은 안 쓴다 — 박스마다 항목이 그만큼 늘고
        #     경계가 흐려져 「어디부터 배지인가」를 오히려 못 알려준다.
        plate_bg = self._mix(bg, self._tint_target(), self.BADGE_TINT)
        if faint:
            # 연결은 있는데 이미 다 화면에 있다(0) — 판을 더 옅게 (52-1)
            plate_bg = self._mix(bg, self._tint_target(), min(0.9, self.BADGE_TINT * 1.8))
        self.create_rectangle(x1, c[1] + 1, x2, c[3] - 1,
                              fill=plate_bg, outline='', tags=(view_id, badge_tag))
        self.create_text(c[2] - self.BOX_PAD_X, y, text=disp,
                         anchor='e', justify='right',
                         fill=self._C('fg_dim', '#7F8C8D'),
                         font=bf,
                         tags=(view_id, badge_tag, "badge"))
        nid = self.nodes.get(view_id, {}).get('node_id')
        self.tag_bind(badge_tag, "<Button-1>",
                      lambda e, n=nid, v=view_id: self._on_badge_click(n, v))
        # ── ＋/− 단추 = **박스 바깥, 배지 위/아래** (2026-09-02 사용자 확정 —
        #   「＋ 표시와 숫자의 간격이 좁은데 오클릭 위험도 있다. 차라리 박스
        #   바깥쪽에 배지 위 ＋, 아래에 −」).
        #   옛 안쪽 ＋ 판(§49)은 박스 폭이 이름+배지에 재단돼 자리가 없어
        #   **한 번도 그려지지 못한 죽은 코드**였다 — 밖으로 나오면서 폭
        #   문제가 사라졌다. 판이 배지와 떨어져 있어 오클릭도 없다.
        #   ＋ = 다음 묶음을 **아래에 추가** · − = 마지막에 추가한 묶음 걷기.
        _bx = c[2] - self.BOX_PAD_X - w2 / 2      # 배지 숫자의 세로축
        try:
            _gh = f.metrics('linespace')
        except Exception:
            _gh = 14
        _half = max(9, _gh // 2 + 2)
        if plus:
            plus_tag = f"pls_{view_id.replace(':', '_')}"
            _cy = c[1] - _half - 2                 # 박스 위 바깥
            plus_bg = self._mix(bg, self._tint_target(), self.BADGE_TINT * 2)
            self.create_rectangle(_bx - _half, _cy - _half, _bx + _half, _cy + _half,
                                  fill=plus_bg, outline='',
                                  tags=(view_id, plus_tag))
            self.create_text(_bx, _cy, text='＋', anchor='center',
                             fill=self._C('fg', '#2C3E50'),
                             font=(fam, size, "bold"),
                             tags=(view_id, plus_tag))
            self.tag_bind(plus_tag, "<Button-1>",
                          lambda e, n=nid, v=view_id: self._on_plus_click(n, v))
        if minus:
            minus_tag = f"mns_{view_id.replace(':', '_')}"
            _cy = c[3] + _half + 2                 # 박스 아래 바깥
            minus_bg = self._mix(bg, self._tint_target(), self.BADGE_TINT * 2)
            self.create_rectangle(_bx - _half, _cy - _half, _bx + _half, _cy + _half,
                                  fill=minus_bg, outline='',
                                  tags=(view_id, minus_tag))
            self.create_text(_bx, _cy, text='−', anchor='center',
                             fill=self._C('fg', '#2C3E50'),
                             font=(fam, size, "bold"),
                             tags=(view_id, minus_tag))
            self.tag_bind(minus_tag, "<Button-1>",
                          lambda e, n=nid, v=view_id: self._on_minus_click(n, v))

    def _on_plus_click(self, node_id, view_id):
        """＋ 클릭 = 다음 묶음을 아래에 추가 (user_main._on_plus_next 로 위임)."""
        cb = getattr(self, 'on_plus_click', None)
        if cb:
            try:
                cb(node_id, view_id)
            except Exception as e:
                print(f'[plus click] {e}')

    def _on_minus_click(self, node_id, view_id):
        """− 클릭 = 마지막에 추가한 묶음 걷기 (user_main._on_minus_prev 로 위임)."""
        cb = getattr(self, 'on_minus_click', None)
        if cb:
            try:
                cb(node_id, view_id)
            except Exception as e:
                print(f'[minus click] {e}')

    def _on_badge_click(self, node_id, view_id):
        """배지 클릭 = **자녀 펼치기만** (2026-08-20 사용자 설계).

        박스(이름) 클릭은 읽기 — 탭모음이 그 구절로 바뀐다. 배지를 누르면
        **탭모음은 그대로 둔 채** 자녀만 펼쳐진다. 「펼치는 것과 읽는 것을
        분리하자」는 지시의 구현.
        """
        cb = getattr(self, 'on_badge_click', None)
        if cb:
            try:
                cb(node_id, view_id)
            except Exception as e:
                print(f'[badge click] {e}')

    def update_badge(self, view_id, count, text=None, plus=False, minus=False,
                     faint=False):
        """우상단 배지를 다시 그린다 — **이 박스를 누르면 나올 개수**.

        캔버스에 노드가 늘고 줄 때마다 그 수가 변하므로 그릴 때 한 번으로는
        반드시 낡는다 — user_main._refresh_all_badges 가 펼침/접힘 뒤 전 노드에
        대해 부른다.
        ★ **0 도 그린다**(2026-08-20 사용자 확정) — 안 그리면 「다 펼쳤다」와
          「연결이 없다」와 「고장났다」가 구별되지 않는다.
        ⚠ 위치는 장부의 x,y 가 아니라 **박스 실좌표**에서 계산한다 — 드래그로
          옮긴 노드는 장부 좌표가 낡아 있다.
        text·plus — 표시 상한 표기(「10/42」·「11~20/42」+＋, 2026-08-26 ③).
        """
        rect_tag = f"rect_{view_id.replace(':', '_')}"
        badge_tag = f"bdg_{view_id.replace(':', '_')}"
        plus_tag = f"pls_{view_id.replace(':', '_')}"
        minus_tag = f"mns_{view_id.replace(':', '_')}"
        try:
            for iid in list(self.find_withtag(badge_tag)):
                self.delete(iid)
            for iid in list(self.find_withtag(plus_tag)):
                self.delete(iid)
            for iid in list(self.find_withtag(minus_tag)):
                self.delete(iid)
            rc = self.find_withtag(rect_tag)
            if not rc:
                return
            c = self.coords(rc[0])
            info = self.nodes.get(view_id, {})
            fam, size = info.get('fstyle', ('', 9))
            bg = info.get('boxbg') or self._C('panel', '#FFFFFF')
            self._draw_badge(view_id, count, c, fam, size, bg,
                             text=text, plus=plus, minus=minus, faint=faint)
        except Exception:
            pass

    # 박스 규격 — 최소는 옛 고정값(120×30)과 같게 두어 구절 박스가 안 흔들린다
    BOX_MIN_HALF_W = 60
    BOX_MAX_HALF_W = 150      # 아주 긴 이름은 여기서 멈춘다(줄이 밀리지 않게)
    BOX_PAD_X = 10            # 박스 안 좌우 여백(한쪽)
    BOX_PAD_Y = 7             # 글자 상하 여백(한쪽)
    BOX_GAP = 16              # 이름 ↔ 배지 사이 (2026-08-20 사용자 「간격을 충분히」)

    BOX_MAX_LINES = 8         # 폭 기준일 때도 이만큼에서 멈춘다(무한히 길어지지 않게)
    MIN_WRAP_CHARS = 6        # 줄 수를 정해도 한 줄이 이보다 좁아지지는 않는다

    def wrap_label(self, label, a_type=None):
        """렌즈노드 이름을 설정대로 여러 줄로 나눈다 → 줄 목록.

        ★ **한 축을 정하면 나머지는 글자에서 나온다** (2026-08-20 사용자 설계):
          · 'H' 줄 수를 정한다 → **폭은 자동**(글자 수 ÷ 줄 수)
          · 'W' 글자 수를 정한다 → **줄 수(높이)는 자동**
        ★ 정한 줄 수는 **상한**이다 — 이름이 짧으면 그보다 낮은 박스가 된다
          (렌즈노드 이름 평균 11자라 늘 3줄로 고정하면 빈칸만 생긴다).
        ⚠ **구절 박스는 손대지 않는다** — 약명은 규격이 정해져 있어 조절할
          필요가 없다(사용자). 여기서 갈라 두지 않으면 설정이 구절까지 흔든다.
        """
        s = str(label or '')
        if a_type == 'BIBLE' or not s:
            return [s]
        d = getattr(self, 'style_defaults', {}) or {}
        mode = str(d.get('node_mode', 'H') or 'H').upper()
        import textwrap
        if mode == 'W':
            width = max(2, int(d.get('node_chars', 14) or 14))
            lines = textwrap.wrap(s, width=width) or [s]
            return lines[:self.BOX_MAX_LINES]
        n = max(1, int(d.get('node_lines', 1) or 1))
        if n <= 1:
            return [s]
        # 줄 수를 정했으니 폭을 거기서 되계산한다. 한 번에 안 맞으면
        # (긴 낱말이 안 쪼개져) 폭을 조금씩 넓혀 그 줄 수 안에 들인다.
        # ⚠ **한 줄 최소 글자 수를 지킨다** — 안 그러면 「빛이 있으라」(6자)가
        #   3줄 설정에서 폭 2자로 계산돼 `빛이/있으/라` 로 쪼개진다(실측).
        #   정한 줄 수는 **상한**이지 채워야 할 칸이 아니다.
        width = max(self.MIN_WRAP_CHARS, -(-len(s) // n))          # ceil
        for _ in range(6):
            lines = textwrap.wrap(s, width=width) or [s]
            if len(lines) <= n:
                return lines
            width += 2
        return lines[:n]

    def _box_metrics(self, label, family, size, a_type=None, badge_reserve=None):
        """박스 반폭·반높이 + 배지 칸 폭 + 줄 목록.

        badge_reserve — 배지가 커질 수 있는 최대 글(예 「42~42/42＋」, 2026-08-26
        ③ §47 갱신). 잘리는 노드는 펼친 뒤 배지가 「11~20/42」+＋ 로 자라므로
        **만들 때부터 그 폭을 비워** 둔다 — 묶음이 바뀔 때 박스가 늘었다 줄면
        화면이 흔들린다(두 자리 고정폭 예약과 같은 정신).

        ★ 배지는 **박스 안 맨 오른쪽**, 이름은 **왼쪽 정렬** (2026-08-20 사용자
          지시). 배지 글자는 이름과 같은 크기로 키운다.
        ⚠ 배지 칸은 **고정폭으로 예약**한다(두 자리 기준) — 숫자가 3→10 으로
          바뀔 때마다 박스가 늘었다 줄면 화면이 흔들린다.
        ⚠ ★ **배지 클릭 판까지 폭에 넣는다** (2026-08-20 사용자 「빛이 있으라가
          '빛이 있으'로 잘린다」의 정체). 49차에서 배지 클릭 판을 숫자 왼쪽으로
          네 칸 넓혔는데, 그 판은 **박스와 같은 색으로 칠한 사각형**이라 이름
          위에 덮이면 글자가 지워진 것처럼 보인다(실측 겹침 22px). 글자가
          모자란 것이 아니라 **덮인 것**이었다 — 판이 앉을 자리를 미리 비운다.
        """
        lines = self.wrap_label(label, a_type)
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(family=(family or ''), size=int(size or 9), weight='bold')
            name_w = max((f.measure(t) for t in lines), default=0)
            # ★ 폭 기준 모드에서는 **정한 폭을 지킨다** — 이름이 짧아도 박스를
            #   줄이지 않는다. 그래야 「폭을 맞추고 싶다」는 뜻대로 가지런해진다
            #   (2026-08-20 실측: 안 지키면 6자 이름 박스만 혼자 좁았다).
            _d2 = getattr(self, 'style_defaults', {}) or {}
            if a_type != 'BIBLE' and str(_d2.get('node_mode', 'H')).upper() == 'W':
                name_w = max(name_w, f.measure('가' * max(2, int(_d2.get('node_chars', 14) or 14))))
            badge_w = f.measure('88')
            # 배지 클릭 판(숫자 왼쪽 **두 칸**) — 네 칸이면 박스가 그만큼
            # 넓어진다(2026-08-21 사용자 「구절 박스가 더 넓어진 것 같다」).
            plate_w = f.measure('  ')
            h = (f.metrics('linespace') * len(lines)) // 2 + self.BOX_PAD_Y
            if badge_reserve:
                # ★ 잘린 노드의 배지는 **상하로 늘어난다** (2026-08-26 사용자
                #   확정 — 「배지 표시 공간이 좌우로 늘지 않고 상하로 늘어난다.
                #   글자를 조금 작게, 10 (엔터) /38」). 렌즈노드 박스가 여러
                #   줄로 높아지는 것과 같은 문법 — 폭은 안 늘리고 **높이만**.
                bl = str(badge_reserve).split('\n')
                bf = tkfont.Font(family=(family or ''),
                                 size=max(7, int(size or 9) - 2), weight='bold')
                badge_w = max(badge_w, max(bf.measure(x) for x in bl))
                if len(bl) > 1:
                    h = max(h, (bf.metrics('linespace') * len(bl)) // 2
                            + self.BOX_PAD_Y)
        except Exception:
            return self.BOX_MIN_HALF_W, 15, 16, lines
        full = (self.BOX_PAD_X + name_w + self.BOX_GAP
                + plate_w + badge_w + self.BOX_PAD_X)
        half = max(self.BOX_MIN_HALF_W, full // 2)
        # 폭을 직접 정한 모드에서는 상한을 두지 않는다(사용자가 고른 폭이 곧 뜻).
        if str((getattr(self, 'style_defaults', {}) or {}).get('node_mode', 'H')).upper() != 'W':
            half = min(max(self.BOX_MAX_HALF_W, self.BOX_MIN_HALF_W), half)
        return half, max(15, h), badge_w, lines

    def focus_on_coordinate(self, x, y, margin_x=300):
        """좌표를 왼쪽 margin_x px · 상하 중앙에 놓는다. 초점은 기억해 두어
        창 크기가 바뀌면 `_on_canvas_resize` 가 같은 초점으로 다시 맞춘다."""
        self.update_idletasks()
        # 🎯 가시 영역의 높이를 구하여 물리적 중앙 좌표를 계산합니다.
        # ⚠ 폴백 450 은 **아직 배치 전(1×1)** 일 때만 — 예전 문턱 100 은
        #   창을 줄여 캔버스가 정말 얕아졌을 때(실측 48px)도 발동해서
        #   루트가 화면 밖 450px 아래로 갔다(2026-08-20 실측으로 잡음).
        curr_h = self.winfo_height()
        margin_y = curr_h / 2 if curr_h > 2 else 450

        # 🎯 0.5는 전체 스크롤 영역(-5000 ~ 5000)의 중앙인 0을 의미합니다.
        vx = (x + 5000 - margin_x) / 10000
        vy = (y + 5000 - margin_y) / 10000

        self.xview_moveto(max(0, min(1, vx)))
        self.yview_moveto(max(0, min(1, vy)))
        self._last_focus = (x, y, margin_x)
        self._user_moved = False

    def _on_canvas_resize(self, event=None):
        """창 크기 변화 → 마지막 초점 재적용 (사용자가 스스로 움직인 뒤는 제외).

        ⚠ <Configure> 는 리사이즈 드래그 동안 연발한다 — after 로 디바운스."""
        if self._last_focus is None or self._user_moved:
            return
        # ★ 시점 「고정」이면 리사이즈 재중심도 하지 않는다 (2026-08-20).
        #   ⚠ 설명패널이 열리고 닫힐 때도 캔버스 폭이 바뀌어 이 자리가 돈다 —
        #     실측 90px. 사용자가 「보던 맥락을 놓친다」고 한 흔들림의 하나.
        try:
            _v = getattr(self.winfo_toplevel(), 'view_follow_var', None)
            if _v is not None and not int(_v.get()):
                return
        except Exception:
            pass
        if self._refocus_job:
            try:
                self.after_cancel(self._refocus_job)
            except Exception:
                pass
        def _go():
            self._refocus_job = None
            if self._last_focus and not self._user_moved:
                self.focus_on_coordinate(*self._last_focus)
        self._refocus_job = self.after(80, _go)

    def _on_mousewheel(self, event):
        """[철칙 1] 마우스 휠로 상하 스크롤 조절"""
        self._user_moved = True
        self.yview_scroll(int(-1*(event.delta/120)), "units")

    def _on_pan_start(self, event):
        if not self.find_withtag("current"):
            self.scan_mark(event.x, event.y)

    def _on_pan_drag(self, event):
        if not self.find_withtag("current"):
            self._user_moved = True
            self.scan_dragto(event.x, event.y, gain=1)

    def _setup_persistent_scrollbars(self, master):
        """[수리] 들여쓰기를 정렬하여 IndentationError를 해결합니다."""
        v_scroll = tk.Scrollbar(master, orient="vertical", command=self.yview)
        h_scroll = tk.Scrollbar(master, orient="horizontal", command=self.xview)
        self.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
        v_scroll.pack(side="right", fill="y")
        h_scroll.pack(side="bottom", fill="x")

    def clear_all(self):
        """[수리] 물리적 객체, 이벤트 바인딩, 메모리 장부를 원자적으로 소거합니다."""
        self._clear_all_desc_boxes()
        self.delete("all")
        self.nodes = {}
        if not hasattr(self, 'desc_boxes'): self.desc_boxes = {}
        self.unbind("<ButtonRelease-1>")
        self._has_moved = False
        if hasattr(self, '_current_group'): del self._current_group
        self.update_idletasks()

    def _on_double_click(self, event, vid_s):
        if self.expand_callback: self.expand_callback(vid_s)

    # 토글 오프

    def remove_descendants(self, target_vid, visited=None):
        """[최종수리] 새 ID 규격(BIBLE:1_v1)에 맞춰 물리 잔상과 메모리를 완벽 소거합니다."""
        if visited is None: visited = set()
        target_vid_s = str(target_vid)
        if target_vid_s in visited: return
        visited.add(target_vid_s)

        # 1. 🎯 자손들 먼저 재귀적으로 사냥
        # 장부에 저장된 p_id는 변환되지 않은 원본 view_id 문자열입니다.
        to_remove = [vid for vid, n in self.nodes.items() if str(n.get('p_id')) == target_vid_s]
        for vid in to_remove:
            self.remove_descendants(vid, visited)

        # 2. 🎯 본인 소거 (물리 객체 -> 메모리 순서 엄수)
        if target_vid_s in self.nodes:
            # ⚠️ Tkinter 태그 안전을 위해 콜론(:)을 언더바(_)로 치환하여 물리 객체를 찾습니다.
            # 이는 add_enhanced_node에서 tags를 생성할 때와 동일한 규칙이어야 합니다.
            safe_tag = f"node_{target_vid_s.replace(':', '_')}"
            
            # (1) 연결선 및 관계명 텍스트 삭제
            line_id = self.nodes[target_vid_s].get('incoming_line')
            rel_id = self.nodes[target_vid_s].get('rel_tag')
            if line_id: self.delete(line_id)
            if rel_id: self.delete(rel_id)
            
            # (2) 노드 박스 및 그룹화된 모든 요소 물리적 삭제
            self.delete(safe_tag)
            # ⚠ 배지·＋ 판은 일부러 safe_tag 를 안 가진다(클릭 분리) —
            #   view_id 태그로 마저 지운다. 안 지우면 묶음 교체(＋)가 걷어낸
            #   자리에 배지 유령이 남는다(2026-08-26 ③).
            self.delete(target_vid_s)

            # (3) 메모리 장부 영구 삭제 (재사용을 위해 깨끗이 비움)
            del self.nodes[target_vid_s]
            # (4) 설명문 박스가 열려있으면 함께 제거
            self.remove_desc_box(target_vid_s)

    @staticmethod
    def _C(role, fallback):
        try:
            import ui_theme
            return ui_theme.C(role) or fallback
        except Exception:
            return fallback

    def _theme_colors(self, a_type):
        """(글자, 테두리, 유형별 박스 바탕) — 그리는 시점의 테마 역할."""
        bg = (self._C('accent_bg', '#EBF5FB') if a_type == 'BIBLE'
              else self._C('warning_bg', '#FEF9E7') if a_type == 'NODE'
              else self._C('success_bg', '#D1F2EB'))
        return self._C('fg', '#000000'), self._C('border', '#AEB6BF'), bg

    def add_enhanced_node(self, p_id, view_id, node_id, label, context_text, x, y, a_type,
                          badge_count=0, rel_label="", qp_label="", note_count=0, **style):
        """[최종 확정] 성경 구절 전용 Q&P 서브 박스 및 배지/마커 통합 생성기"""
        if not a_type: return
        
        # 1. 기존 노드 파기 (중복 방지)
        if view_id in self.nodes or self.find_withtag(view_id): 
            self.delete(view_id); (view_id in self.nodes and self.nodes.pop(view_id))

        # 2. 스타일 설정
        # ★ **캔버스가 기본값을 기억한다** (2026-08-20 사용자 「설정을 바꿔도
        #   다른 구절을 클릭하고 돌아오면 초기값으로 돌아간다」).
        #   값은 app_state 에 잘 저장되고 있었는데, **다시 그리는 자리들이
        #   글꼴·크기·굵기를 안 넘겨서** 여기 기본값(Malgun 9)으로 그려졌다.
        #   호출부를 전부 고치는 대신 캔버스가 마지막 설정을 들고 있게 한다 —
        #   `user_main._sync_canvas_style()` 이 채워 준다.
        _d = getattr(self, 'style_defaults', {})
        f_fam = style.get('font_family') or _d.get('font_family') or "Malgun Gothic"
        f_size = style.get('font_size') or _d.get('font_size') or 9
        # ★ 「선 굵기」 옵션 폐지 (2026-09-02 0.txt 5-1) — 본문은 늘 보통 굵기.
        f_weight = "normal"
        safe_tag = f"node_{view_id.replace(':', '_')}"
        rect_tag = f"rect_{view_id.replace(':', '_')}"
        badge_tag = f"bdg_{view_id.replace(':', '_')}"
        qp_tag = f"qp_{view_id}"

        # 3. 장부 등록
        self.nodes[view_id] = {'node_id': node_id, 'p_id': p_id, 'x': x, 'y': y, 'tag': safe_tag, 'rel_label': rel_label}
        # ★ 색은 그리는 시점의 테마 역할 (2026-08-19 사용자 — 「배경색을 바꿀 때
        #   잘 보이지 않을 수 있다. 표준서식을 따르라」. 캔버스 그림은 paint 가
        #   못 바꾸므로 **그릴 때** 역할로 칠한다. 유형 구분은 역할쌍으로 유지 —
        #   구절=accent_bg(파랑) · 노드=warning_bg(노랑) · 그 외=success_bg(초록).
        #   크기·간격·선 굵기·글꼴은 캔버스 설정의 개별값 그대로).
        _fg, _bd, _bg = self._theme_colors(a_type)

        # 4. [물리 생성] 본체 박스와 라벨
        # ★ **박스는 글자에 맞춘다** (2026-08-20 사용자 지시 — 「상하 또는 좌우
        #   하나만 정하고 나머지는 글자 크기에 맞춰 자유롭게」).
        #   ⚠ 옛 코드는 **120×30 픽셀 고정**이라, 렌즈 노드 이름(평균 11자·
        #     최대 20자 「하나님이 가라사대 우리의 형상을 따라」)이 박스를 넘어
        #     삐져나왔다. 설정의 폭 값은 박스가 아니라 **본문 자르기**에만
        #     쓰이고 있었다(실측으로 확인).
        #   ⇒ 높이는 글꼴 크기가 정하고(상하 여백 고정), 폭은 이름 길이를 재서
        #     정한다. 아주 긴 이름만 최대폭에서 멈춘다.
        _half_w, _half_h, _badge_w, _lines = self._box_metrics(
            label, f_fam, f_size, a_type,
            badge_reserve=style.get('badge_reserve'))
        self.create_rectangle(x - _half_w, y - _half_h, x + _half_w, y + _half_h,
                              fill=_bg, outline=_bd, tags=(view_id, safe_tag, rect_tag))
        # 이름은 **왼쪽 정렬** (2026-08-20 사용자 지시). 여러 줄이면 그대로 쌓는다 —
        # 줄 나누기는 `wrap_label` 이 설정(높이 기준/폭 기준)대로 이미 해 두었다.
        self.create_text(x - _half_w + self.BOX_PAD_X, y, text='\n'.join(_lines),
                         anchor='w', justify='left',
                         fill=_fg, font=(f_fam, f_size, "bold"),
                         tags=(view_id, safe_tag))
        self.nodes[view_id]['fstyle'] = (f_fam, f_size)   # 배지 갱신이 쓴다
        self.nodes[view_id]['boxbg'] = _bg                # 배지 클릭 판 색
        # 이름이 끝나는 x — 배지 판이 여기를 넘지 않게 한다(2026-08-21)
        try:
            import tkinter.font as _tf
            _fm = _tf.Font(family=(f_fam or ''), size=int(f_size or 9), weight='bold')
            self.nodes[view_id]['name_x2'] = (x - _half_w + self.BOX_PAD_X
                                              + max((_fm.measure(t) for t in _lines), default=0))
        except Exception:
            pass

        # [2026-06-04] P 마커 제거 — LINK 페리코프 사용 안 함. 페리코프는 NodePanel 탭6에서 자동 표시.

        # 6. [물리 생성] 본문 텍스트 및 배지
        if context_text:
            # 박스가 글자 폭을 따르므로 본문·배지도 그 폭 기준으로 (2026-08-20)
            self.create_text(x + _half_w + 5, y, text=context_text, anchor='w',
                             fill=_fg, font=(f_fam, f_size, f_weight),
                             tags=(view_id, safe_tag))
        # ★ 배지 = **이 박스를 누르면 몇 개가 나오나**. 0 도 그린다(사용자 확정 —
        #   「연결이 없는 경우에도 0으로 표시하는 것이 명확하다. 오류가 아니라는
        #   것을 확실하게 보여준다」).
        #   자리 = **박스 안 맨 오른쪽**, 글자 크기 = 이름과 같게, 바탕은 박스와
        #   같은 색(사용자 — 「공간 색상을 다르게 하면 혼란스럽다」).
        #   ⚠ 배지 태그에는 **safe_tag 를 넣지 않는다** — 넣으면 박스 클릭
        #     바인딩이 함께 걸려 「읽기/펼치기 분리」가 무너진다. 드래그는
        #     view_id 태그로 옮기므로 함께 따라온다.
        # 배지 클릭 = 자녀 펼치기 (읽기는 박스 클릭 — 2026-08-20 사용자 설계).
        # 넓은 클릭 판은 `_draw_badge` 가 함께 깐다.
        self._draw_badge(view_id, badge_count,
                         [x - _half_w, y - _half_h, x + _half_w, y + _half_h],
                         f_fam, f_size, _bg,
                         text=style.get('badge_text'))

        # ★ 마커 정리 (2026-08-19 사용자 지시)
        #   · N 배지(묵상노트 개수) 제거 — P2/우측 패널 탭 이름의 (N) 배지가 대신한다.
        #   · C 마커(구속사연결) 제거 — 노드 클릭 시 우측 「구속사연결」 탭이
        #     자동 로드되므로 캔버스 마커가 필요 없다. `on_chain_click` 경로 폐기.
        #   · 묵상질문(qp_label) 제거 — 박스만 길어지고 질문은 우측 설명 탭 몫.
        #   ⚠ note_count·qp_label 인자는 **받되 무시한다** — 호출부(스냅샷 복원
        #     3곳 포함)를 전부 고치는 것보다 안전하다.

        # 8. 이벤트 바인딩
        def _db_click_wrap(nid, vid):
            # 더블클릭 플래그 설정 → _on_node_release가 on_node_click(desc토글)을 건너뜀
            self._is_double_click = True
            if self.on_node_double_click: self.on_node_double_click(nid, vid)
            if self.expand_callback: self.expand_callback(nid, a_type, x, y, vid)

        self.tag_bind(safe_tag, "<Button-1>", lambda e: self._on_node_press(e, view_id))
        self.tag_bind(safe_tag, "<Double-1>", lambda e: _db_click_wrap(node_id, view_id))
        self.tag_bind(safe_tag, "<B1-Motion>", lambda e: self._on_node_drag(e, view_id))

    def _on_node_release(self, event):
        """드래그가 끝나면 내부 상태를 정리하고 메인 앱의 콜백을 호출합니다."""
        if hasattr(self, '_current_group'):
            del self._current_group

        # 드래그 없이 제자리에서 뗀 경우에만 싱글 클릭으로 간주
        # find_closest(event.x, event.y)는 윈도우 좌표로 캔버스 스크롤 시 틀리므로
        # _on_node_press에서 저장한 _pressed_vid를 직접 사용
        # 더블클릭 시에는 _is_double_click 플래그가 True이므로 on_node_click을 건너뜀
        if not self._has_moved and not getattr(self, '_is_double_click', False):
            vid = getattr(self, '_pressed_vid', None)
            if vid and vid in self.nodes and self.on_node_click:
                nid = self.nodes[vid]['node_id']
                self.on_node_click(nid, vid)

        self.unbind("<ButtonRelease-1>")
        self._has_moved = False
        self._is_double_click = False
        if hasattr(self, '_pressed_vid'):
            del self._pressed_vid

    def _get_all_descendants(self, parent_vid, visited=None):
        """[무결성수리] 순환 참조를 차단하고 모든 심층 자손을 누락 없이 수집합니다."""
        if visited is None: visited = set()
        # 🎯 순환 참조 방어: 이미 계산한 노드면 즉시 탈출 (RecursionError 해결)
        if parent_vid in visited: return []
        visited.add(parent_vid)
        
        descendants = []
        for vid, data in self.nodes.items():
            # 🎯 [6번 노드 가출 해결] p_id 비교 시 문자열 정규화로 매칭 누락 방지
            if str(data.get('p_id')) == str(parent_vid):
                descendants.append(vid)
                # 재귀 호출 시 방문 기록을 공유하여 안전하게 심층 탐색
                descendants.extend(self._get_all_descendants(vid, visited))
        return descendants

    # ── 배지 약속보다 적게 나왔을 때 알림 (2026-10-07 docs/1.txt 52-1) ──────────
    NOTE_MS = 3500           # 풍선이 떠 있는 시간
    FLASH_MS = 1400          # 이미 있는 상자를 반짝이는 시간

    def show_note(self, view_id, text):
        """그 노드 박스 바로 위에 작은 풍선 글을 띄웠다가 걷는다(팝업 창 아님).

        캔버스 그림이라 함께 굴러가고, 이전 풍선은 지우고 하나만 둔다."""
        try:
            self.delete('p4note')
            rc = self.find_withtag(f"rect_{view_id.replace(':', '_')}")
            if not rc or not text:
                return
            c = self.coords(rc[0])
            info = self.nodes.get(view_id, {})
            fam, size = info.get('fstyle', ('', 9))
            tid = self.create_text(c[0] + 6, c[1] - 8, text=text, anchor='sw',
                                   fill=self._C('fg', '#2C3E50'),
                                   font=(fam, max(8, int(size or 9) - 1)),
                                   tags=('p4note',))
            bb = self.bbox(tid)
            if bb:
                rid = self.create_rectangle(bb[0] - 6, bb[1] - 3, bb[2] + 6, bb[3] + 3,
                                            fill=self._C('warning_bg', '#FFF4D6'),
                                            outline=self._C('warning', '#E67E22'),
                                            tags=('p4note',))
                self.tag_raise(tid, rid)
            if getattr(self, '_note_job', None):
                try:
                    self.after_cancel(self._note_job)
                except Exception:
                    pass
            self._note_job = self.after(self.NOTE_MS, lambda: self.delete('p4note'))
        except Exception:
            pass

    def flash_nodes(self, view_ids):
        """이미 화면에 있는 상자들의 테두리를 잠깐 굵게 칠해 자리를 알린다."""
        olds = []
        for v in view_ids or []:
            for iid in self.find_withtag(f"rect_{str(v).replace(':', '_')}"):
                try:
                    olds.append((iid, self.itemcget(iid, 'outline'),
                                 self.itemcget(iid, 'width')))
                    self.itemconfig(iid, outline=self._C('accent', '#2980B9'), width=3)
                except Exception:
                    pass

        def _back():
            for iid, ol, w in olds:
                try:
                    self.itemconfig(iid, outline=ol, width=w)
                except Exception:
                    pass
        if olds:
            self.after(self.FLASH_MS, _back)
        return len(olds)

    def redraw_edges(self):
        """[최종완결] 관계명(rel_name)을 자녀 노드 박스 하단 모서리에 밀착 배치합니다."""
        self.delete("edge")
        self.update_idletasks()
        
        for inst_id, info in self.nodes.items():
            p_id = info.get('p_id')
            if p_id and p_id in self.nodes:
                p_title_rect = f"rect_{p_id.replace(':', '_')}"
                c_title_rect = f"rect_{inst_id.replace(':', '_')}"
                
                p_box = self.bbox(p_title_rect)
                c_box = self.bbox(c_title_rect)
                
                if p_box and c_box:
                    # 1. 연결선 (화살표) 생성
                    px, py = p_box[2], (p_box[1] + p_box[3]) / 2
                    cx, cy = c_box[0], (c_box[1] + c_box[3]) / 2
                    self.create_line(px, py, cx, cy,
                                     fill=self._C('fg_dim', '#ABB2B9'), width=0.7,
                                     tags=("edge", f"line_{inst_id.replace(':', '_')}"), arrow=tk.LAST)

                    # 2. 🎯 [교정] 관계명 배치 로직 (하단 밀착 + 왼쪽 돌출)
                    #    글자 크기 8 은 의도된 하드코딩(2026-08-19 사용자 — 「글자가
                    #    커지면 복잡하므로 예외적으로 유지」). 색만 역할.
                    rel_txt = info.get('rel_label', "")
                    if rel_txt:
                        # tx: 자녀 박스 왼쪽(cx)에서 알파벳 4글자 정도(-28px) 왼쪽으로
                        # ty: 자녀 박스 하단 + 6px (2026-08-20 사용자 — 「1mm 차이도
                        #     없이 붙어 있다. 1~2mm 아래로 떼라」. 1mm ≈ 4px)
                        tx, ty = c_box[0] - 28, c_box[3] + 6
                        self.create_text(tx, ty, text=rel_txt,
                                         fill=self._C('accent', '#2E86C1'),
                                         font=("Malgun Gothic", 8, "italic"),
                                         tags=("edge", "rel_name"), anchor='nw')
                                         # 'nw'(NorthWest)로 텍스트의 왼쪽 위를 기준점 삼아 박스 아래에 매답니다.

        self.tag_lower("edge")


    # 노드 드래그
    def _on_node_drag(self, event, vid_s):
        """[복구] 확정된 그룹을 이동시키며 미세 떨림을 보정합니다."""
        if not hasattr(self, '_current_group') or not hasattr(self, '_drag_start_x'): return

        dx, dy = event.x - self._drag_start_x, event.y - self._drag_start_y
        if abs(dx) < 2 and abs(dy) < 2: return

        self._has_moved = True
        self._drag_start_x, self._drag_start_y = event.x, event.y

        for t_vid in self._current_group:
            if t_vid in self.nodes:
                self.move(t_vid, dx, dy)
                self.nodes[t_vid]['x'] += dx
                self.nodes[t_vid]['y'] += dy

        self.redraw_edges()

        # 이동된 노드에 연결된 desc_box 연결선도 함께 갱신
        if hasattr(self, 'desc_boxes'):
            for dv_id, dinfo in self.desc_boxes.items():
                if dv_id in self._current_group and dv_id in self.nodes:
                    nx = self.nodes[dv_id]['x']
                    ny = self.nodes[dv_id]['y']
                    bx, by = dinfo['bx'], dinfo['by']
                    x1, y1 = nx + 60, ny
                    x2, y2 = bx, by + dinfo['box_h'] // 2
                    mx = (x1 + x2) / 2
                    self.coords(dinfo['line'], x1, y1, mx, y1, mx, y2, x2, y2)

    # 노드 드래그 : 그룹이동
    def _on_node_press(self, event, vid_s):
        """드래그 시작 시 이동 그룹을 확정하고 이동 플래그를 초기화합니다."""
        self._drag_start_x, self._drag_start_y = event.x, event.y
        self._has_moved = False
        self._pressed_vid = vid_s  # 릴리즈 시 find_closest 대신 사용

        is_ctrl = (event.state & 0x0004)
        self._current_group = [vid_s] if is_ctrl else [vid_s] + self._get_all_descendants(vid_s)
        self.bind("<ButtonRelease-1>", self._on_node_release, add="+")

    # 토글기능 : 클릭한 노드의 형제노드의 자손들을 안보이기 (형제 본인은 유지)
    def clear_sibling_branches(self, clicked_vid):
        """[최종수리] 형제 본인은 유지하고, 형제들의 모든 하위 자손(배지 포함)만 제거합니다."""
        if not clicked_vid: return
        
        target_info = self.nodes.get(clicked_vid)
        if not target_info: return
        p_id = target_info.get('p_id')
        if not p_id: return # 루트 노드는 형제가 없으므로 통과

        # 1. 🎯 '나'를 제외하고 같은 부모를 공유하는 형제 노드들 선별
        siblings = [vid for vid, d in self.nodes.items() 
                    if str(d.get('p_id')) == str(p_id) and vid != clicked_vid]
        
        for s_vid in siblings:
            # 2. 🎯 각 형제의 모든 자손(하위 노드 전체)을 수집
            # _get_all_descendants 메서드는 하위 트리를 리스트로 반환해야 합니다.
            descendants = self._get_all_descendants(s_vid)
            
            for d_vid in descendants:
                if d_vid in self.nodes:
                    self.delete(d_vid)
                    del self.nodes[d_vid]
                    self.remove_desc_box(d_vid)

        self.redraw_edges()

    # ──────────────────────────────────────────────────────────────
    # 설명문 결합 박스 (Description Combo Box)
    # ──────────────────────────────────────────────────────────────

    def show_desc_box(self, view_id, text_content, node_x, node_y):
        """노드와 연결된 설명문 결합 박스를 캔버스에 표시/토글합니다."""
        if not hasattr(self, 'desc_boxes'):
            self.desc_boxes = {}
        # 이미 열려있으면 토글오프
        if view_id in self.desc_boxes:
            self.remove_desc_box(view_id)
            return

        bx, by = self._find_desc_box_position(node_x, node_y)
        box_w, box_h = 300, 180

        # 외부 프레임 (타이틀바 + 텍스트 영역)
        outer = tk.Frame(self, bg='#F4F6F7', bd=1, relief='solid')

        title_bar = tk.Frame(outer, bg='#BFC9CA', height=20, cursor='fleur')
        title_bar.pack(fill='x', side='top')
        title_bar.pack_propagate(False)

        lbl = tk.Label(title_bar, text=''+i18n.t('COMMON_DESCTEXT','설명문'), bg='#BFC9CA',
                       font=('Malgun Gothic', 8), anchor='w', cursor='fleur')
        lbl.pack(side='left', padx=4)

        close_btn = tk.Button(title_bar, text='✕', bg='#BFC9CA', fg='#555',
                              font=('Arial', 8), bd=0, cursor='hand2',
                              command=lambda vid=view_id: self.remove_desc_box(vid))
        close_btn.pack(side='right', padx=2, pady=1)

        txt_frame = tk.Frame(outer, bg='#FDFEFE')
        txt_frame.pack(fill='both', expand=True)

        sb = tk.Scrollbar(txt_frame, orient='vertical')
        sb.pack(side='right', fill='y')

        txt = tk.Text(txt_frame, wrap='word', font=('Malgun Gothic', 9),
                      bd=0, bg='#FDFEFE', yscrollcommand=sb.set,
                      state='normal', cursor='arrow')
        txt.pack(side='left', fill='both', expand=True)
        sb.config(command=txt.yview)

        txt.insert('1.0', text_content if text_content.strip() else "표시할 설명문이 없습니다.")
        txt.config(state='disabled')

        win_id = self.create_window(bx, by, window=outer, anchor='nw',
                                    tags=('desc_box', f'desc_{view_id.replace(":", "_")}'),
                                    width=box_w, height=box_h)

        # 연결선: 노드 오른쪽 끝 → 박스 왼쪽 중앙, 부드러운 꺾음선
        x1, y1 = node_x + 60, node_y
        x2, y2 = bx, by + box_h // 2
        mx = (x1 + x2) / 2
        line_id = self.create_line(x1, y1, mx, y1, mx, y2, x2, y2,
                                   smooth=True, fill=self._C('fg_dim', '#85929E'),
                                   dash=(5, 3), width=1.5, tags=('desc_line',))
        self.tag_lower(line_id)

        self.desc_boxes[view_id] = {
            'win': win_id, 'line': line_id, 'frame': outer,
            'bx': bx, 'by': by, 'box_w': box_w, 'box_h': box_h,
            'nx': node_x, 'ny': node_y,
        }

        # 타이틀바 드래그로 박스 이동
        for w in (outer, title_bar, lbl):
            w.bind('<Button-1>',      lambda e, vid=view_id: self._start_desc_drag(e, vid))
            w.bind('<B1-Motion>',     lambda e, vid=view_id: self._drag_desc(e, vid))
            w.bind('<ButtonRelease-1>', lambda e: self._end_desc_drag())

    def remove_desc_box(self, view_id):
        """설명문 박스와 연결선을 제거합니다."""
        if not hasattr(self, 'desc_boxes'):
            return
        info = self.desc_boxes.pop(view_id, None)
        if not info:
            return
        try:
            self.delete(info['win'])
            self.delete(info['line'])
            info['frame'].destroy()
        except Exception:
            pass

    def _clear_all_desc_boxes(self):
        """모든 설명문 박스를 제거합니다 (캔버스 전체 초기화 시 사용)."""
        if not hasattr(self, 'desc_boxes'):
            self.desc_boxes = {}
            return
        for vid in list(self.desc_boxes.keys()):
            self.remove_desc_box(vid)

    def _find_desc_box_position(self, node_x, node_y):
        """클릭 노드의 수직 위치에 따라 박스 배치를 결정합니다."""
        box_w, box_h = 300, 180
        # 노드가 다른 노드들의 평균 y보다 아래에 있으면 → 위쪽 우선, 아니면 아래쪽 우선
        avg_y = (sum(n['y'] for n in self.nodes.values()) / len(self.nodes)) if self.nodes else 0
        if node_y > avg_y:
            candidates = [
                (node_x - box_w - 120, node_y - box_h - 30),   # 왼쪽 위 (1순위)
                (node_x - box_w - 120, node_y - box_h // 2),   # 왼쪽 중앙
                (node_x - box_w // 2,  node_y - box_h - 70),   # 위쪽
                (node_x - box_w - 120, node_y + 30),            # 왼쪽 아래
                (node_x - box_w // 2,  node_y + 50),            # 아래쪽
                (node_x + 160,         node_y - box_h // 2),   # 오른쪽 (최후)
            ]
        else:
            candidates = [
                (node_x - box_w - 120, node_y + 30),            # 왼쪽 아래 (1순위)
                (node_x - box_w - 120, node_y - box_h // 2),   # 왼쪽 중앙
                (node_x - box_w // 2,  node_y + 50),            # 아래쪽
                (node_x - box_w - 120, node_y - box_h - 30),   # 왼쪽 위
                (node_x - box_w // 2,  node_y - box_h - 70),   # 위쪽
                (node_x + 160,         node_y - box_h // 2),   # 오른쪽 (최후)
            ]

        def overlaps(bx, by):
            for info in self.nodes.values():
                nx, ny = info.get('x', 0), info.get('y', 0)
                if not (bx + box_w + 20 < nx - 70 or bx - 20 > nx + 70
                        or by + box_h + 10 < ny - 20 or by - 10 > ny + 20):
                    return True
            return False

        for cx, cy in candidates:
            if not overlaps(cx, cy):
                return cx, cy
        return candidates[0]

    def _start_desc_drag(self, event, view_id):
        self._desc_drag_start = (event.x_root, event.y_root)
        self._desc_drag_vid = view_id

    def _drag_desc(self, event, view_id):
        if not hasattr(self, '_desc_drag_start'):
            return
        x0, y0 = self._desc_drag_start
        dx = event.x_root - x0
        dy = event.y_root - y0
        self._desc_drag_start = (event.x_root, event.y_root)

        info = self.desc_boxes.get(view_id)
        if not info:
            return

        self.move(info['win'], dx, dy)
        info['bx'] += dx
        info['by'] += dy

        # 연결선 재계산 (노드 위치는 최신값으로)
        node_info = self.nodes.get(view_id, {})
        nx = node_info.get('x', info['nx'])
        ny = node_info.get('y', info['ny'])
        bx, by = info['bx'], info['by']
        x1, y1 = nx + 60, ny
        x2, y2 = bx, by + info['box_h'] // 2
        mx = (x1 + x2) / 2
        self.coords(info['line'], x1, y1, mx, y1, mx, y2, x2, y2)

    def _end_desc_drag(self):
        if hasattr(self, '_desc_drag_start'):
            del self._desc_drag_start
        if hasattr(self, '_desc_drag_vid'):
            del self._desc_drag_vid
