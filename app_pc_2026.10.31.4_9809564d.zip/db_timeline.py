# -*- coding: utf-8 -*-
"""둘러보기 ▸ 성경 연대표 + 세계사 — 사건·연대(학설 여러 줄)·글을 담는다 (2026-10-22 · 영구 · docs/둘러보기_03).

  python db_timeline.py --selftest      # 빈 DB 에서 적재·멱등·되돌리기 (의무)
  python db_timeline.py --init          # 표 둘을 만든다(있으면 그대로)
  python db_timeline.py --check         # 초안(source_texts/timeline_ko.json)을 풀어 보기만 — DB 0
  python db_timeline.py --apply         # 담는다(멱등 · 사람이 고친 글은 안 덮는다)
  python db_timeline.py --undo          # 이 도구가 담은 것만 걷는다(source='TLDRAFT')
  python db_timeline.py --status

표 — `sys_timeline_event`(event_id · event_code · era_code(sys_era_code) · lane BIBLE|WORLD · sort_order · start_vid · end_vid · entity_id · source)
   · `sys_timeline_date`(date_id · event_id · view_code MAIN|EARLY|LATE|TRAD · y_from · y_to(음수 = B.C.) · certainty SURE|APPROX|RANGE|UNKNOWN · label · source)
글 — `sys_text_asset` TL_EVENT_TITLE · TL_EVENT_WORLD(그때 세상) · TL_EVENT_EVIDENCE(근거) · TL_EVENT_DESC(clicked_id = event_id · 11언어).
★ 시대는 이미 있는 `sys_era_code`(12) 를 쓴다 — 새 시대 표를 만들지 않는다(구절 → 시대는 `sys_era_span` 이 이미 안다).
★ 연대가 갈리면 **여러 줄**을 둔다(view_code). 한 칸에 숫자 하나만 적지 않는다(사용자 2026-10-22).
⚠ 엔티티 코드가 없으면 알리고 비워 둔다(막지 않는다 · 지어내지 않는다).

★ 2026-10-25 세부 사건(docs/연대표.txt · 사용자 「추천대로」) — 굵은 사건 아래 세부 사건 · 구절 여러 개 · 장소 여러 곳.
  · `sys_timeline_event.parent_id` — 굵은 사건의 번호(없으면 굵은 사건 자신).
  · 구절 = `"refs": "마 14:13-21; 막 6:30-44"` → 통합 연결 표 `sys_link_asset(TLEV_VERS · clicked_id=사건 · target_id/end_id=구간 · 차례)`.
    첫 구간은 옛 칸(start_vid·end_vid)에도 — 옛 화면이 그대로 돈다. 새 표를 만들지 않는다(coding.md §1-A).
  · 장소 = `"places": [{"name":…, "modern":…, "entity":"PL_…", "conf":"TEXT|CONTEXT|TRADITION"}]`
    → 용어가 있으면 `sys_link_asset(TLEV_ENTI · confidence=conf)` · 글은 `TL_EVENT_PLACE`(한 줄에 한 곳 · 「성경 지명 · 오늘의 위치」).
    conf — TEXT 본문에 이름 있음 · CONTEXT 앞뒤 문맥에서 추정 · TRADITION 성경에 없는 후대 전통 이름.
  · 초안 파일마다 `_source`(되돌리기 단위) — 세부 사건 초안은 `source_texts/timeline_detail_ko.json`(TLDETAIL).
    python db_timeline.py --check  --draft source_texts/timeline_detail_ko.json
"""
import json
import os
import re
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DRAFT = os.path.join(HERE, 'source_texts', 'timeline_ko.json')
SOURCE = 'TLDRAFT'
LANG = 'KO'
LANES = ('BIBLE', 'WORLD', 'EMPIRE', 'KING', 'PROPHET', 'BOOK', 'THOUGHT', 'EVIDENCE')
CERT = ('SURE', 'APPROX', 'RANGE', 'UNKNOWN')
TEXTS = (('title', 'TL_EVENT_TITLE'), ('world', 'TL_EVENT_WORLD'), ('evidence', 'TL_EVENT_EVIDENCE'), ('desc', 'TL_EVENT_DESC'),
         ('place_text', 'TL_EVENT_PLACE'))
TEXT_TYPES = tuple(t for _k, t in TEXTS)
LINK_VERS, LINK_ENTI = 'TLEV_VERS', 'TLEV_ENTI'
PLACE_CONF = ('TEXT', 'CONTEXT', 'TRADITION')
REGIONS = ('', 'EGYPT', 'NEAREAST', 'EUROPE', 'ASIA', 'AMERICAS')

DDL = """
CREATE TABLE IF NOT EXISTS sys_timeline_event(
  event_id INTEGER PRIMARY KEY AUTOINCREMENT, event_code TEXT UNIQUE NOT NULL, era_code TEXT NOT NULL,
  lane TEXT NOT NULL DEFAULT 'BIBLE', sort_order INTEGER DEFAULT 0, start_vid INTEGER, end_vid INTEGER,
  entity_id INTEGER, source TEXT, record_status TEXT DEFAULT 'LIVE');
CREATE TABLE IF NOT EXISTS sys_timeline_date(
  date_id INTEGER PRIMARY KEY AUTOINCREMENT, event_id INTEGER NOT NULL, view_code TEXT NOT NULL DEFAULT 'MAIN',
  y_from INTEGER, y_to INTEGER, certainty TEXT NOT NULL DEFAULT 'APPROX', label TEXT, source TEXT,
  record_status TEXT DEFAULT 'LIVE');
CREATE INDEX IF NOT EXISTS ix_tl_date_event ON sys_timeline_date(event_id);
"""


def init(conn):
    conn.executescript(DDL)
    cols = {r[1] for r in conn.execute('PRAGMA table_info(sys_timeline_event)')}
    if 'parent_id' not in cols:
        conn.execute('ALTER TABLE sys_timeline_event ADD COLUMN parent_id INTEGER')   # ★ 2026-10-25 세부 사건
    if 'region' not in cols:
        conn.execute("ALTER TABLE sys_timeline_event ADD COLUMN region TEXT DEFAULT ''")


def place_line(p):
    """장소 한 곳 → 글 한 줄(「성경 지명 · 오늘의 위치」 + 확실성 낱말) — 화면이 그대로 보인다."""
    s = (p.get('name') or '').strip()
    if (p.get('modern') or '').strip():
        s += ' · 오늘: ' + p['modern'].strip()
    tag = {'CONTEXT': '본문에 이름이 없고 앞뒤 문맥에서 추정', 'TRADITION': '성경에 없는 후대 전통 이름'}.get(p.get('conf') or 'TEXT')
    return s + (' (%s)' % tag if tag else '')


def load_draft(path=DRAFT):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def _gate(s):
    bad = []
    s = (s or '').strip()
    if '—' in s:
        bad.append('대시(—)')
    if re.search(r'[①-⑳]', s):
        bad.append('동그라미 번호')
    return bad


def plan(conn, draft):
    """초안 → (문제, 알림, 사건 목록). 문제가 있으면 apply 가 거부한다 · 알림은 막지 않는다."""
    import scripture_ref as S
    eras = {r[0] for r in conn.execute('SELECT era_code FROM sys_era_code')}
    problems, notes, out = [], [], []
    seen = set()
    for i, e in enumerate(draft.get('events', [])):
        code = e.get('code', '')
        if not code or code in seen:
            problems.append('사건 코드 없음/겹침 %r' % code)
            continue
        seen.add(code)
        if e.get('era') not in eras:
            problems.append('%s: 시대 코드 %r 가 sys_era_code 에 없다' % (code, e.get('era')))
        if e.get('lane', 'BIBLE') not in LANES:
            problems.append('%s: 줄 %r' % (code, e.get('lane')))
        if not e.get('title'):
            problems.append('%s: 제목 없음' % code)
        for k, _t in TEXTS:
            for b in _gate(e.get(k, '')):
                problems.append('%s %s: %s' % (code, k, b))
        a = b2 = None
        refs = []
        if e.get('refs'):
            for x in [y.strip() for y in e['refs'].replace('–', '-').split(';') if y.strip()]:
                ra, rb = S.resolve(conn, x, LANG)
                if ra is None:
                    problems.append('%s: 구절을 못 풀었다 %r' % (code, x))
                else:
                    refs.append((ra, rb or ra))
            if refs:
                a, b2 = refs[0]
        elif e.get('ref'):
            a, b2 = S.resolve(conn, e['ref'], LANG)
            if a is None:
                problems.append('%s: 구절을 못 풀었다 %r' % (code, e['ref']))
        if e.get('region', '') not in REGIONS:
            problems.append('%s: 지역 %r' % (code, e.get('region')))
        places = []
        for p in e.get('places') or []:
            if (p.get('conf') or 'TEXT') not in PLACE_CONF:
                problems.append('%s: 장소 확실성 %r' % (code, p.get('conf')))
            pe = None
            if p.get('entity'):
                r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                                 (p['entity'],)).fetchone()
                pe = r[0] if r else None
                if pe is None:
                    notes.append('%s: 장소 용어 %s 없음 — 글로만' % (code, p['entity']))
            places.append((pe, p.get('conf') or 'TEXT'))
        if e.get('places') and not e.get('place_text'):
            e = dict(e, place_text='\n'.join(place_line(p) for p in e['places']))
        eid = None
        if e.get('entity'):
            r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                             (e['entity'],)).fetchone()
            if r:
                eid = r[0]
            else:
                notes.append('%s: 엔티티 %s 없음 — 비워 둔다' % (code, e['entity']))
        dates = e.get('dates') or []
        if not dates:
            problems.append('%s: 연대 줄이 없다(확정 불가면 UNKNOWN 한 줄)' % code)
        views = set()
        for d in dates:
            if d.get('certainty', 'APPROX') not in CERT:
                problems.append('%s: certainty %r' % (code, d.get('certainty')))
            v = d.get('view', 'MAIN')
            if v in views:
                problems.append('%s: 학설 %s 두 번' % (code, v))
            views.add(v)
            if d.get('certainty') != 'UNKNOWN' and (d.get('from') is None or d.get('to') is None):
                problems.append('%s %s: 연대 숫자 없음' % (code, v))
            if d.get('from') is not None and d.get('to') is not None and d['from'] > d['to']:
                problems.append('%s %s: from > to' % (code, v))
        if len(views) > 1 and 'MAIN' not in views and 'EARLY' not in views:
            problems.append('%s: 학설이 여럿인데 다수설(MAIN·EARLY) 표시가 없다' % code)
        out.append({'code': code, 'era': e['era'], 'lane': e.get('lane', 'BIBLE'), 'sort': e.get('sort', i * 10), 'a': a, 'b': b2, 'eid': eid,
                    'texts': {t: e.get(k, '').strip() for k, t in TEXTS if e.get(k)}, 'dates': dates,
                    'refs': refs, 'places': places, 'parent': e.get('parent', ''), 'region': e.get('region')})
    known = {r[0] for r in conn.execute('SELECT event_code FROM sys_timeline_event')} if _has(conn, 'sys_timeline_event') else set()
    for x in out:
        if x['parent'] and x['parent'] not in known and x['parent'] not in seen:
            problems.append('%s: 굵은 사건 %s 이 없다' % (x['code'], x['parent']))
        if x['parent'] == x['code']:
            problems.append('%s: 제 자신을 굵은 사건으로' % x['code'])
    return problems, notes, out


def _has(conn, t):
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone() is not None


def apply(conn, draft, commit=True):
    init(conn)
    problems, notes, evs = plan(conn, draft)
    if problems:
        raise SystemExit('초안에 문제가 있어 담지 않는다:\n  ' + '\n  '.join(problems))
    src = draft.get('_source') or SOURCE
    n_ev = n_dt = n_tx = 0
    for e in evs:
        cur = conn.execute('SELECT event_id FROM sys_timeline_event WHERE event_code=?', (e['code'],)).fetchone()
        if cur:
            ev = cur[0]
            conn.execute("UPDATE sys_timeline_event SET era_code=?, lane=?, sort_order=?, start_vid=?, end_vid=?, entity_id=COALESCE(entity_id,?), "
                         "record_status='LIVE' WHERE event_id=?", (e['era'], e['lane'], e['sort'], e['a'], e['b'], e['eid'], ev))
        else:
            conn.execute("INSERT INTO sys_timeline_event(event_code,era_code,lane,sort_order,start_vid,end_vid,entity_id,source,record_status) "
                         "VALUES(?,?,?,?,?,?,?,?,'LIVE')", (e['code'], e['era'], e['lane'], e['sort'], e['a'], e['b'], e['eid'], src))
            ev = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
            n_ev += 1
        if e['region'] is not None:
            conn.execute('UPDATE sys_timeline_event SET region=? WHERE event_id=?', (e['region'], ev))
        if e['parent']:
            conn.execute('UPDATE sys_timeline_event SET parent_id=(SELECT event_id FROM sys_timeline_event WHERE event_code=?) '
                         'WHERE event_id=?', (e['parent'], ev))
        # 구절 여럿 · 장소 — 이 초안이 담은 연결만 갈아 끼운다(사람이 이은 것은 그대로)
        if e['refs'] or e['places']:
            conn.execute('DELETE FROM sys_link_asset WHERE clicked_id=? AND link_type IN (?,?) AND source=?', (ev, LINK_VERS, LINK_ENTI, src))
            for k, (ra, rb) in enumerate(e['refs']):
                conn.execute("INSERT INTO sys_link_asset(clicked_id,target_id,end_id,link_type,sort_order,source,record_status) "
                             "VALUES(?,?,?,?,?,?,'LIVE')", (ev, ra, rb if rb != ra else None, LINK_VERS, k, src))
            for k, (pe, conf) in enumerate(e['places']):
                if pe:
                    conn.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,sort_order,confidence,source,record_status) "
                                 "VALUES(?,?,?,?,?,?,'LIVE')", (ev, pe, LINK_ENTI, k, conf, src))
        for d in e['dates']:
            v = d.get('view', 'MAIN')
            cur = conn.execute('SELECT date_id FROM sys_timeline_date WHERE event_id=? AND view_code=?', (ev, v)).fetchone()
            row = (d.get('from'), d.get('to'), d.get('certainty', 'APPROX'), d.get('label'), d.get('source'))
            if cur:
                conn.execute("UPDATE sys_timeline_date SET y_from=?, y_to=?, certainty=?, label=?, source=?, record_status='LIVE' WHERE date_id=?",
                             row + (cur[0],))
            else:
                conn.execute("INSERT INTO sys_timeline_date(event_id,view_code,y_from,y_to,certainty,label,source,record_status) "
                             "VALUES(?,?,?,?,?,?,?,'LIVE')", (ev, v) + row)
                n_dt += 1
        for t, body in e['texts'].items():
            have = conn.execute("SELECT 1 FROM sys_text_asset WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=? "
                                "AND COALESCE(record_status,'LIVE')='LIVE'", (t, ev, LANG)).fetchone()
            if have:
                continue  # 사람이 고쳤을 수 있다 — 안 덮는다
            conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status) VALUES(?,?,?,?,'LIVE')",
                         (ev, t, LANG, body))
            n_tx += 1
    if commit:
        conn.commit()
    return {'events': n_ev, 'dates': n_dt, 'texts': n_tx, 'notes': notes, 'total': len(evs)}


def undo(conn, commit=True, source=SOURCE):
    ids = [r[0] for r in conn.execute("SELECT event_id FROM sys_timeline_event WHERE source=?", (source,))]
    for ev in ids:
        conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type IN (%s)" % ','.join('?' * len(TEXT_TYPES)), (ev,) + TEXT_TYPES)
        conn.execute('DELETE FROM sys_timeline_date WHERE event_id=?', (ev,))
    if _has(conn, 'sys_link_asset'):
        conn.execute('DELETE FROM sys_link_asset WHERE link_type IN (?,?) AND source=?', (LINK_VERS, LINK_ENTI, source))
    conn.execute('DELETE FROM sys_timeline_event WHERE source=?', (source,))
    if commit:
        conn.commit()
    return len(ids)


def status(conn):
    return conn.execute(
        "SELECT e.era_code, SUM(e.lane='BIBLE'), SUM(e.lane<>'BIBLE'), "
        "(SELECT COUNT(*) FROM sys_timeline_date d WHERE d.event_id IN (SELECT event_id FROM sys_timeline_event x WHERE x.era_code=e.era_code)) "
        "FROM sys_timeline_event e JOIN sys_era_code c ON c.era_code=e.era_code WHERE COALESCE(e.record_status,'LIVE')='LIVE' "
        "GROUP BY e.era_code ORDER BY c.sort_order").fetchall()


# ───────────── selftest ─────────────
def _mini():
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE book_names(book_code INT, lang_code TEXT, short_name TEXT, full_name TEXT);
    CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT, chapter INT, verse INT);
    CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_code TEXT, entity_type TEXT, record_status TEXT);
    CREATE TABLE sys_era_code(era_code TEXT, sort_order INT);
    CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT, record_status TEXT);
    CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, clicked_id INT, target_id INT, end_id INT, link_type TEXT,
      sort_order INT, confidence TEXT, source TEXT, record_status TEXT);
    INSERT INTO sys_entity_master VALUES(7,'PL_SINAI','PLACE','LIVE');
    INSERT INTO book_names VALUES(1,'KO','창','창세기'),(2,'KO','출','출애굽기');
    INSERT INTO sys_era_code VALUES('PRIMEVAL',10),('EXODUS',30);
    INSERT INTO sys_entity_master VALUES(5,'P_MOSES','PERSON','LIVE');
    """)
    vid = 1
    for b in (1, 2):
        for ch in range(1, 16):
            for v in range(1, 32):
                c.execute('INSERT INTO bible_index VALUES(?,?,?,?)', (vid, b, ch, v))
                vid += 1
    return c


def selftest():
    ok = [0, 0]

    def ck(name, cond, got=''):
        ok[0 if cond else 1] += 1
        print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  got=%r' % (got,)))

    c = _mini()
    d = {'events': [
        {'code': 'CREATION', 'era': 'PRIMEVAL', 'lane': 'BIBLE', 'title': '창조', 'ref': '창 1:1-2:3',
         'dates': [{'view': 'MAIN', 'certainty': 'UNKNOWN', 'label': '연대 확정 불가'}], 'world': '확정할 수 없습니다.'},
        {'code': 'EXODUS', 'era': 'EXODUS', 'lane': 'BIBLE', 'title': '출애굽', 'ref': '출 12:1-15:21', 'entity': 'P_MOSES',
         'dates': [{'view': 'EARLY', 'from': -1446, 'to': -1446, 'certainty': 'APPROX', 'label': '15세기설'},
                   {'view': 'LATE', 'from': -1270, 'to': -1250, 'certainty': 'APPROX', 'label': '13세기설'}],
         'evidence': '왕상 6:1'},
        {'code': 'W_X', 'era': 'EXODUS', 'lane': 'WORLD', 'title': '신왕국', 'entity': 'P_NOBODY',
         'dates': [{'view': 'MAIN', 'from': -1550, 'to': -1070, 'certainty': 'RANGE'}]},
    ]}
    pr, notes, evs = plan(c, d)
    ck('초안이 풀린다 — 문제 0 · 사건 3 · 없는 엔티티는 알림', not pr and len(evs) == 3 and any('P_NOBODY' in n for n in notes), (pr, notes))
    ck('구절 구간이 풀렸다', evs[0]['a'] is not None and evs[0]['b'] > evs[0]['a'])
    r = apply(c, d)
    ck('담김 — 사건 3 · 연대 4 · 글 5(제목 3 · 세상 1 · 근거 1)', r['events'] == 3 and r['dates'] == 4 and r['texts'] == 5, r)
    ck('출애굽 연대 두 줄(EARLY·LATE)', c.execute("SELECT COUNT(*) FROM sys_timeline_date WHERE event_id=(SELECT event_id FROM sys_timeline_event WHERE event_code='EXODUS')").fetchone()[0] == 2)
    ck('확정 불가는 숫자 없이 UNKNOWN', c.execute("SELECT y_from, certainty FROM sys_timeline_date WHERE event_id=1").fetchone() == (None, 'UNKNOWN'))
    r2 = apply(c, d)
    ck('멱등', r2['events'] == 0 and r2['dates'] == 0 and r2['texts'] == 0, r2)
    c.execute("UPDATE sys_text_asset SET contents='사람이 고쳤습니다.' WHERE text_type='TL_EVENT_TITLE' AND clicked_id=1")
    apply(c, d)
    ck('사람이 고친 글 불변', c.execute("SELECT contents FROM sys_text_asset WHERE text_type='TL_EVENT_TITLE' AND clicked_id=1").fetchone()[0] == '사람이 고쳤습니다.')
    d['events'][1]['dates'][0]['from'] = -1450
    apply(c, d)
    ck('연대 숫자는 초안이 정본 — 다시 담으면 갱신', c.execute("SELECT y_from FROM sys_timeline_date WHERE view_code='EARLY'").fetchone()[0] == -1450)
    n = undo(c)
    ck('되돌리기 — 사건·연대·글 0', n == 3 and c.execute('SELECT COUNT(*) FROM sys_timeline_event').fetchone()[0] == 0
       and c.execute('SELECT COUNT(*) FROM sys_timeline_date').fetchone()[0] == 0
       and c.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type LIKE 'TL_%'").fetchone()[0] == 0)
    # ★ 세부 사건 — 굵은 사건 아래 · 구절 여럿 · 장소
    apply(c, d)
    dd = {'_source': 'TLDETAIL', 'events': [
        {'code': 'EX_D1', 'parent': 'EXODUS', 'era': 'EXODUS', 'title': '시내산에 이름', 'refs': '출 2:1-5; 창 1:1',
         'dates': [{'from': -1446, 'to': -1446}], 'sort': 5000,
         'places': [{'name': '시내 광야', 'modern': '시나이반도', 'entity': 'PL_SINAI', 'conf': 'TEXT'},
                    {'name': '호렙', 'modern': '', 'conf': 'CONTEXT'}]}]}
    r = apply(c, dd)
    ev = c.execute("SELECT event_id, parent_id, start_vid FROM sys_timeline_event WHERE event_code='EX_D1'").fetchone()
    ck('세부 사건 — 굵은 사건 번호가 붙는다', ev and ev[1] == c.execute("SELECT event_id FROM sys_timeline_event WHERE event_code='EXODUS'").fetchone()[0], ev)
    ck('구절 둘 → 연결 둘 · 첫 구간은 옛 칸에도', c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='TLEV_VERS' AND clicked_id=?", (ev[0],)).fetchone()[0] == 2
       and ev[2] is not None)
    ck('장소 — 용어 있는 곳만 연결 · 확실성', c.execute("SELECT confidence FROM sys_link_asset WHERE link_type='TLEV_ENTI' AND clicked_id=?", (ev[0],)).fetchall() == [('TEXT',)])
    pt = c.execute("SELECT contents FROM sys_text_asset WHERE text_type='TL_EVENT_PLACE' AND clicked_id=?", (ev[0],)).fetchone()[0]
    ck('장소 글 — 한 줄에 한 곳 · 문맥 추정 표시', pt.split('\n')[0] == '시내 광야 · 오늘: 시나이반도' and '앞뒤 문맥에서 추정' in pt, pt)
    apply(c, dd)
    ck('세부 사건 멱등 — 연결이 늘지 않는다', c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 3)
    pr, _, _ = plan(c, {'events': [{'code': 'Z', 'parent': 'NOPE', 'era': 'EXODUS', 'title': 'x', 'dates': [{'from': 1, 'to': 1}]}]})
    ck('막는다: 없는 굵은 사건', any('굵은 사건' in x for x in pr), pr)
    undo(c, source='TLDETAIL')
    ck('세부만 되돌리기 — 굵은 사건은 남고 연결 0', c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 0
       and c.execute("SELECT COUNT(*) FROM sys_timeline_event WHERE event_code='EXODUS'").fetchone()[0] == 1)
    undo(c)
    for bad, word in (
        ({'events': [{'code': 'A', 'era': 'NOPE', 'title': 'x', 'dates': [{'certainty': 'UNKNOWN'}]}]}, '시대 코드'),
        ({'events': [{'code': 'A', 'era': 'EXODUS', 'title': 'x', 'dates': []}]}, '연대 줄이 없다'),
        ({'events': [{'code': 'A', 'era': 'EXODUS', 'title': 'x', 'dates': [{'view': 'EARLY', 'from': -1, 'to': -1}, {'view': 'LATE', 'from': -1, 'to': -1}]}]}, ''),
        ({'events': [{'code': 'A', 'era': 'EXODUS', 'title': 'x', 'dates': [{'view': 'X', 'from': -1, 'to': -1}, {'view': 'LATE', 'from': -1, 'to': -1}]}]}, '다수설'),
        ({'events': [{'code': 'A', 'era': 'EXODUS', 'title': 'x', 'ref': '없는책 1:1', 'dates': [{'from': -1, 'to': -1}]}]}, '못 풀었다'),
        ({'events': [{'code': 'A', 'era': 'EXODUS', 'title': 'x', 'dates': [{'from': 5, 'to': -1}]}]}, 'from > to'),
    ):
        pr, _, _ = plan(c, bad)
        if word:
            ck('막는다: ' + word, any(word in x for x in pr), pr)
        else:
            ck('EARLY·LATE 둘이면 다수설 표시로 친다', not pr, pr)
    print('%d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    args = sys.argv[1:]
    if '--selftest' in args:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if '--draft' in args:
        DRAFT = os.path.join(HERE, args[args.index('--draft') + 1])
    if '--init' in args:
        init(conn)
        conn.commit()
        print('ok')
    elif '--check' in args:
        init(conn)
        pr, notes, evs = plan(conn, load_draft(DRAFT))
        for e in evs:
            ds = ' · '.join('%s %s~%s %s' % (d.get('view', 'MAIN'), d.get('from'), d.get('to'), d.get('certainty')) for d in e['dates'])
            print('%-14s %-10s %-6s %s | %s' % (e['code'], e['era'], e['lane'], e['texts'].get('TL_EVENT_TITLE', '')[:22], ds))
        print('사건 %d · 문제 %d · 알림 %d' % (len(evs), len(pr), len(notes)))
        for p in pr:
            print('  ⚠', p)
        for n in notes:
            print('  ·', n)
    elif '--apply' in args:
        print(apply(conn, load_draft(DRAFT)))
    elif '--undo' in args:
        print('걷음', undo(conn, source=load_draft(DRAFT).get('_source') or SOURCE))
    elif '--status' in args:
        for r in status(conn):
            print('%-10s 성경 %d · 세계 %d · 연대 줄 %d' % r)
    else:
        print(__doc__)
