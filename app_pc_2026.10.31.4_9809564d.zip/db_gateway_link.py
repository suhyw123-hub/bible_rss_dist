# -*- coding: utf-8 -*-
"""db_gateway_link.py — 관문 엔티티 ↔ 소속 낱말 연결 (영구, 2026-09-07).

사용자 지시: 「하나님의 속성 - 편재성, 전능성... **연결되어야 한다.** 먼저
이런 속성 용어가 등록되어야 한다. **하나님의 속성 이외에도 유사한 것들이
많이 있을 것이다 모두 일괄적으로 처리**하도록 하자」.

★★★ **관문이란 무엇인가** — 「하나님의 속성」·「성령의 열매」처럼 **여럿을
  묶어 부르는 이름**이다. 실측(2026-09-07) 그런 항목이 18개인데 **하나도
  안 이어져 있었다**(DOCTRINE 46 중 40이 엔티티 연결 0).

★★ **재료가 이미 글 안에 있다** — 관문의 설명문이 소속 낱말을 구절과 함께
  적어 두었다(「자존성(Aseity): … 출3:14」·「사랑(agape): … 롬13:10」).
  §205차 ⑯ 과 같은 꼴이다 — 흐름이 모아 둔 구절 위에 용어를 세운 그 자리.
  ⚠ **그래도 기계가 뽑지 않는다** — 이름이 「자비·인자(Mercy)」처럼 겹쳐 있고
    우리 용어 이름과 글자가 다르다(자비 → 「인애 · 헤세드」). §165차 그대로
    **사람이 이 표에 적고 도구는 실재만 확인한다.**

★ **저장은 통합 표 하나** — `sys_link_asset(ENTI_ENTI, rel_code='ASPECT')`.
  clicked=관문 · target=소속. **새 표 0**이고 화면(`_fetch_related` 서브트리)이
  이미 그린다 — §168차 민족·우상이 낸 길을 그대로 탄다.

⚠ **파일 원장이다**(§183차 ⑤) — DB 가 무너져도 이 파일 하나로 되살아난다.
⚠ **연결은 `link_picker.add` 를 쓴다**(§135차) — 없는 자산을 거부하는 문이
  거기 있다. 여기서 INSERT 를 또 쓰면 그 문을 비껴간다.

사용:  python db_gateway_link.py --selftest | --check | --apply | --list
"""
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

#: **관문 → 소속** — 사람이 적는다. 값은 소속 엔티티 코드.
#:
#: ⚠ **관문의 설명문이 근거다** — 여기 적는 것은 그 글에 이미 이름과 구절이
#:   함께 적힌 것들뿐이다. 설명문에 없는 것을 여기서 지어내지 않는다.
#: ⚠ **없는 용어는 적지 않는다** — `check` 가 그 자리에서 잡는다.
GATEWAY = {
    # ── 하나님의 속성 (설명문이 비공유/공유로 갈라 적어 두었다) ──────────
    'D_DIVINE_ATTRIBUTES': [
        # 비공유적 — 피조물과 본질적으로 다르다
        'T_ASEITY',          # 자존성 · 출3:14
        'T_IMMUTABILITY',    # 불변성 · 말3:6
        'T_OMNIPRESENCE',    # 편재성 · 시139:7~12
        'T_OMNISCIENCE',     # 전지성 · 시139:1~6
        'T_SHADDAI',         # 전능성 — 「전능자 · 샤다이」가 그 이름이다
        'T_AION',            # 무한성·영원성 — 「세대 · 영원 · 아이온」
        # 공유적 — 사람에게 제한적으로 비친다
        'T_KADOSH',          # 거룩 · 사6:3
        'T_AHAV',            # 사랑 · 요일4:8
        'T_TSEDEQ',          # 공의 · 시89:14
        'T_HESED',           # 자비·인자 · 출34:6~7
        'T_EMET',            # 진실하심 · 민23:19 · 딛1:2
        'T_TOV',             # 선하심 · 시107:1
    ],
    # ── 성령의 은사 (2026-09-07 사용자 지시 「성령의 은사 용어를 진행하라」)
    #   ⚠ 설명문이 목록을 **넷**으로 적었다(계시·표적·봉사·직책). 그 가운데
    #     **낱말로 설 수 있는 것**만 용어로 세웠다 — 「사도」·「목사」는 직책이라
    #     인물·그룹 축이고, 「병 고침」·「다스림」은 우리 용어가 아직 없다.
    #   ⚠ 「능력 · 뒤나미스」·「긍휼 · 라함」·「믿음」은 **이미 있어** 그대로 잇는다.
    'D_GIFTS_OF_SPIRIT': [
        'T_CHOKMAH',         # 지혜의 말씀 — 고전12:8
        'T_DAAT',            # 지식의 말씀 — 고전12:8
        'T_PROPHETEIA',      # 예언 — 롬12:6 · 고전12:10
        'T_GLOSSA',          # 방언 — 고전12:10
        'T_DIDASKALIA',      # 가르침 — 롬12:7
        'T_DYNAMIS',         # 능력 행함 — 고전12:10
        'T_RACHAM',          # 긍휼 — 롬12:8
    ],
    # ── 성령의 열매 (갈5:22~23 아홉 — 우리 용어가 있는 것만) ────────────
    #   ⚠⚠ **아홉 중 넷만 잇는다 — 그것이 정직한 상태다.** 나머지 다섯은
    #     우리 용어가 없거나 **엄밀히 다른 낱말**이다(아래 EXCLUDE).
    #     비슷하다고 갖다 붙이면 그 자리에서 틀린 연결이 된다(§165차).
    'D_FRUIT_OF_SPIRIT': [
        'T_AHAV',            # 사랑 아가페 — 우리 용어가 그 낱말을 안고 있다
        'T_SIMCHAH',         # 희락 — 「기쁨 · 심하」
        'T_SHALOM',          # 화평 — 「평강 · 샬롬」
        'T_TOV',             # 양선 — 「좋다 · 선 · 토브」(앵커에 G18 이 있다)
    ],
}

#: **아직 관문이 못 되는 것** — 실측으로 갈랐다(2026-09-07).
#:
#: ★★ **관문이 되려면 설명문이 「낱말」을 열거해야 한다.** 실측 나머지 일곱은
#:   구절 참조와 **국면**을 열거하지 낱말을 열거하지 않는다:
#:     D_IMAGO_DEI          본질적 · 관계적 · 기능적   ← 한 개념의 세 측면
#:     D_SOVEREIGNTY        창조 · 섭리 · 구원        ← 영역이지 낱말이 아니다
#:     D_UNION_WITH_CHRIST  요15 · 롬6 · 갈2 …        ← 구절 참조
#:     D_PERSEVERANCE       성부의 선택 · 성자의 중보   ← 근거이지 소속이 아니다
#:     D_ILLUMINATION · D_INDWELLING · D_GIFTS_OF_SPIRIT
#:   ⇒ **억지로 잇지 않는다** — 「국면」을 소속으로 넣으면 그 관문이 「무엇의
#:     묶음인지」가 흐려진다(§205차 ⑬ 「축은 자격 심사가 아니다」와 같은 결).
#: ✅ `D_GIFTS_OF_SPIRIT` 는 **용어 다섯을 새로 세워 관문이 섰다**(2026-09-07)
#:   — 지혜·지식·예언·방언·가르침. 병 고침·다스림·섬김은 아직 용어가 없다.
NOT_YET = ('D_IMAGO_DEI', 'D_SOVEREIGNTY', 'D_UNION_WITH_CHRIST',
           'D_PERSEVERANCE', 'D_ILLUMINATION', 'D_INDWELLING')

#: **일부러 안 이은 것** — 근거를 함께 적는다(§205차 규칙).
EXCLUDE = {
    ('D_DIVINE_ATTRIBUTES', 'T_HEMAH'):
        '진노는 설명문의 속성 목록에 **없다**. 하나님의 진노는 성경의 큰 주제이나 '
        '이 관문이 세운 열두 갈래에 저자가 넣지 않았다 — 목록을 우리가 늘리지 않는다',
    ('D_FRUIT_OF_SPIRIT', 'T_RUACH'):
        '성령은 열매를 **맺게 하시는 분**이지 열매 하나가 아니다. 넣으면 아홉이 열이 된다',
    ('D_FRUIT_OF_SPIRIT', 'T_HYPOMONE'):
        '갈5:22 의 「오래 참음」은 **마크로튀미아**(사람에 대한 인내)이고 우리 '
        '「인내 · 휘포모네」는 **휘포모네**(환난 중 견딤)라 **다른 낱말**이다. '
        '비슷해 보인다고 이으면 그 자리에서 틀린 연결이 된다',
    ('D_FRUIT_OF_SPIRIT', 'T_HESED'):
        '갈5:22 의 「자비」는 **크레스토테스**(친절)이고 헤세드는 **언약적 인자**다. '
        '헤세드는 「하나님의 속성」 쪽 「자비·인자(출34:6)」가 제자리다',
    ('D_FRUIT_OF_SPIRIT', 'D_FAITH'):
        '갈5:22 의 「충성」은 **피스티스**(신실함)이고 우리 「믿음」은 **교리**라 '
        '축이 다르다. 충성·온유·절제에 맞는 용어는 **아직 없다**(다음 배치)',
}


def _nm(conn, eid, lang='KO'):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        " AND clicked_id=? AND lang_code=? AND COALESCE(record_status,'LIVE')"
        "='LIVE' LIMIT 1", (eid, lang)).fetchone()
    return r[0] if r else ''


def _eid(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE "
                     "entity_code=? AND record_status='LIVE'", (code,)).fetchone()
    return r[0] if r else None


def check(conn, table=None):
    """표를 재서 문제를 낸다 → (없는 것, 이을 것, 이미 있는 것)."""
    import entity_relation as ER
    tbl = table if table is not None else GATEWAY
    missing, todo, have = [], [], []
    for gate, members in tbl.items():
        g = _eid(conn, gate)
        if g is None:
            missing.append('관문 없음: %s' % gate)
            continue
        seen = set()
        for m in members:
            if m in seen:
                missing.append('%s — 같은 소속을 두 번 적었다: %s' % (gate, m))
                continue
            seen.add(m)
            if (gate, m) in EXCLUDE:
                missing.append('%s — EXCLUDE 에 적어 두고 표에도 적었다: %s'
                               % (gate, m))
                continue
            t = _eid(conn, m)
            if t is None:
                missing.append('%s — 소속 없음: %s' % (gate, m))
                continue
            if g == t:
                missing.append('%s — 자기 자신을 이었다' % gate)
                continue
            n = conn.execute(
                "SELECT COUNT(*) FROM sys_link_asset WHERE link_type=? "
                "AND clicked_id=? AND target_id=? AND rel_code=?",
                (ER.LT, g, t, ER.GATEWAY[0])).fetchone()[0]
            (have if n else todo).append((gate, g, m, t))
    return missing, todo, have


def apply(conn, table=None):
    """이을 것을 잇는다 — 멱등. `link_picker.add` 한 문을 쓴다(§135차)."""
    import entity_relation as ER
    import link_picker as LP
    bad, todo, have = check(conn, table)
    if bad:
        for b in bad:
            print('X %s' % b)
        print('문제가 있어 잇지 않습니다 — --check 로 확인.')
        return 0
    n = 0
    for gate, g, m, t in todo:
        if LP.add(conn, ('ENTITY', g), ('ENTITY', t), scope='SYS',
                  rel=ER.GATEWAY[0]):
            n += 1
    conn.commit()
    print('이은 것 %d · 이미 있던 것 %d' % (n, len(have)))
    return n


def listing(conn):
    import entity_relation as ER
    for gate in GATEWAY:
        g = _eid(conn, gate)
        if g is None:
            print('%s — (없는 관문)' % gate)
            continue
        rows = conn.execute(
            "SELECT target_id FROM sys_link_asset WHERE link_type=? "
            "AND clicked_id=? AND rel_code=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'",
            (ER.LT, g, ER.GATEWAY[0])).fetchall()
        print('%-24s %-16s 소속 %d' % (gate, _nm(conn, g)[:16], len(rows)))
        for (t,) in rows:
            print('    %s' % _nm(conn, t))


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    import entity_relation as ER
    t('★ 관문 어휘가 하나뿐', len(ER.GATEWAY) == 1, ER.GATEWAY)
    t('  다른 갈래와 안 겹친다',
      not (set(ER.GATEWAY) & (set(ER.PERSON) | set(ER.IDOL) | set(ER.NATION))))

    # 표 자체
    t('★ 관문마다 소속이 둘 이상',
      all(len(v) >= 2 for v in GATEWAY.values()),
      {k: len(v) for k, v in GATEWAY.items()})
    dup = [(g, m) for g, v in GATEWAY.items()
           for m in v if v.count(m) > 1]
    t('  같은 소속을 두 번 안 적었다', not dup, dup)
    t('  관문이 제 소속에 안 들어간다',
      not [g for g, v in GATEWAY.items() if g in v])
    t('★ EXCLUDE 는 근거를 적는다',
      all(len(v) > 20 for v in EXCLUDE.values()))
    t('  EXCLUDE 와 표가 안 겹친다',
      not [k for k in EXCLUDE if k[1] in GATEWAY.get(k[0], ())])
    t('★ 아직 관문이 못 되는 것은 표에 없다',
      not (set(NOT_YET) & set(GATEWAY)), set(NOT_YET) & set(GATEWAY))

    # 메모리 DB — 실 DB 를 한 글자도 안 건드린다(§0-5)
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
              " entity_code TEXT, entity_type TEXT, record_status TEXT)")
    c.execute("CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT,"
              " lang_code TEXT, contents TEXT, record_status TEXT)")
    # ⚠ **칸 이름을 짐작하지 않는다** — `link_picker.add` 가 `note`·`is_key`
    #   같은 칸에 쓴다. 손으로 적으면 그 자리에서 `no such column` 이 난다
    #   (실측으로 잡았다). 실 DB 스키마를 읽어 시험 표를 만든다.
    _cols = ("sys_link_id INTEGER PRIMARY KEY, clicked_id INT, target_id INT,"
             " link_type TEXT, rel_code TEXT, sort_order INT,"
             " record_status TEXT, origin_id INT, chain_code TEXT, end_id INT,"
             " note TEXT, milestone_type TEXT, importance INT, is_key INT,"
             " source TEXT, confidence TEXT, lemma_id INT, is_directed INT,"
             " relation_cat TEXT, rank_score REAL")
    c.execute("CREATE TABLE sys_link_asset(%s)" % _cols)
    for i, (code, ty) in enumerate(
            (('G_X', 'DOCTRINE'), ('T_A', 'TERM'), ('T_B', 'TERM')), 1):
        c.execute("INSERT INTO sys_entity_master VALUES(?,?,?,'LIVE')",
                  (i, code, ty))
        c.execute("INSERT INTO sys_text_asset VALUES(?,'ENTITY_NAME','KO',"
                  "?,'LIVE')", (i, code))
    T = {'G_X': ['T_A', 'T_B']}
    bad, todo, have = check(c, T)
    t('★ 이을 것을 찾는다', not bad and len(todo) == 2 and not have,
      (bad, len(todo), len(have)))
    # 잇기 — link_picker 를 통해서
    try:
        import link_picker as LP
        for _g, g, _m, tt in todo:
            LP.add(c, ('ENTITY', g), ('ENTITY', tt), scope='SYS',
                   rel=ER.GATEWAY[0])
        bad2, todo2, have2 = check(c, T)
        t('  이은 뒤에는 「이미 있다」', not todo2 and len(have2) == 2,
          (len(todo2), len(have2)))
        n0 = c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        for _g, g, _m, tt in todo:
            LP.add(c, ('ENTITY', g), ('ENTITY', tt), scope='SYS',
                   rel=ER.GATEWAY[0])
        t('★ 멱등 — 두 번 이어도 안 는다',
          c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == n0)
    except Exception as e:
        t('  link_picker 로 잇는다', False, e)
    # 탐지력
    t('★ 없는 소속을 잡는다',
      any('소속 없음' in x for x in check(c, {'G_X': ['T_A', 'T_ZZZ']})[0]))
    t('  없는 관문을 잡는다',
      any('관문 없음' in x for x in check(c, {'G_ZZZ': ['T_A', 'T_B']})[0]))
    t('  자기 자신을 잡는다',
      any('자기 자신' in x for x in check(c, {'G_X': ['G_X', 'T_A']})[0]))
    c.close()

    print('db_gateway_link selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if '--check' in a:
        bad, todo, have = check(conn)
        for b in bad:
            print('X %s' % b)
        print('문제 %d · 이을 것 %d · 이미 있는 것 %d'
              % (len(bad), len(todo), len(have)))
        for g, _gi, m, _ti in todo:
            print('  + %-24s %s' % (g, m))
    if '--apply' in a:
        apply(conn)
    if '--list' in a:
        listing(conn)
