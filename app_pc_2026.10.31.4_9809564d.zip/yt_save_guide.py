"""유튜브 간편 저장 — 사용 안내 글 (2026-10-11 · 사용자 「한 줄로 입력해 놓고 사용방법을 안내했다고 생각하는가 ·
대표 브라우저 3개를 각각 고르고 자세히 설명하라」).

글의 단일 소스 — 화면(`yt_save_view`)은 폴백으로, 적재 스크립트(`temp_db_p379_ytguide.py`)는 ui_strings 로 이것을 쓴다.
열쇠: YTS_G_EXT · YTS_G_LIST · YTS_G_COPY(설정 없이 주소 복사) · YTS_G_NOTE(공통 주의).
⚠ 북마크 안내(YTS_G_CHROME·EDGE·FIREFOX)는 2026-10-12 북마크 단추 폐기와 함께 걷었다.
⚠ 브라우저의 메뉴 이름은 그 브라우저 화면에 실제로 적힌 낱말을 「」로 쓴다 — 바꾸면 사용자가 못 찾는다.
⚠ 다른 9개 언어는 아직 없다 — i18n 이 EN 으로 물러선다(EN 은 영어 브라우저의 메뉴 이름).
"""

GUIDE = {
    'KO': {
        'YTS_G_EXT': (
            '확장 프로그램 「+Hagah」 — 단추 하나로 저장(크롬·엣지·웨일 · 추천)\n'
            '\n'
            '처음 한 번만 넣습니다. 스토어 등록 전에는 「압축 해제된 확장 프로그램」으로 넣습니다.\n'
            '1. 이 화면 위의 [확장 프로그램 폴더 열기] 를 누릅니다. browser_ext 폴더가 열립니다.\n'
            '2. 브라우저 맨 위 주소창에 다음을 적고 Enter 를 누릅니다.\n'
            '   · 크롬: chrome://extensions   · 엣지: edge://extensions   · 웨일: whale://extensions\n'
            '3. 「개발자 모드」 스위치를 켭니다(크롬·웨일은 오른쪽 위 · 엣지는 왼쪽 아래).\n'
            '4. 「압축해제된 확장 프로그램을 로드합니다」(엣지는 「압축을 푼 항목 로드」)를 누르고 1번에서 열린 browser_ext 폴더를 선택합니다.\n'
            '5. 주소창 오른쪽의 퍼즐 조각 아이콘 ▸ 「+Hagah」 옆의 핀을 눌러 툴바에 고정합니다.\n'
            '\n'
            '쓰는 법 — 유튜브 영상이나 읽던 글에서 툴바의 하가 아이콘을 누릅니다. 화면 오른쪽 아래에 「저장할까요?」 창이 뜹니다.\n'
            '· 빈 곳을 오른쪽 클릭 ▸ 「+Hagah」, 링크 위에서 오른쪽 클릭 ▸ 「+Hagah」도 됩니다.\n'
            '· 유튜브 = 「내 영상」(온라인 영상 탭) · 그 밖의 쪽 = 「내 자료 · 웹 글」(연구/설교노트 탭).\n'
            '· 제목과 주소만 저장합니다. 글 본문은 가져오지 않습니다. 구절·주요용어는 그 창의 [연결하며 저장 ▾] 에서 선택합니다.\n'
            '· 아이콘에 초록 ✓ = 하가에 보냈습니다 · 빨간 ! = 하가가 꺼져 있습니다(하가 앱이나 트레이를 켭니다).\n'
            '⚠ browser_ext 폴더를 옮기거나 지우면 확장이 사라집니다. 하가 폴더 안에 그대로 두십시오.'),
        'YTS_G_LIST': (
            '「+Hagah」 재생목록 — 유튜브의 「저장」 단추로 모으기(폰·TV·PC 어디서든)\n'
            '\n'
            '★ 핵심은 공개 범위 「일부 공개」입니다. 「비공개」로 두면 하가가 목록을 읽지 못합니다.\n'
            '\n'
            '처음 한 번만 합니다.\n'
            '1. 유튜브 앱(또는 youtube.com)에서 아무 영상이나 열고, 영상 아래의 [저장] 단추 ▸ [새 재생목록] 을 누릅니다.\n'
            '2. 이름은 「+Hagah」로 적습니다(다른 이름이어도 됩니다).\n'
            '3. 공개 범위에서 「일부 공개」 를 선택하고 [만들기] 를 누릅니다.\n'
            '4. 그 재생목록의 주소를 복사합니다.\n'
            '   · 폰: [내 페이지](또는 [보관함]) ▸ 재생목록 ▸ Hagah ▸ [공유] ▸ [링크 복사]\n'
            '   · PC: youtube.com 왼쪽 메뉴 ▸ 재생목록 ▸ Hagah ▸ [공유] ▸ [복사]\n'
            '5. 이 화면 위의 「+Hagah 재생목록 주소」 칸에 붙여 넣고 [저장하고 지금 가져오기] 를 누릅니다.\n'
            '\n'
            '쓰는 법 — 어느 기기에서든 영상 아래 [저장] ▸ Hagah 에 체크하면 끝입니다.\n'
            '· 하가(앱 또는 트레이)가 몇 시간마다 목록을 읽어 「내 영상」으로 들입니다. 구절·주요용어는 아래 「받은 영상」에서 [연결 고치기] 로 잇습니다.\n'
            '· 폰에서 담은 영상도 PC 하가가 들인 뒤 폰과 동기화하면 폰의 하가에도 갑니다.\n'
            '⚠ 이미 만든 목록이 「비공개」라면: 그 재생목록 ▸ 연필(수정) 단추 ▸ 공개 범위 ▸ 「일부 공개」 로 바꿉니다.\n'
            '⚠ 「일부 공개」는 주소를 아는 사람만 볼 수 있습니다. 재생목록 주소를 남에게 알리지 마십시오.\n'
            '⚠ 「나중에 볼 동영상」은 유튜브가 바깥 프로그램에 열어 주지 않아 쓸 수 없습니다. 꼭 새 재생목록을 만드십시오.\n'
            '⚠ 몇 시간 사이에 15개 넘게 담으면 앞의 것이 빠질 수 있습니다(유튜브가 최근 15개만 알려 줍니다).'),
        'YTS_G_COPY': (
            '설정 없이 바로 쓰는 방법 — 주소를 복사하고 하가로 돌아오기\n'
            '\n'
            '1. 유튜브에서 저장하고 싶은 영상을 엽니다.\n'
            '2. 영상 주소를 복사합니다. 둘 중 하나로 하면 됩니다.\n'
            '   · 영상 아래의 [공유] 단추 ▸ 뜨는 창의 [복사]\n'
            '   · 브라우저 맨 위 주소창을 한 번 눌러 주소 전체가 파랗게 칠해지면 Ctrl + C\n'
            '3. 화면 아래 작업표시줄에서 하가 아이콘을 누릅니다.\n'
            '   하가 창을 닫아 두었고 트레이만 켜져 있으면, 화면 오른쪽 아래(시계 옆) 트레이의 하가 아이콘을 누릅니다.\n'
            '   트레이 아이콘이 안 보이면 시계 옆의 ^ 단추를 눌러 숨은 아이콘을 펼칩니다.\n'
            '4. 「저장할까요?」 창이 뜨면 [저장] 을 누릅니다. 구절·주요용어를 선택하고 저장하려면 [연결하며 저장 ▾] 를 누릅니다.\n'
            '\n'
            '· 복사만 하고 하가로 오지 않으면 묻지 않습니다(다른 일로 복사한 것일 수 있기 때문입니다).\n'
            '· 한 번 물은 주소와 이미 저장한 영상은 다시 묻지 않습니다. 그래도 저장하려면 이 화면 위의 [복사한 주소 저장] 을 누릅니다.\n'
            '· 이 방법을 쓰려면 이 화면 위의 첫째 체크(「유튜브 주소를 복사하고 하가…」)가 켜져 있어야 합니다.'),
        'YTS_G_NOTE': (
            '단추가 작동하려면 — 하가 앱이 켜져 있거나 트레이 아이콘이 떠 있어야 하고, '
            '이 화면 위의 둘째 체크(「브라우저의 「+Hagah」 북마크 단추 받기」)가 켜져 있어야 합니다.\n'
            '제목과 채널 이름만 받고(설명문은 받지 않습니다) 주소는 이 PC 안에서만 오갑니다.'),
    },
    'EN': {
        'YTS_G_EXT': (
            'Browser extension “+Hagah” — one click (Chrome, Edge, Whale · recommended)\n'
            '\n'
            'Install once. Until it is on the store, load it as an unpacked extension.\n'
            '1. Click [Open extension folder] at the top of this screen. The browser_ext folder opens.\n'
            '2. Type this in the browser address bar and press Enter:\n'
            '   · Chrome: chrome://extensions   · Edge: edge://extensions   · Whale: whale://extensions\n'
            '3. Turn on “Developer mode” (top right in Chrome and Whale · bottom left in Edge).\n'
            '4. Click “Load unpacked” and choose the browser_ext folder from step 1.\n'
            '5. Click the puzzle-piece icon right of the address bar ▸ the pin next to “+Hagah”.\n'
            '\n'
            'Use — on a YouTube video or a page you are reading, click the Hagah icon. A “Save?” window appears at the bottom right.\n'
            '· Right-click the page ▸ “+Hagah”, or right-click a link ▸ “+Hagah”.\n'
            '· YouTube = “My videos” (Online video tab) · other pages = “My materials · Web page” (Study notes tab).\n'
            '· Only the title and address are saved, never the page text. Pick verses and key terms with [Save with links ▾].\n'
            '· Green ✓ = sent to Hagah · red ! = Hagah is not running (start the Hagah app or tray).\n'
            '⚠ Do not move or delete the browser_ext folder — the extension disappears. Leave it inside the Hagah folder.'),
        'YTS_G_LIST': (
            '“+Hagah” playlist — collect with YouTube’s Save button (phone, TV or PC)\n'
            '\n'
            '★ The key is the visibility “Unlisted”. If it is “Private”, Hagah cannot read the list.\n'
            '\n'
            'Do this once.\n'
            '1. In the YouTube app (or youtube.com) open any video and tap [Save] below it ▸ [New playlist].\n'
            '2. Name it “+Hagah” (any name works).\n'
            '3. Set visibility to “Unlisted” and tap [Create].\n'
            '4. Copy the playlist link.\n'
            '   · Phone: [You] (or [Library]) ▸ Playlists ▸ Hagah ▸ [Share] ▸ [Copy link]\n'
            '   · PC: youtube.com left menu ▸ Playlists ▸ Hagah ▸ [Share] ▸ [Copy]\n'
            '5. Paste it into “+Hagah playlist address” at the top of this screen and click [Save and fetch now].\n'
            '\n'
            'Use — on any device, tap [Save] under a video ▸ tick Hagah. That is all.\n'
            '· Hagah (app or tray) reads the list every few hours and adds the videos to “My videos”. Link verses and key terms later with [Edit links] in “Received videos” below.\n'
            '· Videos saved on your phone reach the phone app too, after the PC adds them and you sync the phone.\n'
            '⚠ If the list is already “Private”: open the playlist ▸ pencil (edit) ▸ visibility ▸ “Unlisted”.\n'
            '⚠ “Unlisted” means anyone with the link can see it. Do not share the playlist link.\n'
            '⚠ “Watch later” cannot be used — YouTube does not open it to other programs. Make a new playlist.\n'
            '⚠ If you save more than 15 videos within a few hours, the oldest may be missed (YouTube reports only the latest 15).'),
        'YTS_G_COPY': (
            'No setup needed — copy the address and come back to Hagah\n'
            '\n'
            '1. Open the video you want to save on YouTube.\n'
            '2. Copy the video address, either way:\n'
            '   · the [Share] button under the video ▸ [Copy] in the window that opens\n'
            '   · click the address bar at the top of the browser once (the whole address turns blue), then Ctrl + C\n'
            '3. Click the Hagah icon on the taskbar at the bottom of the screen.\n'
            '   If the Hagah window is closed and only the tray is running, click the Hagah icon in the tray at the bottom right (next to the clock).\n'
            '   If you can\'t see it, click the ^ next to the clock to show hidden icons.\n'
            '4. When the "Save?" window appears, press [Save]. To pick verses and key terms first, press [Save with links ▾].\n'
            '\n'
            '· If you only copy and don\'t come back to Hagah, nothing is asked (you may have copied it for something else).\n'
            '· An address already asked about, or a video already saved, is not asked again. To save anyway, press [Save copied link] at the top of this screen.\n'
            '· This needs the first checkbox at the top of this screen to be on.'),
        'YTS_G_NOTE': (
            'For the button to work — Hagah must be open or its tray icon running, and the second checkbox '
            'at the top of this screen (Accept the browser “+Hagah” bookmark button) must be on.\n'
            'Only the title and channel name are taken (not the description), and the address stays on this PC.'),
    },
}

TABS = (('EXT', 'YTS_GT_EXT', '확장 프로그램(추천)', 'Extension (recommended)'),
        ('LIST', 'YTS_GT_LIST', '+Hagah 재생목록', '+Hagah playlist'),
        ('COPY', 'YTS_GT_COPY', '주소 복사로 저장', 'Copy the address'),
        ('CHROME', None, 'Chrome', 'Chrome'),
        ('EDGE', None, 'Edge', 'Edge'),
        ('FIREFOX', None, 'Firefox', 'Firefox'))


def default_browser():
    """윈도우 기본 브라우저 — 'CHROME' | 'EDGE' | 'FIREFOX' | ''(모름). 처음 선택할 갈래를 정한다."""
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                           r'Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice')
        prog = (winreg.QueryValueEx(k, 'ProgId')[0] or '').lower()
    except Exception:
        return ''
    if 'chrome' in prog:
        return 'CHROME'
    if 'msedge' in prog:
        return 'EDGE'
    if 'firefox' in prog:
        return 'FIREFOX'
    return ''


if __name__ == '__main__':
    for lang, d in GUIDE.items():
        assert set(d) == set(GUIDE['KO']), lang
    print('ok', default_browser())
