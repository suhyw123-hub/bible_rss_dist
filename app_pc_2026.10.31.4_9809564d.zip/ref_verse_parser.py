"""Verse reference string parser for 19th-century theological texts (Torrey era).

Converts abbreviations like 'Jno. 4:24' or 'Col. i:15' to (bcode, ch, vs).
Handles Roman numeral chapters, verse ranges, and common OCR artifacts.
"""
import re

# bcode integers 1-66 matching bible_index.bcode
_B = dict(
    GEN=1, EXO=2, LEV=3, NUM=4, DEU=5, JOS=6, JDG=7, RUT=8,
    SA1=9, SA2=10, KI1=11, KI2=12, CH1=13, CH2=14,
    EZR=15, NEH=16, EST=17, JOB=18, PSA=19, PRO=20,
    ECC=21, SON=22, ISA=23, JER=24, LAM=25, EZE=26,
    DAN=27, HOS=28, JOE=29, AMO=30, OBA=31, JON=32,
    MIC=33, NAH=34, HAB=35, ZEP=36, HAG=37, ZEC=38, MAL=39,
    MAT=40, MRK=41, LUK=42, JHN=43, ACT=44, ROM=45,
    CO1=46, CO2=47, GAL=48, EPH=49, PHP=50, COL=51,
    TH1=52, TH2=53, TI1=54, TI2=55, TIT=56, PHM=57,
    HEB=58, JAM=59, PE1=60, PE2=61,
    JN1=62, JN2=63, JN3=64, JUD=65, REV=66,
)

# Abbreviation -> bcode.  Longer / more-specific entries must be tried first.
# Build sorted list at module load; callers should use parse_refs().
_RAW_ABBREVS = [
    # Prefixed books (must come before bare 'Sam', 'Cor', 'Tim', etc.)
    ('I Sam',    _B['SA1']), ('II Sam',   _B['SA2']),
    ('I Sam.',   _B['SA1']), ('II Sam.',  _B['SA2']),
    ('I Kings',  _B['KI1']), ('II Kings', _B['KI2']),
    ('I Ki',     _B['KI1']), ('II Ki',    _B['KI2']),
    ('I Ki.',    _B['KI1']), ('II Ki.',   _B['KI2']),
    ('I Chr',    _B['CH1']), ('II Chr',   _B['CH2']),
    ('I Chr.',   _B['CH1']), ('II Chr.',  _B['CH2']),
    ('I Chron',  _B['CH1']), ('II Chron', _B['CH2']),
    ('I Chron.', _B['CH1']), ('II Chron.',_B['CH2']),
    ('I Cor',    _B['CO1']), ('II Cor',   _B['CO2']),
    ('I Cor.',   _B['CO1']), ('II Cor.',  _B['CO2']),
    ('I Thess',  _B['TH1']), ('II Thess', _B['TH2']),
    ('I Thess.', _B['TH1']), ('II Thess.',_B['TH2']),
    ('I Thes',   _B['TH1']), ('II Thes',  _B['TH2']),
    ('I Tim',    _B['TI1']), ('II Tim',   _B['TI2']),
    ('I Tim.',   _B['TI1']), ('II Tim.',  _B['TI2']),
    ('I Pet',    _B['PE1']), ('II Pet',   _B['PE2']),
    ('I Pet.',   _B['PE1']), ('II Pet.',  _B['PE2']),
    ('I Jno',    _B['JN1']), ('II Jno',   _B['JN2']), ('III Jno',  _B['JN3']),
    ('I Jno.',   _B['JN1']), ('II Jno.',  _B['JN2']), ('III Jno.', _B['JN3']),
    ('I John',   _B['JN1']), ('II John',  _B['JN2']), ('III John', _B['JN3']),
    ('I Jn',     _B['JN1']), ('II Jn',    _B['JN2']), ('III Jn',   _B['JN3']),
    # Single books
    ('Gen',   _B['GEN']), ('Gen.',  _B['GEN']),
    ('Ex',    _B['EXO']), ('Ex.',   _B['EXO']),
    ('Exod',  _B['EXO']), ('Exod.', _B['EXO']),
    ('Lev',   _B['LEV']), ('Lev.',  _B['LEV']),
    ('Num',   _B['NUM']), ('Num.',  _B['NUM']),
    ('Deu',   _B['DEU']), ('Deu.',  _B['DEU']),
    ('Deut',  _B['DEU']), ('Deut.', _B['DEU']),
    ('Dt',    _B['DEU']), ('Dt.',   _B['DEU']),
    ('Josh',  _B['JOS']), ('Josh.', _B['JOS']),
    ('Jud',   _B['JDG']), ('Jud.',  _B['JDG']),
    ('Judg',  _B['JDG']), ('Judg.', _B['JDG']),
    ('Judges',_B['JDG']),
    ('Ruth',  _B['RUT']),
    ('Sam',   _B['SA1']), ('Sam.',  _B['SA1']),  # bare 'Sam' -> 1 Sam
    ('Ezra',  _B['EZR']), ('Ezr.',  _B['EZR']),
    ('Neh',   _B['NEH']), ('Neh.',  _B['NEH']),
    ('Esth',  _B['EST']), ('Esth.', _B['EST']),
    ('Est',   _B['EST']), ('Est.',  _B['EST']),
    ('Job',   _B['JOB']),
    ('Ps',    _B['PSA']), ('Ps.',   _B['PSA']),
    ('Psa',   _B['PSA']), ('Psa.',  _B['PSA']),
    ('Psalm', _B['PSA']),
    ('Prov',  _B['PRO']), ('Prov.', _B['PRO']),
    ('Pro',   _B['PRO']), ('Pro.',  _B['PRO']),
    ('Eccl',  _B['ECC']), ('Eccl.', _B['ECC']),
    ('Ecc',   _B['ECC']), ('Ecc.',  _B['ECC']),
    ('Song',  _B['SON']),
    ('Isa',   _B['ISA']), ('Isa.',  _B['ISA']),
    ('Is',    _B['ISA']), ('Is.',   _B['ISA']),
    ('Isaiah',_B['ISA']),
    ('Jer',   _B['JER']), ('Jer.',  _B['JER']),
    ('Lam',   _B['LAM']), ('Lam.',  _B['LAM']),
    ('Ezek',  _B['EZE']), ('Ezek.', _B['EZE']),
    ('Eze',   _B['EZE']), ('Eze.',  _B['EZE']),
    ('Dan',   _B['DAN']), ('Dan.',  _B['DAN']),
    ('Hos',   _B['HOS']), ('Hos.',  _B['HOS']),
    ('Joel',  _B['JOE']),
    ('Amos',  _B['AMO']),
    ('Obad',  _B['OBA']), ('Obad.', _B['OBA']),
    ('Jonah', _B['JON']), ('Jon.',  _B['JON']),
    ('Mic',   _B['MIC']), ('Mic.',  _B['MIC']),
    ('Nah',   _B['NAH']), ('Nah.',  _B['NAH']),
    ('Hab',   _B['HAB']), ('Hab.',  _B['HAB']),
    ('Zeph',  _B['ZEP']), ('Zeph.', _B['ZEP']),
    ('Zep',   _B['ZEP']), ('Zep.',  _B['ZEP']),
    ('Hag',   _B['HAG']), ('Hag.',  _B['HAG']),
    ('Zech',  _B['ZEC']), ('Zech.', _B['ZEC']),
    ('Zec',   _B['ZEC']), ('Zec.',  _B['ZEC']),
    ('Mal',   _B['MAL']), ('Mal.',  _B['MAL']),
    ('Mai',   _B['MAL']), ('Mai.',  _B['MAL']),  # OCR 'l'->'i' artifact
    ('Matt',  _B['MAT']), ('Matt.', _B['MAT']),
    ('Mat',   _B['MAT']), ('Mat.',  _B['MAT']),
    ('Mark',  _B['MRK']), ('Mk.',   _B['MRK']),
    ('Mar',   _B['MRK']), ('Mar.',  _B['MRK']),
    ('Luke',  _B['LUK']), ('Luk.',  _B['LUK']),
    ('Lk',    _B['LUK']), ('Lk.',   _B['LUK']),
    ('Jno',   _B['JHN']), ('Jno.',  _B['JHN']),  # old abbrev for John
    ('John',  _B['JHN']), ('Jn.',   _B['JHN']),
    ('Acts',  _B['ACT']), ('Act.',  _B['ACT']),
    ('Rom',   _B['ROM']), ('Rom.',  _B['ROM']),
    ('Cor',   _B['CO1']), ('Cor.',  _B['CO1']),   # bare -> 1 Cor (approx)
    ('Gal',   _B['GAL']), ('Gal.',  _B['GAL']),
    ('Eph',   _B['EPH']), ('Eph.',  _B['EPH']),
    ('Phil',  _B['PHP']), ('Phil.', _B['PHP']),
    ('Php',   _B['PHP']), ('Php.',  _B['PHP']),
    ('Col',   _B['COL']), ('Col.',  _B['COL']),
    ('Thess', _B['TH1']), ('Thess.',_B['TH1']),  # bare -> 1 Thess
    ('Thes',  _B['TH1']), ('Thes.', _B['TH1']),
    ('Tim',   _B['TI1']), ('Tim.',  _B['TI1']),   # bare -> 1 Tim (approx)
    ('Tit',   _B['TIT']), ('Tit.',  _B['TIT']),
    ('Titus', _B['TIT']),
    ('Philem',_B['PHM']), ('Philem.',_B['PHM']),
    ('Phm',   _B['PHM']), ('Phm.',  _B['PHM']),
    ('Heb',   _B['HEB']), ('Heb.',  _B['HEB']),
    ('Jas',   _B['JAM']), ('Jas.',  _B['JAM']),
    ('Pet',   _B['PE1']), ('Pet.',  _B['PE1']),   # bare -> 1 Pet (approx)
    ('Jude',  _B['JUD']),
    ('Rev',   _B['REV']), ('Rev.',  _B['REV']),
    ('Apoc',  _B['REV']), ('Apoc.', _B['REV']),
]

# Sort longest first to avoid prefix matching issues
_ABBREVS_SORTED = sorted(_RAW_ABBREVS, key=lambda x: -len(x[0]))

# Roman numeral -> integer
_ROM_MAP = {'i':1,'v':5,'x':10,'l':50,'c':100,'d':500,'m':1000}

def rom_to_int(s):
    """Convert lowercase Roman numeral string to integer. Returns 0 on failure."""
    s = s.lower().strip()
    if not s or not all(c in _ROM_MAP for c in s):
        return 0
    result = prev = 0
    for ch in reversed(s):
        n = _ROM_MAP[ch]
        result += n if n >= prev else -n
        prev = n
    return result if result > 0 else 0


def _parse_chapter(ch_str):
    """Parse chapter string (Roman or Arabic) -> int."""
    ch_str = ch_str.strip().rstrip(',.:;')
    if ch_str.isdigit():
        return int(ch_str)
    return rom_to_int(ch_str)


def _parse_verse(vs_str):
    """Parse verse start string -> int."""
    vs_str = vs_str.strip().rstrip(',.:;')
    if vs_str.isdigit():
        return int(vs_str)
    v = rom_to_int(vs_str)
    return v if v > 0 else 0


# Regex: book_pattern CH : VS (with optional verse-end for ranges)
# Built dynamically from the sorted abbreviation list.
_BOOK_PATTERN = '|'.join(
    re.escape(abbr) for abbr, _ in _ABBREVS_SORTED
)

_VREF_RE = re.compile(
    r'(?<![A-Za-z])'                              # not preceded by letter
    r'(' + _BOOK_PATTERN + r')'                   # book abbreviation
    r'[,\s]*'                                      # optional comma/space
    r'([ivxlcdmIVXLCDM]+|\d+)'                    # chapter
    r'\s*[:\s]\s*'                                 # colon separator
    r'([ivxlcdmIVXLCDM]+|\d+)'                    # verse start (roman or arabic)
    r'(?:\s*[-–—]\s*(\d+))?'            # optional verse end (range)
)


def parse_refs(text):
    """Extract all verse references from text.
    Returns list of (bcode, ch, vs_start, vs_end_or_None) tuples.
    Skips refs where chapter or verse is 0 or implausibly large.
    """
    results = []
    for m in _VREF_RE.finditer(text):
        abbr, ch_s, vs_s, ve_s = m.group(1), m.group(2), m.group(3), m.group(4)
        bcode = None
        for a, b in _ABBREVS_SORTED:
            if a == abbr:
                bcode = b
                break
        if bcode is None:
            continue
        ch = _parse_chapter(ch_s)
        vs = _parse_verse(vs_s)
        if ch <= 0 or ch > 200 or vs <= 0 or vs > 200:
            continue
        ve = None
        if ve_s:
            ve = int(ve_s)
            if ve <= 0 or ve > 200 or ve < vs:
                ve = None
        results.append((bcode, ch, vs, ve))
    return results
