# -*- coding: utf-8 -*-
"""언약적 메시아 가계도 — 인물마다 언약 구절(체결·성취·불순종)과 한 줄 설명을 담는다 (2026-10-22 · 영구).

  python db_genealogy_cov.py --selftest          # 빈 DB 에서 적재·멱등·되돌리기 (의무)
  python db_genealogy_cov.py --check             # 초안(source_texts/genealogy_cov_ko.json)을 풀어 보기만 — DB 0
  python db_genealogy_cov.py --apply             # 담는다(멱등 · 사람이 고친 글은 안 덮는다)
  python db_genealogy_cov.py --undo              # 이 도구가 담은 것만 걷는다(source='GENCOV')
  python db_genealogy_cov.py --status            # 인물마다 언약 구절 수

★ 새 표를 만들지 않는다 — 용어↔구절 정본 `sys_link_asset(link_type='ENTI_VERS')` 에 **갈래 셋**을 더한다:
    rel_code = COV_MADE(체결) · COV_KEPT(성취·지킴) · COV_BROKEN(불순종)   source='GENCOV'
  한 줄 설명 = `sys_text_asset(text_type='ENTITY_VERSE_DESC', clicked_id=sys_link_id)`(§12-0 그대로).
  인물 설명문 = ENTITY_DESC — **없을 때만** 넣는다(사람이 쓴 글을 덮지 않는다).
  ★ 2026-10-22 「언약 안에서의 자리」 = ENTITY_COV_TAG(노드 꼬리말 · 10자 안팎) · ENTITY_COV_ROLE(카드 맨 위 한두 문장) —
    사람이 고친 글은 안 덮는다(초안과 다르면 「유지」로 센다).
  언약 카드 ↔ 인물 = `sys_genealogy_card.anchor_gp_id`(칸이 없으면 더한다) — 그전에는 좌표로 「근처」일 뿐 매여 있지 않았다.
⚠ `sys_entity_verse` 는 2026-08-24 통합 전의 **옛 표**다 — 여기 쓰지 않는다(§12-0 의 표 이름은 옛 기록).
⚠ 구절 참조는 `scripture_ref.resolve`(KO) 로 푼다 — 못 풀면 `--check` 가 막는다(지어내지 않는다).
"""
import json
import os
import re
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DRAFT = os.path.join(HERE, 'source_texts', 'genealogy_cov_ko.json')
SOURCE = 'GENCOV'
KINDS = {'MADE': 'COV_MADE', 'KEPT': 'COV_KEPT', 'BROKEN': 'COV_BROKEN'}
COV_CODES = tuple(KINDS.values())
LANG = 'KO'
_DASH = '—'


def _gate_text(s, one_line=True):
    """우리 글 규칙 — 합니다체 · 대시 없음 · 동그라미 번호 없음 · (한 줄 설명은) 줄바꿈 없음."""
    bad = []
    s = (s or '').strip()
    if not s:
        bad.append('빈 글')
        return bad
    if _DASH in s:
        bad.append('대시(—)')
    if re.search(r'[①-⑳]', s):
        bad.append('동그라미 번호')
    if one_line and '\n' in s:
        bad.append('줄바꿈')
    if not re.search(r'(니다|습니다|십시오|니까)[.?!」』]*$', s):
        bad.append('합니다체로 끝나지 않음')
    return bad


def load_draft(path=DRAFT):
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def _entity_id(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                     (code,)).fetchone()
    return r[0] if r else None


def _gp_id(conn, name_ko):
    """계보 위에 선 사람(마태·누가 표식이 있는 것) 가운데 세대가 가장 이른 한 사람."""
    r = conn.execute("SELECT gp_id FROM sys_genealogy_person WHERE name_ko=? AND lineage_type IN ('MESSIANIC','BOTH') "
                     "AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY (COALESCE(matthew_line,0)+COALESCE(luke_line,0)) DESC, "
                     "generation LIMIT 1", (name_ko,)).fetchone()
    return r[0] if r else None


def plan(conn, draft):
    """초안을 풀어 (문제 목록, 넣을 줄 목록)로. 문제가 하나라도 있으면 apply 가 거부한다."""
    import scripture_ref as S
    problems, rows = [], []
    for p in draft.get('persons', []):
        eid = _entity_id(conn, p['code'])
        if eid is None:
            problems.append('%s: 엔티티 없음 %s' % (p['name'], p['code']))
            continue
        if p.get('desc'):
            for b in _gate_text(p['desc'], one_line=False):
                problems.append('%s 설명문: %s' % (p['name'], b))
        if p.get('role'):
            for b in _gate_text(p['role'], one_line=False):
                problems.append('%s 자리 문장: %s' % (p['name'], b))
        if p.get('tag') and (len(p['tag']) > 16 or _DASH in p['tag'] or '\n' in p['tag']):
            problems.append('%s 꼬리말: 16자 넘거나 대시·줄바꿈 %r' % (p['name'], p['tag']))
        seen = set()
        for v in p.get('verses', []):
            kind = KINDS.get(v.get('kind', ''))
            if not kind:
                problems.append('%s %s: 갈래 %r' % (p['name'], v.get('ref'), v.get('kind')))
                continue
            a, b = S.resolve(conn, v['ref'], LANG)
            if a is None:
                problems.append('%s: 구절을 못 풀었다 %r' % (p['name'], v['ref']))
                continue
            k = (eid, a, kind)
            if k in seen:
                problems.append('%s %s: 같은 구절·갈래 두 번' % (p['name'], v['ref']))
            seen.add(k)
            for bad in _gate_text(v.get('ko', '')):
                problems.append('%s %s: %s' % (p['name'], v['ref'], bad))
            rows.append({'eid': eid, 'name': p['name'], 'ref': v['ref'], 'a': a, 'b': b if b != a else None,
                         'kind': kind, 'key': 1 if v.get('key') else 0, 'ko': v.get('ko', '').strip()})
    for key, name in draft.get('cards', {}).items():
        if _gp_id(conn, name) is None:
            problems.append('카드 %s: 인물 %r 을 못 찾았다' % (key, name))
    return problems, rows


def ensure_cols(conn):
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_genealogy_card)')]
    if cols and 'anchor_gp_id' not in cols:
        conn.execute('ALTER TABLE sys_genealogy_card ADD COLUMN anchor_gp_id INTEGER')


def apply(conn, draft, commit=True):
    problems, rows = plan(conn, draft)
    if problems:
        raise SystemExit('초안에 문제가 있어 담지 않는다:\n  ' + '\n  '.join(problems))
    ensure_cols(conn)
    n_link = n_desc = n_pdesc = n_card = 0
    for r in rows:
        cur = conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE link_type='ENTI_VERS' AND clicked_id=? AND target_id=? "
                           "AND rel_code=? AND COALESCE(end_id,target_id)=?", (r['eid'], r['a'], r['kind'], r['b'] or r['a'])).fetchone()
        if cur:
            lid = cur[0]
            conn.execute("UPDATE sys_link_asset SET is_key=?, record_status='LIVE', source=COALESCE(source,?) WHERE sys_link_id=?",
                         (r['key'], SOURCE, lid))
        else:
            conn.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,rel_code,is_key,end_id,source,confidence,record_status)"
                         " VALUES('ENTI_VERS',?,?,?,?,?,?,'MANUAL','LIVE')", (r['eid'], r['a'], r['kind'], r['key'], r['b'], SOURCE))
            lid = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
            n_link += 1
        # 한 줄 설명 — 사람이 고친 글(이 도구 글과 다른 것)은 덮지 않는다
        old = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_VERSE_DESC' AND clicked_id=? "
                           "AND UPPER(lang_code)=?", (lid, LANG)).fetchone()
        if old is None:
            conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status) VALUES(?,?,?,?,'LIVE')",
                         (lid, 'ENTITY_VERSE_DESC', LANG, r['ko']))
            n_desc += 1
    # 인물 설명문 — 없을 때만
    for p in draft.get('persons', []):
        if not p.get('desc'):
            continue
        eid = _entity_id(conn, p['code'])
        have = conn.execute("SELECT 1 FROM sys_text_asset WHERE text_type='ENTITY_DESC' AND clicked_id=? AND UPPER(lang_code)=? "
                            "AND COALESCE(record_status,'LIVE')='LIVE'", (eid, LANG)).fetchone()
        if have:
            continue
        conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status) VALUES(?,?,?,?,'LIVE')",
                     (eid, 'ENTITY_DESC', LANG, p['desc'].strip()))
        n_pdesc += 1
    # 언약 안에서의 자리(꼬리말·문장) — 없을 때만 · 있으면 그대로
    n_role = 0
    for p in draft.get('persons', []):
        eid = _entity_id(conn, p['code'])
        for ttype, key in (('ENTITY_COV_TAG', 'tag'), ('ENTITY_COV_ROLE', 'role')):
            if not p.get(key):
                continue
            have = conn.execute("SELECT 1 FROM sys_text_asset WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=? "
                                "AND COALESCE(record_status,'LIVE')='LIVE'", (ttype, eid, LANG)).fetchone()
            if have:
                continue
            conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status) VALUES(?,?,?,?,'LIVE')",
                         (eid, ttype, LANG, p[key].strip()))
            n_role += 1
    # 카드 닻 — 모든 언어 행에 같은 인물
    for key, name in draft.get('cards', {}).items():
        gp = _gp_id(conn, name)
        n_card += conn.execute('UPDATE sys_genealogy_card SET anchor_gp_id=? WHERE card_key=? AND COALESCE(anchor_gp_id,-1)<>?',
                               (gp, key, gp)).rowcount
    if commit:
        conn.commit()
    return {'links': n_link, 'descs': n_desc, 'person_descs': n_pdesc, 'roles': n_role, 'cards': n_card, 'rows': len(rows)}


def undo(conn, commit=True):
    ids = [r[0] for r in conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE link_type='ENTI_VERS' AND source=?", (SOURCE,))]
    for lid in ids:
        conn.execute("DELETE FROM sys_text_asset WHERE text_type='ENTITY_VERSE_DESC' AND clicked_id=?", (lid,))
    conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_VERS' AND source=?", (SOURCE,))
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_genealogy_card)')]
    if 'anchor_gp_id' in cols:
        conn.execute('UPDATE sys_genealogy_card SET anchor_gp_id=NULL')
    if commit:
        conn.commit()
    return len(ids)


def status(conn):
    return conn.execute(
        "SELECT p.name_ko, SUM(l.rel_code='COV_MADE'), SUM(l.rel_code='COV_KEPT'), SUM(l.rel_code='COV_BROKEN') "
        "FROM sys_genealogy_person p JOIN sys_link_asset l ON l.clicked_id=p.entity_id AND l.link_type='ENTI_VERS' "
        "AND l.rel_code IN ('COV_MADE','COV_KEPT','COV_BROKEN') AND COALESCE(l.record_status,'LIVE')='LIVE' "
        "WHERE p.lineage_type IN ('MESSIANIC','BOTH') GROUP BY p.gp_id ORDER BY p.generation").fetchall()


# ───────────────────────── selftest ─────────────────────────
def _mini_db():
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE book_names(book_code INT, lang_code TEXT, short_name TEXT, full_name TEXT);
    CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT, chapter INT, verse INT);
    CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_code TEXT, entity_type TEXT, record_status TEXT);
    CREATE TABLE sys_genealogy_person(gp_id INTEGER PRIMARY KEY, name_ko TEXT, generation INT, matthew_line INT, luke_line INT,
        lineage_type TEXT, entity_id INT, record_status TEXT);
    CREATE TABLE sys_genealogy_card(card_id INTEGER PRIMARY KEY, card_key TEXT, lang_code TEXT, title TEXT, body TEXT);
    CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,
        is_key INT, end_id INT, source TEXT, confidence TEXT, record_status TEXT);
    CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT, record_status TEXT);
    INSERT INTO book_names VALUES(1,'KO','창','창세기'),(45,'KO','롬','로마서');
    INSERT INTO sys_entity_master VALUES(7,'P_ADAM','PERSON','LIVE');
    INSERT INTO sys_genealogy_person VALUES(1,'아담',0,1,1,'MESSIANIC',7,'LIVE');
    INSERT INTO sys_genealogy_card VALUES(22,'COVENANT_ADAM','KO','아담 언약',''),(122,'COVENANT_ADAM','EN','Adam',''),
        (23,'COVENANT_NOAH','KO','노아','');
    """)
    vid = 1
    for ch in range(1, 4):
        for v in range(1, 32):
            c.execute('INSERT INTO bible_index VALUES(?,1,?,?)', (vid, ch, v))
            vid += 1
    for ch in range(1, 6):
        for v in range(1, 22):
            c.execute('INSERT INTO bible_index VALUES(?,45,?,?)', (vid, ch, v))
            vid += 1
    return c


def selftest():
    ok = [0, 0]

    def ck(name, cond, got=''):
        ok[0 if cond else 1] += 1
        print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  got=%r' % (got,)))

    c = _mini_db()
    d = {'cards': {'COVENANT_ADAM': '아담'},
         'persons': [{'code': 'P_ADAM', 'name': '아담', 'desc': '첫 사람입니다.', 'tag': '여자의 후손', 'role': '약속을 받습니다.',
                      'verses': [{'ref': '창 1:27-28', 'kind': 'MADE', 'key': 1, 'ko': '복을 주십니다.'},
                                 {'ref': '창 3:6', 'kind': 'BROKEN', 'ko': '어깁니다.'},
                                 {'ref': '롬 5:19', 'kind': 'KEPT', 'ko': '되돌려 놓습니다.'}]}]}
    pr, rows = plan(c, d)
    ck('초안이 풀린다 — 문제 0 · 줄 3', not pr and len(rows) == 3, pr)
    ck('구간은 end_id 가 있다(창 1:27-28)', rows[0]['b'] == rows[0]['a'] + 1 and rows[1]['b'] is None)
    r = apply(c, d)
    ck('담김 — 연결 3 · 설명 3 · 인물 설명 1 · 자리 2 · 카드 2언어',
       r['links'] == 3 and r['descs'] == 3 and r['person_descs'] == 1 and r['roles'] == 2 and r['cards'] == 2, r)
    ck('자리 = ENTITY_COV_TAG · ENTITY_COV_ROLE',
       {x[0] for x in c.execute("SELECT text_type FROM sys_text_asset WHERE clicked_id=7")} >= {'ENTITY_COV_TAG', 'ENTITY_COV_ROLE'})
    ck('갈래 = COV_* · source GENCOV',
       {x[0] for x in c.execute("SELECT rel_code FROM sys_link_asset WHERE source='GENCOV'")} == set(COV_CODES))
    ck('카드 닻 = 아담(모든 언어 행)', [x[0] for x in c.execute("SELECT anchor_gp_id FROM sys_genealogy_card WHERE card_key='COVENANT_ADAM'")] == [1, 1])
    ck('노아 카드는 안 건드린다', c.execute("SELECT anchor_gp_id FROM sys_genealogy_card WHERE card_key='COVENANT_NOAH'").fetchone()[0] is None)
    r2 = apply(c, d)
    ck('멱등 — 다시 담아도 0', r2['links'] == 0 and r2['descs'] == 0 and r2['person_descs'] == 0 and r2['roles'] == 0 and r2['cards'] == 0, r2)
    bad = {'cards': {}, 'persons': [{'code': 'P_ADAM', 'name': '아담', 'tag': '이 꼬리말은 열여섯 자를 넘기게 길다', 'role': '문장이다', 'verses': []}]}
    pr, _ = plan(c, bad)
    ck('꼬리말 길이·자리 문장 합니다체를 잰다', any('꼬리말' in x for x in pr) and any('자리 문장' in x for x in pr), pr)
    # 사람이 고친 글은 안 덮는다
    c.execute("UPDATE sys_text_asset SET contents='사람이 고쳤습니다.' WHERE text_type='ENTITY_VERSE_DESC'")
    c.execute("UPDATE sys_text_asset SET contents='사람이 쓴 인물 글입니다.' WHERE text_type='ENTITY_DESC'")
    apply(c, d)
    ck('사람이 고친 한 줄 설명·인물 설명문 불변',
       c.execute("SELECT COUNT(*) FROM sys_text_asset WHERE contents LIKE '사람이%'").fetchone()[0] == 4)
    # 되돌리기
    n = undo(c)
    ck('되돌리기 — 연결 3 걷힘 · 설명 0 · 닻 NULL', n == 3 and c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 0
       and c.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type='ENTITY_VERSE_DESC'").fetchone()[0] == 0
       and c.execute("SELECT COUNT(*) FROM sys_genealogy_card WHERE anchor_gp_id IS NOT NULL").fetchone()[0] == 0)
    ck('되돌리기는 인물 설명문을 남긴다(사람 글일 수 있다)', c.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type='ENTITY_DESC'").fetchone()[0] == 1)
    # 막는 것
    bad = {'cards': {}, 'persons': [{'code': 'P_ADAM', 'name': '아담', 'verses': [{'ref': '없는책 1:1', 'kind': 'MADE', 'ko': '글입니다.'}]}]}
    pr, _ = plan(c, bad)
    ck('못 푸는 구절은 문제로', any('못 풀었다' in x for x in pr), pr)
    bad = {'cards': {}, 'persons': [{'code': 'P_ADAM', 'name': '아담', 'verses': [{'ref': '창 1:1', 'kind': 'MADE', 'ko': '글이다 — 대시'}]}]}
    pr, _ = plan(c, bad)
    ck('대시·합니다체 아님은 문제로', any('대시' in x for x in pr) and any('합니다체' in x for x in pr), pr)
    bad = {'cards': {'COVENANT_X': '없는사람'}, 'persons': []}
    pr, _ = plan(c, bad)
    ck('카드 인물을 못 찾으면 문제로', pr and '카드' in pr[0], pr)
    try:
        apply(c, bad)
        ck('문제가 있으면 apply 가 거부한다', False)
    except SystemExit:
        ck('문제가 있으면 apply 가 거부한다', True)
    print('%d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    args = sys.argv[1:]
    if '--selftest' in args:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if '--check' in args:
        pr, rows = plan(conn, load_draft())
        for r in rows:
            print('%-6s %-10s %-12s %s' % (r['name'], r['kind'][4:], r['ref'], r['ko'][:40]))
        print('줄 %d · 문제 %d' % (len(rows), len(pr)))
        for p in pr:
            print('  ⚠', p)
    elif '--apply' in args:
        print(apply(conn, load_draft()))
    elif '--undo' in args:
        print('걷음', undo(conn))
    elif '--status' in args:
        for r in status(conn):
            print('%-8s 체결 %d · 성취 %d · 불순종 %d' % r)
    else:
        print(__doc__)
