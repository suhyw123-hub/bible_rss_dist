# -*- coding: utf-8 -*-
"""overlay_read.py — 덮개 **조회 단일 문** (B 단계 · 2026-08-27 신설·영구).

★★★ 왜 (사용자 확정 — 0.연결팝업.txt 3절 · 할일 13-54):
  저장은 통합됐는데(overlay 엔진) **조회는 화면마다 자기 SQL** 이었다 —
  실측 사용자 앱 131개 파일에 sys 직접 읽기 799자리, 따로 세는 COUNT 74자리.
  그래서 「저장은 되는데 안 보인다」가 자리 수만큼 남았다(갈렙 사건들).
  ⇒ **덮개가 걸리는 조회는 이 모듈만 부른다.** 여기가 한 곳이면 한 곳만 고친다.

무엇을 주나
  · `links(conn, kind, tid, lang)`      — 연결: sys 위에 user 를 덮은 최종 목록
  · `link_count(conn, kind, tid)`       — 개수 규칙 그대로의 수
  · `text(conn, text_type, clicked_id, lang, variant)` — 설명글 한 자리
  · 각 행/결과에 `_src` = 'SYS'|'EDIT'|'NEW' ('HIDE' 는 **안 나온다** — 가림)

★★ **개수 규칙 (사용자 확정): N = +1 · E = 0 · H = −1.**
  개수 = len(목록) 이 되도록 목록을 만든다 — 목록 따로·개수 따로 세면
  반드시 갈라진다(「목록 2건인데 헤더 (0)」이 그 증거였다).
  공식: 개수 = sys(LIVE) + N(내가 더함) − H(sys 를 가림). E 는 대체라 0.

⚠ 연결의 자연 열쇠 = (link_type 정규화 짝, rel, end) — PK 가 아니다.
  배포마다 PK 가 바뀌므로(실측 보존율 0%) 번호로 짝지으면 덮개가 죽는다.
⚠ `link_type` 의 앞뒤는 **밑줄로 가른다** — `TAG` 는 세 자다(substr 함정).

    python overlay_read.py --selftest     (의무)
"""
import re
import sys

import appdb
import link_picker as LP
import overlay

SYS = 'SYS'
EDIT = 'EDIT'
NEW = 'NEW'

#: 개수 규칙 — 사용자 확정 (0.연결팝업.txt 3절)
COUNT_RULE = {NEW: +1, EDIT: 0, 'HIDE': -1}


# ══════════════════════════════════════════════════════════════════
#  연결
# ══════════════════════════════════════════════════════════════════
def _norm_pair(kind, tid, other_kind, other_id, end, rel):
    """연결의 자연 열쇠 — **양쪽 어느 방향으로 저장돼 있어도 같은 값**.

    ⚠ `pair()` 정렬(§81)과 같은 규칙: 넉 자 코드 순으로 (A, B) 를 눕힌다.
    """
    a = (LP.CODE.get(kind, kind), int(tid))
    b = (LP.CODE.get(other_kind, other_kind), int(other_id))
    if a > b:
        a, b = b, a
    return (a[0], a[1], b[0], b[1], int(end or 0), str(rel or ''))


def _user_link_rows(conn, kind, tid):
    """개인 표의 이 자산 연결 — 상태 포함(HIDE = sys 가림 또는 내 것 뗌)."""
    code = LP.CODE.get(kind, kind)
    out = []
    try:
        for lt, a_i, b_i, b_e, rel, st in conn.execute(
                ("SELECT link_type, clicked_id, target_id, end_id, rel_code, "
                 "       COALESCE(record_status,'LIVE') "
                 "  FROM userdb.user_link_asset "
                 " WHERE (%s=? AND clicked_id=?) OR (%s=? AND target_id=?)")
                % (LP.LT_A, LP.LT_B), (code, int(tid), code, int(tid))):
            a_c, _, b_c = lt.partition('_')
            if a_c == code and a_i == int(tid):
                ok, oi, oe = LP.KIND_OF.get(b_c, b_c), b_i, b_e
            else:
                ok, oi, oe = LP.KIND_OF.get(a_c, a_c), a_i, None
            out.append({'kind': ok, 'id': oi, 'end': oe,
                        'rel': rel, 'status': st})
    except Exception as e:
        print('[overlay_read user links] %s' % e)
    return out


def links(conn, kind, tid, lang='KO'):
    """이 자산의 연결 — **덮개 적용 최종 목록.** 각 행에 `_src`.

    resolve 규칙(overlay.resolve 와 동일):
      sys 행  + user 짝 없음        → SYS
      sys 행  + user LIVE 짝        → EDIT (내 행이 대체)
      sys 행  + user HIDE 짝        → (안 나온다 — 가림)
      user 행 + sys 짝 없음 + LIVE  → NEW
      user 행 + sys 짝 없음 + HIDE  → (안 나온다 — 내 것을 뗀 것)
    """
    kind = str(kind).upper()
    sys_rows = LP.links_of(conn, kind, tid, lang, scope='SYS')
    users = {}
    for u in _user_link_rows(conn, kind, tid):
        users[_norm_pair(kind, tid, u['kind'], u['id'], u['end'],
                         u['rel'])] = u
    out = []
    for s in sys_rows:
        if s.get('src') == 'TAG':
            # 태그는 저장소가 따로(tag_picker) — 덮개도 그쪽 규칙(all_tags 표식)
            s['_src'] = SYS
            out.append(s)
            continue
        k = _norm_pair(kind, tid, s['kind'], s['id'], s.get('end'),
                       s.get('rel'))
        u = users.pop(k, None)
        if u is None:
            s['_src'] = SYS
            out.append(s)
        elif (u['status'] or 'LIVE').upper() == 'HIDE':
            continue                        # 가림 — sys 가 안 보인다
        else:
            s['_src'] = EDIT                # 내 행이 같은 짝 — 대체
            out.append(s)
    for k, u in users.items():
        if (u['status'] or 'LIVE').upper() == 'HIDE':
            continue                        # sys 짝 없는 HIDE = 뗀 내 것
        out.append({'kind': u['kind'], 'id': u['id'], 'end': u['end'],
                    'rel': u['rel'], 'src': 'LINK', '_src': NEW,
                    'label': LP.label_of(conn, u['kind'], u['id'],
                                         u['end'], lang)})
    return out


def link_count(conn, kind, tid):
    """개수 — **목록을 세어서 낸다**(규칙 N+1·E0·H−1 은 정의상 성립)."""
    return len(links(conn, kind, tid))


def hidden_ids(conn, kind, tid, other_kind):
    """이 자산에서 **사용자가 가린 상대**(sys 짝 HIDE)의 번호 집합.

    자기 SQL 로 sys 목록을 그리는 화면이 가림만이라도 지키게 하는 문 —
    풍부한 칸(제목·건수·역할)이 필요해 `links()` 를 통째로 못 쓰는 자리용.
    """
    other = str(other_kind).upper()
    return {u['id'] for u in _user_link_rows(conn, kind, tid)
            if (u['status'] or 'LIVE').upper() == 'HIDE'
            and str(u['kind']).upper() == other}


# ══════════════════════════════════════════════════════════════════
#  「가린 것 보기」 옵션 (2026-08-27 사용자 — 「숨기기 할 때 sys 데이터를
#  보여주면서 가림 표시하기 옵션을 주자」)
#
#  ★ 왜 옵션인가 — 가림에는 두 뜻이 섞인다: 「보기 싫다(안 보이게)」와
#    「내 화면에서는 접어 두되 원본은 알고 싶다」. 전자만 지원하면 무엇을
#    가렸는지 되짚을 길이 목록 화면뿐이다. 켜면 **읽는 화면에서도** 가린
#    sys 글이 H 표식과 함께 보인다(내용은 원본 그대로).
#  ⚠ 기본은 **끔** — 가림의 본뜻이 「안 보이게」이므로 켜는 것이 사용자
#    선택이어야 한다. 저장 = `user_config['SHOW_HIDDEN']`.
# ══════════════════════════════════════════════════════════════════
_SHOW_HIDDEN_KEY = 'SHOW_HIDDEN'


def show_hidden(conn):
    """가린 것을 읽는 화면에도 보일까 (기본 False)."""
    try:
        r = conn.execute('SELECT config_val FROM user_config '
                         'WHERE config_key=?', (_SHOW_HIDDEN_KEY,)).fetchone()
        return bool(r and str(r[0]).strip() in ('1', 'Y', 'TRUE', 'true'))
    except Exception:
        return False


def set_show_hidden(conn, on):
    v = '1' if on else '0'
    cur = conn.execute('UPDATE user_config SET config_val=? '
                       'WHERE config_key=?', (v, _SHOW_HIDDEN_KEY))
    if cur.rowcount == 0:
        conn.execute('INSERT INTO user_config(config_key, config_val) '
                     'VALUES(?,?)', (_SHOW_HIDDEN_KEY, v))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  설명글
# ══════════════════════════════════════════════════════════════════
def text_lang(conn, text_type, clicked_id, lang, variant=None,
              opt_show_hidden=None):
    """**한 언어**의 설명글 — 조회 정본 (2026-08-27 텍스트 통합).

    반환 `(내용|None, 상태)` — 상태 = SYS · EDIT · NEW · HIDE · MISSING.
    화면 세 곳(구절 fetch·주요용어·렌즈)이 각자 갖고 있던 「덮개 물어보고
    가림이면 폴백 끊기」 규칙을 이 한 문으로 모은다.

    ★ `opt_show_hidden` — 「가린 것 보기」가 켜져 있으면 가린 sys 글을
      **내용째 돌려주되 상태는 HIDE**(화면이 H 표식으로 그린다). 끄면
      내용 없이 HIDE 만(= 지금까지의 동작).
    ⚠ **가림은 언어 폴백을 이긴다** — 여기서 상태를 HIDE 로 돌려주면
      부르는 쪽이 다음 언어로 넘어가지 않아야 한다(§88차 사고).
    """
    if opt_show_hidden is None:
        opt_show_hidden = show_hidden(conn)
    ov = overlay.text_override(conn, text_type, clicked_id, lang, variant)
    sys_row = _sys_text(conn, text_type, clicked_id, lang, variant)
    if ov is not None:
        st, body = ov
        if st == 'HIDE' or body is None:
            # 가림 — 옵션이 켜져 있으면 **원본을 보여 주되 H 로 표시**
            return (sys_row if opt_show_hidden else None), 'HIDE'
        title, contents = body
        return ({'title': title, 'contents': contents},
                EDIT if sys_row else NEW)
    if sys_row is None:
        return None, 'MISSING'
    return sys_row, SYS


def text(conn, text_type, clicked_id, lang='KO', variant=None):
    """설명글 한 자리 — 덮개 적용 → `(내용 dict | None, _src)`.

    · 내 덮개 HIDE      → (None, 'HIDE')   ← ⚠ **폴백하지 말 것** — 가림은
      언어 폴백을 이긴다(§88차 사고: 가렸는데 영어가 튀어나왔다)
    · 내 덮개 EDIT/NEW  → ({'title','contents'}, 'EDIT'|'NEW')
    · 덮개 없음 + sys    → ({'title','contents'}, 'SYS')
    · 아무것도 없음      → (None, 'MISSING')
    """
    ov = overlay.text_override(conn, text_type, clicked_id, lang, variant)
    if ov is not None:
        st, body = ov
        if st == 'HIDE' or body is None:
            return None, 'HIDE'
        title, contents = body
        src = EDIT if _sys_text_exists(conn, text_type, clicked_id, lang,
                                       variant) else NEW
        return {'title': title, 'contents': contents}, src
    r = _sys_text(conn, text_type, clicked_id, lang, variant)
    if r is None:
        return None, 'MISSING'
    return r, SYS


def _sys_text(conn, text_type, clicked_id, lang, variant):
    q = ("SELECT title, contents FROM sys_text_asset "
         " WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=UPPER(?) "
         "   AND COALESCE(record_status,'LIVE')='LIVE' ")
    args = [text_type, clicked_id, lang]
    if variant is not None:
        q += ' AND text_variant=? '
        args.append(variant)
    r = conn.execute(q + ' LIMIT 1', args).fetchone()
    return {'title': r[0], 'contents': r[1]} if r else None


def _sys_text_exists(conn, text_type, clicked_id, lang, variant):
    return _sys_text(conn, text_type, clicked_id, lang, variant) is not None


# ══════════════════════════════════════════════════════════════════
#  나머지 갈래 — **이미 검증된 단일 소스에 위임**한다
#  ⚠ 여기서 다시 짜지 말 것 — 두 벌이 되는 순간 「저장은 되는데 안
#    보인다」가 다시 난다. 화면은 overlay_read 하나만 import 하면 되고,
#    실제 규칙은 각 단일 소스 한 곳에 산다.
# ══════════════════════════════════════════════════════════════════
def entity(conn, entity_id, lang='KO'):
    """엔티티 머리 — 이름·유형(덮개 적용)·가림·별명(sys+내 것).

    · 이름은 안 고친다(사용자 확정 — 「이름은 별명으로」) → 이름 덮개 없음
    · 유형은 `user_entity_asset.entity_type` 이 덮는다(§95차)
    """
    import entity_aliases as EA
    import entity_overlay as EO
    name, code, etype = EO.entity_head(conn, entity_id, lang)
    t_ov = EO.type_override(conn, code) if code else None
    hidden = False
    try:
        hidden = bool(conn.execute(
            "SELECT 1 FROM userdb.user_entity_asset WHERE entity_code=? "
            "  AND COALESCE(record_status,'LIVE')='HIDE'", (code,)).fetchone())
    except Exception:
        pass
    al = []
    try:
        jd = conn.execute('SELECT json_detail FROM sys_entity_master '
                          ' WHERE entity_id=?', (entity_id,)).fetchone()
        al = EA.aliases_for_lang(jd[0] if jd else None, lang)
    except Exception:
        pass
    ual = overlay.entity_aliases_user(conn, lang).get(code, [])
    return {'name': name, 'code': code,
            'type': t_ov or etype, '_type_src': EDIT if t_ov else SYS,
            'hidden': hidden,
            'aliases': al + [a for a in ual if a not in al]}


def entity_type_counts(conn):
    """유형별 LIVE 엔티티 수 — {entity_type: n, None: 전체}. 화면 단추 () 표기용.

    ★ **내가 가린 엔티티를 뺀다** (2026-09-02 이 문으로 옮기며 고침 — 화면이
      직접 셀 때는 안 빼서, 목록(가림 제외)과 단추 개수가 어긋날 수 있었다)."""
    import db_tag_system as _T
    out = {}
    try:
        hidden = _T.user_hidden_entity_codes(conn)
    except Exception:
        hidden = set()
    try:
        for code, tc, jd in conn.execute(
                "SELECT entity_code, entity_type, COALESCE(json_detail,'')"
                " FROM sys_entity_master"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            if code in hidden:
                continue
            # ★ 기계 낱말(subtype LEX)은 분류·개수에서 뺀다 (2026-09-02 —
            #   1.1만 목록은 훑는 자산이 아니다. 검색·연결·의미장으로 닿는다).
            if '"subtype": "LEX"' in jd:
                continue
            out[tc] = out.get(tc, 0) + 1
    except Exception:
        pass
    # ★★★ **내 용어도 함께 센다**(2026-09-18) — 오버레이의 N 자리다.
    #   개수와 목록이 갈리면 「단추는 3인데 목록은 5」가 된다(§개수 규칙).
    for tc, n in my_term_counts(conn).items():
        out[tc] = out.get(tc, 0) + n
    out[None] = sum(out.values())
    return out


def my_terms(conn, lang='KO'):
    """내가 만든 용어 — [(번호, 이름, 유형)]. **오버레이의 NEW 자리.**

    ★ 저장소는 `user_tag_asset` 한 곳이다(옛 「내 태그」). 사용자에게는
      처음부터 **「내 용어」**로 불렸고(`link_picker.KIND_NAME['UTAG']`),
      2026-09-18 에 축까지 주요용어 유형으로 맞췄다.
    ⚠ 분류값이 비었거나 옛 개념 축이면 **심리·국면으로 읽는다** — 사용자가
      손으로 다는 말은 거의 그 자리다(빈 유형으로 두면 단추 어디에도 안 뜬다).
    """
    import db_tag_system as _T
    ok = {c for c, _n in _T.ALL_AXES}
    out = []
    try:
        for tid, nm, cat in conn.execute(
                'SELECT user_tag_id, tag_name_sid, COALESCE(tag_category,\'\')'
                '  FROM userdb.user_tag_asset'
                "  WHERE COALESCE(record_status,'LIVE')='LIVE'"
                '  ORDER BY tag_name_sid'):
            out.append((tid, nm or ('#%d' % tid),
                        cat if cat in ok else 'PHASE'))
    except Exception:
        pass
    return out


def my_term_counts(conn):
    """내 용어의 유형별 개수 — {유형: n}."""
    out = {}
    for _tid, _nm, tc in my_terms(conn):
        out[tc] = out.get(tc, 0) + 1
    return out


def anchors_of(conn, entity_id, lang=None):
    """엔티티의 원어 앵커 [(strong, 한국어 음역)] — 차례대로, 중복 없이.

    2026-09-15 — 사전 갈래 넷(Strong·BDB·A-S·Thayer)이 저마다 같은 조회를
    품고 있던 것을 한 문으로. `lang` 을 주면 그 언어 앵커만(HE/EL)."""
    out, seen = [], set()
    try:
        q = ("SELECT strong, COALESCE(translit,'') FROM sys_entity_lemma"
             " WHERE entity_id=?" + (" AND lang_code=?" if lang else "")
             + " ORDER BY sort_order, lemma_id")
        for st, tr_ko in conn.execute(q, (entity_id, lang) if lang else (entity_id,)):
            if st and st not in seen:
                seen.add(st)
                out.append((st, tr_ko))
    except Exception:
        pass
    return out


#: 스트롱 사전 번역문 — `sys_text_asset` text_type (2026-09-15 · 사용자
#: 「승격 여부와 관계없이 스트롱 사전을 모두 표시 · 번역된 다국어 표시, 없으면
#: 영어 폴백」). 열쇠 = `db_lex_link.lemma_key(strong)`(정수). 언어별 행이라
#: 번역 대시보드·커버리지가 그대로 다룬다(§0-3 규칙 1).
LEMMA_DEF = 'LEMMA_DEF'


def lemma_text(conn, strong, lang):
    """그 낱말의 스트롱 정의문 **번역** — 그 언어 행이 있으면 글, 없으면 None
    (화면이 영어 원문으로 물러선다). 영어 행은 원문 표(`sys_lemma_master`)가
    정본이라 여기 두지 않는다."""
    if not strong or not lang or str(lang).upper() == 'EN':
        return None
    try:
        import db_lex_link as _LL
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
            " AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
            (LEMMA_DEF, _LL.lemma_key(strong), str(lang).upper())).fetchone()
        if not r:
            return None
        return (r[0] or '').strip() or None
    except Exception:
        return None


def strong_entries(conn, entity_id):
    """엔티티의 원어 앵커 → 낱말 마스터(sys_lemma_master) 항목.

    2026-09-02 신설 (178차 — 스트롱 수용 1단계). 사전 갈래의 [Strong] 단추와
    낱말 단추 오른쪽 글이 이것을 읽는다. 마스터가 아직 없으면 빈 목록
    (화면은 단추를 안 만든다 — 빈 서랍 금지).
    """
    return strong_entries_for(conn, anchors_of(conn, entity_id))


def strong_entries_for(conn, anchors):
    """앵커 [(strong, 음역)] → 낱말 마스터 항목 (승격 안 된 낱말도 같은 문)."""
    out = []
    try:
        for st, tr_ko in anchors or ():
            r = conn.execute(
                "SELECT lang_code, COALESCE(form,''), COALESCE(translit,''),"
                " COALESCE(pos,''), COALESCE(gloss,''), COALESCE(deriv,''),"
                " COALESCE(def_en,''), COALESCE(kjv_def,''), occurrences"
                " FROM sys_lemma_master WHERE strong=?", (st,)).fetchone()
            if r:
                out.append({'strong': st, 'translit_ko': tr_ko, 'lang': r[0],
                            'form': r[1], 'translit': r[2], 'pos': r[3],
                            'gloss': r[4], 'deriv': r[5], 'def_en': r[6],
                            'kjv': r[7], 'occ': r[8] or 0})
    except Exception:
        pass
    return out


def bdb_entries(conn, entity_id):
    """엔티티의 히브리 앵커 → BDB 뜻 개요 항목 (2026-09-03 184차).

    [BDB] 갈래가 읽는다. 다리 = sys_bdb_map(스트롱→BDB id · LexicalIndex).
    본문은 OSHB 의 진행 중 전사(뜻 개요 수준)라 화면이 그것을 밝힌다."""
    return bdb_entries_for(conn, anchors_of(conn, entity_id, 'HE'))


def bdb_entries_for(conn, anchors):
    out = []
    try:
        for st, tr_ko in anchors or ():
            if not str(st).startswith('H'):
                continue
            for bid, heb, body in conn.execute(
                    "SELECT e.bdb_id, e.heb, e.body FROM sys_bdb_map m"
                    " JOIN sys_bdb_entry e ON e.bdb_id=m.bdb_id"
                    " WHERE m.strong=?", (st,)):
                out.append({'strong': st, 'translit_ko': tr_ko,
                            'heb': heb, 'body': body})
    except Exception:
        pass
    return out


# ★ 사전 갈래로 표시하는 **낱말 분석 문헌** — 명시 목록 (2026-09-03 사용자
#   확정 「사전으로 명시한 목록에 대해서만 사전으로 표시한다」).
#   ⚠ BUNT_ENTI 를 가진 책을 전부 자동으로 올리면 스펄전 설교(296연결)까지
#     사전 버튼이 된다 — 설교는 낱말 분석이 아니다. 표에 한 줄이 편입 조건.
BOOK_DICT_SRC = {
    'GIRDLESTONE_OTS': ('Girdlestone',
                        'Girdlestone, Synonyms of the Old Testament'
                        ' (2nd ed. 1897)'),
}


def thayer_entries(conn, entity_id):
    """엔티티의 헬라 앵커 → Thayer(1889) 심층 사전 항목 (2026-09-03 189차).

    [Thayer] 갈래가 읽는다 — A-S(간결한 표준)의 깊은 짝. 다리는 스트롱이
    곧 PK 라 표가 하나뿐이다."""
    return thayer_entries_for(conn, anchors_of(conn, entity_id, 'EL'))


def thayer_entries_for(conn, anchors):
    out = []
    try:
        for st, tr_ko in anchors or ():
            if not str(st).startswith('G'):
                continue
            for grk, tr, body in conn.execute(
                    "SELECT grk, translit, body FROM sys_thayer_entry"
                    " WHERE strong=?", (st,)):
                out.append({'strong': st, 'translit_ko': tr_ko,
                            'grk': grk, 'translit': tr, 'body': body})
    except Exception:
        pass
    return out


def media_titles(conn, ids, lang='KO'):
    """미디어 제목 **덮개**(MEDIA_TITLE) → {media_id: 제목}.

    ⚠ 덮개 조회는 이 모듈의 몫이다 — 화면이 직접 sys 를 뒤지면 검사기가
      잡고(2026-09-03 실제로 잡혔다), 무엇보다 **집(본체·팩)에 따라 규칙이
      갈린다**. 여기 한 문이면 어느 집에서 온 행이든 같은 제목을 본다."""
    out = {}
    ids = [i for i in (ids or []) if isinstance(i, int)]
    if not ids:
        return out
    lg = (lang or 'KO').upper()
    try:
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            ph = ','.join('?' * len(chunk))
            for mid, txt in conn.execute(
                    "SELECT clicked_id, contents FROM sys_text_asset"
                    " WHERE text_type='MEDIA_TITLE' AND lang_code=?"
                    "   AND record_status='LIVE'"
                    "   AND clicked_id IN (%s)" % ph, [lg] + chunk):
                if txt:
                    out[mid] = txt
    except Exception:
        pass
    return out


def relations_with_desc(conn):
    """**설명문을 가진 인물 관계**의 번호 집합 (2026-09-03).

    관계 트리가 「같은 짝의 여러 관계를 한 줄로 합칠지」를 이것으로 가른다 —
    글이 다르면 합치지 않는다(사용자 확정 조건)."""
    out = set()
    try:
        for (rid,) in conn.execute(
                "SELECT DISTINCT clicked_id FROM sys_text_asset"
                " WHERE text_type='RELATION_DESC'"
                " AND COALESCE(record_status,'LIVE')='LIVE'"):
            out.add(rid)
    except Exception:
        pass
    return out


def book_dict_entries(conn, entity_id):
    """엔티티에 걸린 **낱말 분석 문헌 유닛** → [{book,short,full,label,body}].

    [Girdlestone] 갈래가 읽는다. 본문 = sys_book_unit_text ORIGINAL/EN
    (저자의 글 그대로 — 번역 안 함 정책 동일). 책 순서(sequence)대로."""
    out = []
    if not BOOK_DICT_SRC:
        return out
    try:
        ph = ','.join('?' * len(BOOK_DICT_SRC))
        for code, label, body in conn.execute(
                """SELECT a.book_code, COALESCE(u.unit_label,''),
                          COALESCE(t.body_text,'')
                     FROM sys_link_asset le
                     JOIN sys_book_unit u ON u.unit_id=le.clicked_id
                     JOIN sys_book_asset a ON a.book_id=u.book_id
                     LEFT JOIN sys_book_unit_text t ON t.unit_id=u.unit_id
                          AND UPPER(t.lang_code)='EN'
                          AND t.text_variant='ORIGINAL'
                    WHERE le.link_type='BUNT_ENTI' AND le.target_id=?
                      AND a.book_code IN (%s)
                      AND COALESCE(le.record_status,'LIVE')='LIVE'
                      AND COALESCE(u.record_status,'LIVE')='LIVE'
                    ORDER BY a.book_code, u.sequence""" % ph,
                [entity_id] + list(BOOK_DICT_SRC)):
            short, full = BOOK_DICT_SRC[code]
            if (body or '').strip():
                out.append({'book': code, 'short': short, 'full': full,
                            'label': label, 'body': body})
    except Exception:
        pass
    return out


def absmith_entries(conn, entity_id):
    """엔티티의 헬라 앵커 → Abbott-Smith(1922) 사전 항목 (2026-09-03 186차).

    [A-S] 갈래가 읽는다 — BDB(히브리 쪽)의 짝. 다리 = sys_absmith_map
    (열쇠 n= 에 내장된 G 번호). 복수 G 항목(εἰμί 등)이 한 항목을 여러 번
    내지 않게 as_id 로도 거른다."""
    return absmith_entries_for(conn, anchors_of(conn, entity_id, 'EL'))


def absmith_entries_for(conn, anchors):
    out, seen_id = [], set()
    try:
        for st, tr_ko in anchors or ():
            if not str(st).startswith('G'):
                continue
            for aid, grk, occ, body in conn.execute(
                    "SELECT e.as_id, e.grk, e.occurs, e.body"
                    " FROM sys_absmith_map m"
                    " JOIN sys_absmith_entry e ON e.as_id=m.as_id"
                    " WHERE m.strong=?", (st,)):
                if aid in seen_id:
                    continue
                seen_id.add(aid)
                out.append({'strong': st, 'translit_ko': tr_ko,
                            'grk': grk, 'occurs': occ, 'body': body})
    except Exception:
        pass
    return out


def strong_sites(conn):
    """스트롱 번호 축 외부 사이트 — [(code, name, url_template)].

    `sys_ref_site` scope='STRONG' 행. 사이트를 늘리려면 표에 한 줄
    (2026-09-02 실측 — StudyLight 는 403 봇 차단이라 안 넣었다)."""
    try:
        return conn.execute(
            "SELECT site_code, site_name, url_template FROM sys_ref_site"
            " WHERE scope='STRONG' AND is_active=1"
            " AND COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY sort_order").fetchall()
    except Exception:
        return []


def strong_url(template, strong):
    """스트롱 자리표 치환 — {strong_num}·{strong_lang}·{strong_code_lc}·{blb_text}."""
    num = strong[1:].lstrip('0') or '0'
    he = strong.startswith('H')
    return (template
            .replace('{strong_num}', num)
            .replace('{strong_lang}', 'hebrew' if he else 'greek')
            .replace('{strong_code_lc}', strong.lower())
            .replace('{blb_text}', 'wlc' if he else 'tr'))


def ascii_fold(s):
    """음역의 발음 구별 부호를 벗긴 소문자 ASCII — 검색 대조용.

    마스터 음역이 `shâphaṭ`·`ʼâb` 꼴이라 그대로는 ASCII 검색이 0건이 된다
    (2026-09-02 실측). 저장은 안 바꾸고 대조 토큰만 이렇게 만든다."""
    import unicodedata
    # NFKD — ᵉ 같은 수정 글자(Lm)를 e 로 내려 준다(shᵉʼôwl → sheowl)
    s = unicodedata.normalize('NFKD', s or '')
    s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn')
    s = re.sub(r"[^a-z0-9]", '', s.lower())
    # 스트롱 음역의 홀렘·요드 관용 표기 — ow→o·iy→i (sheowl→sheol ·
    # towrah→torah). 원 음역 토큰은 따로 살아 있어 잃는 것이 없다.
    return s.replace('ow', 'o').replace('iy', 'i')


def field_siblings(conn, entity_id, lang='KO'):
    """의미장(semantic field) 형제 — [(다른 entity_id, 이름, 한 줄)] 목록.

    2026-09-02 신설 (177차 — 죄 시범). **연결은 별명(문자열)이 아니라
    데이터**라는 사용자 확정 설계의 조회 문:
      · 낱말 엔티티면 → 자기가 속한 의미장 + 같은 의미장의 다른 낱말 전부
      · 의미장 노드면 → 소속 낱말 전부
    소속 = `ENTI_ENTI` rel_code='FIELD_WORD'(clicked=의미장 · target=낱말).
    한 줄 = 그 항목 설명문의 첫 문장(요청 언어→EN→KO 폴백) — 낱말마다
    비교 글을 따로 쓰지 않아도 「자기 낱말부터」 여는 설명문 초입이 곧 요약이다.
    """
    lg = (lang or 'KO').upper()
    out, seen = [], {entity_id}

    def _name(eid):
        for L in (lg, 'EN', 'KO'):
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                " AND clicked_id=? AND lang_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (eid, L)).fetchone()
            if r and r[0]:
                return r[0]
        return None

    def _first_line(eid):
        for L in (lg, 'EN', 'KO'):
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_DESC'"
                " AND clicked_id=? AND lang_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (eid, L)).fetchone()
            if r and r[0]:
                seg = r[0].split(chr(10))[0].strip()
                # 첫 문장까지만 — 비교 칸 한 줄 요약
                for end in ('다. ', '. '):
                    p = seg.find(end)
                    if 0 < p < len(seg) - len(end):
                        seg = seg[:p + len(end) - 1]
                        break
                return seg
        return ''

    def _alive(eid):
        r = conn.execute(
            "SELECT 1 FROM sys_entity_master WHERE entity_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (eid,)).fetchone()
        return bool(r)

    try:
        fields = [r[0] for r in conn.execute(
            "SELECT clicked_id FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND rel_code='FIELD_WORD' AND target_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (entity_id,))]
        member_of = bool(fields)
        if not fields:
            fields = [entity_id]        # 자신이 의미장일 수 있다
        for fid in fields:
            # 의미장 자신도 한 줄로 — 개관 설명문으로 가는 길
            if member_of and fid not in seen and _alive(fid):
                seen.add(fid)
                nm = _name(fid)
                if nm:
                    out.append((fid, nm, _first_line(fid)))
            for (mid,) in conn.execute(
                    "SELECT target_id FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
                    " AND rel_code='FIELD_WORD' AND clicked_id=?"
                    " AND COALESCE(record_status,'LIVE')='LIVE'"
                    " ORDER BY sys_link_id", (fid,)):
                if mid in seen or not _alive(mid):
                    continue
                seen.add(mid)
                nm = _name(mid)
                if nm:
                    out.append((mid, nm, _first_line(mid)))
    except Exception:
        pass
    return out


#: **검색 결과의 세 갈래** (2026-09-07 사용자 교정).
#:
#: ★★★ **「어느 칸에서 걸렸나」가 아니라 「그 낱말과 무슨 사이인가」로 나눈다.**
#:   앞것은 기계의 사정(이름칸/별명칸)이고 뒤것이 읽는 사람의 사정이다.
#:   실제로 「전능자 · 샤다이」는 **별명**으로 걸리지만 그 자체가 하나님의
#:   이름이라 「거룩」과 같은 칸에 있으면 안 된다 — 사용자 지적이 그 자리다.
#: ⚠ **갈래를 지어내지 않았다** — 낱말 가족(`FIELD_WORD`)이 이미 답을 갖고
#:   있다(실측: 하나님의 이름 가족 7 = 엘·엘로힘·여호와·아도나이·샤다이·
#:   체바오트·엘욘). 축(`db_term_axis`)도 같은 답을 낸다.
SG_SELF, SG_PREFIX, SG_REL = 1, 2, 3


def name_parts(name):
    """이름을 가운뎃점으로 가른다 — 규약이 「대표어 · 음역」이다.

    ⚠ 통짜로 견주면 「하나님 · 엘」이 「하나님」과 정확 일치가 못 된다.
    ⚠ `db_word_chain.name_words` 와 달리 **한 글자·라틴도 남긴다** —
      여기서는 「의 · 체데크」의 「의」가 정답이라 버리면 안 된다.
    """
    import re as _re
    return [p.strip() for p in _re.split(r'[·|/]', name or '') if p.strip()]


def search_kin(conn, q, lang='KO'):
    """**그 낱말 자체이거나 그것의 다른 이름**인 항목 → {entity_id}.

    ① 이름 조각이 검색어와 똑같은 항목 ② 그 항목이 든 **낱말 가족의 형제**
    전부 + 가족 관문. 실측 — 「죄」로 찾으면 하타트·아온·페샤·마알이 한
    묶음에 서고, 「하나님」으로 찾으면 엘·엘로힘·샤다이·엘욘이 함께 선다.
    """
    q = (q or '').strip()
    if not q:
        return set()
    lg = (lang or 'KO').upper()
    kin = set()
    try:
        fam_of, mem_of = {}, {}
        for f, t in conn.execute(
                "SELECT clicked_id, target_id FROM sys_link_asset WHERE "
                "link_type='ENTI_ENTI' AND rel_code='FIELD_WORD' "
                "AND COALESCE(record_status,'LIVE')='LIVE'"):
            fam_of[t] = f
            mem_of.setdefault(f, set()).add(t)
        for eid, nm in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset WHERE "
                "text_type='ENTITY_NAME' AND lang_code=? "
                "AND COALESCE(record_status,'LIVE')='LIVE'", (lg,)):
            if q in name_parts(nm):
                kin.add(eid)
                f = fam_of.get(eid)
                if f:
                    kin.add(f)
                    kin |= mem_of.get(f, set())
    except Exception as e:
        print('[overlay_read search_kin] %s' % e)
    return kin


def search_group(q, name, eid=None, kin=()):
    """1 본명·별명 · 2 그 낱말로 시작하는 이름 · 3 관련된 것."""
    q = (q or '').strip()
    if not q:
        return SG_SELF
    p = name_parts(name)
    if q in p or (eid is not None and eid in kin):
        return SG_SELF
    if any(x.startswith(q) for x in p):
        return SG_PREFIX
    return SG_REL


def entity_search(conn, q='', lang='KO'):
    """엔티티 찾기 — **이름 + 별명(내 것 포함)**, 가린 엔티티 제외 → [(eid, 이름)].

    §12-5 규칙 그대로(별명을 넣어 두고 그것으로 못 찾으면 넣은 뜻이 없다).
    ⚠ 화면이 sys_entity_master 를 직접 뒤지지 말 것 — 검사기가 잡는다
      (2026-08-27 총괄 창 용어 검색이 실제로 첫 검거였다).
    """
    import entity_aliases as EA
    import db_tag_system as _T
    lg = (lang or 'KO').upper()
    q = (q or '').strip().lower()
    hits = []
    try:
        hidden = _T.user_hidden_entity_codes(conn)
        ual = overlay.entity_aliases_user(conn, lg)
        # ★ **낱말(원어 앵커) 층도 검색한다** (2026-09-02 사용자 지적 —
        #   「하마르티아·아노미아 … 검색 자체가 안 된다. 결국 죄에 대한
        #   포괄적 이해를 돕지 못한다」). 음역(하마르티아)·스트롱 번호(G266)
        #   가 이름·별명에 없어도 그 낱말을 안은 용어가 걸린다.
        lem, lemst = {}, {}
        if q:
            try:
                # 마스터 음역 — 정성 용어의 낱말 행은 음역이 한글(토라)이라
                # 라틴 검색(torah)이 비껴간다. 마스터의 라틴 음역을 합류.
                _mtr = {}
                try:
                    _mtr = dict(conn.execute(
                        "SELECT strong, COALESCE(translit,'')"
                        " FROM sys_lemma_master"))
                except Exception:
                    pass
                for _eid2, _tr, _st in conn.execute(
                        "SELECT entity_id, COALESCE(translit,''),"
                        " COALESCE(strong,'') FROM sys_entity_lemma"):
                    if _tr:
                        lem.setdefault(_eid2, []).append(_tr.lower())
                        # ★ 부호 벗긴 꼴도 — 마스터 음역이 shâphaṭ 꼴이라
                        #   ASCII 검색(shaphat)이 0건이 되는 것을 막는다(실측).
                        _a = ascii_fold(_tr)
                        if _a and _a != _tr.lower():
                            lem[_eid2].append(_a)
                    _m = _mtr.get(_st, '')
                    if _m and _m != _tr:
                        lem.setdefault(_eid2, []).append(_m.lower())
                        _a2 = ascii_fold(_m)
                        if _a2:
                            lem[_eid2].append(_a2)
                    if _st:
                        # ⚠ 스트롱 번호는 **정확 일치만** — 부분일치면 G93 이
                        #   G932(바실레이아)까지 잡는다(2026-09-02 실측).
                        lemst.setdefault(_eid2, set()).add(_st.lower())
            except Exception:
                pass
        for eid, code, jd, nm in conn.execute(
                "SELECT em.entity_id, em.entity_code, em.json_detail,"
                " COALESCE("
                "  (SELECT contents FROM sys_text_asset WHERE "
                "   text_type='ENTITY_NAME' AND clicked_id=em.entity_id"
                "   AND lang_code=? AND record_status='LIVE' LIMIT 1),"
                "  (SELECT contents FROM sys_text_asset WHERE "
                "   text_type='ENTITY_NAME' AND clicked_id=em.entity_id"
                "   AND lang_code='EN' AND record_status='LIVE' LIMIT 1),"
                "  em.entity_code) "
                "FROM sys_entity_master em WHERE em.record_status='LIVE'"
                " ORDER BY 4 COLLATE NOCASE", (lg,)):
            if code in hidden:
                continue
            if q:
                al = [a.lower() for a in EA.aliases_for_lang(jd, lg)]
                al += [a.lower() for a in ual.get(code, [])]
                if lg != 'EN':
                    # ★ EN 별명도 검색 열쇠로 (2026-09-03 185차) — 별명은
                    #   표시가 아니라 찾는 길이라 언어를 안 가린다(승격 용어의
                    #   라틴 별명 Raah 가 KO 화면에서 안 잡히던 것을 실측).
                    al += [a.lower() for a in EA.aliases_for_lang(jd, 'EN')]
                if q not in (nm or '').lower() and \
                        not any(q in a for a in al) and \
                        not any(q in w for w in lem.get(eid, ())) and \
                        q not in lemst.get(eid, ()):
                    continue
            elif '"subtype": "LEX"' in (jd or ''):
                # ★ 빈 검색 = 훑기 — 기계 낱말(전수 등록분 1.1만)은 목록이
                #   아니라 **검색·연결·의미장**으로 닿는다 (2026-09-02 사용자
                #   확정 — 「수백 개 묶음은 분류가 의미 없다」).
                continue
            hits.append((eid, nm or code,
                         1 if '"subtype": "LEX"' in (jd or '') else 0))
    except Exception as e:
        print('[overlay_read entity_search] %s' % e)
    # ★ 사람 손이 간 항목이 기계 낱말보다 앞 (2026-09-03 185차) — 승격 용어가
    #   라틴 이름의 LEX 낱말들 뒤(11위)로 밀리던 것을 실측. 각 묶음 안에서는
    #   SQL 의 이름순이 유지된다.
    # ★★ 그다음이 **검색어와의 사이**다 (2026-09-07 사용자 지적 — 「하나님을
    #   검색하면 하나님이 표시되기 이전에 먼저 거룩, 사랑 등이 먼저 표시된다」).
    #   그전에는 정렬 열쇠가 `(기계 낱말인가, 이름)` 둘뿐이라 가나다순으로
    #   거룩(ㄱ)이 하나님(ㅎ)을 이겼다. 실측 20낱말 중 6이 그 꼴이었고
    #   「의」는 44건 중 **32위**였다.
    # ⚠ 묶음 **안에서도** 그 낱말 자체가 형제보다 앞이다 — 안 그러면
    #   「하나님」이 1군 안에서 전능자·지존자 뒤 3위가 된다(실측).
    kin = search_kin(conn, q, lg) if q else set()
    hits.sort(key=lambda h: (h[2], search_group(q, h[1], h[0], kin),
                             0 if q and q in name_parts(h[1]) else 1))
    return [(e, n) for e, n, _ in hits]


def entity_search_grouped(conn, q='', lang='KO'):
    """`entity_search` + 갈래 → [(갈래, eid, 이름)] (갈래 오름차순).

    ⚠ 갈래가 **하나뿐이면 화면이 머리를 안 그린다** — 마디 하나가 늘 뿐이다
      (§0-1 빈 서랍). 실측 20낱말 중 묶음이 둘 이상인 것은 11.
    """
    lg = (lang or 'KO').upper()
    rows = entity_search(conn, q, lg)
    kin = search_kin(conn, q, lg) if (q or '').strip() else set()
    return [(search_group(q, n, e, kin), e, n) for e, n in rows]


def entity_verses(conn, entity_id, lang='KO'):
    """연결구절 — `entity_overlay.verse_links` 위임(합침·표식·설명문 포함)."""
    import entity_overlay as EO
    return EO.verse_links(conn, entity_id, lang)


def media(conn, entity_id, kind='ALL', lang='KO'):
    """엔티티의 영상·텍스트 링크 — **합침 조회의 정본** (C 단계 승격).

    sys(`sys_media_asset` + 통합 표) 위에 내 것(`user_media_asset` +
    `user_link_asset(MEDI_ENTI)`)을 얹고, 가림(`user_media_hide`)을 싣는다.
    갈렙 사고의 정체가 이 자리다 — 링크 탭이 sys 만 읽어서 **팝업으로 넣은
    내 링크가 화면에 없었다.**

    kind = 'VIDEO' | 'TEXT' | 'ALL'.  갈래 판정 = `media_link.yt_id`
    (재생 방식이 곧 갈래 — media_type 만 보면 안 된다, §95차).
    돌려주는 행: {src(SYS|NEW|HIDE), mid, title, url, yt, lang, mtype,
                 ftype, aud, desc, is_fav, is_user}
    ⚠ 위키(WIKI%)는 뺀다 — 사전 탭으로 일원화(§95차). 읽는 화면은
      `src=='HIDE'` 를 걸러서 그린다(H 는 관리 화면만 — overlay_mark 규칙).
    """
    import media_link
    lg = (lang or 'KO').upper()
    out = []
    try:
        hid = {r[0] for r in conn.execute(
            'SELECT media_id FROM userdb.user_media_hide')}
    except Exception:
        hid = set()
    try:
        for (mid, mlang, title, url, mtype, ftype, aud, desc,
             is_fav) in conn.execute(
                "SELECT ma.media_id, ma.lang_code, "
                "  COALESCE((SELECT tx.contents FROM sys_text_asset tx "
                "     WHERE tx.text_type='MEDIA_TITLE' "
                "       AND tx.clicked_id=ma.media_id AND tx.lang_code=? "
                "       AND tx.record_status='LIVE' LIMIT 1), ma.title), "
                "  ma.url, ma.media_type, COALESCE(ma.format_type,'VIDEO'), "
                "  COALESCE(ma.audience,'GENERAL'), COALESCE(ma.description,''),"
                "  CASE WHEN f.fav_id IS NOT NULL THEN 1 ELSE 0 END "
                "FROM " + media_link.TBL + " ml "
                "JOIN sys_media_asset ma ON ma.media_id=ml.clicked_id "
                + __import__('listen').join_sql('ma') + " "
                "WHERE ml.link_type=? AND ml.target_id=? AND ma.is_active=1 "
                # ★★★ 링크 상태를 본다(2026-09-09 실측으로 잡음 — 이 줄이 없어
                #   후보(PEND)·걷은(HIDE) 용어 연결까지 사용자 화면에 나가고 있었다.
                #   다윗 화면 538편 중 LIVE 는 0 이었다).
                "  AND COALESCE(ml.record_status,'LIVE')='LIVE' "
                "  AND ma.record_status='LIVE' AND ma.media_type NOT LIKE "
                "      'WIKI%' "
                "ORDER BY ma.sort_order, ma.media_id",
                (lg, media_link.lt('ENTITY'), int(entity_id))):
            out.append(dict(src='HIDE' if mid in hid else SYS, mid=mid,
                            title=title or '', url=url,
                            yt=media_link.yt_id(url), lang=mlang or '',
                            mtype=mtype, ftype=ftype, aud=aud, desc=desc,
                            is_fav=bool(is_fav), is_user=False))
    except Exception as e:
        print('[overlay_read media(sys)] %s' % e)
    try:
        for uid, title, url, st in conn.execute(
                'SELECT um.user_media_id, um.title, um.url, '
                "COALESCE(um.record_status,'LIVE') "
                'FROM userdb.user_media_asset um '
                'JOIN userdb.user_link_asset ul '
                '  ON ul.clicked_id=um.user_media_id '
                "WHERE ul.link_type='MEDI_ENTI' AND ul.target_id=?"
                "  AND COALESCE(ul.record_status,'LIVE')='LIVE'",
                (int(entity_id),)):
            out.append(dict(src='HIDE' if st == 'HIDE' else NEW, mid=uid,
                            title=title or '', url=url,
                            yt=media_link.yt_id(url), lang='',
                            mtype='USER', ftype='', aud='', desc='',
                            is_fav=False, is_user=True))
    except Exception as e:
        print('[overlay_read media(user)] %s' % e)
    # ★★ **링크 팩 합류** (2026-09-03 190차) — 외부 링크는 URL 이 빨리 썩어
    #   본체 6개월 주기를 못 따라간다. 별도 팩 파일(link_pack.db)이 그 집이고
    #   트레이가 증분으로 채운다. **팩이 없으면 조용히 건너뛴다** — 수신 전
    #   사용자에게도 앱은 그대로 돌아야 한다.
    #   ⚠ 본체에 같은 media_id 가 이미 있으면 **팩이 이긴다**(팩이 더 새 것 —
    #     그것이 팩을 두는 이유다). 본체에서 링크를 은퇴시키면 이 겹침은 0 이 된다.
    try:
        import link_pack as _lp
        if _lp.attach(conn) and _lp.available(conn):
            _have = {d['mid'] for d in out if not d['is_user']}
            try:
                _favv = __import__('listen').vids(conn)        # ♥ 즐겨듣기(영상 번호)
            except Exception:
                _fav = set()
            # ⚠⚠ **제목 덮개가 팩 행에도 걸려야 한다**(2026-09-03 점검에서
            #   검거 — 사용자가 고친 제목이 팩 행에서는 무시됐다). sys 조회와
            #   **같은 규칙**이라야 「어느 집에서 왔는가」로 동작이 갈리지 않는다.
            # ⚠ **제목 덮개를 행마다 묻지 않는다**(2026-09-03 성능 실측 —
            #   행별 서브쿼리로 4.8→21.6ms 였다). 팩 행을 먼저 모으고
            #   `media_titles` 한 문으로 한 번에 덮는다(links_panel 과 같은
            #   방식). 실측 21.6→6ms 대.
            _prows = conn.execute(
                    "SELECT pm.media_id, pm.lang_code, pm.title, pm.url,"
                    "       pm.media_type, COALESCE(pm.format_type,'VIDEO'),"
                    "       COALESCE(pm.description,'')"
                    "  FROM linkpack.pack_link pl"
                    "  JOIN linkpack.pack_media pm ON pm.media_id=pl.clicked_id"
                    " WHERE pl.link_type=? AND pl.target_id=?"
                    "   AND COALESCE(pl.record_status,'LIVE')='LIVE'"
                    "   AND COALESCE(pm.record_status,'LIVE')='LIVE'"
                    "   AND pm.is_active=1"
                    " ORDER BY pm.sort_order, pm.media_id",
                    (media_link.lt('ENTITY'), int(entity_id))).fetchall()
            _ovt = media_titles(conn, [r[0] for r in _prows], lg)
            # ⚠⚠ **겹침 제거를 행마다 하지 않는다**(2026-09-03 성능 실측 —
            #   행마다 목록을 통째로 재구성해 O(n²) 였다. 다윗 155행에서
            #   2.4만 회). 겹치는 번호를 **한 번에** 모아 한 번만 거른다.
            _dup = {r[0] for r in _prows} & _have
            if _dup:
                out = [d for d in out
                       if d['is_user'] or d['mid'] not in _dup]  # 팩이 이긴다
            for (mid, mlang, title, url, mtype, ftype, desc) in _prows:
                title = _ovt.get(mid, title)
                out.append(dict(src='HIDE' if mid in hid else SYS, mid=mid,
                                title=title or '', url=url,
                                yt=media_link.yt_id(url), lang=mlang or '',
                                mtype=mtype, ftype=ftype, aud='GENERAL',
                                desc=desc, is_fav=(media_link.yt_id(url) in _favv),
                                is_user=False))
    except Exception as e:
        print('[overlay_read media(pack)] %s' % e)
    if kind in ('VIDEO', 'TEXT'):
        out = [d for d in out if (kind == 'VIDEO') == bool(d['yt'])]
    return out


def tags(db_path, kind, tid, lang='KO'):
    """붙은 태그 — `tag_picker.tags_of` 위임(sys+user 통합·덮개 이름)."""
    import tag_picker as TP
    return TP.tags_of(db_path, kind, tid, lang)


def count_reading(rows):
    """읽는 화면의 개수 — H 를 뺀 수(entity_verses·media 처럼 `src` 를
    실은 관리 목록에서). 읽는 화면 = N·E·SYS 만(§95차 overlay_mark 규칙)."""
    return sum(1 for r in rows if (r.get('src') or r.get('_src')) != 'HIDE')


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — **탐지력까지** (규칙을 죽이면 FAIL 해야 한다)
# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    conn = appdb.connect()
    E = 999931                              # 시험 엔티티 번호(없는 번호대)
    n0 = conn.execute('SELECT COUNT(*) FROM userdb.user_link_asset'
                      ).fetchone()[0]
    try:
        # ── 연결: N — 내가 더한 것 ──
        conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
                     " target_id, record_status) VALUES('ENTI_MEDI', ?, "
                     " 999932, 'LIVE')", (E,))
        conn.commit()
        got = links(conn, 'ENTITY', E)
        t('★ N — 내가 더한 연결이 나온다', len(got) == 1
          and got[0]['_src'] == NEW, got)
        t('★ 개수 = 목록 (N:+1)', link_count(conn, 'ENTITY', E) == 1)
        # ── H — sys 를 가린다 (실존 sys 연결 하나를 골라) ──
        s = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset "
                         " WHERE link_type='ENTI_MEDI' "
                         "   AND COALESCE(record_status,'LIVE')='LIVE' "
                         " LIMIT 1").fetchone()
        if s:
            eid, mid = s
            base = link_count(conn, 'ENTITY', eid)
            conn.execute("INSERT INTO userdb.user_link_asset(link_type,"
                         " clicked_id, target_id, record_status) "
                         " VALUES('ENTI_MEDI', ?, ?, 'HIDE')", (eid, mid))
            conn.commit()
            after = link_count(conn, 'ENTITY', eid)
            t('★ H — 가리면 sys 가 안 나온다 (개수 −1: %d→%d)'
              % (base, after), after == base - 1)
            hid = [x for x in links(conn, 'ENTITY', eid)
                   if x['kind'] == 'MEDIA' and x['id'] == mid]
            t('   가린 그 행이 목록에 없다', not hid)
            # ── E — 같은 짝을 LIVE 로 (내 행이 대체) ──
            conn.execute("UPDATE userdb.user_link_asset SET "
                         " record_status='LIVE' WHERE clicked_id=? "
                         "   AND target_id=? AND link_type='ENTI_MEDI'",
                         (eid, mid))
            conn.commit()
            back = links(conn, 'ENTITY', eid)
            edit = [x for x in back if x['kind'] == 'MEDIA'
                    and x['id'] == mid]
            t('★ E — 같은 짝 LIVE 는 대체(개수 0: %d)' % len(back),
              len(back) == base and edit and edit[0]['_src'] == EDIT,
              edit[:1])
            conn.execute("DELETE FROM userdb.user_link_asset "
                         " WHERE clicked_id=? AND target_id=? "
                         "   AND link_type='ENTI_MEDI'", (eid, mid))
            conn.commit()
        # ── 방향 불문 — 짝을 뒤집어 가려도 같은 sys 가 가려진다 ──
        # ⚠ 자연 열쇠에 rel 이 든다(§28-1 — 같은 짝에 관점 여럿이 정상).
        #   가림도 **그 관점의 행**을 가리는 것이므로 rel 을 함께 맞춘다.
        # ⚠ **개인 표에 같은 자연 열쇠의 LIVE 행이 있는 짝은 피한다**
        #   (2026-09-01 — 통합 수술로 개인 표에 ENTI_VERS 가 생기자, 아무
        #   행이나 집던 이 시험이 그 짝을 집어 가림이 안 먹는 것처럼 보였다.
        #   LIVE 덮개가 HIDE 시험 행과 같은 열쇠로 겹친 것 — 시험이 틀렸다).
        s2 = conn.execute(
            "SELECT s.clicked_id, s.target_id, s.rel_code "
            "  FROM sys_link_asset s "
            " WHERE s.link_type='ENTI_VERS' "
            "   AND COALESCE(s.record_status,'LIVE')='LIVE' "
            # ⚠ 구간 연결은 피한다 — 자연 열쇠에 end 가 들어 뒤집힌 HIDE(끝 없음)와 안 맞는다
            "   AND s.end_id IS NULL "
            "   AND NOT EXISTS(SELECT 1 FROM userdb.user_link_asset u "
            "     WHERE u.link_type IN ('ENTI_VERS','VERS_ENTI') "
            "       AND ((u.clicked_id=s.clicked_id AND u.target_id=s.target_id)"
            "         OR (u.clicked_id=s.target_id AND u.target_id=s.clicked_id)))"
            " LIMIT 1").fetchone()
        if s2:
            eid2, vid2, rel2 = s2
            b2 = link_count(conn, 'ENTITY', eid2)
            # 일부러 **뒤집힌 이름**으로 가림 행을 넣는다
            conn.execute("INSERT INTO userdb.user_link_asset(link_type,"
                         " clicked_id, target_id, rel_code, record_status) "
                         " VALUES('VERS_ENTI', ?, ?, ?, 'HIDE')",
                         (vid2, eid2, rel2))
            conn.commit()
            t('★ 뒤집힌 이름의 가림도 먹는다 (%d→%d)'
              % (b2, link_count(conn, 'ENTITY', eid2)),
              link_count(conn, 'ENTITY', eid2) == b2 - 1)
            conn.execute("DELETE FROM userdb.user_link_asset "
                         " WHERE link_type='VERS_ENTI' AND clicked_id=? "
                         "   AND target_id=?", (vid2, eid2))
            conn.commit()
        # ── 「가린 것 보기」 옵션 + text_lang 정본 (2026-08-27) ──
        was_opt = show_hidden(conn)
        d0 = conn.execute("SELECT clicked_id, lang_code, contents "
                          " FROM sys_text_asset "
                          " WHERE text_type='ENTITY_DESC' "
                          "   AND COALESCE(record_status,'LIVE')='LIVE' "
                          "   AND contents IS NOT NULL LIMIT 1").fetchone()
        if d0:
            cid, lg, body = d0
            r0, s0 = text_lang(conn, 'ENTITY_DESC', cid, lg,
                               opt_show_hidden=False)
            t('text_lang — sys 읽기', s0 == SYS and r0
              and r0['contents'] == body, s0)
            # 가림 심기 (자연 열쇠 — entity_code 로 바뀐다)
            import entity_overlay as _EO
            ec = conn.execute('SELECT entity_code FROM sys_entity_master '
                              'WHERE entity_id=?', (cid,)).fetchone()
            okey = 'ENTITY_DESC|%s|%s|' % (ec[0], (lg or '').upper())
            had = conn.execute('SELECT 1 FROM userdb.user_text_asset '
                               'WHERE origin_key=?', (okey,)).fetchone()
            if not had:
                conn.execute(
                    "INSERT INTO userdb.user_text_asset(text_type, clicked_id,"
                    " lang_code, origin_key, record_status) "
                    "VALUES('ENTITY_DESC', ?, ?, ?, 'HIDE')",
                    (cid, (lg or '').upper(), okey))
                conn.commit()
                r1, s1 = text_lang(conn, 'ENTITY_DESC', cid, lg,
                                   opt_show_hidden=False)
                t('★ 가림 — 옵션 끄면 내용 없음', s1 == 'HIDE' and r1 is None)
                r2, s2 = text_lang(conn, 'ENTITY_DESC', cid, lg,
                                   opt_show_hidden=True)
                t('★ 가림 — 옵션 켜면 원본이 나오고 상태는 HIDE',
                  s2 == 'HIDE' and r2 and r2['contents'] == body, s2)
                conn.execute('DELETE FROM userdb.user_text_asset '
                             'WHERE origin_key=?', (okey,))
                conn.commit()
        set_show_hidden(conn, True)
        t('옵션 저장 왕복', show_hidden(conn) is True)
        set_show_hidden(conn, was_opt)
        t('   원복', show_hidden(conn) == was_opt)

        # ── 설명글 — 가림은 폴백을 이긴다 ──
        r, src = text(conn, 'ENTITY_DESC', 999933, 'KO')
        t('없는 자리 = MISSING', r is None and src == 'MISSING')
        d = conn.execute("SELECT clicked_id FROM sys_text_asset "
                         " WHERE text_type='ENTITY_DESC' AND lang_code='KO' "
                         "   AND COALESCE(record_status,'LIVE')='LIVE' "
                         " LIMIT 1").fetchone()
        if d:
            r2, src2 = text(conn, 'ENTITY_DESC', d[0], 'KO')
            t('sys 설명글 = SYS', r2 is not None and src2 == SYS, src2)
        # ── 탐지력 — 규칙을 죽이면 검사가 우는가 ──
        conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
                     " target_id, record_status) VALUES('ENTI_MEDI', ?, "
                     " 999934, 'HIDE')", (E,))
        conn.commit()
        t('★ 탐지력 — sys 짝 없는 HIDE(뗀 것)는 안 나온다',
          link_count(conn, 'ENTITY', E) == 1)
        # ── hidden_ids — 자기 SQL 화면이 가림만이라도 지키는 문 ──
        conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
                     " target_id, record_status) VALUES('REFU_ENTI', 999935, "
                     " ?, 'HIDE')", (E,))
        conn.commit()
        t('hidden_ids — 뒤집힌 이름의 HIDE 짝도 잡는다',
          999935 in hidden_ids(conn, 'ENTITY', E, 'REF_UNIT'))
        t('   다른 갈래에는 안 섞인다',
          999935 not in hidden_ids(conn, 'ENTITY', E, 'BOOK_UNIT'))
        # ── 위임 표면 — 엔티티 머리 + 유형 덮개 왕복 ──
        import entity_overlay as EO
        eid3 = conn.execute("SELECT entity_id FROM sys_entity_master "
                            " WHERE record_status='LIVE' LIMIT 1"
                            ).fetchone()[0]
        h0 = entity(conn, eid3, 'KO')
        t('entity() — 이름·code·유형이 나온다',
          bool(h0['code']) and h0['_type_src'] in (SYS, EDIT), h0['code'])
        prev = EO.type_override(conn, h0['code'])
        had_row = bool(conn.execute(
            'SELECT 1 FROM userdb.user_entity_asset WHERE entity_code=?',
            (h0['code'],)).fetchone())
        if prev is None:                    # 실사용 덮개가 없을 때만 왕복 시험
            EO.save_type(conn, h0['code'], 'PLACE')
            h1 = entity(conn, eid3, 'KO')
            t('★ 유형 덮개 — EDIT 로 갈아탄다',
              h1['type'] == 'PLACE' and h1['_type_src'] == EDIT)
            EO.save_type(conn, h0['code'], '')      # 되돌림
            h2 = entity(conn, eid3, 'KO')
            t('   되돌리면 SYS', h2['type'] == h0['type']
              and h2['_type_src'] == SYS)
            if not had_row:                 # ⚠ 시험이 만든 빈 행은 지운다
                conn.execute('DELETE FROM userdb.user_entity_asset '
                             ' WHERE entity_code=?', (h0['code'],))
                conn.commit()
        # ── count_reading — H 를 뺀다 ──
        t('count_reading — H 제외',
          count_reading([{'src': 'SYS'}, {'src': 'NEW'},
                         {'src': 'HIDE'}, {'_src': 'EDIT'}]) == 3)
        # ── 위임 갈래가 실제로 도는가(형태만 — 규칙은 각자 selftest 몫) ──
        t('entity_verses() 위임', isinstance(entity_verses(conn, eid3), list))
        t('media() 위임', isinstance(media(conn, eid3, 'VIDEO'), list))
    finally:
        conn.execute('DELETE FROM userdb.user_link_asset '
                     ' WHERE clicked_id IN (?, 999932, 999934, 999935) '
                     '    OR target_id IN (?, 999932, 999934, 999935)', (E, E))
        conn.commit()
        n1 = conn.execute('SELECT COUNT(*) FROM userdb.user_link_asset'
                          ).fetchone()[0]
        t('시험 잔재 0 (%d→%d)' % (n0, n1), n0 == n1)
        conn.close()
    print('overlay_read selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1) if '--selftest' in sys.argv else print(__doc__)
