"""유튜브 주소 간편 저장 — 엔진 (2026-10-09 · docs/1.txt 59-3).

사용자 「유투브 브라우저에서 설교 / CCM을 듣다가 유투브 주소 등을 우리 앱에 쉽게
저장하고 구절/용어와 연결할 수 있는 손쉬운 기능」 → 「1,2,3 진행하라 · 단축키는
필요없다」.

들어오는 길 셋(같은 알림 창으로 모인다):
  ① **하가로 돌아올 때** — 복사한 뒤 사람이 하가 창을 앞으로 올리는 순간
     클립보드를 **한 번** 읽는다(`ReturnWatch`)
  ② **트레이 아이콘을 누를 때** — 왼쪽 클릭 · 오른쪽 메뉴 맨 위 항목(`TrayHook`)
  ③ **확장 프로그램 「+Hagah」** — 브라우저 단추가 이 PC 안의 앱(127.0.0.1 `/save`)에 주소와 제목을 넘긴다
     (`LinkServer`). ⚠ 북마크 단추(`/yt`)는 2026-10-12 폐기 — 우리 아이콘을 못 단다(사용자).
★★ 2026-10-09 사용자 「유투브 주소 복사를 우리 앱 목적이 아닌 다른 목적으로 한 것일
  수도 있다 · 특히 트레이 모드에서」 → 「하가 앱이 포커스가 주어질 때 · 트레이 앱을
  클릭할 때」 — **1초마다 클립보드를 보던 감지를 걷었다.** 사람이 하가로 온
  순간만 읽으므로 다른 목적의 복사에는 반응하지 않는다.

★ **제목·채널은 유튜브 oEmbed** 로 받는다(키 없음 · 공식 제공).
⚠⚠ **설명문은 받지도 저장하지도 않는다** — 수집한 설명문을 사용자 화면에 그리지
  않기로 정했다(2026-09-17 사용자 · 저작권).
★ 저장 = 내 영상 **한 줄** + 연결 여럿(`UMED_VERS` 구절 · `MEDI_ENTI` 용어).
  같은 주소는 다시 담지 않는다(`link_picker.new_user_media` 멱등) — 개인 DB 에
  중복이 생기면 앱의 결함이다(1.txt 58).
⚠ 클립보드는 **유튜브 주소 한 줄일 때만** 쓴다 — 다른 글은 읽어도 아무 데도
  안 남긴다. 한 번 물은 주소(✕ 로 넘긴 것 포함)와 이미 저장한 영상은 다시 묻지 않는다
  (`user_config['YT_LAST_ASKED']` — 앱과 트레이가 함께 본다).
  스위치 `user_config['YT_ASK_ON_RETURN']`(기본 켜짐) · `['YT_LINK_SERVER']`(기본 켜짐).
"""
import json
import queue
import re
import threading
import time
import urllib.parse
import urllib.request

import appdb

PORT = 47615
#: 앱이 거는 고리 — 설정 화면이 부른다({'cfg': fn(열쇠, 켜짐), 'edit': fn(uid, url, 제목)})
HOOKS = {}
CFG_RETURN = 'YT_ASK_ON_RETURN'
CFG_LAST = 'YT_LAST_ASKED'
CFG_SERVER = 'YT_LINK_SERVER'
MEDIA_TYPES = ('SERMON', 'WORSHIP', 'STUDY')

_YT_RX = re.compile(
    r'^(?:https?://)?(?:(?:www|m|music)\.)?'
    r'(?:youtube\.com/(?:watch\?(?:[^#\s]*&)?v=|shorts/|live/|embed/)|youtu\.be/)'
    r'([A-Za-z0-9_-]{11})(?:[?&#/][^\s]*)?$')


# ── 주소 ─────────────────────────────────────────────────────────────────
def parse(text):
    """글이 **유튜브 영상 주소 한 줄**이면 `(영상 번호, 표준 주소)` · 아니면 None.

    ⚠ 긴 글 속에 섞인 주소는 안 집는다 — 사람이 그 글을 복사한 까닭은 주소가 아니다.
    """
    s = (text or '').strip()
    if not s or len(s) > 400 or any(ch in s for ch in ' \t\r\n'):
        return None
    m = _YT_RX.match(s)
    if not m:
        return None
    vid = m.group(1)
    return vid, 'https://www.youtube.com/watch?v=' + vid


def oembed(url, timeout=6, opener=None):
    """→ {'title','author'} · 못 받으면 {}. 망이 없어도 터지지 않는다."""
    q = 'https://www.youtube.com/oembed?format=json&url=' + urllib.parse.quote(url, safe='')
    try:
        req = urllib.request.Request(q, headers={'User-Agent': 'Hagah/1.0'})
        raw = (opener or urllib.request.urlopen)(req, timeout=timeout).read()
        d = json.loads(raw.decode('utf-8', 'replace'))
        return {'title': (d.get('title') or '').strip(),
                'author': (d.get('author_name') or '').strip()}
    except Exception:
        return {}


# ── 설정 ─────────────────────────────────────────────────────────────────
def cfg_on(key, db_path=None):
    try:
        conn = appdb.connect(db_path)
        try:
            r = conn.execute('SELECT config_val FROM user_config WHERE config_key=?',
                             (key,)).fetchone()
        finally:
            conn.close()
        return not (r and str(r[0]).strip() in ('0', 'OFF', 'False', 'false'))
    except Exception:
        return True


_STATE = {}


def cached_on(key, db_path=None):
    """`cfg_on` 을 한 번만 읽고 기억한다 — 1초마다 도는 감지가 DB 를 두드리지 않게."""
    if key not in _STATE:
        _STATE[key] = cfg_on(key, db_path)
    return _STATE[key]


def cfg_set(key, on, db_path=None):
    _STATE[key] = bool(on)
    conn = appdb.connect(db_path)
    try:
        v = '1' if on else '0'
        if not conn.execute('UPDATE user_config SET config_val=? WHERE config_key=?',
                            (v, key)).rowcount:
            conn.execute('INSERT INTO user_config(config_key,config_val) VALUES(?,?)', (key, v))
        conn.commit()
    finally:
        conn.close()


# ── 추천 ─────────────────────────────────────────────────────────────────
_CTX = {}


def guess_type(title):
    """제목으로 갈래를 짐작한다 — 사람이 바꾼다(창에 라디오가 있다)."""
    t = (title or '').lower()
    for w in ('찬양', 'ccm', 'worship', '워십', 'praise', 'hymn', '찬송', 'lyrics', '가사',
              'live worship', 'mv'):
        if w in t:
            return 'WORSHIP'
    for w in ('설교', 'sermon', '말씀', '강해', '예배', 'preach', 'message'):
        if w in t:
            return 'SERMON'
    return 'STUDY'


def suggest(conn, title, lang='KO'):
    """제목에서 구절·용어 추천 → {'verses': [(s, e, 이름)], 'terms': [(eid, 이름)]}.

    구절 = `scripture_ref.find`(연구자료 자동 연결과 같은 문 · 다국어) ·
    용어 = `media_text_linker.analyze`(영상 자동 연결과 같은 문).
    """
    out = {'verses': [], 'terms': []}
    if not (title or '').strip():
        return out
    L = (lang or 'KO').upper()
    try:
        import scripture_ref
        # 장·편만 적힌 참조는 추천도 안 한다(2026-10-13 84-2 · scripture_ref.linkable 한 문)
        for s, e, _m, _k in scripture_ref.linkable(scripture_ref.find(conn, title, L))[:8]:
            out['verses'].append((s, e, verse_name(conn, s, e, L)))
    except Exception as ex:
        print('[yt_intake verses] %s' % ex)
    try:
        import media_text_linker as MT
        ctx = _CTX.get(L)
        if ctx is None:
            ctx = _CTX[L] = MT.build_context(conn, L)
        for eid in (MT.analyze(conn, title, ctx).get('entity') or [])[:8]:
            out['terms'].append((eid, entity_name(conn, eid, L)))
    except Exception as ex:
        print('[yt_intake terms] %s' % ex)
    return out


def verse_name(conn, s, e=None, lang='KO'):
    def one(v):
        r = conn.execute(
            'SELECT COALESCE(b.short_name, b2.short_name, bi.bcode), bi.chapter, bi.verse '
            'FROM bible_index bi LEFT JOIN book_names b ON b.book_code=bi.bcode AND UPPER(b.lang_code)=? '
            "LEFT JOIN book_names b2 ON b2.book_code=bi.bcode AND b2.lang_code='EN' "
            'WHERE bi.verse_id=?', (lang, int(v))).fetchone()
        return r
    a = one(s)
    if not a:
        return str(s)
    txt = '%s %d:%d' % (a[0], a[1], a[2])
    if e and int(e) != int(s):
        b = one(e)
        if b:
            txt += ('~%d' % b[2]) if b[1] == a[1] else ('~%d:%d' % (b[1], b[2]))
    return txt


def entity_name(conn, eid, lang='KO'):
    for lg in (lang, 'EN', 'KO'):
        r = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                         ' AND clicked_id=? AND UPPER(lang_code)=?', (int(eid), lg)).fetchone()
        if r and r[0]:
            return r[0]
    return str(eid)


# ── 저장 ─────────────────────────────────────────────────────────────────
def find_media(conn, url):
    r = conn.execute('SELECT user_media_id FROM userdb.user_media_asset WHERE url=?'
                     ' ORDER BY user_media_id', (url,)).fetchone()
    return r[0] if r else None


def _link(conn, lt, uid, tgt, end=None):
    """연결 하나 — 살아 있으면 그대로 · 숨겨져 있으면 되살린다(사람이 다시 선택한 것이다)."""
    end = int(end) if end and int(end) != int(tgt) else None
    r = conn.execute(
        'SELECT user_link_id, COALESCE(record_status,\'LIVE\') FROM userdb.user_link_asset'
        ' WHERE link_type=? AND clicked_id=? AND target_id=?'
        ' AND COALESCE(end_id,target_id)=COALESCE(?,target_id) ORDER BY user_link_id',
        (lt, int(uid), int(tgt), end)).fetchall()
    if any(s == 'LIVE' for _i, s in r):
        return False
    if r:
        conn.execute("UPDATE userdb.user_link_asset SET record_status='LIVE' WHERE user_link_id=?",
                     (r[-1][0],))
        return True
    conn.execute('INSERT INTO userdb.user_link_asset(link_type, clicked_id, target_id, end_id,'
                 " record_status) VALUES(?,?,?,?,'LIVE')", (lt, int(uid), int(tgt), end))
    return True


def save(conn, url, title='', media_type='STUDY', verses=(), terms=(), lang='KO'):
    """내 영상 한 줄 + 연결 → (uid, 새로 건 연결 수). 같은 주소면 그 줄을 쓴다."""
    import link_picker as LP
    p = parse(url)
    if not p:
        raise ValueError('유튜브 영상 주소가 아니다: %r' % (url,))
    url = p[1]
    uid = LP.new_user_media(conn, title, url,
                            media_type if media_type in MEDIA_TYPES else 'STUDY', lang)
    n = 0
    for v in verses or ():
        s, e = (v[0], v[1]) if isinstance(v, (tuple, list)) else (v, None)
        n += bool(_link(conn, 'UMED_VERS', uid, s, e))
    for eid in terms or ():
        n += bool(_link(conn, 'MEDI_ENTI', uid, eid))
    conn.commit()
    return uid, n


def collect(conn, url, title='', lang='KO', fetch_title=True):
    """폰이 모은 유튜브 영상을 PC 가 받을 때 — 갈래를 나누고 제목의 구절·용어를 잇는다
    → (uid, 새로 건 연결 수, 갈래).

    ★ 2026-10-14 사용자 「폰이 유튜브 수집기 역할 · 동기화하면 수집함이 아니라 설교/찬양 등으로 분류되고 구절연결 등이
      이루어져야 한다 · PC 도 수집기이자 관리기」 — 폰 「수집함」→ PC 「내 영상」(갈래 = guess_type · 연결 = suggest).
      사람이 고치는 자리는 설정 ▸ 유튜브 간편 저장의 [연결 고치기]다. 같은 주소면 그 줄에 없는 연결만 더한다.
    """
    title = (title or '').strip()
    if fetch_title and not title:
        try:
            title = (oembed(url) or {}).get('title') or ''
        except Exception:
            title = ''
    typ = guess_type(title)
    sg = suggest(conn, title, lang) if title else {'verses': [], 'terms': []}
    uid, n = save(conn, url, title, typ, [(s_, e_) for s_, e_, _nm in sg['verses']],
                  [eid for eid, _nm in sg['terms']], lang)
    return uid, n, typ


# ── 웹 글(유튜브가 아닌 쪽) — 2026-10-11 사용자 결정 ──────────────────────
#   「우리 앱은 텍스트인지 유투브인지 정도로 분류」 · 「기사·블로그·설교·구절 등은 사용자가 연결」.
#   ⇒ 제목·주소만 「내 자료」(user_ref_asset · 유형 WEB)에 담는다. **본문은 가져오지 않는다**(저작권 —
#     유튜브 설명문을 안 받는 것과 같은 원칙). 연결은 사람이 알림 창에서 고른 것만(자동 추천 없음).
WEB_TYPE = 'REFERENCE'   # ★ 2026-10-16 유형 = 참고자료 · 출처 = 외부 수집(ref_origin WEB · docs/1.txt 2-2)


def parse_web(url):
    """유튜브가 아닌 http(s) 쪽 주소면 정리한 주소 · 아니면 None."""
    u = (url or '').strip()
    if not u or parse(u):
        return None
    try:
        p = urllib.parse.urlparse(u)
    except Exception:
        return None
    if p.scheme not in ('http', 'https') or not p.netloc:
        return None
    host = p.hostname or ''
    if host in ('127.0.0.1', 'localhost') or host.endswith('.local'):
        return None
    return urllib.parse.urlunparse(p._replace(fragment=''))


def site_name(url):
    try:
        h = urllib.parse.urlparse(url).hostname or ''
    except Exception:
        return ''
    return h[4:] if h.startswith('www.') else h


def find_web(conn, url):
    import ref_kinds
    ref_kinds.ensure(conn)
    r = conn.execute("SELECT ref_id FROM userdb.user_ref_asset WHERE url=? AND (ref_origin='WEB' OR ref_type='WEB')"
                     " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY ref_id", (url,)).fetchone()
    return r[0] if r else None


def save_web(conn, url, title='', verses=(), terms=(), lang='KO'):
    """내 자료(웹 글) 한 줄 + 사람이 선택한 연결 → (ref_id, 새로 건 연결 수). 같은 주소면 그 줄을 쓴다."""
    import db_user_ref_schema as UR
    u = parse_web(url)
    if not u:
        raise ValueError('웹 쪽 주소가 아니다: %r' % (url,))
    UR.init(conn)
    rid = find_web(conn, u)
    title = (title or '').strip() or site_name(u) or u
    if rid is None:
        cur = conn.execute(
            "INSERT INTO userdb.user_ref_asset(ref_type, title, source_name, url, lang_code, record_status)"
            " VALUES(?,?,?,?,?,'LIVE')", (WEB_TYPE, title, site_name(u), u, (lang or 'KO').upper()))
        rid = cur.lastrowid
        conn.execute("UPDATE userdb.user_ref_asset SET ref_origin='WEB' WHERE ref_id=?", (rid,))
    else:
        conn.execute('UPDATE userdb.user_ref_asset SET title=? WHERE ref_id=?', (title, rid))
    links = [('VERSE', (v[0] if isinstance(v, (tuple, list)) else v),
              (v[1] if isinstance(v, (tuple, list)) else None)) for v in verses or ()]
    links += [('ENTITY', eid, None) for eid in terms or ()]
    n = UR.add_links(conn, rid, links) if links else 0      # src 없음 = 사람이 이은 것
    conn.commit()
    return rid, n


# ── 확장 단추를 눌렀을 때 — 바로 창 / 조용히 저장 (2026-10-12 사용자 결정) ───────────────
#   「체크하는 것은 수시 심사 · 해제하면 공유/저장처럼 필요할 때 PC 열어보고 심사」.
#   ⇒ 조용히 저장 = 연결 없이 받은 목록에만 넣는다(재생목록·폰 공유와 같은 흐름). 기본은 「바로 창」.
CFG_QUIET = 'YT_BTN_QUIET'


def quiet_on(db_path=None):
    """확장 단추를 조용히 저장하나 → True/False(기본 False = 바로 저장·연결 창)."""
    return (_cfg_get(CFG_QUIET, db_path) or '').strip() == '1'


def user_lang(db_path=None):
    try:
        conn = appdb.connect(db_path)
        try:
            r = conn.execute("SELECT config_val FROM user_config WHERE config_key='user_lang'").fetchone()
        finally:
            conn.close()
        return ((r[0] if r and r[0] else 'KO') or 'KO').upper()
    except Exception:
        return 'KO'


def quiet_save(db_path, url, title='', lang=None):
    """창 없이 받은 목록에 넣는다 → ('YT'|'WEB', 번호) 또는 None. 연결은 나중에 사람이 한다."""
    lang = (lang or user_lang(db_path)).upper()
    try:
        if parse(url) and not (title or '').strip():
            title = (oembed(url) or {}).get('title') or ''
        conn = appdb.connect(db_path)
        try:
            if parse(url):
                return 'YT', save(conn, url, title, guess_type(title), (), (), lang)[0]
            if parse_web(url):
                return 'WEB', save_web(conn, url, title, (), (), lang)[0]
        finally:
            conn.close()
    except Exception as e:
        print('[yt quiet] %s' % e)
    return None


def received_all(conn, limit=300):
    """받은 영상·글 — 내 영상(유튜브) + 내 자료(웹 글)를 최근 먼저 한 목록으로.

    → [{'key','uid','web','title','url','kind','verses','terms'}] · key = 'M번호'(영상)·'W번호'(웹 글)
      (두 표가 저마다 1번부터 번호를 매기므로 앞글자로 가른다).
    """
    out = [dict(r, key='M%d' % r['uid'], web=False) for r in received(conn, limit)]
    try:
        rows = conn.execute(
            "SELECT ra.ref_id, ra.title, ra.url,"
            " (SELECT COUNT(*) FROM userdb.user_link_asset l WHERE l.clicked_id=ra.ref_id"
            "   AND l.link_type='UREF_VERS' AND COALESCE(l.record_status,'LIVE')='LIVE'),"
            " (SELECT COUNT(*) FROM userdb.user_link_asset l WHERE l.clicked_id=ra.ref_id"
            "   AND l.link_type='UREF_ENTI' AND COALESCE(l.record_status,'LIVE')='LIVE')"
            " FROM userdb.user_ref_asset ra WHERE (ra.ref_origin='WEB' OR ra.ref_type='WEB')"
            " AND COALESCE(ra.record_status,'LIVE')='LIVE'"
            ' ORDER BY ra.ref_id DESC LIMIT ?', (int(limit),)).fetchall()
    except Exception:
        rows = []
    out += [{'key': 'W%d' % a, 'uid': a, 'web': True, 'title': b or c, 'url': c, 'kind': 'WEB',
             'verses': d, 'terms': e} for a, b, c, d, e in rows]
    return out


def web_links_of(conn, rid):
    """그 웹 글에 걸린 것 → {'verses': [(s,e)], 'terms': [eid]}."""
    out = {'verses': [], 'terms': []}
    for lt, t, e in conn.execute(
            'SELECT link_type, target_id, end_id FROM userdb.user_link_asset WHERE clicked_id=?'
            " AND link_type IN ('UREF_VERS','UREF_ENTI') AND COALESCE(record_status,'LIVE')='LIVE'",
            (int(rid),)):
        if lt == 'UREF_ENTI':
            out['terms'].append(t)
        else:
            out['verses'].append((t, e or t))
    return out


# ── 「+Hagah」 재생목록 — 유튜브 앱의 「저장」 단추로 모은다(2026-10-11 사용자 결정) ────────────
#   사용자가 유튜브에 재생목록 하나를 만들고 **「일부 공개」**로 둔 뒤 그 주소를 하가에 한 번 붙인다.
#   그 뒤로는 폰·TV·PC 어디서든 유튜브 「저장」 ▸ 그 목록 → 하가(앱·트레이)가 몇 시간마다 읽어
#   「내 영상」으로 들인다. 연결(구절·용어)은 사람이 나중에 한다.
#   ★ 유튜브가 주는 **재생목록 피드**(feeds/videos.xml)를 읽는다 — API 키·구글 로그인이 필요 없다.
#   ⚠ 「비공개」 목록은 피드가 열리지 않는다(404) — 그래서 「일부 공개」가 핵심이다.
#   ⚠ 피드는 **최근 15개**만 준다 — 몇 시간마다 읽으므로 그 사이 15개를 넘게 담지 않는 한 빠지지 않는다.
CFG_PLAYLIST = 'YT_PLAYLIST_URL'
CFG_PLAYLIST_LAST = 'YT_PLAYLIST_LAST'      # "때|결과" — 화면이 보인다
FEED_URL = 'https://www.youtube.com/feeds/videos.xml?playlist_id=%s'
_PL_RX = re.compile(r'(?:[?&]list=|^)((?:PL|UU|LL|FL|OL|RD)[A-Za-z0-9_-]{10,})')


def playlist_id(text):
    """재생목록 주소(또는 ID) → ID · 아니면 None. 「나중에 볼 동영상」(WL)은 유튜브가 열어 주지 않는다."""
    t = (text or '').strip()
    m = _PL_RX.search(t)
    return m.group(1) if m else None


def fetch_playlist(pid, timeout=12, opener=None):
    """→ [(영상 주소, 제목, 채널)] 최근 것부터 · 못 읽으면 ValueError(사람 말)."""
    import xml.etree.ElementTree as ET
    op = opener or urllib.request.urlopen
    try:
        req = urllib.request.Request(FEED_URL % pid, headers={'User-Agent': 'Mozilla/5.0 Hagah'})
        raw = op(req, timeout=timeout).read()
    except urllib.error.HTTPError as e:
        if e.code in (400, 403, 404):
            raise ValueError('재생목록을 읽지 못했습니다 — 공개 범위가 「일부 공개」(또는 공개)인지 확인하세요')
        raise ValueError('유튜브가 답하지 않습니다(HTTP %d) — 나중에 다시 해 봅니다' % e.code)
    except Exception:
        raise ValueError('인터넷에 연결하지 못했습니다 — 나중에 다시 해 봅니다')
    ns = {'a': 'http://www.w3.org/2005/Atom', 'yt': 'http://www.youtube.com/xml/schemas/2015'}
    out = []
    root = ET.fromstring(raw)
    for e in root.findall('a:entry', ns):
        vid = (e.findtext('yt:videoId', '', ns) or '').strip()
        if vid:
            out.append(('https://www.youtube.com/watch?v=' + vid, (e.findtext('a:title', '', ns) or '').strip(),
                        (e.findtext('a:author/a:name', '', ns) or '').strip()))
    return out


def import_playlist(conn, pid, lang='KO', fetch=None):
    """재생목록의 영상 가운데 **아직 없는 것만** 내 영상으로 들인다 → (새로 들인 수, 목록 수)."""
    items = (fetch or fetch_playlist)(pid)
    n = 0
    for url, title, _ch in items:
        if find_media(conn, url) is None:
            save(conn, url, title, guess_type(title), (), (), lang)
            n += 1
    return n, len(items)


def playlist_tick(db_path=None, force=False, min_hours=6):
    """앱·트레이가 부른다 — 주소가 있고 때가 됐으면 한 번 읽는다 → 사람 말 한 줄(안 했으면 '').

    ⚠ 결과와 상관없이 때를 적는다(망이 없다고 깨어날 때마다 두드리지 않는다)."""
    url = _cfg_get(CFG_PLAYLIST, db_path) or ''
    pid = playlist_id(url)
    if not pid:
        return ''
    import datetime
    conn = appdb.connect(db_path)
    try:
        if not force:
            try:
                import rss_reader as R
                if not R.should_auto_sync(conn, 'ytlist', min_hours=min_hours):
                    return ''
            except Exception:
                pass
        try:
            n, tot = import_playlist(conn, pid, (_cfg_get('user_lang', db_path) or 'KO').upper())
            msg = ('새 영상 %d개를 들였습니다' % n) if n else '새 영상이 없습니다'
            if tot >= 15 and n >= 15:
                msg += ' · ⚠ 한꺼번에 15개 넘게 담았으면 앞의 것이 빠졌을 수 있습니다'
        except ValueError as e:
            msg = str(e)
        try:
            import rss_reader as R
            R.mark_auto_sync(conn, 'ytlist')
        except Exception:
            pass
    finally:
        conn.close()
    _cfg_put(CFG_PLAYLIST_LAST, '%s|%s' % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M'), msg), db_path)
    return msg


def received(conn, limit=200):
    """받은 영상 — 내가 담은 영상(최근 먼저) + 걸린 구절·용어 수.

    → [{'uid','title','url','kind','verses','terms'}]. 연결이 0인 것도 그대로 둔다
      (개인 DB 의 고립은 의도된 것이다 · 1.txt 58).
    """
    rows = conn.execute(
        "SELECT um.user_media_id, um.title, um.url, COALESCE(um.category,'STUDY'),"
        " (SELECT COUNT(*) FROM userdb.user_link_asset l WHERE l.clicked_id=um.user_media_id"
        "   AND l.link_type IN ('UMED_VERS','MEDI_VERS') AND COALESCE(l.record_status,'LIVE')='LIVE'),"
        " (SELECT COUNT(*) FROM userdb.user_link_asset l WHERE l.clicked_id=um.user_media_id"
        "   AND l.link_type='MEDI_ENTI' AND COALESCE(l.record_status,'LIVE')='LIVE')"
        ' FROM userdb.user_media_asset um'
        " WHERE COALESCE(um.record_status,'LIVE')='LIVE' AND um.url LIKE '%youtu%'"
        ' ORDER BY um.user_media_id DESC LIMIT ?', (int(limit),)).fetchall()
    return [{'uid': a, 'title': b or c, 'url': c, 'kind': d, 'verses': e, 'terms': f}
            for a, b, c, d, e, f in rows]


def links_of(conn, uid):
    """그 영상에 걸린 것 → {'verses': [(s,e)], 'terms': [eid]}."""
    out = {'verses': [], 'terms': []}
    for lt, t, e in conn.execute(
            'SELECT link_type, target_id, end_id FROM userdb.user_link_asset WHERE clicked_id=?'
            " AND link_type IN ('UMED_VERS','MEDI_VERS','MEDI_ENTI')"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (int(uid),)):
        if lt == 'MEDI_ENTI':
            out['terms'].append(t)
        else:
            out['verses'].append((t, e or t))
    return out


class LinkServer:
    """127.0.0.1 에서만 듣는 아주 작은 받는 곳. 받은 주소는 `q` 에 넣는다.

    ⚠ 바깥 기기에서는 닿지 않는다(127.0.0.1 바인드) · 유튜브 주소만 받는다 ·
      자리를 이미 누가 쓰고 있으면(트레이 등) 조용히 안 연다.
    """

    def __init__(self, port=PORT):
        self.port = port
        self.q = queue.Queue()
        self.httpd = None

    def start(self):
        import http.server
        q = self.q

        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                u = urllib.parse.urlparse(self.path)
                ok = False
                web = False
                if u.path == '/save':
                    # /save = 확장 프로그램(2026-10-11) — 유튜브·웹 글을 받는다(북마크 /yt 는 2026-10-12 폐기)
                    qs = urllib.parse.parse_qs(u.query)
                    url = (qs.get('u') or [''])[0]
                    title = (qs.get('t') or [''])[0]
                    if parse(url):
                        title = re.sub(r'\s*-\s*YouTube\s*$', '', title or '').strip()
                        q.put((url, title))
                        ok = True
                    elif parse_web(url):
                        q.put((url, (title or '').strip()))
                        ok = web = True
                if u.path == '/save':                     # 확장 프로그램은 창 없이 짧은 답만 받는다
                    body = (b'{"ok":true,"kind":"%s"}' % (b'WEB' if web else b'YT')) if ok else b'{"ok":false}'
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Content-Length', str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                # 그 밖의 주소(옛 북마크 /yt 포함 · 2026-10-12 폐기)는 받지 않는다
                self.send_response(404)
                self.send_header('Content-Length', '0')
                self.end_headers()

            def log_message(self, *a):
                pass

        class _Srv(http.server.ThreadingHTTPServer):
            # ⚠⚠ **한 프로그램만 이 자리를 쥔다**(2026-10-09 시험이 잡았다) — 기본값
            #   `allow_reuse_address` 가 윈도우에서는 **같은 포트를 둘이 함께** 잡게 해
            #   앱과 트레이가 둘 다 듣고 요청이 아무 쪽으로나 갔다. 재사용을 끄고
            #   배타 사용(SO_EXCLUSIVEADDRUSE)을 건다 — 늦게 온 쪽은 OSError 로 물러난다.
            allow_reuse_address = False

            def server_bind(self):
                import socket as _s
                if hasattr(_s, 'SO_EXCLUSIVEADDRUSE'):
                    try:
                        self.socket.setsockopt(_s.SOL_SOCKET, _s.SO_EXCLUSIVEADDRUSE, 1)
                    except OSError:
                        pass
                super().server_bind()

        try:
            self.httpd = _Srv(('127.0.0.1', self.port), H)
        except OSError:
            self.httpd = None
            return False
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        return True

    def stop(self):
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None

    def ensure(self, gap=5.0):
        """자리를 못 잡았으면 **몇 초마다 다시** 잡아 본다 → 지금 쥐고 있나(True/False).

        ⚠⚠ 2026-10-12 사용자 신고 「크롬 단추를 눌렀더니 하가를 켜라고 한다 — 이미 켜져 있다」 —
          앱이 켜질 때 옛 트레이가 자리를 쥐고 있어 앱은 **한 번 물러나고 다시는 안 잡았다.**
          옛 트레이가 꺼진 뒤에는 **아무도 안 듣는** 자리가 되었다. 앱·트레이가 이 문을
          주기적으로 부르면, 쥐던 쪽이 꺼지는 순간 남은 쪽이 이어받는다.
        """
        if self.httpd is not None:
            return True
        now = time.time()
        if now - getattr(self, '_last_try', 0.0) < gap:
            return False
        self._last_try = now
        return self.start()

    def holder_old(self, timeout=1.5):
        """그 자리를 **남이** 쥐고 있는데 옛 판인가 → True/False.

        새 판은 `/save` 에 JSON(`{"ok":false}`)으로 답하고, 확장 받기를 넣기 전 판은
        웹 화면(HTML)으로 답한다 — 확장은 그 답을 못 읽어 「하가가 꺼져 있다」고 보인다.
        """
        if self.httpd is not None:
            return False
        try:
            import urllib.request
            with urllib.request.urlopen('http://127.0.0.1:%d/save?u=' % self.port, timeout=timeout) as r:
                ct = (r.headers.get('Content-Type') or '').lower()
            return 'json' not in ct
        except Exception:
            return False


def clip_seq():
    """윈도우 클립보드 순번 — 바뀔 때마다 하나씩 는다(못 읽으면 0)."""
    try:
        import ctypes
        return int(ctypes.windll.user32.GetClipboardSequenceNumber())
    except Exception:
        return 0


def clip_text():
    """클립보드 글(유니코드) — Tk 없이 Win32 로 읽는다(트레이용 · 못 읽으면 '')."""
    try:
        import ctypes
        u, k = ctypes.windll.user32, ctypes.windll.kernel32
        u.GetClipboardData.restype = ctypes.c_void_p
        k.GlobalLock.argtypes = [ctypes.c_void_p]
        k.GlobalLock.restype = ctypes.c_void_p
        k.GlobalUnlock.argtypes = [ctypes.c_void_p]
        if not u.OpenClipboard(None):
            return ''
        try:
            h = u.GetClipboardData(13)          # CF_UNICODETEXT
            if not h:
                return ''
            ptr = k.GlobalLock(h)
            try:
                return ctypes.wstring_at(ptr) if ptr else ''
            finally:
                k.GlobalUnlock(h)
        finally:
            u.CloseClipboard()
    except Exception:
        return ''


def _cfg_get(key, db_path=None):
    try:
        conn = appdb.connect(db_path)
        try:
            r = conn.execute('SELECT config_val FROM user_config WHERE config_key=?', (key,)).fetchone()
        finally:
            conn.close()
        return (r[0] if r else '') or ''
    except Exception:
        return ''


def _cfg_put(key, val, db_path=None):
    conn = appdb.connect(db_path)
    try:
        if not conn.execute('UPDATE user_config SET config_val=? WHERE config_key=?',
                            (val, key)).rowcount:
            conn.execute('INSERT INTO user_config(config_key,config_val) VALUES(?,?)', (key, val))
        conn.commit()
    finally:
        conn.close()


def should_ask(text, db_path=None, force=False):
    """클립보드 글을 보고 물을 주소를 낸다 → 표준 주소 또는 None.

    묻지 않는 것 — 유튜브 영상 주소가 아님 · 이미 물었음(✕ 로 넘긴 것 포함 ·
    `force` 면 이 둘을 따지지 않는다) · 이미 저장한 영상.
    """
    p = parse(text)
    if not p:
        return None
    url = p[1]
    if not force and _cfg_get(CFG_LAST, db_path) == url:
        return None
    try:
        conn = appdb.connect(db_path)
        try:
            r = conn.execute("SELECT 1 FROM userdb.user_media_asset WHERE url=?"
                             " AND COALESCE(record_status,'LIVE')='LIVE'", (url,)).fetchone()
        finally:
            conn.close()
        if r and not force:
            return None
    except Exception:
        pass
    return url


def mark_asked(url, db_path=None):
    """물었다고 적는다 — 앱과 트레이가 함께 본다(같은 주소를 두 번 묻지 않게)."""
    try:
        _cfg_put(CFG_LAST, url or '', db_path)
    except Exception as e:
        print('[yt_intake mark] %s' % e)


class ReturnWatch:
    """**하가 창으로 돌아올 때** 한 번 클립보드를 본다(2026-10-09 사용자 지시).

    · 하가를 떠날 때(포커스가 앱 밖으로) 클립보드 순번을 적어 두고
    · 돌아올 때 순번이 바뀌었으면(= 떠난 뒤에 무엇을 복사했으면) 그 글을 읽는다.
    ⚠ 앱 안에서 팝업·다른 창을 오갈 때는 떠난 것이 아니다(`focus_get` 이 앱 위젯).
    ⚠ 앱이 처음 뜰 때 이미 있던 클립보드는 묻지 않는다(그때 순번으로 시작한다).
    """

    def __init__(self, root, on_hit, enabled=lambda: True, db_path=None):
        self.root = root
        self.on_hit = on_hit
        self.enabled = enabled
        self.db_path = db_path
        self.away = False
        self.seq = clip_seq()
        self._job = None

    def start(self):
        self.root.bind_all('<FocusOut>', self._out, add='+')
        self.root.bind_all('<FocusIn>', self._in, add='+')
        # 처음부터 뒤에 떠 있으면(최소화로 켬 등) 「떠난 상태」로 시작한다
        self._job = self.root.after(1000, self._check_left)

    def _focus_inside(self):
        try:
            return self.root.focus_get() is not None
        except Exception:
            return True          # 콤보 펼침처럼 이름을 못 푸는 위젯 = 앱 안이다

    def _out(self, _e=None):
        if self._job:
            try:
                self.root.after_cancel(self._job)
            except Exception:
                pass
        self._job = self.root.after(80, self._check_left)

    def _check_left(self):
        self._job = None
        if not self.away and not self._focus_inside():
            self.away = True
            self.seq = clip_seq()

    def _in(self, _e=None):
        if not self.away:
            return
        self.away = False
        n = clip_seq()
        if n == self.seq:
            return
        self.seq = n
        try:
            if not self.enabled():
                return
            try:
                s = self.root.clipboard_get()
            except Exception:
                s = ''
            url = should_ask(s, self.db_path)
            if url:
                mark_asked(url, self.db_path)
                self.root.after(150, lambda u=url: self.on_hit(u))
        except Exception as e:
            print('[ReturnWatch] %s' % e)


class TrayHook:
    """트레이 — 확장 프로그램 받는 곳 + **아이콘을 누를 때** 클립보드를 본다.

    · 왼쪽 클릭 = `click()` — 아직 안 물은 유튜브 주소가 있으면 알림 창을 띄운다
    · 오른쪽 메뉴 = `has_clip()` 이면 맨 위에 「복사한 유튜브 영상 저장」 → `click(force=True)`
    알림 창은 **따로** 띄운다(`yt_save_win.py --url …` · 트레이에는 Tk 가 없다).
    ⚠ 클립보드를 **주기적으로 보지 않는다**(사용자 지시 — 다른 목적의 복사).
    """

    def __init__(self, db_path='bible_master.db', launch=None):
        self.db_path = db_path
        self.launch = launch or self._launch
        self.srv = LinkServer()
        self.srv.start()          # ★ 2026-10-12 늘 받는다(사용자 — 「단추 받기」 체크상자 걷음)

    @staticmethod
    def _launch(url, title=''):
        import os
        import subprocess
        import sys
        here = os.path.dirname(os.path.abspath(__file__))
        exe = sys.executable
        w = os.path.join(os.path.dirname(exe), 'pythonw.exe')
        if os.path.exists(w):
            exe = w
        args = [exe, os.path.join(here, 'yt_save_win.py'), '--url', url]
        if title:
            args += ['--title', title]
        try:
            subprocess.Popen(args, cwd=here)
        except Exception as e:
            print('[yt tray] %s' % e)

    def has_clip(self):
        return parse(clip_text()) is not None

    def click(self, force=False):
        """→ 띄웠으면 True. `force` = 메뉴에서 선택한 것(이미 물었어도 다시 묻는다)."""
        if not force and not cfg_on(CFG_RETURN, self.db_path):
            return False
        url = should_ask(clip_text(), self.db_path, force=force)
        if not url:
            return False
        mark_asked(url, self.db_path)
        self.launch(url, '')
        return True

    def tick(self):
        """확장 프로그램으로 들어온 것만 처리한다(0.5초마다 · 클립보드는 안 본다)."""
        self.srv.ensure()                      # 앱이 쥐고 있다 꺼지면 이어받는다(몇 초마다)
        try:
            while True:
                url, title = self.srv.q.get_nowait()
                if quiet_on(self.db_path):     # 조용히 저장 — 창 없이 받은 목록에만
                    threading.Thread(target=quiet_save, args=(self.db_path, url, title),
                                     daemon=True).start()
                else:
                    self.launch(url, title)
        except queue.Empty:
            pass

    def stop(self):
        self.srv.stop()


# ── 자가 검증 ───────────────────────────────────────────────────────────
def selftest():
    import os
    import sqlite3
    import tempfile
    ok, tot = 0, 0

    def t(name, cond, got=''):
        nonlocal ok, tot
        tot += 1
        ok += bool(cond)
        print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  ' + str(got)))

    V = 'dQw4w9WgXcQ'
    for s in ('https://www.youtube.com/watch?v=%s' % V, 'youtu.be/%s' % V,
              'https://youtu.be/%s?si=abc' % V, 'https://m.youtube.com/watch?feature=x&v=%s' % V,
              'https://www.youtube.com/shorts/%s' % V, 'https://www.youtube.com/live/%s?t=3' % V,
              'https://music.youtube.com/watch?v=%s&list=RD' % V):
        t('주소 읽기 · ' + s[:40], parse(s) == (V, 'https://www.youtube.com/watch?v=' + V), parse(s))
    for s in ('', '그냥 글', 'https://www.youtube.com/', 'https://vimeo.com/123',
              '설교 https://youtu.be/%s 좋다' % V, 'https://www.youtube.com/playlist?list=PL1'):
        t('안 집는다 · %r' % s[:30], parse(s) is None, parse(s))

    class _R:
        def read(self):
            return json.dumps({'title': '시편 23편 강해', 'author_name': '어느 교회'}).encode()
    t('oEmbed — 제목·채널', oembed('x', opener=lambda *a, **k: _R())
      == {'title': '시편 23편 강해', 'author': '어느 교회'})

    def _boom(*a, **k):
        raise OSError('no net')
    t('oEmbed — 망이 없으면 빈 것', oembed('x', opener=_boom) == {})
    t('갈래 짐작 · 찬양', guess_type('주님 큰 영광 받으소서 | 찬양 가사') == 'WORSHIP')
    t('갈래 짐작 · 설교', guess_type('로마서 8장 설교') == 'SERMON')

    # 저장 — 개인 DB 사본에서(배포 DB 는 읽기 전용)
    app = os.path.dirname(os.path.abspath(__file__))
    tmp = os.path.join(tempfile.gettempdir(), 'hagah_yt_selftest.db')
    for x in ('', '-wal', '-shm'):
        if os.path.exists(tmp + x):
            os.remove(tmp + x)
    src = sqlite3.connect(os.path.join(app, 'user_data.db'))
    dst = sqlite3.connect(tmp)
    src.backup(dst)
    dst.close()
    src.close()
    conn = sqlite3.connect('file:%s?mode=ro' % os.path.join(app, 'bible_master.db').replace('\\', '/'),
                           uri=True)
    conn.execute("ATTACH DATABASE 'file:%s?mode=rw' AS userdb" % tmp.replace('\\', '/'))
    try:
        sug = suggest(conn, '요한복음 3:16 설교 — 니고데모', 'KO')
        t('추천 — 제목의 구절', any(s == e for s, e, _n in sug['verses']) and bool(sug['verses']), sug)
        eid = conn.execute("SELECT entity_id FROM sys_entity_master WHERE"
                           " COALESCE(record_status,'LIVE')='LIVE' ORDER BY entity_id LIMIT 1").fetchone()[0]
        url = 'https://youtu.be/%s' % V
        uid, n = save(conn, url, '시험 영상', 'SERMON', [(1, 1), (2, 3)], [eid])
        t('저장 — 한 줄 + 연결 셋', n == 3, n)
        uid2, n2 = save(conn, 'https://www.youtube.com/watch?v=%s' % V, '', 'SERMON', [(1, 1)], [eid])
        t('★ 같은 주소 다시 — 같은 줄 · 새 연결 0', uid2 == uid and n2 == 0, (uid, uid2, n2))
        t('★ 내 영상 줄은 하나', conn.execute('SELECT COUNT(*) FROM userdb.user_media_asset'
                                       ' WHERE url=?', (parse(url)[1],)).fetchone()[0] == 1)
        lk = links_of(conn, uid)
        t('걸린 것을 읽는다', sorted(lk['verses']) == [(1, 1), (2, 3)] and lk['terms'] == [eid], lk)
        t('받은 영상 목록에 있다', any(r['uid'] == uid and r['verses'] == 2 for r in received(conn)))
        try:
            save(conn, 'https://example.com/x', 'x')
            t('유튜브 아닌 주소는 거부', False)
        except ValueError:
            t('유튜브 아닌 주소는 거부', True)
        # 웹 글(2026-10-11) — 제목·주소만 · 사람이 고른 연결만
        t('웹 주소 읽기', parse_web('https://www.desiringgod.org/articles/x#c') == 'https://www.desiringgod.org/articles/x')
        t('웹 — 유튜브·로컬·글은 안 집는다', parse_web(url) is None and parse_web('http://127.0.0.1:8/x') is None
          and parse_web('그냥 글') is None and parse_web('ftp://a.b/c') is None)
        w = 'https://www.newsnjoy.or.kr/news/articleView.html?idxno=1'
        rid, wn = save_web(conn, w, '시험 웹 글', [(1, 1)], [eid])
        r = conn.execute('SELECT ref_type, ref_origin, title, source_name, url FROM userdb.user_ref_asset WHERE ref_id=?',
                         (rid,)).fetchone()
        t('웹 글 — 내 자료 한 줄(참고자료 · 외부 수집 · 사이트 이름)',
          r == ('REFERENCE', 'WEB', '시험 웹 글', 'newsnjoy.or.kr', w), r)
        t('웹 글 — 연결 둘', wn == 2 and web_links_of(conn, rid) == {'verses': [(1, 1)], 'terms': [eid]},
          (wn, web_links_of(conn, rid)))
        rid2, wn2 = save_web(conn, w + '#top', '', [(1, 1)])
        t('★ 웹 글 같은 주소 — 같은 줄 · 새 연결 0', rid2 == rid and wn2 == 0, (rid, rid2, wn2))
        t('웹 글 — 연결은 사람 표식(source 없음)', conn.execute(
            "SELECT COUNT(*) FROM userdb.user_link_asset WHERE clicked_id=? AND link_type IN ('UREF_VERS','UREF_ENTI')"
            " AND source IS NOT NULL", (rid,)).fetchone()[0] == 0)
        # +Hagah 재생목록(2026-10-11) — 없는 것만 들인다 · 두 번 읽어도 늘지 않는다
        t('재생목록 주소 읽기', playlist_id('https://www.youtube.com/playlist?list=PLabcdefghij12') == 'PLabcdefghij12'
          and playlist_id('https://www.youtube.com/playlist?list=WL') is None)
        fake = lambda _p: [('https://www.youtube.com/watch?v=AAAAAAAAAAA', '시편 1편 설교', 'x'),
                           ('https://www.youtube.com/watch?v=%s' % V, '이미 있음', 'x')]
        t('재생목록 — 새 것만 들인다', import_playlist(conn, 'PLx', 'KO', fetch=fake) == (1, 2))
        t('재생목록 — 다시 읽어도 0', import_playlist(conn, 'PLx', 'KO', fetch=fake) == (0, 2))
    finally:
        conn.close()
        for x in ('', '-wal', '-shm'):
            try:
                os.remove(tmp + x)
            except OSError:
                pass
    print('%d/%d' % (ok, tot))
    return ok == tot


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
