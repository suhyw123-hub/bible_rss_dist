# -*- coding: utf-8 -*-
"""P2 · 오른쪽 패널의 **주 탭 선택하기** 팝업 (2026-09-16 · 1.txt 19-2).

사용자 지시 — 「P2 탭 구조를 사용자 선호에 따라서 설정하는 기능. 설정버튼+팝업화면.
모든 탭 요소를 열거하고, 사용자가 메인탭을 표시할 대상을 지정하면 나머지 요소들은
더보기(서브탭)으로 자동 배치」. 원탭(한 화면 스크롤) 방식은 **뒤에 다시 협의**한다.

무엇을 하나
    두 칸 — 연구 화면(P2) · 캔버스/트리뷰 오른쪽 패널. 갈래마다 체크 하나.
    [적용] 이 ① 설정값(`user_config['P4_NODE_MAIN_TABS']` · `['EB_MAIN_TABS']`)을 쓰고
    ② 살아 있는 화면에 **그 자리에서** 반영한다(`SplitTabs.set_main`). 앱을 다시 켤
    필요가 없다. [기본값] 은 설계 기본으로 되돌린다.

규칙(값을 읽는 쪽과 같다 — `NodePanel._main_keys`)
    · 연구자료·내부연결은 **짝**이다(패널 하나를 나눠 쓴다) — 한쪽을 고르면 다른 쪽도.
    · 하나도 안 고르면 기본값으로 본다(빈 윗줄을 만들지 않는다).
⚠ 단추는 **위**(§0). 색·글꼴은 테마 역할(`ui_theme.adopt` · `theme_font.register`).
"""
import tkinter as tk
from tkinter import ttk

import appdb
import i18n

#: 갈래 이름 열쇠 — 화면(user_main · p4_node_panel)과 같은 `P2T_*`
LABELS = {'DESC': ('P2T_DESC', '설명'), 'COMM': ('P2T_COMM', '주석'),
          'LEX': ('P2T_LEX', '원어'), 'NOTE': ('P2T_NOTE', '묵상노트'),
          'PERI': ('P2T_PERI', '구절단락'), 'FLOW': ('P2T_FLOW', '말씀흐름'),
          'REFR': ('P2T_REFR', '연구자료'), 'NAV': ('P2T_NAV', '내부연결'),
          'VIDEO': ('P2T_VIDEO', '영상'), 'TEXT': ('P2T_TEXT', '텍스트'),
          'SONG': ('P2T_SONG', '찬양')}
PAIR = ('REFR', 'NAV')

#: 주요용어(P4) 서브탭 이름 — **그 화면이 쓰는 열쇠 그대로**(갈라지면 안 된다)
LABELS_EB = {'DICT':  ('TAB_TERMDICT', '용어사전'),
             'LINK':  ('TAB_ENTITY_LINKVERSE', '용례구절'),
             'VIDEO': ('EB_BR_VIDEO', '영상링크'),
             'TEXT':  ('EB_BR_TEXT', '텍스트링크'),
             'STUDY': ('TAB_RESEARCH', '연구자료'),
             'NAV':   ('REFR_SCOPE_NAV', '내부연결'),
             'SONG':  ('TAB_SONG', '찬양')}

#: 두 화면 — (설정 열쇠, 갈래 차례, 기본 주 탭)
SCREENS = (
    # ⚠ 2026-10-13 — P2 줄을 걷었다(P2 는 설명·묵상노트 두 탭으로 고정 · docs/1.txt 75).
    ('P4_NODE_MAIN_TABS',
     ('DESC', 'COMM', 'NOTE', 'PERI', 'FLOW', 'REFR', 'NAV', 'VIDEO', 'TEXT',
      'SONG'),
     ('DESC', 'COMM', 'NOTE', 'PERI'), 'P2TS_COL_NODE', '캔버스·트리뷰 오른쪽 패널'),
    # ★★★ **주요용어(P4)** — 2026-09-17 사용자가 필수·선택을 직접 정했다.
    #   필수 = 용어사전 · 용례구절 / 선택 = 나머지 다섯 / **여정은 삭제**했다
    #   (같은 지도를 P4 「믿음의 발자취」 탭이 넓게 보인다 — 자리가 둘이었다).
    #   ⚠ 기본은 **일곱 전부**다(필수 둘 + 선택 다섯) — 「지금까지의 모습」.
    #     여기를 필수 둘로 두었다가 「서브탭을 골라도 안 바뀐다」가 났다.
    ('EB_MAIN_TABS',
     ('DICT', 'LINK', 'VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG'),
     ('DICT', 'LINK', 'VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG'),
     'P2TS_COL_EB', '주요용어(P4)'),
)


#: ★★★ **필수 메인탭 — 뺄 수 없다**(2026-09-17 사용자 「1)필수 메인탭: 설명문,
#:   주석, 묵상노트」). 이 셋이 고정이라 더보기에 오는 것은 **언제나 줄 목록뿐**이고,
#:   그래서 통합탭이 성립한다(합칠 수 없는 「읽는 글·쓰는 자리」가 안 내려온다).
FIXED = ('DESC', 'COMM', 'NOTE')

#: 화면별 필수 — **없는 화면은 전역 `FIXED`**(옛 호출 보호)
FIXED_BY = {'EB_MAIN_TABS': ('DICT', 'LINK')}
#: 화면별 짝 — 주요용어는 연구자료·내부연결이 **다른 패널**이라 짝이 아니다
PAIR_BY = {'EB_MAIN_TABS': ()}


def fixed_of(cfg_key):
    return FIXED_BY.get(cfg_key, FIXED)


def pair_of(cfg_key):
    return PAIR_BY.get(cfg_key, PAIR)

#: 더보기 표시방식 — 서브탭 / 통합탭 (화면마다 따로 기억한다)
MORE_KEY = {'P4_NODE_MAIN_TABS': 'P4_NODE_MORE_MODE',
            'EB_MAIN_TABS': 'EB_MORE_MODE'}
MORE_MODES = (('TABS', 'P2TS_MORE_TABS', '서브탭'),
              ('ONE', 'P2TS_MORE_ONE', '통합탭'))
MORE_DEFAULT = 'TABS'

#: ⚠⚠ **한 번 걷었다가 되돌렸다**(2026-09-17) — 주요용어에서 라디오가 아무 일도
#:   안 해 보였는데, 까닭은 라디오가 아니라 **기본 주 탭이 「필수 둘」이던 버그**
#:   였다(그때는 서브탭이어도 다섯이 전부 더보기였다). 고친 뒤에는 두 값이
#:   **다른 화면**을 낸다 — 서브탭 = 체크대로 · 통합탭 = 선택 전부 한 목록.
#:   ★ **증상 하나를 두 가지로 진단해 멀쩡한 것을 걷지 말 것.**
NO_MORE_MODE = ()

#: ★★★ **목록이 0인 갈래를 아예 감춘다**(2026-09-17 · 1.txt 3-2 사용자 「탭
#:   내부에 목록이 전혀 없는 경우 **아예 탭 자체가 표시되지 않도록** 할 수
#:   있는가? 이것도 T버튼 눌렀을 때 **사용자 옵션**으로 설정할 수 있는가?」).
#:   ⚠ **예외 = 필수 셋**(설명·주석·묵상노트) — 사용자가 못 박은 그대로다
#:     (「묵상노트는 항상 표시되어야 한다」). 그리고 그 셋이 늘 있어야
#:     통합탭 규칙이 무너지지 않는다.
#:   ⚠ **구절단락·원어는 셈이 없다** — 「0 인지 아닌지」를 모르므로 안 건드린다.
#:     모르는 것을 감추면 조용히 사라지는 것이 된다(§0-1).
HIDE_EMPTY_KEY = {'P4_NODE_MAIN_TABS': 'P4_NODE_HIDE_EMPTY',
                  'EB_MAIN_TABS': 'EB_HIDE_EMPTY'}
HIDEABLE = ('FLOW', 'REFR', 'NAV', 'VIDEO', 'TEXT', 'SONG')
#: 화면별 — 주요용어는 **선택 다섯 전부**가 대상이다(필수 둘만 예외)
HIDEABLE_BY = {'EB_MAIN_TABS': ('VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG')}


def hideable_of(cfg_key):
    return HIDEABLE_BY.get(cfg_key, HIDEABLE)


def read_hide_empty(db_path, key):
    """0 인 갈래를 감출 것인가 — 기본은 **안 감춘다**(지금까지의 동작)."""
    try:
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (key,)).fetchone()
        return (r[0] if r else '') == '1'
    except Exception:
        return False


def write_hide_empty(db_path, key, on):
    with appdb.connect(db_path) as c:
        c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                  "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                  (key, '1' if on else '0'))
        c.commit()
    return bool(on)


def visible_with(key, count, base, hide_empty, hideable=None,
                 empty_gone=('SONG',)):
    """그 갈래를 보일 것인가 — **판정은 여기 하나**(화면 셋이 함께 쓴다).

    `base` = 표시방식이 정한 보임(통합탭이면 주 탭만 참) ·
    `count` = 그 갈래의 개수(`None` = 셀 수 없음) ·
    `hideable` = 그 화면에서 감출 수 있는 갈래 · `empty_gone` = 설정과 상관없이
    0 이면 사라지는 갈래.
    ⚠ **주요용어는 `empty_gone` 을 비워서 부른다** — 거기서는 0건 규칙을
      **다섯 갈래에 똑같이** 건다(2026-09-17 사용자 지적 「일관성이 맞는가」).
    """
    if not base:
        return False
    # ★ 찬양은 설정과 상관없이 곡이 0 이면 감춘다 — 그것이 그 갈래의 뜻이다.
    if key in (empty_gone or ()):
        return bool(count)
    if not hide_empty or key not in (hideable or HIDEABLE) or count is None:
        return True
    return bool(count)


def read_more(db_path, key):
    """더보기 표시방식 → 'TABS' | 'ONE'."""
    try:
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (key,)).fetchone()
        v = (r[0] if r else '') or ''
    except Exception:
        v = ''
    return v if v in {m for m, _i, _k in MORE_MODES} else MORE_DEFAULT


def write_more(db_path, key, mode):
    if mode not in {m for m, _i, _k in MORE_MODES}:
        mode = MORE_DEFAULT
    with appdb.connect(db_path) as c:
        c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                  "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                  (key, mode))
        c.commit()
    return mode


def normalize(keys, order, default, fixed=None, pair=None):
    """읽는 쪽과 같은 규칙 — 차례 유지 · 짝 맞춤 · **필수** · 비면 기본값.

    ⚠ 필수·짝은 **화면마다 다르다**(`fixed_of`·`pair_of`) — 안 넘기면 P2 규칙.
    """
    fixed = FIXED if fixed is None else fixed
    pair = PAIR if pair is None else pair
    ks = [k for k in order if k in set(keys)]
    if len(pair) == 2 and (pair[0] in ks) != (pair[1] in ks):
        ks = [k for k in order if k in set(ks) | set(pair)]
    ks = [k for k in order if k in set(ks) | (set(fixed) & set(order))]
    return tuple(ks) if ks else tuple(default)


def read_main(db_path, cfg_key, order, default):
    try:
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (cfg_key,)).fetchone()
        raw = [x.strip().upper() for x in (r[0] if r and r[0] else '').split(',')]
    except Exception:
        raw = []
    return (normalize(raw, order, default, fixed_of(cfg_key), pair_of(cfg_key))
            if any(raw) else tuple(default))


def write_main(db_path, cfg_key, keys):
    with appdb.connect(db_path) as c:
        c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                  "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                  (cfg_key, ','.join(keys)))
        c.commit()


class TabSettingsWin(tk.Toplevel):
    """`open(parent, db_path, apply_cb)` 로 연다. `apply_cb(cfg_key, keys)` 가 화면에 반영한다."""

    def __init__(self, parent, db_path, apply_cb=None):
        super().__init__(parent)
        self.db_path = db_path
        self.apply_cb = apply_cb
        self.title(i18n.t('P2TS_TITLE', '탭 설정'))
        self.transient(parent)
        self._vars = {}
        self._more = {}
        self._hide = {}
        try:
            import ui_theme
            ui_theme.adopt(self)
            _fk = ui_theme.flat_btn()
        except Exception:
            _fk = dict(bd=0, padx=8, cursor='hand2')
        top = tk.Frame(self)
        top.pack(fill='x', padx=10, pady=(10, 4))
        # ★★ **단추는 [저장]·[초기화] 둘** (2026-09-17 사용자) — 옛 [적용]을
        #   걷었다. 닫는 것이 곧 저장이라 「눌렀는데 안 먹었다」가 없다.
        tk.Button(top, text=i18n.t('COMMON_SAVE', '저장'), command=self._save,
                  **_fk).pack(side='left')
        tk.Button(top, text=i18n.t('COMMON_RESET', '초기화'), command=self._reset,
                  **_fk).pack(side='left', padx=(6, 0))
        # ⚠ 창 [X] 도 같은 문 — 닫는 길이 둘인데 하나만 저장하면 조용히 잃는다
        self.protocol('WM_DELETE_WINDOW', self._save)
        self._msg = tk.Label(top, text='', anchor='w')
        self._msg.pack(side='left', padx=(12, 0), fill='x', expand=True)
        hint = tk.Label(self, anchor='w', justify='left', wraplength=520,
                        text=i18n.t('P2TS_HINT',
                                    '체크한 갈래는 윗줄(주 탭)에, 나머지는 「더보기」 안에 들어갑니다. '
                                    '연구자료와 내부연결은 함께 움직입니다. 적용하면 바로 반영됩니다.'))
        hint.pack(fill='x', padx=12, pady=(0, 6))
        cols = tk.Frame(self)
        cols.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        for cfg_key, order, default, i18n_key, dflt in SCREENS:
            lf = ttk.LabelFrame(cols, text=i18n.t(i18n_key, dflt))
            lf.pack(side='left', fill='both', expand=True, padx=4)
            cur = set(read_main(db_path, cfg_key, order, default))
            self._vars[cfg_key] = {}
            _lab = LABELS_EB if cfg_key == 'EB_MAIN_TABS' else LABELS
            for k in order:
                fixed = k in fixed_of(cfg_key)
                v = tk.IntVar(value=1 if (fixed or k in cur) else 0)
                self._vars[cfg_key][k] = v
                nm = i18n.t(_lab[k][0], _lab[k][1])
                if fixed:
                    nm += ' ' + i18n.t('P2TS_FIXED', '(필수)')
                cb = tk.Checkbutton(lf, variable=v, anchor='w', text=nm,
                                    command=lambda ck=cfg_key, kk=k: self._on_toggle(ck, kk))
                # ★ 필수 셋은 못 뺀다 — 뺄 수 있게 두면 통합탭 규칙이 무너진다
                if fixed:
                    cb.config(state='disabled')
                cb.pack(fill='x', padx=8, pady=1)
            # ── 더보기 표시방식 ──────────────────────────────────────
            mf = ttk.LabelFrame(lf, text=i18n.t('P2TS_MORE', '더보기 표시방식'))
            mf.pack(fill='x', padx=6, pady=(8, 4))
            mv = tk.StringVar(value=read_more(db_path, MORE_KEY[cfg_key]))
            self._more[cfg_key] = mv
            for code, ik, ko in MORE_MODES:
                tk.Radiobutton(mf, text=i18n.t(ik, ko), value=code,
                               variable=mv, anchor='w').pack(fill='x',
                                                             padx=8, pady=1)
            # ★ 빈 갈래 감추기 — 표시방식과 **다른 축**이라 따로 둔다
            hv = tk.IntVar(value=1 if read_hide_empty(
                db_path, HIDE_EMPTY_KEY[cfg_key]) else 0)
            self._hide[cfg_key] = hv
            tk.Checkbutton(lf, variable=hv, anchor='w',
                           text=i18n.t('P2TS_HIDE_EMPTY',
                                       '목록이 없는 갈래는 감추기')
                           ).pack(fill='x', padx=8, pady=(6, 1))
            tk.Label(lf, anchor='w', justify='left', wraplength=230,
                     fg='#5D6D7E',
                     text=i18n.t('P2TS_HIDE_EMPTY_HINT2',
                                 '필수 갈래는 언제나 보입니다.')
                     ).pack(fill='x', padx=8, pady=(0, 4))
            # ⚠ 안내 글은 화면마다 다르다 — 필수 갈래 이름이 다르기 때문이다
            tk.Label(mf, anchor='w', justify='left', wraplength=230,
                     text=i18n.t('P2TS_EB_HINT',
                                 '통합탭 = 선택 갈래를 모두 「더보기」 한 목록으로. '
                                 '서브탭 = 체크한 것은 제 탭, 체크를 푼 것만 더보기. '
                                 '「구분」 칸에 어느 탭에서 온 줄인지 적습니다.')
                     if cfg_key == 'EB_MAIN_TABS' else
                     i18n.t('P2TS_MORE_HINT',
                            '통합탭 = 더보기 갈래를 한 목록으로 보이고 '
                            '「구분」 칸에 어느 탭에서 온 줄인지 적습니다. '
                            '설명·주석·묵상노트는 합치지 않습니다.')
                     ).pack(fill='x', padx=8, pady=(2, 4))
        try:
            import theme_font
            for w in self._all_widgets(self):
                if isinstance(w, (tk.Label, tk.Button, tk.Checkbutton)):
                    theme_font.register(w, db_path, 'ui')
        except Exception:
            pass
        try:
            import ui_theme
            ui_theme.paint(self)
        except Exception:
            pass
        self.update_idletasks()
        self.minsize(self.winfo_reqwidth(), self.winfo_reqheight())

    @staticmethod
    def _all_widgets(w):
        out = [w]
        for c in w.winfo_children():
            out.extend(TabSettingsWin._all_widgets(c))
        return out

    def _on_toggle(self, cfg_key, key):
        """짝은 함께 움직인다 — 체크하는 순간 눈에 보이게."""
        pair = pair_of(cfg_key)
        if len(pair) == 2 and key in pair:
            other = pair[1] if key == pair[0] else pair[0]
            v = self._vars[cfg_key]
            if other in v:
                v[other].set(v[key].get())

    def _chosen(self, cfg_key):
        order = next(o for ck, o, _d, _i, _l in SCREENS if ck == cfg_key)
        default = next(d for ck, _o, d, _i, _l in SCREENS if ck == cfg_key)
        picked = [k for k in order if self._vars[cfg_key][k].get()]
        return normalize(picked, order, default,
                         fixed_of(cfg_key), pair_of(cfg_key))

    def _save(self):
        """저장하고 화면에 반영하고 **닫는다** — 닫기가 곧 저장이다."""
        self._apply()
        try:
            self.destroy()
        except Exception:
            pass

    def _apply(self):
        done = []
        for cfg_key, order, default, _i, _l in SCREENS:
            keys = self._chosen(cfg_key)
            for k in order:                       # 규칙이 고친 값을 화면에도 되비춘다
                self._vars[cfg_key][k].set(1 if k in keys else 0)
            try:
                write_main(self.db_path, cfg_key, keys)
                # ★ 더보기 표시방식도 함께 — 고르는 곳이 하나라야 안 갈린다
                mv = self._more.get(cfg_key)
                if mv is not None:
                    write_more(self.db_path, MORE_KEY[cfg_key], mv.get())
                hv = self._hide.get(cfg_key)
                if hv is not None:
                    write_hide_empty(self.db_path, HIDE_EMPTY_KEY[cfg_key],
                                     bool(hv.get()))
            except Exception as e:
                self._msg.config(text=str(e))
                return
            if callable(self.apply_cb):
                try:
                    self.apply_cb(cfg_key, keys)
                except Exception as e:
                    print('[tab settings apply] %s' % e)
            done.append(len(keys))
        self._msg.config(text=i18n.t('P2TS_APPLIED', '적용했습니다'))

    def _reset(self):
        for cfg_key, order, default, _i, _l in SCREENS:
            for k in order:
                self._vars[cfg_key][k].set(
                    1 if (k in default or k in fixed_of(cfg_key)) else 0)


def open_win(parent, db_path, apply_cb=None):
    w = TabSettingsWin(parent, db_path, apply_cb)
    try:
        w.grab_set()
    except Exception:
        pass
    return w


def _selftest():
    ok = []
    _by = {sc[0]: sc for sc in SCREENS}      # ⚠ 자리 번호가 아니라 열쇠로(2026-10-13 P2 줄을 걷었다)
    o = _by['P4_NODE_MAIN_TABS'][1]; d = _by['P4_NODE_MAIN_TABS'][2]
    # ★ 2026-09-17 — `normalize` 규칙이 바뀌었다: **필수 셋(FIXED)은 뺄 수 없다.**
    #   옛 시험은 「고른 것만 남는다」를 재고 있었다(그때는 필수가 없었다).
    ok.append(('차례 유지', normalize(['VIDEO', 'DESC'], o, d)
               == ('DESC', 'COMM', 'NOTE', 'VIDEO')))
    ok.append(('★ 필수 셋은 안 선택해도 든다',
               set(FIXED) <= set(normalize(['VIDEO'], o, d))))
    ok.append(('★ 필수 셋은 빼도 안 빠진다',
               set(FIXED) <= set(normalize(['VIDEO', 'TEXT'], o, d))))
    ok.append(('짝 — 연구자료만 선택하면 내부연결이 따라온다',
               normalize(['DESC', 'REFR'], o, d)
               == ('DESC', 'COMM', 'NOTE', 'REFR', 'NAV')))
    ok.append(('짝 — 내부연결만 선택해도',
               normalize(['NAV'], o, d) == ('DESC', 'COMM', 'NOTE', 'REFR', 'NAV')))
    ok.append(('비면 기본값(필수가 없을 때)', normalize([], o, d, fixed=()) == d))
    ok.append(('★ P2 줄은 없다(설명·묵상노트 고정)', 'P2_MAIN_TABS' not in _by))
    ok.append(('모르는 열쇠는 버린다',
               normalize(['DESC', 'XX'], o, d) == ('DESC', 'COMM', 'NOTE')))
    # 오른쪽 패널에도 같은 규칙이 걸린다(구절단락은 필수가 아니다)
    o2 = _by['P4_NODE_MAIN_TABS'][1]; d2 = _by['P4_NODE_MAIN_TABS'][2]
    ok.append(('★ 오른쪽 패널도 필수 셋',
               set(FIXED) <= set(normalize(['VIDEO'], o2, d2))))
    ok.append(('  구절단락은 필수가 아니다', 'PERI' not in normalize(['VIDEO'], o2, d2)))
    # 더보기 표시방식 — 표가 단일 소스인가
    modes = {m for m, _i, _k in MORE_MODES}
    ok.append(('★ 더보기 표시방식 둘', modes == {'TABS', 'ONE'}))
    ok.append(('  기본은 서브탭', MORE_DEFAULT == 'TABS'))
    ok.append(('  화면마다 열쇠가 다르다',
               set(MORE_KEY) == {k for k, _o, _d, _i, _l in SCREENS}
               and len(set(MORE_KEY.values())) == len(SCREENS)))
    # ── 주요용어(P4) — 2026-09-17 사용자가 정한 필수·선택 ────────────────
    o3 = _by['EB_MAIN_TABS'][1]; d3 = _by['EB_MAIN_TABS'][2]
    ok.append(('★★ 주요용어 화면이 있다', 'EB_MAIN_TABS' in _by))
    ok.append(('★★ 필수 = 용어사전·용례구절',
               fixed_of('EB_MAIN_TABS') == ('DICT', 'LINK')))
    ok.append(('★★ 여정은 목록에 없다', 'JOURNEY' not in o3))
    ok.append(('★ 필수 둘은 안 선택해도 든다',
               set(('DICT', 'LINK')) <= set(normalize(
                   ['SONG'], o3, d3, fixed_of('EB_MAIN_TABS'),
                   pair_of('EB_MAIN_TABS')))))
    ok.append(('★ 짝 규칙이 없다 — 연구자료만 선택해도 내부연결이 안 따라온다',
               'NAV' not in normalize(['STUDY'], o3, d3,
                                      fixed_of('EB_MAIN_TABS'),
                                      pair_of('EB_MAIN_TABS'))))
    ok.append(('★ 감출 수 있는 것 = 선택 다섯',
               hideable_of('EB_MAIN_TABS')
               == ('VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG')))
    ok.append(('★★ 0건 규칙이 다섯에 똑같이 걸린다',
               all(visible_with(k, 0, True, True,
                                hideable_of('EB_MAIN_TABS'), ()) is False
                   for k in hideable_of('EB_MAIN_TABS'))))
    ok.append(('★★ 감추기를 끄면 다섯 다 보인다(잠글 뿐)',
               all(visible_with(k, 0, True, False,
                                hideable_of('EB_MAIN_TABS'), ()) is True
                   for k in hideable_of('EB_MAIN_TABS'))))
    ok.append(('★ 필수 둘은 0건이어도 안 감춘다',
               visible_with('DICT', 0, True, True,
                            hideable_of('EB_MAIN_TABS'), ()) is True
               and visible_with('LINK', 0, True, True,
                                hideable_of('EB_MAIN_TABS'), ()) is True))
    ok.append(('★ P2 는 그대로 — 찬양만 설정과 무관하게 0 이면 감춘다',
               visible_with('SONG', 0, True, False) is False
               and visible_with('VIDEO', 0, True, False) is True))
    ok.append(('★ 주요용어 이름표가 그 화면 열쇠를 쓴다',
               LABELS_EB['DICT'][0] == 'TAB_TERMDICT'
               and LABELS_EB['LINK'][0] == 'TAB_ENTITY_LINKVERSE'))
    for name, passed in ok:
        print(('  OK ' if passed else '  FAIL ') + name)
    print('p2_tab_settings selftest: %d/%d' % (sum(1 for _n, p in ok if p), len(ok)))
    return 0 if all(p for _n, p in ok) else 1


if __name__ == '__main__':
    import sys
    sys.exit(_selftest())
