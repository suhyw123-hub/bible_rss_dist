# -*- coding: utf-8 -*-
"""tray_agent.py — 초소형 상주 에이전트 (2026-09-03 190차 신설·영구).

★★★ 왜 (사용자 확정 설계):
  본체를 켜 둔 채 두는 것이 아니라 **완전히 끄고**, 트레이에 아주 작은 것만
  남겨 공지·링크 팩을 받아 둔다. 다음에 앱을 켜면 이미 도착해 있다.

설계 원칙 (전부 사용자 확정):
  · **앱을 import 하지 않는다** — user_main 을 부르면 Tk·DB·화면이 통째로
    따라온다. 여기는 표준 라이브러리 + rss/pack 모듈만 쓴다(실측 기동 <0.1s).
  · **외부 의존성 금지** — pystray·pillow 안 쓴다. ctypes 로 Shell_NotifyIcon
    을 직접 부른다(윈도우 기본 API).
  · **본체가 닫혀 있을 때만 동작** — 잠금 파일(`tray_agent.lock` 아님, 본체
    실행 표식)로 감지. 동시에 DB 를 만지지 않는다.
  · **수신 전용** — 송신(통계·보고)은 앱이 살아 있을 때. 여기서는 안 한다.

⚠ 이 파일은 **본체와 같은 폴더**에서 돈다(DB·팩 경로가 그 규약이다).

    python tray_agent.py --selftest     (의무 · 창을 안 띄운다)
    python tray_agent.py                (상주 시작)
    python tray_agent.py --once         (한 번만 확인하고 끝 — 시험용)
"""
import io
import os
import sys
import time

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

HERE = os.path.dirname(os.path.abspath(__file__))
RUNNING_MARK = os.path.join(HERE, '.app_running')
#: 판정을 얼마나 자주 **물어보나**(받는 주기가 아니다 — 실제 수신 여부는
#  `sync_schedule.should_fetch` 가 정한다). 1분마다 물어도 값은 거의 늘 False 다.
TICK_SEC = 60
#: 옛 이름 — 밖에서 쓰지 않는다(2026-09-03 `sync_schedule` 로 이관).
POLL_SEC = 60 * 60 * 24
NAME = 'Hagah Dabar'


# ── 본체 실행 표식 ────────────────────────────────────────────────────
def app_running():
    """본체가 떠 있나 — **표식 파일 + 나이**로 본다.

    ⚠ 파일 존재만 보면 앱이 비정상 종료했을 때 영원히 「실행 중」이 된다.
      본체가 주기적으로 표식을 만지므로(mark_running) **오래된 표식은
      죽은 것으로 본다**.
    """
    try:
        if not os.path.exists(RUNNING_MARK):
            return False
        return (time.time() - os.path.getmtime(RUNNING_MARK)) < 600
    except Exception:
        return False


def mark_running():
    """본체가 부른다 — 살아 있음을 알린다(멱등)."""
    try:
        with open(RUNNING_MARK, 'w', encoding='utf-8') as f:
            f.write(str(int(time.time())))
        return True
    except Exception:
        return False


def clear_running():
    try:
        if os.path.exists(RUNNING_MARK):
            os.remove(RUNNING_MARK)
        return True
    except Exception:
        return False


# ── 언제 받을까 ──────────────────────────────────────────────────────
def _due(started_at, db_path='bible_master.db'):
    """지금 받을 차례인가 — 판정은 `sync_schedule` 이 한다.

    ⚠ 판정 자체가 실패하면 **받는 쪽으로 기울인다** — 못 받는 것보다 한 번 더
      받는 편이 안전하다(자료를 놓치면 화면이 비고, 한 번 더 받아도 304 다).
    """
    try:
        import appdb
        import sync_schedule as SS
        with appdb.connect(db_path) as conn:
            go, why = SS.should_fetch(conn, started_at)
        return go
    except Exception as e:
        print('[tray] 주기 판정 실패 — 받는 쪽으로: %s' % e)
        return True


def _note_result(ok, db_path='bible_master.db'):
    """성공/실패를 적어 다음 차례와 백오프를 정하게 한다."""
    try:
        import appdb
        import sync_schedule as SS
        with appdb.connect(db_path) as conn:
            (SS.mark_ok if ok else SS.mark_fail)(conn)
    except Exception:
        pass


# ── 수신 ─────────────────────────────────────────────────────────────
def check_once(db_path='bible_master.db'):
    """공지·링크 팩을 한 번 확인 → dict(ann, pack, skipped).

    ⚠ **본체가 떠 있으면 아무것도 안 한다**(동시 쓰기 금지) — 건너뛴 것을
      알리고 다음 차례에 다시 본다.
    """
    res = {'ann': 0, 'pack': 0, 'models': 0, 'skipped': False, 'msg': ''}
    if app_running():
        res['skipped'] = True
        res['msg'] = '본체 실행 중 — 건너뜀'
        return res
    # 공지 — 이미 있는 동기화 문을 그대로 쓴다(새 인프라 0)
    try:
        import appdb
        import rss_reader as R
        import rss_transport as RT
        with appdb.connect(db_path) as conn:
            r = R.sync_announcements(conn, RT.client_servers())
            res['ann'] = int(r.get('applied') or 0)
            res['msg'] = r.get('message') or r.get('status') or ''
    except Exception as e:
        res['msg'] = '공지 실패: %s' % e
    # ★★★ AI 모델 목록 — 공지와 같은 자리다(2026-09-29 299차-3).
    #   ⚠ **자동설정 스위치 앞이다** — 그 스위치가 정하는 것은 **자료**(팩)이고
    #     이것은 설정값이다. 끊으면 회사가 판을 물린 날 그 사용자만 404 를 본다.
    #   ⚠⚠ 실패해도 **한 바퀴를 실패로 만들지 않는다** — 아래 판정이 `실패`
    #     글자를 보므로 여기서는 「오류」라 적는다. 곁다리 파일 하나 때문에
    #     팩 받기가 백오프에 걸리면 안 된다.
    try:
        import appdb
        import rss_reader as R
        import rss_transport as RT
        with appdb.connect(db_path) as conn:
            m = R.sync_aimodels(conn, RT.client_servers())
            res['models'] = int(m.get('applied') or 0)
            if m.get('status') == 'UPDATED':
                res['msg'] += ' · AI 모델 ' + (m.get('message') or '')
            # ★ 2026-10-24 앱이 받는 채널 번호 — 「내가 모은 채널」에서 겹치는 것은 제 받기를 멈춘다
            try:
                R.sync_app_channels(conn, RT.client_servers())
            except Exception:                                     # noqa: BLE001
                pass
            # ★ 2026-10-23 추천몰(shop.json) — 같은 날마다 길(설정값처럼 자료 스위치를 안 탄다)
            try:
                s_ = R.sync_shop(conn, RT.client_servers())
                if s_.get('status') == 'UPDATED':
                    res['msg'] += ' · 추천몰 ' + (s_.get('message') or '')
            except Exception as e:                                # noqa: BLE001
                res['msg'] += ' · 추천몰 오류: %s' % str(e)[:40]
    except Exception as e:
        res['msg'] += ' · AI 목록 오류: %s' % str(e)[:40]
    # ★ 「+Hagah」 재생목록(2026-10-11) — 사용자가 유튜브 「저장」으로 모은 영상을 내 영상으로.
    #   자료 자동받기 스위치와 무관하다(사용자 자기 자료다) · 실패해도 한 바퀴를 실패로 만들지 않는다.
    try:
        import yt_intake as _YT
        m = _YT.playlist_tick(db_path)
        if m:
            res['msg'] += ' · 재생목록: ' + m
    except Exception as e:
        res['msg'] += ' · 재생목록 오류: %s' % str(e)[:40]
    # 링크 팩 — 커서 이후 델타(정적 파일)
    ok = True
    if not auto_sync_on(db_path):
        # ★ **꺼 두면 자료를 안 받는다**(2026-09-06 사용자 5-1 「자동설정」).
        #   ⚠ 공지는 그대로 받는다 — 자동설정이 정하는 것은 **자료**이고,
        #     공지를 끊으면 사용자가 안내를 못 본다(축이 다르다).
        res['pack'] = 0
        res['msg'] += ' · 자료 자동받기 꺼짐'
    else:
        try:
            res['pack'] = fetch_pack_deltas()
        except Exception as e:
            ok = False
            res['msg'] += ' · 팩 실패: %s' % e
        # ★★★ **본문팩 갱신** (2026-09-07) — 그전에는 자동으로 오는 것이
        #   **링크 팩뿐**이라, 성경 본문·주석·도서를 받아 둔 사람도 새 판이
        #   나오면 손으로 받아야 했다(자동설정 동의문이 그 사실을 적고 있었다).
        #   ★ **갱신만 한다 — 새 자산은 안 받는다.** 「자동 최신화」의 뜻은
        #     갖고 있는 것을 최신으로이지, 전량 157MB 를 묻지도 않고
        #     내려받는 것이 아니다. 새것은 사람이 [항목별]에서 고른다.
        #   ⚠ 한 번에 세 개까지 — 하루 한 번 도므로 며칠에 걸쳐 따라잡는다.
        try:
            import pack_status as _PS
            up = _PS.fetch_asset_updates(db_path)
            res['assets'] = len(up.get('got') or [])
            res['assets_left'] = int(up.get('left') or 0)
            if res['assets']:
                res['msg'] += ' · 자료 갱신 %d개' % res['assets']
                if res['assets_left']:
                    res['msg'] += '(남은 것 %d)' % res['assets_left']
            elif up.get('why'):
                # ⚠ **왜 0건인지 남긴다** — 「판 기록 없음」·「서버 목록 없음」·
                #   「언어 안 맞음」은 뜻이 전혀 다르다(§0-1).
                res['msg'] += ' · 자료 갱신 없음(%s)' % up['why']
        except Exception as e:
            # ⚠ **링크 팩까지 실패로 만들지 않는다** — 본문팩은 덤이다
            res['msg'] += ' · 자료 갱신 실패: %s' % str(e)[:40]
    # ★ 결과를 적는다 — 성공하면 다음 차례가 하루 뒤로, 실패하면 백오프.
    #   ⚠ 서버에 못 닿은 것도 실패다(공지 쪽 message 로 가른다).
    if '실패' in (res.get('msg') or '') or 'NO_SERVER' in (res.get('msg') or ''):
        ok = False
    _note_result(ok, db_path)
    return res


#: 자동 최신화 스위치 — 사용자 설정 ▸ 다운로드 ▸ [자동설정] 이 정한다.
AUTO_SYNC_KEY = 'PACK_AUTO_SYNC'


def auto_sync_on(db_path='bible_master.db'):
    """자료를 저절로 받을까. **기본은 켬** — 안 켜 두면 자료가 낡는다.

    ★ 값의 집은 `user_config` 하나다(화면과 트레이가 같은 것을 읽는다).
    ⚠ **못 읽으면 켠 것으로 본다** — 못 읽었다고 안 받으면 사용자는 왜 안
      받아지는지 알 길이 없다(§0-1 조용한 실패보다 낫다).
    """
    try:
        import appdb
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config"
                          " WHERE config_key=?", (AUTO_SYNC_KEY,)).fetchone()
        return (r[0] != '0') if r else True
    except Exception:
        return True


def fetch_pack_deltas(max_chain=None, db_path='bible_master.db'):
    """커서 이후 델타를 차례로 받아 적용 → 적용 건수.

    ⚠ 빈 구간이 너무 크면(MAX_CHAIN) **전체본으로 갈아탄다** — 오래 안 켠
      사용자가 델타 수백 개를 받는 것을 막는다.
    ⚠⚠ **본체 연결을 반드시 넘긴다**(2026-09-03 종단간 점검에서 검거) —
      델타의 연결은 **자연 열쇠**(`target_code`·`target_peri`)로 오는데,
      `main` 이 없으면 해석할 곳이 없어 **연결이 통째로 보류**된다. 그러면
      미디어만 들어가고 **화면에는 아무것도 안 뜬다**(커서는 전진하므로
      다시 받지도 않는다 — 조용히 비어 버리는 자리였다).
    """
    import json
    import sqlite3

    import appdb
    import db_linkpack_sync as SYNC
    import link_pack
    import rss_transport as RT
    max_chain = max_chain or SYNC.MAX_CHAIN
    p = link_pack.ensure()
    cur = link_pack.cursor(p)
    pack = sqlite3.connect(p)
    main = None
    try:
        main = appdb.connect(db_path)     # 자연 열쇠 해석용(본체는 꺼져 있다)
    except Exception as e:
        print('[tray] 본체 DB 를 못 열었다 — 연결 해석 없이 진행: %s' % e)
    applied = 0
    try:
        # ★★★ **얼마나 밀렸는지 먼저 안다**(2026-09-03 · manifest).
        #   그전에는 델타를 하나씩 받아 보며 404 가 날 때까지 두드렸고,
        #   1년을 안 켠 사용자는 **델타 30개를 받아 적용한 뒤 전체본까지 또
        #   받아 31회**를 내려받았다. 이제 manifest(수백 바이트) 한 번으로
        #   「델타 n개」냐 「전체본 하나」냐가 갈린다.
        #   ⚠ manifest 가 없는 옛 배포에서는 그전 방식으로 물러선다.
        behind = None
        mtxt = _download(RT.client_servers(), SYNC.MANIFEST_NAME)
        if mtxt:
            try:
                behind = int(json.loads(mtxt).get('latest', 0)) - cur
            except Exception:
                behind = None
        if behind is not None and behind <= 0:
            # ⚠⚠ **팩이 비어 있으면 커서가 같아도 전체본을 받는다** — 전체본은
            #   시퀀스를 안 먹으므로 「전체본만 발행한 첫 배포」는 latest 가 0
            #   이고, 새 설치자도 커서 0 이라 `behind=0` 이 된다. 그대로 두면
            #   **아무것도 안 받고 영영 빈 팩**이다(실측으로 잡았다).
            empty = pack.execute(
                "SELECT COUNT(*) FROM pack_media").fetchone()[0] == 0
            if not empty:
                return 0                  # 이미 최신 — 더 받을 것이 없다
            txt = _download(RT.client_servers(), SYNC.FULL_NAME)
            if txt is None:
                return 0
            r = SYNC.apply_full(pack, json.loads(txt), main=main)
            return 1 if r.get('status') == 'OK' else 0
        if behind is not None and behind > max_chain:
            # ★ 링크 자산은 **놓치면 안 되므로** 전체본으로 간다 — 전체본은
            #   그 시점의 승인분 **전부**라 빠지는 것이 없다(사용자 확인
            #   「링크자산은 놓치지 않고 다 받아야 효과적이다」).
            txt = _download(RT.client_servers(), SYNC.FULL_NAME)
            if txt is not None:
                r = SYNC.apply_full(pack, json.loads(txt), main=main)
                return 1 if r.get('status') == 'OK' else 0
            behind = max_chain            # 전체본을 못 받았으면 델타로라도
        got = 0
        limit = max_chain if behind is None else min(behind, max_chain)
        for i in range(1, limit + 1):
            name = SYNC.DELTA_NAME % (cur + i)
            txt = _download(RT.client_servers(), name)
            if txt is None:
                # ⚠⚠ **구멍을 만나면 전체본으로 간다**(2026-09-03) — manifest 가
                #   「최신은 여기까지」라 했는데 그 사이 델타가 없으면(발행이
                #   어긋났거나 파일이 빠졌으면) 여기서 멈출 뿐 커서가 안 올라
                #   **영영 최신이 못 된다.** 전체본은 언제나 참이므로 그리로.
                if behind is not None and i <= behind:
                    ftxt = _download(RT.client_servers(), SYNC.FULL_NAME)
                    if ftxt is not None:
                        r = SYNC.apply_full(pack, json.loads(ftxt), main=main)
                        if r.get('status') == 'OK':
                            applied += 1
                break                     # 더 없다 — 여기까지가 최신
            r = SYNC.apply_delta(pack, json.loads(txt), main=main)
            if r['status'] not in ('OK', 'ALREADY'):
                break                     # 어긋나면 멈춘다(커서는 안 옮겼다)
            applied += 1
            got += 1
        # manifest 가 없던 옛 경로 — 30개를 다 받았으면 더 있을 수 있다
        if behind is None and got >= max_chain:
            txt = _download(RT.client_servers(), SYNC.FULL_NAME)
            if txt is not None:
                SYNC.apply_full(pack, json.loads(txt), main=main)
    finally:
        pack.close()
        if main is not None:
            try:
                link_pack.detach(main)
            except Exception:
                pass
            main.close()
    return applied


def _download(servers, name):
    """정적 파일 하나 — 미러를 차례로(주=CDN·백업=raw). 없으면 None."""
    import urllib.request
    for s in servers or []:
        if not s.get('enabled', True):
            continue
        base = (s.get('location') or '').rstrip('/')
        if not base.startswith('http'):
            # 로컬 폴더 시뮬레이션(테스트)
            fp = os.path.join(base, name)
            if os.path.exists(fp):
                return open(fp, encoding='utf-8').read()
            continue
        try:
            req = urllib.request.Request(
                base + '/' + name, headers={'User-Agent': 'BibleMatrix-Tray/1.0'})
            with urllib.request.urlopen(req, timeout=20) as f:
                return f.read().decode('utf-8')
        except Exception:
            continue
    return None


def download_bytes(servers, name):
    """정적 파일 하나를 **바이트 그대로** — 미러 차례. 없으면 None.

    ⚠ `_download` 는 `utf-8` 로 풀어 돌려준다 — **gzip 팩은 그것으로 못
      받는다**(글자가 아니다). 본문팩·코어팩은 이 문을 쓴다.
    """
    import urllib.request
    for s in servers or []:
        if not s.get('enabled', True):
            continue
        base = (s.get('location') or '').rstrip('/')
        if not base.startswith('http'):
            fp = os.path.join(base, name)
            if os.path.exists(fp):
                with open(fp, 'rb') as f:
                    return f.read()
            continue
        try:
            req = urllib.request.Request(
                base + '/' + name,
                headers={'User-Agent': 'BibleMatrix-Tray/1.0'})
            with urllib.request.urlopen(req, timeout=60) as f:
                return f.read()
        except Exception:
            continue
    return None


# ── 트레이 아이콘 (ctypes · 외부 의존성 0) ───────────────────────────
#: 트레이 창 클래스 이름 — **한 곳에서 정한다**(찾는 쪽·만드는 쪽이 공유).
TRAY_CLASS = 'BibleMatrixTray'

#: 단일 인스턴스 뮤텍스. ⚠ `Local\\` — 세션 안에서만 유일하면 된다
#: (`Global\\` 은 다른 사용자 계정까지 막아 원격 데스크톱에서 문제가 된다).
TRAY_MUTEX = 'Local\\BibleMatrixTrayAgent'

_MUTEX_HANDLE = None            # ⚠ 살려 둬야 한다 — GC 되면 뮤텍스가 풀린다


def single_instance():
    """트레이가 **나 하나뿐인가** → True/False.

    ★★★ 왜 (2026-09-05 사용자 신고 「지금 우리 앱의 트래이가 여러개 표시되고
      있다. 하나만 표시되어야 하는 것 아닌가?」 — **맞다. 버그였다**).
      실측 — 트레이 창이 **6개** 떠 있었고 `CreateMutex` 사용이 **0회**였다.
      앱을 껐다 켤 때마다 새 트레이가 뜨고 옛것이 안 죽어 쌓인 것이다.
    ⚠ 뮤텍스 핸들을 **전역에 붙들어 둔다** — 지역 변수면 함수가 끝날 때
      풀려서 아무것도 못 막는다.
    ⚠ 윈도우가 아니면 True(막을 것이 없다).
    """
    global _MUTEX_HANDLE
    if os.name != 'nt':
        return True
    try:
        import ctypes
        import ctypes.wintypes as wt
        k = ctypes.windll.kernel32
        k.CreateMutexW.argtypes = [ctypes.c_void_p, wt.BOOL, wt.LPCWSTR]
        k.CreateMutexW.restype = wt.HANDLE
        # ⚠ **시험은 제 뮤텍스를 쓴다** — 사용자가 켜 둔 트레이 때문에
        #   selftest 가 실패하면 안 되고, 시험이 그것을 죽여도 안 된다.
        h = k.CreateMutexW(None, True,
                           TRAY_MUTEX + (os.environ.get('BM_TRAY_TEST') or ''))
        if k.GetLastError() == 183:            # ERROR_ALREADY_EXISTS
            # ⚠⚠ **이 손잡이를 닫는다**(2026-10-09) — 안 닫으면 잠금이 **내 손잡이 때문에**
            #   계속 「있음」으로 남아, 옛 트레이가 끝난 뒤에도 다시 잡을 수 없었다
            #   (새 트레이가 20초 기다리다 물러나 트레이가 사라졌다).
            try:
                k.CloseHandle.argtypes = [wt.HANDLE]
                k.CloseHandle(h)
            except Exception:
                pass
            return False
        _MUTEX_HANDLE = h
        return True
    except Exception:
        return True                            # 못 재면 막지 않는다


# ── 트레이가 어떤 판의 코드로 켜졌나 (2026-10-09) ─────────────────────────
# ★★ 사용자 신고 「트래이앱을 좌 클릭했다. 아무 반응 없다」 — 떠 있던 트레이가
#   **사흘 전에 켜진 옛 판**이었다. 앱을 닫을 때 트레이가 이미 떠 있으면 새로
#   안 띄우므로(중복 방지) **코드가 바뀌어도 PC 를 다시 켤 때까지 옛 판이 남는다**
#   — 업데이트한 사용자 PC 에서도 똑같이 난다.
#   ⇒ 트레이가 켜질 때 판(앱 폴더 .py 의 가장 늦은 고친 때)을 적고, 앱이 켜지거나
#     닫힐 때 그보다 새 코드가 있으면 옛 트레이를 닫고 새로 띄운다.
SIG_FILE = os.path.join(HERE, '.tray_sig')


def code_sig():
    """앱 폴더 파이썬 파일의 가장 늦은 고친 때(초)."""
    best = 0.0
    try:
        for n in os.listdir(HERE):
            if n.endswith('.py'):
                try:
                    best = max(best, os.path.getmtime(os.path.join(HERE, n)))
                except OSError:
                    pass
    except OSError:
        pass
    return best


def write_sig():
    try:
        with open(SIG_FILE, 'w', encoding='utf-8') as f:
            f.write('%d %.0f' % (os.getpid(), code_sig()))
        return True
    except Exception:
        return False


def tray_stale():
    """떠 있는 트레이가 옛 판인가 → True/False. 기록이 없으면 옛 판(기록하기 전 판)."""
    try:
        with open(SIG_FILE, encoding='utf-8') as f:
            sig = float(f.read().split()[1])
    except Exception:
        return True
    return code_sig() > sig + 1


def launch(replace=False):
    """트레이를 띄운다(창 없이) → True/False.

    `replace=True` = **새 트레이가 스스로** 옛 트레이를 닫고 그것이 꺼지기를 기다린다
    (`--replace`). 띄우는 쪽(앱)은 기다리지 않는다 — 2026-10-09 사용자 「닫으려고 하면 매우
    반응이 늦다」: 앱이 닫히면서 옛 트레이가 꺼지기를 기다리고 있었다.
    """
    import subprocess
    try:
        args = [sys.executable, os.path.join(HERE, 'tray_agent.py')]
        if replace:
            args.append('--replace')
        subprocess.Popen(args, cwd=HERE,
                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return True
    except Exception as e:
        print('[tray] 띄우지 못했습니다: %s' % e)
        return False


def replace_tray(wait=10.0):
    """옛 트레이를 닫고 **완전히 꺼진 것을 본 뒤** 새로 띄운다 → True/False.

    ⚠⚠ 2026-10-09 사용자 신고 「트래이가 전혀 표시되지 않는다」 — 닫자마자 띄웠더니
      옛 프로세스가 아직 뮤텍스를 쥐고 있어 **새 트레이가 「이미 떠 있다」며 물러났고**
      옛 것도 닫혀 둘 다 사라졌다. 창이 없어진 것을 보고 띄운다.
    """
    close_other_trays()
    end = time.time() + wait
    while time.time() < end and tray_open():
        time.sleep(0.25)
    time.sleep(0.5)                    # 창이 사라진 뒤 프로세스가 뮤텍스를 놓을 틈
    return launch()


def tray_open():
    """트레이가 이미 떠 있나 → True/False.

    ★ 띄우는 쪽(`user_main._start_tray`)이 이것을 먼저 본다 — 그러면
      **프로세스조차 안 뜬다**(뮤텍스는 뜬 뒤에 막는다).
    """
    if os.name != 'nt':
        return False
    try:
        import ctypes
        import ctypes.wintypes as wt
        u = ctypes.windll.user32
        u.FindWindowW.argtypes = [wt.LPCWSTR, wt.LPCWSTR]
        u.FindWindowW.restype = wt.HWND
        return bool(u.FindWindowW(TRAY_CLASS, None))
    except Exception:
        return False


def close_other_trays():
    """**나 말고** 떠 있는 트레이 창을 닫는다 → 닫은 수.

    ★★ 뮤텍스를 잡았다는 것은 「내가 유일해야 한다」는 뜻인데 창이 더 있으면
      그것은 **뮤텍스가 없던 옛 판**이 남긴 것이다. 그것을 정리해야 실제로
      하나가 된다(뮤텍스만으로는 이미 쌓인 6개가 안 없어진다).
    ⚠ **같은 클래스 이름은 전부 우리 앱의 것**이다 — §195차의 「남의 트레이를
      죽이지 않는다」는 **다른 프로그램**을 말한 것이고, 여기서 닫는 것은
      우리 앱이 잘못 띄운 제 분신들이다.
    ⚠ 내 창은 안 닫는다(`mine` 으로 걸러낸다).
    """
    if os.name != 'nt':
        return 0
    try:
        import ctypes
        import ctypes.wintypes as wt
        u = ctypes.windll.user32
        u.FindWindowExW.argtypes = [wt.HWND, wt.HWND, wt.LPCWSTR, wt.LPCWSTR]
        u.FindWindowExW.restype = wt.HWND
        n = 0
        h = u.FindWindowExW(None, None, TRAY_CLASS, None)
        while h:
            nxt = u.FindWindowExW(None, h, TRAY_CLASS, None)
            u.PostMessageW(h, 0x0010, 0, 0)    # WM_CLOSE
            n += 1
            h = nxt
        return n
    except Exception:
        return 0


def _tray_icon(u):
    """`icons/app_tray.ico` 를 트레이 크기로 읽는다 → HICON 또는 None.

    ⚠ `LoadIconW` 는 파일을 못 읽는다 — **`LoadImageW` + `LR_LOADFROMFILE`**.
    ⚠ 크기를 0 으로 주면 큰 것이 잡혀 흐려진다 — 실제 트레이 크기를 묻는다.
    """
    try:
        # ⚠⚠ `import ctypes.wintypes as wt` 는 `wt` 만 묶고 `ctypes` 이름은 안 묶는다 —
        #   아래 `ctypes.c_int` 가 NameError 를 냈고 except 가 삼켜 **늘 기본 「i」 아이콘**
        #   이었다(2026-10-09 사용자 신고). 함께 들여온다.
        import ctypes
        import ctypes.wintypes as wt
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'icons', 'app_tray.ico')
        if not os.path.exists(p):
            return None
        u.LoadImageW.argtypes = [wt.HINSTANCE, wt.LPCWSTR, wt.UINT,
                                 ctypes.c_int, ctypes.c_int, wt.UINT]
        u.LoadImageW.restype = wt.HICON
        cx = u.GetSystemMetrics(49) or 16      # SM_CXSMICON
        cy = u.GetSystemMetrics(50) or 16      # SM_CYSMICON
        return u.LoadImageW(None, p, 1, cx, cy, 0x00000010) or None
    except Exception:
        return None


def _tray_loop(db_path='bible_master.db'):
    """윈도우 트레이에 아이콘을 두고 주기적으로 확인한다."""
    import ctypes
    import ctypes.wintypes as wt
    # ★ 화면 배율을 안다고 알린다(2026-10-09 사용자 「선명도가 매우 낮다」) — 모르면
    #   윈도우가 16px 그림을 125% 트레이 칸(20px)으로 **늘려** 흐려진다. 알리면
    #   SM_CXSMICON 이 실제 칸 크기(20)를 돌려주고 아이콘의 20px 그림을 그대로 쓴다.
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)      # 모니터별
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    u = ctypes.windll.user32
    shell = ctypes.windll.shell32

    WM_APP = 0x8000
    WM_TRAY = WM_APP + 1
    WM_DESTROY = 0x0002
    WM_COMMAND = 0x0111
    NIM_ADD, NIM_DELETE, NIM_MODIFY = 0, 2, 1
    NIF_MESSAGE, NIF_ICON, NIF_TIP, NIF_INFO = 1, 2, 4, 0x10
    IDI_INFORMATION = 32516
    ID_CHECK, ID_OPEN, ID_QUIT, ID_YT = 1001, 1002, 1003, 1004

    class NOTIFYICONDATA(ctypes.Structure):
        _fields_ = [('cbSize', wt.DWORD), ('hWnd', wt.HWND),
                    ('uID', wt.UINT), ('uFlags', wt.UINT),
                    ('uCallbackMessage', wt.UINT), ('hIcon', wt.HICON),
                    ('szTip', wt.WCHAR * 128), ('dwState', wt.DWORD),
                    ('dwStateMask', wt.DWORD), ('szInfo', wt.WCHAR * 256),
                    ('uVersion', wt.UINT), ('szInfoTitle', wt.WCHAR * 64),
                    ('dwInfoFlags', wt.DWORD)]

    # ⚠⚠⚠ **핸들을 쓰는 ctypes 호출에는 argtypes·restype 이 반드시 있어야
    #   한다** (2026-09-03 — 실제로 당했다). 안 정하면 ctypes 가 기본 `c_int`
    #   (32비트)로 다루는데 64비트 윈도우의 핸들은 그보다 커서
    #   **`CreateWindowExW → OverflowError: int too long to convert`** 로
    #   트레이가 **아예 뜨지 못했다.** 191차에 만든 뒤 한 번도 안 떠 봤고,
    #   selftest 는 창을 안 만들어 이것을 못 봤다.
    LRESULT = ctypes.c_ssize_t                 # LONG_PTR — 64비트에서 8바이트
    UINT_PTR = ctypes.c_size_t
    WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT,
                                 wt.WPARAM, wt.LPARAM)

    class WNDCLASS(ctypes.Structure):
        _fields_ = [('style', wt.UINT), ('lpfnWndProc', WNDPROC),
                    ('cbClsExtra', ctypes.c_int), ('cbWndExtra', ctypes.c_int),
                    ('hInstance', wt.HINSTANCE), ('hIcon', wt.HICON),
                    ('hCursor', wt.HANDLE), ('hbrBackground', wt.HBRUSH),
                    ('lpszMenuName', wt.LPCWSTR), ('lpszClassName', wt.LPCWSTR)]

    _k32 = ctypes.windll.kernel32
    _k32.GetModuleHandleW.argtypes = [wt.LPCWSTR]
    _k32.GetModuleHandleW.restype = wt.HMODULE
    u.RegisterClassW.argtypes = [ctypes.POINTER(WNDCLASS)]
    u.RegisterClassW.restype = wt.ATOM
    u.CreateWindowExW.argtypes = [
        wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        wt.HWND, wt.HMENU, wt.HINSTANCE, wt.LPVOID]
    u.CreateWindowExW.restype = wt.HWND
    u.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
    u.DefWindowProcW.restype = LRESULT
    u.DestroyWindow.argtypes = [wt.HWND]
    u.SetForegroundWindow.argtypes = [wt.HWND]
    u.CreatePopupMenu.restype = wt.HMENU
    u.AppendMenuW.argtypes = [wt.HMENU, wt.UINT, UINT_PTR, wt.LPCWSTR]
    u.TrackPopupMenu.argtypes = [wt.HMENU, wt.UINT, ctypes.c_int, ctypes.c_int,
                                 ctypes.c_int, wt.HWND, wt.LPVOID]
    u.DestroyMenu.argtypes = [wt.HMENU]
    u.LoadIconW.argtypes = [wt.HINSTANCE, wt.LPCWSTR]
    u.LoadIconW.restype = wt.HICON
    u.PeekMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND,
                               wt.UINT, wt.UINT, wt.UINT]
    u.TranslateMessage.argtypes = [ctypes.POINTER(wt.MSG)]
    u.DispatchMessageW.argtypes = [ctypes.POINTER(wt.MSG)]
    u.DispatchMessageW.restype = LRESULT
    shell.Shell_NotifyIconW.argtypes = [wt.DWORD,
                                        ctypes.POINTER(NOTIFYICONDATA)]

    nid = NOTIFYICONDATA()
    state = {'last': 0.0, 'tick': 0.0, 'started': time.time()}

    def notify(title, msg):
        nid.uFlags = NIF_INFO
        nid.szInfoTitle = title[:63]
        nid.szInfo = msg[:255]
        shell.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(nid))

    def do_check(manual=False):
        r = check_once(db_path)
        state['last'] = time.time()
        if r['skipped']:
            if manual:
                notify(NAME, '본체가 실행 중이라 건너뛰었습니다.')
            return
        if r['ann'] or r['pack'] or r.get('models'):
            _extra = (' · AI 모델 %d' % r['models']) if r.get('models') else ''
            notify(NAME, '새 공지 %d건 · 링크 갱신 %d건%s'
                         % (r['ann'], r['pack'], _extra))
        elif manual:
            notify(NAME, '새 소식이 없습니다.')

    def wndproc(hwnd, msg, wp, lp):
        if msg == WM_TRAY and lp == 0x0202:               # 왼쪽 버튼 — 복사한 유튜브 주소
            try:
                if yth is not None:
                    yth.click()
            except Exception as e:
                print('[tray yt click] %s' % e)
            return 0
        if msg == WM_TRAY and lp in (0x0205, 0x0204):     # 오른쪽 버튼
            menu = u.CreatePopupMenu()
            try:
                if yth is not None and yth.has_clip():
                    u.AppendMenuW(menu, 0, ID_YT, '복사한 유튜브 영상 저장')
                    u.AppendMenuW(menu, 0x800, 0, None)
            except Exception:
                pass
            u.AppendMenuW(menu, 0, ID_CHECK, '지금 새 소식 받기')
            u.AppendMenuW(menu, 0, ID_OPEN, '앱 열기')
            u.AppendMenuW(menu, 0x800, 0, None)          # 구분선
            u.AppendMenuW(menu, 0, ID_QUIT, '종료')
            pt = wt.POINT()
            u.GetCursorPos(ctypes.byref(pt))
            u.SetForegroundWindow(hwnd)
            u.TrackPopupMenu(menu, 0, pt.x, pt.y, 0, hwnd, None)
            u.DestroyMenu(menu)
            return 0
        if msg == WM_COMMAND:
            cid = wp & 0xFFFF
            if cid == ID_YT:
                try:
                    if yth is not None:
                        yth.click(force=True)
                except Exception as e:
                    print('[tray yt menu] %s' % e)
            elif cid == ID_CHECK:
                do_check(manual=True)
            elif cid == ID_OPEN:
                _launch_app()
            elif cid == ID_QUIT:
                u.DestroyWindow(hwnd)
            return 0
        if msg == WM_DESTROY:
            shell.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(nid))
            u.PostQuitMessage(0)
            return 0
        return u.DefWindowProcW(hwnd, msg, wp, lp)

    proc = WNDPROC(wndproc)
    cls = WNDCLASS()
    cls.lpfnWndProc = proc
    cls.lpszClassName = TRAY_CLASS
    cls.hInstance = _k32.GetModuleHandleW(None)
    u.RegisterClassW(ctypes.byref(cls))
    hwnd = u.CreateWindowExW(0, cls.lpszClassName, NAME, 0, 0, 0, 0, 0,
                             None, None, cls.hInstance, None)
    nid.cbSize = ctypes.sizeof(NOTIFYICONDATA)
    nid.hWnd = hwnd
    nid.uID = 1
    nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
    nid.uCallbackMessage = WM_TRAY
    # ★ 트레이 아이콘 — 우리 성경책(0.txt 3번 · icons/app_tray.ico).
    #   ⚠ 파일이 없거나 못 읽으면 **윈도우 기본으로 물러선다** — 아이콘이
    #     없다고 트레이가 안 뜨면 안 된다.
    nid.hIcon = _tray_icon(u) or u.LoadIconW(None,
                                             ctypes.c_wchar_p(IDI_INFORMATION))
    nid.szTip = NAME
    shell.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid))

    # ⚠⚠ **뜨자마자 받지 않는다** (2026-09-03) — 그러면 부팅 지터가 아무
    #   소용이 없다. 출근 시간대에 다들 PC 를 켜면 그 몇 분에 요청이 몰린다
    #   (실측 8.3 req/s → 지터를 주면 2.4). 첫 수신도 루프의 판정을 거친다.
    if _due(state['started']):
        do_check()
    # ★ 유튜브 간편 저장(2026-10-09 1.txt 59-3) — 확장 프로그램 단추를 받고(북마크는 2026-10-12 폐기), **아이콘을 누를 때**
    #   복사해 둔 유튜브 주소를 묻는다(알림 창 `yt_save_win.py` 를 따로 띄운다).
    #   ⚠ 클립보드를 주기적으로 보지 않는다(사용자 「다른 목적으로 복사한 것일 수도」).
    yth = None
    try:
        import yt_intake as _YT
        yth = _YT.TrayHook(db_path)
    except Exception as e:
        print('[tray yt] %s' % e)
    msg = wt.MSG()
    while True:
        if u.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
            if msg.message == 0x0012:                    # WM_QUIT
                break
            u.TranslateMessage(ctypes.byref(msg))
            u.DispatchMessageW(ctypes.byref(msg))
        else:
            time.sleep(0.5)
            if yth is not None:
                try:
                    yth.tick()
                except Exception as e:
                    print('[tray yt tick] %s' % e)
            # ★★ **주기·분산은 `sync_schedule` 이 정한다**(2026-09-03) —
            #   여기서는 1분마다 「지금 받을까」를 묻기만 한다. 기본은 하루
            #   1회이고, 실제 시각은 이 기기의 **결정적 해시 슬롯**과 부팅
            #   지터가 정한다(서로 통신하지 않는 1만 대가 저절로 흩어진다).
            if time.time() - state['tick'] >= TICK_SEC:
                state['tick'] = time.time()
                if _due(state['started']):
                    do_check()


def _launch_app():
    """앱 열기 — 트레이는 그대로 두고 본체를 띄운다."""
    import subprocess
    try:
        subprocess.Popen([sys.executable, os.path.join(HERE, 'user_main.py')],
                         cwd=HERE)
    except Exception as e:
        print('앱 실행 실패: %s' % e)


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    # ★ **앱을 import 하지 않는다** — 이 파일의 존재 이유다.
    # ⚠ 소스 글자를 그냥 훑으면 **주석에 적힌 낱말**이 걸린다(실측 오탐).
    #   실제 import 문만 센다 — 파이썬 구문 나무로 읽는다.
    import ast
    tree = ast.parse(open(os.path.abspath(__file__), encoding='utf-8').read())
    mods = set()
    for nd in ast.walk(tree):
        if isinstance(nd, ast.Import):
            mods |= {a.name.split('.')[0] for a in nd.names}
        elif isinstance(nd, ast.ImportFrom) and nd.module:
            mods.add(nd.module.split('.')[0])
    t('user_main 을 import 하지 않는다', 'user_main' not in mods, sorted(mods))
    t('외부 의존성 없음(pystray·PIL)',
      not (mods & {'pystray', 'PIL', 'Pillow', 'win32api', 'win32gui'}))
    # 무거운 앱 모듈도 안 끌어온다(기동이 느려진다)
    t('Tk 를 안 부른다', 'tkinter' not in mods)
    # 표식 왕복
    had = os.path.exists(RUNNING_MARK)
    if not had:
        t('표식 없으면 실행 중 아님', app_running() is False)
        mark_running()
        t('표식 만들면 실행 중', app_running() is True)
        # 오래된 표식은 죽은 것으로 본다
        old = time.time() - 700
        os.utime(RUNNING_MARK, (old, old))
        t('오래된 표식 = 죽은 것', app_running() is False)
        clear_running()
        t('표식 정리', not os.path.exists(RUNNING_MARK))
    else:
        t('표식이 이미 있다(본체 실행 중) — 왕복 시험 생략', True)
    # 본체가 떠 있으면 아무것도 안 한다
    mark_running()
    r = check_once()
    t('본체 실행 중이면 건너뛴다', r['skipped'] is True)
    clear_running()
    # 정적 다운로드 — 로컬 폴더 시뮬레이션
    import tempfile
    d = tempfile.mkdtemp()
    open(os.path.join(d, 'x.json'), 'w', encoding='utf-8').write('{"a":1}')
    srv = [{'location': d, 'enabled': True}]
    t('정적 파일 받기(로컬)', _download(srv, 'x.json') == '{"a":1}')
    t('없는 파일은 None', _download(srv, 'nope.json') is None)
    import shutil
    shutil.rmtree(d, ignore_errors=True)
    # ★★★ **자동 최신화 스위치** (2026-09-06 사용자 5-1 「자동설정」) —
    #   ⚠ 값만 저장하고 **아무도 안 읽으면** 「눌러도 아무 일이 없는 스위치」다
    #     (§0-1). 실제로 받는 자리(`check_once`)가 이 문을 지나는지 잰다.
    import appdb as _ad
    _had = None
    try:
        with _ad.connect('bible_master.db') as _c:
            _r = _c.execute("SELECT config_val FROM user_config WHERE"
                            " config_key=?", (AUTO_SYNC_KEY,)).fetchone()
            _had = _r[0] if _r else None
    except Exception:
        pass

    def _set(v):
        with _ad.connect('bible_master.db') as _c:
            if v is None:
                _c.execute("DELETE FROM user_config WHERE config_key=?",
                           (AUTO_SYNC_KEY,))
            else:
                _c.execute("INSERT OR REPLACE INTO user_config"
                           "(config_key,config_val) VALUES(?,?)",
                           (AUTO_SYNC_KEY, v))
            _c.commit()
    try:
        _set(None)
        t('★★ 설정이 없으면 **켠 것으로 본다**(안 켜 두면 자료가 낡는다)',
          auto_sync_on() is True)
        _set('0')
        t('★ 끄면 꺼진다', auto_sync_on() is False)
        #   실제로 건너뛰는가 — 받는 문을 가짜로 바꿔 부르는지 센다
        _call, _real, _ar = [], fetch_pack_deltas, app_running
        globals()['fetch_pack_deltas'] = lambda *a, **k: (_call.append(1), 9)[1]
        globals()['app_running'] = lambda *a, **k: False
        try:
            r0 = check_once()
            t('★★★ **꺼 두면 자료를 안 받는다**(스위치가 실제로 걸린다)',
              not _call and r0.get('pack') == 0, r0.get('msg', '')[-18:])
            t('  왜 안 받았는지 말한다', '자동받기 꺼짐' in (r0.get('msg') or ''))
            _set('1'); _call.clear()
            r1 = check_once()
            t('★★ 켜면 받는다', len(_call) == 1 and r1.get('pack') == 9)
        finally:
            globals()['fetch_pack_deltas'] = _real
            globals()['app_running'] = _ar
    finally:
        _set(_had)          # ⚠ 시험이 실 설정을 바꾼 채 끝내지 않는다(§0-5)
    t('★ 시험 전 상태로 원복',
      (lambda v: v == _had)(
          (lambda: (_ad.connect('bible_master.db').execute(
              "SELECT config_val FROM user_config WHERE config_key=?",
              (AUTO_SYNC_KEY,)).fetchone() or [None])[0])()))

    # 델타 이름 규약이 sync 와 같은가 — 갈리면 영영 못 받는다
    import db_linkpack_sync as SYNC
    t('델타 이름 규약 공유', SYNC.DELTA_NAME % 7 == 'linkpack_00007.json')
    # ★★ **자연 열쇠 해석을 위해 본체 연결을 넘기는가** (2026-09-03 검거) —
    #   안 넘기면 연결이 통째로 보류돼 화면이 조용히 빈다.
    import inspect
    src = inspect.getsource(fetch_pack_deltas)
    t('★ 델타 적용에 본체 연결을 넘긴다',
      'main=main' in src and 'appdb.connect' in src)

    # ★★ **manifest 이름 규약을 보내는 쪽과 공유하는가** — 갈리면 못 읽고
    #   조용히 옛(비싼) 방식으로 물러선다.
    import db_linkpack_build as LB
    t('★ manifest 이름 규약 공유', LB.MANIFEST == SYNC.MANIFEST_NAME,
      '%s / %s' % (LB.MANIFEST, SYNC.MANIFEST_NAME))
    t('★ 밀린 양을 manifest 로 먼저 본다',
      'MANIFEST_NAME' in src and 'behind' in src)
    t('★ 크게 밀리면 델타를 안 받고 전체본으로',
      'behind > max_chain' in src and 'FULL_NAME' in src)

    # ★ 주기·분산이 `sync_schedule` 에 있는가(여기서 다시 정하지 않는다)
    import sync_schedule as SS
    loop_src = inspect.getsource(_tray_loop)
    t('★ 시작하자마자 받지 않는다(부팅 지터)', '_due(state[' in loop_src)
    t('★ 주기 판정을 sync_schedule 에 맡긴다',
      'should_fetch' in inspect.getsource(_due))
    t('  기본 주기는 하루 1회', SS.PERIODS[SS.DEFAULT_PERIOD] == 86400)
    t('  기본 시간대는 ANY(하루 전체에 흩는다)', SS.DEFAULT_WINDOW == 'ANY')

    # ★★★ **실제로 띄워서 창이 생기는가** (2026-09-03 — 이 항목이 없어서
    #   **트레이가 한 번도 안 떠 본 채로 191차를 통과했다**).
    #   `CreateWindowExW` 에 argtypes 가 없어 64비트 핸들이 넘쳐
    #   `OverflowError` 로 즉사했는데, 그전 selftest 는 창을 안 만들어
    #   전부 통과했다. ⇒ **별도 프로세스로 진짜 띄워** 창을 찾고 죽인다.
    #   ⚠ 다른 벌을 만들지 않는다 — 실제 경로(`python tray_agent.py`)를 그대로 쓴다.
    if sys.platform == 'win32':
        import ctypes
        import ctypes.wintypes as _wt
        import subprocess
        _u = ctypes.windll.user32
        _u.FindWindowW.argtypes = [_wt.LPCWSTR, _wt.LPCWSTR]
        _u.FindWindowW.restype = _wt.HWND
        _u.GetWindowThreadProcessId.argtypes = [_wt.HWND,
                                                ctypes.POINTER(_wt.DWORD)]

        # ★★★ **내가 띄운 창인지 가린다**(2026-09-04 실측으로 잡았다) —
        #   사용자가 트레이를 켜 두었으면(끄기 대화의 「트레이에 두기」)
        #   `FindWindowW` 가 **그 창**을 찾는다. 그러면 시험이 제 프로세스를
        #   죽였는데도 「안 사라졌다」로 판정하고, 반대로 뜨지도 않은 창을
        #   「떴다」고 통과시킨다. **둘 다 거짓 판정이다.**
        #   ⚠ 남의 트레이를 죽이지 않는다 — 사용자가 켜 둔 것이다.
        def _my_hwnd(pid):
            h = None
            cur = _u.FindWindowW(TRAY_CLASS, None)
            seen = set()
            while cur and cur not in seen:
                seen.add(cur)
                w = _wt.DWORD()
                _u.GetWindowThreadProcessId(cur, ctypes.byref(w))
                if w.value == pid:
                    h = cur
                    break
                cur = _u.FindWindowExW(None, cur, TRAY_CLASS, None) \
                    if hasattr(_u, 'FindWindowExW') else None
            return h
        _u.FindWindowExW.argtypes = [_wt.HWND, _wt.HWND, _wt.LPCWSTR,
                                     _wt.LPCWSTR]
        _u.FindWindowExW.restype = _wt.HWND
        had_mark2 = os.path.exists(RUNNING_MARK)
        if had_mark2:
            clear_running()          # 본체 표식이 있으면 트레이가 곧 쉰다
        _env = dict(os.environ, BM_TRAY_TEST='_selftest')
        p = subprocess.Popen([sys.executable, os.path.abspath(__file__)],
                             cwd=os.path.dirname(os.path.abspath(__file__)),
                             env=_env,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             creationflags=getattr(subprocess,
                                                   'CREATE_NO_WINDOW', 0))
        hwnd = 0
        for _ in range(30):
            time.sleep(0.25)
            hwnd = _my_hwnd(p.pid)
            if hwnd or p.poll() is not None:
                break
        died = p.poll() is not None
        out = ''
        if died:
            try:
                out = (p.stdout.read() or b'').decode('utf-8', 'replace')[-400:]
            except Exception:
                pass
        t('★ 트레이가 실제로 뜬다(창 생성)', bool(hwnd) and not died,
          ('죽음: ' + out.strip().replace('\n', ' ')[:180]) if died
          else hex(hwnd))
        try:
            p.kill()
            p.wait(timeout=5)
        except Exception:
            pass
        # ⚠ 프로세스가 죽어도 창이 사라지는 데 시간이 걸린다 — 기다린다.
        # ⚠⚠ **`restype=HWND` 는 NULL 을 `0` 이 아니라 `None` 으로 준다** —
        #   `== 0` 으로 비교하면 영원히 거짓이라 「정리 안 됨」이 된다(실측).
        gone = False
        for _ in range(20):
            time.sleep(0.25)
            if not _my_hwnd(p.pid):
                gone = True
                break
        t('시험 트레이 정리', gone)
        if had_mark2:
            mark_running()
        t('실행 표식 원복', os.path.exists(RUNNING_MARK) == had_mark2)

    # ── 단일 인스턴스(2026-09-05 · 실측 트레이 6개가 떠 있었다) ─────
    # ⚠⚠ **문자열을 세면 이 시험 자신이 걸린다**(실측으로 밟았다) —
    #   대입 꼴(`= '…'`)만 센다. 상수 정의 한 줄이면 1이고, 어딘가에 또
    #   박아 넣으면 2가 되어 그 자리에서 잡힌다.
    _src = io.open(__file__, encoding='utf-8').read()
    _lit = _src.count("= '" + TRAY_CLASS + "'")
    t('★★ **클래스 이름을 한 곳에서 정한다**(박아 넣으면 잡힌다)',
      _lit == 1 and 'cls.lpszClassName = TRAY_CLASS' in _src,
      '대입 %d곳' % _lit)
    t('★★ 뮤텍스 이름이 세션 안에서만 유일하다(Global 이 아니다)',
      TRAY_MUTEX.startswith('Local\\'), TRAY_MUTEX)
    os.environ['BM_TRAY_TEST'] = '_selftest_parent'
    first = single_instance()
    second = single_instance()
    os.environ.pop('BM_TRAY_TEST', None)
    t('★★★ **두 번째는 막힌다**(트레이는 하나뿐이다)',
      first and not second, '%s → %s' % (first, second))
    # ⚠⚠ **`close_other_trays` 는 부르지 않는다** — 사용자가 켜 둔 트레이를
    #   죽인다. 실제 왕복(6개 → 1개)은 손으로 재고 여기서는 문만 확인한다.
    t('  정리하는 문이 있다(여기서는 안 부른다)',
      callable(close_other_trays))
    t('★★ **띄우는 쪽이 먼저 본다**(프로세스조차 안 뜬다)',
      callable(tray_open) and tray_open() in (True, False))
    _um = io.open(os.path.join(HERE, 'user_main.py'), encoding='utf-8').read()
    t('★★★ **본체가 그 문을 실제로 부른다**(배선 확인)',
      '_tray.tray_open()' in _um)
    t('★ 시험이 트레이를 안 죽였다', True, 'close_other_trays 미호출')
    if os.name == 'nt':
        import ctypes as _ct
        t('★★ 트레이 아이콘 파일이 실제로 읽힌다(기본 「i」 로 물러나지 않는다)',
          bool(_tray_icon(_ct.windll.user32)))

    # ★ **본문팩 갱신 배선** (2026-09-07) — 만들어 두고 트레이가 안 부르면
    #   없는 것과 같다(§unwired). 소스에서 그 호출을 잰다.
    _src = io.open(__file__, encoding='utf-8').read() if '__file__' in dir() else ''
    try:
        _src = open(__file__, encoding='utf-8').read()
    except Exception:
        _src = ''
    t('★★ 본문팩 갱신을 실제로 부른다',
      'fetch_asset_updates' in _src)
    # ⚠ **찾는 글자를 검사 코드에 그대로 적지 않는다**(§198차) — 자기가
    #   걸려 두 번 세어진다. 조립해서 만든다.
    t('  링크 팩 실패로 번지지 않는다(따로 try)',
      _src.count('자료 갱신 ' + '실패') == 1)
    t('★ 왜 0건인지 남긴다',
      ('자료 갱신 ' + '없음') in _src)

    print('tray_agent selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--once' in sys.argv:
        print(check_once())
    elif '--cleanup' in sys.argv:
        # 손으로 정리하는 길 — 이미 쌓인 트레이를 한 번에 닫는다
        print('트레이 창 %d개를 닫았습니다.' % close_other_trays())
    else:
        # ★★★ **트레이는 하나뿐이다**(2026-09-05 · 실측 6개가 떠 있었다).
        #   ⚠ 조용히 죽지 않는다 — 왜 안 떴는지 콘솔에 적는다(§0-1).
        # ⚠ 옛 판을 닫고 곧바로 띄우면 옛 프로세스가 아직 뮤텍스를 쥐고 있을 수 있다 —
        #   잠깐 기다려 다시 잡아 본다(최대 20초 · 띄우는 쪽 `replace_tray` 도 기다린다).
        if '--replace' in sys.argv and not os.environ.get('BM_TRAY_TEST'):
            close_other_trays()        # 옛 판에게 닫으라 한다 — 아래에서 꺼지기를 기다린다
        _ok = single_instance()
        for _i in range(40):           # 최대 20초 — 옛 판이 꺼지는 것을 기다린다
            if _ok:
                break
            time.sleep(0.5)
            _ok = single_instance()
        if not _ok:
            print('[tray] 이미 트레이가 떠 있어 이번 것은 뜨지 않습니다.')
            sys.exit(0)
        try:                     # ★ 2026-10-13 — 트레이 오류도 오류 기록에(그전에는 아무 데도 안 남았다)
            import errlog
            errlog.install()
        except Exception:
            pass
        if not os.environ.get("BM_TRAY_TEST"):
            write_sig()          # 시험 트레이는 판을 안 적는다(사용자 트레이 기록을 덮는다)
        # ★★ 뮤텍스를 잡았는데도 창이 있으면 **옛 판이 남긴 것**이다 —
        #   그것까지 닫아야 실제로 하나가 된다.
        # ⚠⚠ **시험 모드에서는 정리하지 않는다** — 사용자가 켜 둔 트레이를
        #   죽인다(§195차 「남의 창을 보고 있었다」와 같은 자리).
        _left = 0 if os.environ.get('BM_TRAY_TEST') else close_other_trays()
        if _left:
            print('[tray] 옛 트레이 %d개를 정리했습니다.' % _left)
        _tray_loop()
