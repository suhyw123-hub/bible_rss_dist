# -*- coding: utf-8 -*-
"""db_peri_title_verify.py — 페리코프 제목(PERI_TITLE) 품질 검증 (영구 도구, §0-5 KEEP).

**언제 돌리나**: PERI_TITLE 을 새로 넣거나 번역했을 때. 특히 기계번역을 돌린 뒤에는
반드시. 2026-06-18 무검토 기계번역이 남긴 결함을 2026-08-01 에 전 언어 교정했고
(peri.md §4-1·§4-1b), 같은 일이 재발하지 않도록 이 검사를 상설화한다.

검사 항목
  ① 결손      — 빈 제목 · `PERI_1234` 같은 플레이스홀더 · EN 과 동일(미번역)
  ② 고유명사  — EN 제목의 성경 인명·지명이 그 언어 표준 표기로 옮겨졌는가
                (정답 = sys_text_asset ENTITY_NAME, 각 언어 권위 역본 표기)
  ③ 문체      — 제목 끝 마침표 · 경어체 종결(KO `…습니다` / JA `…です·ます`)
  ④ KRV 대조  — **KO 제목의 낱말이 그 페리코프의 개역한글 본문에 실제로 있는가**

굴절어(RU·AR)는 어미·접사가 붙으므로 **접두사 일치율**로 비교한다. 그래도 오탐이
남으므로 ②의 숫자는 "확인이 필요한 후보"이지 확정 오류가 아니다.

**④ 를 왜 넣었나 (2026-08-03).** 행 25~26장 제목이 `페스투스`·`아그리파`·`베르니체`·
`카이사르` 인데 개역한글 본문은 `베스도`·`아그립바`·`버니게`·`가이사` 다. 앱은 KRV 본문
옆에 제목을 띄우므로 독자가 다른 사람으로 읽는다. **그런데 ②가 이것을 못 잡았다** —
②는 EN 제목의 고유명사를 `ENTITY_NAME` 과 대조하는데 Festus·Agrippa·Bernice 가
그 표에 없기 때문이다. ④는 외부 표가 필요 없다. `db_commentary_audit.py` 와 같은
원리로 **자료가 스스로 정답을 말한다** — 제목이 가리키는 사람의 이름은 그 단락 본문에
있어야 한다.

⚠ ④는 **경고일 뿐 확정 오류가 아니다.** 제목에만 쓰는 요약어(`반전`·`고별`)는 본문에
없는 것이 정상이다. 이름처럼 생긴 낱말이 걸렸을 때만 의미가 있다.

  python db_peri_title_verify.py                 # 전 언어 요약
  python db_peri_title_verify.py --lang RU       # 한 언어 상세
  python db_peri_title_verify.py --lang RU --names   # 낱말별 집계
  python db_peri_title_verify.py --krv           # ④만, 전체
  python db_peri_title_verify.py --krv --book 44 # ④만, 한 책
  python db_peri_title_verify.py --selftest      # 탐지력 확인(의무)
"""
import re
import sys
import argparse
import collections
import appdb

DB = 'bible_master.db'
LANGS = ['KO', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR']

# EN 이 보통명사와 겹쳐 오탐만 내는 낱말 — 사전에서 제외
COMMON = {
    'Faith', 'Heaven', 'Temple', 'Baptism', 'Atonement', 'Grace', 'Hope', 'Love',
    'Peace', 'Truth', 'Light', 'Life', 'Word', 'Way', 'Bread', 'Rock', 'Stone',
    'Judge', 'Judges', 'King', 'Kings', 'Lord', 'God', 'Son', 'Spirit', 'Law',
    'Sabbath', 'Passover', 'Covenant', 'Israel', 'Christ', 'Jesus', 'Mark',
    'Ram', 'Lots', 'Rest', 'Joy', 'Gate', 'Branch', 'Crown', 'Song', 'Lot',
}
PLACEHOLDER = re.compile(r'^(PERI|peri)[_-]?\d*$')
POLITE = {
    'KO': re.compile(r'(습니다|합니다|십니다|입니다|십시오|세요|까요|습니까)\.?\??$'),
    'JA': re.compile(r'(です|ます|ました|ません|でしょう)。?$'),
}


def _cjk(s):
    return any('぀' <= c <= '鿿' or '가' <= c <= '힣' for c in s)


_SUFFIX = ('족속', '사람들', '사람', '자손', '지파', '파', '인', '들',
            '人', '族', '派', '人々')


def _core(w):
    """집합명사 접미를 떼어 낸 핵심어. 블레셋 족속 / 블레셋 사람들 → 블레셋."""
    w = w.split()[0] if ' ' in w else w
    for sfx in _SUFFIX:
        if w.endswith(sfx) and len(w) > len(sfx) + 1:
            return w[:-len(sfx)]
    return w


def _norm(s):
    return s.lower().replace('ё', 'е')          # ё → е


_AR_PFX = ('ال', 'وال', 'بال',
           'لل', 'فال', 'و', 'ب', 'ل', 'ك', 'ف')


def _ar_strip(w):
    for p in _AR_PFX:                                      # 정관사·전치사 접두 제거
        if w.startswith(p) and len(w) > len(p) + 2:
            return w[len(p):]
    return w


def _inflect_hit(want, text, lang):
    """굴절어: 어간(앞부분) 일치로 본다. 어미가 달라도 통과시킨다."""
    words = [_ar_strip(w) if lang == 'AR' else w
             for w in re.split(r'[\s,.;:—–\-()«»"‘’]+', _norm(text)) if w]
    for part in want.split():
        p = _ar_strip(_norm(part))
        if len(p) < 3:
            continue
        need = max(3, int(len(p) * 0.7))                   # 앞 70% 가 겹치면 같은 말로 본다
        if not any(w.startswith(p[:need]) or p.startswith(w[:need]) for w in words if len(w) >= need):
            return False
    return True


def build_dict(conn):
    d = collections.defaultdict(dict)
    for eid, lg, nm in conn.execute("""
        SELECT t.clicked_id, t.lang_code, t.contents
          FROM sys_text_asset t JOIN sys_entity_master e ON e.entity_id=t.clicked_id
         WHERE t.text_type='ENTITY_NAME'
           AND e.entity_type IN ('PERSON','PLACE','NATION','GROUP','IDOL')
           AND COALESCE(e.record_status,'LIVE')='LIVE'"""):
        if nm and nm.strip():
            d[eid][lg] = nm.strip()
    out = {}
    for m in d.values():
        en = m.get('EN', '')
        if en and ' ' not in en and en[0].isupper() and en not in COMMON:
            out[en] = m
    return out


def rows_for(conn, lg):
    return conn.execute("""
        SELECT e.clicked_id, e.title, t.title, bi.bcode||':'||bi.chapter||':'||bi.verse
          FROM sys_text_asset e
          LEFT JOIN sys_text_asset t ON t.clicked_id=e.clicked_id
                                    AND t.text_type='PERI_TITLE' AND t.lang_code=?
          JOIN sys_pericope_asset p ON p.pericope_id=e.clicked_id
          JOIN bible_index bi ON bi.verse_id=p.start_vid
         WHERE e.text_type='PERI_TITLE' AND e.lang_code='EN'
           AND e.title IS NOT NULL AND TRIM(e.title)<>''
         ORDER BY bi.bcode, bi.chapter, bi.verse""", (lg,)).fetchall()


def check(conn, NAME, lg):
    miss_all, name_bad, style = [], [], []
    for pid, en, tt, ref in rows_for(conn, lg):
        if not tt or not tt.strip() or PLACEHOLDER.match(tt.strip()) or tt.strip() == en.strip():
            miss_all.append((pid, ref, en, tt or ''))
            continue
        bad = []
        for tok in re.findall(r"[A-Z][A-Za-z’'\-]+", en):
            m = NAME.get(tok)
            want = m.get(lg) if m else None
            if not want:
                continue
            if _cjk(want):
                hit = want in tt or _core(want) in tt
            elif lg in ('RU', 'AR'):
                hit = _inflect_hit(want, tt, lg)
            else:
                hit = want.lower() in tt.lower()
            if not hit:
                bad.append((tok, want))
        if bad:
            name_bad.append((pid, ref, en, tt, bad))
        why = []
        if tt.rstrip().endswith(('.', '!')):
            why.append('끝 마침표')
        if lg in POLITE and POLITE[lg].search(tt.strip()):
            why.append('경어체')
        if why:
            style.append((pid, ref, en, tt, '·'.join(why)))
    return miss_all, name_bad, style


# ── ④ KRV 대조 ────────────────────────────────────────────────────────────
KO_TOK = re.compile(r'[가-힣]{2,}')
# 조사·어미. 긴 것부터 떼어야 `에서` 가 `에` 로 잘리지 않는다.
PARTICLE = re.compile(r'(에게서|에서|에게|으로|께서|과의|와의|이|가|은|는|을|를|의|에|와|과|도|로|께)$')


def krv_of(conn, pid):
    r = conn.execute('SELECT start_vid, end_vid FROM sys_pericope_asset '
                     'WHERE pericope_id=?', (pid,)).fetchone()
    if not r:
        return ''
    return ' '.join(x[0] or '' for x in conn.execute(
        "SELECT verse_text FROM bible_content WHERE verse_id BETWEEN ? AND ? "
        "AND version_code='KRV'", r))


# 조사·복수를 뗀 뒤 이 길이 이상인 낱말만 본다. 음역된 외래 인명·지명은 대개 네 음절
# 이상이고(페스투스·아그리파·베르니체·카이사르), 제목 전용 요약어는 그보다 짧다
# (머리말·공동체·나눔). 실측으로 정한 값이다 — 3 으로 낮추면 사도행전에서만 96건이
# 나와 신호가 묻힌다.
MIN_LEN = 4
PLURAL = re.compile(r'(들|까지|부터|마다)$')
# 제목의 동사·형용사는 본문 어형과 달라 늘 어긋난다(`박해하다` vs `핍박하니`).
# 표기 문제가 아니라 요약 방식이므로 이 검사의 대상이 아니다.
VERB = re.compile(r'다$')


def _strip(pat, w):
    """떼고 나서 두 글자 이상 남을 때만 뗀다.

    ⚠ 이 조건이 없으면 `사도` 의 `도` 를 조사로 보고 `사` 로 잘라 버린다
      (2026-08-03 실측에서 `사도들이` 가 오탐으로 걸렸다). 조사와 이름 끝소리가
      겹치는 글자(도·로·와·과·에)가 많아 길이 하한이 필수다.
    """
    b = pat.sub('', w)
    return b if len(b) >= 2 else w


def _base(w):
    b = _strip(PARTICLE, w)
    b = _strip(PLURAL, b)
    return _strip(PARTICLE, b)       # `신자들의` -> `신자들` -> `신자`


def krv_missing(title, src, min_len=MIN_LEN):
    """제목 낱말 중 KRV 본문에 없는 것. 조사·복수를 떼고 본다."""
    miss = []
    for w in KO_TOK.findall(title or ''):
        base = _base(w)
        if base in src or w in src:
            continue
        if len(base) < min_len:
            continue                  # 짧은 요약어는 제목 전용일 수 있다
        if VERB.search(base):
            continue                  # 동사형은 어형이 달라 늘 어긋난다
        miss.append(w)
    return miss


def krv_check(conn, bcode=None):
    q = """SELECT t.clicked_id, t.title, bi.bcode||':'||bi.chapter||':'||bi.verse
             FROM sys_text_asset t
             JOIN sys_pericope_asset p ON p.pericope_id=t.clicked_id
             JOIN bible_index bi ON bi.verse_id=p.start_vid
            WHERE t.text_type='PERI_TITLE' AND t.lang_code='KO'
              AND t.title IS NOT NULL AND TRIM(t.title)<>''"""
    args = []
    if bcode:
        q += ' AND bi.bcode=?'
        args.append(bcode)
    out = []
    for pid, tt, ref in conn.execute(q + ' ORDER BY bi.bcode, bi.chapter, bi.verse', args):
        src = krv_of(conn, pid)
        if not src:
            continue
        miss = krv_missing(tt, src)
        if miss:
            out.append((pid, ref, tt, miss))
    return out


def selftest(conn):
    """탐지력 확인 — 실제 데이터로 확인한다(꾸며 낸 문자열이 아니라)."""
    ok = True
    src = krv_of(conn, 7857)          # 행 25:1-9
    for word, want_missing in (('페스투스', True), ('베스도', False),
                               ('아그리파', True), ('바울', False)):
        miss = krv_missing(word, src, min_len=2)
        hit = bool(miss) == want_missing
        print(f'  [{"PASS" if hit else "FAIL"}] {word} — KRV 행 25:1-9 에 '
              f'{"없음" if miss else "있음"} (기대 {"없음" if want_missing else "있음"})')
        ok = ok and hit
    # 조사 처리
    miss = krv_missing('바울이 베스도에게', src, min_len=2)
    print(f'  [{"PASS" if not miss else "FAIL"}] 조사 제거 — "바울이 베스도에게" {miss or "통과"}')
    return ok and not miss


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lang')
    ap.add_argument('--names', action='store_true')
    ap.add_argument('--krv', action='store_true', help='④ KRV 대조만')
    ap.add_argument('--book', type=int)
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect(DB)

    if a.selftest:
        print('=== ④ KRV 대조 자가 탐지력 ===')
        sys.exit(0 if selftest(conn) else 1)
    if a.krv:
        rows = krv_check(conn, a.book)
        print(f'④ KRV 대조 — 후보 {len(rows)}건'
              + (f' (bcode {a.book})' if a.book else ' (전체)'))
        for pid, ref, tt, miss in rows:
            print(f'  {pid} [{ref}] {tt}\n         본문에 없음: {" · ".join(miss)}')
        return

    NAME = build_dict(conn)

    if a.lang:
        m, n, st = check(conn, NAME, a.lang)
        if a.names:
            cnt = collections.Counter()
            for pid, ref, en, tt, bad in n:
                for tok, want in bad:
                    cnt[(tok, want)] += 1
            print(f'[{a.lang}] 고유명사 후보 {len(n)}건 · 낱말 {len(cnt)}종')
            for (tok, want), c in cnt.most_common():
                ex = next(t for _, _, _, t, bs in n if any(x == tok for x, _ in bs))
                print(f'  {c:>3}  {tok:<16} → {want:<16} | {ex[:52]}')
            return
        print(f'[{a.lang}] 결손 {len(m)} · 고유명사 후보 {len(n)} · 문체 {len(st)}')
        for pid, ref, en, tt in m:
            print(f'  [결손] {pid} [{ref}] {en}  ->  "{tt}"')
        for pid, ref, en, tt, bad in n:
            print(f'  [이름] {pid} [{ref}] {en}\n         {tt}\n         '
                  + ', '.join(f'{x}→{y}' for x, y in bad))
        for pid, ref, en, tt, why in st:
            print(f'  [문체:{why}] {pid} [{ref}] {tt}')
        return

    print(f'고유명사 사전 {len(NAME)}개\n')
    print('언어    결손   고유명사후보   문체')
    tot = [0, 0, 0]
    for lg in LANGS:
        m, n, st = check(conn, NAME, lg)
        tot = [tot[0] + len(m), tot[1] + len(n), tot[2] + len(st)]
        print(f'  {lg:<5} {len(m):>5} {len(n):>12} {len(st):>6}')
    print(f'  {"계":<4} {tot[0]:>5} {tot[1]:>12} {tot[2]:>6}')
    print('\n※ 고유명사는 "확인 필요 후보"다. 굴절어는 오탐이 섞인다.')


if __name__ == '__main__':
    main()
