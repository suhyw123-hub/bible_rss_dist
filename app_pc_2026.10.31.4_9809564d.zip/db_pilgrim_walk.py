"""db_pilgrim_walk.py — 성지순례 「걸어서」 단계: 도보 구역 · 추천 걷기 코스 (2026-10-30 신설·영구)

사용자 설계(2026-10-30) — 「위성에서 한눈에 · 자동차로 달리는 코스 · 실제 걸어가며 둘러볼 코스」 셋 가운데 셋째.
  · 구역 = 사람이 실제로 걸어서 둘러보는 단위(반경만으로 자르면 기드론 골짜기 건너 감람산이 옛 도시와 한 원에 든다)
  · 추천 코스 = 여행사 도시 관광처럼 기본으로 체크된 차례 — 사용자가 더하고 빼고(빼면 보관함) 고른 것만 지도에
  · 길 안내 · 장소 카드(사진·영업시간·전화·예약)는 구글 지도가 맡는다(우리 앱 = 무엇을 · 왜 · 어떤 차례로)

표(둘 다 CORE · 폰 공통팩)
  sys_pilgrim_walk_zone   (zone_id, code, names JSON, lat, lng, radius_m, sort_order, record_status)
  sys_pilgrim_walk_course (course_id, code, zone_code, names JSON, stops JSON ['S12','P163'…], km, minutes, sort_order, record_status)

★ 코스 차례는 **위키데이터 번호(qid)로 적고** seed 가 'S번호'로 푼다(순례 장소 번호는 DB 마다 다르다).
★ 걷는 시간 = 직선 거리 × 1.3 ÷ 시속 4km + 머무름(곳마다 STAY 분) — 어림이다. 실제 길·시간은 구글 걷기 안내.

  --selftest · --seed(멱등 · 같은 code 는 덮는다) · --status
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

import appdb  # noqa: E402

WALK_KMH = 4.0
DETOUR = 1.3
STAY = 15        # 곳마다 머무름(분)


def _n(ko, en, zh, zht, ja, de, fr, es, pt, ru, ar):
    return {'KO': ko, 'EN': en, 'ZH': zh, 'ZHT': zht, 'JA': ja, 'DE': de, 'FR': fr, 'ES': es, 'PT': pt, 'RU': ru, 'AR': ar}


# code, 이름, 중심(위도, 경도), 반경 m
ZONES = (
    ('JER_VIA', _n('예루살렘 · 비아 돌로로사', 'Jerusalem · Via Dolorosa', '耶路撒冷 · 苦路', '耶路撒冷 · 苦路', 'エルサレム・ヴィア・ドロローサ',
                   'Jerusalem · Via Dolorosa', 'Jérusalem · Via Dolorosa', 'Jerusalén · Vía Dolorosa', 'Jerusalém · Via Dolorosa',
                   'Иерусалим · Виа Долороза', 'القدس · طريق الآلام'), 31.7800, 35.2330, 450),
    ('JER_SOUTH', _n('예루살렘 · 성전산 남쪽과 다윗성', 'Jerusalem · Temple Mount South & City of David', '耶路撒冷 · 圣殿山南侧与大卫城',
                     '耶路撒冷 · 聖殿山南側與大衛城', 'エルサレム・神殿の丘南側とダビデの町', 'Jerusalem · Tempelberg-Süd & Davidsstadt',
                     'Jérusalem · sud du mont du Temple et cité de David', 'Jerusalén · sur del Monte del Templo y Ciudad de David',
                     'Jerusalém · sul do Monte do Templo e Cidade de Davi', 'Иерусалим · юг Храмовой горы и Город Давида',
                     'القدس · جنوب جبل الهيكل ومدينة داود'), 31.7745, 35.2350, 480),
    ('JER_ZION', _n('예루살렘 · 시온산', 'Jerusalem · Mount Zion', '耶路撒冷 · 锡安山', '耶路撒冷 · 錫安山', 'エルサレム・シオンの山',
                    'Jerusalem · Zionsberg', 'Jérusalem · mont Sion', 'Jerusalén · Monte Sion', 'Jerusalém · Monte Sião',
                    'Иерусалим · гора Сион', 'القدس · جبل صهيون'), 31.7718, 35.2295, 320),
    ('JER_OLIVES', _n('예루살렘 · 감람산과 기드론 골짜기', 'Jerusalem · Mount of Olives & Kidron Valley', '耶路撒冷 · 橄榄山与汲沦溪',
                      '耶路撒冷 · 橄欖山與汲淪溪', 'エルサレム・オリーブ山とキドロンの谷', 'Jerusalem · Ölberg & Kidrontal',
                      'Jérusalem · mont des Oliviers et vallée du Cédron', 'Jerusalén · Monte de los Olivos y valle del Cedrón',
                      'Jerusalém · Monte das Oliveiras e vale do Cedrom', 'Иерусалим · Елеонская гора и Кедронская долина',
                      'القدس · جبل الزيتون ووادي قدرون'), 31.7780, 35.2445, 700),
    ('BETHLEHEM', _n('베들레헴 · 탄생 기념 성당 둘레', 'Bethlehem · around the Church of the Nativity', '伯利恒 · 主诞堂周边', '伯利恆 · 主誕堂周邊',
                     'ベツレヘム・聖誕教会周辺', 'Bethlehem · rund um die Geburtskirche', 'Bethléem · autour de la basilique de la Nativité',
                     'Belén · alrededor de la Basílica de la Natividad', 'Belém · em torno da Basílica da Natividade',
                     'Вифлеем · вокруг храма Рождества', 'بيت لحم · حول كنيسة المهد'), 31.7048, 35.2060, 450),
    ('NAZARETH', _n('나사렛 옛 도시', 'Nazareth Old City', '拿撒勒老城', '拿撒勒老城', 'ナザレ旧市街', 'Altstadt von Nazareth',
                    'Vieille ville de Nazareth', 'Ciudad vieja de Nazaret', 'Cidade velha de Nazaré', 'Старый город Назарета',
                    'البلدة القديمة في الناصرة'), 32.7040, 35.2985, 600),
    ('TABGHA', _n('갈릴리 호숫가 · 타브가와 팔복산', 'Sea of Galilee · Tabgha & Mount of Beatitudes', '加利利海边 · 塔布加与八福山',
                  '加利利海邊 · 塔布加與八福山', 'ガリラヤ湖畔・タブハと山上の垂訓の丘', 'See Genezareth · Tabgha & Berg der Seligpreisungen',
                  'Lac de Galilée · Tabgha et mont des Béatitudes', 'Mar de Galilea · Tabgha y Monte de las Bienaventuranzas',
                  'Mar da Galileia · Tabgha e Monte das Bem-Aventuranças', 'Галилейское море · Табха и гора Блаженств',
                  'بحيرة طبريا · الطابغة وجبل التطويبات'), 32.8760, 35.5495, 1100),
    ('EPHESUS', _n('에베소 옛 도시', 'Ancient Ephesus', '以弗所古城', '以弗所古城', 'エフェソス遺跡', 'Antikes Ephesos', 'Éphèse antique',
                   'Antigua Éfeso', 'Éfeso antiga', 'Древний Эфес', 'أفسس القديمة'), 37.9405, 27.3415, 600),
    ('SELCUK', _n('셀추크 · 사도 요한 교회와 아데미 신전', 'Selçuk · Basilica of St. John & Temple of Artemis', '塞尔丘克 · 圣约翰大教堂与亚底米神庙',
                  '塞爾丘克 · 聖約翰大教堂與亞底米神廟', 'セルチュク・聖ヨハネ教会とアルテミス神殿', 'Selçuk · Johannesbasilika & Artemistempel',
                  'Selçuk · basilique Saint-Jean et temple d’Artémis', 'Selçuk · Basílica de San Juan y templo de Artemisa',
                  'Selçuk · Basílica de São João e templo de Ártemis', 'Сельчук · базилика Иоанна и храм Артемиды',
                  'سلجوق · كنيسة القديس يوحنا ومعبد أرتميس'), 37.9510, 27.3660, 500),
    ('ATHENS', _n('아테네 · 아크로폴리스와 아레오바고', 'Athens · Acropolis & Areopagus', '雅典 · 卫城与亚略巴古', '雅典 · 衛城與亞略巴古',
                  'アテネ・アクロポリスとアレオパゴス', 'Athen · Akropolis & Areopag', 'Athènes · Acropole et Aréopage',
                  'Atenas · Acrópolis y Areópago', 'Atenas · Acrópole e Areópago', 'Афины · Акрополь и Ареопаг',
                  'أثينا · الأكروبوليس وأريوس باغوس'), 37.9720, 23.7250, 600),
)

# code, 구역, 이름, 차례(qid)
COURSES = (
    ('JER_VIA_14', 'JER_VIA',
     _n('비아 돌로로사 — 십자가의 길', 'Via Dolorosa — the Way of the Cross', '苦路 — 十字架之路', '苦路 — 十字架之路', 'ヴィア・ドロローサ — 十字架の道',
        'Via Dolorosa — der Kreuzweg', 'Via Dolorosa — le chemin de croix', 'Vía Dolorosa — el camino de la cruz',
        'Via Dolorosa — o caminho da cruz', 'Виа Долороза — крестный путь', 'طريق الآلام — درب الصليب'),
     ['Q129278', 'Q1551966', 'Q831297', 'Q1499131', 'Q1761639', 'Q1280187', 'Q92147990', 'Q999100', 'Q28229508',
      'Q92153349', 'Q92147999', 'Q16715750', 'Q92147996', 'Q187702']),
    ('JER_SOUTH_DAVID', 'JER_SOUTH',
     _n('성전산 남쪽 벽에서 실로암 못까지', 'From the Southern Wall to the Pool of Siloam', '从圣殿山南墙到西罗亚池', '從聖殿山南牆到西羅亞池',
        '神殿の丘南壁からシロアムの池まで', 'Von der Südmauer zum Teich Siloah', 'Du mur sud à la piscine de Siloé',
        'Del muro sur al estanque de Siloé', 'Do muro sul ao tanque de Siloé', 'От южной стены до Силоамской купели',
        'من الحائط الجنوبي إلى بركة سلوام'),
     ['Q204719', 'Q134821', 'Q8022908', 'Q2906823', 'Q2912191', 'Q2630170', 'Q1177750', 'Q3655064', 'Q204601',
      'Q1620682', 'Q1483483']),
    ('JER_ZION_UPPER', 'JER_ZION',
     _n('시온산 — 다락방과 베드로의 통곡', 'Mount Zion — the Upper Room and Peter’s tears', '锡安山 — 楼房与彼得的痛哭', '錫安山 — 樓房與彼得的痛哭',
        'シオンの山 — 二階座敷とペテロの涙', 'Zionsberg — Abendmahlssaal und Petrus’ Tränen', 'Mont Sion — le Cénacle et les larmes de Pierre',
        'Monte Sion — el Cenáculo y las lágrimas de Pedro', 'Monte Sião — o Cenáculo e as lágrimas de Pedro',
        'Гора Сион — Сионская горница и слёзы Петра', 'جبل صهيون — العلية ودموع بطرس'),
     ['Q205416', 'Q1245538', 'Q318972', 'Q1177668', 'Q1861408']),
    ('JER_OLIVES_PALM', 'JER_OLIVES',
     _n('감람산 — 종려주일 길(위에서 아래로)', 'Mount of Olives — the Palm Sunday walk (top to bottom)', '橄榄山 — 棕枝主日之路(由上而下)',
        '橄欖山 — 棕枝主日之路(由上而下)', 'オリーブ山 — 棕櫚の主日の道(上から下へ)', 'Ölberg — der Palmsonntagsweg (von oben nach unten)',
        'Mont des Oliviers — le chemin des Rameaux (de haut en bas)', 'Monte de los Olivos — el camino del Domingo de Ramos (de arriba abajo)',
        'Monte das Oliveiras — o caminho do Domingo de Ramos (de cima para baixo)', 'Елеонская гора — путь Вербного воскресенья (сверху вниз)',
        'جبل الزيتون — درب أحد الشعانين (من الأعلى إلى الأسفل)'),
     ['Q3585512', 'Q773726', 'Q588849', 'Q2885760', 'Q1238436', 'Q333594', 'Q1331689', 'Q968028', 'Q331729',
      'Q1708945', 'Q492091']),
    ('BETHLEHEM_NATIVITY', 'BETHLEHEM',
     _n('별의 길에서 탄생 동굴과 젖 동굴까지', 'From Star Street to the Grotto of the Nativity and the Milk Grotto', '从星街到主诞洞与奶洞', '從星街到主誕洞與奶洞', '星の通りから聖誕洞窟とミルク・グロットへ',
        'Von der Sternstraße zur Geburtsgrotte und Milchgrotte', 'De la rue de l’Étoile à la grotte de la Nativité et à la grotte du Lait', 'De la calle de la Estrella a la Gruta de la Natividad y la Gruta de la Leche',
        'Da Rua da Estrela à Gruta da Natividade e à Gruta do Leite', 'От улицы Звезды к пещере Рождества и Молочной пещере', 'من شارع النجمة إلى مغارة الميلاد ومغارة الحليب'),
     ['Q1698008', 'Q7600915', 'Q2557689', 'Q194504', 'Q4362268', 'Q12408516', 'Q2892250']),
    ('NAZARETH_ANNUNC', 'NAZARETH',
     _n('수태고지 성당에서 마리아의 우물까지', 'From the Basilica of the Annunciation to Mary’s Well', '从天使报喜堂到马利亚井',
        '從天使報喜堂到馬利亞井', '受胎告知教会からマリアの泉へ', 'Von der Verkündigungsbasilika zum Marienbrunnen',
        'De la basilique de l’Annonciation à la fontaine de Marie', 'De la Basílica de la Anunciación a la Fuente de María',
        'Da Basílica da Anunciação à Fonte de Maria', 'От базилики Благовещения до источника Девы Марии',
        'من كنيسة البشارة إلى عين العذراء'),
     ['Q130815', 'Q1124878', 'Q7661936', 'Q5293153', 'Q1606462']),
    ('TABGHA_DOWN', 'TABGHA',
     _n('팔복산에서 호숫가로(내리막)', 'From the Mount of Beatitudes down to the shore', '从八福山下到湖边', '從八福山下到湖邊',
        '山上の垂訓の丘から湖畔へ(下り)', 'Vom Berg der Seligpreisungen hinab zum Ufer', 'Du mont des Béatitudes jusqu’au rivage',
        'Del Monte de las Bienaventuranzas a la orilla', 'Do Monte das Bem-Aventuranças até a margem',
        'С горы Блаженств вниз к берегу', 'من جبل التطويبات نزولًا إلى الشاطئ'),
     ['Q2918487', 'Q543683', 'Q990912', 'Q2109794']),
    ('EPHESUS_DOWN', 'EPHESUS',
     _n('윗문에서 대극장과 마리아 교회까지(내리막)', 'From the upper gate to the Great Theatre and the Church of Mary', '从上门到大剧场与马利亚教堂',
        '從上門到大劇場與馬利亞教堂', '上の門から大劇場とマリア教会へ(下り)', 'Vom oberen Tor zum großen Theater und zur Marienkirche',
        'De la porte haute au grand théâtre et à l’église de Marie', 'De la puerta alta al Gran Teatro y la Iglesia de María',
        'Da porta alta ao Grande Teatro e à Igreja de Maria', 'От верхних ворот к Большому театру и церкви Девы Марии',
        'من البوابة العليا إلى المسرح الكبير وكنيسة مريم'),
     ['Q77071662', 'Q2581040', 'Q1575495', 'Q744406', 'Q77071353', 'Q15723477', 'Q2450228']),
    ('SELCUK_JOHN', 'SELCUK',
     _n('사도 요한 교회 · 아데미 신전 · 박물관', 'Basilica of St. John · Temple of Artemis · Museum', '圣约翰大教堂 · 亚底米神庙 · 博物馆',
        '聖約翰大教堂 · 亞底米神廟 · 博物館', '聖ヨハネ教会・アルテミス神殿・博物館', 'Johannesbasilika · Artemistempel · Museum',
        'Basilique Saint-Jean · temple d’Artémis · musée', 'Basílica de San Juan · templo de Artemisa · museo',
        'Basílica de São João · templo de Ártemis · museu', 'Базилика Иоанна · храм Артемиды · музей',
        'كنيسة القديس يوحنا · معبد أرتميس · المتحف'),
     ['Q930613', 'Q43018', 'Q1346784']),
    ('ATHENS_PAUL', 'ATHENS',
     _n('바울의 아테네 — 아크로폴리스 · 아레오바고 · 아고라', 'Paul’s Athens — Acropolis · Areopagus · Agora', '保罗的雅典 — 卫城 · 亚略巴古 · 市集',
        '保羅的雅典 — 衛城 · 亞略巴古 · 市集', 'パウロのアテネ — アクロポリス・アレオパゴス・アゴラ', 'Das Athen des Paulus — Akropolis · Areopag · Agora',
        'L’Athènes de Paul — Acropole · Aréopage · Agora', 'La Atenas de Pablo — Acrópolis · Areópago · Ágora',
        'A Atenas de Paulo — Acrópole · Areópago · Ágora', 'Афины Павла — Акрополь · Ареопаг · Агора',
        'أثينا بولس — الأكروبوليس · أريوس باغوس · الأغورا'),
     ['Q131013', 'Q202487', 'Q395367']),
)


def ensure(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS sys_pilgrim_walk_zone (zone_id INTEGER PRIMARY KEY AUTOINCREMENT,'
                 ' code TEXT UNIQUE, names TEXT, lat REAL, lng REAL, radius_m INTEGER, sort_order INTEGER,'
                 " record_status TEXT DEFAULT 'LIVE')")
    conn.execute('CREATE TABLE IF NOT EXISTS sys_pilgrim_walk_course (course_id INTEGER PRIMARY KEY AUTOINCREMENT,'
                 ' code TEXT UNIQUE, zone_code TEXT, names TEXT, stops TEXT, km REAL, minutes INTEGER, sort_order INTEGER,'
                 " record_status TEXT DEFAULT 'LIVE')")


# ── ★ 2026-10-30 실제 걷는 길(사용자 「도시는 걸어서 갈 수 있도록 선을 · 포장도로가 없는 곳은?」) ──
# 도보 엔진(GraphHopper foot · 포트 8993 · db_walk_extract.py 로 도보 구역 둘레만 자른 지도)이
# 구역 안 장소 두 곳마다 걷는 길을 잰다. 표 sys_pilgrim_walk_path(CORE · 폰 공통팩):
#   a, b      'S12' · 'P163' (a < b 글자 차례 — 폰은 거꾸로 찾으면 선을 뒤집는다)
#   km, minutes, poly(구글 polyline 정밀도 5 · 약 5m 로 덜어 냄)
#   rough     흙길·오솔길(포장 안 된 길)이 차지하는 거리 비율 0~1 — 폰이 선 모양을 가른다
# ★ 길을 못 찾았거나 길이 직선의 3배를 넘으면(엉뚱하게 돌아감) 줄을 안 넣는다 → 폰은 점선 직선 + 「길 정보 없음」.
#   지어내지 않는다 — 블로그·AI 로 길을 그리지 않는다(사용자 합의 2026-10-30).
GH_WALK = 'http://127.0.0.1:8993'
DETOUR_MAX = 3.0
ROUGH_CLASS = {'TRACK', 'PATH', 'BRIDLEWAY'}
ROUGH_SURF = {'UNPAVED', 'COMPACTED', 'FINE_GRAVEL', 'GRAVEL', 'GROUND', 'DIRT', 'GRASS', 'SAND'}
PAVED_SURF = {'PAVED', 'ASPHALT', 'CONCRETE', 'PAVING_STONES', 'COBBLESTONE', 'WOOD'}


def ensure_path(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS sys_pilgrim_walk_path (a TEXT NOT NULL, b TEXT NOT NULL,'
                 ' km REAL, minutes REAL, poly TEXT, rough REAL, made_at TEXT, PRIMARY KEY (a, b))')


def _dist_m(a, b, c, d):
    return math.hypot((c - a) * 111000, (d - b) * 111000 * math.cos(math.radians((a + c) / 2)))


def cands(conn, zone):
    """구역 안 장소 — [(열쇠, 위도, 경도)] · 폰 _wkCands 와 같은 규칙(성경 장소 P · 순례 장소 S)"""
    code, la, lo, r = zone
    out = []
    for i, a, b in conn.execute("SELECT entity_id, geo_lat, geo_lng FROM sys_entity_master WHERE entity_type='PLACE'"
                                " AND geo_lat IS NOT NULL AND COALESCE(record_status,'LIVE')='LIVE'"):
        out.append(('P%d' % i, float(a), float(b)))
    for i, a, b in conn.execute("SELECT site_id, lat, lng FROM sys_pilgrim_site WHERE status='LIVE'"
                                " AND CAST(COALESCE(same_place,0) AS INTEGER)!=1 AND lat IS NOT NULL"):
        out.append(('S%d' % i, float(a), float(b)))
    return [x for x in out if _dist_m(la, lo, x[1], x[2]) <= r]


def rough_share(details):
    """GraphHopper path details → 흙길(포장 안 된 길) 거리 비율 0~1.
    details = {'distance': [[i0, i1, m] …], 'road_class': [[i0, i1, 값] …], 'surface': [...]}"""
    dist = details.get('distance') or []
    if not dist:
        return 0.0

    def at(name, i):
        for a, b, v in details.get(name) or []:
            if a <= i < b:
                return str(v or '').upper()
        return ''
    tot = rough = 0.0
    for a, _b, m in dist:
        m = float(m or 0)
        tot += m
        rc, sf = at('road_class', a), at('surface', a)
        if sf in ROUGH_SURF or (rc in ROUGH_CLASS and sf not in PAVED_SURF):
            rough += m
    return round(rough / tot, 2) if tot else 0.0


def _route(base, pa, pb):
    import urllib.request
    url = ('%s/route?point=%.6f,%.6f&point=%.6f,%.6f&profile=foot&points_encoded=false'
           '&details=road_class&details=surface&details=distance' % (base, pa[1], pa[2], pb[1], pb[2]))
    with urllib.request.urlopen(url, timeout=30) as r:
        return (json.loads(r.read().decode('utf-8')).get('paths') or [None])[0]


def paths(conn, base=GH_WALK, say=print, route_fn=None):
    """도보 구역마다 장소 두 곳씩 걷는 길을 잰다(멱등 · 덮어쓴다) → (쌍, 받음, 길 없음)"""
    import db_place_road as R
    ensure(conn)
    ensure_path(conn)
    fn = route_fn or (lambda pa, pb: _route(base, pa, pb))
    n = ok = none = 0
    for zone in conn.execute("SELECT code, lat, lng, radius_m FROM sys_pilgrim_walk_zone"
                             " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order").fetchall():
        cs = sorted(cands(conn, zone))
        zok = 0
        for i in range(len(cs)):
            for j in range(i + 1, len(cs)):
                pa, pb = cs[i], cs[j]
                n += 1
                straight = _dist_m(pa[1], pa[2], pb[1], pb[2]) / 1000.0
                try:
                    p = fn(pa, pb)
                except Exception:                              # noqa: BLE001
                    p = None
                good = bool(p) and p.get('distance') is not None and (
                    p['distance'] / 1000.0 <= max(straight * DETOUR_MAX, straight + 0.3))
                if not good:
                    conn.execute('DELETE FROM sys_pilgrim_walk_path WHERE a=? AND b=?', (pa[0], pb[0]))
                    none += 1
                    continue
                coords = [(c[1], c[0]) for c in ((p.get('points') or {}).get('coordinates') or [])]
                poly = R.encode(R.simplify(coords, 0.00005)) if len(coords) > 1 else None
                conn.execute("INSERT OR REPLACE INTO sys_pilgrim_walk_path VALUES(?,?,?,?,?,?,datetime('now'))",
                             (pa[0], pb[0], round(p['distance'] / 1000.0, 3), round(p.get('time', 0) / 60000.0, 1),
                              poly, rough_share(p.get('details') or {})))
                ok += 1
                zok += 1
        conn.commit()
        say('  %-10s 장소 %2d · 길 %d' % (zone[0], len(cs), zok))
    return n, ok, none


def course_minutes(conn, stops, pts):
    """코스 거리·걷는 시간 — 잰 길이 있으면 그것, 없는 구간은 직선 × 1.3 어림 · 곳마다 머무름"""
    km = tot = 0.0
    for i in range(1, len(pts)):
        a, b = sorted((stops[i - 1], stops[i]))
        try:
            r = conn.execute('SELECT km, minutes FROM sys_pilgrim_walk_path WHERE a=? AND b=?', (a, b)).fetchone()
        except Exception:                                      # noqa: BLE001
            r = None
        if r and r[1]:
            km += r[0]
            tot += r[1]
        else:
            k = walk_km([pts[i - 1], pts[i]])
            km += k
            tot += k / WALK_KMH * 60
    return round(km, 2), round(tot + STAY * len(pts))


def walk_km(pts):
    """직선 거리 합 × 1.3 (km)"""
    km = 0.0
    for (a, b), (c, d) in zip(pts, pts[1:]):
        km += math.hypot((c - a) * 111.0, (d - b) * 111.0 * math.cos(math.radians((a + c) / 2)))
    return km * DETOUR


def walk_minutes(pts):
    return round(walk_km(pts) / WALK_KMH * 60 + STAY * len(pts))


def _site_by_qid(conn):
    return {q: (sid, lat, lng) for sid, q, lat, lng in
            conn.execute("SELECT site_id, qid, lat, lng FROM sys_pilgrim_site WHERE status='LIVE'")}


def seed(conn, say=print):
    ensure(conn)
    for i, (code, names, lat, lng, r) in enumerate(ZONES):
        conn.execute('INSERT INTO sys_pilgrim_walk_zone(code, names, lat, lng, radius_m, sort_order) VALUES(?,?,?,?,?,?)'
                     ' ON CONFLICT(code) DO UPDATE SET names=excluded.names, lat=excluded.lat, lng=excluded.lng,'
                     " radius_m=excluded.radius_m, sort_order=excluded.sort_order, record_status='LIVE'",
                     (code, json.dumps(names, ensure_ascii=False, sort_keys=True), lat, lng, r, i))
    by = _site_by_qid(conn)
    miss = []
    for i, (code, zone, names, qids) in enumerate(COURSES):
        stops, pts = [], []
        for q in qids:
            if q not in by:
                miss.append((code, q))
                continue
            sid, la, lo = by[q]
            stops.append('S%d' % sid)
            pts.append((la, lo))
        conn.execute('INSERT INTO sys_pilgrim_walk_course(code, zone_code, names, stops, km, minutes, sort_order)'
                     ' VALUES(?,?,?,?,?,?,?) ON CONFLICT(code) DO UPDATE SET zone_code=excluded.zone_code,'
                     ' names=excluded.names, stops=excluded.stops, km=excluded.km, minutes=excluded.minutes,'
                     " sort_order=excluded.sort_order, record_status='LIVE'",
                     (code, zone, json.dumps(names, ensure_ascii=False, sort_keys=True), json.dumps(stops),
                      *course_minutes(conn, stops, pts), i))
        say('  %-16s %2d곳 · %.1fkm · %d분' % ((code, len(stops)) + course_minutes(conn, stops, pts)))
    conn.commit()
    for code, q in miss:
        say('  ⚠ %s — 순례 장소에 없음(승인 전이거나 안 받음): %s' % (code, q))
    return len(ZONES), len(COURSES), miss


def status(conn):
    ensure(conn)
    for code, nm, r in conn.execute('SELECT code, names, radius_m FROM sys_pilgrim_walk_zone ORDER BY sort_order'):
        print(code, json.loads(nm)['KO'], '%dm' % r)
    for code, z, st, mi in conn.execute('SELECT code, zone_code, stops, minutes FROM sys_pilgrim_walk_course ORDER BY sort_order'):
        print(' ', code, z, len(json.loads(st)), '곳', mi, '분')


def selftest():
    ok, bad = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(m)
    langs = {'KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR'}
    ck(all(set(z[1]) == langs and all(z[1].values()) for z in ZONES), '구역 이름 11언어')
    ck(all(set(c[2]) == langs and all(c[2].values()) for c in COURSES), '코스 이름 11언어')
    zc = {z[0] for z in ZONES}
    ck(all(c[1] in zc for c in COURSES), '코스의 구역이 있다')
    ck(len({c[0] for c in COURSES}) == len(COURSES) and len(zc) == len(ZONES), '열쇠가 겹치지 않는다')
    ck(abs(walk_km([(31.0, 35.0), (31.01, 35.0)]) - 1.11 * DETOUR) < 0.01, '거리 = 직선 × 1.3')
    ck(walk_minutes([(31.0, 35.0)]) == STAY, '한 곳 = 머무름만')
    # 흙길 비율 — 포장 안 된 구간 거리만 센다
    det = {'distance': [[0, 1, 100], [1, 2, 300]], 'road_class': [[0, 1, 'FOOTWAY'], [1, 2, 'TRACK']], 'surface': [[0, 2, 'MISSING']]}
    ck(rough_share(det) == 0.75, '흙길 비율 = 트랙 300/400')
    det2 = {'distance': [[0, 1, 100]], 'road_class': [[0, 1, 'PATH']], 'surface': [[0, 1, 'PAVING_STONES']]}
    ck(rough_share(det2) == 0.0, '포장된 오솔길은 흙길이 아니다')
    ck(rough_share({}) == 0.0, '빈 세부 = 0')
    # 길 재기 — 가짜 엔진으로(메모리 DB)
    import sqlite3
    m = sqlite3.connect(':memory:')
    m.execute('CREATE TABLE sys_entity_master(entity_id INTEGER, entity_type TEXT, geo_lat REAL, geo_lng REAL, record_status TEXT)')
    m.execute('CREATE TABLE sys_pilgrim_site(site_id INTEGER, lat REAL, lng REAL, status TEXT, same_place INTEGER)')
    ensure(m)
    m.execute("INSERT INTO sys_pilgrim_walk_zone(code,names,lat,lng,radius_m,sort_order) VALUES('Z','{}',31.0,35.0,500,0)")
    m.executemany('INSERT INTO sys_entity_master VALUES(?,?,?,?,?)', [(1, 'PLACE', 31.0, 35.0, 'LIVE'), (2, 'PLACE', 31.002, 35.0, 'LIVE'),
                                                                      (3, 'PLACE', 31.5, 35.0, 'LIVE')])
    m.execute("INSERT INTO sys_pilgrim_site VALUES(7, 31.0, 35.003, 'LIVE', 0)")

    def fake(pa, pb):
        if {pa[0], pb[0]} == {'S7', 'P2'}:
            return {'distance': 90000, 'time': 1}                 # 엉뚱하게 돌아감 → 버린다
        return {'distance': 300, 'time': 240000, 'points': {'coordinates': [[pa[2], pa[1]], [pb[2], pb[1]]]},
                'details': {'distance': [[0, 1, 300]], 'road_class': [[0, 1, 'TRACK']], 'surface': [[0, 1, 'DIRT']]}}
    n, okn, none = paths(m, say=lambda *_: None, route_fn=fake)
    ck((n, okn, none) == (3, 2, 1), '쌍 3 · 받음 2 · 돌아가는 길 버림 1 %s' % ((n, okn, none),))
    r = m.execute("SELECT km, minutes, rough, poly FROM sys_pilgrim_walk_path WHERE a='P1' AND b='P2'").fetchone()
    ck(bool(r) and r[0] == 0.3 and r[1] == 4.0 and r[2] == 1.0 and bool(r[3]), '거리·시간·흙길·선 %s' % (r,))
    ck(m.execute("SELECT COUNT(*) FROM sys_pilgrim_walk_path WHERE a='P3' OR b='P3'").fetchone()[0] == 0, '구역 밖은 안 잰다')
    km2, mi2 = course_minutes(m, ['P1', 'P2'], [(31.0, 35.0), (31.002, 35.0)])
    ck(km2 == 0.3 and mi2 == round(4.0 + STAY * 2), '코스 시간 = 잰 길 + 머무름 %s' % ((km2, mi2),))
    m.close()
    # 실제 DB — 코스 장소가 다 있고 구역 안에 드는가(반경 + 여유 250m)
    c = appdb.connect()
    try:
        by = _site_by_qid(c)
        zones = {z[0]: z for z in ZONES}
        for code, zone, _, qids in COURSES:
            miss = [q for q in qids if q not in by]
            ck(not miss, '%s 장소가 다 있다 %s' % (code, miss))
            z = zones[zone]
            far = [q for q in qids if q in by and
                   math.hypot((by[q][1] - z[2]) * 111000, (by[q][2] - z[3]) * 111000 * math.cos(math.radians(z[2]))) > z[4] + 250]
            ck(not far, '%s 코스가 구역 안에 %s' % (code, far))
    finally:
        c.close()
    for m in bad:
        print('FAIL', m)
    print('db_pilgrim_walk %d/%d %s' % (ok, ok + len(bad), 'PASS' if not bad else 'FAIL'))
    return not bad


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    if '--paths' in a:
        n, okn, none = paths(c)
        print('쌍 %d · 길 %d · 길 없음(점선) %d' % (n, okn, none))
        seed(c)
    elif '--seed' in a:
        nz, nc, miss = seed(c)
        print('구역 %d · 코스 %d · 빠진 것 %d' % (nz, nc, len(miss)))
    else:
        status(c)
