# -*- coding: utf-8 -*-
"""공동체몰 관리(PC) 알맹이 — 2026-10-28 신설·영구 (docs/공동체몰_약속.md · api 1).

교회 관리자가 PC 하가 앱 「설정 ▸ 공동체몰 관리」에서 쓰는 문. 화면은 `cmall_view.py`.
· 관리하는 몰 = `user_config['CMALL_ADMIN']` JSON [{url, name, church, pw}] — 이 PC 에만(배포 안 됨).
  ⚠ 비밀번호는 그 교회 시트의 관리자 비밀번호다. 우리 서버로는 아무것도 가지 않는다.
· 요청 = 약속의 GET ping·list / POST admin — `call` 을 바꿔 끼우면 시험한다(참고 서버 `cmall_ref.Mall`).
· 초대 글 = 폰 `CmallRepo.inviteTag` 와 **같은 꼬리표**(gzip + base64url) — 바꾸면 둘을 함께.
· 열쇠 글 = `[hagah:mallkey …]` — 주인이 폰을 바꿨을 때 관리자가 새 열쇠를 보낸다(폰이 받아 넣는다).
· ★ 2026-10-28 방식 둘 — **구글 시트 방식**(SHEET · 교회 시트가 서버) / **파일 방식**(FILE · 서버 없이 파일을 카톡으로).
  파일 몰은 이 PC 가 곧 서버다: 몰 하나 = `userdb.user_cmall_file` 한 줄(참고 구현 `cmall_ref.Mall` 을 그대로 돌린다) —
  그래서 화면은 두 방식을 같은 `Client` 로 다룬다(파일 몰은 망 대신 그 몰을 직접 부른다 · `fake_call`).

  python cmall_admin.py --selftest
"""
import base64
import gzip
import json
import re
import sys
import urllib.parse
import urllib.request

API = 1
CFG = 'CMALL_ADMIN'
CATS = ['음식점', '카페', '베이커리', '미용/뷰티', '의료/건강', '교육', '생활서비스', '패션/잡화', '안경', '자동차', '부동산',
        '온라인 쇼핑몰', '기타']
FIELDS = ('name', 'cat', 'intro', 'phone', 'addr', 'hours', 'owner', 'link', 'dc_on', 'dc_text', 'dc_until', 'photo',
          'mode', 'desc', 'photo2', 'photo3', 'photo4', 'photo5',  # ★ 2026-10-28 보이는 방식 · 긴 설명 · 사진 다섯
          'extra')  # ★ 2026-10-28 교회별 추가 칸
SUB_PHOTOS = ('photo2', 'photo3', 'photo4', 'photo5')
# ★ 2026-10-28 분류 = 앱이 정한 코드(시트에는 코드) — 폰 mobile/lib/data/cmall_cats.dart 와 같은 표 · 하나를 고치면 둘 다
CATS = (('FOOD', '음식점'), ('CAFE', '카페'), ('BAKERY', '베이커리 · 디저트'), ('GROCERY', '식료품 · 농수산물'),
        ('BEAUTY', '미용 · 뷰티'), ('MEDICAL', '병원 · 의원'), ('DENTAL', '치과'), ('PHARMACY', '약국'), ('FITNESS', '운동 · 건강'),
        ('EDU', '교육 · 학원'), ('KIDS', '육아 · 아동'), ('LIVING', '생활서비스(세탁 · 청소 · 수선)'),
        ('REPAIR', '수리 · 인테리어 · 건축'), ('FASHION', '패션 · 잡화'), ('OPTICAL', '안경'), ('AUTO', '자동차'),
        ('REALTY', '부동산'), ('PRO', '법률 · 세무 · 회계'), ('FINANCE', '보험 · 금융'), ('TRAVEL', '숙박 · 여행'),
        ('FLOWER', '꽃 · 선물'), ('PRINT', '인쇄 · 디자인 · 광고'), ('IT', 'IT · 컴퓨터 · 휴대폰'), ('MUSIC', '음악 · 악기'),
        ('PET', '반려동물'), ('ONLINE', '온라인 쇼핑몰'), ('ETC', '기타'))
_CAT_LEGACY = {'음식점': 'FOOD', '카페': 'CAFE', '베이커리': 'BAKERY', '미용/뷰티': 'BEAUTY', '의료/건강': 'MEDICAL', '교육': 'EDU',
               '생활서비스': 'LIVING', '패션/잡화': 'FASHION', '안경': 'OPTICAL', '자동차': 'AUTO', '부동산': 'REALTY',
               '온라인 쇼핑몰': 'ONLINE', '기타': 'ETC'}


def cat_code(raw):
    """시트 글자 → 코드(코드 · 옛 한국어 이름 · 지금 이름 · 모르면 ETC · 비었으면 '')."""
    s = ('%s' % (raw or '')).strip()
    if not s:
        return ''
    codes = {c for c, _k in CATS}
    if s.upper() in codes:
        return s.upper()
    if s in _CAT_LEGACY:
        return _CAT_LEGACY[s]
    return next((c for c, k in CATS if k == s), 'ETC')


def cat_name(raw):
    c = cat_code(raw)
    return next((_t('M_CMC_' + cc, k) for cc, k in CATS if cc == c), '')
DESC_MAX = 3000
TAG_MALL = '[hagah:mall '
TAG_KEY = '[hagah:mallkey '
ERR_TEXT = {
    'PW': ('CM_E_PW2', '관리자 비밀번호가 맞지 않습니다. 처음 연결이면 네 글자 이상으로 적으세요.'),
    'SET': ('CM_E_SET', '이 몰은 이미 다른 비밀번호로 열려 있습니다 — 처음 정한 비밀번호를 적으세요.'),
    'NET': ('CM_E_NET', '주소에 닿지 못했습니다 — 주소와 인터넷을 확인하세요.'),
    'FORM': ('CM_E_FORM', '답의 꼴이 공동체몰 약속과 다릅니다 — 웹 앱 주소(…/exec)가 맞는지, 액세스가 「모든 사용자」인지 보세요.'),
    'API': ('CM_E_API', '이 앱보다 새 약속을 쓰는 서버입니다 — 하가 앱을 새 판으로 바꾸세요.'),
    'ID': ('CM_E_ID', '그 가게를 찾지 못했습니다(시트에서 지워졌을 수 있습니다).'),
}


def _t(k, d):
    try:
        import i18n
        return i18n.t(k, d)
    except Exception:
        return d


def err_text(code):
    k, d = ERR_TEXT.get(code, ('CM_E_ANY', '하지 못했습니다(%s).'))
    s = _t(k, d)
    return s % code if '%s' in s else s


# ── 주고받기 ──────────────────────────────────────────────────────────
def _http(url, body=None, timeout=25):
    """GET(body None) 또는 POST JSON → dict | None. Apps Script 의 302 는 urllib 이 GET 으로 따라간다."""
    try:
        if body is None:
            req = urllib.request.Request(url, headers={'User-Agent': 'Hagah'})
        else:
            req = urllib.request.Request(url, data=json.dumps(body, ensure_ascii=False).encode('utf-8'),
                                         headers={'Content-Type': 'application/json', 'User-Agent': 'Hagah'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read().decode('utf-8'))
            return d if isinstance(d, dict) else None
    except Exception:
        return None


def _q(url, a):
    return url + ('&' if '?' in url else '?') + 'a=' + a


class Client:
    """몰 하나(주소 + 관리자 비밀번호). `call(url, body)` 를 바꾸면 시험."""

    def __init__(self, url, pw='', call=None):
        self.url = (url or '').strip()
        self.pw = pw or ''
        self.call = call or _http

    def ping(self):
        d = self.call(_q(self.url, 'ping'), None)
        return self._chk(d)

    def _chk(self, d):
        if d is None:
            return {'ok': False, 'err': 'NET'}
        if 'ok' not in d or 'api' not in d and d.get('ok') is True and 'rows' not in d:
            return {'ok': False, 'err': 'FORM'}
        if d.get('ok') is True and int(d.get('api') or 0) > API:
            return {'ok': False, 'err': 'API'}
        return d

    def admin(self, op, **kw):
        b = {'a': 'admin', 'pw': self.pw, 'op': op}
        b.update(kw)
        d = self.call(self.url, b)
        if d is None:
            return {'ok': False, 'err': 'NET'}
        if 'ok' not in d:
            return {'ok': False, 'err': 'FORM'}
        return d

    def connect(self, name='', church=''):
        """[연결] — 갓 배포한 몰(비밀번호가 빈 시트)이면 이름·교회·비밀번호를 처음 한 번 적고,
        이미 열린 몰이면 비밀번호를 맞춰 본 뒤 이름·교회가 적혀 있으면 고친다 → test() 와 같은 꼴."""
        h = self.ping()
        if not h.get('ok'):
            return False, err_text(h.get('err', 'FORM')), h
        if h.get('setup'):
            if len(self.pw) < 4:
                return False, err_text('PW'), h
            d = self.admin('init', name=(name or '').strip(), church=(church or '').strip())
            if not d.get('ok'):
                return False, err_text(d.get('err', 'FORM')), h
        else:
            m = h.get('mall') or {}
            kw = {}
            if (name or '').strip() and name.strip() != m.get('name'):
                kw['name'] = name.strip()
            if (church or '').strip() and church.strip() != m.get('church'):
                kw['church'] = church.strip()
            if kw:
                self.admin('settings', **kw)
        return self.test()

    def test(self):
        """[연결 시험] — ping 이 약속의 꼴로 오고 관리자 비밀번호가 맞는가 → (ok, 글, 머리)"""
        h = self.ping()
        if not h.get('ok'):
            return False, err_text(h.get('err', 'FORM')), h
        a = self.admin('all')
        if not a.get('ok'):
            return False, err_text(a.get('err', 'FORM')), h
        m = h.get('mall') or {}
        n = len([r for r in a.get('rows', []) if r.get('state') == 'PENDING'])
        return True, _t('CM_OK', '연결됨 · %s · 게시 %d · 대기 %d') % (m.get('name') or '?', int(h.get('count') or 0), n), h


# ── 이 PC 에 적어 두는 몰 목록 ─────────────────────────────────────────
def load(conn):
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (CFG,)).fetchone()
        v = json.loads(r[0]) if r and r[0] else []
        return [x for x in v if isinstance(x, dict) and x.get('url')]
    except Exception:
        return []


def save(conn, malls):
    v = json.dumps(malls, ensure_ascii=False)
    cur = conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (v, CFG))
    if cur.rowcount == 0:
        conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (CFG, v))
    conn.commit()


def upsert(malls, url, **kw):
    for m in malls:
        if m['url'] == url:
            m.update({k: v for k, v in kw.items() if v is not None})
            return malls
    malls.append(dict({'url': url, 'name': '', 'church': '', 'pw': ''}, **{k: v for k, v in kw.items() if v is not None}))
    return malls


# ── 카톡으로 보낼 글 ───────────────────────────────────────────────────
def _tag(head, obj):
    raw = gzip.compress(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
    return head + base64.urlsafe_b64encode(raw).decode('ascii') + ']'


def _b64(obj):
    raw = gzip.compress(json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def link(url, obj):
    """초대·열쇠 링크 = 그 몰의 웹 앱 주소 + ?hagah=<꼬리표와 같은 글>. 누르면 몰 스크립트가 「하가에서 열기」 쪽을
    보이고, 그 단추가 하가(hagah://open?d=…)를 연다 — 글을 선택하거나 복사할 일이 없다. 하가 서버는 안 거친다."""
    return url + ('&' if '?' in url else '?') + 'hagah=' + _b64(obj)


_LINK_RE = re.compile(r'(?:[?&]hagah=|hagah://open\?d=)([A-Za-z0-9_=-]+)')
_APP_OF = {TAG_MALL: 'hagah-mall', TAG_KEY: 'hagah-mallkey'}


def parse_tag(text, head=TAG_MALL):
    """꼬리표 [hagah:mall …] 또는 링크(…?hagah=… · hagah://open?d=…) — 링크는 안의 app 으로 갈래를 가른다."""
    i = text.find(head)
    if i < 0:
        for mt in _LINK_RE.finditer(text or ''):
            b = mt.group(1)
            try:
                b += '=' * (-len(b) % 4)
                d = json.loads(gzip.decompress(base64.urlsafe_b64decode(b)).decode('utf-8'))
            except Exception:
                continue
            if isinstance(d, dict) and d.get('app') == _APP_OF.get(head):
                return d
        return None
    j = text.find(']', i)
    if j < 0:
        return None
    b = ''.join(text[i + len(head):j].split())
    try:
        b += '=' * (-len(b) % 4)
        return json.loads(gzip.decompress(base64.urlsafe_b64decode(b)).decode('utf-8'))
    except Exception:
        return None


def invite_text(url, name, church, role, form=None):
    """성도 초대(MEMBER) · 사장님 초대(OWNER) · 관리자 폰으로(ADMIN) — 붙여 넣을 글 전부.
    ADMIN = 관리자 자기 폰에 담는 글(PC 에 카톡이 없을 때 · 이메일·문자 무엇으로든). 그 폰은 성도·사장님
    초대를 둘 다 나눌 수 있다. ⚠ 관리자 비밀번호는 안 든다 — 공개되어도 할 수 있는 일은 초대 나누기뿐."""
    if role == 'ADMIN':
        lines = [_t('CM_INV_ADMIN_H', '「%s」 관리자 폰으로 옮기기') % name,
                 _t('CM_INV_ADMIN_L', '폰에서 아래 링크를 누르고 「하가에서 열기」를 누르세요. 그 폰의 공동체몰 ⋯ 「이 몰 나누기」에서 '
                                      '성도 초대·사장님 초대를 카톡으로 보낼 수 있습니다. 다른 사람에게 보내지 마세요.')]
    elif role == 'OWNER':
        lines = [_t('CM_INV_OWNER_H', '「%s」 사장님 초대') % name,
                 _t('CM_INV_OWNER_L', '성도님의 가게를 공동체몰에 등록해 주세요. 아래 링크를 누르고 「하가에서 열기」를 누르면 '
                                      '몰 화면 위 ⋯ 에 「내 가게 등록」이 생깁니다. 보내신 내용은 관리자가 확인한 뒤 게시됩니다.')]
    else:
        lines = [_t('CM_INV_MEMBER_H', '「%s」 — 우리 교회 성도들의 가게 모음') % name,
                 _t('CM_INV_MEMBER_L', '아래 링크를 누르고 「하가에서 열기」를 누르세요(하가 앱이 있는 안드로이드 폰).')]
    if church:
        lines.insert(1, church)
    inv = {'app': 'hagah-mall', 'v': 1, 'url': url, 'name': name, 'church': church, 'role': role}
    if ('%s' % url).startswith('file:'):
        # 파일 몰 — 서버가 없으니 링크는 앱 링크 그대로 · 사장님 폰이 등록 화면을 그리도록 서식을 함께 싣는다
        inv.update({'mode': MODE_FILE, 'form': form or {}})
        if role == 'MEMBER':
            lines[-1] = _t('CM_INV_FMEMBER_L', '아래 링크를 누르면 하가에 이 몰이 담깁니다. 가게 목록은 관리자가 카톡방에 올리는 몰 파일로 받습니다.')
        return '\n'.join(lines + ['', 'hagah://open?d=' + _b64(inv)])
    return '\n'.join(lines + ['', link(url, inv)])


def key_text(url, name, sid, key, store_name):
    """새 열쇠 — 그 사장님께만 보낸다(폰이 받으면 그 가게를 다시 고칠 수 있다)."""
    return '\n'.join([_t('CM_KEY_H', '「%s」 · %s 가게 열쇠') % (name, store_name),
                      _t('CM_KEY_L', '아래 링크를 누르고 「하가에서 열기」를 누르면 이 폰에서 가게를 다시 고칠 수 있습니다. '
                                     '다른 사람에게 보내지 마세요.'),
                      '', (('hagah://open?d=' + _b64(dict(app='hagah-mallkey', v=1, url=url, id='%s' % sid, key=key)))
                           if ('%s' % url).startswith('file:')   # 파일 몰 — 서버 쪽이 없으니 앱 링크 그대로
                           else link(url, {'app': 'hagah-mallkey', 'v': 1, 'url': url, 'id': '%s' % sid, 'key': key}))])


def _extra(v):
    if isinstance(v, str):
        try:
            v = json.loads(v or '{}')
        except Exception:
            v = {}
    return {k: ('%s' % t).strip() for k, t in (v or {}).items() if ('%s' % (t or '')).strip()} if isinstance(v, dict) else {}


def diff_fields(a, b):
    """고침 견주기 — 바뀐 칸 이름들(사진은 글자 그대로 견준다 · 추가 칸은 `x:f1` 처럼 칸마다)."""
    out = []
    for f in FIELDS:
        x, y = (a or {}).get(f, ''), (b or {}).get(f, '')
        if f == 'extra':
            ea, eb = _extra(x), _extra(y)
            out += ['x:' + k for k in sorted(set(ea) | set(eb)) if ea.get(k, '') != eb.get(k, '')]
            continue
        if f == 'dc_on':
            x, y = bool(x) and x not in ('false', 'FALSE', 0), bool(y) and y not in ('false', 'FALSE', 0)
        elif f == 'cat':
            x, y = cat_code(x), cat_code(y)
        if ('%s' % x).strip() != ('%s' % y).strip():
            out.append(f)
    return out


# ── 파일 방식 — 이 PC 가 곧 서버 ──────────────────────────────────────────
MODE_SHEET, MODE_FILE = 'SHEET', 'FILE'
FILE_PW = 'local-file-mall'   # 파일 몰의 관리자 비밀번호(이 PC 안에서만 · 밖으로 안 나간다)
FILE_TABLE = 'user_cmall_file'


def is_file(m):
    return (m or {}).get('mode') == MODE_FILE or ('%s' % (m or {}).get('url', '')).startswith('file:')


def _tbl(conn):
    """개인 DB 의 표 이름(appdb 연결이면 userdb. · 시험 DB 면 그대로) — 없으면 만든다."""
    try:
        dbs = {r[1] for r in conn.execute('PRAGMA database_list')}
    except Exception:
        dbs = set()
    t = ('userdb.' if 'userdb' in dbs else '') + FILE_TABLE
    conn.execute('CREATE TABLE IF NOT EXISTS %s(file_id TEXT PRIMARY KEY, data TEXT, updated_at TEXT)' % t)
    return t


class FileMall:
    """파일 몰 하나 — 참고 구현 Mall 을 그대로 쓰고 저장만 개인 DB 로(사진까지 · 백업에 함께 들어간다)."""

    def __new__(cls, opener, file_id, name='', church=''):
        import cmall_ref

        class _M(cmall_ref.Mall):
            def _save(self):
                with opener() as c:
                    t = _tbl(c)
                    c.execute('INSERT OR REPLACE INTO %s(file_id, data, updated_at) VALUES(?,?,datetime(\'now\'))' % t,
                              (file_id, json.dumps(self.d, ensure_ascii=False)))
        m = _M(None, pw=FILE_PW, name=name, church=church, file_id=file_id)
        with opener() as c:
            r = c.execute('SELECT data FROM %s WHERE file_id=?' % _tbl(c), (file_id,)).fetchone()
        if r and r[0]:
            m.d = json.loads(r[0])
            m.d['settings'].setdefault('form', cmall_ref.clean_form({}))
            m.d['settings']['file_id'] = file_id
        else:
            m._save()
        return m


_FILE_MALLS = {}


def file_mall(opener, m):
    """이 PC 의 파일 몰(한 번 읽으면 기억)."""
    fid = m['url']
    if fid not in _FILE_MALLS:
        _FILE_MALLS[fid] = FileMall(opener, fid, m.get('name') or '', m.get('church') or '')
    return _FILE_MALLS[fid]


def client_for(m, opener, call=None):
    """몰 하나의 Client — 시트 몰은 망(또는 시험 call) · 파일 몰은 이 PC 의 몰을 직접."""
    if is_file(m):
        return Client(m['url'], FILE_PW, call=fake_call(file_mall(opener, m)))
    return Client(m.get('url', ''), m.get('pw', ''), call=call)


def new_file_mall(opener, name, church):
    import cmall_ref
    fid = cmall_ref.new_file_id()
    file_mall(opener, {'url': fid, 'name': name, 'church': church})
    return {'url': fid, 'name': name, 'church': church, 'pw': '', 'mode': MODE_FILE}


def out_dir():
    """몰 파일을 두는 폴더 — 문서 ▸ Hagah 공동체몰(메일로 보낼 때 여기서 고른다)."""
    import os
    d = os.path.join(os.path.expanduser('~'), 'Documents', 'Hagah 공동체몰')
    os.makedirs(d, exist_ok=True)
    return d


def _safe(s):
    return re.sub(r'[\\/:*?"<>|\s]+', '_', ('%s' % s).strip()) or 'mall'


def write_mall_file(mall, folder=None, opener=None):
    """[몰 파일 만들기] — 게시된 가게 전부 → `<몰이름>_<날짜>.hagah.json` · (경로, 가게 수, 판, MB).
    opener 가 있으면 개인 DB `user_cmall_outfile` 에도 적는다 → 다음 PC 동기화 때 관리자 폰으로 간다(그 폰이 카톡으로 나눈다)."""
    import os
    from datetime import date
    d = mall.mall_file()
    folder = folder or out_dir()
    p = os.path.join(folder, '%s_%s.hagah.json' % (_safe(d['mall']['name']), date.today().isoformat()))
    raw = json.dumps(d, ensure_ascii=False, separators=(',', ':'))
    with open(p + '.tmp', 'w', encoding='utf-8') as f:
        f.write(raw)
    os.replace(p + '.tmp', p)
    if opener is not None:
        with opener() as c:
            dbs = {r[1] for r in c.execute('PRAGMA database_list')}
            t = ('userdb.' if 'userdb' in dbs else '') + 'user_cmall_outfile'
            c.execute('CREATE TABLE IF NOT EXISTS %s(file_id TEXT PRIMARY KEY, name TEXT, ver INTEGER, made TEXT, data TEXT)' % t)
            c.execute('INSERT OR REPLACE INTO %s(file_id, name, ver, made, data) VALUES(?,?,?,?,?)' % t,
                      (d['mall']['id'], d['mall']['name'], d['ver'], d['made'], raw))
    return p, len(d['stores']), d['ver'], len(raw.encode('utf-8')) / 1e6


def take_store_files(mall, paths):
    """[가게 파일 넣기] — 사장님 가게 파일 여럿 → 대기로 · [(파일 이름, 결과)]."""
    import os
    out = []
    for p in paths:
        try:
            with open(p, encoding='utf-8') as f:
                d = json.load(f)
            r = mall.take(d)
        except Exception:
            r = {'ok': False, 'err': 'FORM'}
        out.append((os.path.basename(p), r))
    return out


def take_text(r):
    """가게 파일 하나의 결과 → 사람 말."""
    if r.get('ok'):
        return {'new': _t('CM_TAKE_NEW', '새 가게 → 대기'), 'edit': _t('CM_TAKE_EDIT', '고침 → 대기'),
                'drop': _t('CM_TAKE_DROP', '내리기 → 대기')}.get(r.get('op'), _t('CM_TAKE_NEW', '새 가게 → 대기'))
    return {'MALL': _t('CM_TAKE_E_MALL', '다른 몰의 파일입니다'), 'KEY': _t('CM_TAKE_E_KEY', '열쇠가 맞지 않습니다(다른 사람이 보낸 글)'),
            'APP': _t('CM_TAKE_E_APP', '가게 파일이 아닙니다'), 'NAME': _t('CM_TAKE_E_NAME', '가게 이름이 비었습니다')}.get(
        r.get('err'), err_text(r.get('err', 'FORM')))


def next_key(form, rows):
    """새 추가 칸 열쇠 — 서식의 칸과 가게 글에 남은 칸(지운 칸 포함) 가운데 가장 큰 번호 + 1."""
    n = [int(x['k'][1:]) for x in (form or {}).get('fields') or [] if re.fullmatch(r'f\d+', x.get('k', ''))]
    for r in rows or []:
        n += [int(k[1:]) for k in _extra(r.get('extra')) if re.fullmatch(r'f\d+', k)]
    return 'f%d' % ((max(n) if n else 0) + 1)


# ── 시험 ───────────────────────────────────────────────────────────────
def fake_call(mall):
    """참고 서버(cmall_ref.Mall)를 이 프로세스 안에서 — 망 없이."""
    def call(url, body):
        if body is None:
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
            return json.loads(json.dumps(mall.handle('GET', qs, '')))
        return json.loads(json.dumps(mall.handle('POST', {}, json.dumps(body))))
    return call


def selftest():
    import sqlite3
    import cmall_ref
    ok, bad = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(m)

    m = cmall_ref.Mall(None, pw='pw1', name='하나몰', church='수원하나교회')
    cmall_ref.seed(m)
    c = Client('https://x/exec', 'pw1', call=fake_call(m))
    good, msg, h = c.test()
    ck(good and '하나몰' in msg, '연결 시험 성공')
    ck(not Client('https://x/exec', 'no', call=fake_call(m)).test()[0], '비밀번호 틀림 → 실패')
    ck(Client('https://x/exec', 'pw1', call=lambda u, b: None).test()[1] == err_text('NET'), '망 없음')
    ck(Client('https://x/exec', 'pw1', call=lambda u, b: {'hello': 1}).ping().get('err') == 'FORM', '엉뚱한 답 = 꼴 다름')
    ck(Client('https://x/exec', 'pw1', call=lambda u, b: {'ok': True, 'api': 9}).ping().get('err') == 'API', '새 약속')
    # 초대 꼬리표 — 폰과 같은 꼴
    t = invite_text('https://x/exec', '하나몰', '수원하나교회', 'OWNER')
    inv = parse_tag(t)
    ck(inv and inv['role'] == 'OWNER' and inv['url'] == 'https://x/exec' and inv['app'] == 'hagah-mall', '초대 꼬리표 왕복')
    ck(t.splitlines()[-1].startswith('https://x/exec?hagah=') and '수원하나교회' in t and '[hagah:' not in t, '초대 글 = 링크 한 줄로 끝난다')
    ck(parse_tag('hagah://open?d=' + _b64({'app': 'hagah-mall', 'url': 'https://y/exec'}))['url'] == 'https://y/exec', '앱 링크도 읽는다')
    ck(parse_tag(t, TAG_KEY) is None, '초대 링크를 열쇠로 읽지 않는다')
    ck(cat_code('카페') == 'CAFE' and cat_code('cafe') == 'CAFE' and cat_code('의료/건강') == 'MEDICAL' and cat_code('뭔지') == 'ETC'
       and cat_code('') == '', '분류 코드 — 옛 이름 · 모르면 기타')
    ck(diff_fields({'cat': '카페'}, {'cat': 'CAFE'}) == [], '옛 이름과 코드는 같은 분류')
    try:
        import os
        d = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mobile', 'lib', 'data', 'cmall_cats.dart'), encoding='utf-8').read()
        ck(re.findall(r"CmallCat\('([A-Z]+)', '([^']+)'", d) == list(CATS), '폰 분류 표와 같다(cmall_cats.dart)')
    except OSError:
        pass  # 배포 꾸러미에는 폰 코드가 없다
    ta = invite_text('https://x/exec', '하나몰', '', 'ADMIN')
    ck((parse_tag(ta) or {}).get('role') == 'ADMIN' and 'pw1' not in ta, '관리자 폰 글 — 비밀번호 없음')
    # 처음 연결 — 빈 시트를 PC 가 채운다
    m0 = cmall_ref.Mall(None, pw='', name='', church='')
    c0 = Client('https://y/exec', 'ab', call=fake_call(m0))
    ck(not c0.connect('새몰', '새교회')[0], '짧은 비밀번호로는 안 연다')
    c0.pw = 'abcd'
    g0, msg0, _ = c0.connect('새몰', '새교회')
    ck(g0 and '새몰' in msg0 and m0.d['settings']['pw'] == 'abcd', '처음 연결 = 이름·교회·비밀번호를 시트에')
    ck(not Client('https://y/exec', 'zzzz', call=fake_call(m0)).connect('딴몰')[0] and m0.d['settings']['name'] == '새몰',
       '열린 몰에 다른 비밀번호 → 거부 · 이름 안 바뀜')
    ck(c0.connect('새몰2')[0] and m0.d['settings']['name'] == '새몰2', '맞는 비밀번호면 이름 고침')
    kt = key_text('https://x/exec', '하나몰', '3', 'abc', '행복 치과')
    ck((parse_tag(kt, TAG_KEY) or {}).get('key') == 'abc', '열쇠 꼬리표')
    # 관리 왕복 — 주인이 고쳐 보내면 견주고 게시
    r = m.submit({'op': 'new', 'store': {'name': '새 가게', 'cat': '카페'}})
    rows = c.admin('all')['rows']
    pend = [x for x in rows if x['state'] == 'PENDING']
    ck(len(pend) == 1 and pend[0]['kind'] == 'NEW', '대기 하나')
    ck(c.admin('publish', id=pend[0]['id'])['ok'] and c.ping()['count'] == 4, '게시')
    m.submit({'op': 'edit', 'id': r['id'], 'key': r['key'], 'store': {'name': '새 가게', 'cat': '카페', 'dc_on': True, 'dc_text': '10%'}})
    rows = c.admin('all')['rows']
    e = [x for x in rows if x['state'] == 'PENDING'][0]
    base = [x for x in rows if x['id'] == e['ref']][0]
    ck(diff_fields(base, e) == ['dc_on', 'dc_text'], '고침 견주기 = 바뀐 칸만')
    ck(c.admin('hold', id=e['id'])['ok'], '보류')
    # 이 PC 의 몰 목록
    conn = sqlite3.connect(':memory:')
    conn.execute('CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
    save(conn, upsert(load(conn), 'https://x/exec', name='하나몰', pw='pw1'))
    save(conn, upsert(load(conn), 'https://x/exec', church='수원하나교회'))
    L = load(conn)
    ck(len(L) == 1 and L[0]['pw'] == 'pw1' and L[0]['church'] == '수원하나교회', '몰 목록 저장 · 고침')
    # ★ 파일 방식 — 이 PC 의 몰 · 가게 파일 넣기 · 몰 파일 만들기 · 서식 · 추가 칸 견주기
    import tempfile
    import os
    tdb = os.path.join(tempfile.mkdtemp(), 'u.db')

    class _O:
        def __enter__(self):
            self.c = sqlite3.connect(tdb)
            return self.c

        def __exit__(self, *a):
            self.c.commit()
            self.c.close()
    fm = new_file_mall(_O, '파일몰', '새교회')
    ck(is_file(fm) and fm['url'].startswith('file:'), '파일 몰 = file: 열쇠')
    cf = client_for(fm, _O)
    ck(cf.test()[0], '파일 몰도 같은 Client 로 연결 시험')
    form = {'guide': '안내', 'fields': [{'k': 'f1', 'label': '교인 할인 내용', 'shape': 'BOX'}], 'cats': ['CAFE']}
    ck(cf.admin('settings', form=form)['form']['fields'][0]['label'] == '교인 할인 내용', '파일 몰 서식 저장')
    _FILE_MALLS.clear()
    mall2 = file_mall(_O, fm)
    ck(mall2.form['guide'] == '안내', '개인 DB 에 남는다(다시 읽어도 서식)')
    sid, key = cmall_ref.new_sid(), 'k' * 24
    d = tempfile.mkdtemp()
    sp = os.path.join(d, 'a.hagah.json')
    json.dump(cmall_ref.store_file(fm['url'], 'new', sid, key, {'name': '파일가게', 'cat': 'CAFE', 'extra': {'f1': '10%'}}),
              open(sp, 'w', encoding='utf-8'))
    bp = os.path.join(d, 'b.hagah.json')
    json.dump(cmall_ref.store_file('file:00', 'new', sid, key, {'name': 'x'}), open(bp, 'w', encoding='utf-8'))
    res = take_store_files(mall2, [sp, bp])
    ck(res[0][1]['ok'] and not res[1][1]['ok'] and '다른 몰' in take_text(res[1][1]), '가게 파일 넣기 — 다른 몰은 거부')
    ck(client_for(fm, _O).admin('publish', id=sid)['ok'], '게시')
    path, n, ver, mb = write_mall_file(file_mall(_O, fm), d, opener=_O)
    with _O() as c0:
        ck(c0.execute('SELECT ver FROM user_cmall_outfile WHERE file_id=?', (fm['url'],)).fetchone()[0] == ver,
           '몰 파일이 개인 DB 에도(관리자 폰으로 갈 것)')
    got = cmall_ref.read_mall_file(open(path, encoding='utf-8').read())
    ck(n == 1 and got['ver'] == ver == 1 and got['stores'][0]['extra'] == {'f1': '10%'} and path.endswith('.hagah.json'),
       '몰 파일 만들기 — 가게 · 판 · 추가 칸')
    ti = invite_text(fm['url'], '파일몰', '새교회', 'OWNER', form=mall2.form)
    iv = parse_tag(ti)
    ck(iv and iv['mode'] == 'FILE' and iv['form']['guide'] == '안내' and 'hagah://open?d=' in ti, '파일 몰 사장님 초대 = 앱 링크 + 서식')
    ck(diff_fields({'extra': {'f1': 'a'}}, {'extra': '{"f1":"b","f2":"c"}'}) == ['x:f1', 'x:f2'], '추가 칸 견주기')
    ck(next_key(form, [{'extra': {'f7': 'x'}}]) == 'f8', '새 칸 열쇠 — 지운 칸의 번호도 다시 안 쓴다')
    print('cmall_admin selftest %d/%d' % (ok, ok + len(bad)))
    for b in bad:
        print('  FAIL', b)
    return not bad


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
