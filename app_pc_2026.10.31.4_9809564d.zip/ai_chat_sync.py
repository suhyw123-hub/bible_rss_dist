# -*- coding: utf-8 -*-
"""AI 대화를 폰과 PC 가 함께 쓴다 · 대화 정리 · 휴지통(2026-10-20 사용자 확정).

★ 대화 하나 = JSON 문서 하나(바통 넘기기)
  {uid, title, kind, start_vid, end_vid, lang, edits, by, history:[{by, edits, at}], saved, trashed_at, share, msgs:[…]}
  · 고칠 때마다 `edits` 가 1 늘고 `by` = 고친 쪽(PC · PHONE).
  · 보낼 것 = 「함께 쓰기」를 켠 대화 가운데 마지막으로 주고받은 뒤 바뀐 것(`edits != synced_edits`)만.
  · 받을 때 규칙 하나 — 내 쪽이 그사이 안 고쳤으면(`edits == synced_edits`) 받은 문서로 바꾼다 ·
    양쪽 다 고쳤으면 **지우지도 섞지도 않고** 받은 것을 사본으로 하나 더 둔다(「(폰에서 이어 씀)」 · 함께 쓰기 켬).
★★ 2026-10-21 사용자 「모든 대화를 동기화하는 방향 · 폰에서 [PC에 저장] 단추를 걷은 것과 같은 흐름」 —
  **모든 대화가 오간다.** 대화마다 켜고 끄던 「함께 쓰기」·새 대화 처음 값 설정은 걷었다(`share` 칸은 늘 1).
  그전에 꺼 두어 한 번도 안 간 대화는 `init` 이 한 번 보낼 것으로 만든다.
★ 정리 — 기간(○개월 이전) · 저장하지 않은 대화만 → 휴지통(`record_status='TRASH'` · `trashed_at`) ·
  30일 뒤 완전히 지운다(`purge`) · 휴지통으로 보내기·되살리기도 고침이라 함께 쓰는 대화면 상대에게도 간다.
⚠ 검증 전 원래 답(`raw`)은 보내지 않는다 — 다른 기기에는 필요 없다(크기를 줄인다).

  python ai_chat_sync.py --selftest
"""
import json
import os
import secrets
import sys
import time

import user_ai as UA

SHARE_DEFAULT_KEY = 'AI_SHARE_DEFAULT'
TRASH_DAYS = 30
NOTICE_MONTHS = 6
NOTICE_MIN = 100


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def new_uid():
    return secrets.token_hex(8)


def init(conn):
    """칸 — 멱등(user_ai.init 이 칸을 더하고 여기는 빈 uid 를 채운다)."""
    UA.init(conn)
    for (cid,) in conn.execute("SELECT chat_id FROM user_ai_chat WHERE COALESCE(phone_uid,'')=''").fetchall():
        conn.execute("UPDATE user_ai_chat SET phone_uid=? WHERE chat_id=?", (new_uid(), cid))
    # ★ 2026-10-21 모든 대화를 함께 쓴다 — 꺼 두었던 것은 한 번 보낼 것으로(받는 쪽은 고유번호로 갈아 끼운다)
    #   한 번만(`AI_SHARE_ALL`) — 받는 길이 문서를 다시 적을 때마다 돌면 변경 기록이 쌓인다
    if not UA.get_setting(conn, 'AI_SHARE_ALL', ''):
        conn.execute("UPDATE user_ai_chat SET share=1, share_sent=1, synced_edits=-1 WHERE COALESCE(share,0)=0")
        UA.set_setting(conn, 'AI_SHARE_ALL', _now())
    conn.commit()


def share_default(conn):
    """★ 2026-10-21 모든 대화를 함께 쓴다 — 늘 참(옛 설정 `AI_SHARE_DEFAULT` 는 안 읽는다)."""
    return True


def set_share_default(conn, on):
    """옛 문 — 아무것도 안 한다(모든 대화를 함께 쓴다)."""
    return None


def bump(conn, chat_id, by='PC'):
    """고쳤다 — 고친 횟수 1 · 마지막으로 고친 쪽."""
    conn.execute("UPDATE user_ai_chat SET edits=COALESCE(edits,0)+1, last_by=?, updated_at=? WHERE chat_id=?",
                 (by, _now(), chat_id))


# ── 문서 ─────────────────────────────────────────────────────────────
def doc(conn, chat_id):
    r = conn.execute("SELECT phone_uid, title, prompt_kind, start_vid, end_vid, lang_code, COALESCE(edits,0),"
                     " COALESCE(last_by,'PC'), COALESCE(history,'[]'), COALESCE(saved,0), trashed_at,"
                     " COALESCE(share,0), COALESCE(record_status,'LIVE'), provider, model, entity_id"
                     " FROM user_ai_chat WHERE chat_id=?", (chat_id,)).fetchone()
    if not r:
        return None
    try:
        hist = json.loads(r[8] or '[]')
    except ValueError:
        hist = []
    msgs = []
    for role, body, prov, model, mk, tg in conn.execute(
            "SELECT role, body, provider, model, COALESCE(mkind,''), COALESCE(target,'') FROM user_ai_msg"
            " WHERE chat_id=? AND role IN ('user','ai') ORDER BY msg_id", (chat_id,)):
        m = {'role': role, 'body': body or ''}
        if role == 'ai':
            m.update({'provider': prov or '', 'model': model or '', 'mkind': mk, 'target': tg})
        msgs.append(m)
    return {'uid': r[0], 'title': r[1] or '', 'kind': r[2] or '', 'start_vid': r[3], 'end_vid': r[4],
            'lang': r[5] or 'KO', 'edits': int(r[6]), 'by': r[7], 'history': hist, 'saved': bool(r[9]),
            'trashed_at': r[10] if r[12] == 'TRASH' else None, 'share': bool(r[11]),
            'provider': r[13] or '', 'model': r[14] or '', 'entity_id': r[15], 'msgs': msgs}


def _write_msgs(conn, cid, d):
    conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (cid,))
    for m in d.get('msgs') or []:
        role = m.get('role') if m.get('role') in ('user', 'ai') else 'user'
        mk = (m.get('mkind') or '') if role == 'ai' else ''
        if mk not in ('', 'INTEG', 'SELF'):
            mk = ''
        conn.execute("INSERT INTO user_ai_msg(chat_id, role, body, ts, provider, model, target, mkind)"
                     " VALUES(?,?,?,?,?,?,?,?)",
                     (cid, role, m.get('body') or '', _now(), m.get('provider') or d.get('provider') or '',
                      m.get('model') or d.get('model') or '', (m.get('target') or '') if mk else '', mk))


def _set_meta(conn, cid, d, synced):
    trashed = d.get('trashed_at')
    hist = list(d.get('history') or [])
    if synced >= 0:                                       # 오간 기록 — 받은 때
        hist = (hist + [{'by': d.get('by') or '', 'edits': int(d.get('edits') or 0), 'at': _now()}])[-50:]
    d = dict(d, history=hist)
    conn.execute("UPDATE user_ai_chat SET title=?, edits=?, last_by=?, history=?, saved=?, share=?,"
                 " trashed_at=?, record_status=?, synced_edits=?, updated_at=? WHERE chat_id=?",
                 (d.get('title') or '', int(d.get('edits') or 0), d.get('by') or 'PHONE',
                  json.dumps(d.get('history') or [], ensure_ascii=False), 1 if d.get('saved') else 0,
                  1, trashed, 'TRASH' if trashed else 'LIVE', synced, _now(), cid))      # 함께 쓰기는 늘 켬


def put(conn, d, src='PHONE'):
    """상대가 보낸 문서 → 'ADDED' · 'REPLACED' · 'TRASHED'(휴지통으로) · 'RESTORED'(되살림) ·
    'COPIED'(양쪽 다 고침 — 사본) · 'SAME' · 'SKIP'.

    ★ 2026-10-22 사용자 「비효율이다 · 막는 것이 좋다」 — 휴지통 상태로 온 문서는 **새로 만들지 않는다**
      (이 기기에 없던 대화 · 양쪽 다 고친 사본 둘 다). 이어 쓴 쪽의 글은 제 길로 상대에게 간다."""
    init(conn)
    uid = (d.get('uid') or '').strip()
    if not uid:
        return 'SKIP'
    if d.get('deleted'):                                  # 옛 폰 — 지움 = 휴지통
        d = dict(d, trashed_at=d.get('trashed_at') or _now(), msgs=None)
    trashed_in = bool(d.get('trashed_at'))
    r = conn.execute("SELECT chat_id, COALESCE(edits,0), COALESCE(synced_edits,0), COALESCE(record_status,'LIVE')"
                     " FROM user_ai_chat WHERE phone_uid=?", (uid,)).fetchone()
    inc = int(d.get('edits') or 0)
    if r:
        cid, ed, sy, st0 = int(r[0]), int(r[1]), int(r[2]), r[3]
        if inc == sy:
            return 'SAME'                                 # 상대에게 새것이 없다(내 쪽 고침은 내가 보낸다)
        if ed != sy:
            # ★ 양쪽 다 고쳤다 — 받은 것을 사본으로(지우지도 섞지도 않는다)
            if d.get('msgs') is None or trashed_in:
                return 'SKIP'                             # 휴지통 사본은 만들지 않는다(내가 이어 쓴 글이 이긴다)
            nd = dict(d, uid=new_uid(), title='%s (%s)' % (d.get('title') or '', '폰에서 이어 씀' if src == 'PHONE' else 'PC에서 이어 씀'),
                      share=True)
            _new_from(conn, nd, synced=-1)                # 사본은 상대에게도 간다(아직 안 보냄)
            conn.commit()
            return 'COPIED'
        if d.get('msgs') is not None:
            _write_msgs(conn, cid, d)
        _set_meta(conn, cid, d, synced=inc)
        conn.commit()
        if trashed_in and st0 != 'TRASH':
            return 'TRASHED'
        if not trashed_in and st0 == 'TRASH':
            return 'RESTORED'
        return 'REPLACED'
    if d.get('msgs') is None or trashed_in:
        return 'SKIP'                                     # 이 기기에 없던 대화가 휴지통 상태로 — 만들지 않는다
    _new_from(conn, d, synced=inc)
    conn.commit()
    return 'ADDED'


def _new_from(conn, d, synced):
    cid = UA.new_chat(conn, d.get('start_vid'), d.get('end_vid'), (d.get('lang') or 'KO').upper(),
                      d.get('title') or '', d.get('kind') or 'ASK', entity_id=d.get('entity_id'))
    conn.execute("UPDATE user_ai_chat SET phone_uid=?, provider=?, model=? WHERE chat_id=?",
                 (d['uid'], d.get('provider') or '', d.get('model') or '', cid))
    _write_msgs(conn, cid, d)
    _set_meta(conn, cid, d, synced=synced)
    return cid


def to_send(conn):
    """보낼 문서 — 마지막으로 주고받은 뒤 바뀐 대화 전부(★ 2026-10-21 모든 대화를 함께 쓴다)."""
    init(conn)
    out = []
    for (cid,) in conn.execute(
            "SELECT chat_id FROM user_ai_chat WHERE COALESCE(edits,0)<>COALESCE(synced_edits,0)"
            " AND COALESCE(record_status,'LIVE') IN ('LIVE','TRASH')"
            " ORDER BY chat_id").fetchall():
        d = doc(conn, cid)
        if d:
            out.append(d)
    return out


def sent(conn, uids):
    """폰이 받았다 — 그때의 고친 횟수를 주고받은 값으로 · 끈 대화는 이제 안 보낸다."""
    for u in uids or []:
        conn.execute("UPDATE user_ai_chat SET synced_edits=COALESCE(edits,0),"
                     " share_sent=COALESCE(share,0) WHERE phone_uid=?", (u,))
    conn.commit()


def set_share(conn, chat_id, on):
    """함께 쓰기 — 바뀌면 고침으로 친다(끔 문서도 한 번 간다)."""
    init(conn)
    cur = conn.execute("SELECT COALESCE(share,0) FROM user_ai_chat WHERE chat_id=?", (chat_id,)).fetchone()
    if not cur or bool(cur[0]) == bool(on):
        return False
    conn.execute("UPDATE user_ai_chat SET share=?, share_sent=CASE WHEN ?=1 THEN 1 ELSE COALESCE(share_sent,0) END"
                 " WHERE chat_id=?", (1 if on else 0, 1 if on else 0, chat_id))
    bump(conn, chat_id)
    conn.commit()
    return True


def mark_saved(conn, chat_id):
    """[저장하기] 했다 — 정리 화면의 「저장하지 않은 대화」에서 빠진다."""
    init(conn)
    r = conn.execute("SELECT COALESCE(saved,0) FROM user_ai_chat WHERE chat_id=?", (chat_id,)).fetchone()
    if r and not r[0]:
        conn.execute("UPDATE user_ai_chat SET saved=1 WHERE chat_id=?", (chat_id,))
        bump(conn, chat_id)
        conn.commit()


# ── 정리 · 휴지통 ─────────────────────────────────────────────────────
def _size(conn, cid):
    r = conn.execute("SELECT COALESCE(SUM(LENGTH(body)),0) FROM user_ai_msg WHERE chat_id=?", (cid,)).fetchone()
    return int(r[0] or 0)


def candidates(conn, months=6, unsaved_only=True):
    """정리할 대화 — `[(chat_id, 제목, 마지막으로 고친 때, 글자 수)]`(오래된 것부터)."""
    init(conn)
    cut = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - int(months) * 30.4 * 86400))
    q = ("SELECT chat_id, title, COALESCE(updated_at, created_at) FROM user_ai_chat"
         " WHERE COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(updated_at, created_at)<?")
    if unsaved_only:
        q += " AND COALESCE(saved,0)=0"
    return [(cid, t or '', u or '', _size(conn, cid)) for cid, t, u in conn.execute(q + " ORDER BY 3", (cut,)).fetchall()]


def trash(conn, ids):
    init(conn)
    n = 0
    for cid in ids:
        if conn.execute("UPDATE user_ai_chat SET record_status='TRASH', trashed_at=? WHERE chat_id=?"
                        " AND COALESCE(record_status,'LIVE')='LIVE'", (_now(), cid)).rowcount:
            bump(conn, cid)
            n += 1
    conn.commit()
    return n


def restore(conn, ids):
    init(conn)
    n = 0
    for cid in ids:
        if conn.execute("UPDATE user_ai_chat SET record_status='LIVE', trashed_at=NULL WHERE chat_id=?"
                        " AND record_status='TRASH'", (cid,)).rowcount:
            bump(conn, cid)
            n += 1
    conn.commit()
    return n


def trashed(conn):
    init(conn)
    return [(cid, t or '', at or '', _size(conn, cid)) for cid, t, at in conn.execute(
        "SELECT chat_id, title, trashed_at FROM user_ai_chat WHERE record_status='TRASH' ORDER BY trashed_at DESC")]


def purge(conn, days=TRASH_DAYS, ids=None):
    """휴지통에서 `days` 일 지난 것(또는 `ids`)을 완전히 지운다 → 지운 수."""
    init(conn)
    if ids is None:
        cut = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - days * 86400))
        ids = [r[0] for r in conn.execute("SELECT chat_id FROM user_ai_chat WHERE record_status='TRASH'"
                                          " AND trashed_at<?", (cut,))]
    for cid in ids:
        conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (cid,))
        conn.execute("DELETE FROM user_ai_chat WHERE chat_id=? AND record_status='TRASH'", (cid,))
    conn.commit()
    return len(ids)


def notice(conn):
    """정리할 만한 대화가 많을 때만 → (개수, 글자 수) · 아니면 None."""
    c = candidates(conn, NOTICE_MONTHS, True)
    return (len(c), sum(x[3] for x in c)) if len(c) >= NOTICE_MIN else None


# ══════════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok, fails = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            fails.append(m)

    def mem():
        c = sqlite3.connect(':memory:')
        c.execute("ATTACH ':memory:' AS userdb")
        c.execute("CREATE TABLE userdb.user_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
        c.execute("CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, bcode INTEGER, chapter INTEGER, verse INTEGER)")
        c.execute("CREATE TABLE book_names (book_code INTEGER, lang_code TEXT, short_name TEXT, full_name TEXT)")
        init(c)
        return c

    pc, ph = mem(), mem()                                 # ph = 폰 쪽을 흉내(같은 규칙)
    cid = UA.new_chat(pc, None, None, 'KO', '대화', 'ASK')
    ck(doc(pc, cid)['share'] == share_default(pc) and len(doc(pc, cid)['uid']) == 16, '새 대화 = uid · 함께 쓰기 처음 값')
    UA.add_msg(pc, cid, 'user', '물음')
    UA.add_msg(pc, cid, 'ai', '답', provider='G', model='g', raw='원래 답')
    d1 = doc(pc, cid)
    ck(d1['edits'] == 2 and d1['by'] == 'PC', '말마다 고친 횟수')
    ck('원래 답' not in json.dumps(d1, ensure_ascii=False), '검증 전 원래 답은 안 보낸다')
    ck([x['uid'] for x in to_send(pc)] == [d1['uid']], '바뀐 대화만 보낼 것')
    ck(put(ph, d1, 'PC') == 'ADDED', '받는 쪽 — 처음은 더함')
    sent(pc, [d1['uid']])
    ck(to_send(pc) == [], '보낸 뒤엔 없다')
    ck(put(ph, d1, 'PC') == 'SAME', '같은 것이 또 오면 그대로')
    # 받은 쪽이 이어 쓰고 돌려보냄 → PC 는 안 고쳤으니 바꾼다
    pid = ph.execute("SELECT chat_id FROM user_ai_chat WHERE phone_uid=?", (d1['uid'],)).fetchone()[0]
    UA.add_msg(ph, pid, 'user', '이어서')
    d2 = doc(ph, pid)
    ck(put(pc, d2, 'PHONE') == 'REPLACED' and len(doc(pc, cid)['msgs']) == 3, '내 쪽이 안 고쳤으면 바꾼다')
    ck(to_send(pc) == [], '받아서 바꾼 것은 다시 안 보낸다')
    # 양쪽 다 고침 → 사본
    UA.add_msg(pc, cid, 'user', 'PC 에서 더함')
    UA.add_msg(ph, pid, 'user', '폰에서 더함')
    r = put(pc, doc(ph, pid), 'PHONE')
    titles = [t for (t,) in pc.execute("SELECT title FROM user_ai_chat")]
    ck(r == 'COPIED' and any('폰에서 이어 씀' in t for t in titles), '양쪽 다 고치면 사본 · 원래 것은 그대로')
    ck(any('PC 에서 더함' == m['body'] for m in doc(pc, cid)['msgs']), '내 쪽 대화는 지우지 않는다')
    ck(len(to_send(pc)) == 2, '내 대화 + 사본이 상대로 간다')
    # ★ 2026-10-21 모든 대화를 함께 쓴다 — 옛 「끔」 대화도 init 이 한 번 보낼 것으로 만든다
    sent(pc, [x['uid'] for x in to_send(pc)])
    pc.execute("UPDATE user_ai_chat SET share=0, share_sent=0 WHERE chat_id=?", (cid,))
    pc.execute("DELETE FROM user_config WHERE config_key='AI_SHARE_ALL'")
    ck(to_send(pc) and to_send(pc)[0]['uid'] == doc(pc, cid)['uid'], '꺼 두었던 옛 대화도 간다')
    sent(pc, [x['uid'] for x in to_send(pc)])
    UA.add_msg(pc, cid, 'user', '그 뒤')
    ck([x['uid'] for x in to_send(pc)] == [doc(pc, cid)['uid']] and doc(pc, cid)['share'], '고치면 늘 간다 · share 늘 켬')
    r_off = put(ph, dict(doc(pc, cid), share=False), 'PC')
    ck(r_off in ('REPLACED', 'ADDED', 'COPIED') and r_off != 'OFF', '옛 폰이 「끔」을 보내도 끄지 않는다')
    # 정리 · 휴지통
    pc.execute("UPDATE user_ai_chat SET updated_at='2020-01-01 00:00:00'")
    c0 = candidates(pc, 6, True)
    ck(len(c0) == 2, '오래된 · 저장 안 한 대화')
    mark_saved(pc, cid)
    pc.execute("UPDATE user_ai_chat SET updated_at='2020-01-01 00:00:00'")
    ck([x[0] for x in candidates(pc, 6, True)] != [] and cid not in [x[0] for x in candidates(pc, 6, True)],
       '저장한 대화는 빠진다')
    ck(cid in [x[0] for x in candidates(pc, 6, False)], '「저장 안 한 것만」을 끄면 들어온다')
    ids = [x[0] for x in candidates(pc, 6, False)]
    ck(trash(pc, ids) == len(ids) and candidates(pc, 6, False) == [] and len(trashed(pc)) == len(ids), '휴지통으로')
    ck(UA.chats_for(pc, limit=50) == [] or all(True for _ in UA.chats_for(pc, limit=50)), '목록 조회가 터지지 않는다')
    ck(restore(pc, [ids[0]]) == 1 and len(trashed(pc)) == len(ids) - 1, '되살리기')
    ck(purge(pc, 30) == 0, '30일 안 된 것은 남는다')
    pc.execute("UPDATE user_ai_chat SET trashed_at='2020-01-01 00:00:00' WHERE record_status='TRASH'")
    ck(purge(pc, 30) == len(ids) - 1 and trashed(pc) == [], '30일 지난 것은 완전히 지운다')
    ck(pc.execute("SELECT COUNT(*) FROM user_ai_msg WHERE chat_id NOT IN (SELECT chat_id FROM user_ai_chat)").fetchone()[0] == 0,
       '말도 함께 지운다')
    # 휴지통도 상대에게 간다
    c2 = UA.new_chat(pc, None, None, 'KO', '휴지통 시험', 'ASK')
    UA.add_msg(pc, c2, 'user', 'x')
    dd = doc(pc, c2)
    put(ph, dd, 'PC')
    sent(pc, [dd['uid']])
    trash(pc, [c2])
    put(ph, to_send(pc)[-1], 'PC')
    ck(ph.execute("SELECT record_status FROM user_ai_chat WHERE phone_uid=?", (dd['uid'],)).fetchone()[0] == 'TRASH',
       '휴지통으로 보낸 것이 상대에게도')
    # ★ 2026-10-22 휴지통 상태로 온 모르는 대화는 만들지 않는다 · 결과 글자
    c3 = UA.new_chat(ph, None, None, 'KO', '폰에서만 쓰고 지움', 'ASK')
    UA.add_msg(ph, c3, 'user', 'y')
    trash(ph, [c3])
    n0 = pc.execute("SELECT COUNT(*) FROM user_ai_chat").fetchone()[0]
    ck(put(pc, doc(ph, c3), 'PHONE') == 'SKIP' and pc.execute("SELECT COUNT(*) FROM user_ai_chat").fetchone()[0] == n0,
       '휴지통 상태로 온 모르는 대화는 만들지 않는다')
    c4 = UA.new_chat(pc, None, None, 'KO', '함께 쓰다 지움', 'ASK')
    UA.add_msg(pc, c4, 'user', 'z')
    d4 = doc(pc, c4)
    put(ph, d4, 'PC')
    sent(pc, [d4['uid']])
    p4 = ph.execute("SELECT chat_id FROM user_ai_chat WHERE phone_uid=?", (d4['uid'],)).fetchone()[0]
    trash(ph, [p4])
    ck(put(pc, doc(ph, p4), 'PHONE') == 'TRASHED', '폰에서 지운 것 = TRASHED')
    restore(ph, [p4])
    ck(put(pc, doc(ph, p4), 'PHONE') == 'RESTORED', '폰에서 되살린 것 = RESTORED')
    trash(ph, [p4])
    UA.add_msg(pc, c4, 'user', 'PC 가 이어 씀')
    nb = pc.execute("SELECT COUNT(*) FROM user_ai_chat").fetchone()[0]
    ck(put(pc, doc(ph, p4), 'PHONE') == 'SKIP' and pc.execute("SELECT COUNT(*) FROM user_ai_chat").fetchone()[0] == nb,
       '양쪽 다 고쳤고 받은 것이 휴지통이면 사본을 만들지 않는다')
    print('ai_chat_sync selftest %d/%d' % (ok, ok + len(fails)))
    for f in fails:
        print('  FAIL', f)
    return not fails


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
