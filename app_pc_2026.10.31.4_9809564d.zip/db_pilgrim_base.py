# -*- coding: utf-8 -*-
"""성지순례 거점(숙박 도시) — 2026-10-29 사용자 「숙박지가 거점이 되어야 하는 것은 정확하다 ·
사용자가 숙박업체가 있는 거점 도시를 선택하고 거리/시간을 선택하면 주변 관광지가 표시」.

★ 거점 = 성경 장소가 아니라 숙소가 있는 도시(성경 장소 「갈릴리 바다」는 호수 위 점이라 도로 계산이 안 된다 · 실측).
★ 거점 → 둘레(성경 장소 + 순례 장소)의 차 시간·거리를 이 PC 의 도로 엔진(GraphHopper)으로 미리 잰다 —
  폰은 그 표만 읽는다(엔진·지도 원본은 사용자에게 안 간다).

표(CORE · 폰 공통팩)
  sys_pilgrim_base       base_id PK · code UNIQUE · names(JSON 언어마다) · lat · lng · region · sort_order · record_status
  sys_pilgrim_base_road  base_id · kind(P 성경 장소 = 용어 번호 · S 순례 장소 = sys_pilgrim_site.site_id) · target_id · km · minutes
                         PK(base_id, kind, target_id)

  python db_pilgrim_base.py --selftest | --seed | --roads [--redo] | --status
"""
import json
import sys
import urllib.error

import appdb
import db_place_road as R

#: (열쇠, 지역, 위도, 경도, 이름{언어}) — 숙박이 있는 도시 · 차례 = 이 표
BASES = [
    ('JERUSALEM', 'ISRAEL', 31.7767, 35.2345, {'KO': '예루살렘', 'EN': 'Jerusalem', 'ZH': '耶路撒冷', 'ZHT': '耶路撒冷', 'JA': 'エルサレム', 'DE': 'Jerusalem', 'FR': 'Jérusalem', 'ES': 'Jerusalén', 'PT': 'Jerusalém', 'RU': 'Иерусалим', 'AR': 'القدس'}),
    ('TIBERIAS', 'ISRAEL', 32.7940, 35.5312, {'KO': '티베리아', 'EN': 'Tiberias', 'ZH': '提比里亚', 'ZHT': '提比里亞', 'JA': 'ティベリア', 'DE': 'Tiberias', 'FR': 'Tibériade', 'ES': 'Tiberíades', 'PT': 'Tiberíades', 'RU': 'Тверия', 'AR': 'طبريا'}),
    ('NAZARETH', 'ISRAEL', 32.6996, 35.3035, {'KO': '나사렛', 'EN': 'Nazareth', 'ZH': '拿撒勒', 'ZHT': '拿撒勒', 'JA': 'ナザレ', 'DE': 'Nazareth', 'FR': 'Nazareth', 'ES': 'Nazaret', 'PT': 'Nazaré', 'RU': 'Назарет', 'AR': 'الناصرة'}),
    ('EIN_BOKEK', 'ISRAEL', 31.2003, 35.3628, {'KO': '엔 보케크(사해)', 'EN': 'Ein Bokek (Dead Sea)', 'ZH': '艾因博凯克(死海)', 'ZHT': '艾因博凱克(死海)', 'JA': 'エイン・ボケック(死海)', 'DE': 'Ein Bokek (Totes Meer)', 'FR': 'Ein Bokek (mer Morte)', 'ES': 'Ein Bokek (mar Muerto)', 'PT': 'Ein Bokek (mar Morto)', 'RU': 'Эйн-Бокек (Мёртвое море)', 'AR': 'عين بوقيق (البحر الميت)'}),
    ('EILAT', 'ISRAEL', 29.5577, 34.9519, {'KO': '에일랏', 'EN': 'Eilat', 'ZH': '埃拉特', 'ZHT': '埃拉特', 'JA': 'エイラート', 'DE': 'Eilat', 'FR': 'Eilat', 'ES': 'Eilat', 'PT': 'Eilat', 'RU': 'Эйлат', 'AR': 'إيلات'}),
    ('AMMAN', 'JORDAN', 31.9539, 35.9106, {'KO': '암만', 'EN': 'Amman', 'ZH': '安曼', 'ZHT': '安曼', 'JA': 'アンマン', 'DE': 'Amman', 'FR': 'Amman', 'ES': 'Amán', 'PT': 'Amã', 'RU': 'Амман', 'AR': 'عمّان'}),
    ('MADABA', 'JORDAN', 31.7160, 35.7939, {'KO': '마다바', 'EN': 'Madaba', 'ZH': '马达巴', 'ZHT': '馬達巴', 'JA': 'マダバ', 'DE': 'Madaba', 'FR': 'Madaba', 'ES': 'Madaba', 'PT': 'Madaba', 'RU': 'Мадаба', 'AR': 'مادبا'}),
    ('PETRA', 'JORDAN', 30.3285, 35.4444, {'KO': '페트라(와디 무사)', 'EN': 'Petra (Wadi Musa)', 'ZH': '佩特拉(瓦迪穆萨)', 'ZHT': '佩特拉(瓦迪穆薩)', 'JA': 'ペトラ(ワディ・ムーサ)', 'DE': 'Petra (Wadi Musa)', 'FR': 'Pétra (Wadi Moussa)', 'ES': 'Petra (Wadi Musa)', 'PT': 'Petra (Wadi Musa)', 'RU': 'Петра (Вади-Муса)', 'AR': 'البتراء (وادي موسى)'}),
    ('AQABA', 'JORDAN', 29.5267, 35.0078, {'KO': '아카바', 'EN': 'Aqaba', 'ZH': '亚喀巴', 'ZHT': '亞喀巴', 'JA': 'アカバ', 'DE': 'Akaba', 'FR': 'Aqaba', 'ES': 'Áqaba', 'PT': 'Ácaba', 'RU': 'Акаба', 'AR': 'العقبة'}),
    ('CAIRO', 'EGYPT', 30.0444, 31.2357, {'KO': '카이로', 'EN': 'Cairo', 'ZH': '开罗', 'ZHT': '開羅', 'JA': 'カイロ', 'DE': 'Kairo', 'FR': 'Le Caire', 'ES': 'El Cairo', 'PT': 'Cairo', 'RU': 'Каир', 'AR': 'القاهرة'}),
    ('ST_CATHERINE', 'EGYPT', 28.5560, 33.9757, {'KO': '성 카타리나(시내산)', 'EN': 'St. Catherine (Mt. Sinai)', 'ZH': '圣凯瑟琳(西奈山)', 'ZHT': '聖凱瑟琳(西奈山)', 'JA': '聖カタリナ(シナイ山)', 'DE': 'St. Katharina (Sinai)', 'FR': 'Sainte-Catherine (Sinaï)', 'ES': 'Santa Catalina (Sinaí)', 'PT': 'Santa Catarina (Sinai)', 'RU': 'Санта-Катарина (Синай)', 'AR': 'سانت كاترين (سيناء)'}),
    ('LUXOR', 'EGYPT', 25.6872, 32.6396, {'KO': '룩소르', 'EN': 'Luxor', 'ZH': '卢克索', 'ZHT': '盧克索', 'JA': 'ルクソール', 'DE': 'Luxor', 'FR': 'Louxor', 'ES': 'Luxor', 'PT': 'Luxor', 'RU': 'Луксор', 'AR': 'الأقصر'}),
    # ★ 2026-10-29 튀르키예·그리스 권역(비행기로 잇는다 · 도로는 둘째 엔진 GH2 · db_place_road.engine_of)
    ('ISTANBUL', 'TURKEY', 41.0082, 28.9784, {'KO': '이스탄불', 'EN': 'Istanbul', 'ZH': '伊斯坦布尔', 'ZHT': '伊斯坦堡', 'JA': 'イスタンブール', 'DE': 'Istanbul', 'FR': 'Istanbul', 'ES': 'Estambul', 'PT': 'Istambul', 'RU': 'Стамбул', 'AR': 'إسطنبول'}),
    ('IZMIR', 'TURKEY', 38.4237, 27.1428, {'KO': '이즈미르(서머나)', 'EN': 'Izmir (Smyrna)', 'ZH': '伊兹密尔(士每拿)', 'ZHT': '伊茲密爾(士每拿)', 'JA': 'イズミル(スミルナ)', 'DE': 'Izmir (Smyrna)', 'FR': 'Izmir (Smyrne)', 'ES': 'Esmirna (İzmir)', 'PT': 'Esmirna (Izmir)', 'RU': 'Измир (Смирна)', 'AR': 'إزمير (سميرنا)'}),
    ('SELCUK', 'TURKEY', 37.951, 27.37, {'KO': '셀추크(에베소)', 'EN': 'Selçuk (Ephesus)', 'ZH': '塞尔丘克(以弗所)', 'ZHT': '塞爾丘克(以弗所)', 'JA': 'セルチュク(エフェソス)', 'DE': 'Selçuk (Ephesus)', 'FR': 'Selçuk (Éphèse)', 'ES': 'Selçuk (Éfeso)', 'PT': 'Selçuk (Éfeso)', 'RU': 'Сельчук (Эфес)', 'AR': 'سلجوق (أفسس)'}),
    ('PAMUKKALE', 'TURKEY', 37.9204, 29.1189, {'KO': '파묵칼레(히에라볼리)', 'EN': 'Pamukkale (Hierapolis)', 'ZH': '棉堡(希拉波利斯)', 'ZHT': '棉堡(希拉波利斯)', 'JA': 'パムッカレ(ヒエラポリス)', 'DE': 'Pamukkale (Hierapolis)', 'FR': 'Pamukkale (Hiérapolis)', 'ES': 'Pamukkale (Hierápolis)', 'PT': 'Pamukkale (Hierápolis)', 'RU': 'Памуккале (Иераполь)', 'AR': 'باموكالي (هيرابوليس)'}),
    ('ANTALYA', 'TURKEY', 36.8969, 30.7133, {'KO': '안탈리아(앗달리아)', 'EN': 'Antalya (Attalia)', 'ZH': '安塔利亚(亚大利)', 'ZHT': '安塔利亞(亞大利)', 'JA': 'アンタルヤ(アタリア)', 'DE': 'Antalya (Attalia)', 'FR': 'Antalya (Attalie)', 'ES': 'Antalya (Atalia)', 'PT': 'Antália (Atália)', 'RU': 'Анталья (Атталия)', 'AR': 'أنطاليا (أتاليا)'}),
    ('KONYA', 'TURKEY', 37.8746, 32.4932, {'KO': '코니아(이고니온)', 'EN': 'Konya (Iconium)', 'ZH': '科尼亚(以哥念)', 'ZHT': '科尼亞(以哥念)', 'JA': 'コンヤ(イコニオン)', 'DE': 'Konya (Ikonion)', 'FR': 'Konya (Iconium)', 'ES': 'Konya (Iconio)', 'PT': 'Cónia (Icônio)', 'RU': 'Конья (Иконий)', 'AR': 'قونية (إيقونية)'}),
    ('GOREME', 'TURKEY', 38.6431, 34.8289, {'KO': '괴레메(갑바도기아)', 'EN': 'Göreme (Cappadocia)', 'ZH': '格雷梅(加帕多家)', 'ZHT': '格雷梅(加帕多家)', 'JA': 'ギョレメ(カッパドキア)', 'DE': 'Göreme (Kappadokien)', 'FR': 'Göreme (Cappadoce)', 'ES': 'Göreme (Capadocia)', 'PT': 'Göreme (Capadócia)', 'RU': 'Гёреме (Каппадокия)', 'AR': 'غوريمي (كبادوكية)'}),
    ('ANTAKYA', 'TURKEY', 36.2025, 36.1606, {'KO': '안타키아(안디옥)', 'EN': 'Antakya (Antioch)', 'ZH': '安塔基亚(安提阿)', 'ZHT': '安塔基亞(安提阿)', 'JA': 'アンタキヤ(アンティオキア)', 'DE': 'Antakya (Antiochia)', 'FR': 'Antakya (Antioche)', 'ES': 'Antakya (Antioquía)', 'PT': 'Antáquia (Antioquia)', 'RU': 'Антакья (Антиохия)', 'AR': 'أنطاكيا'}),
    ('ATHENS', 'GREECE', 37.9838, 23.7275, {'KO': '아테네(아덴)', 'EN': 'Athens', 'ZH': '雅典', 'ZHT': '雅典', 'JA': 'アテネ', 'DE': 'Athen', 'FR': 'Athènes', 'ES': 'Atenas', 'PT': 'Atenas', 'RU': 'Афины', 'AR': 'أثينا'}),
    ('THESSALONIKI', 'GREECE', 40.6401, 22.9444, {'KO': '테살로니키(데살로니가)', 'EN': 'Thessaloniki', 'ZH': '塞萨洛尼基(帖撒罗尼迦)', 'ZHT': '塞薩洛尼基(帖撒羅尼迦)', 'JA': 'テッサロニキ', 'DE': 'Thessaloniki', 'FR': 'Thessalonique', 'ES': 'Tesalónica', 'PT': 'Tessalónica', 'RU': 'Салоники', 'AR': 'سالونيك'}),
    ('KAVALA', 'GREECE', 40.9396, 24.4069, {'KO': '카발라(네압볼리)', 'EN': 'Kavala (Neapolis)', 'ZH': '卡瓦拉(尼亚坡里)', 'ZHT': '卡瓦拉(尼亞坡里)', 'JA': 'カヴァラ(ネアポリス)', 'DE': 'Kavala (Neapolis)', 'FR': 'Kavala (Néapolis)', 'ES': 'Kavala (Neápolis)', 'PT': 'Cavala (Neápolis)', 'RU': 'Кавала (Неаполь)', 'AR': 'كافالا (نيابوليس)'}),
    ('KALAMBAKA', 'GREECE', 39.7044, 21.6269, {'KO': '칼람바카(메테오라)', 'EN': 'Kalambaka (Meteora)', 'ZH': '卡兰巴卡(迈泰奥拉)', 'ZHT': '卡蘭巴卡(邁泰奧拉)', 'JA': 'カランバカ(メテオラ)', 'DE': 'Kalambaka (Meteora)', 'FR': 'Kalambaka (Météores)', 'ES': 'Kalambaka (Meteora)', 'PT': 'Kalambaka (Meteora)', 'RU': 'Каламбака (Метеоры)', 'AR': 'كالامباكا (ميتيورا)'}),
    ('PATMOS', 'GREECE', 37.322, 26.545, {'KO': '밧모(스칼라)', 'EN': 'Patmos (Skala)', 'ZH': '拔摩岛(斯卡拉)', 'ZHT': '拔摩島(斯卡拉)', 'JA': 'パトモス(スカラ)', 'DE': 'Patmos (Skala)', 'FR': 'Patmos (Skala)', 'ES': 'Patmos (Skala)', 'PT': 'Patmos (Skala)', 'RU': 'Патмос (Скала)', 'AR': 'بطمس (سكالا)'}),
]

#: 거점에서 이 직선 거리 안의 대상만 잰다(차로 하루 다녀올 수 있는 범위)
MAX_KM = 160.0

DDL = [
    """CREATE TABLE IF NOT EXISTS sys_pilgrim_base(
        base_id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, names TEXT DEFAULT '{}',
        lat REAL, lng REAL, region TEXT DEFAULT '', sort_order INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE')""",
    """CREATE TABLE IF NOT EXISTS sys_pilgrim_base_road(
        base_id INTEGER NOT NULL, kind TEXT NOT NULL, target_id INTEGER NOT NULL, km REAL, minutes REAL,
        PRIMARY KEY(base_id, kind, target_id))""",
]


def ensure(conn):
    for d in DDL:
        conn.execute(d)


def seed(conn):
    """거점 목록을 심는다 — 이미 있는 열쇠는 이름·좌표만 맞춘다(번호는 그대로 · 도로 표가 번호를 가리킨다)."""
    ensure(conn)
    n = 0
    for i, (code, rg, la, ln, names) in enumerate(BASES):
        nm = json.dumps(names, ensure_ascii=False)
        if conn.execute('SELECT 1 FROM sys_pilgrim_base WHERE code=?', (code,)).fetchone():
            conn.execute('UPDATE sys_pilgrim_base SET names=?, lat=?, lng=?, region=?, sort_order=? WHERE code=?',
                         (nm, la, ln, rg, (i + 1) * 10, code))
        else:
            conn.execute('INSERT INTO sys_pilgrim_base(code,names,lat,lng,region,sort_order) VALUES(?,?,?,?,?,?)',
                         (code, nm, la, ln, rg, (i + 1) * 10))
            n += 1
    conn.commit()
    return n


def bases(conn):
    ensure(conn)
    return conn.execute("SELECT base_id, code, lat, lng FROM sys_pilgrim_base WHERE COALESCE(record_status,'LIVE')='LIVE'"
                        ' ORDER BY sort_order').fetchall()


def targets(conn):
    """잴 대상 — ('P', 용어 번호, 위도, 경도)(순례 지역 성경 장소) + ('S', 장소 번호, …)(순례 장소 · 승인 전 것도 미리 잰다)."""
    out = [('P', p[0], p[1], p[2]) for p in R.places(conn, 'ALL')]
    try:
        out += [('S', r[0], r[1], r[2]) for r in conn.execute(
            "SELECT site_id, lat, lng FROM sys_pilgrim_site WHERE status<>'HIDE' AND lat IS NOT NULL")]
    except Exception:                                   # noqa: BLE001
        pass
    return out


def pairs(conn):
    """(base_id, kind, target_id, 직선 km) — MAX_KM 안"""
    out = []
    for bid, _code, la, ln in bases(conn):
        for kind, tid, ta, tn in targets(conn):
            d = R.km((0, la, ln), (0, ta, tn))
            if d <= MAX_KM:
                out.append((bid, kind, tid, d, (la, ln), (ta, tn)))
    return out


def roads(conn, redo=False, base=None, say=print):
    """이 PC 엔진으로 거점 → 대상 차 시간·거리를 잰다(선은 안 받는다) · 이미 잰 것은 건너뛴다."""
    ensure(conn)
    have = set() if redo else {(r[0], r[1], r[2]) for r in conn.execute(
        'SELECT base_id, kind, target_id FROM sys_pilgrim_base_road')}
    todo = [p for p in pairs(conn) if (p[0], p[1], p[2]) not in have]
    ok = fail = 0
    for n, (bid, kind, tid, _d, a, b) in enumerate(todo, 1):
        # ⚠ 첫 열은 snap 이 기억하는 열쇠다 — 점마다 달라야 한다(2026-10-29 모두 0 으로 넘겨 「갈릴리 바다 0분」이 났다)
        pa, pb = ('B%d' % bid, a[0], a[1]), ('%s%d' % (kind, tid), b[0], b[1])
        eng = base or R.engine_of(a[0], a[1])          # ★ 그 거점의 권역 엔진(튀르키예·그리스 = GH2)
        try:
            try:
                path = R._gh_path(eng, pa, pb, False)
            except urllib.error.HTTPError as e:
                if e.code != 400:
                    raise
                path = R._gh_path(eng, R.snap(pa), R.snap(pb), False)
            if path:
                conn.execute('INSERT OR REPLACE INTO sys_pilgrim_base_road VALUES(?,?,?,?,?)',
                             (bid, kind, tid, round(path['distance'] / 1000.0, 2), round(path['time'] / 60000.0, 1)))
                ok += 1
            else:
                fail += 1
                conn.execute('DELETE FROM sys_pilgrim_base_road WHERE base_id=? AND kind=? AND target_id=?', (bid, kind, tid))
        except Exception:                               # noqa: BLE001
            fail += 1                                   # 못 잰 쌍은 옛 값을 남기지 않는다(다시 잴 때 틀린 값이 남았다)
            conn.execute('DELETE FROM sys_pilgrim_base_road WHERE base_id=? AND kind=? AND target_id=?', (bid, kind, tid))
        if n % 50 == 0:
            conn.commit()
        if n % 500 == 0:
            say('  %d/%d (받음 %d · 실패 %d)' % (n, len(todo), ok, fail))
    conn.commit()
    return len(todo), ok, fail


def around(conn, base_id, max_minutes=60, lang='KO'):
    """거점 둘레 — 차로 max_minutes 안 대상 [(kind, target_id, km, minutes)] 가까운 차례(PC·폰 같은 규칙)."""
    return conn.execute('SELECT kind, target_id, km, minutes FROM sys_pilgrim_base_road'
                        ' WHERE base_id=? AND minutes<=? ORDER BY minutes', (base_id, max_minutes)).fetchall()


def status(conn):
    ensure(conn)
    print('거점 %d · 도로 %d · 잴 쌍 %d' % (conn.execute('SELECT COUNT(*) FROM sys_pilgrim_base').fetchone()[0],
                                         conn.execute('SELECT COUNT(*) FROM sys_pilgrim_base_road').fetchone()[0],
                                         len(pairs(conn))))
    for bid, code, _a, _b in bases(conn):
        r = conn.execute("SELECT SUM(kind='P'), SUM(kind='S'), SUM(minutes<=60) FROM sys_pilgrim_base_road WHERE base_id=?",
                         (bid,)).fetchone()
        print('  %-13s 성경 장소 %s · 순례 장소 %s · 60분 안 %s' % (code, r[0] or 0, r[1] or 0, r[2] or 0))


def selftest():
    import sqlite3
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    c = sqlite3.connect(':memory:')
    ensure(c)
    ck(seed(c) == len(BASES), '거점 심기')
    ck(seed(c) == 0, '두 번 심어도 안 늘어남')
    ck(all(len(b[4]) == 11 for b in BASES), '거점 이름 11개 언어')
    ck(len({b[0] for b in BASES}) == len(BASES), '열쇠 겹침 없음')
    jid = c.execute("SELECT base_id FROM sys_pilgrim_base WHERE code='JERUSALEM'").fetchone()[0]
    c.executemany('INSERT INTO sys_pilgrim_base_road VALUES(?,?,?,?,?)',
                  [(jid, 'P', 1, 5.0, 8.0), (jid, 'S', 2, 40.0, 50.0), (jid, 'P', 3, 90.0, 95.0)])
    ck([r[1] for r in around(c, jid, 60)] == [1, 2], '둘레 = 시간 안 · 가까운 차례')
    ck(len(around(c, jid, 120)) == 3, '시간을 늘리면 더 나온다')
    print('\ndb_pilgrim_base selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(a):
    if '--selftest' in a:
        return 0 if selftest() else 1
    conn = appdb.connect('bible_master.db')
    if '--seed' in a:
        print('거점 새로 %d' % seed(conn))
    if '--roads' in a:
        print('도로: 잴 것 %d · 받음 %d · 실패 %d' % roads(conn, redo='--redo' in a))
    status(conn)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
