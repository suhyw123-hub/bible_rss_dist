# -*- coding: utf-8 -*-
"""코어팩이 **지금 DB 와 같은가** — 낡은 팩을 배포하지 않게 막는다.

    python db_pack_fresh.py --selftest
    python db_pack_fresh.py --check     # 지금 낡았는가
    python db_pack_fresh.py --stamp     # 팩을 만든 직후 도장을 찍는다

★★★ **왜 필요한가 — 실측으로 잡았다**(2026-09-18).
  코어팩을 **2026-09-04** 에 만들고 그 뒤로 DB 가 계속 바뀌었는데
  `PACK_ITEM_STALE` 은 **0** 을 말했다. 그 규칙이 재는 것은
  「**판을 올렸는데** 다시 안 만들었나」이고, 판은 **팩을 만들 때** 오른다.
  ⇒ **내용이 바뀌어도 판이 안 오르므로 「낡음」으로 영영 안 잡힌다.**
  사용자 지적 그대로다 — 「고쳐 놓고 배포할 때 과거 버전으로 배포해버릴 위험」.

★★ **잣대 둘을 함께 본다 — 하나로는 못 잡는다.**
  | 잣대 | 잡는 것 | 못 잡는 것 |
  |---|---|---|
  | **감사 로그 시각**(§10-1) | 고침·지움까지 **전부** | 트리거가 안 걸린 표 · 로그를 꺼 둔 동안 |
  | **표 행수 지문** | 트리거 없는 표의 늘고 줆 | 행수가 그대로인 **고침** |
  ⚠ 감사 로그가 통째로 비었으면 **「깨끗하다」가 아니라 「못 잰다」**로
    말한다(§0-1). 조용히 통과시키면 이 문이 있으나 마나다.

⚠ **도장은 팩을 만든 뒤에 찍는다**(`stamp`) — 만들기 전에 찍으면 그 사이
  변경을 영영 못 본다. `db_pack_core.build` 가 끝에서 부른다.
⚠ **도장이 없으면 행수 잣대를 건너뛰되 그 사실을 말한다** — 처음 한 번은
  감사 로그만으로 잰다(그것만으로도 오늘 사고를 잡는다).
"""
import io
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, '_linkpack_dist')
STAMP = os.path.join(DIST, 'corepack_fresh.json')


# ── 재료 ─────────────────────────────────────────────────────────────
def core_tables(conn):
    """코어팩이 담는 표 이름들. 못 읽으면 빈 목록(부르는 쪽이 판단)."""
    try:
        import db_pack_core as PK
        return [t for t, _cd in PK.core_tables()]
    except Exception:                                         # noqa: BLE001
        return []


def _has(conn, tbl):
    try:
        return bool(conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (tbl,)).fetchone())
    except Exception:                                         # noqa: BLE001
        return False


def made_at(conn):
    """코어팩을 마지막으로 만든 시각(글자) 또는 ''."""
    try:
        r = conn.execute("SELECT made_at FROM sys_pack_item"
                         " WHERE UPPER(kind)='CORE'").fetchone()
        return (r[0] or '') if r else ''
    except Exception:                                         # noqa: BLE001
        return ''


def audit_since(conn, tables, since):
    """`since` 뒤에 바뀐 코어 표 → `[(표, 건수)]` · 감사 로그가 없으면 None.

    ⚠ **없음과 0 을 가른다** — 로그 자체가 없으면 `None` 을 낸다.
    """
    if not _has(conn, 'sys_audit_log'):
        return None
    try:
        n = conn.execute("SELECT COUNT(*) FROM sys_audit_log").fetchone()[0]
    except Exception:                                         # noqa: BLE001
        return None
    if not n:
        return None
    ts = [t for t in tables if t]
    if not ts:
        return []
    ph = ','.join('?' * len(ts))
    rows = conn.execute(
        "SELECT tbl, COUNT(*) FROM sys_audit_log"
        " WHERE tbl IN (%s) AND ts > ? GROUP BY tbl ORDER BY 2 DESC" % ph,
        ts + [since or '']).fetchall()
    return [(r[0], int(r[1])) for r in rows]


def row_counts(conn, tables):
    """표마다 행수 → dict. 없는 표는 건너뛴다."""
    out = {}
    for t in tables:
        if not _has(conn, t):
            continue
        try:
            out[t] = int(conn.execute(
                'SELECT COUNT(*) FROM "%s"' % t).fetchone()[0])
        except Exception:                                     # noqa: BLE001
            pass
    return out


# ── 도장 ─────────────────────────────────────────────────────────────
def stamp(conn, path=None):
    """지금 상태를 기준으로 찍는다 — **팩을 만든 직후에** 부른다."""
    p = path or STAMP
    os.makedirs(os.path.dirname(p), exist_ok=True)
    body = {'made_at': made_at(conn),
            'rows': row_counts(conn, core_tables(conn))}
    with io.open(p, 'w', encoding='utf-8') as f:
        json.dump(body, f, ensure_ascii=False, indent=1)
    return p


def read_stamp(path=None):
    p = path or STAMP
    try:
        with io.open(p, encoding='utf-8') as f:
            return json.load(f)
    except Exception:                                         # noqa: BLE001
        return None


# ── 판정 ─────────────────────────────────────────────────────────────
def check(conn, path=None):
    """코어팩이 낡았는가 → `(어긋난 수, 사람이 읽는 말)`.

    ★ 어긋난 수 = **바뀐 표의 수**(0 이면 성하다).
    """
    ts = core_tables(conn)
    if not ts:
        return 1, '코어 표 목록을 읽을 수 없다'
    mk = made_at(conn)
    if not mk:
        return 1, '코어팩을 아직 만든 적이 없다'

    msg, bad = [], set()

    # ① 감사 로그 — 팩을 만든 뒤에 바뀐 것이 있나
    a = audit_since(conn, ts, mk)
    if a is None:
        msg.append('감사 로그가 없어 **고침은 못 잰다**'
                   '(db_audit_triggers.py 로 켠다)')
    elif a:
        bad |= {t for t, _n in a}
        tot = sum(n for _t, n in a)
        head = ' · '.join('%s %d' % (t, n) for t, n in a[:3])
        msg.append('팩을 만든 %s 뒤에 코어 표 %d개가 %d번 바뀌었다 — %s%s'
                   % (mk, len(a), tot, head, ' 등' if len(a) > 3 else ''))

    # ② 행수 지문 — 트리거가 없는 표까지 본다
    st = read_stamp(path)
    if not st or not st.get('rows'):
        msg.append('행수 도장이 없어 **트리거 없는 표는 못 잰다**'
                   '(다음에 팩을 만들면 찍힌다)')
    else:
        now = row_counts(conn, ts)
        diff = [(t, st['rows'].get(t), now.get(t))
                for t in sorted(set(st['rows']) | set(now))
                if st['rows'].get(t) != now.get(t)]
        if diff:
            bad |= {t for t, _o, _n in diff}
            head = ' · '.join('%s %s→%s' % (t, o, n) for t, o, n in diff[:3])
            msg.append('행수가 달라진 표 %d개 — %s%s'
                       % (len(diff), head, ' 등' if len(diff) > 3 else ''))

    if bad:
        return len(bad), ' / '.join(msg)
    return 0, (' / '.join(msg) if msg else '')


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    import tempfile
    ok, bad = [0], []

    def chk(n, cond, extra=''):
        if cond:
            ok[0] += 1
        else:
            bad.append(n)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', n, extra))

    d = tempfile.mkdtemp()
    sp = os.path.join(d, 'st.json')
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_pack_item(kind TEXT, key TEXT, made_at TEXT);
      INSERT INTO sys_pack_item VALUES('CORE','-','2026-09-04 18:14');
      CREATE TABLE sys_audit_log(audit_id INTEGER PRIMARY KEY, ts TEXT,
                                 tbl TEXT, pk TEXT, action TEXT);
      CREATE TABLE sys_link_asset(sys_link_id INTEGER);
      CREATE TABLE sys_unit_asset(sys_unit_id INTEGER);
      INSERT INTO sys_link_asset VALUES(1),(2),(3);
    """)
    g = globals()
    _orig = g['core_tables']
    g['core_tables'] = lambda _c: ['sys_link_asset', 'sys_unit_asset']
    try:
        chk('팩 만든 때를 읽는다', made_at(c) == '2026-09-04 18:14', made_at(c))

        # ⓐ 아무것도 안 바뀌었고 도장도 없다 → 성하되 **못 잰다고 말한다**
        n, why = check(c, sp)
        chk('변경 0 이면 어긋남 0', n == 0, (n, why))
        chk('감사 로그가 비면 「못 잰다」고 말한다', '못 잰다' in why, why)

        # ⓑ 도장을 찍으면 행수 잣대가 산다
        stamp(c, sp)
        n, why = check(c, sp)
        chk('도장 직후에는 성하다', n == 0, (n, why))
        chk('도장 뒤에는 행수 경고가 사라진다',
            '행수 도장이 없어' not in why, why)

        # ⓒ 행이 늘면 잡는다(트리거가 없어도)
        c.execute('INSERT INTO sys_link_asset VALUES(4)')
        n, why = check(c, sp)
        chk('행이 늘면 잡는다', n == 1 and 'sys_link_asset' in why, (n, why))

        # ⓓ 행수가 같은 **고침**은 감사 로그만 잡는다
        c.execute('DELETE FROM sys_link_asset WHERE sys_link_id=4')
        n0, _ = check(c, sp)
        chk('되돌리면 행수 잣대는 조용하다', n0 == 0, n0)
        c.execute("INSERT INTO sys_audit_log(ts,tbl,pk,action)"
                  " VALUES('2026-09-18 17:05','sys_link_asset','1','UPDATE')")
        n, why = check(c, sp)
        chk('행수가 같은 고침을 감사 로그가 잡는다',
            n == 1 and '바뀌었다' in why, (n, why))

        # ⓔ 팩을 만들기 **전**의 로그는 안 센다
        c.execute('DELETE FROM sys_audit_log')
        c.execute("INSERT INTO sys_audit_log(ts,tbl,pk,action)"
                  " VALUES('2026-08-01 09:00','sys_link_asset','1','UPDATE')")
        n, _ = check(c, sp)
        chk('팩보다 이른 변경은 안 센다', n == 0, n)

        # ⓕ 코어 표가 아닌 것은 안 센다
        c.execute("INSERT INTO sys_audit_log(ts,tbl,pk,action)"
                  " VALUES('2026-09-18 17:05','user_text_asset','1','UPDATE')")
        n, _ = check(c, sp)
        chk('코어 표가 아니면 안 센다', n == 0, n)

        # ⓖ 팩을 만든 적이 없으면 그렇게 말한다
        c.execute("UPDATE sys_pack_item SET made_at=''")
        n, why = check(c, sp)
        chk('만든 적이 없으면 어긋남으로 본다',
            n == 1 and '만든 적이 없다' in why, (n, why))
        c.execute("UPDATE sys_pack_item SET made_at='2026-09-04 18:14'")

        # ⓗ 도장을 다시 찍으면 조용해진다(왕복)
        c.execute('INSERT INTO sys_link_asset VALUES(9)')
        c.execute('DELETE FROM sys_audit_log')
        chk('다시 어긋난다', check(c, sp)[0] == 1)
        stamp(c, sp)
        chk('도장을 다시 찍으면 조용하다', check(c, sp)[0] == 0)

        # ⓘ 실 DB 에서도 돌아간다(읽기만)
        try:
            import appdb
            rc = appdb.connect()
            g['core_tables'] = _orig
            nn, ww = check(rc)
            rc.close()
            chk('실 DB 에서 판정이 나온다', isinstance(nn, int), (nn, ww[:70]))
        except Exception as e:                                # noqa: BLE001
            chk('실 DB 에서 판정이 나온다', False, e)
    finally:
        g['core_tables'] = _orig
        c.close()
        try:
            import shutil
            shutil.rmtree(d, ignore_errors=True)
        except Exception:                                     # noqa: BLE001
            pass
    print('db_pack_fresh selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    for n in bad:
        print('  X', n)
    return not bad


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--stamp', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return 0 if _selftest() else 1
    import appdb
    c = appdb.connect()
    try:
        if a.stamp:
            print('도장:', stamp(c))
            return 0
        n, why = check(c)
        print('코어팩 만든 때 :', made_at(c) or '(없음)')
        print('판정          :', '낡았다 — 표 %d개' % n if n else '성하다')
        if why:
            print('까닭          :', why)
        return 1 if n else 0
    finally:
        c.close()


if __name__ == '__main__':
    sys.exit(main())
