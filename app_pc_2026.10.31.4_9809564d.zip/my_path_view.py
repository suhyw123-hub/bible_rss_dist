# -*- coding: utf-8 -*-
"""P1 탭4 '나의 길' — 묵상 진행중·독서 진행중·즐겨찾기 통합 뷰.

서브탭:
  1) 묵상 진행중: user_plan_enrollment (ACTIVE) 4종 scope 통합
  2) 독서 진행중: app_state.json['last_reading'] + 도서/설교 즐겨찾기
  3) ★ 즐겨찾기:  user_favorite 전체 + 유형 필터
"""
import sqlite3
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(§verse_text)
import i18n
import tkinter as tk
from tkinter import ttk
import bidi                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)
import book_label                         # 도서 유닛 제목 = 번역 덮개 우선
import highlight_notes as _HN             # 밑줄 메모 text_type 단일 소스


# scope → 한글 라벨
SCOPE_LABEL = {
    'BIBLE': '통독',
    'DIAG':  '자가진단',
    'BOOK':  '도서묵상',
    'LENS':  '렌즈묵상',
}

# fav_type → 한글 라벨
FAV_TYPE_LABEL = {
    'VERSE':       '구절',
    'COMMENTARY':  '주석',
    'BOOK_UNIT':   '도서',
    'SERMON_UNIT': '설교',
    'REF_UNIT':    '교리/자료',
    'PERICOPE':    '페리코프',
    'ENTITY':      '엔티티',
    # (렌즈 · 묵상후보는 즐겨찾기에서 뺐다 — 2026-10-13 「묵상플랜은 즐겨찾기 대상에서 제외」)
}

# 언어별 기본 역본 (구절 즐겨찾기 본문 미리보기용)
LANG_DEFAULT_VER = {
    'KO': 'KRV', 'EN': 'BSB', 'ZH': 'CUVS', 'ZHT': 'CUV', 'JA': 'JLV',
    'DE': 'GerElb', 'FR': 'FreJND', 'ES': 'SpaRV', 'RU': 'RusSyn', 'PT': 'PorBL',
}


class MyPathView(ttk.Frame):
    """P1 탭4 '나의 길' 메인 뷰."""

    def __init__(self, parent, db_path, lang_getter,
                 last_reading_getter=None,
                 on_plan_jump=None,
                 on_book_jump=None,
                 on_favorite_jump=None,
                 recent_getter=None,
                 ver_getter=None,
                 on_verse_jump=None,
                 on_note_focus=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter
        self.last_reading_getter = last_reading_getter or (lambda: {})
        self.on_plan_jump = on_plan_jump
        self.on_book_jump = on_book_jump
        self.on_favorite_jump = on_favorite_jump
        # 최근 구절 — 목록의 주인은 user_main 이다(app_state.json 에 저장).
        # 여기서 따로 들고 있으면 두 곳이 어긋나므로 볼 때마다 받아 온다.
        self.recent_getter = recent_getter or (lambda: [])
        self.ver_getter = ver_getter or (lambda: 'KRV')
        self.on_verse_jump = on_verse_jump
        self.on_note_focus = on_note_focus     # 구절노트 탭을 띄운다

        self._plan_data: dict = {}
        self._book_fav_data: dict = {}
        self._fav_data: dict = {}

        self._build()
        self.refresh()

    # ── UI 구성 ──────────────────────────────────────────────────────────

    def _build(self):
        """3탭 재편 (2026-08-19 사용자 — 0.txt 5번):
        ① 진행중 = 묵상 진행중 + 독서(이어서 읽기) 한 목록 — 값이 없는 칸은 공란
        ② 즐겨찾기 = 구절/도서·설교 **갈래 단추**(한 목록으로 합치면 구절 쪽의
           책 필터·메모 편집 기능이 죽는다 — 사용자 허용안 「버튼 추가」)
        ③ 나의 노트 (옛 ✎ 내 메모 — 이모지 삭제·개명)
        최근 구절 탭은 제거(Recent 팝업과 중복 — 사용자 「필요 없다」).
        독서 진행중 탭의 즐겨찾기 도서 목록은 즐겨찾기 탭(도서/설교 갈래)이 커버."""
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill='both', expand=True)

        # 탭1 — 진행중 (플랜 + 이어서 읽기)
        self._sub_plan = tk.Frame(self._nb, bg='#FAFAFA')
        self._nb.add(self._sub_plan, text=' '+i18n.t('TAB_MYPATH_PLAN','진행중')+' ')
        self._build_plan_subtab()

        # 탭2 — 즐겨찾기 [구절 | 도서/설교] 갈래 (branch_tabs — 표준 부품)
        fav_tab = tk.Frame(self._nb, bg='#FAFAFA')
        self._nb.add(fav_tab, text=' '+i18n.t('TAB_FAVORITES','즐겨찾기')+' ')
        try:
            from branch_tabs import BranchTabs
            bt = BranchTabs(fav_tab, db_path=self.db_path,
                            state_key='MYPATH_BR_FAV')
            bt.pack(fill='both', expand=True)
            self._sub_vfav = bt.frame_for('verse')
            self._sub_fav = bt.frame_for('etc')
            self._build_versefav_subtab()
            self._build_fav_subtab()
            bt.add('verse', 'REFV_KIND_VERSE', '구절')
            bt.add('etc', 'REFV_KIND_BOOK', '도서·설교')
            bt.finish()
        except Exception:
            import traceback; traceback.print_exc()
            self._sub_vfav = tk.Frame(fav_tab, bg='#FAFAFA')
            self._sub_vfav.pack(fill='both', expand=True)
            self._sub_fav = tk.Frame(fav_tab, bg='#FAFAFA')
            self._build_versefav_subtab()
            self._build_fav_subtab()

        # 탭3 — **노트/메모** (2026-08-23 사용자 「나의 노트 … 묵상노트와
        #   혼동된다. "노트/메모"라고 수정하자」).
        #   ⚠ 이 탭이 담는 것은 **밑줄 메모 + 구절 노트** 둘이라 이름이 그 둘을
        #     말해야 한다. 「나의 노트」는 P2 「묵상노트」와 구별이 안 됐다.
        self._sub_note = tk.Frame(self._nb, bg='#FAFAFA')
        self._nb.add(self._sub_note, text=' '+i18n.t('TAB_MYPATH_NOTE', '노트/메모')+' ')
        self._build_note_subtab()

        # 탭4 — ★ 2026-10-29 **때에 맞는 말씀**(docs/1.txt 3 · 사용자 「나의 묵상 탭 내부에 서브탭」) —
        #   폰 둘러보기와 같은 자료(db_verse_topic) · 처음 열 때 짓는다
        self._sub_vt = tk.Frame(self._nb)
        self._nb.add(self._sub_vt, text=' '+i18n.t('M_VT_TITLE', '때에 맞는 말씀')+' ')
        self._vt_view = None

        def _vt_build(_e=None):
            if self._vt_view is not None or self._nb.select() != str(self._sub_vt):
                return
            try:
                from verse_topic_view import VerseTopicView
                self._vt_view = VerseTopicView(self._sub_vt, self.db_path, lang_getter=self.lang_getter,
                                               ver_getter=self.ver_getter)
                self._vt_view.pack(fill='both', expand=True)
            except Exception:
                import traceback; traceback.print_exc()
        self._nb.bind('<<NotebookTabChanged>>', _vt_build, add='+')

    def _build_plan_subtab(self):
        wrap = tk.Frame(self._sub_plan, bg='#FAFAFA')
        wrap.pack(fill='both', expand=True, padx=8, pady=8)
        # ★ 맨 왼쪽 [Focus]/[Restore] 자리 (2026-09-16 · 1.txt 10번) — 호스트가 심는다
        _frow = tk.Frame(wrap, bg='#FAFAFA')
        _frow.pack(fill='x', pady=(0, 4))
        _fs = tk.Frame(_frow, bg='#FAFAFA')
        _fs.pack(side='left')
        self.focus_slots = getattr(self, 'focus_slots', []) + [_fs]

        cols = ('scope', 'title', 'progress', 'start')
        tree = ttk.Treeview(wrap, columns=cols, show='headings', selectmode='browse')
        tree.heading('scope', text=i18n.t('COMMON_TYPE','유형'))
        tree.heading('title', text=i18n.t('MYPATH_COL_PLAN','플랜'))
        tree.heading('progress', text=i18n.t('MYPATH_COL_PROGRESS','진행'))
        tree.heading('start', text=i18n.t('MYPATH_COL_START','시작일'))
        tree.column('scope', width=80, anchor='center')
        tree.column('title', width=400, anchor='w')
        tree.column('progress', width=80, anchor='center')
        tree.column('start', width=100, anchor='center')
        tree.pack(side='left', fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tree.yview)
        vsb.pack(side='right', fill='y')
        tree.config(yscrollcommand=vsb.set)
        tree.bind('<Double-1>', self._on_plan_dblclick)
        self._plan_tv = tree

        # 안내문 (데이터 없을 때 표시)
        self._plan_hint = tk.Label(
            self._sub_plan,
            text=i18n.t('MYPATH_HINT_NOPLAN','진행중인 묵상이 없습니다. 묵상 플랜 탭에서 새 플랜을 시작하세요.'),
            bg='#FAFAFA', fg='#566573', font=('Malgun Gothic', 9))

    # (독서 진행중 탭은 2026-08-19 재편으로 폐지 — 마지막 위치는 진행중 탭의
    #  「이어서 읽기」 행이, 즐겨찾기 도서 목록은 즐겨찾기 탭의 도서·설교 갈래가 맡는다)

    def _build_fav_subtab(self):
        # 필터
        filt = tk.Frame(self._sub_fav, bg='#FAFAFA')
        filt.pack(fill='x', padx=8, pady=(8, 4))
        _fs = tk.Frame(filt, bg='#FAFAFA')
        _fs.pack(side='left', padx=(0, 8))        # [Focus]/[Restore] 자리(2026-09-16)
        self.focus_slots = getattr(self, 'focus_slots', []) + [_fs]
        tk.Label(filt, text=i18n.t('COMMON_TYPE','유형')+':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left')
        self._fav_filter = ttk.Combobox(
            filt, state='readonly',
            values=[i18n.t('COMMON_ALL','전체')] + [i18n.t('FAVTYPE_'+k, v) for k, v in FAV_TYPE_LABEL.items() if k != 'VERSE'],
            width=15)
        self._fav_filter.current(0)
        self._fav_filter.pack(side='left', padx=4)
        self._fav_filter.bind('<<ComboboxSelected>>', lambda e: self._reload_favorites())

        # ★★ **분류값 필터 둘** (2026-08-30 사용자 지시 「하트표시, 별표는 모두
        #   P1 나의 묵상 탭의 즐겨찾기에서 볼 수 있도록 하고 **두 가지 분류값
        #   필터**를 제공하라」). 첫째 = 유형(위) · 둘째 = **읽음 상태**.
        # ★ 표식은 도서/설교와 **같은 매트릭스**다 — ★ 읽음∧찜 · ♥ 안 읽음∧찜.
        #   그 두 글리프가 여기서 갈리는 유일한 축이므로 그것이 곧 상태 필터다.
        tk.Label(filt, text=i18n.t('MYPATH_MARK', '표식') + ':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(14, 0))
        self._fav_mark = ttk.Combobox(
            filt, state='readonly', width=14,
            values=[i18n.t('COMMON_ALL', '전체'),
                    '★ ' + i18n.t('MYPATH_MARK_READ', '읽음'),
                    '♥ ' + i18n.t('MYPATH_MARK_UNREAD', '안 읽음')])
        self._fav_mark.current(0)
        self._fav_mark.pack(side='left', padx=4)
        self._fav_mark.bind('<<ComboboxSelected>>',
                            lambda e: self._reload_favorites())

        # Treeview
        wrap = tk.Frame(self._sub_fav, bg='#FAFAFA')
        wrap.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        cols = ('mark', 'type', 'label', 'note', 'added')
        tree = ttk.Treeview(wrap, columns=cols, show='headings', selectmode='browse')
        tree.heading('mark', text=i18n.t('MYPATH_MARK', '표식'))
        tree.column('mark', width=44, anchor='center')
        tree.heading('type', text=i18n.t('COMMON_TYPE','유형'))
        tree.heading('label', text=i18n.t('MYPATH_COL_LABEL','라벨'))
        tree.heading('note', text=i18n.t('MYPATH_COL_MEMO','메모'))
        tree.heading('added', text=i18n.t('MYPATH_COL_ADDED','추가일'))
        tree.column('type', width=80, anchor='center')
        tree.column('label', width=300, anchor='w')
        tree.column('note', width=200, anchor='w')
        tree.column('added', width=120, anchor='center')
        tree.pack(side='left', fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tree.yview)
        vsb.pack(side='right', fill='y')
        tree.config(yscrollcommand=vsb.set)
        tree.bind('<Double-1>', self._on_fav_dblclick)
        self._fav_tv = tree

    # ── 구절 즐겨찾기 서브탭 (VERSE 전용) ─────────────────────────────────

    def _build_versefav_subtab(self):
        f = self._sub_vfav
        filt = tk.Frame(f, bg='#FAFAFA'); filt.pack(fill='x', padx=8, pady=(8, 4))
        tk.Label(filt, text=i18n.t('MYPATH_VF_BOOK', '책') + ':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left')
        # ⚠ 정식명(예 「데살로니가전서」)이 들어가므로 폭을 넓힌다
        self._vf_book = ttk.Combobox(filt, state='readonly', width=15)
        self._vf_book.pack(side='left', padx=(2, 8))
        self._vf_book.bind('<<ComboboxSelected>>', self._on_vf_book)
        tk.Label(filt, text=i18n.t('MYPATH_VF_CHAP', '장') + ':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left')
        self._vf_chap = ttk.Combobox(filt, state='readonly', width=5)
        self._vf_chap.pack(side='left', padx=(2, 8))
        self._vf_chap.bind('<<ComboboxSelected>>', lambda e: self._reload_versefav())
        tk.Label(filt, text=i18n.t('MYPATH_VF_KEYWORD', '키워드') + ':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left')
        self._vf_kw = tk.Entry(filt, width=14, font=('Malgun Gothic', 9))
        self._vf_kw.pack(side='left', padx=2)
        self._vf_kw.bind('<Return>', lambda e: self._reload_versefav())
        tk.Button(filt, text=i18n.t('COMMON_SEARCH', '검색'), font=('Malgun Gothic', 8),
                  command=self._reload_versefav).pack(side='left', padx=2)
        # 액션 버튼 상단 배치 (§0 원칙)
        tk.Button(filt, text=i18n.t('MYPATH_VF_IMPORT', '새 추천 가져오기'),
                  font=('Malgun Gothic', 8, 'bold'), bg='#D4E6F1',
                  command=self._import_verse_recs).pack(side='right', padx=2)
        # ★ 2026-10-29 암송 주제에 담기(사용자 「즐겨찾기는 자기가 분류에 맞게 저장」 · 때에 맞는 말씀 ▸ 암송)
        self._vf_memo_btn = tk.Button(filt, text=i18n.t('M_VT_TO_MEMO', '암송 주제에 담기'), font=('Malgun Gothic', 8, 'bold'),
                                      command=self._vf_to_memo)
        self._vf_memo_btn.pack(side='right', padx=2)
        tk.Button(filt, text=i18n.t('MYPATH_VF_UNFAV', '즐겨찾기 해제'),
                  font=('Malgun Gothic', 8, 'bold'), bg='#FADBD8',
                  command=self._unfav_verse).pack(side='right', padx=2)

        # 상세/메모 패널 — 콤보 바로 아래(목록 위)에 배치(찾기 쉬움). 선택 구절 전체 본문 + 메모 입력
        det = tk.LabelFrame(f, text=i18n.t('MYPATH_VF_DETAIL', '구절 본문 · 메모'), bg='#FAFAFA',
                            font=('Malgun Gothic', 8, 'bold'))
        det.pack(side='top', fill='x', padx=8, pady=(4, 2))
        self._vf_body = tk.Label(det, text='', bg='white', anchor='w', justify='left',
                                 font=('Malgun Gothic', 10), wraplength=720, relief='solid', bd=1, padx=8, pady=6)
        self._vf_body.pack(fill='x', padx=4, pady=(4, 2))
        mrow = tk.Frame(det, bg='#FAFAFA'); mrow.pack(fill='x', padx=4, pady=(0, 4))
        tk.Label(mrow, text=i18n.t('MYPATH_COL_MEMO', '메모') + ':', bg='#FAFAFA',
                 font=('Malgun Gothic', 9)).pack(side='left')
        self._vf_memo = tk.Entry(mrow, font=('Malgun Gothic', 9))
        self._vf_memo.pack(side='left', fill='x', expand=True, padx=4)
        self._vf_memo.bind('<Return>', lambda e: self._save_vf_memo())
        tk.Button(mrow, text=i18n.t('COMMON_SAVE', '저장'), font=('Malgun Gothic', 8, 'bold'),
                  bg='#A9DFBF', command=self._save_vf_memo).pack(side='left', padx=2)

        wrap = tk.Frame(f, bg='#FAFAFA'); wrap.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        cols = ('ref', 'text', 'note', 'added')
        tree = ttk.Treeview(wrap, columns=cols, show='headings', selectmode='browse')
        tree.heading('ref', text=i18n.t('MYPATH_VF_REF', '참조'))
        tree.heading('text', text=i18n.t('COMMON_CONTENT', '본문'))
        tree.heading('note', text=i18n.t('MYPATH_COL_MEMO', '메모'))
        tree.heading('added', text=i18n.t('MYPATH_COL_ADDED', '추가일'))
        tree.column('ref', width=110, anchor='w')
        tree.column('text', width=360, anchor='w')
        tree.column('note', width=160, anchor='w')
        tree.column('added', width=90, anchor='center')
        tree.pack(side='left', fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tree.yview); vsb.pack(side='right', fill='y')
        tree.config(yscrollcommand=vsb.set)
        tree.bind('<Double-1>', self._on_versefav_dblclick)
        tree.bind('<<TreeviewSelect>>', self._on_vf_select)
        self._vf_tv = tree
        self._vf_data: dict = {}
        self._vf_books: list = []   # [(bcode, short)]
        self._vf_sel_fav = None

    # (최근 구절 탭은 2026-08-19 재편으로 폐지 — P1 Recent 팝업과 내용이 같았다.
    #  사용자: 「탭 제거하자. 필요 없다」)

    # ── 내 메모 (2026-08-15) ──────────────────────────────────────────

    # ⚠ 앞의 값은 **필터 열쇠이자 text_type** 이다 — 둘이 어긋나면
    #   목록이 조용히 빈다. `highlight_notes.KINDS` 를 단일 소스로 쓴다.
    _NOTE_KINDS = (('ALL',              '전체',   None),
                   (_HN.KINDS['BOOK'],  '도서',   'BOOK'),
                   ('SERMON',           '설교',   'SERMON'),
                   (_HN.KINDS['REF'],   '교리',   None),
                   ('VERS_NOTE',        '구절',   None))

    def _build_note_subtab(self):
        f = self._sub_note
        top = tk.Frame(f, bg='#FAFAFA'); top.pack(fill='x', padx=8, pady=(8, 4))
        self._note_filter = 'ALL'
        self._note_btns = {}
        for code, ko, _x in self._NOTE_KINDS:
            b = tk.Button(top, text=i18n.t('MYPATH_NK_' + code, ko),
                          font=('Malgun Gothic', 8), bd=1,
                          relief='sunken' if code == 'ALL' else 'raised',
                          cursor='hand2', padx=8,
                          command=lambda c=code: self._set_note_filter(c))
            b.pack(side='left', padx=(0 if code == 'ALL' else 2, 0))
            self._note_btns[code] = b
        self._note_cnt = tk.Label(top, text='', bg='#FAFAFA', fg='#7F8C8D',
                                  font=('Malgun Gothic', 8))
        self._note_cnt.pack(side='left', padx=(10, 0))
        tk.Button(top, text=i18n.t('COMMON_REFRESH', '새로고침'),
                  font=('Malgun Gothic', 8), command=self._reload_notes
                  ).pack(side='right', padx=2)

        wrap = tk.Frame(f, bg='#FAFAFA')
        wrap.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        cols = ('date', 'src', 'quote', 'note')
        tree = ttk.Treeview(wrap, columns=cols, show='headings', selectmode='browse')
        for c, ko, w in (('date', '날짜', 90), ('src', '어디', 220),
                         ('quote', '밑줄 친 곳', 300), ('note', '내 메모', 320)):
            tree.heading(c, text=i18n.t('MYPATH_NH_' + c, ko))
            tree.column(c, width=w, anchor='w')
        tree.tag_configure('lost', foreground='#B03A2E')
        tree.pack(side='left', fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical', command=tree.yview)
        vsb.pack(side='right', fill='y')
        tree.config(yscrollcommand=vsb.set)
        tree.bind('<Double-1>', self._on_note_dblclick)
        self._nt_tv = tree
        self._nt_data = {}
        self._reload_notes()

    def _set_note_filter(self, code):
        self._note_filter = code
        for c, b in self._note_btns.items():
            b.config(relief='sunken' if c == code else 'raised')
        self._reload_notes()

    def _reload_notes(self):
        tv = self._nt_tv
        tv.delete(*tv.get_children())
        self._nt_data = {}
        want = self._note_filter
        rows = []
        try:
            with appdb.connect(self.db_path) as conn:
                # 도서·설교집 — 유닛 제목과 책 제목을 함께
                if want in ('ALL', _HN.KINDS['BOOK'], 'SERMON'):
                    # ⚠ 유닛 제목은 **번역 덮개를 먼저** 본다 — `book_label` 참조.
                    for r in conn.execute("""
                        SELECT t.user_text_id, COALESCE(t.updated_at, t.created_at),
                               ba.book_category, ba.title, """ + book_label.SQL_PICK + """,
                               t.title, t.contents, t.clicked_id
                        FROM user_text_asset t
                        JOIN sys_book_unit  bu ON bu.unit_id = t.clicked_id
                        JOIN sys_book_asset ba ON ba.book_id = bu.book_id
                        """ + book_label.SQL_JOIN + """
                        WHERE t.text_type='""" + _HN.KINDS['BOOK'] + """'
                          AND COALESCE(t.record_status,'LIVE') IN ('LIVE','NEW','EDIT')""",
                            (self._vf_lang(),)):
                        nid, when, cat, btitle, ulabel, anchor, body, uid = r
                        kind = ('SERMON' if cat == 'SERMON'
                                else _HN.KINDS['BOOK'])
                        if want in (_HN.KINDS['BOOK'], 'SERMON') and kind != want:
                            continue
                        rows.append((nid, when, '%s · %s' % (
                            '설교' if kind == 'SERMON' else '도서', btitle),
                            anchor, body, ('BOOK', uid, ulabel)))
                # 교리자료
                if want in ('ALL', _HN.KINDS['REF']):
                    for r in conn.execute("""
                        SELECT t.user_text_id, COALESCE(t.updated_at, t.created_at),
                               s.title, u.unit_label, t.title, t.contents, t.clicked_id
                        FROM user_text_asset t
                        JOIN sys_ref_unit   u ON u.ref_unit_id = t.clicked_id
                        JOIN sys_ref_source s ON s.ref_src_id = u.ref_src_id
                        WHERE t.text_type='""" + _HN.KINDS['REF'] + """'
                          AND COALESCE(t.record_status,'LIVE') IN ('LIVE','NEW','EDIT')"""):
                        nid, when, stitle, ulabel, anchor, body, uid = r
                        rows.append((nid, when, '교리 · %s' % stitle,
                                     anchor, body, ('REF', uid, ulabel)))
                # 구절노트 — 닻이 없다(제목이 곧 제목이다)
                if want in ('ALL', 'VERS_NOTE'):
                    lang = self._ref_lang()
                    for r in conn.execute("""
                        SELECT t.user_text_id, COALESCE(t.updated_at, t.created_at),
                               bn.short_name, bi.chapter, bi.verse,
                               t.title, t.contents, t.clicked_id
                        FROM user_text_asset t
                        JOIN bible_index bi ON bi.verse_id = t.clicked_id
                        LEFT JOIN book_names bn ON bn.book_code = bi.bcode
                             AND UPPER(bn.lang_code) = ?
                        WHERE t.text_type='VERS_NOTE'
                          AND COALESCE(t.record_status,'LIVE') IN ('LIVE','NEW','EDIT')""",
                                          (lang,)):
                        nid, when, bk, ch, vs, ttl, body, vid = r
                        rows.append((nid, when, '구절 · %s %s:%s' % (bk or '?', ch, vs),
                                     None, body, ('VERSE', vid, ttl or '')))
        except Exception as e:
            print('[note hub] %s' % e)

        rows.sort(key=lambda x: (x[1] or ''), reverse=True)
        for nid, when, src, anchor, body, target in rows:
            quote = ''
            if anchor:
                try:
                    import highlight_notes
                    quote = highlight_notes.split_anchor(anchor)[1]
                except Exception:
                    quote = anchor
            elif target[2]:
                quote = target[2]                     # 구절노트는 제목이 그 자리
            iid = tv.insert('', 'end', values=(
                (when or '')[:10], src,
                self._cut(quote, 60), self._cut(' '.join((body or '').split()), 70)))
            self._nt_data[iid] = target
        self._note_cnt.config(text=i18n.t('MYPATH_NCNT', '%d건') % len(rows))

    @staticmethod
    def _cut(s, n):
        s = s or ''
        return s if len(s) <= n else s[:n] + '…'

    def _ref_lang(self):
        try:
            import lang_config
            return lang_config.ref_lang()
        except Exception:
            return 'KO'

    def _on_note_dblclick(self, _e=None):
        """그 메모가 붙은 자리로 간다."""
        sel = self._nt_tv.selection()
        if not sel:
            return
        kind, tid, _label = self._nt_data.get(sel[0], (None, None, None))
        if kind == 'VERSE' and callable(self.on_verse_jump):
            self.on_verse_jump(tid)
            # ⚠ 구절로 옮기기만 하면 **P2 가 어느 탭에 있는지는 안 바뀐다** —
            #   메모를 보러 눌렀는데 주석 탭이 떠 있으면 「안 보인다」가 된다.
            if callable(getattr(self, 'on_note_focus', None)):
                self.on_note_focus()
        elif kind in ('BOOK', 'REF') and callable(self.on_book_jump):
            self.on_book_jump(tid)

    def _vf_lang(self):
        return (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'

    def _reload_vf_books(self):
        lang = self._vf_lang()
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                # ★ **정식명**이다 (2026-08-23 사용자 「책 콤보상자에 표시되는
                #   것이 창, 출, 레 형식이다. 창세기, 출애굽기 등 정식명으로
                #   바꾸어라. 다국어 모드」). 약명은 구절 참조 표기(창1:1)와
                #   좁은 라벨의 것이고, **책을 고르는 콤보는 전부 full_name**
                #   이다(P1·관리자 구절연결관리·작성도구와 같은 규칙).
                "SELECT DISTINCT bi.bcode, "
                " (SELECT full_name FROM book_names WHERE book_code=bi.bcode "
                "    AND lang_code IN (?,'EN','KO') "
                "    ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1) "
                "FROM user_favorite uf JOIN bible_index bi ON bi.verse_id=uf.verse_id "
                "WHERE uf.fav_type='VERSE' AND uf.record_status='LIVE' ORDER BY bi.bcode",
                (lang, lang)).fetchall()
        finally:
            conn.close()
        self._vf_books = [(b, s or str(b)) for b, s in rows]
        all_lbl = i18n.t('COMMON_ALL', '전체')
        vals = [all_lbl] + [s for _, s in self._vf_books]
        self._vf_book['values'] = vals
        if self._vf_book.get() not in vals:
            self._vf_book.current(0)
        self._vf_chap['values'] = [all_lbl]
        self._vf_chap.current(0)

    def _on_vf_book(self, _e=None):
        sel = self._vf_book.get(); all_lbl = i18n.t('COMMON_ALL', '전체')
        chaps = []
        if sel and sel != all_lbl:
            bcode = next((b for b, s in self._vf_books if s == sel), None)
            if bcode is not None:
                conn = appdb.connect(self.db_path)
                try:
                    chaps = [r[0] for r in conn.execute(
                        "SELECT DISTINCT bi.chapter FROM user_favorite uf "
                        "JOIN bible_index bi ON bi.verse_id=uf.verse_id "
                        "WHERE uf.fav_type='VERSE' AND uf.record_status='LIVE' AND bi.bcode=? "
                        "ORDER BY bi.chapter", (bcode,)).fetchall()]
                finally:
                    conn.close()
        self._vf_chap['values'] = [all_lbl] + [str(c) for c in chaps]
        self._vf_chap.current(0)
        self._reload_versefav()

    def _reload_versefav(self):
        for iid in self._vf_tv.get_children():
            self._vf_tv.delete(iid)
        self._vf_data = {}
        self._vf_sel_fav = None
        if hasattr(self, '_vf_body'):
            self._vf_body.config(text='')
            self._vf_memo.delete(0, 'end')
        lang = self._vf_lang()
        import verse_tier   # 단일 소스(2026-07-30) — 없을 때만 언어별 기본값
        ver = verse_tier.get_version(self.db_path, None) or LANG_DEFAULT_VER.get(lang, 'KRV')
        all_lbl = i18n.t('COMMON_ALL', '전체')
        bsel = self._vf_book.get(); csel = self._vf_chap.get()
        kw = (self._vf_kw.get() or '').strip().lower()
        bcode = next((b for b, s in self._vf_books if s == bsel), None) if (bsel and bsel != all_lbl) else None
        conn = appdb.connect(self.db_path)
        try:
            q = ("SELECT uf.fav_id, uf.verse_id, uf.label, uf.note, uf.created_at, "
                 "  bi.bcode, bi.chapter, bi.verse, "
                 "  (SELECT short_name FROM book_names WHERE book_code=bi.bcode "
                 "     AND lang_code IN (?,'EN','KO') "
                 "     ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1) AS bk, "
                 "  (SELECT verse_text FROM bible_content WHERE verse_id=uf.verse_id AND version_code=?) AS body "
                 "FROM user_favorite uf JOIN bible_index bi ON bi.verse_id=uf.verse_id "
                 "WHERE uf.fav_type='VERSE' AND uf.record_status='LIVE' ")
            params = [lang, lang, ver]
            if bcode is not None:
                q += "AND bi.bcode=? "; params.append(bcode)
                if csel and csel != all_lbl and csel.isdigit():
                    q += "AND bi.chapter=? "; params.append(int(csel))
            q += "ORDER BY bi.bcode, bi.chapter, bi.verse"
            rows = conn.execute(q, params).fetchall()
            # ★ 합쳐진 절·없는 절을 **한 바퀴 안에서** 보완한다(§verse_text).
            #   ⚠ 표식·빈 칸인 줄만 — 정상 줄은 조회 결과 그대로 쓴다.
            _fix = {}
            for _r in rows:
                _vid, _b = _r[1], (_r[9] or '')
                if _vt.classify(_b, bool(_b))[0] != _vt.OK:
                    _fix[_vid] = _vt.resolve(conn, _vid, ver, lang)['text']
        finally:
            conn.close()
        for fav_id, vid, label, note, created, bc, ch, vs, bk, body in rows:
            ref = f'{bk or bc} {ch}:{vs}'
            body = body or ''
            if kw and kw not in (label or '').lower() and kw not in (note or '').lower() and kw not in body.lower():
                continue
            # ⚠ 위 검색(`kw in body`)은 **되돌리기 전 · 보완 전** 원문으로
            #   해야 걸린다 — 보완문으로 찾으면 설명문 낱말이 검색된다.
            body = _fix.get(vid, body)
            iid = self._vf_tv.insert('', 'end', values=(ref, bidi.for_display(body[:60]),
                                                        note or '', (created or '')[:10]))
            self._vf_data[iid] = {'fav_id': fav_id, 'fav_type': 'VERSE',
                                  'target_id': vid, 'verse_id': vid, 'source_code': 'USER',
                                  'body': body, 'note': note or '', 'ref': ref}

    def _on_vf_select(self, _e=None):
        sel = self._vf_tv.selection()
        if not sel:
            return
        info = self._vf_data.get(sel[0])
        if not info:
            return
        self._vf_sel_fav = info.get('fav_id')
        self._vf_body.config(text=f"[{info.get('ref','')}]  {info.get('body','')}")
        self._vf_memo.delete(0, 'end')
        self._vf_memo.insert(0, info.get('note', ''))

    def _save_vf_memo(self):
        if not self._vf_sel_fav:
            return
        note = (self._vf_memo.get() or '').strip()
        conn = appdb.connect(self.db_path)
        try:
            conn.execute("UPDATE user_favorite SET note=? WHERE fav_id=?",
                         (note, self._vf_sel_fav))
            conn.commit()
        finally:
            conn.close()
        self._reload_versefav()

    def _on_versefav_dblclick(self, _e=None):
        sel = self._vf_tv.selection()
        if not sel:
            return
        info = self._vf_data.get(sel[0])
        if info and self.on_favorite_jump:
            self.on_favorite_jump(info)

    def _vf_to_memo(self):
        """고른 즐겨찾기 구절을 암송 주제(관리자 열 + 내 주제) 가운데 하나에 담는다 — 단추 아래 메뉴."""
        sel = self._vf_tv.selection()
        info = self._vf_data.get(sel[0]) if sel else None
        if not info:
            return
        import db_verse_topic as VT
        conn = appdb.connect(self.db_path)
        try:
            ts = VT.topics(conn, (self.lang_getter() or 'KO').upper(), 'MEMO')
            r = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?', (info['verse_id'],)).fetchone()
        finally:
            conn.close()
        if not r:
            return
        ref = '%d:%d:%d' % r

        def put(key):
            c = appdb.connect(self.db_path)
            try:
                VT.add_verse(c, key, ref)
            finally:
                c.close()
        m = tk.Menu(self, tearoff=0)
        for t in ts:
            m.add_command(label=t['name'], command=lambda k=t['key']: put(k))
        b = self._vf_memo_btn
        m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())

    def _unfav_verse(self):
        sel = self._vf_tv.selection()
        if not sel:
            return
        info = self._vf_data.get(sel[0])
        if not info:
            return
        conn = appdb.connect(self.db_path)
        try:
            conn.execute("UPDATE user_favorite SET record_status='HIDE' WHERE fav_id=?", (info['fav_id'],))
            conn.commit()
        finally:
            conn.close()
        self._reload_vf_books(); self._reload_versefav()

    def _import_verse_recs(self):
        from datetime import datetime
        conn = appdb.connect(self.db_path)
        added = 0
        try:
            # ⚠ 책 약명이 `'KO'` 로 **박혀 있었다**(2026-08-14). 요청→EN→KO(§0-3).
            _lg = (self.lang_getter() or 'KO').upper()
            feat = conn.execute(
                "SELECT svh.verse_id, "
                " (SELECT short_name FROM book_names WHERE book_code=bi.bcode "
                "   AND UPPER(lang_code) IN (?,'EN','KO') "
                "   ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 "
                "            WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1), "
                " bi.chapter, bi.verse "
                "FROM sys_verse_highlight svh JOIN bible_index bi ON bi.verse_id=svh.verse_id "
                "WHERE svh.highlight_type='FEATURED' AND svh.record_status='LIVE'",
                (_lg, _lg)).fetchall()
            live = {r[0] for r in conn.execute(
                "SELECT verse_id FROM user_favorite WHERE fav_type='VERSE' "
                "AND record_status='LIVE' AND verse_id IS NOT NULL")}
            now = datetime.now().isoformat(timespec='seconds')
            for vid, bk, ch, vs in feat:
                if vid in live:
                    continue
                hid = conn.execute(
                    "SELECT fav_id FROM user_favorite WHERE fav_type='VERSE' AND verse_id=? "
                    "AND record_status='HIDE' LIMIT 1", (vid,)).fetchone()
                if hid:
                    conn.execute("UPDATE user_favorite SET record_status='LIVE' WHERE fav_id=?", (hid[0],))
                else:
                    conn.execute(
                        "INSERT INTO user_favorite(fav_type,target_id,verse_id,source_code,label,note,created_at,record_status) "
                        "VALUES('VERSE',?,?,?,?,?,?,'LIVE')",
                        (vid, vid, 'SYS_FEATURED', f'{bk} {ch}:{vs}', '', now))
                added += 1
            conn.commit()
        finally:
            conn.close()
        self._reload_vf_books(); self._reload_versefav()
        try:
            from tkinter import messagebox
            messagebox.showinfo(i18n.t('MYPATH_VF_IMPORT', '새 추천 가져오기'),
                                i18n.t('MYPATH_VF_IMPORTED', '{n}개 추가됨').format(n=added))
        except Exception:
            pass

    # ── 데이터 로딩 ──────────────────────────────────────────────────────

    def refresh(self):
        # 독서 진행중·최근 구절 탭은 2026-08-19 재편으로 없어졌다 —
        # 이어서 읽기는 _reload_plans 가 한 행으로 넣는다.
        self._reload_plans()
        self._reload_vf_books()
        self._reload_versefav()
        self._reload_favorites()

    def _reload_plans(self):
        for iid in self._plan_tv.get_children():
            self._plan_tv.delete(iid)
        self._plan_data = {}

        lang = self.lang_getter() if callable(self.lang_getter) else 'KO'
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute('''
                SELECT e.enrollment_id, e.plan_id, e.user_plan_id, e.current_day, e.start_date,
                       sp.cat_id AS sys_cat_id, up.origin_plan_id,
                       sp.duration_days AS sys_dur, up.duration_days AS user_dur
                  FROM user_plan_enrollment e
             LEFT JOIN sys_bible_plan sp ON sp.plan_id = e.plan_id
             LEFT JOIN user_bible_plan up ON up.user_plan_id = e.user_plan_id
                 WHERE e.enrollment_status='ACTIVE'
                   AND COALESCE(e.record_status, 'LIVE') = 'LIVE'
              ORDER BY e.start_date DESC
            ''')
            rows = c.fetchall()

            for r in rows:
                (enr_id, plan_id, user_plan_id, current_day, start_date,
                 sys_cat_id, origin_plan_id, sys_dur, user_dur) = r

                # cat_id 결정: sys_cat_id 우선, 아니면 origin_plan_id로 한 번 더
                cat_id = sys_cat_id
                if cat_id is None and origin_plan_id:
                    c.execute('SELECT cat_id FROM sys_bible_plan WHERE plan_id=?', (origin_plan_id,))
                    row = c.fetchone()
                    if row:
                        cat_id = row[0]

                # scope
                scope_raw = None
                if cat_id is not None:
                    c.execute('SELECT scope FROM sys_plan_category WHERE cat_id=?', (cat_id,))
                    row = c.fetchone()
                    if row:
                        scope_raw = row[0]
                scope = i18n.t('SCOPE_'+str(scope_raw), SCOPE_LABEL.get(scope_raw, '기타'))

                # duration
                duration = user_dur if user_dur else sys_dur

                # PLAN_TITLE 조회 (user_plan_id 우선)
                title_plan_id = user_plan_id if user_plan_id else plan_id
                c.execute('''SELECT contents FROM sys_text_asset
                              WHERE text_type='PLAN_TITLE' AND clicked_id=?
                                AND lang_code=? AND record_status='LIVE' LIMIT 1''',
                          (title_plan_id, lang))
                title_row = c.fetchone()
                if not title_row and lang != 'EN':
                    # 폴백: EN
                    c.execute('''SELECT contents FROM sys_text_asset
                                  WHERE text_type='PLAN_TITLE' AND clicked_id=?
                                    AND lang_code='EN' AND record_status='LIVE' LIMIT 1''',
                              (title_plan_id,))
                    title_row = c.fetchone()
                title = title_row[0] if title_row else f'plan_id={title_plan_id}'

                progress = f'{current_day}/{duration}' if duration else f'{current_day}/-'

                iid = self._plan_tv.insert(
                    '', 'end',
                    values=(scope, title, progress, start_date or ''))
                self._plan_data[iid] = {
                    'enrollment_id': enr_id,
                    'plan_id': plan_id,
                    'user_plan_id': user_plan_id,
                    'current_day': current_day,
                    'scope': scope,
                    'scope_raw': scope_raw,
                }

            # ── 이어서 읽기(독서 진행중) — 같은 목록의 한 행으로 (2026-08-19
            #    통합. 진행·시작일 칸은 독서에 없는 값이라 공란 — 사용자 확정)
            n_reading = 0
            lr = (self.last_reading_getter() or {}) if callable(
                getattr(self, 'last_reading_getter', None)) else {}
            unit_id = lr.get('unit_id')
            if unit_id:
                type_kr = (i18n.t('REFRT_BOOK', '도서') if lr.get('type') == 'BOOK'
                           else i18n.t('REFRT_SERMON', '설교'))
                title = ''
                try:
                    # ⚠ 유닛 제목은 **번역 덮개를 먼저** 본다 — `book_label` 참조.
                    r2 = c.execute(
                        "SELECT COALESCE(bat.title, ba.title, ''), "
                        "       COALESCE(" + book_label.SQL_PICK + ", '') "
                        "FROM sys_book_unit bu "
                        "JOIN sys_book_asset ba ON ba.book_id=bu.book_id "
                        "LEFT JOIN sys_book_asset_text bat "
                        "     ON bat.book_id=ba.book_id AND UPPER(bat.lang_code)=? "
                        + book_label.SQL_JOIN +
                        "WHERE bu.unit_id=?", ((lang or 'KO').upper(),
                                               (lang or 'KO'), unit_id)).fetchone()
                    if r2:
                        title = ' · '.join(x for x in r2 if x)
                except Exception:
                    pass
                iid = self._plan_tv.insert(
                    '', 'end',
                    values=(type_kr,
                            '%s  %s' % (i18n.t('MYPATH_CONTINUE_SHORT',
                                               '이어서 읽기'), title), '', ''))
                self._plan_data[iid] = {'kind': 'READING', 'unit_id': unit_id}
                n_reading = 1

            # 안내문 표시 토글
            if rows or n_reading:
                self._plan_hint.pack_forget()
            else:
                self._plan_hint.pack(side='bottom', pady=12)
        finally:
            conn.close()

    # (_reload_books 는 2026-08-19 폐지 — 마지막 위치는 _reload_plans 의
    #  「이어서 읽기」 행이, 즐겨찾기 도서 목록은 _reload_favorites(도서·설교
    #  갈래의 유형 콤보)가 그대로 커버한다)

    def _reload_favorites(self):
        for iid in self._fav_tv.get_children():
            self._fav_tv.delete(iid)
        self._fav_data = {}

        filt = self._fav_filter.get()
        type_filter = None
        if filt and filt != i18n.t('COMMON_ALL','전체'):
            for k, v in FAV_TYPE_LABEL.items():
                if i18n.t('FAVTYPE_'+k, v) == filt:
                    type_filter = k
                    break

        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            base = '''SELECT fav_id, fav_type, target_id, verse_id, label, note,
                              created_at, source_code
                        FROM user_favorite
                       WHERE record_status='LIVE' '''
            if type_filter:
                c.execute(base + " AND fav_type=? ORDER BY created_at DESC",
                          (type_filter,))
            else:   # VERSE는 전용 서브탭에서 관리 — 통합 탭에서 제외
                c.execute(base + " AND fav_type!='VERSE' ORDER BY created_at DESC")
            rows = c.fetchall()
            # ★ 읽음 집합은 **한 번에** 가져온다 — 행마다 물으면 그만큼 질의가 난다
            #   (`db_read_state.read_ids` 주석과 같은 이유).
            read = {}
            try:
                import db_read_state
                for kind in ('BOOK', 'REF'):
                    read[kind] = db_read_state.read_ids(conn, kind=kind)
            except Exception:
                read = {}
            done_plans = set()
            try:
                for (x,) in c.execute(
                        "SELECT COALESCE(plan_id, user_plan_id) FROM user_plan_enrollment"
                        " WHERE enrollment_status='COMPLETED' AND record_status='LIVE'"):
                    if x:
                        done_plans.add(x)
            except Exception:
                pass
            want = self._fav_mark.get() if hasattr(self, '_fav_mark') else ''
            want = ('★' if want.startswith('★') else
                    '♥' if want.startswith('♥') else None)
            for r in rows:
                fav_id, ftype, tid, vid, label, note, created, src_code = r
                # ⚠ **갈래를 가르지 않으면 도서와 교리자료가 서로 물든다**
                #   (번호가 549개 겹친다 — `db_read_state.read_ids` 실측).
                # ⚠ **묵상후보(플랜)는 유닛이 아니다** — 읽음 표를 물으면 엉뚱한
                #   도서 유닛 번호와 우연히 겹친다. 플랜은 **완료 등록**으로 본다.
                if ftype == 'PLAN_WISH':
                    done = tid in done_plans
                else:
                    kind = 'REF' if ftype == 'REF_UNIT' else 'BOOK'
                    done = tid in read.get(kind, ())
                mark = '★' if done else '♥'
                if want and mark != want:
                    continue
                type_label = i18n.t('FAVTYPE_'+str(ftype), FAV_TYPE_LABEL.get(ftype, ftype))
                added = (created or '')[:10]
                iid = self._fav_tv.insert(
                    '', 'end',
                    values=(mark, type_label, label or '', note or '', added))
                self._fav_data[iid] = {
                    'fav_id': fav_id, 'fav_type': ftype,
                    'target_id': tid, 'verse_id': vid,
                    'source_code': src_code or 'SYS'}
        finally:
            conn.close()

    # ── 점프 콜백 ──────────────────────────────────────────────────────────

    def _on_plan_dblclick(self, _evt):
        sel = self._plan_tv.selection()
        if not sel:
            return
        info = self._plan_data.get(sel[0])
        if not info:
            return
        # 진행중 통합(2026-08-19) — 독서(이어서 읽기) 행은 도서 화면으로
        if info.get('kind') == 'READING':
            if self.on_book_jump and info.get('unit_id'):
                self.on_book_jump(info['unit_id'])
            return
        if self.on_plan_jump:
            self.on_plan_jump(info)

    def _on_fav_dblclick(self, _evt):
        sel = self._fav_tv.selection()
        if not sel:
            return
        info = self._fav_data.get(sel[0])
        if info and self.on_favorite_jump:
            self.on_favorite_jump(info)
