# -*- coding: utf-8 -*-
"""db_unit_audit.py — **유튜브 쿼터(units) 점검** (2026-09-17 신설·영구, `--selftest` 의무).

사용자: 「자동수집·수동수집이 unit 소비량을 효과적으로 통제하도록 설계되어 있는지, 낭비하는
요소가 있는지 점검하라. 이미 수집한 데이터를 중복해서 수집하는지 …」

★★★ **이 파일이 존재하는 까닭 한 줄 — `search.list` 는 결과가 1개든 50개든 100 units 다.**
  그래서 「몇 개를 받는가」가 곧 효율이고, 그 값이 자리마다 흩어져 있으면 **아무도 모르게 손해**가 난다.
  실측(2026-09-17) 구절·용어 수동수집이 **5개**만 받고 있었다 — 1,675회 = **167,500 units 로 8,375개**.

| 부르는 곳 | 비용 | 한 번에 | 쿼터를 지키는 장치 |
|---|---|---|---|
| `search.list`(구절·용어·찬양·곡·채널 발굴) | **100** | 1~50 (**같은 값**) | 페이지 크기 · 시도 로그(안 돈 것부터) · 씨앗 자기 교정 |
| `playlistItems.list`(등록 채널 수집) | **1** | 최대 50 | **RSS 를 먼저**(쿼터 0) 돌리고 끝난 채널은 뺀다 · 주기(`pace`) |
| `videos.list`(설명문·길이·조회수·링크 점검) | **1 / 50개** | 50 | 50개씩 묶는다 · `DAILY_MAX` · `only_missing` |
| `channels.list`(구독자·주소 점검) | **1 / 50개** | 50 | 50개씩 묶는다 |
| RSS(`youtube_channel_rss`) | **0** | 15 | — |

⚠ **중복 수집의 층이 둘이다** — ⓐ **같은 영상을 다시 담는 것**은 `media_intake.admit` 이 주소로 막아
  **저장은 안 되지만 검색 비용은 이미 나갔다** ⓑ **같은 검색을 다시 도는 것**이 진짜 낭비다.
  그래서 잣대는 「담은 수」가 아니라 **「본 것 대비 새것」**(`n_seen` 대 `n_new`)이다.

쓰는 법 — `python db_unit_audit.py`(점검) · `--selftest`.
"""
import io
import os
import re
import sys
import sqlite3

APP = os.path.dirname(os.path.abspath(__file__))
#: `search.list` 를 부르는 자리 — (파일, 사람이 읽는 이름, 이 자리의 최소 권장 페이지)
SEARCH_SITES = (
    ('db_media_crawler.py', '구절·용어 수동수집', 25),
    ('db_worship_collect.py', '찬양·성경듣기 씨앗', 50),
    ('db_song_collect.py', '곡 이름 수집', 25),
    ('admin/panel_entity_youtube.py', '엔티티 수집(관리자)', 25),
)
_PAGE = re.compile(r'maxResults\s*=\s*(\d+)')
_PAGE_VAR = re.compile(r'(?:SEARCH_PAGE|DEFAULT_PER)\s*=\s*(\d+)')


def page_sizes(root=APP):
    """검색 자리의 페이지 크기 → [(파일, 이름, 값|None, 권장)]. 상수와 리터럴 둘 다 본다."""
    out = []
    for fn, label, want in SEARCH_SITES:
        p = os.path.join(root, fn)
        try:
            src = io.open(p, encoding='utf-8').read()
        except Exception:
            out.append((fn, label, None, want))
            continue
        got = None
        m = _PAGE_VAR.search(src)
        if m:
            got = int(m.group(1))
        else:
            nums = [int(x) for x in _PAGE.findall(src)]
            # 채널 검색(1)·미리보기처럼 작은 값이 섞인다 — **검색 자리의 최대치**를 본다
            got = max(nums) if nums else None
        out.append((fn, label, got, want))
    return out


def seed_yield(conn):
    """씨앗 낱말 — 본 것 대비 새것(분야·갈래별). → [(domain, kind, 낱말, 돈 횟수, units, 본 것, 새것, 비율)]"""
    rows = []
    for d, k, cnt, run, seen, new in conn.execute(
            "SELECT COALESCE(domain,'COMMON'), COALESCE(kind,''), COUNT(*),"
            " COALESCE(SUM(n_run),0), COALESCE(SUM(n_seen),0), COALESCE(SUM(n_new),0)"
            "  FROM sys_mine_keyword WHERE COALESCE(enabled,1)=1 GROUP BY 1,2"):
        rows.append((d, k, cnt, run, run * 100, seen, new,
                     (100.0 * new / seen) if seen else 0.0))
    return rows


def repeat_attempts(conn):
    """같은 자리를 다시 판 시도 → (중복 조합, 재시도 횟수, 낭비 units)."""
    try:
        rows = conn.execute(
            "SELECT COUNT(*) n FROM sys_media_attempt GROUP BY scope, key_id, lang HAVING n>1").fetchall()
    except Exception:
        return 0, 0, 0
    extra = sum(r[0] - 1 for r in rows)
    return len(rows), extra, extra * 100


def daily_plan(conn):
    """하루에 나갈 units 어림 → [(이름, units, 까닭)]."""
    out = []
    try:
        per = dict(conn.execute(
            "SELECT COALESCE(check_interval_days,14), COUNT(*) FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(enabled,1)=1 GROUP BY 1"))
        # RSS 가 먼저 돌아 대부분을 끝낸다 — playlistItems 는 RSS 가 놓친 것만(보수적으로 10%)
        due = sum(n / max(1, d) for d, n in per.items())
        out.append(('등록 채널 수집(playlistItems)', int(due * 0.1),
                    '기한 지난 채널 %d곳/일 · RSS(쿼터 0)가 먼저 · 한 채널 1 unit' % int(due)))
    except Exception:
        pass
    try:
        import db_media_linkcheck as LC
        out.append(('링크 점검(videos.list)', (LC.DAILY_MAX + 49) // 50,
                    '하루 %d건 · 50개당 1 unit' % LC.DAILY_MAX))
    except Exception:
        pass
    try:
        import db_worship_collect as WC
        # ⚠ **갈래마다 한 바퀴**를 돈다(`_worship_round` 가 `WC.KINDS` 를 돈다) —
        #   갈래를 섞어 언어 수만 세면 어림이 갈래 수만큼 적게 나온다.
        _parts, _tot = [], 0
        for _c, _ko in WC.KINDS:
            _n = len({r[1] for r in WC.keywords(conn, _c)})
            if _n:
                _parts.append('%s %d' % (_ko, _n * 100))
                _tot += _n * 100
        for _dm, _dk in (('READING', '성경듣기'), ('PRAYER', '기도')):
            _nr = len({r[1] for r in WC.keywords(conn, domain=_dm)})
            if _nr:
                _parts.append('%s %d' % (_dk, _nr * 100))
                _tot += _nr * 100
        out.append(('찬양·성경듣기·기도 한 바퀴(search)', _tot,
                    '갈래마다 언어 하나씩 — ' + ' · '.join(_parts)))
    except Exception:
        pass
    try:
        import db_channel_mine as CM
        n = int(CM.discover_n(conn)) if hasattr(CM, 'discover_n') else 5
        out.append(('채널 자동 발굴(search)', n * 100, '씨앗 %d개 × 100 · 월·수·금' % n))
    except Exception:
        out.append(('채널 자동 발굴(search)', 500, '씨앗 5개 × 100 · 월·수·금'))
    return out


def _log(msg=''):
    """줄마다 **즉시 비운다** — 남이 `sys.stdout` 을 갈아 끼워도 차례가 지켜진다.

    ⚠ `daily_plan` 이 부르는 모듈들이 **import 만으로** stdout 을 바꾼다
      (저장소 전역 관례 · 실측 20여 개). 그때 버퍼가 남아 있으면 보고서가
      뒤집혀 찍힌다 — 실제로 ④ 가 맨 위에 나왔다.
    """
    import sys as _s
    print(msg)
    try:
        _s.stdout.flush()
    except Exception:
        pass


def report(conn, log=_log):
    bad = []
    log('── ① 검색 페이지 크기 (100 units 로 몇 개를 보나)')
    for fn, label, got, want in page_sizes():
        mark = 'OK ' if (got or 0) >= want else '낭비'
        if (got or 0) < want:
            bad.append('%s — %s개만 받는다(권장 %d)' % (label, got, want))
        log('   %s %-22s %-34s %s개 / 권장 %d' % (mark, str(got), label, got, want))
    log('── ② 씨앗 낱말 — 본 것 대비 새것')
    for d, k, cnt, run, units, seen, new, pct in seed_yield(conn):
        log('   %-8s %-9s 낱말 %3d · 돈 %4d회(%6d units) · 본 %6d · 새 %5d (%.1f%%)'
            % (d, k or '-', cnt, run, units, seen, new, pct))
        if seen >= 200 and pct < 10:
            bad.append('%s/%s 씨앗 — 본 것의 %.1f%% 만 새것(검색어를 갈거나 기간을 좁힌다)' % (d, k or '-', pct))
    log('── ③ 같은 자리를 다시 판 시도')
    nd, extra, waste = repeat_attempts(conn)
    log('   중복 조합 %d개 · 재시도 %d회 · %d units' % (nd, extra, waste))
    log('── ④ 하루 어림')
    tot = 0
    for nm, u, why in daily_plan(conn):
        tot += u
        log('   %-28s %6d units  (%s)' % (nm, u, why))
    log('   합계 약 %d units / 키 하나 하루 10,000' % tot)
    log('── 판정')
    if bad:
        for b in bad:
            log('   ⚠ ' + b)
    else:
        log('   ✅ 낭비로 볼 자리 없음')
    return bad


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))
    print('=== db_unit_audit selftest')
    ps = {label: got for _f, label, got, _w in page_sizes()}
    t('★★★ 검색 자리 넷을 전부 읽는다', len(ps) == 4 and all(v for v in ps.values()), ps)
    t('★★★ **구절·용어 수동수집이 25개 이상**(100 units 에 5개는 낭비)',
      (ps.get('구절·용어 수동수집') or 0) >= 25, ps.get('구절·용어 수동수집'))
    t('★★ 찬양 씨앗은 50(최신순이라 깎을 까닭이 없다)',
      (ps.get('찬양·성경듣기 씨앗') or 0) >= 50, ps.get('찬양·성경듣기 씨앗'))
    # 탐지력 — 값을 낮춘 가짜 소스를 읽어 잡아내는가
    import tempfile
    d = tempfile.mkdtemp()
    os.makedirs(os.path.join(d, 'admin'), exist_ok=True)
    for fn, _l, _w in SEARCH_SITES:
        io.open(os.path.join(d, fn), 'w', encoding='utf-8').write('maxResults=5\n')
    low = [g for _f, _l, g, _w in page_sizes(d)]
    t('  잣대가 실제로 잡는다(가짜 소스 5 → 전부 낮음)', low == [5, 5, 5, 5], low)
    # 길이 제한을 되돌려 놓지 않았는가 — 20분 넘는 설교를 API 자리에서 버리던 자리
    src = io.open(os.path.join(APP, 'db_media_crawler.py'), encoding='utf-8').read()
    t("★★★ `videoDuration='medium'` 을 안 쓴다(20분 초과 설교 5,591편을 버리던 자리)",
      "videoDuration='medium'" not in src.replace('#', '\\n#').split('\\n#')[0] or
      not re.search(r"^\s*videoDuration='medium'", src, re.M))
    t('★★ 결과마다 HTTP 로 쇼츠를 묻지 않는다(문지기가 길이로 거른다)',
      not re.search(r'^\s*if is_youtube_short\(', src, re.M))
    cc = io.open(os.path.join(APP, 'collect_channels.py'), encoding='utf-8').read()
    t('★★ 채널 수집의 search 폴백(100 units)에 상한이 있다', 'FALLBACK_MAX' in cc)
    t('  없는 채널·쿼터면 폴백을 안 한다', "playlistNotFound" in cc)
    # 묶음 조회는 50개씩
    lc = io.open(os.path.join(APP, 'db_media_linkcheck.py'), encoding='utf-8').read()
    import re as _re
    _b = _re.findall(r'\[i:i \+ (\d+)\]', lc)
    t('★ videos.list·channels.list 는 50개씩 묶는다(1 unit)',
      bool(_b) and all(int(x) == 50 for x in _b), _b)
    # 실 DB 가 있으면 한 번 돌려 본다(읽기만)
    try:
        import appdb
        c = appdb.connect()
        try:
            n0 = c.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0]
            report(c, log=lambda *_a: None)
            t('  실 DB 로 점검이 돌고 아무것도 안 바꾼다',
              c.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0] == n0)
        finally:
            c.close()
    except Exception as e:
        t('  실 DB 점검', False, str(e)[:60])
    print('db_unit_audit selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv[1:]:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    try:
        report(conn)
    finally:
        conn.close()
