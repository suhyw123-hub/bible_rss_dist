"""db_read_state.py — 도서·설교 유닛의 「읽음」 기록 (영구 도구·헬퍼).

**왜 새로 만들었나.** 2026-08-15 실측 — 읽음을 담은 곳이 어디에도 없었다.
`user_favorite` 는 `VERSE` 46건뿐이고, `app_state.json['last_reading']` 은
**마지막 한 건**만 기억한다. 그래서 설교 3,519편 중 무엇을 읽었는지 표시할 수 없었다.

담는 것은 둘뿐이다:
  ① **읽음**(`user_book_read`) — 편 하나와 언제 읽었나. 읽음의 **단일 소스**.
  ② **읽는 자리**(`user_book_pos`) — 책마다 한 줄. 어느 **편**까지 왔나.

⚠⚠ 2026-08-24 — 한때 편 안을 ~1,000자로 쪼갠 「파트」를 세었으나 **전량
  폐기했다**(사용자 「다시는 파트 따위의 설계를 하지 마라」). 단위는 **저자가
  나눈 편**뿐이다. 까닭은 아래 「읽는 자리」 절에.

쓰는 곳:
  · 설교집 목록의 ● / ○ 표시
  · 상단 걸러보기 [전체][● 진행중][✓ 완료]
  · 「▶ 이어서」 한 줄 (설교번호 순으로 다음 것)
  · **진행 띠** — `◐ 3 / 18편  [◀ 이전 편][이어서 읽기][다음 편 ▶][완료]`

⚠ `userdb`(user_data.db)에 만든다 — 사용자 개인 기록이라 배포물에 안 실린다.
⚠ **`sys_book_unit` 에 외래키를 걸지 않는다.** 두 DB 가 따로 있어 걸 수 없고,
   콘텐츠를 통째로 교체 배포해도 사용자 기록이 살아남아야 한다(§1).

사용:
    python db_read_state.py --selftest    (의무)
    python db_read_state.py --init
    python db_read_state.py --status
"""
import sys
import appdb

TABLE = 'user_book_read'

# ⚠ 열쇠는 **`(kind, unit_id)`** 다. 도서 유닛과 교리자료 유닛은 표가 달라
#   번호가 겹친다(실측 549개). `unit_id` 만으로 담으면 서로를 읽음으로 물들인다.
DDL = """
CREATE TABLE IF NOT EXISTS userdb.user_book_read (
    kind      TEXT    NOT NULL DEFAULT 'BOOK',
    unit_id   INTEGER NOT NULL,
    read_at   TEXT    NOT NULL,
    book_id   INTEGER,
    PRIMARY KEY (kind, unit_id)
)
"""
IDX = ("CREATE INDEX IF NOT EXISTS userdb.idx_book_read_book "
       "ON user_book_read(kind, book_id)")


def ensure(conn):
    """표가 없으면 만든다. 매 조회 앞에 불러도 싸다."""
    conn.execute(DDL)
    conn.execute(IDX)


def mark(conn, unit_id, book_id=None, when=None, kind='BOOK'):
    """읽음으로 표시. 이미 있으면 시각만 갱신한다(다시 읽는 일이 잦다)."""
    ensure(conn)
    if when is None:
        from datetime import date
        when = date.today().isoformat()
    conn.execute(
        "INSERT INTO user_book_read (kind, unit_id, read_at, book_id) VALUES (?,?,?,?) "
        "ON CONFLICT(kind, unit_id) DO UPDATE SET read_at=excluded.read_at",
        (kind, unit_id, when, book_id))
    conn.commit()


def unmark(conn, unit_id, kind='BOOK'):
    ensure(conn)
    conn.execute("DELETE FROM user_book_read WHERE kind=? AND unit_id=?",
                 (kind, unit_id))
    conn.commit()


def read_ids(conn, book_id=None, kind='BOOK'):
    """그 갈래에서 읽은 unit_id 집합.

    **한 번에 가져와 화면이 행마다 묻지 않게 한다** — 설교 3,519행에서 행마다
    물으면 그만큼 질의가 난다.
    ⚠ `kind` 를 빼먹으면 도서와 교리자료가 서로 물든다(id 549개 겹침).
    """
    ensure(conn)
    if book_id is None:
        return {r[0] for r in conn.execute(
            "SELECT unit_id FROM user_book_read WHERE kind=?", (kind,))}
    return {r[0] for r in conn.execute(
        "SELECT unit_id FROM user_book_read WHERE kind=? AND book_id=?",
        (kind, book_id))}


#: 연구자료(sys_ref_unit) 읽음 갈래 — 도서·교리 번호와 섞이지 않게 따로 둔다
REF = 'REF'


def ref_marks(conn):
    """✓ 를 붙일 연구자료 번호 — **사람이 [읽었음]을 누른 글 전부**.

    ★ 2026-10-16 (docs/1.txt 2-1 · 사용자 「목록을 클릭했는데 체크 표시를 한다」) — 열기만 해서는 안 적고
      본문 제목 오른쪽 [읽었음]을 눌러야 적는다. 사람이 고른 것이므로 여러 절 거르개도 걷었다.
    (옛 설명 —) **읽었고 · 여러 절에 걸친** 글만.

    ★ 2026-10-11 (docs/1.txt 7 · 사용자 「여러 단락이나 장에 걸쳐 있는 연구자료의
      경우 이미 읽었다는 표시가 의미있을 것」) — 한 절에만 걸린 글은 그 절에서만
      만나므로 표시가 소음이다. 기록은 모든 글에 남기고 **보이는 것만** 가른다.
    """
    return read_ids(conn, kind=REF)
    multi = {r[0] for r in conn.execute(
        "SELECT clicked_id FROM sys_link_asset "
        "WHERE link_type='REFU_VERS' AND COALESCE(record_status,'LIVE')='LIVE' "
        "GROUP BY clicked_id "
        "HAVING COUNT(*)>1 OR MAX(COALESCE(end_id,target_id)-target_id)>0")}
    return read & multi


def next_unit(conn, book_id):
    """그 책에서 **아직 안 읽은 첫 유닛** — 「▶ 이어서」용.

    ⚠ 순서는 `sequence`(설교번호·연대순)를 그대로 따른다. 읽은 것을 위로 올리는
      재정렬을 하지 않는다 — 설교집은 번호 자체가 정보다(사용자 지시 2026-08-15).
    """
    ensure(conn)
    return conn.execute("""
        SELECT bu.unit_id, bu.sequence, bu.unit_label
        FROM sys_book_unit bu
        WHERE bu.book_id=? AND COALESCE(bu.record_status,'LIVE')='LIVE'
          AND bu.unit_id NOT IN
              (SELECT unit_id FROM user_book_read WHERE kind='BOOK')
        ORDER BY bu.sequence, bu.unit_id LIMIT 1""", (book_id,)).fetchone()


# ═════════════════════════════════════════════════════════════════════════
#  읽는 자리 — **편 단위**  (2026-08-24 · 파트 폐기)
# ═════════════════════════════════════════════════════════════════════════
# ★★★ **파트를 전량 폐기했다** (사용자 「다시는 파트 따위의 설계를 하지 마라」).
#   한 편이 수십 쪽이라 ~1,000자마다 잘라 「파트」로 세었는데:
#     ① 경계가 화면에 안 보여 [이전][다음]이 **스크롤처럼만** 느껴졌고
#     ② 편을 닻으로 쓰면서 파트가 있으니 **페이지마다 쓸 수 있는 것으로 착각**하게 했고
#     ③ 저자가 안 나눈 자리에 의미를 붙이는 것이라 **오류 가능성이 더 크며**
#     ④ DB 행도 없이 그릴 때마다 다시 계산했고 **붙는 것이 아무것도 없었다.**
#   ⇒ 단위는 **저자가 나눈 편**뿐이다. 긴 글 안의 특정 대목은 **여백메모**
#     (인용문 닻)가 맡는다 — 이미 있는 도구다.
# ★ 읽음의 단일 소스는 `user_book_read`(편 단위). 여기 담는 것은 「어디까지
#   왔나」 **한 줄뿐**(책마다 하나).
# ⚠ `user_book_pos.part_no` 는 **옛 DB 에 남아 있을 수 있다** — 읽지도 쓰지도
#   않는다(NOT NULL DEFAULT 0 이라 빼고 INSERT 해도 된다).

POS_TABLE = 'user_book_pos'
POS_DDL = """
CREATE TABLE IF NOT EXISTS userdb.user_book_pos (
    kind       TEXT    NOT NULL DEFAULT 'BOOK',
    book_id    INTEGER NOT NULL,
    unit_id    INTEGER NOT NULL,
    updated_at TEXT    NOT NULL,
    PRIMARY KEY (kind, book_id)
)
"""


def ensure_pos(conn):
    conn.execute(POS_DDL)


def get_pos(conn, book_id, kind='BOOK'):
    """읽던 편의 `unit_id` 또는 None."""
    ensure_pos(conn)
    r = conn.execute(
        "SELECT unit_id FROM user_book_pos WHERE kind=? AND book_id=?",
        (kind, book_id)).fetchone()
    return r[0] if r else None


def set_pos(conn, book_id, unit_id, kind='BOOK'):
    """책마다 **한 줄**. 편을 옮길 때마다 덮어쓴다."""
    ensure_pos(conn)
    from datetime import datetime
    conn.execute(
        "INSERT INTO user_book_pos (kind, book_id, unit_id, updated_at) "
        "VALUES (?,?,?,?) "
        "ON CONFLICT(kind, book_id) DO UPDATE SET "
        "  unit_id=excluded.unit_id, updated_at=excluded.updated_at",
        (kind, book_id, unit_id, datetime.now().isoformat(' ', 'seconds')))
    conn.commit()


def clear_pos(conn, book_id, kind='BOOK'):
    ensure_pos(conn)
    conn.execute("DELETE FROM user_book_pos WHERE kind=? AND book_id=?",
                 (kind, book_id))
    conn.commit()


# ── 「읽는 중」 = 사람이 [읽기 시작]을 누른 책 (2026-10-16 사용자) ─────────────
# ★★ 읽던 자리(`user_book_pos`)와 따로 둔다 — 사용자 「한번 살펴보려고 들어간 것일 뿐이다.
#   명시적인 구독(읽기시작) 버튼이 있어야 살펴보는 것과 정식읽기를 구분할 수 있다」.
#   편을 열면 자리는 늘 담기지만(다시 열면 그 편으로) **「읽는 중」 목록에는 여기 있는 책만** 든다.
#   중단 = 줄을 지운다(읽음·자리는 남는다). 폰에는 사본으로 간다(mobile_sync.MIRROR_TABLES).
READING_TABLE = 'user_book_reading'
READING_DDL = """
CREATE TABLE IF NOT EXISTS userdb.user_book_reading (
    kind       TEXT    NOT NULL DEFAULT 'BOOK',
    book_id    INTEGER NOT NULL,
    started_at TEXT    NOT NULL,
    PRIMARY KEY (kind, book_id)
)
"""


def ensure_reading(conn):
    conn.execute(READING_DDL)


def is_reading(conn, book_id, kind='BOOK'):
    ensure_reading(conn)
    return conn.execute("SELECT 1 FROM user_book_reading WHERE kind=? AND book_id=?",
                        (kind, book_id)).fetchone() is not None


def start_reading(conn, book_id, kind='BOOK', when=None):
    """[읽기 시작] — 이미 있으면 그대로(시작한 때를 안 바꾼다)."""
    ensure_reading(conn)
    from datetime import datetime
    conn.execute("INSERT OR IGNORE INTO user_book_reading (kind, book_id, started_at) VALUES (?,?,?)",
                 (kind, book_id, when or datetime.now().isoformat(' ', 'seconds')))
    conn.commit()


def stop_reading(conn, book_id, kind='BOOK'):
    """[읽기 중단] — 「읽는 중」에서만 빠진다. 읽음 표시·읽던 자리는 남는다."""
    ensure_reading(conn)
    conn.execute("DELETE FROM user_book_reading WHERE kind=? AND book_id=?", (kind, book_id))
    conn.commit()


def reading_list(conn):
    """[(kind, book_id, started_at)] — 최근에 시작한 것 먼저."""
    ensure_reading(conn)
    return [tuple(r) for r in conn.execute(
        "SELECT kind, book_id, started_at FROM user_book_reading ORDER BY started_at DESC")]


def unit_map(conn, book_id):
    """`([unit_id] sequence 순, 편 수)`."""
    rows = conn.execute(
        "SELECT unit_id FROM sys_book_unit "
        " WHERE book_id=? AND COALESCE(record_status,'LIVE')='LIVE' "
        " ORDER BY sequence, unit_id", (book_id,)).fetchall()
    out = [r[0] for r in rows]
    return out, len(out)


def locate(conn, book_id, unit_id):
    """`(책 안 몇 번째 편인가(1부터), 편 수)`. 못 찾으면 `(0, 전체)`."""
    umap, total = unit_map(conn, book_id)
    try:
        return umap.index(unit_id) + 1, total
    except ValueError:
        return 0, total


def read_progress(conn, book_id, kind='BOOK'):
    """`(읽은 편 수, 전체 편 수)`.

    ⚠ 편마다 길이가 크게 다르지만(1,000자 ↔ 37만 자) **가중하지 않는다** —
      가중하려면 다시 우리가 센 단위가 필요해지고, 그것이 파트였다.
      「몇 편 중 몇 편」은 저자가 나눈 그대로라 언제나 참이다.
    """
    umap, total = unit_map(conn, book_id)
    done = read_ids(conn, book_id, kind)
    return sum(1 for uid in umap if uid in done), total


def step(conn, book_id, unit_id, delta):
    """이전/다음 **편** 한 칸. 끝이면 `None`."""
    umap, _total = unit_map(conn, book_id)
    try:
        idx = umap.index(unit_id)
    except ValueError:
        return None
    j = idx + (1 if delta > 0 else -1)
    return umap[j] if 0 <= j < len(umap) else None


def status(conn):
    ensure(conn)
    n = conn.execute("SELECT COUNT(*) FROM user_book_read").fetchone()[0]
    print('읽음 기록 %d건' % n)
    for bid, cnt, tot in conn.execute("""
        SELECT r.book_id, COUNT(*),
               (SELECT COUNT(*) FROM sys_book_unit b
                 WHERE b.book_id = r.book_id AND COALESCE(b.record_status,'LIVE')='LIVE')
        FROM user_book_read r WHERE r.book_id IS NOT NULL
        GROUP BY r.book_id"""):
        t = conn.execute("SELECT title FROM sys_book_asset WHERE book_id=?",
                         (bid,)).fetchone()
        print('  %-40s %d / %d' % ((t[0] if t else bid)[:40], cnt, tot))


# ═════════════════════════════════════════════════════════════════════════
#  자가 검증
# ═════════════════════════════════════════════════════════════════════════
# ⚠⚠⚠ **2026-08-24 — 이 selftest 가 사용자의 진짜 읽음 기록을 지웠다.**
#   옛 판은 `conn.execute('BEGIN')` … `finally: conn.rollback()` 로 되돌린다고
#   믿었는데 **두 겹으로 틀렸다**:
#     ① `mark`/`unmark`/`set_pos` 가 **안에서 `commit()`** 을 한다
#     ② `ensure()` 의 `CREATE TABLE` 이 **암묵 커밋**을 낸다
#   그래서 BEGIN 이 곧바로 풀리고 rollback 은 아무 일도 안 했다. 게다가 시험이
#   고른 유닛(스펄전 설교 No.1)에 **실제 읽음 기록이 있어** `unmark` 가 그것을
#   지웠다(3행 → 2행. `read_at` 은 되찾을 수 없었다).
#   §69차 `db_book_trans --selftest` 가 진짜 번역을 지운 것과 **같은 계열**이다.
#
#   ⇒ 세 가지로 막는다:
#     ㉠ **스냅샷하고 그대로 되살린다**(rollback 에 기대지 않는다)
#     ㉡ **읽음 기록이 없는 유닛만 고른다**(사용자 행을 애초에 안 건드린다)
#     ㉢ 검사를 「몇 건인가」가 아니라 **「원래대로인가」**(내용까지)로


def _snapshot(conn):
    ensure(conn)
    ensure_pos(conn)
    return (conn.execute("SELECT kind, unit_id, read_at, book_id "
                         "  FROM user_book_read ORDER BY kind, unit_id").fetchall(),
            conn.execute("SELECT kind, book_id, unit_id, updated_at "
                         "  FROM user_book_pos ORDER BY kind, book_id").fetchall())


def _restore(conn, snap):
    reads, poss = snap
    conn.execute("DELETE FROM user_book_read")
    conn.executemany("INSERT INTO user_book_read (kind, unit_id, read_at, book_id) "
                     "VALUES (?,?,?,?)", reads)
    conn.execute("DELETE FROM user_book_pos")
    conn.executemany("INSERT INTO user_book_pos "
                     "(kind, book_id, unit_id, updated_at) "
                     "VALUES (?,?,?,?)", poss)
    conn.commit()


def selftest():
    conn = appdb.connect()
    snap = _snapshot(conn)
    ok = True

    def bad(msg, *a):
        nonlocal ok
        ok = False
        print('FAIL', msg, *a)

    try:
        # ── 읽음 (편 단위) ─────────────────────────────────────────────
        # ★ **아직 안 읽은** 설교 유닛으로 시험한다 — 사용자 행을 안 건드린다.
        row = conn.execute("""
            SELECT bu.book_id, bu.unit_id, bu.sequence FROM sys_book_unit bu
            JOIN sys_book_asset ba ON ba.book_id = bu.book_id
            WHERE ba.book_category='SERMON'
              AND COALESCE(bu.record_status,'LIVE')='LIVE'
              AND bu.unit_id NOT IN
                  (SELECT unit_id FROM user_book_read WHERE kind='BOOK')
            ORDER BY bu.book_id, bu.sequence LIMIT 1""").fetchone()
        if not row:
            bad('시험할(안 읽은) 설교 유닛이 없다')
        else:
            bid, uid, seq = row
            n0 = len(read_ids(conn, bid))

            # next_unit 은 **안 읽은 것**을 준다 — 「첫 유닛」이라 못 박지 않는다
            # (그렇게 재면 사용자가 그 편을 읽는 순간 selftest 가 깨진다, §0-5).
            nxt0 = next_unit(conn, bid)
            if not nxt0:
                bad('next_unit 이 아무것도 안 준다')
            elif nxt0[0] in read_ids(conn, bid):
                bad('next_unit 이 이미 읽은 것을 준다:', nxt0)

            mark(conn, uid, bid, when='2026-01-01')
            if uid not in read_ids(conn, bid):
                bad('표시가 안 된다')
            if len(read_ids(conn, bid)) != n0 + 1:
                bad('표시했는데 개수가 안 는다')
            if (next_unit(conn, bid) or (None,))[0] == uid:
                bad('읽은 것이 아직 다음으로 나온다')

            mark(conn, uid, bid, when='2026-02-02')      # 멱등
            if len(read_ids(conn, bid)) != n0 + 1:
                bad('다시 읽으면 행이 는다')

            # ★ 갈래가 서로를 물들이지 않는가 — 이 도구의 존재 이유다
            mark(conn, uid, None, when='2026-01-01', kind='REF')
            if uid not in read_ids(conn, kind='REF'):
                bad('REF 갈래 표시가 안 된다')
            unmark(conn, uid, kind='REF')
            if uid in read_ids(conn, kind='REF'):
                bad('REF 해제가 안 된다')
            if uid not in read_ids(conn, bid):
                bad('REF 를 지웠더니 BOOK 까지 사라졌다')

            unmark(conn, uid)
            if uid in read_ids(conn, bid):
                bad('해제가 안 된다')
            if len(read_ids(conn, bid)) != n0:
                bad('해제 뒤 개수가 안 돌아온다')

        # ── 읽는 자리 (편 단위) ────────────────────────────────────────
        # ★★ 파트 폐기(2026-08-24) — 단위는 **저자가 나눈 편**뿐이다.
        # ★ 편이 셋 이상인 책이라야 앞·중간·끝을 다 잰다.
        prow = conn.execute("""
            SELECT book_id FROM sys_book_unit
             WHERE COALESCE(record_status,'LIVE')='LIVE'
             GROUP BY book_id HAVING COUNT(*) >= 3
             ORDER BY COUNT(*) DESC LIMIT 1""").fetchone()
        if not prow:
            print('  (건너뜀) 편이 셋 이상인 책이 없다')
        else:
            pbid = prow[0]
            umap, total = unit_map(conn, pbid)
            if total != len(umap):
                bad('편 수가 목록 길이와 다르다', total, len(umap))
            if len(set(umap)) != len(umap):
                bad('편이 중복된다')

            u0 = umap[0]
            if locate(conn, pbid, u0) != (1, total):
                bad('첫 편은 1번', locate(conn, pbid, u0))
            if locate(conn, pbid, umap[1])[0] != 2:
                bad('둘째 편은 2번')
            if locate(conn, pbid, umap[-1])[0] != total:
                bad('마지막 편은 전체 번호')
            if locate(conn, pbid, -1)[0] != 0:
                bad('없는 편은 0 이어야 한다')

            # step — 앞·뒤·양 끝
            if step(conn, pbid, u0, +1) != umap[1]:
                bad('다음 편')
            if step(conn, pbid, umap[1], -1) != u0:
                bad('이전 편')
            if step(conn, pbid, u0, -1) is not None:
                bad('책 맨 앞에서 이전은 없다')
            if step(conn, pbid, umap[-1], +1) is not None:
                bad('책 맨 끝에서 다음은 없다')
            if step(conn, pbid, -1, +1) is not None:
                bad('없는 편에서는 None')
            # 한 칸씩 끝까지 — **편 수와 딱 맞는가**
            cur, walked = u0, 1
            while True:
                nx = step(conn, pbid, cur, +1)
                if nx is None:
                    break
                cur, walked = nx, walked + 1
                if walked > total + 5:
                    break
            if walked != total:
                bad('한 칸씩 걸으면 편 수와 같아야 한다', walked, total)

            # 자리 담기 — 책마다 한 줄
            had = get_pos(conn, pbid)
            set_pos(conn, pbid, u0)
            if get_pos(conn, pbid) != u0:
                bad('자리를 못 담았다')
            set_pos(conn, pbid, umap[1])
            if conn.execute("SELECT COUNT(*) FROM user_book_pos WHERE book_id=?",
                            (pbid,)).fetchone()[0] != 1:
                bad('자리 행이 는다')
            if get_pos(conn, pbid) != umap[1]:
                bad('자리가 안 덮인다')
            clear_pos(conn, pbid)
            if get_pos(conn, pbid) is not None:
                bad('자리가 안 지워진다')
            if had is not None:
                set_pos(conn, pbid, had)

            # 진도 — **편 단위**. 한 편을 읽으면 딱 1 늘어야 한다
            r0, t0 = read_progress(conn, pbid)
            if t0 != total:
                bad('진도 분모가 편 수가 아니다', t0, total)
            tgt = next((u for u in umap if u not in read_ids(conn, pbid)), None)
            if tgt is None:
                print('  (건너뜀) 안 읽은 편이 없다')
            else:
                mark(conn, tgt, pbid, when='2026-01-01')
                r1, _ = read_progress(conn, pbid)
                if r1 - r0 != 1:
                    bad('한 편을 읽으면 1 늘어야 한다', r1 - r0)
                unmark(conn, tgt)

            # ⚠⚠ **파트가 되살아나지 않는가 — 동작으로 잰다.**
            #   소스에 낱말이 있는지로 재면 **역사를 적은 주석까지 걸린다**
            #   (실제로 그렇게 짰다가 제 주석에 걸렸다). 재야 할 것은 글자가
            #   아니라 **편 수보다 큰 수를 세지 않는가**이다.
            nu = conn.execute(
                "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? "
                "  AND COALESCE(record_status,'LIVE')='LIVE'", (pbid,)
            ).fetchone()[0]
            if total != nu:
                bad('편 수가 아닌 것을 센다(파트 부활?)', total, nu)
            if read_progress(conn, pbid)[1] != nu:
                bad('진도 분모가 편 수가 아니다')
    finally:
        # ★ **rollback 이 아니라 스냅샷 복원**(위 ⚠⚠⚠ 참조)
        _restore(conn, snap)

    # ★ 검사는 「몇 건인가」가 아니라 **「원래대로인가」** — 내용까지 본다
    now = _snapshot(conn)
    if now[0] != snap[0]:
        bad('읽음 기록이 원래대로가 아니다', len(snap[0]), '→', len(now[0]))
    if now[1] != snap[1]:
        bad('읽는 자리가 원래대로가 아니다', len(snap[1]), '→', len(now[1]))

    # ★ **되살리기 자체를 시험한다** — 안 그러면 위 두 검사가 늘 통과한다
    #   (§69차 교훈: 되돌리기가 진짜 데이터를 지운 것을 아무도 못 봤다).
    probe = conn.execute(
        "SELECT unit_id FROM sys_book_unit WHERE unit_id NOT IN "
        "  (SELECT unit_id FROM user_book_read WHERE kind='BOOK') LIMIT 1").fetchone()
    if probe:
        mark(conn, probe[0], None, when='1999-09-09')
        if _snapshot(conn)[0] == snap[0]:
            bad('탐지력 없음 — 행을 더했는데 「원래대로」라고 한다')
        _restore(conn, snap)
        if _snapshot(conn)[0] != snap[0]:
            bad('되살리기가 안 된다')

    # ── 「읽는 중」(시작·중단) — 없는 책 번호로만 시험한다(사용자 줄을 안 건드린다) ──
    TB = -99161
    try:
        start_reading(conn, TB, when='2000-01-01 00:00:00')
        start_reading(conn, TB, when='2001-01-01 00:00:00')
        if not is_reading(conn, TB):
            bad('읽기 시작이 안 담긴다')
        if [r for r in reading_list(conn) if r[1] == TB] != [('BOOK', TB, '2000-01-01 00:00:00')]:
            bad('두 번 시작하면 시작한 때가 바뀌거나 줄이 는다')
        stop_reading(conn, TB)
        if is_reading(conn, TB):
            bad('읽기 중단이 안 된다')
    finally:
        conn.execute('DELETE FROM user_book_reading WHERE book_id=?', (TB,))
        conn.commit()

    conn.close()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else '--status'
    if arg == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if arg == '--init':
        ensure(conn); conn.commit(); print('%s 준비 완료' % TABLE)
    status(conn)
    conn.close()
