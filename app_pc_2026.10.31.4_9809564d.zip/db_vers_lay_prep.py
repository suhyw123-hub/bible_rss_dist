# -*- coding: utf-8 -*-
"""db_vers_lay_prep.py — LAY 티어 재작성 재료 뽑기 (영구 도구)

`db_vers_gate` 의 `유사도` 위반을 고치기 위한 재료를 모은다.
LAY 가 EXPERT 의 경어체 축약이 되어 버린 절을 골라, 그 절의
**KRV 본문 · EXPERT · 현재 LAY · 유사도** 를 한자리에 놓는다.

왜 필요한가 — 실측(2026-08-05):
  창세기 KO EXPERT/LAY 유사도 평균 0.49 · 62%가 상한(0.45) 초과.
  다니엘은 0.59 · 84%. 반면 신약은 0.24~0.31 · 0~13%.
  마가·사도행전도 서사인데 0.26~0.27 이므로 **서사라서가 아니라
  표준 확립 전에 쓰였기 때문**이다.

고치는 방향 (lay.md §1):
  LAY 는 EXPERT 를 경어체로 옮긴 요약이 아니라 **독립적으로 쓴 다른 글**이다.
  ① 다른 도입으로 시작한다(EXPERT 의 첫 문장을 따라가지 않는다)
  ② 원어·상호참조·논증장치를 쓰지 않는다
  ③ EXPERT 의 45~60% 길이
  ④ 문단 구조를 따라가지 않는다

사용:
  python -X utf8 db_vers_lay_prep.py --selftest
  python -X utf8 db_vers_lay_prep.py --book 1 --ch 12
  python -X utf8 db_vers_lay_prep.py --book 1 --todo
"""
import argparse
import difflib
import os
import re
import sys

import appdb
from db_vers_gate import TH, new_word_ratio, new_word_ratio_en

APP = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(APP, '_vers_prep')

# 언어별 설정 (2026-08-06 EN 추가)
#   ⚠ 한글 낱말 기준(앞 2글자)으로 영어를 재면 안 된다 — 정규식이 한 글자도 못 잡아
#     신출 어휘비가 늘 0.0 이 되고, 전권이 「미달」로 찍힌다.
#   본문 역본은 그 언어에서 이 앱이 기준으로 쓰는 것을 따른다(KO=개역한글 · EN=BSB).
LANGS = {
    'KO': {'ratio': new_word_ratio, 'version': 'KRV'},
    'EN': {'ratio': new_word_ratio_en, 'version': 'BSB'},
}


# EN LAY 에 남은 절 인용. KO 는 게이트의 `LAY_CITE` 가 잡지만 그 정규식은
# 한글 책약명 기준이라 `Rom 8:1` 을 한 건도 못 잡는다(2026-08-06).
# `temp_db_lay_cite_strip` 의 EN 패턴과 같은 얼개 — 괄호형과 본문 삽입형 둘 다 본다.
CITE_EN = re.compile(r'\([^)]{0,80}?\d{1,3}:\d{1,3}[^)]{0,80}?\)'
                     r'|(?<![(\d])\b(?:\d\s)?[A-Z][A-Za-z]{2,11}\.?\s\d{1,3}:\d{1,3}')

# 초안 경로 → 짝 재료 경로 (`draft_lay_en_53_3.json` → `lay_en_53_3.md`)
MAT_RX = re.compile(r'(^|[\\/])draft_(lay[^\\/]*)\.json$')
VID_RX = re.compile(r'^\*\*vid\*\* (\d+)', re.M)


def ratio_fn(lang):
    return LANGS.get(lang, LANGS['KO'])['ratio']


def flagged(conn, bcode, ch, lang='KO'):
    """그 장에서 신출 어휘비가 하한에 못 미친 절 (verse, sim, 본문, expert, lay)."""
    q = """SELECT bi.verse_id, bi.verse, t.text_variant, t.contents
           FROM sys_text_asset t JOIN bible_index bi ON bi.verse_id = t.clicked_id
           WHERE t.text_type='VERS_DESC' AND bi.bcode=? AND bi.chapter=?
             AND t.lang_code=? AND COALESCE(t.record_status,'LIVE')='LIVE'
           ORDER BY bi.verse"""
    d = {}
    for vid, vs, var, txt in conn.execute(q, (bcode, ch, lang)):
        d.setdefault((vid, vs), {})[var] = txt or ''
    out = []
    for (vid, vs), r in sorted(d.items(), key=lambda x: x[0][1]):
        e, l = r.get('EXPERT'), r.get('LAY')
        if not e or not l:
            continue
        # 2026-08-05 — 선별 기준을 게이트와 같은 신출 어휘비로 교체.
        # 유사도는 autojunk·언어 편향으로 판정에서 내려갔다(db_vers_gate TH 주석).
        # 값은 재료 헤더에 그대로 실어 참고만 한다.
        s = ratio_fn(lang)(e, l)
        if s >= TH['NEWWORD_MIN']:
            continue
        ver = LANGS.get(lang, LANGS['KO'])['version']
        base = conn.execute(
            "SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?",
            (vid, ver)).fetchone()
        row = {'vid': vid, 'verse': vs, 'sim': s,
               'krv': base[0] if base else '', 'expert': e, 'lay': l}
        if lang != 'KO':
            # ★ 그 언어를 EXPERT 에서 다시 줄이면 같은 실패를 되풀이한다.
            #   KO LAY 는 이미 독립된 상으로 다시 쓴 글이므로, 그 상을 옮길 원본으로 싣는다.
            ko = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_DESC'"
                " AND lang_code='KO' AND text_variant='LAY'"
                " AND COALESCE(record_status,'LIVE')='LIVE'", (vid,)).fetchone()
            row['ko_lay'] = ko[0] if ko else ''
        out.append(row)
    return out


def build(conn, bcode, ch, lang='KO'):
    rows = flagged(conn, bcode, ch, lang)
    os.makedirs(OUT_DIR, exist_ok=True)
    bn = conn.execute("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'",
                      (bcode,)).fetchone()
    name = bn[0] if bn else str(bcode)
    ver = LANGS.get(lang, LANGS['KO'])['version']
    suffix = '' if lang == 'KO' else '_' + lang.lower()
    lines = ['# %s %d장 — %s LAY 재작성 재료 (%d절)' % (name, ch, lang, len(rows)), '']
    if lang == 'KO':
        lines.append('> LAY 는 EXPERT 의 경어체 축약이 아니라 **다른 도입으로 독립해서 쓴 글**이다.')
        lines.append('> 원어·상호참조 없음 · EXPERT 의 45~60% 길이 · 합니다체.')
    else:
        lines.append('> **`KO LAY` 를 옮긴다. `EXPERT` 를 줄이지 않는다.**')
        lines.append('> KO LAY 가 세운 상(비유·진입점·문단 흐름)을 영어로 다시 세운다.')
        lines.append('> 원어 음역·절 인용 없음 · EXPERT 의 45~60% 길이 · 평이한 현대 영어.')
    lines.append('')
    for r in rows:
        lines.append('## %d:%d  (신출어휘 %.2f · EXPERT %d자 / LAY %d자)'
                     % (ch, r['verse'], r['sim'], len(r['expert']), len(r['lay'])))
        lines.append('**vid** %d' % r['vid'])
        lines.append('')
        lines.append('**%s** %s' % (ver, r['krv']))
        lines.append('')
        if r.get('ko_lay'):
            lines.append('**KO LAY (이 상을 옮긴다)**')
            lines.append(r['ko_lay'])
            lines.append('')
        lines.append('**EXPERT**')
        lines.append(r['expert'])
        lines.append('')
        lines.append('**현재 LAY (다시 쓸 것)**')
        lines.append(r['lay'])
        lines.append('')
    path = os.path.join(OUT_DIR, 'lay%s_%d_%d.md' % (suffix, bcode, ch))
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    skel = os.path.join(OUT_DIR, 'draft_lay%s_%d_%d.json' % (suffix, bcode, ch))
    if not os.path.exists(skel):
        import json
        with open(skel, 'w', encoding='utf-8') as f:
            json.dump([{'clicked_id': r['vid'], 'text_type': 'VERS_DESC',
                        'lang_code': lang, 'text_variant': 'LAY', 'contents': ''}
                       for r in rows], f, ensure_ascii=False, indent=2)
    print('%s %d장 — %s 재작성 대상 %d절' % (name, ch, lang, len(rows)))
    print('  재료: %s' % path)
    print('  초안: %s' % skel)
    if rows:
        print('  신출어휘 %.2f~%.2f' % (min(r['sim'] for r in rows),
                                   max(r['sim'] for r in rows)))
    print()
    print('다음: 초안을 채운 뒤')
    print('  python -X utf8 db_verse_text_loader.py %s' % skel)
    print('  python -X utf8 db_vers_gate.py %d %d %d' % (bcode, ch, ch))


def check_draft(conn, path):
    """초안을 적재 전에 검증한다. 게이트를 장 단위로 돌리기 전에 여기서 걸러 낸다.

    ⚠ 창세기 실측 보정 — 신약 감각으로 쓰면 길이비가 넘는다.
      창세기 EXPERT 는 130~260자라 LAY 는 **80~150자 두세 문장**이다.
      그리고 4문장짜리를 2+2 로 나누면 문단당 2.0 이라 밀도 하한(2.5)에 걸린다 —
      5문장 미만은 나누지 않는다.
    """
    import json
    from db_vers_gate import PARA_MIN_SENT, TH, sentences
    rows = json.load(open(path, encoding='utf-8'))
    bad, rs, ss = [], [], []

    # ★ 초안이 그 장의 대상 절에 붙었는지 (2026-08-06 실사고 — 살후 3장 10절 전부 오배치)
    #   재료의 vid 를 읽지 않고 짐작해 적었는데, 그 vid 들도 EXPERT 가 있어서
    #   길이비·어휘비가 멀쩡히 계산돼 게이트를 그대로 통과했다.
    #   ⇒ 비율로 추정하지 않는다. **짝 재료 파일이 정답을 갖고 있으니 그것과 맞춘다.**
    mat = re.sub(r'(^|[\\/])draft_(lay[^\\/]*)\.json$', r'\1\2.md', path)
    if mat != path and os.path.exists(mat):
        want = set(int(m) for m in re.findall(r'^\*\*vid\*\* (\d+)', open(mat, encoding='utf-8').read(), re.M))
        got_ids = set(r['clicked_id'] for r in rows)
        stray = sorted(got_ids - want)
        if stray:
            bad.append('재료에 없는 vid %s — 엉뚱한 절에 붙었다 (%s 대조)'
                       % (', '.join(str(s) for s in stray[:5]), os.path.basename(mat)))

    for r in rows:
        v, new = r['clicked_id'], r.get('contents') or ''
        lang = r.get('lang_code', 'KO')
        if not new.strip():
            bad.append('vid %d 비었다' % v)
            continue
        got = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_DESC'"
            " AND lang_code=? AND text_variant='EXPERT'"
            " AND COALESCE(record_status,'LIVE')='LIVE'",
            (v, lang)).fetchone()
        if not got:
            bad.append('vid %d EXPERT 가 없다' % v)
            continue
        e = got[0]
        ratio, sim = len(new) / len(e), ratio_fn(lang)(e, new)
        cites = CITE_EN.findall(new) if lang == 'EN' else []
        if cites:
            bad.append('vid %d 절 인용 %s' % (v, ' · '.join(sorted(set(cites))[:3])))
        rs.append(ratio)
        ss.append(sim)
        ns = len(sentences(new))
        if ratio > TH['LEN_RATIO_MAX']:
            bad.append('vid %d 길이비 %.2f (상한 %.2f)' % (v, ratio, TH['LEN_RATIO_MAX']))
        if sim < TH['NEWWORD_MIN']:
            bad.append('vid %d 신출어휘 %.2f (하한 %.2f)' % (v, sim, TH['NEWWORD_MIN']))
        if ns >= PARA_MIN_SENT and '\n\n' not in new:
            bad.append('vid %d 문단없음 (%d문장)' % (v, ns))
        if '\n\n' in new:
            ps = [p for p in new.split('\n\n') if p.strip()]
            dens = sum(len(sentences(p)) for p in ps) / len(ps)
            if dens < TH['SENT_PER_PARA_MIN']:
                bad.append('vid %d 문단밀도 %.2f — %d문장짜리는 나누지 말 것' % (v, dens, ns))
    if rs:
        print('%d행 · 길이비 평균 %.2f 최대 %.2f · 신출어휘 평균 %.2f 최소 %.2f'
              % (len(rows), sum(rs) / len(rs), max(rs), sum(ss) / len(ss), max(ss)))
    if bad:
        print('위반 %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('위반 없음 — 적재해도 된다')
    return 0


def todo(conn, bcode, lang='KO'):
    mx = conn.execute("SELECT MAX(chapter) FROM bible_index WHERE bcode=?",
                      (bcode,)).fetchone()[0]
    tot = 0
    parts = []
    for ch in range(1, mx + 1):
        n = len(flagged(conn, bcode, ch, lang))
        tot += n
        if n:
            parts.append('%d장:%d' % (ch, n))
    print('bcode %d — %s 재작성 대상 %d절 / %d장' % (bcode, lang, tot, mx))
    print('  ' + ' · '.join(parts))


def selftest():
    print('db_vers_lay_prep 자가 검증')
    bad = []
    conn = appdb.connect()

    # ① 탐지력 — **인위 사례로 본다.**
    #    ⚠ 고정 장을 양성 사례로 쓰면 그 장을 고치는 순간 자가 검증이 깨진다.
    #      실제로 두 번 겪었다(단 1장 → 단 2장 → 이번엔 단 2장 KO 완료로 0절).
    #      기준 자체를 재는 데는 DB 가 필요 없다.
    E = ('바울은 통렬한 반어로 고린도인의 영적 자만을 되비춘다. 세 번 반복되는 이미가 '
         '그들의 착각을 폭로한다. 하나님 나라의 완성은 미래에 있건만 그들은 현재에 '
         '그 부요와 통치를 앞당겨 소유했다고 착각했다.')
    COPY = ('바울은 통렬한 반어로 고린도인의 영적 자만을 되비춥니다. 세 번 반복되는 '
            '이미가 그들의 착각을 폭로합니다. 하나님 나라의 완성은 미래에 있습니다.')
    NEW = ('경기가 끝나기도 전에 시상대에 올라선 선수를 떠올려 보십시오. 배부르다, '
           '부요하다, 벌써 왕이 되었다 — 칭찬이 아니라 뼈아픈 놀림입니다. 잔치는 아직 '
           '차려지는 중인데 다 받은 듯 굴었습니다.')
    if new_word_ratio(E, COPY) >= TH['NEWWORD_MIN']:
        bad.append('베낀 글(%.2f)이 하한을 넘었다 — 기준이 헐겁다' % new_word_ratio(E, COPY))
    if new_word_ratio(E, NEW) < TH['NEWWORD_MIN']:
        bad.append('다시 쓴 글(%.2f)이 하한에 걸렸다 — 기준이 빡빡하다' % new_word_ratio(E, NEW))

    E_EN = ('Paul turns to biting irony to expose the spiritual arrogance of the '
            'Corinthians. The threefold already unmasks their delusion.')
    COPY_EN = ('Paul uses biting irony to expose the spiritual arrogance of the '
               'Corinthians. The threefold already unmasks their delusion.')
    # ⚠ 이 표본은 **실제 재작성문 길이**여야 한다. 두세 문장짜리로 줄이면
    #   흔한 기능어조차 겹치지 않아 신출 어휘비가 0.8 을 넘고, 오배치 천장 검사가
    #   제대로 쓴 글을 오탐으로 잡는다(2026-08-06 selftest 가 실제로 그렇게 실패했다).
    NEW_EN = ('Picture an athlete climbing onto the podium before the race is even over. '
              'That is roughly how the Corinthians were carrying themselves, and Paul '
              'answers with irony rather than praise. Fed already, rich already, reigning '
              'already, he says, and every one of those words lands as a sting. The '
              'kingdom is still being set out, and they were behaving as though the meal '
              'had been served and cleared. Meanwhile the men who brought them the message '
              'were hungry and beaten in some other city.')
    if new_word_ratio_en(E_EN, COPY_EN) >= TH['NEWWORD_MIN']:
        bad.append('EN 베낀 글이 하한을 넘었다')
    if new_word_ratio_en(E_EN, NEW_EN) < TH['NEWWORD_MIN']:
        bad.append('EN 다시 쓴 글이 하한에 걸렸다')

    # ② 하한 이상인 절을 고르지는 않는가 (아직 남은 장에서 확인 — 없으면 건너뛴다)
    rows = flagged(conn, 27, 2, 'EN') or flagged(conn, 1, 1, 'EN')
    if any(r['sim'] >= TH['NEWWORD_MIN'] for r in rows):
        bad.append('하한 이상인 절을 골랐다')

    # ③ 재료가 다 붙는가
    for r in rows[:3]:
        if not r['expert'] or not r['lay']:
            bad.append('EXPERT/LAY 가 비었다')
        if not r['krv']:
            bad.append('본문을 못 붙였다 (2:%d)' % r['verse'])

    # ④ 잘 쓴 책은 빠지는가 — 요한복음은 KO·EN 둘 다 신출 어휘비가 가장 높다
    if len(flagged(conn, 43, 1)) > 2:
        bad.append('요 1장에서 %d절이 걸렸다 — 기준이 헐겁다' % len(flagged(conn, 43, 1)))

    # ── EN (2026-08-06 추가) ────────────────────────────────────────────────
    # ⑤ **언어를 안 갈아 끼우면 전권이 거짓 미달로 찍힌다.** 한글 낱말 정규식은
    #    영어에서 한 글자도 못 잡아 신출 어휘비가 늘 0.0 이 된다. 그 사고를 고정한다.
    en_pair = conn.execute(
        "SELECT e.contents, l.contents FROM sys_text_asset e JOIN sys_text_asset l"
        " ON e.clicked_id=l.clicked_id AND e.text_type=l.text_type AND e.lang_code=l.lang_code"
        " WHERE e.text_type='VERS_DESC' AND e.lang_code='EN' AND e.text_variant='EXPERT'"
        " AND l.text_variant='LAY' AND COALESCE(e.record_status,'LIVE')='LIVE'"
        " AND COALESCE(l.record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
    if not en_pair:
        bad.append('EN EXPERT/LAY 쌍을 하나도 못 찾았다')
    else:
        if new_word_ratio(*en_pair) != 0.0:
            bad.append('한글 함수가 영어에서 0 이 아닌 값을 냈다 — 전제가 바뀌었다')
        if ratio_fn('EN') is not new_word_ratio_en:
            bad.append('lang=EN 인데 한글 함수가 걸린다')

    # ⑥ EN 도 미작업 책은 잡히고 잘 쓴 책은 빠지는가 (KO 와 같은 두 방향)
    en_dan = flagged(conn, 27, 2, 'EN')
    if len(en_dan) < 10:
        bad.append('EN 단 2장에서 %d절만 골랐다' % len(en_dan))
    en_jn = flagged(conn, 43, 1, 'EN')
    if len(en_jn) > 3:
        bad.append('EN 요 1장에서 %d절이 걸렸다 — 기준이 헐겁다' % len(en_jn))
    if en_dan and 'ko_lay' not in en_dan[0]:
        bad.append('EN 재료에 KO LAY 를 안 붙였다 — 옮길 원본이 없다')

    # ⑦ 오배치 탐지 — 재료에 없는 vid 를 적으면 잡히는가 (2026-08-06 실사고)
    #    임시 폴더에 재료·초안 한 쌍을 만들어 경로 변환과 vid 추출을 그대로 검증한다.
    #    ⚠ 비율로 추정하지 않는다 — 실측 9,848쌍에서 0.80 초과가 119건이라
    #      천장을 두면 잘 쓴 글을 오배치로 몬다(그 시도는 폐기했다).
    import json as _json
    import tempfile
    _d = tempfile.mkdtemp()
    _md = os.path.join(_d, 'lay_en_99_1.md')
    with open(_md, 'w', encoding='utf-8') as f:
        f.write(chr(10).join(['## 1:1', '**vid** 111', '', '## 1:2', '**vid** 222']))
    _dr = os.path.join(_d, 'draft_lay_en_99_1.json')
    with open(_dr, 'w', encoding='utf-8') as f:
        _json.dump([{'clicked_id': 333, 'lang_code': 'EN', 'contents': 'x'}], f)
    _mat = MAT_RX.sub(chr(92)+'1'+chr(92)+'2.md', _dr)
    if not os.path.exists(_mat):
        bad.append('짝 재료 경로를 못 찾는다 — 오배치 검사가 통째 죽는다')
    else:
        _want = set(int(m) for m in re.findall(
            r'^\*\*vid\*\* (\d+)', open(_mat, encoding='utf-8').read(), re.M))
        if _want != {111, 222}:
            bad.append('재료에서 vid 를 못 읽는다 (%s)' % sorted(_want))
        if 333 in _want:
            bad.append('엉뚜한 vid 가 재료에 있다고 나온다')

    # ⑧ EN 절 인용 검사의 탐지력 (인위 사례 — 실제 데이터에 기대지 않는다)
    for s in ('He quotes the psalm (Ps 110:1) here.', 'as Rom 8:1 says', 'see 1 Cor 3:16'):
        if not CITE_EN.search(s):
            bad.append('EN 인용을 놓쳤다: %s' % s)
    for s in ('The ratio was 3:1 in his favor.', 'They met at 9:30 that morning.'):
        if CITE_EN.search(s):
            bad.append('EN 인용 오탐: %s' % s)

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print("SELFTEST PASS — 8개 항목")
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--book', type=int)
    ap.add_argument('--ch', type=int)
    ap.add_argument('--todo', action='store_true')
    ap.add_argument('--lang', default='KO', choices=sorted(LANGS), help='기본 KO')
    ap.add_argument('--check', help='초안 JSON 을 적재 전에 검증')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    conn = appdb.connect()
    if a.check:
        sys.exit(check_draft(conn, a.check))
    if not a.book:
        ap.error('--book 이 필요하다')
    if a.todo:
        todo(conn, a.book, a.lang)
        return
    if not a.ch:
        ap.error('--ch 가 필요하다')
    build(conn, a.book, a.ch, a.lang)


if __name__ == '__main__':
    main()
