# -*- coding: utf-8 -*-
"""시대구분 코드표 (영구 도구 · 2026-09-01 사용자 확정).

★★★ 확정 설계 — 「왕정·공생애·정복·귀환 등은 **용어가 아니라 시대분류값**이다.
  필요한 곳에서 구분값/카테고리 만들어서 사용하면 된다」. 값 목록을 작은
  코드표 하나로 통제한다 — 표기가 갈리는 것을 막는 것이 이 표의 전부다.

표 둘:
  · `sys_era_code`  — 시대 값 목록(코드 · 차례). 이름은 `ui_strings`(`ERA_*`).
  · `sys_era_span`  — 책·장 구간 → 시대. **기본 배정은 「그 책(또는 그 장)의
    무대·저자 활동 시대」**다. 시편의 비다윗 시·사40~66 같은 정밀화는 장
    구간 행을 더하는 것으로 한다(코드 수정 없음).

쓰는 곳(사용자 승인 2026-09-01):
  ① 시대별 묵상플랜(콘텐츠 — 뒤에) ② 인물 목록 시대 거르기
  ③ 용어의 연결구절 시대 분포. ④~⑥(지도·검색·연대표)은 검토대상 기록.

사용법
  python db_era_code.py --selftest
  python db_era_code.py --init      # 표·값·구간 적재(멱등)
  python db_era_code.py --status
"""
import sys

import appdb

#: 시대 값 — 차례가 곧 역사 순서다. 사용자 확정: 공생애 다음 **제자시대**.
#  INTERTEST(중간기)는 본문 구간이 없다 — 인물·사건용으로 값만 둔다.
ERAS = [
    ('PRIMEVAL',   10, '태초',      'Primeval'),
    ('PATRIARCH',  20, '족장',      'Patriarchs'),
    ('EXODUS',     30, '출애굽·광야', 'Exodus & Wilderness'),
    ('CONQUEST',   40, '정복',      'Conquest'),
    ('JUDGES',     50, '사사',      'Judges'),
    ('KINGDOM',    60, '통일 왕정',  'United Kingdom'),
    ('DIVIDED',    70, '분열 왕국',  'Divided Kingdom'),
    ('EXILE',      80, '포로',      'Exile'),
    ('RETURN',     90, '귀환',      'Return'),
    ('INTERTEST', 100, '중간기',    'Intertestamental'),
    ('GOSPEL',    110, '공생애',    'Life of Christ'),
    ('DISCIPLES', 120, '제자시대',  'Age of the Disciples'),
]

#: 책·장 → 시대. (bcode, 장부터, 장까지(None=끝), 시대).
#  ⚠ 한 책이 갈리는 곳만 장을 적는다 — 창(1~11/12~), 삼상(1~7/8~),
#    왕상(1~11/12~), 대하(1~9/10~).
SPANS = [
    (1, 1, 11, 'PRIMEVAL'), (1, 12, None, 'PATRIARCH'),
    (2, 1, None, 'EXODUS'), (3, 1, None, 'EXODUS'),
    (4, 1, None, 'EXODUS'), (5, 1, None, 'EXODUS'),
    (6, 1, None, 'CONQUEST'),
    (7, 1, None, 'JUDGES'), (8, 1, None, 'JUDGES'),
    (9, 1, 7, 'JUDGES'), (9, 8, None, 'KINGDOM'),
    (10, 1, None, 'KINGDOM'),
    (11, 1, 11, 'KINGDOM'), (11, 12, None, 'DIVIDED'),
    (12, 1, None, 'DIVIDED'),
    (13, 1, None, 'KINGDOM'),
    (14, 1, 9, 'KINGDOM'), (14, 10, None, 'DIVIDED'),
    (15, 1, None, 'RETURN'), (16, 1, None, 'RETURN'),
    (17, 1, None, 'EXILE'),
    (18, 1, None, 'PATRIARCH'),
    (19, 1, None, 'KINGDOM'), (20, 1, None, 'KINGDOM'),
    (21, 1, None, 'KINGDOM'), (22, 1, None, 'KINGDOM'),
    (23, 1, None, 'DIVIDED'), (24, 1, None, 'DIVIDED'),
    (25, 1, None, 'EXILE'), (26, 1, None, 'EXILE'), (27, 1, None, 'EXILE'),
    (28, 1, None, 'DIVIDED'), (29, 1, None, 'DIVIDED'),
    (30, 1, None, 'DIVIDED'), (31, 1, None, 'EXILE'),
    (32, 1, None, 'DIVIDED'), (33, 1, None, 'DIVIDED'),
    (34, 1, None, 'DIVIDED'), (35, 1, None, 'DIVIDED'),
    (36, 1, None, 'DIVIDED'),
    (37, 1, None, 'RETURN'), (38, 1, None, 'RETURN'), (39, 1, None, 'RETURN'),
    (40, 1, None, 'GOSPEL'), (41, 1, None, 'GOSPEL'),
    (42, 1, None, 'GOSPEL'), (43, 1, None, 'GOSPEL'),
] + [(b, 1, None, 'DISCIPLES') for b in range(44, 67)]

#: `sys_person.time_context` → 시대 코드. 값을 갈아 끼우지 않고 **읽을 때 잇는다**
#  (칸을 다시 쓰면 ENTITY_TIME_* 라벨 배선이 함께 밀린다).
PERSON_ERA = {
    'CREATION': 'PRIMEVAL', 'PRE_PATRIARCH': 'PRIMEVAL',
    'PATRIARCH': 'PATRIARCH', 'EXODUS': 'EXODUS', 'CONQUEST': 'CONQUEST',
    'JUDGES': 'JUDGES', 'KINGDOM': 'KINGDOM', 'DIVIDED': 'DIVIDED',
    'EXILE': 'EXILE', 'RETURN': 'RETURN', 'INTERTEST': 'INTERTEST',
    'GOSPEL': 'GOSPEL', 'EARLY_CHURCH': 'DISCIPLES',
}


def init(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS sys_era_code ("
                 " era_code TEXT PRIMARY KEY, sort_order INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS sys_era_span ("
                 " bcode INTEGER, ch_from INTEGER, ch_to INTEGER,"
                 " era_code TEXT)")
    conn.execute("DELETE FROM sys_era_code")
    conn.execute("DELETE FROM sys_era_span")
    for code, so, ko, en in ERAS:
        conn.execute("INSERT INTO sys_era_code VALUES(?,?)", (code, so))
        for lg, v in (('KO', ko), ('EN', en)):
            if conn.execute("SELECT 1 FROM ui_strings WHERE string_id=?"
                            " AND UPPER(lang_code)=?",
                            ('ERA_' + code, lg)).fetchone():
                conn.execute("UPDATE ui_strings SET string_value=? WHERE"
                             " string_id=? AND UPPER(lang_code)=?",
                             (v, 'ERA_' + code, lg))
            else:
                conn.execute("INSERT INTO ui_strings(string_id,lang_code,"
                             "string_value) VALUES(?,?,?)",
                             ('ERA_' + code, lg, v))
    for b, f, t, code in SPANS:
        conn.execute("INSERT INTO sys_era_span VALUES(?,?,?,?)",
                     (b, f, t, code))
    conn.commit()
    print('시대 %d개 · 구간 %d행' % (len(ERAS), len(SPANS)))


def eras(conn, lang='KO'):
    """시대 목록 → [(코드, 이름)] 역사 순서."""
    out = []
    for code, in conn.execute("SELECT era_code FROM sys_era_code"
                              " ORDER BY sort_order"):
        r = conn.execute("SELECT string_value FROM ui_strings WHERE"
                         " string_id=? AND UPPER(lang_code)=?",
                         ('ERA_' + code, (lang or 'KO').upper())).fetchone()
        if not r:
            r = conn.execute("SELECT string_value FROM ui_strings WHERE"
                             " string_id=? AND UPPER(lang_code)='EN'",
                             ('ERA_' + code,)).fetchone()
        out.append((code, r[0] if r else code))
    return out


def era_name(conn, code, lang='KO'):
    for c, n in eras(conn, lang):
        if c == code:
            return n
    return code or ''


def era_of_verse(conn, vid):
    """절 → 시대 코드. 못 찾으면 None."""
    r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                     (vid,)).fetchone()
    if not r:
        return None
    b, ch = r
    row = conn.execute(
        "SELECT era_code FROM sys_era_span WHERE bcode=? AND ch_from<=?"
        " AND (ch_to IS NULL OR ch_to>=?) LIMIT 1", (b, ch, ch)).fetchone()
    return row and row[0]


def person_era(time_context):
    return PERSON_ERA.get((time_context or '').upper())


def status(conn):
    from collections import Counter
    cnt = Counter()
    for b, ch in conn.execute("SELECT DISTINCT bcode, chapter"
                              " FROM bible_index"):
        r = conn.execute("SELECT era_code FROM sys_era_span WHERE bcode=?"
                         " AND ch_from<=? AND (ch_to IS NULL OR ch_to>=?)",
                         (b, ch, ch)).fetchone()
        cnt[r[0] if r else '(없음)'] += 1
    for k, n in cnt.most_common():
        print('  %-10s %4d장' % (k, n))


def _selftest():
    ok = [0, 0]

    def chk(name, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('PASS' if cond else 'FAIL', name, got))

    conn = appdb.connect('bible_master.db')
    init(conn)
    chk('시대 12개', len(eras(conn)) == 12, len(eras(conn)))
    chk('제자시대가 공생애 다음이다',
        [c for c, _n in eras(conn)][-2:] == ['GOSPEL', 'DISCIPLES'])
    # ★ 1,189장 전부 — 빠진 장도, 두 시대에 걸친 장도 없다
    miss = dup = 0
    for b, ch in conn.execute("SELECT DISTINCT bcode, chapter"
                              " FROM bible_index"):
        n = conn.execute("SELECT COUNT(*) FROM sys_era_span WHERE bcode=?"
                         " AND ch_from<=? AND (ch_to IS NULL OR ch_to>=?)",
                         (b, ch, ch)).fetchone()[0]
        miss += (n == 0)
        dup += (n > 1)
    chk('★ 전 장이 정확히 한 시대다 (빠짐 %d · 겹침 %d)' % (miss, dup),
        miss == 0 and dup == 0)
    # 표본 — 경계가 갈리는 자리
    def _era(b, ch):
        vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=?"
                           " AND chapter=? AND verse=1", (b, ch)).fetchone()[0]
        return era_of_verse(conn, vid)
    for b, ch, want in ((1, 11, 'PRIMEVAL'), (1, 12, 'PATRIARCH'),
                        (9, 7, 'JUDGES'), (9, 8, 'KINGDOM'),
                        (11, 11, 'KINGDOM'), (11, 12, 'DIVIDED'),
                        (14, 9, 'KINGDOM'), (14, 10, 'DIVIDED'),
                        (43, 1, 'GOSPEL'), (44, 1, 'DISCIPLES')):
        chk('  %d권 %d장 = %s' % (b, ch, want), _era(b, ch) == want,
            _era(b, ch))
    chk('인물 시대 매핑 — EARLY_CHURCH → 제자시대',
        person_era('EARLY_CHURCH') == 'DISCIPLES')
    chk('인물 시대 매핑 — CREATION → 태초',
        person_era('CREATION') == 'PRIMEVAL')
    chk('이름이 나온다', era_name(conn, 'KINGDOM', 'KO') == '통일 왕정')
    print('%s  %d/%d' % ('PASS' if ok[0] == ok[1] else 'FAIL', ok[0], ok[1]))
    if ok[0] != ok[1]:
        raise SystemExit(1)


def main():
    a = sys.argv[1:]
    conn = appdb.connect('bible_master.db')
    if '--selftest' in a:
        return _selftest()
    if '--init' in a:
        return init(conn)
    if '--status' in a:
        return status(conn)
    print(__doc__)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    main()
