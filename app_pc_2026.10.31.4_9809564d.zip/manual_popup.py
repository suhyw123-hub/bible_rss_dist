"""
manual_popup.py
---------------
매뉴얼 팝업 — 사용자 화면에서 매뉴얼 표시·수정·복구.

ManualPopup(parent, screen_code, icon_key, lang_provider, db_path):
  - 헤더: 번호(M203) + [수정] [저장] [복구]
  - 제목 (편집 모드에서 Entry, 평소 Label)
  - 본문 (편집 모드에서 Text 활성, 평소 disabled)
  - 편집 모드에서만 **기호 줄**이 나타난다

EN 폴백.

저장 → user_manual_asset_v2 UPSERT (사용자 lang 기준, title + contents)
복구 → user_manual_asset_v2 해당 행 DELETE

★★ **표준 서식 (2026-08-23)** — `font.md` §36. 이 파일이 색 20곳·글꼴 이름을
  전부 박아 두고 있었다. `ui_theme.adopt` 는 팔레트에 없는 색을 못 번역하므로
  검정 테마에서 그대로 굳었다.
  ⇒ 색은 전부 `_C(역할, 폴백)`, 글꼴 이름은 적지 않는다(본문만 `theme_font`).
     머리 띠는 **없애지 않고 역할색으로**(`dark_bg`+`fg_on_dark`) — 매뉴얼임을
     알리는 표식이라 본문과 구분돼야 한다는 판단은 그대로다.
⚠⚠ **편집 모드에서 바탕색을 바꾸지 않는다** (사용자 재지적 「수정 버튼을 누르면
  테마 설정과 다른 색으로 표시한다. 표준서식 준수하라. 철저하게 점검하라」).
  처음 `#FFFEF0`(거의 흰색) → `warning_bg`(어두운 갈색) → **결국 `panel` 그대로**.
  **편집 중임을 색으로 알리려던 것 자체가 표준서식 밖이었다.** 편집 중임은
  이미 넷이 알린다: 제목 칸 테두리 · 「수정 취소」 · 저장 활성 · **기호 줄 등장**.

⚠⚠ **✕ 를 우리가 또 그리지 않는다** (「x 표시가 2개」의 정체).
  이 창은 `Toplevel` 이라 **OS 제목줄이 이미 ✕ 를 준다.** 앱 관례를 실측하니
  진짜 팝업(`tag_picker`·`reading_setup`)은 전부 **OS 제목줄만** 쓰고, 자체 ✕ 를
  그리는 것은 `journey_story` 처럼 **`place()` 로 띄우는 겹침 카드**뿐이다.
  ⇒ 자체 ✕ 를 걷었다(창 방식을 바꾸는 것보다 관례에 맞다).

⚠ **✏ ✖ ↺ ✕ 는 맑은 고딕·굴림·바탕 어디에도 없다**(cmap 실측 2026-08-23).
  폴백 글꼴로 그려져 크기·기준선이 어긋난다(§54 `➔` 와 같은 계열).
  ⇒ 이 창의 단추에서 전부 걷고 **글자로만** 적는다. i18n 값(11개 언어)도 함께.
"""

import os
import i18n
import appdb
import tkinter as tk
from tkinter import messagebox

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')


def _C(role, fallback):
    """테마 역할색 — 팔레트에 없으면 폴백(§0 색 하드코딩 금지)."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


class ManualPopup(tk.Toplevel):
    def __init__(self, parent, screen_code, icon_key='MAIN',
                  lang_provider=None, db_path=None):
        super().__init__(parent)
        self.screen_code = screen_code
        self.icon_key = icon_key
        self.lang_provider = lang_provider or (lambda: 'KO')
        self.db_path = db_path or DB
        self._curr_lang = (self.lang_provider() or 'KO').upper()
        self._origin_id = None
        self._user_type = None
        self._is_user_edited = False
        self._edit_mode = False

        self.title(i18n.t('WIN_MANUAL', '매뉴얼'))
        self.geometry('600x520')
        self.minsize(420, 340)
        self.transient(parent)

        # 1. 헤더 (번호 + 동작 단추 — 한 줄, 가장 상단. §0 「버튼은 항상 상단」)
        head = tk.Frame(self, bg=_C('dark_bg', '#2C4259'), height=44)
        head.pack(fill='x', side='top')
        head.pack_propagate(False)
        # ★ **번호는 여기서 보인다** (2026-08-22 사용자 지시 — 화면 단추는
        #   `M` 한 글자, 번호는 누를 때). 「M203 고쳐줘」로 바로 찾는다.
        try:
            import db_manual
            with appdb.connect(self.db_path) as _c:
                code_disp = db_manual.label_of(_c, screen_code)
        except Exception:
            code_disp = str(screen_code)
        if icon_key != 'MAIN':
            code_disp += f'.{icon_key}'

        self._code_lbl = tk.Label(head, text=code_disp,
                                   bg=_C('dark_bg', '#2C4259'),
                                   fg=_C('fg_on_dark', '#FFFFFF'), padx=10)
        self._code_lbl.pack(side='left', fill='y')

        # ⚠ 자체 ✕ 없음 — OS 제목줄이 이미 준다(위 머리글 설명 참조).
        self._btn_edit = tk.Button(head, text=i18n.t('COMMON_EDIT', '수정'),
                                     font=('', 9, 'bold'),
                                     command=self._toggle_edit,
                                     bg=_C('panel', '#FFFFFF'),
                                     fg=_C('accent', '#1A5276'),
                                     padx=10, pady=2, cursor='hand2',
                                     relief='flat')
        self._btn_edit.pack(side='left', padx=8, pady=6)
        self._btn_save = tk.Button(head, text=i18n.t('COMMON_SAVE', '저장'),
                                     font=('', 9, 'bold'),
                                     bg=_C('success', '#27AE60'),
                                     fg=_C('fg_on_dark', '#FFFFFF'),
                                     command=self._save,
                                     state='disabled',
                                     padx=10, pady=2, cursor='hand2',
                                     relief='flat')
        self._btn_save.pack(side='left', padx=2, pady=6)
        self._btn_restore = tk.Button(head, text=i18n.t('MP_RESTORE', '복구'),
                                        font=('', 9),
                                        command=self._restore,
                                        state='disabled',
                                        bg=_C('panel', '#FFFFFF'),
                                        fg=_C('warning', '#7E5109'),
                                        padx=8, pady=2, cursor='hand2',
                                        relief='flat')
        self._btn_restore.pack(side='left', padx=4, pady=6)

        # 2. 상태 라벨 (사용자 수정본 여부) — pack 은 조건부(`_load`)
        self._status_lbl = tk.Label(self, text='',
                                      bg=_C('warning_bg', '#FDF2E9'),
                                      fg=_C('warning', '#7E5109'),
                                      font=('', 8, 'italic'),
                                      anchor='w', padx=8)

        # 3. 제목 영역
        title_frm = tk.Frame(self, bg=_C('bg', '#FAFAFA'))
        title_frm.pack(fill='x', padx=8, pady=(8, 2), side='top')
        tk.Label(title_frm, text=i18n.t('COMMON_TITLE', '제목') + ':',
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_label', '#333333'),
                 font=('', 9)).pack(side='left', padx=(0, 4))
        self._title_var = tk.StringVar()
        self._title_entry = tk.Entry(title_frm, textvariable=self._title_var,
                                       font=('', 11, 'bold'),
                                       state='readonly', relief='flat',
                                       readonlybackground=_C('panel', '#FFFFFF'),
                                       bg=_C('panel', '#FFFFFF'),
                                       fg=_C('fg_title', '#1A5276'))
        self._title_entry.pack(side='left', fill='x', expand=True)

        # 4. 기호 단추 — **편집 모드에서만** 나타난다(평소엔 자리도 안 차지한다)
        #   ★ 목록·모양은 **공용 부품** `symbol_picker` 가 갖는다 — 묵상노트·
        #     연구자료도 **같은 판**을 쓴다.
        #   ⚠⚠ 처음에는 여기만 「한 줄로 쫙」 늘어놓았는데 **36자가 1119px 이라
        #     600px 창을 넘었다**(실측). 사용자가 드롭다운에서 지적한 「화면
        #     바깥에 배치되는 기호들이 있다」와 같은 사고다.
        #     ⇒ **세 곳 다 드롭다운 하나**로 통일했다. 판이 화면 안으로
        #       끌어당겨지고, 끌어 옮긴 자리를 기억하고, 닫기 전에는 유지된다.
        import symbol_picker
        self._sym_f = tk.Frame(self, bg=_C('bg', '#FAFAFA'))
        symbol_picker.button(
            self._sym_f, lambda: self._text,
            text=i18n.t('MP_SYMBOLS', '기호'), db_path=self.db_path
        ).pack(side='left', padx=8, pady=2)

        # 5. 본문 영역 (남은 공간 전부)
        body = tk.Frame(self, bg=_C('bg', '#FAFAFA'))
        body.pack(fill='both', expand=True, padx=8, pady=4, side='top')
        sb = tk.Scrollbar(body, orient='vertical')
        sb.pack(side='right', fill='y')
        self._text = tk.Text(body, wrap='word', yscrollcommand=sb.set,
                             state='disabled', relief='flat',
                             bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'),
                             insertbackground=_C('fg', '#2C3E50'))
        self._text.pack(side='left', fill='both', expand=True)
        sb.config(command=self._text.yview)
        try:
            import theme_font
            theme_font.register(self._text, self.db_path, 'prose')
        except Exception:
            pass

        self._load()
        # ⚠ 테마·글꼴은 **다 지은 뒤 한 번** — 창을 만들자마자 부르면 뒤에
        #   붙는 위젯이 안 칠해지고, `adopt` 는 멱등이라 나중 호출이 그냥
        #   돌아간다(2026-08-21 연결하기 창에서 겪은 것과 같은 함정).
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass

    def _load(self):
        """매뉴얼 로드 — 사용자 수정본 우선, 없으면 sys, EN 폴백."""
        self._edit_mode = False
        self._btn_edit.config(text=i18n.t('COMMON_EDIT', '수정'))
        self._btn_save.config(state='disabled')
        self._title_entry.config(state='readonly')
        self._sym_f.pack_forget()

        with appdb.connect(self.db_path) as c:
            sys_row = c.execute(
                "SELECT manual_id, title, contents, user_type "
                "  FROM sys_manual_asset_v2 "
                " WHERE screen_code=? AND icon_key=? "
                "   AND record_status='LIVE' "
                "   AND UPPER(lang_code) IN (?, 'EN') "
                " ORDER BY CASE UPPER(lang_code) "
                "                WHEN ? THEN 0 ELSE 1 END LIMIT 1",
                (self.screen_code, self.icon_key, self._curr_lang,
                 self._curr_lang)).fetchone()
            if not sys_row:
                self._title_var.set(i18n.t('MSG_NO_MANUAL', '(매뉴얼 없음)'))
                self._set_text(i18n.t('MSG_NO_MANUAL_BODY', '이 화면의 매뉴얼이 아직 등록되지 않았습니다.'))
                self._btn_edit.config(state='disabled')
                return
            self._origin_id, sys_title, sys_contents, self._user_type = sys_row

            user_row = c.execute(
                "SELECT title, contents FROM user_manual_asset_v2 "
                " WHERE origin_id=? AND UPPER(lang_code)=? "
                "   AND COALESCE(record_status,'EDIT')='EDIT'",
                (self._origin_id, self._curr_lang)).fetchone()

        if user_row and (user_row[0] or user_row[1]):
            title = user_row[0] if user_row[0] else sys_title
            contents = user_row[1] if user_row[1] else sys_contents
            self._is_user_edited = True
        else:
            title = sys_title
            contents = sys_contents
            self._is_user_edited = False

        self._title_var.set(title)
        self._set_text(contents)

        if self._is_user_edited:
            self._status_lbl.config(
                text=i18n.t('MP_USERMOD', '  사용자 수정본 표시 중 — [복구]로 원본 복원 가능'))
            if not self._status_lbl.winfo_ismapped():
                self._status_lbl.pack(fill='x', side='top', before=None)
            self._btn_restore.config(state='normal')
        else:
            self._status_lbl.pack_forget()
            self._btn_restore.config(state='disabled')

        # USER_EDITABLE만 수정 허용
        if self._user_type == 'USER_EDITABLE':
            self._btn_edit.config(state='normal')
        else:
            self._btn_edit.config(state='disabled')

    def _set_text(self, contents):
        self._text.config(state='normal')
        self._text.delete('1.0', 'end')
        self._text.insert('1.0', contents or '')
        self._text.config(state='disabled' if not self._edit_mode else 'normal')

    def _toggle_edit(self):
        self._edit_mode = not self._edit_mode
        if self._edit_mode:
            self._title_entry.config(state='normal', relief='solid', bd=1)
            # ★★ **편집 모드에서도 바탕색을 바꾸지 않는다** (2026-08-23 사용자
            #   재지적 「수정 버튼을 누르면 테마 설정과 다른 색으로 표시한다.
            #   표준서식 준수하라」).
            #   ⚠ 처음엔 `#FFFEF0`(거의 흰색) → 그 다음 `warning_bg`(어두운
            #     갈색)로 고쳤는데 **여전히 테마 배경이 아니었다.** 편집 중임을
            #     색으로 알리려던 것 자체가 표준서식 밖이다.
            #   ⇒ 바탕은 **읽을 때와 똑같이** 두고, 편집 중임은 이미 있는 네
            #     가지가 알린다: 제목 칸 테두리 · 단추가 「수정 취소」로 · 저장
            #     단추 활성화 · **기호 줄 등장**.
            self._text.config(state='normal', bg=_C('panel', '#FFFFFF'))
            self._text.focus_set()
            # 기호 줄은 본문 **위**에 — 그냥 pack 하면 expand 자식 뒤라
            # 바닥으로 밀린다(§0-5 「expand 자식 뒤에 pack 한 띠」 함정).
            self._sym_f.pack(fill='x', padx=8, pady=(0, 2), side='top',
                             before=self._text.master)
            self._btn_edit.config(text=i18n.t('MP_CANCELEDIT', '수정 취소'))
            self._btn_save.config(state='normal')
        else:
            self._title_entry.config(state='readonly', relief='flat', bd=0)
            self._text.config(state='disabled', bg=_C('panel', '#FFFFFF'))
            self._sym_f.pack_forget()
            self._btn_edit.config(text=i18n.t('COMMON_EDIT', '수정'))
            self._btn_save.config(state='disabled')
            self._load()  # 변경 사항 폐기, 원래 값 다시 표시

    def _save(self):
        if not self._origin_id:
            return
        title = self._title_var.get().strip()
        contents = self._text.get('1.0', 'end').strip()
        if not title or not contents:
            messagebox.showinfo(i18n.t('COMMON_NOTICE', '알림'), i18n.t('MSG_ENTER_TITLE_BODY', '제목과 본문 모두 입력하세요.'))
            return

        with appdb.connect(self.db_path) as c:
            cur = c.cursor()
            row = cur.execute(
                "SELECT user_manual_id FROM user_manual_asset_v2 "
                " WHERE origin_id=? AND UPPER(lang_code)=?",
                (self._origin_id, self._curr_lang)).fetchone()
            if row:
                cur.execute(
                    "UPDATE user_manual_asset_v2 "
                    "   SET title=?, contents=?, record_status='EDIT', "
                    "       updated_at=datetime('now') "
                    " WHERE user_manual_id=?",
                    (title, contents, row[0]))
            else:
                cur.execute(
                    "INSERT INTO user_manual_asset_v2 "
                    "(origin_id, title, contents, lang_code, record_status, updated_at) "
                    "VALUES (?, ?, ?, ?, 'EDIT', datetime('now'))",
                    (self._origin_id, title, contents, self._curr_lang))
            c.commit()
        messagebox.showinfo(i18n.t('COMMON_DONE', '완료'), i18n.t('MSG_USERMANUAL_SAVED', '사용자 매뉴얼 저장 완료.\n([복구]로 원본 복원 가능)'))
        self._load()

    def _restore(self):
        if not self._origin_id:
            return
        if not messagebox.askyesno(i18n.t('MSG_T_CONFIRM', '확인'),
            i18n.t('MSG_RESTORE_ADMIN_Q', '사용자 수정본을 삭제하고 관리자 매뉴얼로 복원합니다.\n계속하시겠습니까?')):
            return
        with appdb.connect(self.db_path) as c:
            c.execute(
                "DELETE FROM user_manual_asset_v2 "
                " WHERE origin_id=? AND UPPER(lang_code)=?",
                (self._origin_id, self._curr_lang))
            c.commit()
        messagebox.showinfo(i18n.t('COMMON_DONE', '완료'), i18n.t('MSG_RESTORED_ADMIN', '관리자 매뉴얼로 복원되었습니다.'))
        self._load()
