# -*- coding: utf-8 -*-
"""db_sw_aog_plans.py — 스펄전 도서 플랜 2종 (영구 도구).

2026-08-18 사용자 지시 「영혼을 살리는 사람 진행한 후에 오직은혜 진행하라」.
db_spurgeon_psalms_plan(§0-5) 과 같은 틀 — 하루 = BOOK_TEXT + CORE(§17-5),
화면 수정 0. 플랜 하나 = 묶음 이름 규칙(cat 4 아래 새 묶음).

  python db_sw_aog_plans.py --selftest      # 의무 (실 DB 트랜잭션 롤백)
  python db_sw_aog_plans.py --apply SW      # 「영혼을 살리는 사람」 15일
  python db_sw_aog_plans.py --apply AOG     # 「오직 은혜」 20일

  · 각 장의 CORE 구절은 그 장이 강해하는 본문에서 골랐다(잠 11:30 · 롬 4:5
    · 엡 2:8 등). 유닛의 key_verse_ref/start_vid/end_vid 도 함께 채운다.
  · meditation_focus = 「왜 이 구절이 여기 있나」 한 줄(KO 합니다체, — 금지).
  · 멱등 — 재실행하면 스케줄만 다시 깔고 plan_id·unit_id 는 불변.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, 'bible_master.db')
sys.path.insert(0, HERE)
import appdb
import scripture_ref_kr


def _upsert_text(c, tt, cid, lang, val):
    row = c.execute(
        "SELECT sys_text_id FROM sys_text_asset WHERE text_type=? AND "
        "clicked_id=? AND UPPER(lang_code)=?", (tt, cid, lang)).fetchone()
    if row:
        # 제목류는 title·contents 두 칸에 같은 값(plan_label 규칙)
        c.execute("UPDATE sys_text_asset SET contents=?, title=?, "
                  "record_status='LIVE' WHERE sys_text_id=?",
                  (val, val, row[0]))
    else:
        c.execute("INSERT INTO sys_text_asset (text_type, clicked_id, "
                  "lang_code, title, contents, record_status) "
                  "VALUES (?,?,?,?,?,'LIVE')", (tt, cid, lang, val, val))


PLANS = {
    'SW': dict(
        book_code='SPURGEON_SW', plan_code='SPURGEON_SW_15D', days=15,
        titles={'KO': '영혼을 살리는 사람', 'EN': 'The Soul Winner'},
        descs={'KO': '스펄전이 사역자와 성도에게 전한 영혼 구원 강의 15편을 '
                     '하루 한 장씩 읽습니다. 각 장이 강해하는 구절을 함께 '
                     '묵상합니다.',
               'EN': "Fifteen of Spurgeon's lectures and addresses on "
                     'winning souls, one chapter a day with its key '
                     'scripture.'},
        # (sequence, CORE 구절, 묵상포커스 한 줄)
        core=[
            (1, '잠 11:30',
             '사람을 얻는 자는 지혜롭다는 이 한 구절이 책 전체의 제목이 '
             '되었습니다.'),
            (2, '시 51:12-13',
             '먼저 자신이 구원의 기쁨을 회복해야 범죄자에게 주의 도를 '
             '가르칠 수 있습니다.'),
            (3, '고전 9:22',
             '바울은 몇 사람이라도 구원하려고 여러 사람에게 여러 모습이 '
             '되었습니다.'),
            (4, '사 55:11',
             '하나님의 말씀은 헛되이 돌아오지 않습니다. 영혼을 살리는 '
             '설교의 확신입니다.'),
            (5, '고후 4:3-4',
             '복음이 가려지는 자리가 어디인지 알아야 장애물을 걷어낼 수 '
             '있습니다.'),
            (6, '요 1:41-42',
             '안드레는 먼저 자기 형제를 찾아 예수님께 데려왔습니다. 평범한 '
             '성도의 전도입니다.'),
            (7, '겔 37:9-10',
             '마른 뼈가 살아나는 것은 생기 곧 하나님의 영이 하시는 '
             '일입니다.'),
            (8, '약 5:20',
             '죄인을 돌아서게 하는 사람은 한 영혼을 사망에서 구원합니다.'),
            (9, '갈 4:19',
             '영혼을 살리는 일에는 해산하는 수고와 같은 대가가 따릅니다.'),
            (10, '살전 2:19-20',
             '얻은 영혼이 곧 소망이요 기쁨이요 자랑의 면류관입니다.'),
            (11, '행 20:24',
             '바울은 복음 증거하는 일을 위해 생명도 귀히 여기지 '
             '않았습니다.'),
            (12, '딤전 4:16',
             '자신과 가르침을 살피는 일이 자신과 듣는 자를 함께 '
             '구원합니다.'),
            (13, '고전 9:16',
             '복음 전하는 일은 자랑이 아니라 부득불 해야 할 일입니다.'),
            (14, '마 4:19',
             '나를 따라오라 부르신 주님이 사람을 낚는 어부로 만드십니다.'),
            (15, '시 126:5-6',
             '눈물로 씨를 뿌리는 자는 반드시 기쁨으로 거둡니다.'),
        ]),
    'AOG': dict(
        book_code='SPURGEON_AOG', plan_code='SPURGEON_AOG_20D', days=20,
        titles={'KO': '오직 은혜', 'EN': 'All of Grace'},
        descs={'KO': '구원이 처음부터 끝까지 은혜임을 전하는 스펄전의 초청을 '
                     '하루 한 장씩 읽습니다. 각 장이 강해하는 구절을 함께 '
                     '묵상합니다.',
               'EN': "Spurgeon's warm invitation to salvation entirely of "
                     'grace, one chapter a day with its key scripture.'},
        core=[
            (1, '사 55:1',
             '값없이 오라는 초청이 이 책이 건네는 첫마디입니다.'),
            (2, '눅 19:10',
             '예수님은 잃어버린 자를 찾아 구원하러 오셨습니다.'),
            (3, '롬 4:5',
             '하나님은 경건치 않은 자를 의롭다 하십니다. 은혜의 '
             '출발점입니다.'),
            (4, '롬 8:33-34',
             '의롭다 하신 이가 하나님이시면 누가 정죄할 수 있습니까.'),
            (5, '롬 3:26',
             '하나님은 자기도 의로우시며 믿는 자를 의롭다 하시는 '
             '분입니다.'),
            (6, '마 1:21',
             '예수라는 이름 자체가 자기 백성을 죄에서 구원할 자라는 '
             '뜻입니다.'),
            (7, '엡 2:8',
             '구원은 은혜에 의하여 믿음으로 말미암습니다. 행위가 '
             '아닙니다.'),
            (8, '히 11:1', '믿음이 무엇인지 성경이 스스로 정의해 줍니다.'),
            (9, '사 45:22',
             '땅 끝의 모든 백성아 나를 앙망하라. 바라보는 것이 믿음입니다.'),
            (10, '롬 4:16',
             '믿음으로 되는 까닭은 은혜에 속하게 하려 함입니다.'),
            (11, '요 6:44',
             '아무것도 할 수 없다는 고백 앞에서 이끄시는 아버지를 '
             '만납니다.'),
            (12, '눅 17:5', '믿음을 더하소서. 작은 믿음도 자랍니다.'),
            (13, '요 3:7', '거듭남은 성령께서 하시는 일입니다.'),
            (14, '욥 19:25',
             '나의 구속자가 살아 계시다는 확신이 믿음의 노래가 됩니다.'),
            (15, '행 5:31', '회개와 죄 사함은 같은 손에서 함께 주어집니다.'),
            (16, '슥 12:10',
             '찌른 바 그를 바라볼 때 참된 회개가 시작됩니다.'),
            (17, '빌 1:6', '착한 일을 시작하신 이가 그날까지 이루십니다.'),
            (18, '고전 1:8', '주께서 끝까지 견고하게 하십니다.'),
            (19, '요 10:28', '주님이 주시는 영생은 영원히 멸망하지 않습니다.'),
            (20, '계 22:17',
             '성령과 신부가 말씀하십니다. 오라, 값없이 생명수를 받으라.'),
        ]),
}


def apply(conn, which, verbose=True):
    p = PLANS[which]
    c = conn
    book_id = c.execute('SELECT book_id FROM sys_book_asset WHERE '
                        'book_code=?', (p['book_code'],)).fetchone()[0]

    # ① CORE 구절 해석 + 유닛 key_verse 채움
    bm = scripture_ref_kr.book_map_ko(c)
    day_vids = {}
    for seq, ref, _focus in p['core']:
        a, b = scripture_ref_kr.resolve(c, ref, bm)
        if a is None:
            raise SystemExit('구절 해석 실패: %s' % ref)
        day_vids[seq] = (a, b)
        c.execute("UPDATE sys_book_unit SET key_verse_ref=?, start_vid=?, "
                  "end_vid=? WHERE book_id=? AND sequence=?",
                  (ref, a, b, book_id, seq))

    # ② 카테고리 — cat 4 아래 새 묶음(플랜 하나 = 묶음 이름)
    row = c.execute("""SELECT t.clicked_id FROM sys_text_asset t
        JOIN sys_plan_category pc ON pc.cat_id=t.clicked_id
        WHERE t.text_type='PLAN_CAT_NAME' AND t.contents=? AND
        t.lang_code='KO' AND pc.parent_id=4 LIMIT 1""",
        (p['titles']['KO'],)).fetchone()
    if row:
        cat_id = row[0]
    else:
        cat_id = c.execute('SELECT COALESCE(MAX(cat_id),0)+1 FROM '
                           'sys_plan_category').fetchone()[0]
        so = c.execute('SELECT COALESCE(MAX(sort_order),0)+10 FROM '
                       'sys_plan_category WHERE parent_id=4').fetchone()[0]
        c.execute("INSERT INTO sys_plan_category (cat_id, parent_id, "
                  "sort_order, record_status, scope) "
                  "VALUES (?,4,?,'LIVE','BOOK')", (cat_id, so))
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_CAT_NAME', cat_id, lg, p['titles'][lg])

    # ③ 플랜
    row = c.execute('SELECT plan_id FROM sys_bible_plan WHERE plan_code=?',
                    (p['plan_code'],)).fetchone()
    if row:
        plan_id = row[0]
        c.execute("UPDATE sys_bible_plan SET plan_type='BOOK_BASED', "
                  "plan_category='THEMATIC', duration_days=?, track_count=1, "
                  "cat_id=?, record_status='LIVE' WHERE plan_id=?",
                  (p['days'], cat_id, plan_id))
    else:
        cur = c.execute("""INSERT INTO sys_bible_plan (plan_code, plan_type,
                     duration_days, track_count, record_status,
                     plan_category, cat_id)
                     VALUES (?,'BOOK_BASED',?,1,'LIVE','THEMATIC',?)""",
                        (p['plan_code'], p['days'], cat_id))
        plan_id = cur.lastrowid
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_TITLE', plan_id, lg, p['titles'][lg])
        _upsert_text(c, 'PLAN_DESC', plan_id, lg, p['descs'][lg])

    # ④ 스케줄 — day N = BOOK_TEXT(포커스) + CORE
    c.execute('DELETE FROM sys_plan_schedule WHERE plan_id=?', (plan_id,))
    units = {seq: uid for uid, seq in c.execute(
        'SELECT unit_id, sequence FROM sys_book_unit WHERE book_id=? '
        "AND record_status='LIVE'", (book_id,))}
    for seq, ref, focus in p['core']:
        a, b = day_vids[seq]
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order, unit_key, "
                  "meditation_focus) VALUES (?,?,1,?,?,'BOOK_TEXT',1,?,?)",
                  (plan_id, seq, a, b, 'BOOK_%d' % units[seq], focus))
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order) "
                  "VALUES (?,?,1,?,?,'CORE',2)", (plan_id, seq, a, b))
    if verbose:
        ns = c.execute('SELECT COUNT(*) FROM sys_plan_schedule WHERE '
                       'plan_id=?', (plan_id,)).fetchone()[0]
        print('플랜 %s(plan_id %d, cat %d) 스케줄 %d행 · 유닛 key_verse %d'
              % (p['plan_code'], plan_id, cat_id, ns, len(day_vids)))
    return plan_id, cat_id


def selftest():
    """실 DB 트랜잭션 롤백 검증 — 흔적 0 (db_spurgeon_psalms_plan 방식)."""
    ok = True

    def t(name, cond):
        nonlocal ok
        print('%s %s' % ('✓' if cond else '✗', name))
        ok = ok and cond

    conn = appdb.connect(DB)
    # ⚠ 「흔적 0」으로 재지 않는다 — 실제 적재 뒤에는 플랜이 정당하게
    #   존재한다(§0-5 「자가 검증을 데이터 상태에 걸지 말 것」). 전후 비교.
    before = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
    try:
        conn.execute('BEGIN')
        for which, days in (('SW', 15), ('AOG', 20)):
            plan_id, cat_id = apply(conn, which, verbose=False)
            rows = conn.execute(
                "SELECT day, stage_type, start_vid, meditation_focus, "
                "unit_key FROM sys_plan_schedule WHERE plan_id=? "
                "ORDER BY day, sort_order", (plan_id,)).fetchall()
            t('%s 스케줄 %d행(=일수×2)' % (which, len(rows)),
              len(rows) == days * 2)
            t('%s 일 연속·쌍 구조' % which,
              [(d, s) for d, s, *_r in rows] ==
              [(n, st) for n in range(1, days + 1)
               for st in ('BOOK_TEXT', 'CORE')])
            t('%s BOOK_TEXT 전부 unit_key·포커스 보유' % which,
              all(r[4] and (r[3] or '').strip() for r in rows
                  if r[1] == 'BOOK_TEXT'))
            t('%s 포커스에 — 없음' % which,
              all('—' not in (r[3] or '') for r in rows))
            t('%s vid 전부 채움' % which, all(r[2] for r in rows))
            title = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE "
                "text_type='PLAN_TITLE' AND clicked_id=? AND lang_code='KO'",
                (plan_id,)).fetchone()[0]
            t('%s 제목 규칙(10자 이내·대시 없음)' % which,
              len(title) <= 10 and '—' not in title and '-' not in title)
            # 멱등 — 두 번째 적용에서 plan_id·cat_id 불변
            p2, c2 = apply(conn, which, verbose=False)
            t('%s 멱등(plan·cat 불변)' % which,
              (p2, c2) == (plan_id, cat_id))
    finally:
        conn.rollback()
        conn.close()
    # 롤백 확인 — 스케줄 행수가 시작 전과 같아야 한다
    conn = appdb.connect(DB)
    try:
        after = conn.execute(
            'SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
        t('롤백 — 실 DB 무변화(스케줄 %d행 유지)' % before, after == before)
    finally:
        conn.close()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if a[0] == '--apply' and len(a) >= 2 and a[1].upper() in PLANS:
        conn = appdb.connect(DB)
        try:
            apply(conn, a[1].upper())
            conn.commit()
        finally:
            conn.close()
        sys.exit(0)
    print(__doc__)
