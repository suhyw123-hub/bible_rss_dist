# shared_map.py
# -*- coding: utf-8 -*-

# 🎯 1. NAV_REGISTRY: UI 컴포넌트와 DB 자산의 정밀 배선도
# - tgt: 대상 자산 타입 (UNIT, LINK, TEXT 등)
# - filter: DB 조회 시 적용할 고정 필터 (신규 용어 적용)
# - multi: False(1:1 관계, 엄격 중복 체크), True(1:N 관계, 중복 허용)
NAV_REGISTRY = {
    # --- UNIT 자산 ---
    'CONT_list':     {'tgt': 'UNIT', 'filter': {'unit_type': 'CONTAINER'}},
    'NODE_list':     {'tgt': 'UNIT', 'filter': {'unit_type': 'NODE'}},
    
    # --- LINK 자산 ---
    'CN_list':       {'tgt': 'LINK', 'filter': {'link_type': 'CONT_NODE'}, 'src_key': 'clicked_id'},
    'NV_list':       {'tgt': 'LINK', 'filter': {'link_type': 'NODE_VERS'}, 'src_key': 'clicked_id'},
    'VV_list':       {'tgt': 'LINK', 'filter': {'link_type': 'VERS_VERS'}, 'src_key': 'clicked_id'},
    'PV_list':       {'tgt': 'LINK', 'filter': {'link_type': 'PERI_VERS'}, 'src_key': 'clicked_id'}, # 🆕 신설
    'TP_list':       {'tgt': 'LINK', 'filter': {'link_type': 'TAG_PERI'}, 'src_key': 'clicked_id'},  # 🆕 신설
    
    # --- TEXT 자산 (is_multi = False: 설명 및 주석류) ---
    'CONT_desc':     {'tgt': 'TEXT', 'filter': {'text_type': 'CONT_DESC'},      'multi': False},
    'NODE_desc':     {'tgt': 'TEXT', 'filter': {'text_type': 'NODE_DESC'},      'multi': False},
    'CN_desc':       {'tgt': 'TEXT', 'filter': {'text_type': 'CONT_NODE_DESC'}, 'multi': False}, # 🔄 용어수정
    'NV_desc':       {'tgt': 'TEXT', 'filter': {'text_type': 'NODE_VERS_DESC'}, 'multi': False}, # 🔄 용어수정
    'VV_desc':       {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_VERS_DESC'}, 'multi': False}, # 🔄 용어수정
    'V_desc':        {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_DESC'},      'multi': False}, # 🔄 용어수정 (구 COMMENTARY)
    'V_quest':       {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_QUESTION'},  'multi': False}, # 🔄 용어수정
    'V_pray':        {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_PRAYER'},    'multi': False}, # 🔄 용어수정
    'PERI_desc':     {'tgt': 'TEXT', 'filter': {'text_type': 'PERI_DESC'},      'multi': False}, # 🆕 신설
    'PV_desc':       {'tgt': 'TEXT', 'filter': {'text_type': 'PERI_VERS_DESC'}, 'multi': False}, # 🆕 신설

    # --- TEXT 자산 (is_multi = True: 노트 및 참조류) ---
    'V_note':        {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_NOTE'},      'multi': True},  # 🔄 용어수정
    'V_refr':        {'tgt': 'TEXT', 'filter': {'text_type': 'VERS_REFR'},      'multi': True},  # 🔄 용어수정
}

# 🎯 2. EVENT_MAP: 상위 리스트 선택 시 하위 컴포넌트로 전파되는 연쇄 반응 정의
# - use_target: True일 경우 선택된 행의 target_id를, False일 경우 pk를 전달
EVENT_MAP = {
    'CONT_list': [
        {'comp': 'CONT_desc'}, 
        {'comp': 'CN_list'}
    ],
    'CN_list': [
        {'comp': 'CN_desc'},   
        {'comp': 'NV_list', 'use_target': True}
    ],
    'NODE_list': [
        {'comp': 'NODE_desc'}, 
        {'comp': 'NV_list'}
    ],
    'NV_list': [
        {'comp': 'COMM_desc',     'use_target': True}, 
        {'comp': 'NV_desc',        'use_target': False},
        {'comp': 'QUESTION_desc', 'use_target': True}, 
        {'comp': 'PRAYER_desc',   'use_target': True}
    ]
}

# 🎯 3. SYS_MASTER_MAP: 시스템 자산 테이블 상세 명세 (물리 스키마 기반)
SYS_MASTER_MAP = {
    'UNIT': {
        'table': 'sys_unit_asset', 'pk': 'sys_unit_id', 'disp': 'unit_name_sid',
        'cols': ['unit_name_sid', 'unit_type', 'contents', 'record_status', 'sort_order', 'cat_id'],
        'rules': {'has_lang': False, 'has_sort': True}
    },
    'TEXT': {
        'table': 'sys_text_asset', 'pk': 'sys_text_id', 'disp': 'text_type',
        'cols': ['text_type', 'clicked_id', 'lang_code', 'contents', 'record_status'],
        'rules': {'has_lang': True, 'has_sort': False}
    },
    'TAG': {
        'table': 'sys_tag_asset', 'pk': 'sys_tag_id', 'disp': 'tag_name_sid',
        'cols': ['tag_name_sid', 'tag_category', 'record_status'],
        'rules': {'has_lang': False, 'has_sort': False}
    },
    'BIBLE': {
        'table': 'bible_index', 'pk': 'verse_id', 'disp': 'verse_id',
        'cols': ['bcode', 'chapter', 'verse'],
        'rules': {'has_lang': False, 'has_sort': False, 'no_union': True}
    },
    'LINK': {
        'table': 'sys_link_asset', 'pk': 'sys_link_id', 'disp': 'link_type',
        'cols': ['link_type', 'clicked_id', 'target_id', 'record_status', 'sort_order'],
        'rules': {'has_lang': False, 'has_sort': True}
    }
}



# 🎯 4. USER_MASTER_MAP: 사용자 자산 테이블 상세 명세 (SYS와 대칭 구조)
USER_MASTER_MAP = {
    'UNIT': {
        'table': 'user_unit_asset', 
        'pk': 'user_unit_id', 
        'disp': 'unit_name_sid', 
        'origin': 'origin_id',
        'cols': ['unit_type', 'unit_name_sid', 'origin_id', 'record_status']
    },
    'TEXT': {
        'table': 'user_text_asset', 
        'pk': 'user_text_id', 
        'disp': 'contents',      
        'origin': 'origin_id',
        'cols': ['text_type', 'lang_code', 'clicked_id', 'contents', 'origin_id', 'record_status']
    },
    'LINK': {
        'table': 'user_link_asset', 
        'pk': 'user_link_id', 
        'disp': 'link_type',     
        'origin': 'origin_id',
        'cols': ['link_type', 'clicked_id', 'target_id', 'origin_id', 'record_status']
    },
    'TAG': {
        'table': 'user_tag_asset',  
        'pk': 'user_tag_id',  
        'disp': 'tag_name_sid',  
        'origin': 'origin_id',
        'cols': ['user_tag_id', 'tag_name_sid', 'tag_category', 'origin_id', 'record_status']
    }
}


# 🎯 2. RELATION_GATES: 자산 간의 논리적 연결 통로 정의
RELATION_GATES = {
    'CONT_NODE': {'src': 'UNIT',   'tgt': 'UNIT'},
    'NODE_VERS': {'src': 'UNIT',   'tgt': 'BIBLE'},
    'VERS_VERS': {'src': 'BIBLE',  'tgt': 'BIBLE'},
    'PERI_VERS': {'src': 'PERICOPE','tgt': 'BIBLE'}, # 🆕 신설
    'TAG_CONT':  {'src': 'TAG',    'tgt': 'UNIT'},
    'TAG_NODE':  {'src': 'TAG',    'tgt': 'UNIT'},
    'TAG_VERS':  {'src': 'TAG',    'tgt': 'BIBLE'},
    'TAG_PERI':  {'src': 'TAG',    'tgt': 'PERICOPE'} # 🆕 신설
}


# 🎯 3. IDENTITY_MAP: 각 자산의 유일성(중복 판단) 기준 정의
IDENTITY_MAP = {
    'UNIT': ['unit_name_sid'],
    'TAG':  ['tag_name_sid'],
    'LINK': ['link_type', 'clicked_id', 'target_id'],
    'PERICOPE': ['start_vid', 'end_vid'], # 🆕 신설
    'TEXT': {
        'VERS_NOTE': [], # 🎯 Multi 타입: 중복 체크 건너뜀
        'VERS_REFR': [], # 🎯 Multi 타입: 중복 체크 건너뜀
        '__default__': ['text_type', 'clicked_id', 'lang_code'] # 🎯 Single 타입 기본 규격
    }
}
# 🎯 4. FETCH_POLICIES: 엔진 사냥 시 적용할 상세 명령어 파라미터
# 모든 자산 유형(TEXT, TAG, BIBLE, UNIT, LINK)의 세부 정책을 완전하게 유지합니다.
FETCH_POLICIES = {
    'TEXT': {
        'mandatory_filters': ['lang_code'],
        'forbidden_order': ['sort_order'],
        'virtual_filters': [],
        'use_union': True
    },
    'TAG': {
        'mandatory_filters': [],
        'forbidden_order': ['sort_order'],
        'virtual_filters': [],
        'use_union': True
    },
    'BIBLE': {
        'mandatory_filters': [],
        'forbidden_order': [],
        'virtual_filters': ['step', 'bcode'],
        'use_union': False,
        'pk_mapping': 'verse_id'
    },
    'UNIT': {
        'mandatory_filters': [], 
        'forbidden_order': [], 
        'virtual_filters': [], 
        'use_union': True
    },
    'LINK': {
        'mandatory_filters': [], 
        'forbidden_order': [], 
        'virtual_filters': ['p4_connection'], 
        'use_union': True
    }
}

