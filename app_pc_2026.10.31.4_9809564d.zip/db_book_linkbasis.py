# -*- coding: utf-8 -*-
"""db_book_linkbasis.py — 마이어 『Our Daily Homily』 의 **주제 구절 절 번호를 원본 스캔에서 되살린다**
(2026-10-13 신설 · 영구 · `--selftest` · 멱등 · `--undo`).

★ 왜 — `book_link` 가 마이어 편을 **주제 구절 한 절에만** 건다(docs/1.txt 72-2 · 사용자 「원본에 따라서
  구절만 연결 또는 장연결을 결정하라」). 그런데 1,189편 중 **146편**은 `key_verse_ref` 에 장만 있다
  (「Luke 12」) — 적재 때 원본 줄 「Luke xii. ii (R. v.).」 의 숫자가 OCR 로 깨져(ii=11) 못 읽었다.
  절을 모르면 그 편은 장 전체로 물러난다.

★★ 되살리는 길 둘 — **둘 다 원본과 성경 본문으로 검증한다**(지어내지 않는다 §0-1b).
  ⓐ 원본 스캔(`_meyer_raw/v1~5.txt`)에서 그 편 머리 위의 참조 줄을 찾아 **장(로마 숫자)이 맞는지** 보고,
     깨진 숫자는 OCR 혼동 표(`DIG`)로 **후보 여럿**을 만든 뒤 **편 제목 낱말이 가장 많이 든 절**을 고른다
     (제목 낱말 포함률 0.34 이상).
  ⓑ 참조 줄이 없거나 못 읽으면 **편 제목이 그 장의 한 절에만 0.8 이상** 들어맞을 때만.
  못 찾으면 **그대로 둔다** — 장으로 물러나는 것이 틀린 절에 거는 것보다 낫다.
⚠ 고치는 칸은 `key_verse_ref` 하나(「Luke 12」 → 「Luke 12:11」) — 범위(`start_vid~end_vid`)는 읽을 장이라
  손대지 않는다. `sys_book_unit` 은 감사 트리거 밖이라 **제 백업표**를 남긴다.

    python -X utf8 db_book_linkbasis.py --selftest
    python -X utf8 db_book_linkbasis.py --check     (무엇을 고칠지)
    python -X utf8 db_book_linkbasis.py --apply
    python -X utf8 db_book_linkbasis.py --undo
"""
import itertools
import os
import re
import sys

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_meyer_raw')
BOOK = 'MEYER_ODH'
BACKUP = 'temp_p72_keyverse_backup'
VERS = ('KJV', 'ASV', 'WEB', 'BSB')

#: OCR 이 숫자로 읽어야 할 글자 — 실측(i=1 · j=1/3 · y=7 · z=2 · ^=4 …)
DIG = {'i': '1', 'l': '1', 'I': '1', '|': '1', '!': '1', 't': '1', 'j': '13', 'J': '13', 'y': '7',
       'z': '2', 'Z': '2', 'o': '0', 'O': '0', 's': '5', 'S': '5', 'g': '9', 'b': '6', 'B': '8',
       '^': '4', 'H': '1'}
REF = re.compile(r'(?<![A-Za-z])([ivxlcIVXLCjH]{1,7})\s*[.,]\s*([0-9a-zA-Z|!^]{1,3})(?=[\s.,;(\-]|$)')
REF_MIN, TITLE_MIN = 0.34, 0.8


def roman(s):
    s = s.lower().replace('j', 'i')
    vals = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100}
    tot = 0
    for k, ch in enumerate(s):
        if ch not in vals:
            return None
        v = vals[ch]
        nx = vals.get(s[k + 1]) if k + 1 < len(s) else 0
        tot += -v if nx and nx > v else v
    return tot


def vcands(tok):
    opts = []
    for ch in tok:
        if ch.isdigit():
            opts.append(ch)
        elif ch in DIG:
            opts.append(DIG[ch])
        else:
            return set()
    return {int(''.join(p)) for p in itertools.product(*opts)}


def nw(s):
    return [w for w in re.sub(r'[^a-z ]', ' ', (s or '').lower()).split() if len(w) > 2]


def title_of(label):
    """제목에 섞인 참조(「… Isa. XXXV. 8.」)를 떼어 낸 앞부분."""
    return re.split(r'\s[A-Z][a-z]{1,5}[.,]?\s*[ivxlcIVXL]{1,7}[.,]', label or '')[0]


def pick(lines, title, ch, vtext):
    """→ (절, 길) 또는 (None, '')."""
    tw = nw(title)

    def sc(v):
        if not tw or v not in vtext:
            return -1
        s = set(nw(vtext[v]))
        return sum(1 for w in tw if w in s) / len(tw)
    for ln in lines:
        for m in REF.finditer(ln or ''):
            if roman(m.group(1)) != ch:
                continue
            cs = sorted(((sc(x), x) for x in vcands(m.group(2)) if x in vtext), reverse=True)
            if cs and cs[0][0] >= REF_MIN:
                return cs[0][1], 'REF'
    cand = sorted(((sc(v), v) for v in vtext), reverse=True)
    if cand and cand[0][0] >= TITLE_MIN and (len(cand) < 2 or cand[1][0] < cand[0][0]):
        return cand[0][1], 'TITLE'
    return None, ''


def _raw_lines():
    out = []
    for v in range(1, 6):
        p = os.path.join(RAW, 'v%d.txt' % v)
        if os.path.exists(p):
            out.append([' '.join(ln.split()) for ln in open(p, encoding='utf-8', errors='replace').read().splitlines()])
    return out


def plan(conn):
    raws = _raw_lines()
    rows = conn.execute(
        "SELECT u.unit_id, u.unit_label, u.key_verse_ref, a.bcode, a.chapter, t.body_text "
        "  FROM sys_book_unit u JOIN sys_book_asset k ON k.book_id=u.book_id "
        "  JOIN bible_index a ON a.verse_id=u.start_vid "
        "  LEFT JOIN sys_book_unit_text t ON t.unit_id=u.unit_id AND t.text_variant='ORIGINAL' "
        "       AND UPPER(t.lang_code)='EN' "
        " WHERE k.book_code=? AND u.record_status='LIVE' AND COALESCE(u.key_verse_ref,'')<>'' "
        "   AND u.key_verse_ref NOT LIKE '%:%'", (BOOK,)).fetchall()
    got, miss = [], []
    for uid, lab, ref, b, ch, body in rows:
        head = ' '.join((body or '').split())[:20]
        lines = [lab]
        if head:
            for vol in raws:
                hit = next((i for i, ln in enumerate(vol) if ln.startswith(head)), None)
                if hit is not None:
                    lines += vol[max(hit - 5, 0):hit]
                    break
        vtext = {}
        for vid, v in conn.execute('SELECT verse_id, verse FROM bible_index WHERE bcode=? AND chapter=?', (b, ch)):
            vtext[v] = ' '.join(t for (t,) in conn.execute(
                'SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code IN (%s)'
                % ','.join('?' * len(VERS)), (vid,) + VERS))
        v, how = pick(lines, title_of(lab), ch, vtext)
        (got if v else miss).append((uid, ref, ('%s:%d' % (ref, v)) if v else None, how, lab))
    return got, miss


def apply(conn):
    got, miss = plan(conn)
    conn.execute('CREATE TABLE IF NOT EXISTS %s (unit_id INTEGER PRIMARY KEY, key_verse_ref TEXT)' % BACKUP)
    for uid, old, new, _h, _l in got:
        conn.execute('INSERT OR IGNORE INTO %s VALUES(?,?)' % BACKUP, (uid, old))
        conn.execute('UPDATE sys_book_unit SET key_verse_ref=? WHERE unit_id=?', (new, uid))
    conn.commit()
    return got, miss


def undo(conn):
    n = 0
    try:
        for uid, old in conn.execute('SELECT unit_id, key_verse_ref FROM %s' % BACKUP).fetchall():
            n += conn.execute('UPDATE sys_book_unit SET key_verse_ref=? WHERE unit_id=?', (old, uid)).rowcount
        conn.execute('DROP TABLE %s' % BACKUP)
        conn.commit()
    except Exception as e:                                # noqa: BLE001
        print('되돌릴 것이 없습니다: %s' % e)
    return n


def selftest():
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)
    ck(roman('xii') == 12 and roman('XXXV') == 35 and roman('ix') == 9, '로마 숫자')
    ck(vcands('ii') == {11} and vcands('2y') == {27} and vcands('jo') == {10, 30}, 'OCR 숫자 후보')
    vt = {11: 'Be not anxious how or what ye shall answer', 22: 'Be not anxious for your life',
          25: 'which of you by being anxious'}
    ck(pick(['Luke xii. ii (R. v.).'], 'Be not anxious.', 12, vt) == (11, 'REF'), '원본 줄 — 깨진 숫자를 읽는다')
    ck(pick(['Luke xiii. ii (R. v.).'], 'Be not anxious.', 12, vt)[0] is None,
       '장이 다르면 그 줄을 안 믿는다 · 제목이 두 절에 같으면 안 고른다')
    ck(pick(['Luke xii. 25.'], 'Fear not little flock.', 12, vt)[0] is None, '제목 낱말이 그 절에 없으면 안 고른다')
    ck(title_of('The way of holiness. Isa. XXXV. 8.') == 'The way of holiness.', '제목에서 참조를 뗀다')
    c = appdb.connect()
    if os.path.isdir(RAW):
        # ⚠ 데이터 상태를 전제하지 않는다(§0-5) — 이미 적용했으면 백업표의 옛 값을 잠깐 되돌려 잰다.
        c.execute('SAVEPOINT st')
        try:
            try:
                for uid, old in c.execute('SELECT unit_id, key_verse_ref FROM %s' % BACKUP).fetchall():
                    c.execute('UPDATE sys_book_unit SET key_verse_ref=? WHERE unit_id=?', (old, uid))
            except Exception:                         # noqa: BLE001
                pass
            got, miss = plan(c)
        finally:
            c.execute('ROLLBACK TO st')
            c.execute('RELEASE st')
        ck(len(got) >= 90, '실제 자료 — 되살릴 편 %d · 남는 편 %d' % (len(got), len(miss)))
        g = {u: n for u, _o, n, _h, _l in got}
        ck(g.get(4640) == 'Luke 12:11', '「Be not anxious」 = 눅 12:11(원본 「Luke xii. ii」)')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    if '--undo' in a:
        print('되돌림 %d편' % undo(c))
    elif '--apply' in a or '--check' in a:
        got, miss = apply(c) if '--apply' in a else plan(c)
        for uid, old, new, how, lab in got:
            print('%5d  %-22s → %-26s %-5s %s' % (uid, old, new, how, (lab or '')[:50]))
        print('— 절을 못 찾아 장으로 남는 편 %d —' % len(miss))
        for uid, old, _n, _h, lab in miss:
            print('%5d  %-22s %s' % (uid, old, (lab or '')[:60]))
        print('%s %d편 · 남음 %d편' % ('고침' if '--apply' in a else '고칠 것', len(got), len(miss)))
    else:
        print(__doc__)
