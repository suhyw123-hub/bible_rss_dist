# -*- coding: utf-8 -*-
"""
db_versification_tvtms_check.py  (영구 진단도구)

목적: 저장된 각 버전이 우리 bible_index(영어/KJV 표준 번호축)에 실제로 정렬돼 있는지
      검증한다. 특히 히브리(맛소라) 전통이 영어와 다른 지점(시편 표제·장경계)에서
      어떤 버전이 번호를 밀어 넣어 '같은 verse_id에 다른 내용'을 담고 있는지 찾는다.

Ground truth: Tyndale House STEPBible-Data / TVTMS (CC BY 4.0)
  Versification/TVTMS ... - STEPBible.org CC BY.txt
  → OT Hebrew vs English-standard 차이 구절 목록. (raw 파일은 재배포 금지 — 로컬 참조만)

핵심 검사(언어 독립): 시편 각 장에서 버전의 절별 '길이 벡터'가 KJV와
  offset 0(정렬)에서 상관이 높은지, offset +1(표제를 v1로 밀어 넣음)에서 높은지 비교.
  표제를 별도 v1로 둔 대륙식(히브리) 번호 버전은 +1에서 상관이 튄다.

사용법: python -X utf8 db_versification_tvtms_check.py
검증 결과(2026-07-18): 내용 보유 12개 MT 버전 중 FreJND(프랑스 Darby)만 시편 ~56편에서 +1 밀림.
  나머지(KJV/ASV/WEB/BSB/KRV/CUV/CUVS/ARB/GerElb/SpaRV/PorBL)는 표제를 버리거나 v1에 합쳐 정렬.
  WLC/JLV/TRC = 본문 0행(빈 껍데기). RusSyn/Coptic = 비-MT라 제외.
"""
import sqlite3, re

DB='bible_master.db'
PSA_BCODE=19

def corr(a,b):
    n=len(a)
    if n<4: return 0.0
    ma=sum(a)/n; mb=sum(b)/n
    num=sum((a[i]-ma)*(b[i]-mb) for i in range(n))
    da=sum((x-ma)**2 for x in a)**.5; db=sum((x-mb)**2 for x in b)**.5
    return num/(da*db) if da and db else 0.0

def main():
    conn=sqlite3.connect(DB); c=conn.cursor()
    # 내용 보유 MT 버전만
    mt=[r[0] for r in c.execute("SELECT version_code FROM bible_version WHERE versification_system='MT'")]
    content=[]
    print("=== MT 버전 본문 보유 현황 ===")
    for v in sorted(mt):
        n=c.execute("SELECT COUNT(*) FROM bible_content WHERE version_code=? AND verse_text IS NOT NULL AND TRIM(verse_text)!=''",(v,)).fetchone()[0]
        print(f"  {v:8} {n}")
        if n>0: content.append(v)
    if 'KJV' not in content:
        print("KJV 없음 — 기준 불가"); return
    print(f"\n내용 보유 MT 버전 {len(content)}개: {content}")

    print("\n=== 시편 표제 밀림(+1) 검사 [언어 독립: 절 길이-상관] ===")
    result={v:[] for v in content}
    for ch in range(1,151):
        vids=[r[0] for r in c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse",(PSA_BCODE,ch))]
        if len(vids)<5: continue
        L={}
        for ver in content:
            vec=[]
            for vid in vids:
                t=c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?",(vid,ver)).fetchone()
                vec.append(len(t[0]) if t and t[0] else 0)
            L[ver]=vec
        base=L['KJV']
        for ver in content:
            v=L[ver]
            if sum(1 for x in v if x>0)<5: continue
            c0=corr(v,base); cs=corr(v[1:],base[:-1])
            # ① 길이-상관: 정렬(offset0) 상관이 낮고 밀림(offset+1) 상관이 높음
            # ② 결정적 구별자: v1이 '표제만'이라 비정상적으로 짧음(뒤 절들 중앙값보다 작음).
            #    표제를 v1에 '합친' 버전은 v1=표제+본문이라 길어서 여기서 걸러짐(오탐 제거).
            body=[x for x in v[1:] if x>0]
            med=sorted(body)[len(body)//2] if body else 0
            v1_title_only = v[0]>0 and med>0 and v[0] < 0.9*med
            if c0<0.45 and cs>0.7 and v1_title_only:
                result[ver].append(ch)
    print("  [버전별 실제 밀린 시편 수]")
    for ver in content:
        mark = '  <<< 밀림(재정렬 필요)' if result[ver] else '  정렬 OK'
        print(f"    {ver:8} {len(result[ver]):3}편{mark}")
    for ver in content:
        if result[ver]:
            print(f"\n  {ver} 밀린 시편 장: {result[ver]}")

    print("\n=== 요약 ===")
    bad=[v for v in content if result[v]]
    if not bad:
        print("  모든 내용 버전이 영어/KJV 표준에 정렬됨.")
    else:
        print(f"  재정렬 필요: {bad}")
        print("  → 해당 버전은 표제를 별도 v1로 둔 히브리/대륙식 번호 → 우리 영어축과 +1 어긋남.")
        print("  → 설명문(clicked_id=verse_id)은 영어축(KRV/BSB) 기준이라 이 버전 독자에겐 한 절 밀려 보임.")

if __name__=='__main__':
    main()
