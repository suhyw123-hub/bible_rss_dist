# -*- coding: utf-8 -*-
"""찬양 패널 — **곡 → 판 → 영상 세 층**을 한 트리로 (2026-09-09 신설).

★★★ **왜 부품 하나인가** — 같은 것을 P2(구절 축)와 주요용어(용어 축)가 함께
  보인다. 화면마다 지으면 층·표기·정렬이 갈린다(§95차 「같은 것을 두 문이
  다르게 답한다」).

★★★ **평평한 목록이 아니라 층이다** (2026-09-09 사용자 지적 — 「현재 구조대로는
  **수백건 수천건이 표시되는 문제**」). 실측 — 곡 19개에 영상 **306편**이다.
  평평하게 늘어놓으면 306줄이고, 층으로 접으면 **19줄**이다.

⚠ **플레이어를 여기서 또 만들지 않는다** — 인라인 재생은 별도 프로세스를
  띄운다(§30). 호스트가 `on_play` 를 주면 그것을 쓰고, 없으면 브라우저로 연다.
⚠ **비면 아무것도 안 그린다** — `load_*` 가 0 을 내면 호스트가 갈래를 감춘다
  (§0-1 빈 서랍 금지).
"""
import tkinter as tk
from tkinter import ttk
import webbrowser

import appdb
import i18n

try:
    import ui_theme
except Exception:
    ui_theme = None
try:
    import theme_font
except Exception:
    theme_font = None


def _c(role, dflt):
    try:
        return ui_theme.C(role)
    except Exception:
        return dflt


def _views_label(n):
    """조회수 — 사람이 읽는 자리. ⚠ 모르면 **빈 글자**(0 으로 짓지 않는다)."""
    if not n:
        return ''
    n = int(n)
    if n >= 100000000:
        return '%.1f억' % (n / 100000000.0)
    if n >= 10000:
        return '%.1f만' % (n / 10000.0)
    return '{:,}'.format(n)


class SongPanel(ttk.Frame):
    """곡 → 판 → 영상. `load_verse` / `load_entity` 가 채운다."""

    def __init__(self, parent, db_path, lang_getter=None, on_play=None,
                 on_song=None):
        """`on_song(song_id)` — **곡 줄을 두 번 누르면** 부른다(2026-09-17 사용자
        「클릭하면 어차피 P4 온라인 영상 탭에서 표시해야 한다 … 가장 대표적인 영상을
        자동 플레이」). 안 주면 지금처럼 그 자리에서 펼치기만 한다."""
        super().__init__(parent)
        self.db_path = db_path
        self._lang = lang_getter or (lambda: 'KO')
        self._on_play = on_play
        self._on_song = on_song
        self._url = {}          # iid → url
        self._loaded = set()    # 이미 펼쳐 채운 마디
        self._n = 0
        self._build()

    # ── 화면 ────────────────────────────────────────────────────────────
    def _build(self):
        wrap = ttk.Frame(self)
        wrap.pack(fill='both', expand=True)
        self.tv = ttk.Treeview(wrap, columns=('meta',), show='tree headings',
                               selectmode='browse')
        self.tv.heading('#0', text=i18n.t('SP_COL_NAME', '찬양'))
        self.tv.heading('meta', text=i18n.t('SP_COL_META', '정보'))
        self.tv.column('#0', width=300, stretch=True)
        self.tv.column('meta', width=190, stretch=False, anchor='w')
        sb = ttk.Scrollbar(wrap, orient='vertical', command=self.tv.yview)
        self.tv.configure(yscrollcommand=sb.set)
        self.tv.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')
        self.tv.bind('<<TreeviewOpen>>', self._on_open)
        self.tv.bind('<Double-1>', self._on_dbl)
        # ★ 목록 표준서식 — 글꼴·행높이를 여기서 박지 않는다(§theme_font)
        if theme_font is not None:
            try:
                theme_font.list_style('SongPanel.Treeview', self.db_path)
                self.tv.configure(style='SongPanel.Treeview')
            except Exception:
                pass
        self._retag()

    def _retag(self):
        """★ Treeview 태그 색은 `paint` 가 못 본다 — 그릴 때마다 역할로 다시."""
        try:
            self.tv.tag_configure('song', foreground=_c('fg_title', '#1A3A5C'))
            self.tv.tag_configure('rend', foreground=_c('fg', '#000000'))
            self.tv.tag_configure('media', foreground=_c('fg_dim', '#5D6D7E'))
        except Exception:
            pass

    def apply_font(self):
        if theme_font is not None:
            try:
                theme_font.list_style('SongPanel.Treeview', self.db_path)
            except Exception:
                pass
        self._retag()

    def _db(self):
        return appdb.connect(self.db_path)

    # ── 채우기 ──────────────────────────────────────────────────────────
    def count(self):
        return self._n

    def load_verse(self, verse_id):
        """그 구절의 곡 → 곡 수."""
        import db_song as S
        return self._load(lambda c, lg: S.songs_of_verse(c, verse_id, lg))

    #: 공통 로드 경로(`_ensure_p2_tab_built` 등)가 부르는 이름 — 구절 축이 기본이다
    load = load_verse

    def load_entity(self, entity_id):
        """그 용어의 곡 → 곡 수."""
        import db_song as S
        return self._load(lambda c, lg: S.songs_of_entity(c, entity_id, lg))

    def load_song(self, song_id, expand=True):
        """**곡 하나**만 펴서 보인다 → 곡 수(0 또는 1). 2026-09-17 사용자
        「왼쪽 패널에 클릭한 곡의 곡/판/영상 목록을 모두 표시」.

        ⚠ 펼치는 것까지 여기서 한다 — 목록만 내고 접힌 채 두면 「모두 표시」가 아니다.
        """
        import db_song as S
        # ⚠ `songs_brief` 는 **여섯 칸**(닻갈래·닻이름까지)을 낸다 — `_load` 가 받는
        #   네 칸으로 줄여서 넘긴다(그냥 넘기면 「too many values to unpack」).
        n = self._load(lambda c, lg: [(a, b, cc, d)
                                      for a, b, cc, d, *_r
                                      in S.songs_brief(c, lg, '', 500)])
        keep = 'S%d' % int(song_id)
        for iid in list(self.tv.get_children('')):
            if iid != keep:
                self.tv.delete(iid)
        self._n = 1 if self.tv.exists(keep) else 0
        if self._n and expand:
            # ⚠ `_on_open` 은 **포커스가 있는 줄**을 채운다 — 줄마다 포커스를 옮겨야
            #   한다(그냥 open 만 주면 「…」 자리가 그대로 남는다).
            try:
                self.tv.item(keep, open=True)
                self.tv.focus(keep)
                self._on_open()
                for r in list(self.tv.get_children(keep)):
                    self.tv.item(r, open=True)
                    self.tv.focus(r)
                    self._on_open()
                self.tv.selection_set(keep)
                self.tv.focus(keep)
            except Exception:
                pass
        return self._n

    def clear(self):
        self.tv.delete(*self.tv.get_children())
        self._url = {}
        self._loaded = set()
        self._n = 0

    def _load(self, fetch):
        self.clear()
        lg = (self._lang() or 'KO').upper()
        try:
            conn = self._db()
            rows = fetch(conn, lg)
            conn.close()
        except Exception:
            rows = []
        for sid, nm, n_r, n_m in rows:
            meta = i18n.t('SP_META_SONG', '판 %d · 영상 %d') % (n_r, n_m)
            iid = 'S%d' % sid
            self.tv.insert('', 'end', iid=iid, text=nm or ('#%d' % sid),
                           values=(meta,), tags=('song',))
            if n_r:
                self.tv.insert(iid, 'end', iid=iid + '_x', text='…')
        self._n = len(rows)
        self._retag()
        return self._n

    # ── 펼치면 그때 채운다 (§29 지연) ───────────────────────────────────
    def _on_open(self, _e=None):
        iid = self.tv.focus()
        if not iid or iid in self._loaded:
            return
        self._loaded.add(iid)
        for ch in self.tv.get_children(iid):
            if ch.endswith('_x'):
                self.tv.delete(ch)
        try:
            conn = self._db()
            if iid.startswith('S'):
                self._fill_rends(conn, iid, int(iid[1:]))
            elif iid.startswith('R'):
                self._fill_media(conn, iid, int(iid[1:]))
            conn.close()
        except Exception:
            pass
        self._retag()

    def _fill_rends(self, conn, parent, song_id):
        import db_song as S
        lg = (self._lang() or 'KO').upper()
        for rid, title, lang, artist, is_orig, is_off, n_m in S.rends_of(
                conn, song_id, lg):
            bits = []
            if artist:
                bits.append(artist)
            # ⚠⚠ **사용자에게 「원곡」을 말하지 않는다**(2026-09-11 사용자
            #   「사용자에게는 **원곡 대표곡 표현을 할 필요 없다**」).
            #   ★ 그 값은 **안쪽 값**이다 — 구절·주제를 어느 영상에서 뽑을지
            #     정하는 잣대이지 사용자가 알 일이 아니다. 게다가 실측 20곡 중
            #     6곡이 근거 없이 짐작한 값이라 **틀린 배지가 나갈 자리**였다.
            if is_off:
                bits.append(i18n.t('SP_OFFICIAL', '공식'))
            if n_m:
                bits.append(i18n.t('SP_N_MEDIA', '영상 %d') % n_m)
            nm = title or ''
            if lang:
                nm = '%s  [%s]' % (nm, lang)
            iid = 'R%d' % rid
            self.tv.insert(parent, 'end', iid=iid, text=nm,
                           values=(' · '.join(bits),), tags=('rend',))
            if n_m:
                self.tv.insert(iid, 'end', iid=iid + '_x', text='…')

    def _fill_media(self, conn, parent, rend_id):
        import db_song as S
        import media_taxonomy as tax
        for mid, ti, kinds, views in S.media_of(conn, rend_id):
            bits = []
            lab = ''
            try:
                lab = tax.rend_label(kinds)
            except Exception:
                pass
            if lab:
                bits.append(lab)
            v = _views_label(views)
            if v:
                bits.append(v)
            iid = '%s.M%d' % (parent, mid)
            self.tv.insert(parent, 'end', iid=iid, text=ti or ('#%d' % mid),
                           values=(' · '.join(bits),), tags=('media',))
            # ⚠ 화면이 `sys_media_asset` 을 직접 묻지 않는다 — 주소를 찾는
            #   단일 문이 `media_link.asset_url` 이다(§121차 · 덮개 검사기가
            #   그 직접 읽기를 센다).
            try:
                import media_link
                u, _t = media_link.asset_url(conn, mid)
                if u:
                    self._url[iid] = u
            except Exception:
                pass

    # ── 클릭 ────────────────────────────────────────────────────────────
    def _on_dbl(self, _e=None):
        iid = self.tv.focus()
        if not iid:
            return
        url = self._url.get(iid)
        if not url:
            # ★ **곡 줄은 온라인 영상 탭으로 보낸다**(2026-09-17) — 거기서 곡·판·영상을
            #   모두 보이고 대표를 자동으로 튼다. 받는 쪽이 없으면 그냥 펼친다.
            if iid.startswith('S') and self._on_song:
                try:
                    self._on_song(int(iid[1:].split('_')[0]))
                    return
                except Exception:
                    pass
            # 곡·판 줄은 펼친다(눌러도 아무 일이 없으면 고장으로 읽힌다)
            try:
                self.tv.item(iid, open=not self.tv.item(iid, 'open'))
                self._on_open()
            except Exception:
                pass
            return
        title = self.tv.item(iid, 'text')
        if self._on_play:
            try:
                self._on_play(url, title)
                return
            except Exception:
                pass
        try:
            webbrowser.open(url)
        except Exception:
            pass


# ── selftest ────────────────────────────────────────────────────────────────

def selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % name)
        else:
            fail += 1
            print('  FAIL %s' % name)

    t('조회수 — 모르면 빈 글자', _views_label(None) == ''
      and _views_label(0) == '')
    t('조회수 — 만 단위', _views_label(12345).endswith('만'))
    t('조회수 — 억 단위', _views_label(123456789).endswith('억'))
    t('조회수 — 작으면 그대로', _views_label(999) == '999')

    import io as _io
    src = _io.open('song_panel.py', encoding='utf-8').read()
    t('★ 플레이어를 여기서 안 만든다', 'media_' + 'player' not in src)
    t('★ 색을 박지 않는다(역할로)', src.count('_c(') >= 3)
    # ⚠ 찾는 글자를 그대로 적으면 **검사 코드 자신이 걸린다**(§199차) — 조립한다
    t('★ 화면이 sys 를 직접 안 읽는다(asset_url 위임)',
      ('FROM ' + 'sys_') not in src and 'asset_url' in src)
    t('목록 표준서식을 쓴다', 'list_style' in src)
    t('세 층을 다 그린다',
      '_fill_rends' in src and '_fill_media' in src)
    t('비면 0 을 낸다(호스트가 갈래를 감춘다)', 'return self._n' in src)

    # 실 DB 왕복 — 곡이 있는 구절에서 실제로 채워지는가
    try:
        import db_song as S
        c = appdb.connect('bible_master.db')
        pairs = S.song_verses(c)
        if pairs:
            got = S.songs_of_verse(c, pairs[0][1], 'KO')
            t('실 DB — 곡이 걸린 절에서 곡이 나온다', len(got) >= 1)
            if got:
                rd = S.rends_of(c, got[0][0], 'KO')
                t('실 DB — 그 곡에 판이 있다', len(rd) >= 1)
                t('실 DB — 그 판에 영상이 있다',
                  bool(rd) and len(S.media_of(c, rd[0][0])) >= 1)
            else:
                t('실 DB — 판/영상 (건너뜀)', True)
        else:
            t('실 DB — 곡↔구절 연결이 아직 없다(건너뜀)', True)
        c.close()
    except Exception as e:
        t('실 DB 왕복 (%s)' % e, False)

    print('song_panel selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('use --selftest')
