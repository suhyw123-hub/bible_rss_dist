# -*- coding: utf-8 -*-
"""db_claim_audit.py — 본문 밖 사실 주장 검출·대조 (영구 도구, 읽기 전용)

  python -X utf8 db_claim_audit.py --selftest                    # 탐지력 확인(의무)
  python -X utf8 db_claim_audit.py --count                       # 규모만
  python -X utf8 db_claim_audit.py --book 44                     # 대조표
  python -X utf8 db_claim_audit.py --book 44 --hard              # 강한 주장만
  python -X utf8 db_claim_audit.py --peri 7851                   # 한 건 자세히

**왜 필요한가 (2026-08-03, 사용자 지시).** 행 23:1 에 *"그 시대 기록에 아나니아는
재물을 탐하고 폭력을 서슴지 않던 사람으로 남아 있으니"* 라고 썼는데 주석 DB 어디에도
그런 말이 없었다. **파라미터에서 나온 말을 출처가 있는 것처럼 단언한 것**이다.
사용자 판정: *"매우 심각한 오류다. 반드시 기억이 아니라 자료에 근거해서 확인한 것만
기록하라."*

문체 게이트(`db_peri_gate`)는 **어떻게 썼는가**만 본다. 사실이 맞는지는 재지 않는다.
이 도구가 그 빈칸을 메우되, **판정하지는 못한다** — 한국어 설명문과 영어 주석을
기계가 대조할 수 없기 때문이다. 하는 일은 셋이다.

  ① 본문 밖 사실을 주장하는 문장을 뽑는다
  ② 그 페리코프 범위의 주석 원문을 **바로 옆에 붙인다**(사람이 한 번 읽으면 끝나게)
  ③ **숫자는 언어를 넘으므로 자동 대조한다** (사백칠십 -> 470 -> commentary 검색)

사람이 판단하는 시간을 줄이는 것이 목적이지 사람을 대신하는 것이 아니다.
근거를 못 찾으면 빼거나 본문이 받쳐 주는 것으로 바꾼다(peri.md §3-3b).
"""
import argparse
import re
import sys

import appdb

DB = 'bible_master.db'

# ── 강한 주장 — 출처가 있다고 명시하거나 암시한다 ──────────────────────────
HARD = (
    # ⚠ 오탐 주의(2026-08-03 첫 실행에서 6건). `역사가` 는 `오용된 역사가 있으나` 의
    #   명사+조사에도 걸린다 → `한 역사가`·`역사가 적` 처럼 사람을 가리킬 때만.
    ('출처명시', re.compile(r'(그 시대 기록|당시 기록|기록에 [^ ]{0,6}남아|'
                            r'(한|그|로마|유대) 역사가|역사가 (적|전|남)|'
                            r'문헌|비문|요세푸스|미쉬나|탈무드|필론)')),
    # ⚠ `전해집니다` 가 **`온전해집니다` 안에** 들어 있다. 앞 글자로 갈라낸다.
    #   `잘못 전해집니다`(=전달되다)·`전해지는 통로`(=전달 경로) 도 출처 주장이 아니다.
    ('전문', re.compile(r'((?<![온완])전해집니다|전해 옵니다|(?<![온완])전해 오는|'
                        r'알려져 있습니다|알려진 바|이름이 나 있|유명했)')),
)
# ── 약한 주장 — 그 시대를 단정하되 출처를 밝히지 않는다 ───────────────────
SOFT = (
    ('시대단정', re.compile(r'(그 시대(는|에는|의|를)|당시(에는|의|를)|그 무렵|그 시절|그때는)')),
    ('관습주장', re.compile(r'(관습이었|관습으로|풍습|하던 일이었|여기던|여겼습니다|여겨졌|'
                            r'불리던|보통이었|흔했|흔한 일|~라 불렀|이라 불렀)')),
    ('제도주장', re.compile(r'(로마법|로마의 법|법으로 금|금했습니다|금했고|허락했습니다|'
                            r'규정이었|정해져 있었|의무였|처형하도록)')),
)
SENT = re.compile(r'[^.!?]*[.!?]')
NUMWORD = re.compile(r'[일이삼사오육칠팔구십백천만]{2,}|\d[\d,]*')
_DIG = {'일': 1, '이': 2, '삼': 3, '사': 4, '오': 5, '육': 6, '칠': 7, '팔': 8, '구': 9}
_SML = {'십': 10, '백': 100, '천': 1000}


def ko_number(s):
    """`사백칠십`→470 · `이만오천`→25000 · `오만`→50000. 못 읽으면 None."""
    if re.fullmatch(r'\d[\d,]*', s):
        return int(s.replace(',', ''))
    total = section = cur = 0
    for ch in s:
        if ch in _DIG:
            cur = _DIG[ch]
        elif ch in _SML:
            section += (cur or 1) * _SML[ch]
            cur = 0
        elif ch == '만':
            total += ((section + cur) or 1) * 10000
            section = cur = 0
        else:
            return None
    return (total + section + cur) or None


def en_forms(n):
    """그 수가 영어 주석에 나타날 만한 형태들."""
    out = {str(n), f'{n:,}'}
    words = {1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five', 6: 'six', 7: 'seven',
             8: 'eight', 9: 'nine', 10: 'ten', 12: 'twelve', 20: 'twenty', 30: 'thirty',
             40: 'forty', 50: 'fifty', 70: 'seventy', 100: 'hundred', 200: 'two hundred',
             400: 'four hundred', 470: 'four hundred and seventy',
             1000: 'thousand', 20000: 'twenty thousand', 25000: 'twenty-five thousand',
             30000: 'thirty thousand', 50000: 'fifty thousand'}
    if n in words:
        out.add(words[n])
    return out


# ── 자료 ────────────────────────────────────────────────────────────────────
COMM = ('BARNES_NT', 'CLARKE', 'JFB', 'HENRY_MHC', 'PULPIT_COM')


def peris(conn, bcode, pid=None):
    q = """SELECT p.pericope_id, p.start_vid, p.end_vid, bi.bcode, bi.chapter, bi.verse,
                  t.contents
             FROM sys_pericope_asset p
             JOIN bible_index bi ON bi.verse_id = p.start_vid
             JOIN sys_text_asset t ON t.clicked_id = p.pericope_id
                  AND t.text_type='PERI_DESC' AND t.lang_code='KO'
                  AND COALESCE(t.record_status,'LIVE')='LIVE'
            WHERE p.peri_type='BODY'"""
    a = []
    if pid:
        q += ' AND p.pericope_id=?'; a.append(pid)
    elif bcode:
        q += ' AND bi.bcode=?'; a.append(bcode)
    return conn.execute(q + ' ORDER BY p.start_vid', a).fetchall()


def commentary(conn, sv, ev):
    """그 범위를 덮는 주석 원문 전부를 한 덩어리로."""
    out = []
    for code in COMM:
        for (body,) in conn.execute(
                """SELECT x.body_text FROM sys_commentary_entry e
                     JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
                     JOIN sys_commentary_text  x ON x.entry_id=e.entry_id
                    WHERE s.commentary_code=? AND x.text_variant='ORIGINAL'
                      AND ((e.start_vid BETWEEN ? AND ?)
                           OR (e.start_vid <= ? AND COALESCE(e.end_vid,e.start_vid) >= ?))""",
                (code, sv, ev, sv, sv)):
            if body:
                out.append((code, ' '.join(body.split())))
    return out


def claims(txt, hard_only=False):
    """(등급, 종류, 문장) 목록."""
    found = []
    for m in SENT.finditer(txt or ''):
        s = m.group(0).strip()
        if not s:
            continue
        for kind, pat in HARD:
            if pat.search(s):
                found.append(('HARD', kind, s)); break
        else:
            if hard_only:
                continue
            for kind, pat in SOFT:
                if pat.search(s):
                    found.append(('SOFT', kind, s)); break
    return found


def num_check(sent, comm_text):
    """문장 속 수치가 주석 원문에 나타나는지. (수, 찾음여부) 목록."""
    out = []
    for w in NUMWORD.findall(sent):
        n = ko_number(w)
        if not n or n < 10:
            continue
        hit = any(f.lower() in comm_text for f in en_forms(n))
        out.append((w, n, hit))
    return out


def run(conn, bcode, pid, hard_only, show_comm, limit):
    rows = peris(conn, bcode, pid)
    tot_p = tot_c = 0
    for p, sv, ev, bc, ch, vs, txt in rows:
        cl = claims(txt, hard_only)
        if not cl:
            continue
        tot_p += 1
        tot_c += len(cl)
        cm = commentary(conn, sv, ev)
        blob = ' '.join(t for _c, t in cm).lower()
        print(f'\n{"="*74}')
        print(f'peri {p}  {bc} {ch}:{vs}  — 주장 {len(cl)}건 · 주석 {len(cm)}항목')
        for grade, kind, s in cl:
            print(f'  [{grade}/{kind}] {s[:150]}')
            for w, n, hit in num_check(s, blob):
                print(f'      수치 {w}({n}) — 주석에서 {"찾음 ✅" if hit else "못 찾음 ⚠"}')
        if show_comm and cm:
            print('  ── 그 범위 주석(대조용) ' + '─' * 40)
            for code, t in cm[:4]:
                print(f'  [{code}] {t[:700]}')
        if limit and tot_p >= limit:
            print(f'\n(--limit {limit} 도달)')
            break
    print(f'\n{"="*74}')
    print(f'페리코프 {len(rows)}개 중 {tot_p}개에서 주장 {tot_c}건')


def count(conn):
    print('=== 본문 밖 사실 주장 규모 (PERI_DESC KO) ===')
    print(f'{"책":<12}{"페리코프":>8}{"HARD":>7}{"SOFT":>7}{"주장있는 peri":>14}')
    names = dict(conn.execute("SELECT book_code, full_name FROM book_names "
                              "WHERE lang_code='KO'"))
    g_h = g_s = g_p = g_n = 0
    for (bc,) in conn.execute("""SELECT DISTINCT bi.bcode FROM sys_pericope_asset p
            JOIN bible_index bi ON bi.verse_id=p.start_vid
            JOIN sys_text_asset t ON t.clicked_id=p.pericope_id AND t.text_type='PERI_DESC'
           WHERE p.peri_type='BODY' ORDER BY bi.bcode"""):
        rows = peris(conn, bc)
        h = s = np = 0
        for p, sv, ev, _b, _c, _v, txt in rows:
            cl = claims(txt)
            if cl:
                np += 1
            h += sum(1 for g, _k, _t in cl if g == 'HARD')
            s += sum(1 for g, _k, _t in cl if g == 'SOFT')
        if not rows:
            continue
        g_h += h; g_s += s; g_p += np; g_n += len(rows)
        print(f'{names.get(bc, bc):<12}{len(rows):>8}{h:>7}{s:>7}{np:>14}')
    print(f'{"합계":<12}{g_n:>8}{g_h:>7}{g_s:>7}{g_p:>14}')


def selftest(conn):
    cases = [
        ('HARD', '그 시대 기록에 그는 재물을 탐하던 사람으로 남아 있습니다.'),
        ('HARD', '왕의 옷은 은실로 짜여 번쩍였다고 전해집니다.'),
        ('HARD', '요세푸스가 이 일을 적어 두었습니다.'),
        ('SOFT', '그 시대는 고난을 죄와 곧장 이어서 이해했습니다.'),
        ('SOFT', '안식일에 반죽하는 일은 금했습니다.'),
        ('SOFT', '남의 서원 비용을 대는 것은 경건한 일로 여겨졌습니다.'),
    ]
    ok = True
    for want, s in cases:
        got = claims(s)
        hit = bool(got) and got[0][0] == want
        print(f'  [{"PASS" if hit else "FAIL"}] {want} 탐지 — {s[:40]}')
        ok = ok and hit
    clean = '베드로가 세 번 물음을 받고 세 번 일을 맡습니다. 그러고는 나를 따르라 하십니다.'
    got = claims(clean)
    print(f'  [{"PASS" if not got else "FAIL"}] 본문 서술 오탐 없음 {got or ""}')
    ok = ok and not got
    for s, want in (('사백칠십', 470), ('이만', 20000), ('오만', 50000),
                    ('이만오천', 25000), ('사십', 40)):
        got = ko_number(s)
        print(f'  [{"PASS" if got == want else "FAIL"}] 수사 {s} -> {got} (기대 {want})')
        ok = ok and got == want
    return ok


def find(conn, bcode, terms, width=520):
    """책 전체 주석에서 낱말을 찾아 앞뒤와 함께 보여 준다.

    **왜 필요한가 (2026-08-03).** `가시채를 뒷발질` 이 헬라 속담이라는 배경을 찾다가
    `comm_44_26.md` 에 26:14 항목이 없어 **근거 없음으로 판단하고 지웠다.** 그런데
    자료는 있었다 — 같은 사건을 처음 전한 **9:5** 에 BARNES 가 에우리피데스·핀다로스·
    테렌티우스·오비디우스를 인용해 두었고 JFB 는 `the metaphor ... is a classic one`
    이라고 적어 두었다. `--comm` 이 페리코프 범위만 긁으므로 **평행 본문에 있는 자료를
    통째로 놓친다.** 사도행전은 회심을 9·22·26장 세 번 전하므로 특히 그렇다.

    ⇒ 근거를 못 찾았을 때 **지우기 전에 이것부터 돌린다.** 범위를 책 전체로 넓힌다.
    """
    lo, hi = conn.execute('SELECT MIN(verse_id), MAX(verse_id) FROM bible_index '
                          'WHERE bcode=?', (bcode,)).fetchone()
    pat = re.compile('|'.join(terms), re.I)
    n = 0
    for code, sv, body in conn.execute(
            """SELECT s.commentary_code, e.start_vid, x.body_text
                 FROM sys_commentary_entry e
                 JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
                 JOIN sys_commentary_text  x ON x.entry_id=e.entry_id
                WHERE x.text_variant='ORIGINAL' AND e.start_vid BETWEEN ? AND ?""",
            (lo, hi)):
        t = ' '.join((body or '').split())
        m = pat.search(t)
        if not m:
            continue
        r = conn.execute('SELECT chapter, verse FROM bible_index WHERE verse_id=?',
                         (sv,)).fetchone()
        a = max(0, m.start() - 150)
        print(f'\n[{code} {r[0]}:{r[1]}] …{t[a:m.end() + width]}…')
        n += 1
    print(f'\n{"="*74}\n찾음 {n}건 (bcode {bcode} 전체 주석)')
    if not n:
        print('  ⚠ 책 전체에도 없다. 이제야 "근거 없음" 이라 할 수 있다.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int)
    ap.add_argument('--peri', type=int)
    ap.add_argument('--find', nargs='+', metavar='TERM',
                    help='책 전체 주석에서 낱말 검색 (--book 필요). 지우기 전에 이것부터.')
    ap.add_argument('--hard', action='store_true', help='강한 주장만')
    ap.add_argument('--comm', action='store_true', help='주석 원문도 함께 출력')
    ap.add_argument('--limit', type=int, default=0)
    ap.add_argument('--count', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect(DB)
    if a.selftest:
        print('=== 자가 탐지력 ===')
        sys.exit(0 if selftest(conn) else 1)
    if a.find:
        if not a.book:
            ap.error('--find 는 --book 이 필요하다')
        find(conn, a.book, a.find); return
    if a.count:
        count(conn); return
    if not (a.book or a.peri):
        ap.error('--book 또는 --peri 또는 --count 가 필요하다')
    run(conn, a.book, a.peri, a.hard, a.comm or bool(a.peri), a.limit)


if __name__ == '__main__':
    main()
