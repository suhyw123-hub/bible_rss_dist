# -*- coding: utf-8 -*-
"""
[Phase 2-G Step 5] 엔티티 외부 사이트 URL 자동 생성 + HEAD 일괄 검증.

기능:
  - generate_urls_for_site(site_id, overwrite=False) — 모든 LIVE 엔티티 × 사이트 → URL UPSERT
  - verify_urls_batch(limit=50, site_id=None) — http_status 미확인 URL HEAD 검증
  - normalize_for_url(name, rule) — name 정규화 (snake_case / lowercase / as_is)

CLI:
  python db_entity_url_generate.py generate [site_id]   # 사이트별 URL 생성 (없으면 전체)
  python db_entity_url_generate.py verify [N]           # N개 HEAD 검증 (기본 50)
  python db_entity_url_generate.py status               # 사이트별 진척 보고
"""
import sqlite3
import sys
import time
import json
import urllib.request
import urllib.error
from urllib.parse import quote, urlsplit, urlunsplit
from datetime import datetime

DB = 'bible_master.db'

USER_AGENT = 'Mozilla/5.0 (compatible; BibleMatrix/1.0; +https://github.com)'
REQUEST_TIMEOUT = 8  # seconds
SLEEP_BETWEEN = 0.4  # seconds — rate limit


# ── 정규화 ────────────────────────────────────────────────────────────────

def normalize_for_url(name: str, rule: str = 'snake_case') -> str:
    """name → URL-safe 변환."""
    if not name:
        return ''
    n = name.strip()
    if rule == 'snake_case':
        return n.replace(' ', '_')
    if rule == 'lowercase':
        return n.lower()
    if rule == 'lower_snake':
        return n.lower().replace(' ', '_')
    if rule == 'as_is':
        return n
    return n.replace(' ', '_')


def build_url(template: str, name_en: str, name_ko: str, aliases: dict,
                site_code: str, site_lang: str = 'EN') -> tuple[str, str]:
    """URL + alias_used 반환.

    placeholder:
      {alias}    — site_aliases[site_code] (json_detail).
                   없으면 site_lang='KO'면 name_ko, 아니면 name_en 정규화.
      {name_en}  — entity name (영문)
      {name_lc}  — name_en lowercase
      {name_us}  — name_en 공백→underscore
      {first_lc} — name_en 첫 글자 lowercase
      {first_us} — name_en 첫 글자 uppercase
      {name_ko}  — entity name (한국어)

    site_lang 'KO'이면 alias fallback이 한글 ENTITY_NAME(KO)을 사용 — Wikipedia(한국어)
    같이 영문 URL이 동음이의로 자동 redirect되는 문제 방지.

    반환: (url, alias_used). alias_used가 빈 문자열이면 적절한 매핑 없음 (호출자가 skip 가능).
    """
    explicit_alias = (aliases or {}).get(site_code) or (aliases or {}).get('default') or ''
    # alias fallback — site_lang에 따라 한글/영문
    if explicit_alias:
        alias = explicit_alias
        used_alias = alias
    elif site_lang == 'KO' and name_ko:
        alias = name_ko
        used_alias = name_ko
    elif name_en:
        alias = name_en.replace(' ', '_')
        used_alias = alias
    else:
        alias = ''
        used_alias = ''
    base = alias or name_en
    first = (base or 'x')[:1]
    url = (template
            .replace('{alias}',    alias)
            .replace('{name_en}',  name_en)
            .replace('{name_lc}',  name_en.lower())
            .replace('{name_us}',  name_en.replace(' ', '_'))
            .replace('{first_lc}', first.lower())
            .replace('{first_us}', first.upper())
            .replace('{name_ko}',  name_ko or ''))
    return url, used_alias


# ── 엔티티 정보 조회 ──────────────────────────────────────────────────────

def _fetch_entities(conn) -> list[dict]:
    """LIVE 엔티티 목록 + ENTITY_NAME(EN, KO) + json_detail.site_aliases + json_detail.aliases.

    반환 dict:
      'aliases'       : site_aliases (URL용, 사이트별 매핑) — 기존
      'name_aliases'  : json_detail.aliases (검색용 별명, 언어별 배열) — 신규
                         예: {"EN": ["Remphan", "Chiun"], "KO": ["자캐오"]}
    """
    rows = conn.execute("""
        SELECT em.entity_id, em.entity_code, em.json_detail,
               (SELECT contents FROM sys_text_asset
                  WHERE text_type='ENTITY_NAME' AND clicked_id=em.entity_id
                    AND lang_code='EN' AND record_status='LIVE' LIMIT 1) AS name_en,
               (SELECT contents FROM sys_text_asset
                  WHERE text_type='ENTITY_NAME' AND clicked_id=em.entity_id
                    AND lang_code='KO' AND record_status='LIVE' LIMIT 1) AS name_ko
          FROM sys_entity_master em
         WHERE em.record_status='LIVE'
      ORDER BY em.entity_id
    """).fetchall()
    out = []
    for eid, ecode, jd_raw, n_en, n_ko in rows:
        site_aliases = {}
        name_aliases = {}
        if jd_raw:
            try:
                jd = json.loads(jd_raw)
                if isinstance(jd, dict):
                    site_aliases = jd.get('site_aliases', {}) or {}
                    name_aliases = jd.get('aliases', {}) or {}
            except Exception:
                pass
        # name_en fallback: entity_code에서 prefix 제거 (P_DAVID → David)
        if not n_en:
            n_en = ecode.split('_', 1)[-1].title() if ecode else ''
        out.append({
            'entity_id': eid,
            'entity_code': ecode,
            'name_en': n_en or '',
            'name_ko': n_ko or '',
            'aliases': site_aliases,        # URL 생성용 (사이트별)
            'name_aliases': name_aliases,   # 검색용 별명 (언어별 배열)
        })
    return out


# ── URL 생성 ──────────────────────────────────────────────────────────────

def generate_urls_for_site(site_id: int, overwrite: bool = False,
                            only_dead: bool = False) -> dict:
    """한 사이트의 LIVE 엔티티 URL 생성·UPSERT.

    site_lang='KO' 사이트는 한글 ENTITY_NAME(KO) 자동 fallback (영문 redirect 방지).

    only_dead=True: 기존 행 중 is_active=0 OR http_status>=400 인 것만 UPDATE
                   (정상 URL은 건드리지 않음). 새 INSERT는 안 함. overwrite는 무관.

    반환: {'inserted': N, 'updated': N, 'skipped': N, 'missing_name': N}"""
    stats = {'inserted': 0, 'updated': 0, 'skipped': 0, 'missing_name': 0}
    conn = sqlite3.connect(DB)
    try:
        site_row = conn.execute(
            "SELECT site_code, url_template, scope, lang_code "
            "FROM sys_ref_site WHERE site_id=?",
            (site_id,)).fetchone()
        if not site_row:
            print(f'[err] site_id={site_id} not found')
            return stats
        site_code, template, scope, site_lang = site_row
        if scope != 'ENTITY':
            print(f'[err] site scope={scope} (expected ENTITY)')
            return stats
        site_lang = (site_lang or 'EN').upper()

        # only_dead 모드: 해당 entity_id 집합만 대상 (재생성 + 재검증 reset)
        # 단, map_status='MANUAL' 은 자동 보호 (수동편집 행은 자동생성에서 항상 제외)
        dead_eids = None
        if only_dead:
            rows = conn.execute(
                "SELECT entity_id FROM sys_ref_entity_url "
                "WHERE site_id=? "
                "  AND (is_active=0 OR http_status>=400) "
                "  AND COALESCE(map_status,'AUTO')='AUTO' "
                "  AND COALESCE(record_status,'LIVE')='LIVE'",
                (site_id,)).fetchall()
            dead_eids = {r[0] for r in rows}
            if not dead_eids:
                print(f'[only_dead] 오류 행 없음 (site_id={site_id})')
                return stats

        # MANUAL/EXCLUDED 자동 보호: 자동생성에서 항상 제외
        #   MANUAL   = 관리자 수동편집 (보존)
        #   EXCLUDED = 사이트에 정보 없음 (접속 제한 — 사용자 화면 미표시)
        protected_eids = {r[0] for r in conn.execute(
            "SELECT entity_id FROM sys_ref_entity_url "
            "WHERE site_id=? "
            "  AND COALESCE(map_status,'AUTO') IN ('MANUAL','EXCLUDED') "
            "  AND COALESCE(record_status,'LIVE')='LIVE'",
            (site_id,)).fetchall()}
        if protected_eids:
            print(f'[protect] MANUAL/EXCLUDED 행 {len(protected_eids)}개 자동 보호 — 자동생성 제외')

        entities = _fetch_entities(conn)
        c = conn.cursor()
        for e in entities:
            # MANUAL/EXCLUDED 보호: 자동생성에서 항상 제외
            if e['entity_id'] in protected_eids:
                stats['skipped'] += 1
                continue
            # only_dead: 오류 행 entity만
            if dead_eids is not None and e['entity_id'] not in dead_eids:
                continue
            if not e['name_en'] and not e['name_ko']:
                stats['missing_name'] += 1
                continue
            # KO 사이트인데 name_ko 없고 alias도 없으면 skip (영문 redirect 방지)
            if (site_lang == 'KO' and not e['name_ko']
                    and not (e['aliases'] or {}).get(site_code)):
                stats['missing_name'] += 1
                continue
            url, alias_used = build_url(template, e['name_en'], e['name_ko'],
                                          e['aliases'], site_code, site_lang)
            existing = c.execute(
                "SELECT rel_id, url FROM sys_ref_entity_url "
                "WHERE entity_id=? AND site_id=?",
                (e['entity_id'], site_id)).fetchone()
            if existing:
                # only_dead 또는 overwrite일 때만 UPDATE
                if not overwrite and not only_dead:
                    stats['skipped'] += 1
                    continue
                c.execute(
                    "UPDATE sys_ref_entity_url SET url=?, alias_used=?, "
                    "http_status=NULL, last_checked=NULL, is_active=0, "
                    "map_status='AUTO' "
                    "WHERE rel_id=?",
                    (url, alias_used, existing[0]))
                stats['updated'] += 1
            else:
                # only_dead 모드에서는 기존 행만 처리 (새 INSERT 안 함)
                if only_dead:
                    continue
                c.execute(
                    "INSERT INTO sys_ref_entity_url "
                    "(entity_id, site_id, url, alias_used, is_active, map_status) "
                    "VALUES (?, ?, ?, ?, 0, 'AUTO')",
                    (e['entity_id'], site_id, url, alias_used))
                stats['inserted'] += 1
        conn.commit()
    finally:
        conn.close()
    return stats


def build_url_candidates(template: str, name_en: str, name_ko: str,
                          name_aliases: dict, site_code: str,
                          site_lang: str = 'EN') -> list[tuple[str, str, str]]:
    """정식이름 + 별명 각각으로 URL 후보 목록 생성.

    name_aliases: {"EN": ["Remphan"], "KO": ["자캐오"]} 형식
    site_lang: 사이트 언어 → 어느 별명 배열을 시도할지 결정.

    반환: [(label, url, alias_used), ...]
      - 첫 항목은 항상 정식이름 (label='정식이름')
      - 이후 항목은 별명 (label='별명: <별명문자열>')
      - 중복 URL은 1회만 포함
    """
    out: list[tuple[str, str, str]] = []
    seen: set[str] = set()

    # 1) 정식이름 후보
    url1, alias1 = build_url(template, name_en, name_ko, {}, site_code, site_lang)
    primary_alias = alias1 or (name_ko if site_lang.upper() == 'KO' else name_en)
    if url1 and url1 not in seen:
        seen.add(url1)
        out.append(('정식이름', url1, primary_alias or ''))

    # 2) 별명 후보 (사이트 언어와 같은 언어의 별명만)
    lang_u = (site_lang or 'EN').upper()
    aliases_list = (name_aliases or {}).get(lang_u, []) or []
    for a in aliases_list:
        if not a:
            continue
        # build_url의 explicit_alias 경로 활용 (site_code 매핑으로 일회용 주입)
        fake_site_aliases = {site_code: a}
        url_a, _ = build_url(template, name_en, name_ko,
                              fake_site_aliases, site_code, site_lang)
        if url_a and url_a not in seen:
            seen.add(url_a)
            out.append((f'별명: {a}', url_a, a))

    return out


def generate_urls_all(overwrite: bool = False) -> dict:
    """모든 ENTITY scope 사이트에 대해 URL 생성."""
    result = {}
    conn = sqlite3.connect(DB)
    try:
        sites = conn.execute(
            "SELECT site_id, site_code FROM sys_ref_site "
            "WHERE scope='ENTITY' AND COALESCE(record_status,'LIVE')='LIVE'"
        ).fetchall()
    finally:
        conn.close()
    for sid, code in sites:
        print(f'\n-- generating for site {code} (id={sid}) --')
        stats = generate_urls_for_site(sid, overwrite=overwrite)
        print(f'   inserted={stats["inserted"]} updated={stats["updated"]} '
              f'skipped={stats["skipped"]} missing_name={stats["missing_name"]}')
        result[code] = stats
    return result


# ── HEAD 검증 ─────────────────────────────────────────────────────────────

def _encode_url(url: str) -> str:
    """URL의 path/query에 비-ASCII 문자 percent-encode (한글·기타 다국어 안전)."""
    parts = urlsplit(url)
    return urlunsplit((
        parts.scheme,
        parts.netloc,
        quote(parts.path, safe='/-_.~'),
        quote(parts.query, safe='=&'),
        quote(parts.fragment, safe=''),
    ))


def _head_check(url: str) -> int | None:
    """HEAD 요청 → status code. 실패 시 GET fallback. 모두 실패 시 None."""
    headers = {'User-Agent': USER_AGENT, 'Accept': '*/*'}
    try:
        safe_url = _encode_url(url)
    except Exception:
        return None
    for method in ('HEAD', 'GET'):
        req = urllib.request.Request(safe_url, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                return resp.status
        except urllib.error.HTTPError as e:
            return e.code  # 4xx/5xx도 의미 있는 결과
        except (urllib.error.URLError, TimeoutError, OSError):
            if method == 'GET':
                return None
    return None


def adopt_alias_for_entity(entity_id: int, site_id: int,
                             alias: str, new_url: str) -> bool:
    """별명 후보 채택 → site_aliases 저장 + sys_ref_entity_url 즉시 갱신.

    - sys_entity_master.json_detail.site_aliases[site_code] = alias
    - sys_ref_entity_url: url 갱신 + is_active=1, http_status=200,
                          last_checked=오늘, map_status='AUTO' (재생성 시
                          site_aliases가 우선 적용되므로 AUTO 유지 안전)
    """
    from datetime import date as _date
    conn = sqlite3.connect(DB)
    try:
        # site_code 조회
        srow = conn.execute(
            "SELECT site_code FROM sys_ref_site WHERE site_id=?",
            (site_id,)).fetchone()
        if not srow:
            return False
        site_code = srow[0]

        # json_detail.site_aliases[site_code] = alias
        jrow = conn.execute(
            "SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
            (entity_id,)).fetchone()
        if not jrow:
            return False
        jd = {}
        if jrow[0]:
            try:
                parsed = json.loads(jrow[0])
                if isinstance(parsed, dict):
                    jd = parsed
            except Exception:
                jd = {}
        sa = jd.get('site_aliases')
        if not isinstance(sa, dict):
            sa = {}
        sa[site_code] = alias
        jd['site_aliases'] = sa
        conn.execute(
            "UPDATE sys_entity_master SET json_detail=? WHERE entity_id=?",
            (json.dumps(jd, ensure_ascii=False), entity_id))

        # sys_ref_entity_url 즉시 갱신
        today = _date.today().isoformat()
        conn.execute(
            "UPDATE sys_ref_entity_url "
            "SET url=?, alias_used=?, is_active=1, http_status=200, "
            "    last_checked=?, map_status='AUTO' "
            "WHERE entity_id=? AND site_id=?",
            (new_url, alias, today, entity_id, site_id))
        conn.commit()
        return True
    finally:
        conn.close()


def verify_urls_batch(limit: int = 50, site_id: int | None = None) -> dict:
    """미확인 URL(last_checked IS NULL) 또는 site_id 지정 시 그 사이트 전체 검증.
    HTTP 200 → is_active=1, 4xx/5xx/None → is_active=0."""
    stats = {'checked': 0, 'ok_200': 0, 'redirect_3xx': 0,
             'client_4xx': 0, 'server_5xx': 0, 'failed': 0}
    conn = sqlite3.connect(DB)
    try:
        # [Phase D fix] site_id 지정 시에도 last_checked NULL만 (누적 진행)
        if site_id:
            rows = conn.execute(
                "SELECT rel_id, url FROM sys_ref_entity_url "
                "WHERE site_id=? AND last_checked IS NULL "
                "  AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY rel_id LIMIT ?", (site_id, limit)).fetchall()
        else:
            rows = conn.execute(
                "SELECT rel_id, url FROM sys_ref_entity_url "
                "WHERE last_checked IS NULL "
                "  AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY rel_id LIMIT ?", (limit,)).fetchall()

        c = conn.cursor()
        now = datetime.utcnow().isoformat(timespec='seconds')
        for rid, url in rows:
            stats['checked'] += 1
            code = _head_check(url)
            if code is None:
                is_active = 0
                stats['failed'] += 1
            elif 200 <= code < 300:
                is_active = 1
                stats['ok_200'] += 1
            elif 300 <= code < 400:
                is_active = 1  # redirect도 살아있음
                stats['redirect_3xx'] += 1
            elif 400 <= code < 500:
                is_active = 0
                stats['client_4xx'] += 1
            else:
                is_active = 0
                stats['server_5xx'] += 1
            c.execute(
                "UPDATE sys_ref_entity_url SET http_status=?, last_checked=?, "
                "is_active=? WHERE rel_id=?",
                (code, now, is_active, rid))
            conn.commit()  # 중도 종료 대비 커밋
            time.sleep(SLEEP_BETWEEN)
    finally:
        conn.close()
    return stats


# ── 보고 ──────────────────────────────────────────────────────────────────

def status_report():
    conn = sqlite3.connect(DB)
    try:
        print('\n== Sites (scope=ENTITY) ==')
        for r in conn.execute(
            "SELECT site_id, site_code, site_name, is_active "
            "FROM sys_ref_site WHERE scope='ENTITY' ORDER BY sort_order"
        ).fetchall():
            print(f'  id={r[0]:>3}  {r[1]:<22}  {r[2]:<32}  site_active={r[3]}')

        print('\n== URL counts per site ==')
        for r in conn.execute("""
            SELECT s.site_code,
                   COUNT(*) AS total,
                   SUM(CASE WHEN eu.is_active=1 THEN 1 ELSE 0 END) AS active,
                   SUM(CASE WHEN eu.last_checked IS NULL THEN 1 ELSE 0 END) AS pending,
                   SUM(CASE WHEN eu.http_status BETWEEN 200 AND 299 THEN 1 ELSE 0 END) AS ok200,
                   SUM(CASE WHEN eu.http_status BETWEEN 400 AND 499 THEN 1 ELSE 0 END) AS err4xx,
                   SUM(CASE WHEN eu.http_status IS NULL AND eu.last_checked IS NOT NULL THEN 1 ELSE 0 END) AS failed
              FROM sys_ref_entity_url eu
              JOIN sys_ref_site s ON s.site_id=eu.site_id
             WHERE s.scope='ENTITY'
          GROUP BY s.site_code
          ORDER BY s.sort_order
        """).fetchall():
            print(f'  {r[0]:<22}  total={r[1]:>4}  active={r[2]:>4}  '
                  f'pending={r[3]:>4}  ok200={r[4]:>4}  4xx={r[5]:>4}  failed={r[6]:>4}')

        print('\n== Entity coverage ==')
        n_ent = conn.execute("SELECT COUNT(*) FROM sys_entity_master WHERE record_status='LIVE'").fetchone()[0]
        n_with_url = conn.execute(
            "SELECT COUNT(DISTINCT entity_id) FROM sys_ref_entity_url "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
        print(f'  Entities total (LIVE): {n_ent}')
        print(f'  Entities with at least 1 URL: {n_with_url}')
    finally:
        conn.close()


# ── CLI ───────────────────────────────────────────────────────────────────

def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return
    cmd = argv[1]
    if cmd == 'generate':
        if len(argv) >= 3:
            sid = int(argv[2])
            print(f'-- generating for site_id={sid} --')
            print(generate_urls_for_site(sid, overwrite=False))
        else:
            print(generate_urls_all(overwrite=False))
    elif cmd == 'verify':
        n = int(argv[2]) if len(argv) >= 3 else 50
        print(f'-- verifying {n} URLs --')
        print(verify_urls_batch(limit=n))
    elif cmd == 'status':
        status_report()
    else:
        print(f'unknown command: {cmd}')
        print(__doc__)


if __name__ == '__main__':
    main(sys.argv)
