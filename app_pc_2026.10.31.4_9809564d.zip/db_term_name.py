# -*- coding: utf-8 -*-
"""기계 낱말(스트롱)의 **이름을 사람이 읽을 수 있게** 다시 짓는다.

    python db_term_name.py --selftest     # 의무
    python db_term_name.py --check        # 무엇이 달라지나(안 건드린다)
    python db_term_name.py --apply        # 고친다(멱등)
    python db_term_name.py --undo         # 되돌린다(백업표에서)

★★★ 왜 (2026-09-24 사용자 1.txt 15번 ⑥ — 「시12:6 에 연결한 타호르 같은
  경우 엔티티 라벨에 **사전의 본문**을 표시하고 있다. **짧은 번역된 단어 또는
  음역** 같은 것이 표시되어야 한다」).
  실측 — 기계 낱말 **10,892개**의 이름이 `음역 (사전 정의문…)` 꼴이라
  **중앙 38자 · 40자 넘는 것 5,010개 · 최대 78자**였다. 그래서 라벨에
  `ṭâhôwr (pure (in a physical, chemical, ceremonial…)` 가 통째로 떴다.
  승격된 123개는 `정결 · 타헤르` 로 제대로 나온다 — **이름 짓는 방식이 둘**
  이었던 것이다.

★★ **새 이름 = `음역 · 짧은 뜻`**(뜻이 확실할 때만) · 아니면 **음역만**.
  ⚠ **승격된 용어(한국어 이름이 있는 것)는 한 줄도 안 건드린다** — 그쪽은
    사람이 지은 이름이다(selftest 가 양방향으로 잰다).
  ⚠ 순서가 승격형(`뜻 · 음역`)과 **반대인 것은 일부러다** — 기계 낱말은
    **원어 낱말 자체가 표제**이고(사전 항목), 뜻이 없는 것도 같은 자리에서
    시작해 목록 정렬이 안 흔들린다.

★★★ **틀린 뜻을 적느니 안 적는다**(§0-1) — 실측으로 잡은 자리:
  `dâbar` 의 사전 정의는 「perhaps **properly, to arrange**; but used
  figuratively (of words), **to speak**」다. 앞 조각만 잘라 쓰면
  「다바르 = to arrange」가 되는데 **틀렸다**(실제 용법은 「말하다」이고
  구약 1,049절에 나온다). ⇒ `properly …; but …` 꼴은 **뜻을 안 붙인다.**

★ 재료는 **`sys_lemma_master`** 다(`gloss`·`kjv_def`·`n_verse`) —
  `sys_entity_lemma.gloss` 는 이미 잘려 있어 첫 조각이 더 자주 어긋난다.
"""
import argparse
import re
import sys

import appdb

#: 백업 — `--undo` 가 여기서 되돌린다(지우지 않는다 §0-5)
BACKUP = 'temp_termname_backup'

#: 기계 낱말 표식 — `db_term_load` 가 적어 둔 그 값
LEX_MARK = '"subtype": "LEX"'

#: 뜻 앞에 붙는 군더더기 — 걷어야 첫 뜻이 보인다
LEAD = re.compile(
    r'^(?:perhaps\s+)?(?:properly|literally|figuratively|by\s+implication|'
    r'specifically|specially|generally|probably|primarily|intensively|'
    r'causatively|denominatively|transitively|intransitively|reflexively|'
    r'passively|actively|adverbially|apparently|meaning)\b[\s,;:]*', re.I)

#: 「어원은 X 인데 실제로는 Y」 — 앞 조각을 쓰면 틀린다
SPLIT_SENSE = re.compile(r'^(?:perhaps\s+)?properly\b', re.I)

#: 이름에 붙일 뜻의 한계 — 넘으면 정의문이지 이름이 아니다
MAX_SENSE, MAX_WORDS = 24, 4


def short_sense(gloss):
    """짧고 **확실한** 뜻 한 조각 → 없으면 `''`.

    ⚠ 되도록 안 붙인다 — 라벨은 「무엇인지 짐작하게 하는 자리」이고 정확한
      뜻은 사전 탭이 말한다. **애매하면 음역만** 남기는 것이 옳다.
    """
    s = (gloss or '').strip()
    if not s:
        return ''
    m = SPLIT_SENSE.match(s)
    if m and re.search(r';|\bbut\b', s[m.end():]):
        return ''                      # 어원 ≠ 용법 — 안 적는다(dâbar)
    s = re.sub(r'^\([^)]*\)\s*,?\s*', '', s).strip()   # 앞 괄호 주석
    for _ in range(2):
        s2 = LEAD.sub('', s)
        if s2 == s:
            break
        s = s2.strip()
    s = re.split(r'\s*;|\s*,?\s*i\.e\.|\s*\(|\s*,', s)[0].strip()
    # ⚠ 사전이 낱말을 따옴표로 묶어 두는 자리가 있다(`to "will," i.e. …`) —
    #   조각을 내면 **짝 잃은 따옴표**가 남는다(실측 `boúlomai · to "will`).
    s = s.replace('"', '').replace('“', '').replace('”', '')
    s = s.strip(' ,;:.-×')
    if not s or len(s) > MAX_SENSE or len(s.split()) > MAX_WORDS:
        return ''
    return s


def make_name(translit, gloss, strong=''):
    """새 이름 — `음역 · 뜻` 또는 `음역`. 음역도 없으면 스트롱 번호."""
    tr = (translit or '').strip()
    if not tr:
        return (strong or '').strip()
    sense = short_sense(gloss)
    return ('%s · %s' % (tr, sense)) if sense else tr


def rows(conn):
    """기계 낱말 → `[(entity_id, strong, translit, gloss, 지금 이름)]`.

    ⚠ **승격된 것은 여기 안 들어온다** — 한국어 이름이 있으면 사람이 지은
      것이다. 표식(`subtype:LEX`)과 **두 겹으로** 거른다.
    """
    return conn.execute("""
        SELECT e.entity_id, l.strong, l.translit,
               COALESCE(m.gloss, l.gloss),
               (SELECT ta.contents FROM sys_text_asset ta
                 WHERE ta.clicked_id = e.entity_id
                   AND ta.text_type = 'ENTITY_NAME'
                   AND ta.lang_code = 'EN')
          FROM sys_entity_master e
          JOIN sys_entity_lemma  l ON l.entity_id = e.entity_id
          LEFT JOIN sys_lemma_master m ON m.strong = l.strong
         WHERE e.entity_type = 'TERM'
           AND COALESCE(e.record_status, 'LIVE') = 'LIVE'
           AND COALESCE(e.json_detail, '') LIKE ?
           AND NOT EXISTS (SELECT 1 FROM sys_text_asset k
                            WHERE k.clicked_id = e.entity_id
                              AND k.text_type = 'ENTITY_NAME'
                              AND k.lang_code = 'KO'
                              AND COALESCE(k.contents, '') <> '')
      """, ('%' + LEX_MARK + '%',)).fetchall()


def plan(conn):
    """바꿀 것 → `[(entity_id, 옛 이름, 새 이름)]`(같은 것은 뺀다 — 멱등)."""
    out = []
    for eid, strong, tr, gloss, old in rows(conn):
        new = make_name(tr, gloss, strong)
        if new and new != (old or ''):
            out.append((eid, old or '', new))
    return out


def _ensure_backup(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " entity_id INTEGER PRIMARY KEY,"
                 " old_name TEXT, at TEXT)" % BACKUP)


def apply(conn, limit=None):
    """고친다 → 고친 수. **옛 이름을 백업표에 남긴다**(되돌릴 자리)."""
    import time
    todo = plan(conn)
    if limit:
        todo = todo[:limit]
    _ensure_backup(conn)
    now = time.strftime('%Y-%m-%d %H:%M')
    n = 0
    for eid, old, new in todo:
        # ⚠ **처음 값만** 남긴다 — 두 번 돌려도 원본을 안 잃는다
        conn.execute("INSERT OR IGNORE INTO %s(entity_id, old_name, at)"
                     " VALUES(?,?,?)" % BACKUP, (eid, old, now))
        conn.execute("UPDATE sys_text_asset SET contents=?"
                     " WHERE clicked_id=? AND text_type='ENTITY_NAME'"
                     " AND lang_code='EN'", (new, eid))
        n += 1
    conn.commit()
    return n


def undo(conn):
    """백업표의 옛 이름으로 되돌린다 → 되돌린 수."""
    try:
        got = conn.execute("SELECT entity_id, old_name FROM %s" % BACKUP
                           ).fetchall()
    except Exception:                                         # noqa: BLE001
        return 0
    n = 0
    for eid, old in got:
        conn.execute("UPDATE sys_text_asset SET contents=?"
                     " WHERE clicked_id=? AND text_type='ENTITY_NAME'"
                     " AND lang_code='EN'", (old, eid))
        n += 1
    conn.execute("DELETE FROM %s" % BACKUP)
    conn.commit()
    return n


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    # ── 뜻 고르기 ────────────────────────────────────────────────
    t('짧은 뜻은 그대로', short_sense('just') == 'just')
    t('괄호 부연을 걷는다',
      short_sense('pure (in a physical, chemical, ceremonial or moral sense)')
      == 'pure')
    t('쉼표 뒤 부연을 걷는다',
      short_sense('to do or make, in the broadest sense') == 'to do or make')
    t('군더더기 머리를 걷는다',
      short_sense('properly, the whole') == 'the whole')
    t('★★★ 어원≠용법이면 **안 붙인다**(dâbar)',
      short_sense('perhaps properly, to arrange; but used figuratively'
                  ' (of words), to speak') == '',
      repr(short_sense('perhaps properly, to arrange; but used figuratively'
                       ' (of words), to speak')))
    t('앞 괄호 주석을 걷는다',
      short_sense('(adverbially) certainly') == 'certainly')
    t('긴 것은 안 붙인다',
      short_sense('used only in certain past tenses, the others being'
                  ' borrowed') == '')
    t('빈 것은 빈 것', short_sense('') == '' and short_sense(None) == '')
    t('★ 짝 잃은 따옴표를 걷는다',
      short_sense('to "will," i.e. be willing') == 'to will',
      repr(short_sense('to "will," i.e. be willing')))

    # ── 이름 짓기 ────────────────────────────────────────────────
    t('★★ 음역 · 뜻',
      make_name('ṭâhôwr', 'pure (in a physical sense)') == 'ṭâhôwr · pure')
    t('★★ 뜻이 없으면 음역만',
      make_name('dâbar', 'perhaps properly, to arrange; but to speak')
      == 'dâbar')
    t('음역도 없으면 스트롱',
      make_name('', 'x', 'H9999') == 'H9999')
    t('★ 이름에 사전 정의문이 안 들어간다',
      len(make_name('ʻôsheq', 'injury, fraud, (subjectively) distress,'
                              ' (concretely) unjust gain')) < 20,
      make_name('ʻôsheq', 'injury, fraud, (subjectively) distress'))

    # ── 실 DB — 고르는 쪽 ────────────────────────────────────────
    c = appdb.connect('bible_master.db')
    try:
        rs = rows(c)
        t('★ 기계 낱말을 선택한다', len(rs) > 9000, '%d개' % len(rs))
        ids = {r[0] for r in rs}
        ko = c.execute("""SELECT COUNT(*) FROM sys_entity_master e
             WHERE e.entity_type='TERM'
               AND EXISTS(SELECT 1 FROM sys_text_asset t
                          WHERE t.clicked_id=e.entity_id
                            AND t.text_type='ENTITY_NAME' AND t.lang_code='KO'
                            AND COALESCE(t.contents,'')<>'')
               AND e.entity_id IN (%s)"""
                       % ','.join(str(i) for i in list(ids)[:900])
                       ).fetchone()[0] if ids else 0
        t('★★★ **승격된 것(한국어 이름)은 안 선택한다**', ko == 0, str(ko))
        # 승격된 보기 하나가 실제로 빠졌나 — 정결·타헤르(H2891)
        r = c.execute("SELECT entity_id FROM sys_entity_lemma"
                      " WHERE strong='H2891'").fetchone()
        t('  보기: 「정결 · 타헤르」가 대상에서 빠졌다',
          bool(r) and r[0] not in ids)
        pl = plan(c)
        # ⚠⚠⚠ **데이터 상태를 전제한 검사를 두지 않는다**(§0-5). 전에는
        #   「바꿀 것이 9,000개 넘게 있다」였는데, `--apply` 로 다 고치자
        #   그날로 FAIL 이 됐다 — 이 저장소에서 「아직 안 한 일」을 전제한
        #   검사는 반드시 깨진다.
        #   ⇒ 묻는 것은 **「규칙이 도는가」** — 고친 이름 하나를 옛 꼴로
        #     되돌려 놓고 목록에 걸리는지 보고, 곧바로 되돌린다.
        probe = c.execute(
            "SELECT a.clicked_id, a.contents FROM sys_text_asset a"
            "  JOIN sys_entity_master e ON e.entity_id=a.clicked_id"
            " WHERE a.text_type='ENTITY_NAME' AND a.lang_code='EN'"
            "   AND COALESCE(e.json_detail,'') LIKE ?"
            "   AND NOT EXISTS(SELECT 1 FROM sys_text_asset k"
            "        WHERE k.clicked_id=e.entity_id"
            "          AND k.text_type='ENTITY_NAME' AND k.lang_code='KO')"
            " LIMIT 1", ('%' + LEX_MARK + '%',)).fetchone()
        if probe:
            eid, keep = probe
            c.execute("UPDATE sys_text_asset SET contents=? WHERE clicked_id=?"
                      " AND text_type='ENTITY_NAME' AND lang_code='EN'",
                      ('__시험용 옛 이름__', eid))
            hit = [x for x in plan(c) if x[0] == eid]
            c.execute("UPDATE sys_text_asset SET contents=? WHERE clicked_id=?"
                      " AND text_type='ENTITY_NAME' AND lang_code='EN'",
                      (keep, eid))
            c.commit()
            t('★★★ **규칙이 돈다** — 옛 꼴을 심으면 목록에 걸린다',
              len(hit) == 1, '%d건' % len(hit))
            t('  시험 자국 0', c.execute(
                "SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                " AND text_type='ENTITY_NAME' AND lang_code='EN'",
                (eid,)).fetchone()[0] == keep)
        else:
            t('★ 잴 재료가 없다(기계 낱말 0)', False, '재료 없음')
        long_new = [x for x in pl if len(x[2]) > 45]
        t('★★ 새 이름이 45자를 안 넘는다', not long_new, str(long_new[:1]))
        # 멱등 — 이미 새 꼴인 것은 목록에 안 든다
        same = [x for x in pl if x[1] == x[2]]
        t('  이미 같은 것은 안 센다(멱등)', not same)
    finally:
        c.close()
    print('db_term_name selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--limit', type=int, default=0)
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect('bible_master.db')
    try:
        if a.check:
            pl = plan(c)
            print('바꿀 이름 %d개' % len(pl))
            n_sense = sum(1 for _e, _o, n in pl if ' · ' in n)
            print('  뜻까지 붙는 것 %d · 음역만 %d'
                  % (n_sense, len(pl) - n_sense))
            for eid, old, new in pl[:15]:
                print('  %-34s ← %s' % (new, (old or '')[:44]))
        elif a.apply:
            print('고침 %d개' % apply(c, a.limit or None))
        elif a.undo:
            print('되돌림 %d개' % undo(c))
        else:
            ap.print_help()
    finally:
        c.close()


if __name__ == '__main__':
    main()
