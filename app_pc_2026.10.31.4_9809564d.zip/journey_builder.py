# -*- coding: utf-8 -*-
"""journey_builder.py — 골라담기 「발자취 여정」 빌더 (2026-08-18 신설).

사용자 확정 설계: 골라담기 기준 = 「선택의 여지가 다양한 경우」 — 정류장
198개는 완주 불가 규모라 골라 담는 것이 본질이다. **인물묵상과의 차별**:
생애의 국면이 아니라 **장소(정류장)** 가 하루의 단위다(축에서 국면을 뺐다).

  부품  = sys_place_route_stop (기존 발자취 데이터 재사용 — 저작 0)
  축    = 시대 그룹(족장~바울) · 지역(4 대권역) + 인물 개별 체크
  하루  = 정류장 1개(그 자리의 본문 + 여정 맥락 설명문이 포커스)

  · 학설 테마(아브라함 남부설/북부설·출애굽)는 **기본 경로만**, 바울처럼
    같은 confidence 의 다중 경로(1~3차·압송)는 **전부 순서대로**.
  · 전승 경로(도마·안드레)는 성경 본문이 없어 제외(실측 — 해석 가능 정류장
    각 1개뿐). 경유점(is_waypoint)도 제외.
  · 저장 = user_bible_plan(origin=JOURNEY_BUILDER 앵커) + user_plan_schedule
    (miracle_builder 와 같은 규약). sys 에는 쓰지 않는다(§0-6 C-2).
"""
import json
import tkinter as tk
from tkinter import ttk, messagebox

import i18n
import appdb
import scripture_ref_kr
from plan_builder import FilterRow, check_plan_name, unique_sibling_name, _readable

ANCHOR_CODE = 'JOURNEY_BUILDER'

# 시대 그룹 — theme_code 로 못 박는다(id 는 DB 마다 다를 수 있다)
_ERAS = [
    ('PATRIARCH', '족장',   {'ABRAHAM', 'ISAAC', 'JACOB', 'JOSEPH'}),
    ('EXODUS',    '출애굽·광야', {'EXODUS', 'MOSES', 'JOSHUA'}),
    ('JUDGES',    '사사',   {'GIDEON', 'SAMUEL'}),
    ('KINGS',     '왕정',   {'SAUL', 'DAVID', 'SOLOMON'}),
    ('PROPHETS',  '선지자', {'ELIJAH', 'ELISHA'}),
    ('JESUS',     '예수님', {'JESUS_LIFE'}),
    ('APOSTLES',  '사도',   {'PETER', 'JOHN', 'PHILIP_EV'}),
    ('PAUL',      '바울',   {'PAUL'}),
]
_EXCLUDE = {'THOMAS', 'ANDREW'}       # 전승 — 성경 본문 없음(실측)

_REGIONS = [
    ('EGYPT_WILD', '애굽·광야', {'EGYPT', 'SINAI'}),
    ('CANAAN', '이스라엘', {'JUDEA', 'SAMARIA', 'GALILEE', 'TRANSJORDAN'}),
    ('SYRIA_MESO', '시리아·메소포타미아', {'SYRIA', 'MESOPOTAMIA'}),
    ('NT_MISSION', '소아시아·그리스·로마',
     {'CYPRUS', 'ASIA_MINOR', 'GREECE', 'ITALY'}),
]


def _era_of(code):
    for key, _l, codes in _ERAS:
        if code in codes:
            return key
    return None


def load_parts(conn):
    """인물(테마)과 사용 가능한 정류장을 전부 읽는다.

    반환 = [{theme_id, code, name, era, stops:[{stop_id, seq_key, place,
             region, ref, a, b, desc}]}]  (시대순)
    """
    bm = scripture_ref_kr.book_map_ko(conn)
    persons = []
    for tid, code, so, nm in conn.execute(
            """SELECT t.theme_id, t.theme_code, t.sort_order,
               (SELECT contents FROM sys_text_asset WHERE
                text_type='ROUTE_THEME_NAME' AND clicked_id=t.theme_id
                AND lang_code='KO' LIMIT 1)
               FROM sys_place_route_theme t
               WHERE t.record_status='LIVE' AND EXISTS
                 (SELECT 1 FROM sys_place_route r WHERE r.theme_id=t.theme_id
                  AND r.record_status='LIVE')
               ORDER BY t.sort_order"""):
        era = _era_of(code)
        if era is None or code in _EXCLUDE:
            continue
        routes = conn.execute(
            "SELECT route_id, confidence, is_default, sort_order FROM "
            "sys_place_route WHERE theme_id=? AND record_status='LIVE' "
            "ORDER BY sort_order", (tid,)).fetchall()
        variant = len({r[1] for r in routes}) > 1     # 학설 → 기본 경로만
        use = [r[0] for r in routes if (r[2] == 1 if variant else True)]
        stops = []
        for k, rid in enumerate(use):
            for sid, seq, eid, ref, wp in conn.execute(
                    "SELECT stop_id, seq, entity_id, scripture_ref, "
                    "COALESCE(is_waypoint,0) FROM sys_place_route_stop "
                    "WHERE route_id=? ORDER BY seq", (rid,)):
                if wp:
                    continue
                a, b = scripture_ref_kr.resolve(conn, ref or '', bm)
                if a is None:
                    continue
                place = conn.execute(
                    "SELECT contents FROM sys_text_asset WHERE "
                    "text_type='ENTITY_NAME' AND clicked_id=? AND "
                    "UPPER(lang_code)='KO' AND record_status='LIVE' LIMIT 1",
                    (eid,)).fetchone()
                region = None
                row = conn.execute("SELECT json_detail FROM sys_entity_master "
                                   "WHERE entity_id=?", (eid,)).fetchone()
                if row and row[0]:
                    try:
                        rc = json.loads(row[0]).get('region_code')
                        for key, _l, codes in _REGIONS:
                            if rc in codes:
                                region = key
                    except Exception:
                        pass
                desc = conn.execute(
                    "SELECT contents FROM sys_text_asset WHERE "
                    "text_type='ROUTE_STOP_DESC' AND clicked_id=? AND "
                    "UPPER(lang_code)='KO' AND record_status='LIVE' LIMIT 1",
                    (sid,)).fetchone()
                stops.append(dict(
                    stop_id=sid, seq_key=(k, seq),
                    place=(place[0] if place else '') or '',
                    region=region, ref=ref, a=a, b=b,
                    desc=(desc[0] if desc else '') or ''))
        if stops:
            persons.append(dict(theme_id=tid, code=code, name=nm or code,
                                era=era, stops=stops))
    return persons


def anchor_plan_id(conn):
    row = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                       (ANCHOR_CODE,)).fetchone()
    return row[0] if row else None


class JourneyBuilderDialog(tk.Toplevel):
    """골라담기 발자취 빌더 — miracle_builder 와 같은 흐름."""

    def __init__(self, parent, db_path='bible_master.db'):
        super().__init__(parent)
        self.db_path = db_path
        self.created_user_plan_id = None
        self.enroll_now = None
        self.title(i18n.t('JB_TITLE', '발자취 여정 만들기'))
        self.geometry('980x640')
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        with appdb.connect(self.db_path) as conn:
            self._persons = load_parts(conn)
        self._checked = {p['code']: tk.BooleanVar(value=True)
                         for p in self._persons}
        self._build()
        self._refresh()

    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill='x', padx=10, pady=(8, 4))
        ttk.Label(top, text=i18n.t('PB_PLAN_NAME', '플랜 이름')).pack(side='left')
        self._name_var = tk.StringVar()
        ttk.Entry(top, textvariable=self._name_var, width=24).pack(
            side='left', padx=(6, 10))
        ttk.Button(top, text=i18n.t('JB_CREATE', '플랜 만들기'),
                   command=self._create_plan).pack(side='left')
        self._cnt_lbl = ttk.Label(top, text='', foreground='#1A5276')
        self._cnt_lbl.pack(side='right')

        ff = ttk.Frame(self)
        ff.pack(fill='x', padx=10, pady=(2, 4))
        self._fr_era = FilterRow(
            ff, 0, i18n.t('JB_ERA', '시대'), [k for k, _l, _c in _ERAS],
            display={k: l for k, l, _c in _ERAS}, on_change=self._refresh)
        self._fr_region = FilterRow(
            ff, 1, i18n.t('JB_REGION', '지역'), [k for k, _l, _c in _REGIONS],
            display={k: l for k, l, _c in _REGIONS}, on_change=self._refresh)

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=10, pady=(2, 8))
        lf = ttk.LabelFrame(pw, text=' 인물 (체크로 담기) ')
        pw.add(lf, weight=1)
        rf = ttk.LabelFrame(pw, text=' 여정 미리보기 ')
        pw.add(rf, weight=2)

        self._ptv = ttk.Treeview(lf, columns=('n',), show='tree headings',
                                 selectmode='browse')
        self._ptv.heading('#0', text=i18n.t('COMMON_NAME', '이름'))
        self._ptv.column('#0', width=170)
        self._ptv.heading('n', text=i18n.t('JB_STOPS', '정류장'))
        self._ptv.column('n', width=56, anchor='center')
        self._ptv.pack(fill='both', expand=True, padx=4, pady=4)
        self._ptv.bind('<Button-1>', self._on_person_click)

        self._stv = ttk.Treeview(rf, columns=('who', 'ref'),
                                 show='tree headings', selectmode='browse')
        self._stv.heading('#0', text=i18n.t('JB_PLACE', '장소'))
        self._stv.column('#0', width=180)
        self._stv.heading('who', text=i18n.t('JB_PERSON', '인물'))
        self._stv.column('who', width=90, anchor='center')
        self._stv.heading('ref', text=i18n.t('COMMON_VERSE', '본문'))
        self._stv.column('ref', width=110, anchor='center')
        vsb = ttk.Scrollbar(rf, orient='vertical', command=self._stv.yview)
        self._stv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._stv.pack(fill='both', expand=True, padx=(4, 0), pady=4)

    # ── 필터 · 선택 ────────────────────────────────────────────────────

    def _visible_persons(self):
        eras = set(self._fr_era.get_selected())
        return [p for p in self._persons if p['era'] in eras]

    def _stops_of(self, p):
        regions = set(self._fr_region.get_selected())
        all_regions = self._fr_region.is_all()
        out = []
        for s in p['stops']:
            if all_regions or s['region'] in regions or s['region'] is None:
                out.append(s)
        return out

    def _picked(self):
        """(person, stops) — 시대순 · 정류장 순서 보존."""
        out = []
        for p in self._visible_persons():
            if not self._checked[p['code']].get():
                continue
            st = self._stops_of(p)
            if st:
                out.append((p, st))
        return out

    def _refresh(self):
        tv = self._ptv
        tv.delete(*tv.get_children())
        for p in self._visible_persons():
            n = len(self._stops_of(p))
            mark = '☑' if self._checked[p['code']].get() else '☐'
            tv.insert('', 'end', iid=p['code'],
                      text='%s %s' % (mark, p['name']), values=(n,))
        sv = self._stv
        sv.delete(*sv.get_children())
        total = 0
        for p, stops in self._picked():
            for s in stops:
                total += 1
                sv.insert('', 'end', text='%d. %s' % (total, s['place']),
                          values=(p['name'], s['ref']))
        self._cnt_lbl.config(text=i18n.t(
            'JB_COUNT', '{n}일 여정').format(n=total))

    def _on_person_click(self, ev):
        iid = self._ptv.identify_row(ev.y)
        if iid in self._checked:
            self._checked[iid].set(not self._checked[iid].get())
            self._refresh()
        return 'break'

    # ── 생성 ───────────────────────────────────────────────────────────

    def _create_plan(self):
        picked = self._picked()
        if not picked:
            messagebox.showwarning(
                i18n.t('COMMON_WARNING', '경고'),
                i18n.t('JB_EMPTY', '담긴 정류장이 없습니다.'), parent=self)
            return
        plan_code = _readable(self._name_var.get().strip(), '내 발자취 여정')
        plan_code = check_plan_name(plan_code, self)
        if plan_code is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                anchor = anchor_plan_id(conn)
                if not anchor:
                    messagebox.showerror(
                        i18n.t('COMMON_ERROR', '오류'),
                        '앵커 플랜(JOURNEY_BUILDER)이 없습니다.', parent=self)
                    return
                plan_code = unique_sibling_name(conn, plan_code, anchor)
                self._name_var.set(plan_code)
                days = sum(len(st) for _p, st in picked)
                config = {
                    'filter': {
                        'era': self._fr_era.get_selected(),
                        'region': self._fr_region.get_selected(),
                        'persons': [p['code'] for p, _s in picked],
                    },
                    'total_units': days,
                }
                cur = conn.execute(
                    "INSERT INTO user_bible_plan (origin_plan_id, plan_code, "
                    "plan_type, plan_category, duration_days, track_count, "
                    "plan_config) VALUES (?, ?, 'JOURNEY', 'THEMATIC', ?, 1, ?)",
                    (anchor, plan_code, days,
                     json.dumps(config, ensure_ascii=False)))
                uid = cur.lastrowid
                day = 0
                for p, stops in picked:
                    for s in stops:
                        day += 1
                        desc = s['desc'] or i18n.t(
                            'JB_STOP_FALLBACK', '이 자리의 이야기를 본문에서 '
                            '읽습니다.')
                        focus = '%s · %s: %s' % (p['name'], s['place'], desc)
                        conn.execute(
                            "INSERT INTO user_plan_schedule (user_plan_id, "
                            "week, day, track, start_vid, end_vid, "
                            "stage_type, connection_level, sort_order, "
                            "meditation_focus, unit_key) "
                            "VALUES (?,?,?,1,?,?,'CORE','CORE',1,?,?)",
                            (uid, (day - 1) // 7 + 1, day, s['a'], s['b'],
                             focus, 'STOP_%d' % s['stop_id']))
            self.created_user_plan_id = uid
            self.enroll_now = messagebox.askyesno(
                i18n.t('COMMON_DONE', '완료'),
                i18n.t('MSG_PLAN_CREATED_ASK2',
                       '플랜을 만들었습니다 — {code} ({days}일)\n{status}\n\n'
                       '지금 등록할까요?').format(
                    code=plan_code, days=days,
                    status=i18n.t('JB_MADE', '정류장 {n}곳').format(n=days)),
                parent=self)
            self.destroy()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e),
                                 parent=self)


if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    dlg = JourneyBuilderDialog(root)
    root.wait_window(dlg)
    root.destroy()
