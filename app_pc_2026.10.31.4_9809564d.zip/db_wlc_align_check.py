# -*- coding: utf-8 -*-
"""히브리 원문이 **우리 절 번호와 같은 자리에 있는가** — 스트롱으로 증명한다.

★★★ 왜 (2026-09-24 사용자 물음 「성경 어떤 구절을 선택하든지 그 구절의
  내용/의미가 동일한 히브리어 구절이 100% 연결되는가? … **단지 공란이 있는지
  여부가 아니라** 정말 히브리 버전의 특정한 구절이 다른 버전의 동일한 구절번호와
  **100% 일치하는지** 답변하라」).
  ⚠⚠ 역본 차이 진단(`panel_verse_divergence`)이 재는 것은 **칸이 비었나**뿐이다.
    「글이 들어 있는데 **한 칸 밀렸다**」는 그 검사로 영영 안 잡힌다 —
    §267차 RusSyn 시편이 딱 그 꼴이었다(빈칸보다 나쁘다).

★★★ 잣대 = §273차 `db_strong_align` 과 **같은 방법**(스트롱 집합).
  번역은 달라도 **원문 낱말 번호는 같다.** 같은 칸의 BSB 스트롱 집합과 WLC
  스트롱 집합을 견주고, **제자리보다 이웃이 뚜렷하게 나으면 밀린 것**이다
  (§268차 「어긋남 판정」 — 아무 데도 없으면 번역 차이이고, **이웃에 있는데
  제자리에 없을 때만** 밀림이다).

⚠⚠⚠ **얇은 태깅을 걸러야 한다** — BSB 는 족보의 고유명사에 스트롱을 거의 안
  단다(실측 「BSB 낱말 2 ↔ 원문 낱말 13」인 절이 554개). 그 절의 자카드는
  **자리가 아니라 태깅 두께**를 재는 것이라, 안 걸러내면 족보가 통째로
  밀린 것처럼 보인다(첫 판이 실제로 그랬다 — 16건 중 9건이 헛것).

⚠ 이 도구는 **로컬 전용 `wlc_verify.db`** 를 읽는다(§18-10). 없으면
  「못 잰다」고 말하고 통과시키지 않는다 — **조용한 통과가 가장 나쁘다**(§0-1).

`--selftest`(의무 · 양방향) · `--check` · `--check --all`(얇은 태깅까지).
"""
import argparse
import collections
import io
import os
import sqlite3
import sys

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
WDB = os.path.join(os.path.dirname(__file__), 'wlc_verify.db')

#: 기준 역본 — 스트롱이 붙은 역본 가운데 **우리 좌표축의 기준**이다(§273차).
BASE = 'BSB'

#: ⚠⚠ **BSB 낱말이 이보다 적으면 판정하지 않는다** — 자카드가 자리가 아니라
#:   태깅 두께를 재게 된다(족보 오탐의 정체). 「못 쟀다」로 적는다.
MIN_BASE = 5

#: 이웃이 **이만큼 닮았고** …
NEAR = 0.60
#: … 제자리보다 **이만큼 나으면** 밀린 것으로 본다.
GAP = 0.25

#: 몇 칸까지 보나 — §268차 는 ±2 를 썼다(한 칸 밀림이 대부분이지만
#: 표제가 두 절인 시편에서는 두 칸이 난다).
SPAN = 2


def jac(a, b):
    """두 스트롱 집합의 겹침(자카드). 한쪽이 비면 0."""
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def _codes(s):
    return {x for x in (s or '').split() if x.startswith('H')}


def load(conn, wconn):
    """`(원문 스트롱, 기준 스트롱, 읽기차례, 좌표)` — 재료를 한 번에."""
    base = {}
    for vid, st in conn.execute(
            "SELECT verse_id, strongs FROM sys_verse_strong"
            " WHERE version_code=?", (BASE,)):
        s = _codes(st)
        if s:
            base[vid] = s
    wlc = {}
    for vid, st in wconn.execute('SELECT verse_id, strongs FROM wlc_verse'):
        s = _codes(st)
        if s:
            wlc[vid] = s
    order = {v: i for i, (v,) in enumerate(conn.execute(
        'SELECT verse_id FROM bible_index ORDER BY sort_order'))}
    idx = {v: (b, ch, vs) for v, b, ch, vs in conn.execute(
        'SELECT verse_id, bcode, chapter, verse FROM bible_index')}
    return wlc, base, order, idx


def shifted(wlc, base, order, min_base=MIN_BASE, near=NEAR, gap=GAP,
            span=SPAN):
    """밀린 절 → `[(verse_id, 제자리, 이웃, 몇 칸)]` · 못 잰 절 수.

    ⚠ **판정 못 한 것을 「통과」로 세지 않는다** — 따로 돌려준다(§0-1).
    """
    back = {i: v for v, i in order.items()}
    hits, skipped = [], 0
    for vid, s in wlc.items():
        if vid not in base or vid not in order:
            skipped += 1
            continue
        if len(base[vid]) < min_base:
            skipped += 1
            continue
        here = jac(s, base[vid])
        best, who = here, 0
        for d in range(-span, span + 1):
            if not d:
                continue
            nb = back.get(order[vid] + d)
            if nb in base:
                jj = jac(s, base[nb])
                if jj > best:
                    best, who = jj, d
        if who and best >= near and best - here >= gap:
            hits.append((vid, here, best, who))
    hits.sort(key=lambda x: order[x[0]])
    return hits, skipped


def coverage(wlc, base, order):
    """제자리 겹침 분포 → `(평균, {구간: 절수}, 잰 절)`."""
    buck = collections.Counter()
    tot = n = 0.0
    for vid, s in wlc.items():
        if vid not in base:
            continue
        j = jac(s, base[vid])
        tot += j
        n += 1
        buck['0.9~1.0' if j >= 0.9 else
             '0.7~0.9' if j >= 0.7 else
             '0.5~0.7' if j >= 0.5 else
             '0.3~0.5' if j >= 0.3 else '<0.3'] += 1
    return (tot / n if n else 0.0), buck, int(n)


def text_same(conn, wconn):
    """배포 본문(`bible_content.WLC`)이 **검증 원문과 같은 글인가**.

    ⚠ 이것을 먼저 본다 — 검증 DB 로 아무리 재도 **배포되는 글이 딴것이면**
      잰 것이 아무 뜻이 없다.
    ⚠ 모음 부호·낱말 구분 `/` 는 걷고 **자음만** 견준다(배포본은 `/` 를 뗐다).
    """
    import unicodedata as ud

    def strip(s):
        return ''.join(ch for ch in ud.normalize('NFC', s or '')
                       if ud.category(ch) != 'Mn'
                       and ch not in '/־׃׀׳״ ')

    heb = dict(wconn.execute('SELECT verse_id, heb FROM wlc_verse'))
    same = diff = miss = merged = 0
    bad = []
    for vid, t in conn.execute("SELECT verse_id, verse_text FROM bible_content"
                               " WHERE version_code='WLC'"):
        # ⚠ `<병합 N:M>` 칸은 **우리가 구운 표식**이지 원문 줄이 아니다 —
        #   「검증본에 없다」로 세면 고친 자리가 흠처럼 보인다(§18-8 ④).
        if t and t.lstrip().startswith('<병합'):
            merged += 1
            continue
        if vid not in heb:
            miss += 1
            continue
        if strip(t) == strip(heb[vid]):
            same += 1
        else:
            diff += 1
            if len(bad) < 5:
                bad.append(vid)
    return {'same': same, 'diff': diff, 'missing': miss, 'merged': merged,
            'sample': bad, 'source': len(heb)}


def check(conn=None, wconn=None, min_base=MIN_BASE, log=print):
    """전수 점검 → `{ok, shifted, skipped, mean, text}`."""
    own = conn is None
    conn = conn or appdb.connect(DB)
    if wconn is None:
        if not os.path.exists(WDB):
            log('⚠ 검증 원문(%s)이 없다 — **못 잰다**(통과가 아니다).'
                ' `db_wlc_verify.py --build` 로 만든다.' % os.path.basename(WDB))
            return {'ok': None, 'why': 'NO_WLC_DB'}
        wconn = sqlite3.connect(WDB)
    t = text_same(conn, wconn)
    log('■ 배포 본문 ↔ 검증 원문 — 같은 글인가')
    log('  원문 %d절 · 같다 %d · **다르다 %d** · 검증본에 없는 칸 %d'
        ' · 병합 표식 %d'
        % (t['source'], t['same'], t['diff'], t['missing'], t['merged']))
    wlc, base, order, idx = load(conn, wconn)
    mean, buck, n = coverage(wlc, base, order)
    log('■ 같은 칸에서 기준(%s)과 원문 낱말이 겹치나 — 잰 절 %d · 평균 %.3f'
        % (BASE, n, mean))
    for k in ('0.9~1.0', '0.7~0.9', '0.5~0.7', '0.3~0.5', '<0.3'):
        log('    %-9s %6d절 (%.1f%%)' % (k, buck[k], 100.0 * buck[k]
                                         / max(n, 1)))
    hits, skipped = shifted(wlc, base, order, min_base=min_base)
    log('■ 밀림 — 제자리보다 이웃이 뚜렷하게 나은 절'
        ' (얇은 태깅 %d절은 **못 쟀다**)' % skipped)
    log('  **밀린 절 %d**' % len(hits))
    bn = dict(conn.execute("SELECT book_code, short_name FROM book_names"
                           " WHERE lang_code='KO'"))
    for vid, here, best, who in hits:
        b, ch, vs = idx[vid]
        # ⚠ `book_names.book_code` 는 **INTEGER** 다 — 글자로 찾으면 다 빗나간다.
        log('    %s %d:%d  제자리 %.2f ↔ %+d칸 %.2f'
            % (bn.get(b, '책%s' % b), ch, vs, here, who, best))
    if own:
        conn.close()
    return {'ok': (t['diff'] == 0 and not hits), 'shifted': hits,
            'skipped': skipped, 'mean': mean, 'text': t}


# ── 자가검증 ────────────────────────────────────────────────────────
def selftest():
    n = [0, 0]

    def t(name, cond, got=''):
        n[1] += 1
        if cond:
            n[0] += 1
        print('  %-5s %s %s' % ('OK' if cond else 'FAIL', name, str(got)[:80]))

    t('겹침 — 같으면 1', jac({'H1', 'H2'}, {'H1', 'H2'}) == 1.0)
    t('겹침 — 다르면 0', jac({'H1'}, {'H2'}) == 0.0)
    t('  한쪽이 비면 0', jac(set(), {'H1'}) == 0.0)
    t('스트롱만 선택한다', _codes('H1 G2 x H3') == {'H1', 'H3'})

    # ★★★ **탐지력 — 일부러 한 칸 밀어 본다**(양방향)
    base = {i: {'H%d' % (i * 10 + k) for k in range(6)} for i in range(1, 9)}
    order = {i: i - 1 for i in range(1, 9)}
    good = {i: set(base[i]) for i in base}
    h, sk = shifted(good, base, order)
    t('★★★ 제자리면 **밀림 0**', not h, str(h))
    t('  못 잰 절 0', sk == 0)
    bad = {i: set(base[i - 1]) for i in range(2, 9)}
    h2, _s = shifted(bad, base, order)
    t('★★★ 한 칸 밀면 **전부 잡는다**', len(h2) == 7, '%d/7' % len(h2))
    t('  방향도 맞힌다(-1)', all(x[3] == -1 for x in h2),
      str([x[3] for x in h2]))
    bad2 = {i: set(base[i - 2]) for i in range(3, 9)}
    h3, _s = shifted(bad2, base, order)
    t('★★ 두 칸 밀어도 잡는다', len(h3) == 6, '%d/6' % len(h3))

    # ⚠⚠ **얇은 태깅은 판정하지 않는다** — 족보 오탐의 정체
    thin = {i: {'H%d' % (i * 10)} for i in range(1, 9)}   # 기준 낱말 1개
    w = {i: {'H%d' % (i * 10 + k) for k in range(6)} for i in range(1, 9)}
    h4, sk4 = shifted(w, thin, order)
    t('★★★ 기준 태깅이 얇으면 **판정하지 않는다**(「통과」가 아니다)',
      not h4 and sk4 == 8, '밀림 %d · 못 잼 %d' % (len(h4), sk4))

    # 번역 차이(아무 데도 없다)는 밀림이 아니다
    odd = {i: {'H999%d' % i} for i in range(1, 9)}
    h5, _s = shifted(odd, base, order)
    t('★★ 아무 이웃과도 안 닮으면 **밀림이 아니다**(번역 차이)', not h5)

    # 실 DB — 읽기만
    if os.path.exists(WDB):
        c = appdb.connect(DB)
        wc = sqlite3.connect(WDB)
        try:
            wlc, bs, od, _ix = load(c, wc)
            # ⚠ 기준은 **구약 절만** 센다 — `_codes` 가 `H` 로 시작하는 것만
            #   고르므로 신약(G 코드)은 빈 집합이 되어 빠진다. 그것이 옳다.
            t('실 DB — 원문·기준을 읽는다', len(wlc) > 20000 and len(bs) > 20000,
              '원문 %d · 기준(구약) %d' % (len(wlc), len(bs)))
            ts = text_same(c, wc)
            t('★★ 배포 본문이 검증 원문과 **글자 그대로 같다**',
              ts['diff'] == 0, '다르다 %d' % ts['diff'])
        finally:
            wc.close()
            c.close()
    else:
        t('실 DB 확인', False, '검증 원문이 없다 — **못 쟀다**')

    print('db_wlc_align_check selftest %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--all', action='store_true',
                    help='얇은 태깅까지 판정한다(오탐이 는다)')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    r = check(min_base=1 if a.all else MIN_BASE)
    if r.get('ok') is None:
        sys.exit(2)
    print('판정: %s' % ('✅ 제자리' if r['ok'] else '⚠ 밀린 절이 있다'))
    sys.exit(0 if r['ok'] else 1)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                        # noqa: BLE001
        pass
    main()
