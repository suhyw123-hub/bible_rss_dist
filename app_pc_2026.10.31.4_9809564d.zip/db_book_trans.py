# -*- coding: utf-8 -*-
"""도서 본문 번역 적재 — MODERN_EN · TRANSLATED (영구 도구)

  규약은 **`booktrans.md`** 가 단일 소스다. 이 파일은 그 §10 게이트를 기계로
  잰다. 규칙을 여기 베끼지 않는다 — 갈라진다.

  ★ **요약을 번역 자리에 넣지 못하게 막는 것이 이 도구의 첫째 목적이다.**
    2026-08-15 전수검사에서 설교집 1,608편이 원문의 4~7%짜리 요약인 채
    `MODERN_EN` 으로 들어가 있었고, 사용자가 「현대영어」를 눌러 요약을 봤다.
    (2026-08-23 사용자: 「내가 번역하라고 요구했는데 네가 임의로 요약해버렸다.
    매우 황당했었다.」) ⇒ **길이비 게이트가 이 도구의 심장이다.**

  초안 = `_trans_prep/<BOOK_CODE>.json`
      {"units": {"<sequence>": {"modern_en": "...", "ko": "..."}}}

  사용법
      python db_book_trans.py --selftest              (의무)
      python db_book_trans.py --dump KEMPIS_IOC 3 5   원문을 파일로
      python db_book_trans.py --check KEMPIS_IOC
      python db_book_trans.py --apply KEMPIS_IOC      (멱등)
      python db_book_trans.py --status KEMPIS_IOC
"""
import io
import json
import os
import re
import sys

try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
DRAFT_DIR = os.path.join(HERE, '_trans_prep')

# ── 길이비 (booktrans.md §10). MODERN_EN 은 같은 언어라 원문과 거의 같아야 한다.
#    KO 는 한국어가 영어보다 글자 수가 적으므로 띠가 다르다 — **표본에서 실측해
#    좁힌다.** 지금 값은 「요약을 잡는다」는 목적에만 맞춘 넓은 띠다.
#    KO 띠는 **실측으로 좁혔다** — 켐피스 표본 두 편이 둘 다 0.48 이었다
#    (#3 2159→1032 · #41 1418→682). 한국어는 같은 내용을 영어의 절반쯤 되는
#    글자 수로 담는다. 0.35 아래면 줄인 것이고 0.70 위면 늘린 것이다.
#    ⚠ 책마다 다시 잰다 — 고유명사가 많은 책은 음역 때문에 비율이 올라간다.
RATIO = {'modern_en': (0.85, 1.15), 'ko': (0.35, 0.70)}
VARIANT = {'modern_en': ('MODERN_EN', 'EN'), 'ko': ('TRANSLATED', 'KO')}

# ── 옛말. ⚠ booktrans.md §2 경고 — 낱말만 보면 오탐이 난다.
#    `art`(the art of), `wilt`(시들다), `year`·`yet` 속의 `ye` 는 멀쩡한 현대어다.
#    그래서 **홀로 서도 옛말인 것만** 넣고, 짝으로만 옛말인 것은 짝으로 잡는다.
_ARCHAIC = (r"\b(?:thee|thou|thy|thine|hath|doth|saith|shalt|hast|didst|dost|"
            r"wouldest|couldest|shouldest|unto|yea|nay|whither|thence|hither|"
            r"cometh|goeth|maketh|giveth|beareth|knoweth|seeketh|loveth|"
            r"profiteth|neglecteth|serveth|watcheth|deemeth|counteth|"
            r"betwixt|oft|ere|verily|behooveth|methinks)\b")
_ARCHAIC_RE = re.compile(_ARCHAIC, re.I)
# 짝으로만 옛말인 것 (`thou art` 는 위 `thou` 가 이미 잡는다 — 여기는 나머지)
_ARCHAIC_PAIR_RE = re.compile(r"\bye\s+(?:are|shall|have|know|will|may)\b", re.I)

_HANGUL = re.compile(r'[가-힣]')
_ATTRIB_RE = re.compile(r'(?m)^—\s')          # 출처 한 줄 (본문 끝)
# ⚠ 원문 안에 출처가 **두 번** 든 책이 있다 — 적재기가 넣은 `-- 저자, 제목 (연도)`
#   한 줄이 끝의 `— 저자, "제목" (기관). Public domain.` 과 같은 말을 되풀이한다
#   (실측 MURRAY_AIC 29편 · SMITH_CSHL 22편). 번역판은 그 줄을 빼므로 원문보다
#   **늘 한 줄 적어지고**, 원문이 9줄이면 허용 오차가 0 이라 그대로 FAIL 이 된다
#   (머레이 10·11·14 편이 실제로 그렇게 걸려 있었다).
#   ⚠ **`^--` 를 통째로 떼면 안 된다** — 파스칼 9줄·매클라렌 1줄·스펄전 1줄은
#     진짜 본문이 그 두 글자로 시작한다(실측). **출처 모양만** 뗀다.
_ATTRIB2_RE = re.compile(r'(?m)^--\s*[A-Z][\w.\'’ ]+,\s+.+\(\d{4}\)\s*$')
# 출판사·전사자 노트. **§5 가 번역판에서 빼라고 못 박은 것**이라, 원문 쪽에
# 남겨 두면 올바르게 옮긴 번역이 「문단이 줄었다」로 걸린다(머레이 9편 실측).
# ⚠ 전 코퍼스에 **한 줄뿐**이다 — 넓히지 말 것.
_PUBNOTE_RE = re.compile(r"^(Publisher's|Transcriber's)\s+Note\s*:", re.I)
_ROMAN_REF = re.compile(r'\b[A-Z][a-z]+\.?\s+[ivxlc]+\.\s*\d+')   # Psalm xciv. 12


def _is_apparatus(line):
    """본문이 아닌 출처 한 줄인가 (두 표기 모두)."""
    return bool(_ATTRIB_RE.match(line) or _ATTRIB2_RE.match(line)
                or _PUBNOTE_RE.match(line.strip()))


# ───────────────────────────── 조회

def book_row(conn, code):
    r = conn.execute(
        "SELECT book_id, COALESCE(title,'') FROM sys_book_asset WHERE book_code=?",
        (code,)).fetchone()
    if not r:
        raise SystemExit('도서 %s 가 없습니다.' % code)
    return r[0], r[1]


def originals(conn, code):
    """{sequence: (unit_id, unit_label, original_text)} — LIVE 만."""
    bid, _ = book_row(conn, code)
    out = {}
    for s, uid, lab, body in conn.execute(
            "SELECT u.sequence, u.unit_id, u.unit_label, x.body_text "
            "  FROM sys_book_unit u "
            "  JOIN sys_book_unit_text x ON x.unit_id = u.unit_id "
            "   AND x.text_variant='ORIGINAL' "
            "   AND COALESCE(x.record_status,'LIVE')='LIVE' "
            " WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'", (bid,)):
        out[s] = (uid, lab or '', body or '')
    return out


def draft_path(code):
    return os.path.join(DRAFT_DIR, '%s.json' % code)


def load_draft(code):
    p = draft_path(code)
    if not os.path.exists(p):
        return {}
    with open(p, encoding='utf-8') as f:
        d = json.load(f)
    return {int(k): v for k, v in (d.get('units') or d).items()}


# ───────────────────────────── 게이트

def body_only(text):
    """출처 한 줄을 뗀 본문 — 길이·구조를 잴 때는 이것으로."""
    lines = [ln for ln in (text or '').split('\n') if not _is_apparatus(ln)]
    return '\n'.join(lines).strip()


def paragraphs(text):
    return [p for p in re.split(r'\n\s*\n', body_only(text)) if p.strip()]


def lines(text):
    """빈 줄이 아닌 줄.

    ⚠ 책마다 문단을 나누는 방법이 다르다 — 켐피스는 절 사이를 **빈 줄이 아니라
      홑 줄바꿈**으로 나눈다. 그래서 `paragraphs()` 로만 재면 어느 편이든 1문단
      이라 구조 검사가 아무것도 안 잡는다(실측으로 잡았다). **둘 다 잰다.**
    """
    return [ln for ln in body_only(text).split('\n') if ln.strip()]


# ⚠ **낱말 안에 박힌 `?` 는 물음표가 아니다** (2026-08-29 마이어 #15 에서 잡았다).
#   스캔이 글자를 `?` 로 잘못 읽거나 줄표를 `?` 로 옮긴 자리다 —
#   `flaj?iing`(flaming) · `co?fessio?i`(confession) · `retain?the`(retain—the).
#   그것을 물음표로 세면 게이트가 **구조가 아니라 손상을 잰다.** 원문에 없는
#   물음표를 번역에 지어 넣어야 통과하는 꼴이라 §3(구조 보존)과 정면으로 어긋난다.
#   ★ 가르는 잣대는 **바로 뒤 글자** 하나다 — 실측 59건이 정확히 갈렸다:
#     소문자·숫자가 뒤따르면 58건 전부 오식·줄표 / 대문자가 뒤따르는 1건
#     (`love?Then`, 스펄전 #1133)은 **띄어쓰기만 잃은 진짜 물음표**다.
#     물음표 다음에 소문자·숫자가 **붙어서** 오는 진짜 문장은 없다.
#   ⚠ **앞 글자를 보면 안 된다** — 처음에 `앞이 글자일 때`로 좁혔다가 아홉을
#     놓쳤다. 스캔은 `m` 을 **`?n`(공백 뒤)**으로도 읽는다: `We ?nust`=must ·
#     `p€r??iits`=permits · `??iystery`=mystery · `?night`=might · `?narg.`=marg.
#     **물음표는 낱말을 시작할 수 없다** — 앞을 보지 않는 편이 옳고 더 단순하다.
#   ⚠ 숫자까지 보는 것도 그래서다 — `e?2Joyed`=enjoyed · `7?ie`=me · `7?iore`=more.
#   ⚠ **물음표가 잇단 자리도 본다**(`p€r??iits`=permits · `??iystery`=mystery,
#     실측 2건뿐이고 둘 다 오식). 뒤엣것만 걷으면 앞엣것이 남아 하나로 세어진다.
#   ⚠ **`/ > ^` 도 넣는다** — 물음표 뒤에 오는 글자를 전 코퍼스에서 세어 보니
#     따옴표(`”` 15,974 · `"` 906) · 줄표 538 · 괄호 68 은 **전부 정상**이고,
#     이 셋만 오식 전용이었다(`/^-i?/^/`=from · `/<?^/`=see · `6^<?>/`=Lord,
#     여섯 자리 전부 마이어). **뒤 글자를 세어 보고 고른 것이지 짐작이 아니다.**
#   ⏭ `?Iis`(=His, 마이어 #722) 한 자리는 **대문자가 뒤따라 못 거른다** —
#     `love?Then`(진짜 물음표)과 생김새가 같다. 그 편을 옮길 때 손으로 본다.
#   ⚠ 한국어에는 이 꼴이 없어 번역 쪽에서는 아무 일도 하지 않는다.
_Q_INWORD = re.compile(r'\?(?=[a-z0-9?/>^])')


def count_q(text):
    """문장 부호로서의 물음표만 센다."""
    return _Q_INWORD.sub('', text or '').count('?')


def check_one(seq, key, trans, orig):
    """한 편 한 언어를 잰다 → 문제 목록."""
    bad = []
    t = (trans or '').strip()
    if not t:
        return ['빈 본문']
    ob, tb = body_only(orig), body_only(t)
    if not ob:
        return bad                            # 표지 편 — 잴 것이 없다
    lo, hi = RATIO[key]
    ratio = len(tb) / len(ob)
    # ⚠ 아주 짧은 편(책 표지·머리글)에는 길이비를 걸지 않는다 — 60자짜리
    #   「THE FIRST BOOK」을 「제1권」으로 옮기면 비율이 0.28 이 되는데, 그것은
    #   요약이 아니라 한국어가 원래 짧은 것이다. 산문에만 잰다.
    if len(ob) < 200:
        pass
    elif ratio < lo:
        bad.append('길이비 %.2f — 줄었다 (요약 의심, 하한 %.2f)' % (ratio, lo))
    elif ratio > hi:
        bad.append('길이비 %.2f — 늘었다 (덧붙임 의심, 상한 %.2f)' % (ratio, hi))
    if not _ATTRIB_RE.search(t):
        bad.append('출처 한 줄 없음')
    # 구조 (booktrans.md §3)
    # ⚠ 문단·물음표는 **작은 편에서 엄격해야** 뜻이 있다. `max(1, n//5)` 로 두면
    #   문단 2개짜리에서 1개로 합쳐도 통과한다(자가검증이 잡았다). n//10 이면
    #   10문단 미만은 정확히 같아야 하고, 큰 편만 여유를 준다.
    po, pt = len(paragraphs(orig)), len(paragraphs(t))
    if po and abs(po - pt) > po // 10:
        bad.append('문단 %d → %d' % (po, pt))
    lo_, lt = len(lines(orig)), len(lines(t))
    if lo_ and abs(lo_ - lt) > lo_ // 10:
        bad.append('줄 %d → %d' % (lo_, lt))
    qo, qt = count_q(ob), count_q(tb)
    if abs(qo - qt) > qo // 10:
        bad.append('물음표 %d → %d' % (qo, qt))
    # 언어
    if key == 'modern_en':
        arch = sorted({m.group(0).lower() for m in _ARCHAIC_RE.finditer(tb)}
                      | {m.group(0).lower() for m in _ARCHAIC_PAIR_RE.finditer(tb)})
        if arch:
            bad.append('옛말 잔존: %s' % ', '.join(arch[:6]))
        if _HANGUL.search(tb):
            bad.append('한글이 섞임')
        if _ROMAN_REF.search(tb):
            bad.append('로마 숫자 성경 참조 (Psalm xciv. 12 꼴)')
    else:
        if not _HANGUL.search(tb):
            bad.append('한글이 없음')
    return bad


def check(conn, code, draft=None, verbose=True):
    orig = originals(conn, code)
    draft = load_draft(code) if draft is None else draft
    problems, done = [], {'modern_en': 0, 'ko': 0}
    for s in sorted(draft):
        if s not in orig:
            problems.append((s, '-', '그런 편이 없다'))
            continue
        for key in ('modern_en', 'ko'):
            if not (draft[s].get(key) or '').strip():
                continue
            done[key] += 1
            for b in check_one(s, key, draft[s][key], orig[s][2]):
                problems.append((s, key, b))
    if verbose:
        print('%s — 원문 %d편 · 초안 %d편' % (code, len(orig), len(draft)))
        print('  MODERN_EN %d / %d · KO %d / %d'
              % (done['modern_en'], len(orig), done['ko'], len(orig)))
        print('  게이트 위반 %d건' % len(problems))
        for s, k, b in problems[:40]:
            print('   #%-4d %-10s %s' % (s, k, b))
        if len(problems) > 40:
            print('   … 외 %d건' % (len(problems) - 40))
    return problems


# ───────────────────────────── 적재

def apply(conn, code, draft=None, dry=False):
    orig = originals(conn, code)
    draft = load_draft(code) if draft is None else draft
    ins = upd = same = 0
    for s in sorted(draft):
        if s not in orig:
            continue
        uid = orig[s][0]
        for key in ('modern_en', 'ko'):
            txt = (draft[s].get(key) or '').strip()
            if not txt:
                continue
            variant, lang = VARIANT[key]
            row = conn.execute(
                "SELECT text_id, body_text FROM sys_book_unit_text "
                " WHERE unit_id=? AND text_variant=? AND UPPER(lang_code)=?",
                (uid, variant, lang)).fetchone()
            if row is None:
                if not dry:
                    conn.execute(
                        "INSERT INTO sys_book_unit_text "
                        "(unit_id, text_variant, lang_code, body_text, record_status) "
                        "VALUES (?,?,?,?,'LIVE')", (uid, variant, lang, txt))
                ins += 1
            elif (row[1] or '') != txt:
                if not dry:
                    conn.execute(
                        "UPDATE sys_book_unit_text SET body_text=?, "
                        "record_status='LIVE' WHERE text_id=?", (txt, row[0]))
                upd += 1
            else:
                same += 1
    if not dry:
        conn.commit()
    print('%s 새로 %d · 고침 %d · 그대로 %d'
          % ('[모의]' if dry else '[적재]', ins, upd, same))
    return ins, upd, same


def dump(conn, code, a, b):
    """원문을 파일로 — 옮기기 전에 눈으로 볼 때."""
    orig = originals(conn, code)
    d = os.path.join(HERE, '_%s_raw' % code.lower())
    os.makedirs(d, exist_ok=True)
    n = 0
    for s in sorted(orig):
        if a <= s <= b:
            with open(os.path.join(d, 'ch%03d.txt' % s), 'w', encoding='utf-8') as f:
                f.write('# %s\n\n%s' % (orig[s][1], orig[s][2]))
            n += 1
    print('%s → %d편' % (d, n))


def status(conn, code):
    orig = originals(conn, code)
    bid, _ = book_row(conn, code)
    for variant, lang in (('MODERN_EN', 'EN'), ('TRANSLATED', 'KO')):
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_book_unit_text x "
            "  ON x.unit_id=u.unit_id AND x.text_variant=? AND UPPER(x.lang_code)=? "
            "   AND COALESCE(x.record_status,'LIVE')='LIVE' "
            " WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'",
            (variant, lang, bid)).fetchone()[0]
        print('  %-10s %-3s %4d / %d' % (variant, lang, n, len(orig)))


# ───────────────────────────── 자가 검증

def selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    # ⚠⚠ **표본은 반드시 길이비 면제선(200자)보다 길어야 한다.**
    #   표지 편을 봐주려고 `len(ob) < 200` 면제를 넣은 날, 짧던 이 표본이 함께
    #   면제되어 **「요약을 잡는다」 세 항목이 조용히 통과**했다(2026-08-23 실측).
    #   ⇒ 같은 덩이를 세 번 이어 400자 남짓으로 만든다. 구조(줄·문단·물음표)는
    #     원문과 번역이 똑같이 늘어나므로 다른 항목은 그대로 산다.
    _O = ("He who knoweth himself well is vile in his own sight.\n"
          "What doth it profit thee to argue? Is it not vanity?\n\n"
          "Better a lowly peasant who serveth God.\n\n")
    _E = ("Anyone who knows himself well is lowly in his own sight.\n"
          "What does it profit you to argue? Is that not vanity?\n\n"
          "Better a humble peasant who serves God.\n\n")
    _K = ("자기를 잘 아는 사람은 자기 눈에 보잘것없습니다.\n"
          "따져서 무슨 유익이 있습니까? 그것도 헛됨이 아닙니까?\n\n"
          "하나님을 섬기는 낮은 농부가 낫습니다.\n\n")
    ORIG = _O * 3 + "— Thomas a Kempis, \"The Imitation of Christ\""
    GOOD_EN = _E * 3 + "— Modern English adaptation"
    GOOD_KO = _K * 3 + "— 토마스 아 켐피스"

    # ★ 잡아야 할 것 — 요약이 첫째다
    t('요약을 잡는다 (EN)', any('길이비' in b for b in
                            check_one(1, 'modern_en', 'He knows himself.\n— x', ORIG)))
    t('요약을 잡는다 (KO)', any('길이비' in b for b in
                            check_one(1, 'ko', '자기를 안다.\n— x', ORIG)))
    t('부풀림을 잡는다', any('늘었다' in b for b in
                        check_one(1, 'modern_en', (GOOD_EN + ' and more words. ') * 2, ORIG)))
    t('빈 본문', check_one(1, 'ko', '', ORIG) == ['빈 본문'])
    t('출처 줄 없음', any('출처' in b for b in
                      check_one(1, 'modern_en', GOOD_EN.split('\n—')[0], ORIG)))
    t('옛말 잔존', any('옛말' in b for b in
                    check_one(1, 'modern_en', GOOD_EN.replace('does', 'doth'), ORIG)))
    # ⚠ 출처 줄 뒤에 붙이면 `body_only` 가 떼어 버려 안 잡힌다 — **본문 안에** 넣는다
    t('EN 에 한글', any('한글이 섞임' in b for b in
                     check_one(1, 'modern_en',
                               GOOD_EN.replace('vanity', 'vanity 헛됨'), ORIG)))
    t('KO 에 한글 없음', any('한글이 없음' in b for b in
                        check_one(1, 'ko', GOOD_EN, ORIG)))
    t('로마 숫자 참조', any('로마 숫자' in b for b in
                       check_one(1, 'modern_en',
                                 GOOD_EN + '\n(1) Psalm xciv. 12', ORIG)))
    t('물음표 사라짐', any('물음표' in b for b in
                      check_one(1, 'modern_en', GOOD_EN.replace('?', '.'), ORIG)))
    t('문단 합침', any('문단' in b for b in
                    check_one(1, 'modern_en', GOOD_EN.replace('\n\n', '\n'), ORIG)))
    t('줄 합침 (홑 줄바꿈 책)', any('줄 ' in b for b in
                             check_one(1, 'modern_en',
                                       GOOD_EN.replace('sight.\nWhat', 'sight. What'),
                                       ORIG)))

    # ★ 통과해야 할 것 — 오탐 시험 (booktrans.md §2)
    t('정상 EN 통과', not check_one(1, 'modern_en', GOOD_EN, ORIG))
    t('정상 KO 통과', not check_one(1, 'ko', GOOD_KO, ORIG))
    # ── 낱말 안 물음표 (2026-08-29) ────────────────────────────────────────
    t('오식 물음표는 안 센다 · flaj?iing', count_q('God as a flaj?iing Torch.') == 0)
    t('오식 물음표는 안 센다 · co?fessio?i', count_q('Faith prompts to co?fessio?i.') == 0)
    t('줄표 자리도 안 센다 · retain?the', count_q('may have and retain?the art') == 0)
    t('★ 낱말 앞의 오식도 안 센다 · ?nust', count_q('We ?nust reckon on it.') == 0)
    t('★ 낱말 앞의 오식도 안 센다 · ?night', count_q('as it ?night be.') == 0)
    t('겹친 오식도 안 센다 · p€r??iits', count_q('what He p€r??iits.') == 0)
    t('기호가 뒤따르는 오식도 안 센다 · i?/',
       count_q('We must be separated /^-i?/^/ sin and sinners.') == 0)
    t('기호가 뒤따르는 오식도 안 센다 · <?>',
       count_q('Jesus, our 6^<?>/and Redeemer, liveth.') == 0)
    # ⚠ 따옴표·줄표·괄호가 뒤따르는 것은 **진짜 물음표**다 (실측 17,000건)
    t('★ 따옴표가 뒤따르면 센다', count_q('kept the door of my lips?” What then.') == 1)
    t('★ 줄표가 뒤따르면 센다', count_q('eateth unworthily”—what?—“damnation.') == 1)
    t('★ 괄호가 뒤따르면 센다', count_q('who can hear it?) to give each what.') == 1)
    t('숫자가 섞인 오식도 안 센다 · e?2Joyed', count_q('WJiat he e?2Joyed.') == 0)
    t('숫자가 섞인 오식도 안 센다 · 7?ie', count_q('the grace of God with 7?ie.') == 0)
    t('★ 진짜 물음표는 센다 · love?Then',
       count_q('with your truest love?Then you have the Spirit') == 1)
    t('보통 물음표는 그대로', count_q('Where art thou ? And where is he?') == 2)
    t('한국어는 그대로', count_q('그대는 어디 있습니까? 아우는 어디 있습니까?') == 2)
    t('물음표 없으면 0', count_q('There is none here.') == 0)
    # 탐지력 — 오식을 세면 원문 2 · 번역 1 이 되어 FAIL 이 나야 정상이었다
    t('오식 때문에 FAIL 하지 않는다',
       not any('물음표' in b for b in check_one(
           1, 'ko', GOOD_KO, ORIG.replace('one', 'o?ne'))))
    t('the art of 는 옛말 아님', not _ARCHAIC_RE.search('the art of holy living'))
    t('시든다 wilt 는 옛말 아님', not _ARCHAIC_RE.search('the flower wilt and fade'))
    t('year 속 ye 는 옛말 아님', not _ARCHAIC_RE.search('this year and yet more'))
    t('yes 는 yea 가 아님', not _ARCHAIC_RE.search('yes indeed'))
    t('thou 는 잡는다', bool(_ARCHAIC_RE.search('thou art')))
    t('ye are 짝은 잡는다', bool(_ARCHAIC_PAIR_RE.search('ye are my friends')))
    t('표지 편은 잴 것이 없다', not check_one(1, 'ko', '표지\n— x', '— x'))

    # ★ 원문 안에 두 번 든 출처 (`-- 저자, 제목 (연도)`) — 떼는 쪽·지키는 쪽
    _DUP = ORIG.replace('— Thomas', '-- Thomas a Kempis, The Imitation (1418)\n\n— Thomas')
    t('두 하이픈 출처를 뗀다',
      len(lines(_DUP)) == len(lines(ORIG)))
    t('두 하이픈 출처가 있어도 정상 통과',
      not check_one(1, 'modern_en', GOOD_EN, _DUP))
    t('파스칼 본문 -- 은 지킨다',
      _is_apparatus('--Incomprehensible.--Not all that is incomprehensible.') is False)
    t('매클라렌 본문 -- 은 지킨다',
      _is_apparatus('--All in it (are) saying, "Glory."') is False)
    t('스펄전 본문 --Psalm 은 지킨다', _is_apparatus('--Psalm 38:21') is False)
    t('출판사 노트를 뗀다',
      _is_apparatus("Publisher's Note: reissued by Oliphants Ltd. in 1955.") is True)
    t('저자의 각주는 지킨다',
      _is_apparatus('1. "Holiness may be called spiritual perfection." --Bonar.') is False)
    t('번역판 출처는 여전히 em 대시라야 한다',
      any('출처' in b for b in
          check_one(1, 'modern_en',
                    GOOD_EN.replace('— Modern English adaptation',
                                    '-- Modern English adaptation (1895)'), ORIG)))

    # 적재 — 실 DB 에 넣었다 되돌린다
    conn = appdb.connect('bible_master.db')
    try:
        o = originals(conn, 'KEMPIS_IOC')
        t('켐피스 118편', len(o) == 118)
        seq = 3
        t('3편 있음', seq in o)
        uid = o[seq][0]
        # ⚠⚠ **자가 검증을 데이터 상태에 걸지 말 것**(§0-5 — 실제로 당했다).
        #   예전에는 「3편 MODERN_EN 자리가 비어 있다」를 전제로 넣었다 지웠는데,
        #   책을 다 번역하고 나니 그 DELETE 가 **진짜 번역을 지웠다**
        #   (2026-08-23 실측: 118 → 117). ⇒ 있든 없든 **찍어 두고 그대로 되돌린다.**
        SNAP_SQL = ("SELECT text_id, text_variant, lang_code, body_text, "
                    "record_status FROM sys_book_unit_text WHERE unit_id=? "
                    "AND text_variant IN ('MODERN_EN','TRANSLATED') "
                    "ORDER BY text_id")
        before = conn.execute(SNAP_SQL, (uid,)).fetchall()
        d = {seq: {'modern_en': '자가검증 임시', 'ko': '자가검증 임시'}}
        apply(conn, 'KEMPIS_IOC', d, dry=True)
        t('모의는 안 쓴다', conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text WHERE unit_id=? "
            "AND body_text='자가검증 임시'", (uid,)).fetchone()[0] == 0)
        apply(conn, 'KEMPIS_IOC', d)
        t('적재됨', conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text WHERE unit_id=? "
            "AND body_text='자가검증 임시'", (uid,)).fetchone()[0] == 2)
        i2, u2, s2 = apply(conn, 'KEMPIS_IOC', d)
        t('멱등', (i2, u2, s2) == (0, 0, 2))
        conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? "
                     "AND text_variant IN ('MODERN_EN','TRANSLATED')", (uid,))
        for row in before:
            conn.execute(
                "INSERT INTO sys_book_unit_text (text_id, unit_id, text_variant,"
                " lang_code, body_text, record_status) VALUES (?,?,?,?,?,?)",
                (row[0], uid, row[1], row[2], row[3], row[4]))
        conn.commit()
        t('시험 글 0', conn.execute(
            "SELECT COUNT(*) FROM sys_book_unit_text "
            "WHERE body_text='자가검증 임시'").fetchone()[0] == 0)
        t('원래대로 되돌림', conn.execute(SNAP_SQL, (uid,)).fetchall() == before)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect('bible_master.db')
    try:
        cmd = a[0]
        code = a[1] if len(a) > 1 else ''
        if cmd == '--dump':
            dump(conn, code, int(a[2]), int(a[3]))
        elif cmd == '--check':
            sys.exit(0 if not check(conn, code) else 1)
        elif cmd == '--apply':
            p = check(conn, code)
            if p:
                raise SystemExit('게이트를 통과하지 못했습니다 — 적재하지 않습니다.')
            apply(conn, code)
        elif cmd == '--status':
            status(conn, code)
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
