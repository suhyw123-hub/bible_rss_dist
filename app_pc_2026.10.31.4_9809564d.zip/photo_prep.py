# -*- coding: utf-8 -*-
"""photo_prep — 시작화면·말씀카드 사진 한 장을 세 가지로 만든다 (2026-10-11 · 영구 · --selftest 의무).

사용자 결정(2026-10-11): 사진은 직접 찍은 것 · JPEG 로 줄인다 · 오른쪽 아래 「Hagah Dabar」(시작화면·카드 둘 다) ·
관리자가 사진을 고르면 샘플 구절로 표시를 시험한다 · 오늘 사진은 구절 주제(장면)에 맞춘다 · 폰 카드 사진은 자동만.

  variants(원본 경로|바이트, crop) → {'splash': jpg, 'card': jpg, 'thumb': png, 'orig_size': (w,h)}
      시작화면 1920×1200(16:10) · 말씀카드 1080×1350(4:5) · 목록용 240×150
      crop = {'splash': (cx, cy), 'card': (cx, cy)} — 잘라 낼 자리의 가운데(0~1). 없으면 가운데.
  render_card(card_jpg, 구절, 출처, lang) → PIL 그림(1080×1350) · 관리자 미리보기용
  render_splash(splash_jpg, 구절, 출처, lang) → PIL 그림(1920×1200) · 관리자 미리보기용
  draw_credit(img, scale, text, caption, lang) — 오른쪽 아래 「Hagah Dabar」 · 왼쪽 아래 사진 설명(찍은 곳 등)

★ 표시 모양의 단일 소스 = CARD_SPEC · SPLASH_SPEC · CREDIT. 폰(Flutter)의 말씀카드가 같은 값을 쓴다
  (mobile/lib/ui/share_util.dart 머리글에 이 파일을 적어 둔다). 한쪽만 고치면 미리보기와 실제가 갈린다.
★ 「Hagah Dabar」는 사진 파일에 굽지 않는다 — 그릴 때 얹는다(크기·위치를 바꿔도 사진을 다시 보낼 필요가 없다).
⚠ 아랍어는 이 미리보기에서 글자가 이어지지 않는다(PIL 에 raqm 없음) — 폰에서는 바르게 나온다.
"""
import io
import os
import re

from PIL import Image, ImageDraw, ImageFont

SPLASH_SIZE = (1920, 1200)
CARD_SIZE = (1080, 729)     # ★ 2026-10-30 폰 말씀카드와 같은 모양(높이 = 폭 × 0.675 · mobile cardAspect) — PC·폰 통일(사용자)
THUMB_SIZE = (240, 150)
JPEG_Q = 84                 # 기본 품질 — 관리자 화면에서 바꾼다
CREDIT = {'text': 'Hagah Dabar', 'size': 0.026, 'margin': 0.035, 'alpha': 205}   # 폭 대비 비율
#: ★ 출처 문구는 관리자가 언제든 고친다(2026-10-11 사용자 지시) — sys_config 한 칸 · 비우면 안 그린다.
CREDIT_KEY = 'PHOTO_CREDIT'


def credit_text(conn=None):
    """지금 출처 문구 — 설정이 없으면 'Hagah Dabar' · 빈칸으로 저장하면 ''(안 그린다)."""
    if conn is not None:
        try:
            r = conn.execute('SELECT config_val FROM sys_config WHERE config_key=?', (CREDIT_KEY,)).fetchone()
            if r is not None:
                return (r[0] or '').strip()
        except Exception:
            pass
    return CREDIT['text']


def set_credit(conn, text):
    conn.execute('INSERT INTO sys_config(config_key, config_val) VALUES(?,?) '
                 'ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val', (CREDIT_KEY, (text or '').strip()))
    conn.commit()
# ★ 2026-10-30 폰 PhotoVerseCard(card_page.dart)와 같은 값 — 어둡게 0x50 · 글자 폭 84% · 최대 폭×0.050 · 최소 ×0.026 ·
#   줄 높이 1.42 · 출처 0.62 · 글자 칸 = 높이 × 0.80(멘트 없을 때). 한쪽만 고치면 PC 미리보기가 폰과 달라진다.
CARD_SPEC = {'dim': 80,               # 사진 전체를 어둡게(0~255)
             'box_w': 0.84,           # 구절 글자 폭(카드 폭 대비)
             'verse_max': 0.050,      # 구절 글자 최대 크기(카드 폭 대비)
             'verse_min': 0.026,
             'line_gap': 0.42,        # 줄 사이(글자 크기 대비)
             'ref_ratio': 0.62,       # 출처 글자 = 구절 글자 × 이것
             'box_h': 0.80,
             'verse_weight': 'Medium'}           # 구절 + 출처가 들어갈 높이(카드 높이 대비)
SPLASH_SPEC = {'band_h': 0.22, 'band_alpha': 120, 'verse': 0.024, 'ref_ratio': 0.75}

FONT_DIR = os.path.join(os.environ.get('WINDIR', 'C:/Windows'), 'Fonts')
FONTS = {'KO': ['NotoSansKR-VF.ttf', 'malgun.ttf'], 'JA': ['YuGothM.ttc', 'msgothic.ttc'],
         'ZH': ['YuGothM.ttc', 'msgothic.ttc'], 'ZHT': ['YuGothM.ttc', 'msgothic.ttc'],
         'AR': ['NotoSansArabic-Regular.ttf', 'arial.ttf'], '*': ['NotoSans-Regular.ttf', 'arial.ttf', 'malgun.ttf']}
CREDIT_FONT = ['NotoSerif-Regular.ttf', 'georgia.ttf', 'NotoSans-Regular.ttf', 'arial.ttf']


def _font(lang, size, names=None, weight='Regular'):
    for n in (names or FONTS.get((lang or '').upper()) or FONTS['*']):
        p = os.path.join(FONT_DIR, n)
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, int(size))
            except OSError:
                continue
            try:                                   # 가변 글꼴은 굵기를 고른다(기본이 가장 가는 것이라 사진 위에서 안 읽힌다)
                if weight.encode() in f.get_variation_names():
                    f.set_variation_by_name(weight)
            except Exception:
                pass
            return f
    return ImageFont.load_default()


def _open(src):
    if isinstance(src, Image.Image):
        return src.convert('RGB')
    img = Image.open(io.BytesIO(src) if isinstance(src, (bytes, bytearray)) else src)
    try:                                    # 폰 사진의 회전 정보
        from PIL import ImageOps
        img = ImageOps.exif_transpose(img)
    except Exception:
        pass
    return img.convert('RGB')


def crop_box(size, target, center=(0.5, 0.5)):
    """원본 size 에서 target 비율로 가장 크게 잘라 낼 자리 — center(0~1)를 가운데로, 가장자리는 넘지 않게."""
    ow, oh = size
    tw, th = target
    r = tw / th
    if ow / oh > r:
        cw, ch = int(oh * r), oh
    else:
        cw, ch = ow, int(ow / r)
    cx, cy = center
    left = min(max(int(cx * ow - cw / 2), 0), ow - cw)
    top = min(max(int(cy * oh - ch / 2), 0), oh - ch)
    return left, top, left + cw, top + ch


def _jpg(img, q):
    buf = io.BytesIO()
    img.save(buf, 'JPEG', quality=int(q), optimize=True, progressive=True)
    return buf.getvalue()


def cut(img, kind, center=(0.5, 0.5)):
    """열린 그림에서 kind('splash'|'card') 꼴로 잘라 그 크기로 — 미리보기·만들기가 함께 쓴다."""
    size = SPLASH_SIZE if kind == 'splash' else CARD_SIZE
    return img.crop(crop_box(img.size, size, center)).resize(size, Image.LANCZOS)


def variants(src, crop=None, quality=JPEG_Q):
    crop = crop or {}
    img = _open(src)
    out = {'orig_size': img.size}
    s = cut(img, 'splash', crop.get('splash', (0.5, 0.5)))
    c = cut(img, 'card', crop.get('card', (0.5, 0.5)))
    out['splash'] = _jpg(s, quality)
    out['card'] = _jpg(c, quality)
    t = s.resize(THUMB_SIZE, Image.LANCZOS)
    buf = io.BytesIO()
    t.save(buf, 'PNG', optimize=True)
    out['thumb'] = buf.getvalue()
    return out


def to_png(jpg_bytes):
    """JPEG → PNG 바이트(사용자 PC 시작화면 캐시는 Tk 가 읽는 PNG 여야 한다)."""
    buf = io.BytesIO()
    _open(jpg_bytes).save(buf, 'PNG', optimize=True)
    return buf.getvalue()


# ── 그리기 ─────────────────────────────────────────────────────────────────
def _wrap(draw, text, font, width, lang):
    """폭에 맞춰 줄을 나눈다 — 띄어쓰기 없는 글(중·일)은 글자 단위."""
    cjk = (lang or '').upper() in ('ZH', 'ZHT', 'JA')
    units = list(text) if cjk else text.split(' ')
    lines, cur = [], ''
    for u in units:
        t = (cur + u) if (cjk or not cur) else cur + ' ' + u
        if draw.textlength(t, font=font) <= width or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = u
    if cur:
        lines.append(cur)
    return lines


def caption_text(conn, img_id, lang='KO'):
    """사진 설명 한 줄 = `제목 · 설명`(그 언어 → EN → 아무 언어) — 시작화면 띠가 쓰던 것과 같은 글."""
    try:
        import db_splash_scene as SC
        ti, de = SC.photo_text(conn, img_id, lang, 'SYS')
    except Exception:
        return ''
    return ' · '.join(x for x in (ti, de) if (x or '').strip() and x != '')


def fit_line(d, text, font, room):
    """한 줄에 넣는다 — 넘치면 뒤를 잘라 `…`."""
    if d.textlength(text, font=font) <= room:
        return text
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi) // 2
        if d.textlength(text[:mid] + '…', font=font) <= room:
            lo = mid + 1
        else:
            hi = mid
    return text[:max(1, lo - 1)] + '…'


def draw_credit(img, scale=None, text=None, caption='', lang='KO'):
    """오른쪽 아래 출처 · 왼쪽 아래 사진 설명(2026-10-11 사용자 지시 — 시작화면·카드 모두 사진 위에)."""
    text = CREDIT['text'] if text is None else text
    if not text and not caption:
        return img
    w, h = img.size
    d = ImageDraw.Draw(img, 'RGBA')
    sz = w * (scale or CREDIT['size'])
    m = w * CREDIT['margin']
    tw = 0
    if text:
        f = _font('*', sz, CREDIT_FONT)
        tw = d.textlength(text, font=f)
        x, y = w - m - tw, h - m - f.size
        d.text((x + 1, y + 1), text, font=f, fill=(0, 0, 0, 120))
        d.text((x, y), text, font=f, fill=(255, 255, 255, CREDIT['alpha']))
    if caption:
        f = _font(lang, sz)
        room = w - 2 * m - tw - (m if tw else 0)
        cap = fit_line(d, caption, f, room)
        y = h - m - f.size
        d.text((m + 1, y + 1), cap, font=f, fill=(0, 0, 0, 120))
        d.text((m, y), cap, font=f, fill=(255, 255, 255, CREDIT['alpha']))
    return img


def render_card(card_jpg, verse, ref, lang='KO', credit=None, caption=''):
    img = _open(card_jpg).resize(CARD_SIZE)
    W, H = img.size
    sp = CARD_SPEC
    img = Image.alpha_composite(img.convert('RGBA'), Image.new('RGBA', img.size, (0, 0, 0, sp['dim'])))
    d = ImageDraw.Draw(img, 'RGBA')
    bw, bh = W * sp['box_w'], H * sp['box_h']
    size = W * sp['verse_max']
    while True:                                       # 상자에 들어갈 때까지 글자를 줄인다
        f = _font(lang, size, weight=CARD_SPEC['verse_weight'])
        rf = _font(lang, size * sp['ref_ratio'], weight='Regular')
        lines = _wrap(d, verse, f, bw, lang)
        gap = size * sp['line_gap']
        total = len(lines) * size + (len(lines) - 1) * gap + size * 1.2 + rf.size
        if total <= bh or size <= W * sp['verse_min']:
            break
        size -= 2
    y = (H - total) / 2
    for ln in lines:
        x = (W - d.textlength(ln, font=f)) / 2
        d.text((x + 2, y + 2), ln, font=f, fill=(0, 0, 0, 110))
        d.text((x, y), ln, font=f, fill=(255, 255, 255, 255))
        y += size + gap
    y += size * 1.2 - gap
    x = (W - d.textlength(ref, font=rf)) / 2
    d.text((x, y), ref, font=rf, fill=(255, 255, 255, 225))
    out = {'overflow': total > bh, 'size': int(size), 'lines': len(lines)}
    img = draw_credit(img.convert('RGB'), text=credit, caption=caption, lang=lang)
    img.info.update(out)
    return img, out


def render_splash(splash_jpg, verse, ref, lang='KO', credit=None, caption=''):
    img = _open(splash_jpg).resize(SPLASH_SIZE).convert('RGBA')
    W, H = img.size
    sp = SPLASH_SPEC
    bh = int(H * sp['band_h'])
    band = Image.new('RGBA', (W, bh), (0, 0, 0, sp['band_alpha']))
    img.alpha_composite(band, (0, H - bh))
    d = ImageDraw.Draw(img, 'RGBA')
    f = _font(lang, W * sp['verse'], weight='Medium')
    rf = _font(lang, W * sp['verse'] * sp['ref_ratio'])
    lines = _wrap(d, verse, f, W * 0.80, lang)[:3]
    y = H - bh + bh * 0.16
    for ln in lines:
        d.text(((W - d.textlength(ln, font=f)) / 2, y), ln, font=f, fill=(255, 255, 255, 255))
        y += f.size * 1.35
    d.text(((W - d.textlength(ref, font=rf)) / 2, y), ref, font=rf, fill=(255, 255, 255, 220))
    img = draw_credit(img.convert('RGB'), CREDIT['size'] * 0.6, text=credit, caption=caption, lang=lang)
    return img, {'overflow': len(_wrap(d, verse, f, W * 0.80, lang)) > 3}


def selftest():
    ok = []

    def t(name, cond):
        ok.append(bool(cond))
        print(('PASS ' if cond else 'FAIL ') + name)
    base = Image.new('RGB', (4000, 3000), (40, 90, 140))
    ImageDraw.Draw(base).rectangle((0, 2600, 4000, 3000), fill=(200, 60, 40))   # 아래 띠(카드가 가로로 길어 위아래로 자른다 · 2026-10-30)
    buf = io.BytesIO()
    base.save(buf, 'JPEG', quality=90)
    v = variants(buf.getvalue())
    t('세 가지가 나온다', all(k in v for k in ('splash', 'card', 'thumb')))
    t('시작화면 1920×1200', Image.open(io.BytesIO(v['splash'])).size == SPLASH_SIZE)
    t('카드 1080×729(폰 모양)', Image.open(io.BytesIO(v['card'])).size == CARD_SIZE)
    t('JPEG 로 줄었다(원본보다 작다)', len(v['card']) < len(buf.getvalue()))
    left = variants(buf.getvalue(), {'card': (0.5, 0.0)})
    right = variants(buf.getvalue(), {'card': (0.5, 1.0)})
    pl = Image.open(io.BytesIO(left['card'])).getpixel((540, 660))
    pr = Image.open(io.BytesIO(right['card'])).getpixel((540, 660))
    t('자르는 자리가 정한 대로(아래로 옮기면 붉은 띠가 보인다)', pr[0] > 150 and pl[0] < 100)
    t('crop_box 가 가장자리를 넘지 않는다', crop_box((4000, 3000), CARD_SIZE, (1.2, -0.3))[0] >= 0)
    img, info = render_card(v['card'], '태초에 하나님이 천지를 창조하시니라', '창 1:1', 'KO')
    t('카드 그림 1080×1350', img.size == CARD_SIZE)
    t('짧은 구절은 넘치지 않는다', not info['overflow'])
    long = '여호와는 나의 목자시니 내가 부족함이 없으리로다 ' * 40
    img2, info2 = render_card(v['card'], long, '시 23:1', 'KO')
    t('긴 구절은 글자가 작아진다', info2['size'] < info['size'])
    t('아주 긴 구절은 넘침을 알린다', info2['overflow'])
    img3, _ = render_card(v['card'], 'Jesus wept.', 'John 11:35', 'EN')
    t('영어 카드도 그린다', img3.size == CARD_SIZE)
    s, si = render_splash(v['splash'], '태초에 하나님이 천지를 창조하시니라', '창 1:1', 'KO')
    t('시작화면 미리보기 1920×1200', s.size == SPLASH_SIZE)
    # 오른쪽 아래 출처가 그려졌는가(그 자리가 바탕보다 밝아진다)
    plain = _open(v['card'])
    H = CARD_SIZE[1]
    br = lambda im: sum(im.crop((900, H - 80, 1040, H - 30)).convert('L').tobytes())
    t('오른쪽 아래에 출처가 그려진다', br(draw_credit(plain.copy())) > br(plain))
    bl = lambda im: sum(im.crop((40, H - 80, 300, H - 30)).convert('L').tobytes())
    t('왼쪽 아래에 사진 설명이 그려진다', bl(draw_credit(plain.copy(), caption='갈릴리 호수 · 2024')) > bl(plain))
    t('설명이 없으면 왼쪽 아래는 그대로', bl(draw_credit(plain.copy())) == bl(plain))
    _d = ImageDraw.Draw(plain.copy())
    _f = _font('KO', 28)
    t('긴 설명은 한 줄로 줄인다(…)', fit_line(_d, '가' * 400, _f, 300).endswith('…'))
    t('PNG 로 바꿀 수 있다(시작화면 캐시)', to_png(v['splash'])[:4] == b'\x89PNG')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
