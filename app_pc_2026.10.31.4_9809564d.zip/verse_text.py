# -*- coding: utf-8 -*-
"""절 본문을 **화면에 낼 때 거치는 단 하나의 문**.

    python verse_text.py --selftest
    python verse_text.py --audit            # 역본별 차이 유형 집계
    python verse_text.py --verse 창24:30    # 한 절을 모든 역본에서

★★★ **왜 만들었나**(2026-09-19 사용자 「어떤 구절이든 어떤 버전이든 특정한
  구절을 클릭하면 **동일한 내용의 구절이 표시되어야 한다**. (), [] 등 필요한
  기호와 설명문을 추가해서라도 의미를 알 수 있도록 해야 한다」).
  ⚠⚠⚠ 같은 지적이 여러 번 나왔는데 그때마다 한두 화면만 고치고 끝났다.
    뿌리는 **`bible_content` 를 직접 읽는 자리가 39곳**이라는 것이다.
    공용 문이 없으니 고칠 자리가 39곳이고, 그래서 늘 몇 곳이 남았다.
  ⇒ **여기가 단일 소스다.** 화면은 `resolve()`·`texts()` 만 부른다.

★★★ **실측 — 지금 자리표가 여섯 가지로 갈려 있다**(2026-09-19 전수):
  | 꼴 | 수 | 역본 |
  |---|---|---|
  | `<Absent>`·`<없음>`·`<Fehlt>`·`<Ausente>`·`<Ἀπόν>`·`<缺>` | 165 | 13역본 |
  | `'a'` (**원본 결함**) | 70 | CUV |
  | `(18절에 포함되어 있음)` | 19 | KRV |
  | `✠` · `[—]` | 22 | COPCNT·COPSHC |
  | `併入上節` | 2 | CUV |
  | **행 자체가 없음** | 882 | RusSyn 785 · CUVS 73 … |
  ⚠ 그래서 **독일어 사용자가 포르투갈어 `<Ausente>` 를** 보고, 중국어
    사용자가 **`a` 를 성경 본문으로** 읽고 있었다.

★ **보완 규칙** — 사용자 지시대로 **기호와 설명문**을 붙인다.
  · 합쳐진 절  → `[29절에 합쳐져 있습니다]` + **그 29절 본문 그대로**
  · 없는 절    → `[이 역본에는 없는 절입니다]` + 있으면 그 역본 글, 없으면
                 다른 역본 본문을 **( ) 안에 · 어느 역본인지 밝혀서**
  · 못 구한 절 → `[본문을 구하지 못했습니다]` + 다른 역본 본문을 ( ) 안에
  ⚠ **글은 전부 `ui_strings`** — 한국어를 박지 않는다(11언어).
  ⚠ **빌려 온 본문임을 반드시 밝힌다** — 안 밝히면 그 역본이 그렇게 적은
    줄로 읽는다(그것이 더 나쁜 거짓말이다 §0-1).
"""
import io
import json
import os
import re
import sys
import unicodedata

#: 눈에 안 보이는 글자 — `TRIM` 이 못 걷는다(2026-09-19 실측으로 당했다)
INVIS = ('          '
         '   ​‌‍  ⁠　﻿')

#: 「이 역본에는 없는 절」 표식 — 역본마다 제 나라 말로 적어 두었다
ABSENT_WORDS = ('Absent', '없음', 'Fehlt', 'Ausente', 'Ἀπόν', '缺', 'Missing',
                'Отсутствует', 'غائب')

_RX_ANGLE = re.compile(r'^<([^>]{1,24})>\s*')
_RX_MERGE_TAG = re.compile(r'^<병합\s*(\d+):(\d+)\s*>\s*')
_RX_PAREN_KO = re.compile(r'^\(\s*(\d+)\s*절에 포함[^)]*\)\s*')
_RX_CJK_PREV = re.compile(r'^(併入上節|并入上节|併於上節)\s*')
_RX_CROSS = re.compile(r'^[✠✚†]\s*')
_RX_DASH = re.compile(r'^\[\s*[—–-]\s*\]\s*')

#: 차이 유형 — 화면·진단이 같은 낱말을 쓴다
OK, MERGED, ABSENT, MISSING, GARBAGE = (
    'OK', 'MERGED', 'ABSENT', 'MISSING', 'GARBAGE')

#: 유형마다 **왜 그런가**(관리자 진단이 그대로 보인다)
WHY = {
    OK: '',
    MERGED: '그 역본이 앞뒤 절과 한 절로 묶어 옮겼다 — 내용은 그 절에 있다',
    ABSENT: '그 역본의 본문 전통에 이 절이 없다(비평본문에서 뺀 신약 이형 등)',
    MISSING: '그 역본에 이 절의 행이 아예 없다 — 절체계 미정렬이거나 미적재',
    GARBAGE: '원본 자료가 본문 대신 뜻 없는 글자를 담고 있다',
}
#: 유형마다 **어떻게 보완했나**
FIX = {
    OK: '',
    MERGED: '합쳐진 절 번호를 밝히고 **그 절 본문을 그대로** 보인다',
    ABSENT: '없는 절임을 밝히고, 그 역본이 참고로 실은 글이 있으면 함께 보인다',
    MISSING: '다른 역본의 본문을 **( ) 안에 · 역본 이름을 밝혀** 빌려 보인다',
    GARBAGE: '다른 역본의 본문을 **( ) 안에 · 역본 이름을 밝혀** 빌려 보인다',
}

#: 빌려 올 역본 차례 — 언어가 같은 것을 먼저, 그다음 기준 역본
BORROW_BY_LANG = {
    'KO': ('KRV',), 'EN': ('BSB', 'WEB', 'KJV'), 'ZH': ('CUV', 'CUVS'),
    'ZHT': ('CUV',), 'JA': (), 'DE': ('GerElb',), 'FR': ('FreLSG', 'FreJND'),
    'ES': ('SpaRV',), 'PT': ('PorBL',), 'RU': ('RusSyn',), 'AR': ('ARB',),
}
BORROW_LAST = ('BSB', 'KJV', 'WEB', 'KRV')


# ── 낱낱 도구 ────────────────────────────────────────────────────────
def strip_invisible(s):
    return ''.join(ch for ch in str(s or '') if ch not in INVIS).strip()


def letter_len(s):
    """글자·숫자만 센다 — 공백·구두점·표식은 안 센다."""
    return sum(1 for ch in str(s or '')
               if unicodedata.category(ch)[0] in ('L', 'N'))


#: 원본 결함으로 볼 라틴 글자 수 상한
JUNK_MAX = 3


def is_junk(s):
    """원본이 본문 대신 남긴 **뜻 없는 글자**인가.

    ★★★ **글자 수로 재지 않는다 — 문자체계로 잰다**(2026-09-19 사용자 지시).
      옛 규칙은 「글자 세 자 이하면 못구함」이었는데 **표의문자 역본에 부당
      하다**. 중국어는 같은 뜻을 훨씬 적은 글자로 적는다 — 실측 화합본의
      정당한 본문에 「不可殺人。」(4자) · 「神對挪亞說：」(5자)가 있고,
      **욥 3:2 는 본문 자체가 「說：」(1자)** 다(3:1 「約伯開口咒詛自己的生日，」
      에서 이어지는 도입구). 그 한 절이 두 역본에서 **못구함으로 오인**됐고,
      그것이 「못구함 유형은 중국어 버전 뿐」의 정체였다.
    ⇒ 잣대 = **그 글이 라틴 글자·숫자뿐인가**. 성경 본문이 라틴 글자 한두
      자로 끝나는 절은 어느 역본에도 없다(실측 라틴 역본의 가장 짧은 절 =
      `Jesus wept.` **9자** · `Jésus pleura.` 11 · `No matarás.` 9).
      그래서 CUV 의 `'a'`(69절)는 잡고 「說：」 는 놓아 준다.
    ⚠ 표식(`[—]`·`✠`)은 여기 오기 전에 **없는절**로 갈린다 — 글자가 0이다.
    """
    t = str(s or '')
    n = letter_len(t)
    if n == 0 or n > JUNK_MAX:
        return False
    return all(ch.isascii() for ch in t
               if unicodedata.category(ch)[0] in ('L', 'N'))


def _t(key, fallback, **kw):
    """ui_strings 한 줄. ⚠ 한국어를 박지 않는다."""
    try:
        import i18n
        s = i18n.t(key, fallback)
    except Exception:                                         # noqa: BLE001
        s = fallback
    try:
        return s.format(**kw) if kw else s
    except Exception:                                         # noqa: BLE001
        return s


def classify(text, has_row=True):
    """본문 한 줄 → `(유형, 남는 본문, 합쳐진 절 번호 또는 None)`.

    ⚠ **판정은 여기 한 곳**이다 — 화면마다 표식을 알아보게 하면 반드시
      한 꼴을 빠뜨린다(지금 여섯 꼴이 있다).
    """
    if not has_row:
        return MISSING, '', None
    s = strip_invisible(text)
    if not s:
        return MISSING, '', None

    m = _RX_MERGE_TAG.match(s)
    if m:
        return MERGED, s[m.end():].strip(), int(m.group(2))
    m = _RX_PAREN_KO.match(s)
    if m:
        return MERGED, s[m.end():].strip(), int(m.group(1))
    if _RX_CJK_PREV.match(s):
        return MERGED, _RX_CJK_PREV.sub('', s).strip(), -1   # -1 = 바로 앞 절
    m = _RX_ANGLE.match(s)
    if m:
        inner = m.group(1).strip()
        if any(w.lower() in inner.lower() for w in ABSENT_WORDS):
            return ABSENT, s[m.end():].strip(), None
        return ABSENT, s[m.end():].strip(), None
    if _RX_CROSS.match(s) or _RX_DASH.match(s):
        rest = _RX_DASH.sub('', _RX_CROSS.sub('', s)).strip()
        return ABSENT, rest, None
    if is_junk(s):
        return GARBAGE, '', None
    return OK, s, None


# ── DB 재료 ──────────────────────────────────────────────────────────
def _row(conn, vid, ver):
    r = conn.execute('SELECT verse_text FROM bible_content'
                     ' WHERE verse_id=? AND version_code=?',
                     (vid, ver)).fetchone()
    return (r[0] if r else None), bool(r)


def _coord(conn, vid):
    r = conn.execute('SELECT bcode, chapter, verse FROM bible_index'
                     ' WHERE verse_id=?', (vid,)).fetchone()
    return tuple(r) if r else (None, None, None)


def _vid_of(conn, bcode, chapter, verse):
    r = conn.execute('SELECT verse_id FROM bible_index'
                     ' WHERE bcode=? AND chapter=? AND verse=?',
                     (bcode, chapter, verse)).fetchone()
    return r[0] if r else None


def _ver_lang(conn, ver):
    r = conn.execute('SELECT lang_code FROM bible_version'
                     ' WHERE version_code=?', (ver,)).fetchone()
    return (r[0] or '').upper() if r else ''


def _scope(conn, ver):
    """`FULL` · `OT_ONLY` · `NT_ONLY` — 그 역본이 덮는 범위.

    ⚠ 칸이 없는 DB(시험 자료)에서도 죽지 않는다 — 모르면 `FULL` 로 본다.
    """
    try:
        r = conn.execute('SELECT coverage_scope FROM bible_version'
                         ' WHERE version_code=?', (ver,)).fetchone()
    except Exception:                                         # noqa: BLE001
        return 'FULL'
    return (r[0] or 'FULL').upper() if r else 'FULL'


def partner_of(conn, ver, user_pick=None):
    """반쪽 역본이 **나머지 절반에서 쓸 짝** → 역본 코드 또는 `''`.

    ★★★ 셋을 겹친다 — 아무것도 고르지 않은 사용자도 늘 무엇인가 얻는다:
      ① 사용자가 고른 짝(`user_pick` · 성경버전 화면이 넘긴다)
      ② **역본이 스스로 아는 기본 짝**(`bible_version.partner_code`)
      ③ 없으면 `''` — 그다음은 여느 폴백(같은 언어 → 기준 역본)
    ⚠ **없는 짝을 지어내지 않는다**(§0-1) — 콥트어는 구약이 없으므로 ② 가
      비어 있고, 그러면 영어로 떨어지는 지금 동작 그대로다.
    """
    if user_pick:
        return str(user_pick)
    try:
        r = conn.execute('SELECT partner_code FROM bible_version'
                         ' WHERE version_code=?', (ver,)).fetchone()
    except Exception:                       # 칸이 아직 없는 DB
        return ''
    return (r[0] or '') if r else ''


def _user_partner(conn, ver):
    """사용자가 성경버전 화면에서 선택한 짝 → `user_config['VERSION_PARTNER']`."""
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE"
                         " config_key='VERSION_PARTNER'").fetchone()
        if not r or not r[0]:
            return ''
        return (json.loads(r[0]) or {}).get(ver, '')
    except Exception:
        return ''


def _borrow(conn, vid, want_lang, skip, ver=''):
    """다른 역본에서 본문을 빌린다 → `(본문, 역본)` 또는 `(None, None)`.

    ⚠ **빌려 온 것임을 반드시 밝힌다** — 부르는 쪽이 역본 이름을 적는다.
    ★ **짝이 가장 앞이다** — 히브리어 구약을 읽던 사람이 신약으로 가면
      영어가 아니라 **히브리어 신약**이 나와야 한다.
    """
    order = []
    if ver:
        pc = partner_of(conn, ver, _user_partner(conn, ver))
        if pc and pc not in skip:
            order.append(pc)
    order += [v for v in BORROW_BY_LANG.get((want_lang or '').upper(), ())
              if v not in order]
    order += [v for v in BORROW_LAST if v not in order]
    for v in order:
        if v in skip:
            continue
        t, ok = _row(conn, vid, v)
        if not ok:
            continue
        k, body, _n = classify(t, True)
        if k == OK and body:
            return body, v
    return None, None


# ── 본 문 ────────────────────────────────────────────────────────────
def resolve(conn, verse_id, version, lang='KO', borrow=True):
    """그 절 · 그 역본을 **화면에 그대로 그릴 수 있는 꼴**로 → dict.

        {'text', 'body', 'kind', 'note', 'why', 'fix',
         'merged_verse', 'src_version'}

    ★ `text` = 설명문(`[ ]`)과 빌려 온 본문(`( )`)까지 합친 **완성된 글**.
    ★ `body` = 본문만(표식 걷음) — 검색·대조는 이것을 쓴다.
    """
    raw, has_row = _row(conn, verse_id, version)
    kind, body, mv = classify(raw, has_row)
    out = {'kind': kind, 'body': body, 'note': '', 'merged_verse': None,
           'src_version': version if kind == OK else None, 'partner': None,
           'why': WHY.get(kind, ''), 'fix': FIX.get(kind, '')}

    if kind == OK:
        out['text'] = body
        return out

    b, ch, vs = _coord(conn, verse_id)

    # ── 합쳐진 절 — 그 절 본문을 그대로 보인다 ───────────────────────
    if kind == MERGED:
        tgt_v = (vs - 1) if (mv == -1 and vs) else mv
        out['merged_verse'] = tgt_v
        # ⚠⚠ **합쳐진 절이 다른 장에 있을 수 있다** — 히브리 63:19 가 영어
        #   63:19 와 64:1 을 함께 덮는 자리가 그렇다(285차). 그때 「19절에
        #   포함」이라고만 적으면 **같은 장의 19절**을 찾게 되는데 그 장에는
        #   19절이 없다. 표식이 장을 이미 들고 있으므로 그것을 쓴다.
        tgt_ch = None
        m0 = _RX_MERGE_TAG.match((raw or '').strip())
        if m0 and int(m0.group(1)) != ch:
            tgt_ch = int(m0.group(1))
        if not body and tgt_v and b:
            tv = _vid_of(conn, b, tgt_ch or ch, tgt_v)
            if tv:
                t2, ok2 = _row(conn, tv, version)
                k2, body2, _ = classify(t2, ok2)
                if k2 == OK:
                    body = body2
                    out['src_version'] = version
        out['note'] = _t('VT_MERGED', '{n}절에 포함',
                         n=('%d:%d' % (tgt_ch, tgt_v)) if tgt_ch
                         else (tgt_v if tgt_v else '?'))
        out['body'] = body
        out['text'] = ('[%s] %s' % (out['note'], body)).strip()
        return out

    # ── 없는 절 / 못 구한 절 ─────────────────────────────────────────
    if kind == ABSENT:
        out['note'] = _t('VT_ABSENT', '이 역본에 없음')
    elif kind == GARBAGE:
        out['note'] = _t('VT_GARBAGE', '본문을 구하지 못함')
    else:
        # ★ 반쪽 역본이면 **까닭을 말한다** — 「본문 없음」은 결함처럼 읽힌다.
        #   구약만 있는 역본으로 신약에 온 것은 고장이 아니라 그 역본의 범위다.
        sc = _scope(conn, version)
        if b and sc == 'OT_ONLY' and b >= 40:
            out['note'] = _t('VT_NO_NT', '이 역본은 신약이 없습니다')
        elif b and sc == 'NT_ONLY' and b < 40:
            out['note'] = _t('VT_NO_OT', '이 역본은 구약이 없습니다')
        else:
            out['note'] = _t('VT_MISSING', '본문 없음')

    if body:                                   # 그 역본이 참고로 실은 글
        out['text'] = '[%s] %s' % (out['note'], body)
        out['src_version'] = version
        return out

    if borrow:
        bt, bv = _borrow(conn, verse_id, lang or _ver_lang(conn, version),
                         {version}, ver=version)
        if bt:
            out['body'] = bt
            out['src_version'] = bv
            # ★ 짝이 채운 자리는 **표식을 짧게**(§257차 ②) — 「[본문 없음]」을
            #   앞에 붙이면 정상 동작이 결함으로 읽힌다. 어느 역본에서 왔는지는
            #   그대로 밝힌다(§0-1).
            if bv == partner_of(conn, version, _user_partner(conn, version)):
                out['partner'] = bv
                out['text'] = '(%s) %s' % (
                    _t('VT_FROM', '{v} 본문', v=bv), bt)
            else:
                out['text'] = '[%s] (%s) %s' % (
                    out['note'], _t('VT_FROM', '{v} 본문', v=bv), bt)
            return out
    out['text'] = '[%s]' % out['note']
    return out


def texts(conn, verse_ids, version, lang='KO', borrow=True):
    """여러 절 한 번에 → `{verse_id: resolve(...)}`.

    ⚠ 절마다 `resolve` 를 부르면 조회가 절 수만큼이다 — 목록 화면은 이 문.
    """
    vids = [int(v) for v in (verse_ids or [])]
    if not vids:
        return {}
    ph = ','.join('?' * len(vids))
    have = {r[0]: r[1] for r in conn.execute(
        'SELECT verse_id, verse_text FROM bible_content'
        ' WHERE version_code=? AND verse_id IN (%s)' % ph, [version] + vids)}
    out = {}
    for vid in vids:
        raw = have.get(vid)
        kind, _b, _m = classify(raw, vid in have)
        if kind == OK:
            out[vid] = {'kind': OK, 'body': strip_invisible(raw),
                        'text': strip_invisible(raw), 'note': '',
                        'merged_verse': None, 'src_version': version,
                        'partner': None, 'why': '', 'fix': ''}
        else:                                  # 드문 자리만 제 문으로
            out[vid] = resolve(conn, vid, version, lang, borrow)
    return out


# ── 진단 ─────────────────────────────────────────────────────────────
def audit(conn, versions=None):
    """역본별 차이 유형 집계 → `{역본: {유형: 수}}`.

    ★ 관리자 진단 화면이 이 문을 쓴다 — 화면이 제 SQL 을 쓰면 갈린다.
    """
    from collections import Counter, defaultdict
    tot = conn.execute('SELECT COUNT(*) FROM bible_index').fetchone()[0]
    vers = versions or [r[0] for r in conn.execute(
        'SELECT version_code FROM bible_version ORDER BY version_code')]
    out = defaultdict(Counter)
    for v in vers:
        n = 0
        for (raw,) in conn.execute(
                'SELECT verse_text FROM bible_content WHERE version_code=?',
                (v,)):
            n += 1
            k, _b, _m = classify(raw, True)
            out[v][k] += 1
        if n:
            out[v][MISSING] += tot - n
    return {k: dict(c) for k, c in out.items()}


def rows(conn, version, kinds=None, limit=500):
    """그 역본에서 **차이가 있는 절**만 → `[(verse_id, 좌표, 유형, 원인, 보완, 글)]`."""
    want = set(kinds or (MERGED, ABSENT, MISSING, GARBAGE))
    out = []
    for vid, raw in conn.execute(
            'SELECT bc.verse_id, bc.verse_text FROM bible_content bc'
            ' JOIN bible_index bi ON bi.verse_id=bc.verse_id'
            ' WHERE bc.version_code=? ORDER BY bi.sort_order', (version,)):
        k, _b, _m = classify(raw, True)
        if k in want and k != OK:
            out.append((vid, k))
            if len(out) >= limit:
                break
    if MISSING in want and len(out) < limit:
        for (vid,) in conn.execute(
                'SELECT bi.verse_id FROM bible_index bi WHERE NOT EXISTS('
                ' SELECT 1 FROM bible_content bc WHERE bc.verse_id=bi.verse_id'
                '   AND bc.version_code=?) ORDER BY bi.sort_order LIMIT ?',
                (version, limit - len(out))):
            out.append((vid, MISSING))
    res = []
    for vid, k in out:
        b, ch, vs = _coord(conn, vid)
        r = resolve(conn, vid, version)
        res.append((vid, (b, ch, vs), k, r['why'], r['fix'], r['text']))
    return res


#: `bible_content` 를 **직접 읽어도 되는** 자리와 까닭.
#:  ⚠ 여기 없는 파일이 절 본문을 직접 읽으면 `sweep()` 이 실패한다.
ALLOWED = {
    'verse_text.py': '이 문 자신',
    'search.py': '찾는 색인 — 보완문으로 찾으면 설명문이 검색된다',
    'notify_chapter.py': '텔레그램 알림 — 화면에서 읽는 자리가 아니다',
    'figure_tree.py': '구간을 통째로 잇는다 — 절마다 보완하면 설명문 투성이',
    'verse_range.py': '세는 자리·시험',
    'license_info.py': '세는 자리',
    'pack_fallback.py': '세는 자리',
    'book_footnote.py': '역본 코드만 읽는다',
    'admin/pack_deploy_tab.py': '세는 자리',
    'admin/panel_verse_divergence.py': '진단 화면 — **원본을 봐야** 판정이 보인다',
    'admin/panel_verse_link.py': '고치는 자리 — 보완문을 보이면 그것을 저장한다',
    'admin/panel_chain_manager.py': '고치는 자리 — 같은 까닭',
    'admin/panel_verse_assets.py': '고치는 자리 — 같은 까닭',
    'admin/panel_entity_manager.py': '고치는 자리 — 같은 까닭',
    # ★ 아래 둘은 **조회는 그대로 두고 결과만** 보완한다 — 한 문으로
    #   여러 절을 내는 자리라 조회를 쪼개면 절마다 DB 를 열게 된다.
    #   ⚠ 보완하는 코드가 그 바로 아래에 있다(`_vt.classify` → `resolve`).
    'link_picker.py': '한 문으로 여러 절 — 결과를 뒤에서 보완한다',
    'my_path_view.py': '한 문으로 여러 절 — 결과를 뒤에서 보완한다',
}

#: 읽는 것이 아니라 **세거나 지우는** 조회 — 여기 걸리면 그냥 넘어간다
_COUNTISH = ('count(', 'delete from', 'version_code from', 'insert into',
             'create table', 'max(', 'min(')


def sweep(root=None):
    """저장소를 훑어 **허가 없이 절 본문을 직접 읽는 자리**를 찾는다.

    → `[(파일, 줄번호, 그 줄)]`. 비어 있어야 성하다.
    """
    root = root or os.path.dirname(os.path.abspath(__file__))
    bad, unread = [], []
    for dirpath, dirnames, files in os.walk(root):
        dirnames[:] = [d for d in dirnames
                       if d not in ('참고코드', '.git', '__pycache__',
                                    '.claude', '_backup_20260812_1912')]
        for fn in files:
            if not fn.endswith('.py'):
                continue
            if fn.startswith(('db_', 'temp_')):
                continue          # 적재·1회성 도구는 원문을 쓴다
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, root).replace(os.sep, '/')
            if rel in ALLOWED:
                continue
            try:
                src = io.open(full, encoding='utf-8').read()
            except Exception as _e:                           # noqa: BLE001
                # ⚠⚠ **조용히 건너뛰지 않는다** — 여기서 삼킨 `NameError`
                #   때문에 이 검사가 「0곳」이라 **거짓 통과**했다(실측).
                unread.append((rel, 0, '못 읽었다: %s' % str(_e)[:40]))
                continue
            for i, ln in enumerate(src.split('\n'), 1):
                low = ln.lower()
                if 'from bible_content' not in low:
                    continue
                if any(k in low for k in _COUNTISH):
                    continue
                bad.append((rel, i, ln.strip()[:88]))
    return bad + unread


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [0], []

    def chk(n, cond, extra=''):
        if cond:
            ok[0] += 1
        else:
            bad.append(n)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', n, extra))

    # ⓐ 판정 — 여섯 꼴을 다 알아본다
    cases = [
        ('평범한 본문입니다 그렇습니다', OK, None),
        ('<Absent> where their worm', ABSENT, None),
        ('<없음> 거기는 구더기도', ABSENT, None),
        ('<Fehlt>', ABSENT, None),
        ('<Ausente>', ABSENT, None),
        ('<Ἀπόν> ὅπου ὁ σκώληξ', ABSENT, None),
        ('<缺> 人 子 來', ABSENT, None),
        ('✠', ABSENT, None),
        ('[—]', ABSENT, None),
        ('<병합 6:13> Reviens, Sulamithe', MERGED, 13),
        ('(18절에 포함되어 있음)', MERGED, 18),
        ('併入上節', MERGED, -1),
        ('a', GARBAGE, None),
        ('ab', GARBAGE, None),
        # ★ 짧아도 **그 언어의 글자**면 정당한 본문이다 (2026-09-19)
        ('说：', OK, None),
        ('說：', OK, None),
        ('不可殺人。', OK, None),
        ('神對挪亞說：', OK, None),
        ('', MISSING, None),
        ('　 ', MISSING, None),
    ]
    for t, want_k, want_m in cases:
        k, _b, m = classify(t, True)
        chk('판정 %r' % t[:18], k == want_k and m == want_m, (k, m))
    chk('행이 없으면 MISSING', classify('아무거나', False)[0] == MISSING)
    chk('★ 전각 공백도 빈 것으로 본다(TRIM 은 못 잡는다)',
        classify('　', True)[0] == MISSING)
    chk('표식 뒤 본문을 남긴다',
        classify('<Absent> hello world here', True)[1] == 'hello world here')

    # ⓑ 메모리 DB 왕복
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INTEGER,
        chapter INTEGER, verse INTEGER, sort_order INTEGER);
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
        verse_text TEXT);
      CREATE TABLE bible_version(version_code TEXT, lang_code TEXT);
      INSERT INTO bible_index VALUES(1,1,24,29,10),(2,1,24,30,20),
                                    (3,1,24,31,30);
      INSERT INTO bible_version VALUES('BSB','EN'),('CUV','ZH'),('KRV','KO');
      INSERT INTO bible_content VALUES
        (1,'BSB','Now Rebekah had a brother named Laban'),
        (2,'BSB','As soon as he saw the ring and the bracelets'),
        (3,'BSB','Come, you who are blessed of the LORD'),
        (1,'CUV','利百加有一個哥哥名叫拉班看見金環'),
        (2,'CUV','併入上節'),
        (1,'KRV','리브가에게 오라비가 있어 이름은 라반이라'),
        (2,'KRV','a');
    """)
    try:
        r = resolve(c, 2, 'CUV', 'ZH')
        chk('합쳐진 절을 알아본다', r['kind'] == MERGED, r['kind'])
        chk('합쳐진 절 번호를 낸다', r['merged_verse'] == 29, r['merged_verse'])
        chk('★ 그 절 본문을 그대로 보인다', '拉班' in r['text'], r['text'][:40])
        chk('설명문이 대괄호 안에', r['text'].startswith('['), r['text'][:20])

        r = resolve(c, 2, 'KRV', 'KO')
        chk('원본 결함을 알아본다', r['kind'] == GARBAGE)
        chk('★ 다른 역본에서 빌려 온다', r['src_version'] not in (None, 'KRV'),
            r['src_version'])
        chk('★★ 빌려 온 것임을 밝힌다',
            '(' in r['text'] and r['src_version'] in r['text'], r['text'][:60])
        chk('빌리기를 끄면 설명문만',
            resolve(c, 2, 'KRV', 'KO', borrow=False)['text'].count('[') == 1)

        r = resolve(c, 3, 'CUV', 'ZH')
        chk('행이 없으면 MISSING', r['kind'] == MISSING, r['kind'])
        chk('그때도 본문을 빌려 온다', bool(r['body']), r['text'][:40])

        r = resolve(c, 1, 'BSB', 'EN')
        chk('정상 절은 그대로', r['kind'] == OK and r['text'] == r['body'])
        chk('정상 절에는 대괄호가 없다', '[' not in r['text'])

        # ⓒ 여러 절 한 번에 — 낱낱과 같은 답
        m = texts(c, [1, 2, 3], 'CUV', 'ZH')
        chk('여러 절 문이 같은 답', len(m) == 3
            and m[2]['kind'] == MERGED and m[1]['kind'] == OK, list(m))
        chk('여러 절에서도 본문이 채워진다', bool(m[3]['body']))

        # ⓓ 집계·목록
        a = audit(c, ['CUV', 'KRV'])
        chk('집계가 유형별로 센다',
            a['CUV'].get(MERGED) == 1 and a['CUV'].get(MISSING) == 1, a)
        rws = rows(c, 'CUV')
        chk('목록이 원인·보완을 함께 낸다',
            rws and rws[0][3] and rws[0][4], rws[:1])

        # ⓔ 판정에 한국어를 박지 않았는가 — 글은 ui_strings 로
        src = open(__file__, encoding='utf-8').read() if '__file__' in \
            globals() else ''
        chk('★ 화면 글이 ui_strings 열쇠로 나간다',
            "_t('VT_MERGED'" in src and "_t('VT_ABSENT'" in src)
    finally:
        c.close()

    # ⓕ-0 ★★★ **반쪽 역본의 짝** — 구약만 있는 역본으로 신약에 가면
    #   영어가 아니라 **짝 역본**이 나와야 한다(279차 사용자 지시).
    c2 = sqlite3.connect(':memory:')
    c2.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INTEGER,
        chapter INTEGER, verse INTEGER, sort_order INTEGER);
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
        verse_text TEXT);
      CREATE TABLE bible_version(version_code TEXT, lang_code TEXT,
        coverage_scope TEXT, partner_code TEXT);
      CREATE TABLE user_config(config_key TEXT, config_val TEXT);
      INSERT INTO bible_index VALUES(9,43,3,16,90);
      INSERT INTO bible_version VALUES
        ('OTX','HE','OT_ONLY','NTX'), ('NTX','HE','NT_ONLY','OTX'),
        ('LON','XX','NT_ONLY',NULL), ('BSB','EN','FULL',NULL);
      INSERT INTO bible_content VALUES
        (9,'NTX','כי ככה אהב האלהים את העולם'),
        (9,'BSB','For God so loved the world');
    """)
    try:
        r = resolve(c2, 9, 'OTX', 'HE')
        chk('★★★ 반쪽 역본이 신약에서 **짝 본문**을 낸다',
            r['src_version'] == 'NTX' and 'אהב' in r['text'], r['text'][:40])
        chk('   그것이 짝임을 말한다', r['partner'] == 'NTX', r['partner'])
        chk('   짝이 채우면 「본문 없음」을 앞에 안 붙인다',
            not r['text'].startswith('['), r['text'][:20])
        chk('   그래도 어디서 왔는지는 밝힌다', 'NTX' in r['text'])
        # ⚠ **짝이 없으면 지금 동작 그대로** — 없는 짝을 지어내지 않는다
        r2 = resolve(c2, 9, 'LON', 'XX')
        chk('   짝이 없는 역본은 여느 폴백(기준 역본)으로',
            r2['src_version'] == 'BSB' and r2['partner'] is None,
            r2['src_version'])
        # ★ 사용자가 고른 짝이 기본 짝을 이긴다
        c2.execute("INSERT INTO user_config VALUES('VERSION_PARTNER',"
                   " '{\"OTX\": \"BSB\"}')")
        chk('★ 사용자가 선택한 짝이 기본 짝을 이긴다',
            resolve(c2, 9, 'OTX', 'HE')['src_version'] == 'BSB')
        c2.execute("DELETE FROM user_config")
        # ★ 범위를 까닭으로 말한다 — 「본문 없음」은 결함처럼 읽힌다
        chk('★ 반쪽 역본의 까닭을 note 가 말한다',
            resolve(c2, 9, 'OTX', 'HE', borrow=False)['note']
            != _t('VT_MISSING', '본문 없음'),
            resolve(c2, 9, 'OTX', 'HE', borrow=False)['note'])
    finally:
        c2.close()

    # ⓕ 실 DB — 사용자가 든 세 구절
    try:
        import appdb
        rc = appdb.connect()
        for label, (b, ch, vs) in (('창24:30', (1, 24, 30)),
                                   ('레3:15', (3, 3, 15)),
                                   ('막9:44', (41, 9, 44)),
                                   ('눅2:35', (42, 2, 35))):
            vid = _vid_of(rc, b, ch, vs)
            for ver in ('CUV', 'CUVS', 'KRV', 'PorBL'):
                r = resolve(rc, vid, ver, _ver_lang(rc, ver))
                good = letter_len(r['text']) >= 5
                chk('실 DB %s %s 에 읽을 글이 있다' % (label, ver), good,
                    '%s · %s' % (r['kind'], r['text'][:44]))
        rc.close()
    except Exception as e:                                    # noqa: BLE001
        chk('실 DB', False, e)

    # ⓖ ★★★ **새 자리가 생기는 것을 막는다** — 이 문제가 여러 번 지나간
    #   뿌리가 「읽는 자리가 39곳」이었다. 지침이 아니라 검사로 세운다.
    try:
        left = sweep()
        chk('★★★ 허가 없이 절 본문을 직접 읽는 자리 0', not left,
            left[:3] if left else '')
        # 탐지력 — 없는 파일을 하나 끼워 보면 잡히는가
        import io as _io
        import tempfile as _tf
        d = _tf.mkdtemp()
        _io.open(os.path.join(d, 'fake_view.py'), 'w', encoding='utf-8').write(
            "x = conn.execute('SELECT verse_text FROM bible_content')\n")
        chk('   (탐지력) 새 자리를 심으면 잡는다', len(sweep(d)) == 1, sweep(d))
        import shutil as _sh
        _sh.rmtree(d, ignore_errors=True)
        chk('   허가 목록에 까닭이 다 있다',
            all(v.strip() for v in ALLOWED.values()))
        # ⚠ 「결과를 뒤에서 보완한다」고 적은 파일은 **정말 보완하는지**
        #   확인한다 — 허가를 빈 약속으로 두지 않는다.
        _rt = os.path.dirname(os.path.abspath(__file__))
        _no = [f for f, v in ALLOWED.items() if '뒤에서 보완' in v
               and '_vt.resolve' not in _io.open(
                   os.path.join(_rt, f), encoding='utf-8').read()]
        chk('   ★ 「뒤에서 보완」이라 적은 파일이 정말 보완한다',
            not _no, _no)
    except Exception as e:                                    # noqa: BLE001
        chk('훑어보기', False, e)
    print('verse_text selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    for n in bad:
        print('  X', n)
    return not bad


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--audit', action='store_true')
    ap.add_argument('--verse')
    ap.add_argument('--sweep', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return 0 if _selftest() else 1
    if a.sweep:
        left = sweep()
        print('허가 없이 절 본문을 직접 읽는 자리 %d곳' % len(left))
        for f, i, ln in left:
            print('  %s:%d  %s' % (f, i, ln))
        return 1 if left else 0
    import appdb
    c = appdb.connect()
    try:
        if a.verse:
            import scripture_ref_kr as SR
            b, ch, vs = None, None, None
            try:
                st, _en = SR.resolve(a.verse)
                b, ch, vs = _coord(c, st)
            except Exception:                                 # noqa: BLE001
                pass
            vid = _vid_of(c, b, ch, vs) if b else None
            if not vid:
                print('좌표를 못 찾았습니다:', a.verse)
                return 1
            print('%s (verse_id %d)' % (a.verse, vid))
            for (v,) in c.execute('SELECT version_code FROM bible_version'
                                  ' ORDER BY version_code'):
                r = resolve(c, vid, v, _ver_lang(c, v))
                print('  %-8s %-8s %s' % (v, r['kind'], r['text'][:76]))
            return 0
        ad = audit(c)
        print('%-8s %8s %7s %7s %7s %8s' %
              ('역본', 'OK', '합쳐짐', '없는절', '못구함', '행없음'))
        for v in sorted(ad):
            d = ad[v]
            if sum(d.values()) < 1000:
                continue
            print('%-8s %8d %7d %7d %7d %8d'
                  % (v, d.get(OK, 0), d.get(MERGED, 0), d.get(ABSENT, 0),
                     d.get(GARBAGE, 0), d.get(MISSING, 0)))
        return 0
    finally:
        c.close()


if __name__ == '__main__':
    sys.exit(main())
