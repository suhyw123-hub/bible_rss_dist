# -*- coding: utf-8 -*-
"""배포 꾸러미 만들기 — **파이썬도 SQLite 도 PyQt 도 없는 PC** 한 대에 통째로.

★★★ 왜 (2026-09-17 사용자 「다른 사람의 PC에 파이선, SQLITE, PyQT 등을 전혀
  설치하지 않았다는 전제 하에서 **필요한 것들을 모두 전송**한다고 가정하고
  진행하라 … **코어팩 전송하는 것 테스트를 준비하라**」).

★★★ **이 앱은 한 번도 이 PC 밖에서 돈 적이 없다.** 그래서 1차 시험이 묻는 것은
  기능이 아니라 **「깔리고 켜지는가」** 하나다. 컨텐츠 갱신(팩 증분)은 2차다 —
  둘을 같이 시험하면 무엇이 깨졌는지 못 가른다.

⚠⚠⚠ **임베더블 파이썬은 못 쓴다 — 재서 알았다.** `python-3.14-embed-amd64`
  에는 **tkinter 와 tcl 이 없다.** 이 앱은 통째로 Tkinter 다. ⇒ **설치본을
  다듬어 복사**한다(기본 파이썬 약 60MB · tcl 5.6MB).

⚠⚠ **SQLite 는 따로 안 보낸다** — 파이썬이 `_sqlite3.pyd` + `sqlite3.dll` 로
  품고 있다. 「SQLite 설치」라는 걸음은 애초에 없다(실측으로 확인한다).

⚠⚠⚠ **가장 큰 것은 앱이 아니라 Qt 다** — 실측 `PyQt6` **572MB**, 그 가운데
  `Qt6WebEngineCore.dll` 하나가 **202MB**. 유튜브 재생기(§30)가 그것을 쓴다.
  ⇒ `--no-video` 로 **재생기를 빼고** 보낼 수 있다(그 기능만 죽고 나머지는 산다).
  ★ 다듬기는 **나중**이다 — 먼저 통째로 보내 도는 것을 보고, 그다음에 줄인다.
    안 도는 꾸러미를 줄이면 무엇 때문에 안 도는지 못 가른다.

⚠⚠ **개인 DB 는 안 보낸다**(§C-2) — `user_data.db` 는 **스키마만** 새로 뜬다.
  받는 사람의 묵상노트가 들어갈 빈 그릇이고, 다음 배포가 그것을 덮으면 안 된다
  (그 규칙을 실제로 지키는지가 1차 시험의 핵심 물음이다).

⚠ **배포 DB 에서 걷는 것은 둘뿐이다** — 감사 로그(`sys_audit_log` 실측
  1,067,105행 · old_json 475MB)와 `temp_*` 백업 표. **LOCAL 표는 안 건드린다**
  — 어느 화면이 그것을 읽는지 전수로 확인하기 전에 비우면 조용히 빈 화면이
  된다(§0-1). 줄이는 일은 2차다.

명령
  `--selftest`   의무
  `--plan`       무엇을 담고 얼마나 큰가 · **막는 것** (아무것도 안 만든다)
  `--build DIR`  꾸러미를 만든다 (`--no-video` · `--no-db`)
  `--slim-db F`  배포용 `bible_master.db` 하나만
  `--empty-user F` 빈 `user_data.db` 하나만
"""
import argparse
import io
import re
import os
import shutil
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb  # noqa: E402

APP_DIR = os.path.dirname(os.path.abspath(__file__))

# ── 보내야 하는 바깥 꾸러미 — 왜 필요한지 함께 적는다 ──────────────────
#   ⚠ 목록을 손으로 적되 `--plan` 이 **코드를 훑어 빠진 것을 신고**한다.
PKGS = [
    ('PyQt6', '유튜브 재생기(§30 딴 프로세스) — 가장 크다', 'video'),
    ('PIL', '썸네일·시작화면·지도 타일', ''),
    ('numpy', '녹음 재생(voice_bible)', 'voice'),
    ('sounddevice', '녹음 재생', 'voice'),
    ('_sounddevice', '↑ cffi 로 만든 짝 — 이름이 달라 안 따라온다', 'voice'),
    ('_sounddevice_data', '↑ portaudio DLL', 'voice'),
    ('soundfile', '녹음 재생', 'voice'),
    ('_soundfile', '↑ 짝', 'voice'),
    ('_soundfile_data', '↑ libsndfile DLL', 'voice'),
    ('cffi', 'sounddevice·soundfile 이 C 를 부르는 통로', 'voice'),
    ('_cffi_backend', '↑ 그 본체(.pyd)', 'voice'),
    ('pycparser', 'cffi 짝', 'voice'),
    ('typing_extensions', 'soundfile 이 부른다', 'voice'),
    ('requests', '자료 내려받기', ''),
    ('certifi', 'requests 의 인증서', ''),
    ('urllib3', 'requests', ''),
    ('idna', 'requests', ''),
    ('charset_normalizer', 'requests', ''),
]

# 파이썬 설치본에서 **빼는** 것 — 배포에 뜻이 없다
PY_SKIP_TOP = ('Doc', 'include', 'libs', 'Scripts', 'NEWS.txt')
PY_SKIP_LIB = ('test', 'idlelib', 'ensurepip', 'site-packages', '__pycache__',
               'lib2to3', 'turtledemo')

# 앱에서 함께 보내는 폴더 — **없으면 그냥 건너뛴다**
# ⚠⚠ 2026-10-31 docs 를 뺐다 — 앱이 읽지 않는 작업 문서 폴더가 공개 배포 zip 에 실려, 그 안의 Cloudflare 열쇠 메모가 나갔다(GitHub 비밀 검사가 잡아 토큰 취소)
APP_DIRS = ('admin', 'icons', 'browser_ext')   # browser_ext = 「하가에 저장」 확장(2026-10-11)

# ⚠⚠ 안 보내는 코드 — 하네스는 **실제 DB 를 바꾼다**(§241차 그 자리).
#   받는 사람 폴더에 두면 잘못 눌렀을 때 제 자료가 상한다.
#   ⚠ `db_*` 도구는 남긴다 — 사용자 화면이 import 해서 쓴다.
SKIP_PY = ('temp_', '_')   # ⚠ `_patch7.py` 같은 1회성 패치도 안 보낸다
#   (실측 — 그런 것이 꾸러미에 실려 나가고 있었다. 누르면 코드를 고친다)

# 배포 DB 에서 비우는 표
DROP_ROWS = ('sys_audit_log',)

# 앱이 **켜지면서 스스로 만드는** 파일 — 꾸러미 대조에서 뺀다(§34 스플래시는
# 설치마다 새로 만든다). 없다고 잘못이 아니고 있다고 잘못도 아니다.
RUNTIME_MADE = ('.app_running', 'splash_photo.json', 'splash_verse.json',
                'bg.png')

# ⚠⚠⚠ **MSVC C++ 런타임을 함께 보낸다**(2026-09-17 — 첫 배포가 조용히 죽었다).
#   파이썬은 `vcruntime140*.dll` 만 있으면 서는데(설치본에 들어 있다)
#   **PyQt6·numpy·PIL 은 `msvcp140.dll` 을 쓴다.** 받는 PC 에 Visual C++
#   재배포 패키지가 없으면 그 자리에서 **아무 말 없이** 죽는다.
#   ★ 앱 폴더에 함께 두는 것(app-local deployment)은 재배포 허용 범위다.
#   ⚠ 없으면 **이름을 대고 넘어간다** — 조용히 빠뜨리지 않는다(§0-1).
VC_DLLS = ('msvcp140.dll', 'msvcp140_1.dll', 'msvcp140_2.dll',
           'msvcp140_codecvt_ids.dll', 'concrt140.dll',
           'vcruntime140.dll', 'vcruntime140_1.dll', 'vccorlib140.dll')


def vc_src():
    """시스템에서 그 DLL 을 찾는다 — 64비트는 `System32` 다."""
    root = os.environ.get('SystemRoot', r'C:\Windows')
    return os.path.join(root, 'System32')

# **일부러 안 보내는** 바깥 꾸러미 — 까닭을 적는다(§0-1 조용히 빼지 않는다)
SKIP_PKGS = {
    'googleapiclient': '관리자 전용(유튜브 수집) · `try/except ImportError` 로 '
                       '감싸여 있어 없으면 조용히 꺼진다(실측 102MB 를 뺀다)',
    'google': 'googleapiclient 짝',
    'googleapiclient_discovery': 'googleapiclient 짝',
    'pandas': '관리자 분석용',
    'openpyxl': '관리자 내보내기',
    'cryptography': '관리자 인증',
}


ICON_PREF = ('app_user.ico', 'Hagah Dabar.ico', 'app_tray.ico')


def app_icon():
    """바로가기에 붙일 아이콘 — **있는 것**을 선택한다.

    ⚠ `user_main` 은 `icons/app_user.ico` 를 찾는데 실측 그 파일이 **없다**
      (지금 있는 것은 `Hagah Dabar.ico`). `iconbitmap` 이 try 로 감싸여 있어
      **조용히 기본 아이콘**으로 뜬다 — 배포에서는 그것이 눈에 띈다.
      ⇒ 여기서는 있는 것을 골라 붙이고, 없으면 **아이콘을 안 붙인다**.
    """
    for n in ICON_PREF:
        p = os.path.join(APP_DIR, 'icons', n)
        if os.path.exists(p):
            return n
    return ''


def _size(p):
    if os.path.isfile(p):
        return os.path.getsize(p)
    t = 0
    for r, _d, fs in os.walk(p):
        for f in fs:
            try:
                t += os.path.getsize(os.path.join(r, f))
            except OSError:
                pass
    return t


def _mb(n):
    return '%.1f MB' % (n / 1e6)


# ── 꾸러미 찾기 ────────────────────────────────────────────────────────
def _by_record(name):
    """설치 기록(`dist-info/RECORD`)으로 그 배포본의 **맨 위 항목 전부**.

    ★★★ **이름 짐작을 버린 까닭** — `charset_normalizer` 는 mypyc 로 컴파일한
      곁파일 이름이 **해시**(`ada92cb5…__mypyc.pyd`)라 어떤 규칙으로도 못
      맞힌다. 꾸러미가 스스로 적어 둔 목록을 읽는 것이 유일하게 옳다.
    ⚠ `../../Scripts/…` 처럼 site-packages 밖으로 나가는 줄은 건너뛴다.
    """
    import importlib.metadata as md
    dists = set()
    try:
        for mod, ds in md.packages_distributions().items():
            if mod == name:
                dists |= set(ds)
    except Exception:
        pass
    if not dists:
        try:
            dists = {md.distribution(name).metadata['Name']}
        except Exception:
            return []
    tops, base = set(), None
    for dn in dists:
        try:
            d = md.distribution(dn)
            fs = d.files or []
        except Exception:
            continue
        for f in fs:
            rel = str(f).replace('\\', '/')
            if rel.startswith('..') or not rel:
                continue
            head = rel.split('/')[0]
            if head in ('__pycache__',):
                continue
            tops.add(head)
            if base is None:
                try:
                    base = os.path.dirname(os.path.abspath(str(d.locate_file(
                        rel.split('/')[0]))))
                except Exception:
                    base = None
    if not tops:
        return []
    if base is None:
        import sysconfig
        base = sysconfig.get_paths()['purelib']
    out = []
    for t_ in sorted(tops):
        fp = os.path.join(base, t_)
        if os.path.exists(fp):
            out.append(fp)
    return out


def pkg_paths(name):
    """그 꾸러미가 차지하는 경로 전부 — **설치 기록이 먼저**다."""
    rec = _by_record(name)
    if rec:
        return rec
    try:
        mod = __import__(name)
    except Exception:
        return []
    base = getattr(mod, '__file__', None)
    if not base:
        return []
    d = os.path.dirname(os.path.abspath(base))
    out = []
    if os.path.basename(d).lower() == name.lower():
        out.append(d)
        sp = os.path.dirname(d)
    else:                      # 단일 모듈(.py / .pyd)
        out.append(os.path.abspath(base))
        sp = d
    low = name.lower().replace('-', '_')
    try:
        for e in os.listdir(sp):
            el = e.lower()
            if el.startswith(low) and (el.endswith('.dist-info')
                                       or el.endswith('.libs')):
                out.append(os.path.join(sp, e))
            # pyqt6_sip / pyqt6_qt6 처럼 **짝 꾸러미**
            elif low == 'pyqt6' and el.startswith('pyqt6_'):
                out.append(os.path.join(sp, e))
    except OSError:
        pass
    seen, uniq = set(), []
    for p in out:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq


def wanted(no_video=False, no_voice=False):
    off = set()
    if no_video:
        off.add('video')
    if no_voice:
        off.add('voice')
    return [(n, why) for n, why, tag in PKGS if tag not in off]


# ── 코드가 실제로 부르는 바깥 꾸러미 ──────────────────────────────────
def third_party():
    """보낼 코드 전체를 훑어 **표준 라이브러리가 아닌 import** 를 모은다."""
    import ast
    std = set(sys.stdlib_module_names)
    local = {f[:-3] for f in os.listdir(APP_DIR) if f.endswith('.py')}
    ad = os.path.join(APP_DIR, 'admin')
    if os.path.isdir(ad):
        # ⚠ `admin` 은 **우리 폴더**다 — 바깥 꾸러미로 세면 안 된다
        local |= {f[:-3] for f in os.listdir(ad) if f.endswith('.py')}
        local |= {'admin'}
    hits = {}
    files = [os.path.join(APP_DIR, f) for f in os.listdir(APP_DIR)
             if f.endswith('.py')]
    if os.path.isdir(ad):
        files += [os.path.join(ad, f) for f in os.listdir(ad)
                  if f.endswith('.py')]
    for p in files:
        try:
            tree = ast.parse(io.open(p, encoding='utf-8',
                                     errors='replace').read())
        except Exception:
            continue
        for n in ast.walk(tree):
            names = []
            if isinstance(n, ast.Import):
                names = [a.name.split('.')[0] for a in n.names]
            elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
                names = [n.module.split('.')[0]]
            for m in names:
                if m and m not in std and m not in local and m != '__future__':
                    hits.setdefault(m, set()).add(os.path.basename(p))
    return hits


# ── 배포 DB ────────────────────────────────────────────────────────────
def slim_db(out, src=None, log=print):
    """배포용 `bible_master.db` — 감사 로그·백업 표를 걷고 **VACUUM**.

    ⚠ `VACUUM INTO` 로 뜬다(§0-5 `db_backup`) — `.db`+`-wal`+`-shm` 세 파일이
      한 몸이라 그냥 복사하면 반쪽이 된다.
    ⚠ **다 되기 전에는 완성본처럼 보이지 않는다** — `.tmp` 로 만들고 끝에
      제 이름을 준다(사용자가 반쯤 된 파일을 옮긴 적이 있다).
    """
    src = src or appdb.resolve_db(appdb.MAIN_DB_NAME)
    tmp = out + '.tmp'
    for p in (tmp, out):
        if os.path.exists(p):
            os.remove(p)
    t0 = time.time()
    c = sqlite3.connect(src)
    try:
        c.execute("PRAGMA wal_checkpoint(FULL)")
        c.execute("VACUUM INTO ?", (tmp,))
    finally:
        c.close()
    log('  사진 %s (%.0f초)' % (_mb(os.path.getsize(tmp)), time.time() - t0))

    c = sqlite3.connect(tmp)
    try:
        names = [r[0] for r in c.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")]
        n_row = 0
        for t in DROP_ROWS:
            if t in names:
                n = c.execute('SELECT COUNT(*) FROM "%s"' % t).fetchone()[0]
                c.execute('DELETE FROM "%s"' % t)
                n_row += n
                log('  %s %d행 비움' % (t, n))
        # ★ 2026-10-13 (docs/1.txt 73-5) — 사용자 PC 에서는 배포 자료 변경 이력을 **끈 채** 보낸다.
        #   켜 두면 팩을 받을 때마다 지워지는 옛 행 수십만 줄이 쌓인다(정본은 다음 팩이라 쓸 데가 없다).
        #   내 자료 쪽(`user_audit_switch`)은 그대로 켠다 — 내 글을 되살리는 수단이다.
        if 'sys_audit_switch' in names:
            c.execute('UPDATE sys_audit_switch SET enabled=0')
            log('  배포 자료 변경 이력 기록 꺼짐')
        n_drop = 0
        for t in names:
            if t.startswith('temp_'):
                c.execute('DROP TABLE IF EXISTS "%s"' % t)
                n_drop += 1
        log('  temp_* 백업 표 %d개 걷음' % n_drop)
        c.commit()
        c.execute('VACUUM')
        c.commit()
    finally:
        c.close()
    # ★★ 2026-10-11 — 비밀 열쇠(API 키)는 배포 DB 에 있으면 안 된다(secret_store).
    #   ① 옛 자리(sys_config) 줄을 털고 ② 파일 전체를 훑어 하나라도 있으면 **완성본을 만들지 않는다**.
    import secret_store as _SS
    n_sec = _SS.scrub_db(tmp)
    if n_sec:
        log('  비밀 열쇠 줄 %d개 털어 냄' % n_sec)
    with open(tmp, 'rb') as _f:
        _tail = b''
        while True:
            _b = _f.read(8 << 20)
            if not _b:
                break
            if _SS.find_leaks(_tail + _b):
                os.remove(tmp)
                raise ValueError('⚠ 배포 DB 에 비밀 열쇠가 남아 있어 만들지 않습니다 — secret_store.py --status 로 확인')
            _tail = _b[-128:]
    os.replace(tmp, out)
    log('  ⇒ %s  %s' % (os.path.basename(out), _mb(os.path.getsize(out))))
    return out


def empty_user_db(out, src=None, log=print):
    """빈 `user_data.db` — **스키마만**(사용자 글이 들어갈 그릇).

    ⚠ 행은 한 줄도 안 담는다 — 남의 묵상노트를 보내는 일이 되면 안 된다.
    """
    src = src or appdb.user_db_path(appdb.MAIN_DB_NAME)
    if os.path.exists(out):
        os.remove(out)
    s = sqlite3.connect(src)
    d = sqlite3.connect(out)
    try:
        n = 0
        for typ, sql in s.execute(
                "SELECT type, sql FROM sqlite_master WHERE sql IS NOT NULL "
                "AND name NOT LIKE 'sqlite_%' ORDER BY "
                "CASE type WHEN 'table' THEN 0 WHEN 'index' THEN 1 ELSE 2 END"):
            try:
                d.execute(sql)
                n += 1
            except sqlite3.Error:
                pass
        d.commit()
        rows = sum(r[0] for r in [
            d.execute('SELECT COUNT(*) FROM "%s"' % t[0]).fetchone()
            for t in d.execute("SELECT name FROM sqlite_master "
                               "WHERE type='table'")])
    finally:
        s.close()
        d.close()
    log('  ⇒ %s  스키마 %d개 · 행 %d  %s'
        % (os.path.basename(out), n, rows, _mb(os.path.getsize(out))))
    if rows:
        raise SystemExit('빈 개인 DB 에 행이 남았다 — 보내면 안 된다')
    return out



# ── 배포 기본값 씨앗 ───────────────────────────────────────────────────
#   ⚠⚠⚠ **허용 목록**이다. 여기 없는 열쇠는 안 보낸다 — 제외 목록으로 두면
#     새 열쇠가 생기는 날 개인 자료가 조용히 샌다(§C-2).
SEED_CFG = (
    # 색·글꼴
    'UI_THEME', 'THEME', 'font_family', 'font_size', 'READING_FONT',
    # 역본
    'BIBLE_VERSION', 'PREFERRED_VERSIONS', 'READING_VERSIONS',
    'v1_code', 'v1_color', 'v1_font', 'v1_size',
    'v2_color', 'v2_font', 'v2_size',
    # 설명 탭
    'DESC_MODE', 'DESC_TIER', 'DESC_SECTIONS',
    # P2 탭 짜임 — 2026-10-13 설명·묵상노트 두 탭(docs/1.txt 75) · 설명 탭 갈래와 직전 탭만
    'P2_DG', 'P2_TAB', 'LANGSEL_P2_DESC',
    # P4 구절연결·NodePanel
    'P4_NODE_MAIN_TABS', 'P4_NODE_MORE_MODE', 'P4_NODE_HIDE_EMPTY',
    'P4_NODE_BR_FLOW', 'P4_NODE_BR_LINK', 'P4_NODE_BR_NOTE', 'P4_NODE_DG',
    'P4_NODE_TAB_CANVAS', 'P4_NODE_TAB_TREE',
    'P4_BR_COMPARE', 'P4_BR_REFS', 'P4_BR_VIDEO',
    # 주요용어
    'EB_MAIN_TABS', 'EB_MORE_MODE', 'EB_HIDE_EMPTY', 'EB_MORE_BR',
    # 캔버스
    'CANVAS_LINK_LIMIT', 'LINK_RANK_WEIGHTS',
    # 표시 언어(화면마다)
    'LANGSEL_BOOK', 'LANGSEL_COMMENTARY', 'LANGSEL_COMPOSE', 'LANGSEL_DESC',
    'LANGSEL_DESCCOMM', 'LANGSEL_DICT', 'LANGSEL_LENS', 'LANGSEL_PLAN_BOOK',
    'LANGSEL_REF',
    # 렌즈묵상
    'LENS_VERS_SHOW', 'LENS_VIEW_MODE', 'LENS_TREE_HIDDEN',
    # 읽기·영상
    'READ_MODE', 'VIDEO_OPEN_MODE', 'LP_KIND', 'LP_OPEN_MODE', 'LINKS_VIDEO',
    'MYPATH_BR_FAV',
    # 검색
    'SEARCH_DEEP', 'SEARCH_SCOPE_OFF', 'SEARCH_BUCKET_OFF',
    # 최신 컨텐츠 번역
    'RSS_AUTOTRANSLATE', 'RSS_TRANSLATE_LANG', 'RSS_XL_LANG',
    'RSS_XL_LANG_ITEMS', 'RSS_XL_LANG_YT', 'RSS_LANG_ONLY',
    # 언어·나라
    'user_lang', 'user_country', 'DL_LANG', 'DL_LANGS',
    # 앱 동작
    'CLOSE_MODE',
)

#   ⚠ **안 보내는 것을 까닭과 함께 적어 둔다** — 나중에 「왜 빠졌지」를
#     다시 묻지 않게. selftest 가 이 둘이 안 겹치는지 잰다.
SKIP_CFG = {
    'SUPPORT_EMAIL': '개인 — 문의 주소',
    'SUPPORT_UUID': '개인 — 익명 식별자(같으면 두 사람이 한 사람이 된다)',
    'SYNC_SEED': '개인 — 동기화 씨앗', 'SYNC_FAILS': '개인', 'SYNC_LAST_OK': '개인',
    'ANNOUNCE_LAST_SEEN': '개인 — 어디까지 읽었나',
    'READING_HISTORY': '개인 — 읽은 기록', 'READING_FAVORITES': '개인 — 즐겨찾기',
    'READ_LENS_CONTAINERS': '개인 — 읽은 렌즈',
    'COMPOSE_DRAFT': '개인 — 쓰다 만 글', 'COMPOSE_SCOPE': '개인',
    'ME_RECENT': '개인 — 최근 연결', 'ME_LAST_LINK': '개인',
    'first_run_done': '★ 받는 분은 **처음 켜는 것이 맞다**',
    'last_verse_id': '개인 — 마지막으로 본 절',
    'SHOW_HIDDEN': '가린 것까지 보이는 설정 — 받는 분에게는 기본이 아니다',
    'FONT_WIN_GEOM': '절대 좌표 — 화면이 다르면 뜻이 없다',
    'OC_GEOM': '절대 좌표', 'rel_edit_pop': '절대 좌표',
    'v_link_edit_geo': '절대 좌표', 'SYMBOL_POP_XY': '절대 좌표',
    'P4_NODE_PANEL_WIDTH': '칸 나눔 픽셀 — 작은 화면을 삼킨다(조이개가 있어도 안 보낸다)',
    'RSS_EXCLUDE_FEEDS': '개인 — 내가 뺀 피드',
}

#   ⚠ 캔버스 배치는 **화면 크기와 무관한 상대 값**이라 보낸다.
#     반대로 `p1_width`·`p1_height`·`kids_sash` 는 픽셀이라 안 보낸다.
SEED_STATE = (
    'cfg_box_limit', 'cfg_box_width', 'cfg_font_family', 'cfg_font_size',
    'cfg_h_gap', 'cfg_line_bold', 'cfg_node_chars', 'cfg_node_lines',
    'cfg_node_mode', 'cfg_v_gap',
    'last_scope_t1', 'link_tier_filter', 'path_mode', 'p4_link_view',
    'map_popup_scope', 'kids_view_kind',
)


def seed_user_db(out, src=None, log=print):
    """빈 개인 DB 에 **배포 기본값**을 심는다(허용 목록만)."""
    src = src or appdb.user_db_path(appdb.MAIN_DB_NAME)
    n = 0
    sc = sqlite3.connect(src)
    dc = sqlite3.connect(out)
    try:
        rows = sc.execute(
            'SELECT config_key, config_val FROM user_config').fetchall()
        for k, v in rows:
            if k in SEED_CFG:
                dc.execute('INSERT OR REPLACE INTO user_config'
                           '(config_key, config_val) VALUES(?,?)', (k, v))
                n += 1
        dc.commit()
        miss = [k for k in SEED_CFG
                if k not in {r[0] for r in rows}]
    finally:
        sc.close()
        dc.close()
    log('  배포 기본값 %d개 심음%s'
        % (n, ('  ⚠ 이 PC 에 없어 못 담은 것: ' + ', '.join(miss)) if miss else ''))
    return n


def seed_state(out_json, src=None, log=print):
    """`app_state.json` 씨앗 — **화면 크기와 무관한 것만**."""
    import json
    src = src or os.path.join(APP_DIR, 'app_state.json')
    try:
        d = json.load(io.open(src, encoding='utf-8'))
    except Exception:
        d = {}
    seed = {k: d[k] for k in SEED_STATE if k in d}
    io.open(out_json, 'w', encoding='utf-8').write(
        json.dumps(seed, ensure_ascii=False, indent=1))
    log('  화면 배치 씨앗 %d개 (픽셀 값은 일부러 뺐다)' % len(seed))
    return seed


# ── 시작화면 정리 ──────────────────────────────────────────────────────
def splash_audit(log=print, apply=False):
    """배포에 나갈 시작화면 — **출처가 적힌 것만** 남긴다.

    ⚠⚠⚠ 실측 `sys_splash_image` 넷 가운데 **출처(attribution/license)가 빈
      것이 하나**(`Sea Sunrise`)고, 이름·나라 칸이 시험 자료인 것이 둘
      (`icon`/`dyfeks`, `22`/`fffffff`)이다. 고르는 규칙이 `ORDER BY RANDOM()`
      이라 **새 사용자의 첫 화면이 그것일 확률이 절반**이다.
    ⚠ **지우지 않는다** — `is_active=0` 으로 내린다(§222차). 되돌리는 SQL 을
      함께 찍는다.
    """
    c = appdb.connect()
    try:
        rows = c.execute(
            'SELECT img_id, name, COALESCE(attribution,""), '
            'COALESCE(license,""), COALESCE(country,""), is_active, '
            'LENGTH(png_blob) FROM sys_splash_image ORDER BY img_id').fetchall()
        off = []
        log('  %-4s %-14s %-10s %-8s %-10s %-4s %s'
            % ('id', '이름', '출처', '허락', '나라', '활성', '판정'))
        for i, nm, at, lc, co, ac, sz in rows:
            why = ''
            # ⚠⚠ **이름 길이로 판정하면 안 된다** — 실측 「길」(한 글자)이
            #   정당한 사진인데 걸렸다. 한국어 이름은 짧은 것이 정상이다.
            #   ⇒ 잣대는 둘뿐이다: ⓐ 출처를 못 댄다 ⓑ 나라 칸이 나라가 아니다
            #     (실측 시험 자료는 `dd`·`dyfeks`·`fffffff` 처럼 **소문자**다).
            if not at.strip() or not lc.strip():
                why = '출처를 못 댄다 — 권리 근거가 없다'
            elif co and not re.match(r'^[A-Z][A-Z ]*$', co.strip()):
                why = '나라 칸이 시험 자료다'
            log('  %-4s %-14s %-10s %-8s %-10s %-4s %s'
                % (i, nm, at or '-', lc or '-', co or '-', ac, why or 'OK'))
            if why and ac:
                off.append(i)
        if not off:
            log('  내릴 것 없음')
            return []
        if apply:
            c.executemany('UPDATE sys_splash_image SET is_active=0 '
                          'WHERE img_id=?', [(i,) for i in off])
            c.commit()
            log('  ⇒ %s 를 내렸다(지운 것이 아니다)' % off)
            log('  되돌리려면: UPDATE sys_splash_image SET is_active=1 '
                'WHERE img_id IN (%s);' % ','.join(str(i) for i in off))
        else:
            log('  ⇒ 내릴 후보: %s   (`--splash-off` 로 적용)' % off)
        return off
    finally:
        c.close()


# ── 실행기 ─────────────────────────────────────────────────────────────
RUN_CMD = (
    '@echo off\r\n'
    'chcp 65001 >nul\r\n'
    'rem Hagah - run (test build)\r\n'
    'rem pythonw 를 쓰지 않는다. 오류를 어디에도 안 적기 때문이다.\r\n'
    'if not exist "%~dp0runtime\\python.exe" (\r\n'
    '  echo.\r\n'
    '  echo *** runtime 폴더가 없습니다 ***\r\n'
    '  echo 압축을 풀지 않고 zip 안에서 바로 누르면 이렇게 됩니다.\r\n'
    '  echo zip 을 폴더로 푼 다음 그 폴더 안에서 눌러 주십시오.\r\n'
    '  pause\r\n'
    '  exit /b 1\r\n'
    ')\r\n'
    'cd /d "%~dp0app"\r\n'
    '"%~dp0runtime\\python.exe" -X utf8 "%~dp0app\\user_main.py" '
    '>"%~dp0error_log.txt" 2>&1\r\n'
    'if errorlevel 1 (\r\n'
    '  echo.\r\n'
    '  echo *** 하가를 실행하지 못했습니다 ***\r\n'
    '  echo.\r\n'
    '  type "%~dp0error_log.txt"\r\n'
    '  echo.\r\n'
    '  echo 위 내용과 error_log.txt 를 그대로 보내 주십시오.\r\n'
    '  echo 아무 글도 없으면 [진단.cmd] 를 눌러 주십시오.\r\n'
    '  pause\r\n'
    ')\r\n'
)
DIAG_CMD = (
    '@echo off\r\n'
    'chcp 65001 >nul\r\n'
    'rem Hagah - doctor\r\n'
    'echo 하가 진단을 시작합니다.\r\n'
    'echo.\r\n'
    'if not exist "%~dp0runtime\\python.exe" (\r\n'
    '  echo *** runtime 폴더가 없습니다. 압축이 덜 풀렸습니다. ***\r\n'
    '  pause\r\n'
    '  exit /b 1\r\n'
    ')\r\n'
    '"%~dp0runtime\\python.exe" -V\r\n'
    'if errorlevel 1 (\r\n'
    '  echo.\r\n'
    '  echo *** 꾸러미 안 파이썬이 아예 안 뜹니다 ***\r\n'
    '  pause\r\n'
    '  exit /b 1\r\n'
    ')\r\n'
    'echo.\r\n'
    '"%~dp0runtime\\python.exe" -X utf8 "%~dp0hagah_doctor.py"\r\n'
    'echo.\r\n'
    'pause\r\n'
)
LINK_CMD = (
    '@echo off\r\n'
    'rem Hagah - make a desktop shortcut\r\n'
    'powershell -NoProfile -ExecutionPolicy Bypass -Command ^\r\n'
    ' "$w=New-Object -ComObject WScript.Shell;'
    ' $s=$w.CreateShortcut([Environment]::GetFolderPath(\'Desktop\')'
    '+\'\\%LNK%.lnk\');'
    ' $s.TargetPath=\'%~dp0%RUN%\';'
    ' $s.WorkingDirectory=\'%~dp0\';'
    '%ICO%'
    ' $s.Save()"\r\n'
    'echo 바탕화면에 바로가기를 만들었습니다.\r\n'
    'pause\r\n'
)
ICO_FRAG = ' $s.IconLocation=\'%~dp0app\\icons\\%ICO%\';'
RUN_NAME = '하가 실행.cmd'
DOCTOR_NAME = 'hagah_doctor.py'


def _link_cmd():
    """바로가기 만드는 cmd — 아이콘이 없으면 **그 조각만** 걷는다.

    ⚠ 파워셸 명령은 `^` 로 이어 붙인 **한 물리 줄**이라 「그 줄을 지운다」가
      성립하지 않는다(그러면 명령 전체가 날아간다). 조각을 비운다.
    ⚠ 빈 `IconLocation` 을 넣으면 바로가기가 깨진다 — 넣지 않는 것이 맞다.
    ⚠⚠⚠ **바로가기는 `pythonw` 가 아니라 `cmd` 를 가리킨다**(2026-09-17 —
      첫 배포가 아무 말 없이 안 켜졌다). 창이 하나 뜨는 값을 치르더라도
      **실패가 보이는 쪽**이 시험판에서는 옳다.
    """
    ico = app_icon()
    frag = ICO_FRAG.replace('%ICO%', ico) if ico else ''
    return (LINK_CMD.replace('%LNK%', '하가')
            .replace('%RUN%', RUN_NAME)
            .replace('%ICO%', frag))


def _copytree(src, dst, skip=()):
    def ig(_d, names):
        return [n for n in names if n in skip or n == '__pycache__']
    shutil.copytree(src, dst, ignore=ig, dirs_exist_ok=True)


def build(out, no_video=False, no_voice=False, no_db=False, log=print):
    t0 = time.time()
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(out)
    rt = os.path.join(out, 'runtime')
    ap = os.path.join(out, 'app')
    os.makedirs(ap)

    # ① 파이썬 — 설치본을 다듬어 복사
    log('① 파이썬 런타임')
    P = sys.prefix
    os.makedirs(rt)
    for e in os.listdir(P):
        if e in PY_SKIP_TOP:
            continue
        s, d = os.path.join(P, e), os.path.join(rt, e)
        if e == 'Lib':
            os.makedirs(d)
            for le in os.listdir(s):
                if le in PY_SKIP_LIB:
                    continue
                ls, ld = os.path.join(s, le), os.path.join(d, le)
                if os.path.isdir(ls):
                    _copytree(ls, ld)
                else:
                    shutil.copy2(ls, ld)
            os.makedirs(os.path.join(d, 'site-packages'), exist_ok=True)
        elif os.path.isdir(s):
            _copytree(s, d)
        else:
            shutil.copy2(s, d)
    # ⚠⚠⚠ MSVC C++ 런타임 — 없으면 PyQt6·numpy 가 조용히 죽는다
    src = vc_src()
    got, miss = [], []
    for f in VC_DLLS:
        sp_ = os.path.join(src, f)
        if os.path.exists(sp_):
            shutil.copy2(sp_, os.path.join(rt, f))
            got.append(f)
        else:
            miss.append(f)
    log('   MSVC 런타임 %d개 함께 보냄%s'
        % (len(got), ('  ⚠ 못 찾음: ' + ', '.join(miss)) if miss else ''))
    log('   기본 %s' % _mb(_size(rt)))

    # ② 바깥 꾸러미
    log('② 바깥 꾸러미')
    sp = os.path.join(rt, 'Lib', 'site-packages')
    for name, why in wanted(no_video, no_voice):
        ps = pkg_paths(name)
        if not ps:
            log('   ⚠ %s 없음 — 건너뜀 (%s)' % (name, why))
            continue
        if not _by_record(name):
            log('   ⚠ %s 는 설치 기록이 없어 **이름으로 짐작**했다 —'
                ' 곁파일이 빠질 수 있다' % name)
        for p in ps:
            d = os.path.join(sp, os.path.basename(p))
            if os.path.isdir(p):
                _copytree(p, d)
            else:
                shutil.copy2(p, d)
        log('   %-18s %10s  %s' % (name, _mb(sum(_size(p) for p in ps)), why))

    # ③ 앱 코드
    log('③ 앱 코드')
    n = 0
    for f in os.listdir(APP_DIR):
        if f.endswith('.py') and not f.startswith(SKIP_PY):
            shutil.copy2(os.path.join(APP_DIR, f), os.path.join(ap, f))
            n += 1
    for d in APP_DIRS:
        s = os.path.join(APP_DIR, d)
        if os.path.isdir(s):
            _copytree(s, os.path.join(ap, d))
    log('   .py %d개 + %s  %s' % (n, '/'.join(APP_DIRS), _mb(_size(ap))))

    # ④ DB
    if not no_db:
        log('④ DB')
        slim_db(os.path.join(ap, 'bible_master.db'), log=log)
        empty_user_db(os.path.join(ap, 'user_data.db'), log=log)
        seed_user_db(os.path.join(ap, 'user_data.db'), log=log)
        seed_state(os.path.join(ap, 'app_state.json'), log=log)
    else:
        log('④ DB — 건너뜀(--no-db)')

    # ⑤ 실행기
    io.open(os.path.join(out, '하가 실행.cmd'), 'w',
            encoding='cp949', errors='replace', newline='').write(RUN_CMD)
    io.open(os.path.join(out, '바로가기 만들기.cmd'), 'w',
            encoding='cp949', errors='replace',
            newline='').write(_link_cmd())
    io.open(os.path.join(out, '진단.cmd'), 'w',
            encoding='cp949', errors='replace', newline='').write(DIAG_CMD)
    shutil.copy2(os.path.join(APP_DIR, 'hagah_doctor.py'),
                 os.path.join(out, DOCTOR_NAME))
    io.open(os.path.join(out, '읽어주세요.txt'), 'w',
            encoding='utf-8').write(README)

    tot = _size(out)
    log('\n⇒ %s\n   전부 %s · %.0f초' % (out, _mb(tot), time.time() - t0))
    return out


README = """하가 — 시험판 설치 안내

1. 이 폴더를 통째로 원하는 곳에 복사하십시오(예: C:\\하가).
   ⚠ 폴더 이름과 위치는 무엇이든 괜찮습니다. 옮긴 뒤에도 그대로 돌아갑니다.
2. 「바로가기 만들기.cmd」를 한 번 누르면 바탕화면에 아이콘이 생깁니다.
3. 그 아이콘이나 「하가 실행.cmd」로 실행하십시오.

· 파이썬·SQLite·PyQt 를 따로 설치할 필요가 없습니다. 이 안에 다 있습니다.
· 처음 켤 때 10~20초 걸릴 수 있습니다(윈도우가 파일을 처음 읽는 시간입니다).
· 여러분이 쓴 글은 app\\user_data.db 한 파일에 담깁니다.
  다음 판을 받을 때 **그 파일만 옮겨 오면** 글이 그대로 따라옵니다.

무엇이 안 되는지, 어디서 막히는지 알려 주시면 큰 도움이 됩니다.
"""


def verify_code(dist, log=print):
    """꾸러미 안 코드가 **지금 소스와 글자 하나까지 같은가** (2026-09-17 신설).

    ★★★ 사용자 확정 — 「**배포앱과 지금 내가 사용하는 앱이 100% 동일해야
      한다**(사용자 데이터·환경설정의 차이는 의도된 것이므로 문제가 되지
      않는다)」. 코드를 고치고 꾸러미를 다시 안 만들면 **화면이 다르게
      움직이는데 까닭을 DB 에서 찾게 된다** — 실제로 배지 분모를 그렇게
      쫓았다. 그 헛걸음을 막는 자물쇠다.
    ⚠ **DB·app_state 는 안 본다** — 그 둘은 다른 것이 정상이다(씨앗·개인 자료).
    반환 = (같은 수, 다른 목록, 꾸러미에만 있는 목록, 꾸러미에 빠진 목록)
    """
    import hashlib
    ap = os.path.join(os.path.abspath(dist), 'app')
    if not os.path.isdir(ap):
        raise SystemExit('꾸러미가 아니다 — %s 에 app 폴더가 없다' % dist)

    def _h(p):
        return hashlib.md5(io.open(p, 'rb').read()).hexdigest()

    def _dev_set():
        """build() 가 보내는 것과 **같은 규칙**으로 선택한다."""
        out = {}
        for f in os.listdir(APP_DIR):
            if f.endswith('.py') and not f.startswith(SKIP_PY):
                out[f] = os.path.join(APP_DIR, f)
        for d in APP_DIRS:
            s0 = os.path.join(APP_DIR, d)
            if not os.path.isdir(s0):
                continue
            for root, dirs, files in os.walk(s0):
                dirs[:] = [x for x in dirs if x != '__pycache__']
                for f in files:
                    p = os.path.join(root, f)
                    out[os.path.relpath(p, APP_DIR).replace('\\', '/')] = p
        return out

    dev = _dev_set()
    pkg = {}
    for root, dirs, files in os.walk(ap):
        dirs[:] = [x for x in dirs if x not in ('__pycache__', 'errors')]
        for f in files:
            if f in ('bible_master.db', 'user_data.db', 'app_state.json'):
                continue
            if f.endswith(('.db-wal', '.db-shm', '.log')):
                continue
            # ⚠ **앱이 켜지면서 스스로 만드는 것**은 안 센다 — 한 번 눌러 본
            #   꾸러미에서도 이 검사가 뜻을 잃지 않아야 한다(실측 — 하네스가
            #   앱을 띄운 뒤 다섯 개가 「안 보낼 것이 실렸다」로 잡혔다).
            if f in RUNTIME_MADE or f.startswith('.'):
                continue
            p = os.path.join(root, f)
            pkg[os.path.relpath(p, ap).replace('\\', '/')] = p

    same, diff = 0, []
    for rel, dp in sorted(dev.items()):
        pp = pkg.get(rel)
        if pp is None:
            continue
        if _h(dp) == _h(pp):
            same += 1
        else:
            diff.append(rel)
    only_pkg = sorted(set(pkg) - set(dev))
    missing = sorted(set(dev) - set(pkg))

    log('꾸러미 = %s' % ap)
    log('  같다        %d개' % same)
    log('  **다르다**  %d개%s' % (len(diff),
                                  ('  ← 다시 만들어야 한다' if diff else '')))
    for x in diff:
        log('      %s' % x)
    log('  꾸러미에만  %d개%s' % (len(only_pkg),
                                  ('  ← 안 보낼 것이 실렸다' if only_pkg else '')))
    for x in only_pkg[:20]:
        log('      %s' % x)
    log('  꾸러미에 빠짐 %d개' % len(missing))
    for x in missing[:20]:
        log('      %s' % x)
    ok = not diff and not only_pkg and not missing
    log('\n  %s' % ('PASS — 코드가 100% 같다' if ok
                    else 'FAIL — `--build` 로 다시 만든다'))
    return same, diff, only_pkg, missing


def zip_up(dist, out=None, log=print):
    """꾸러미를 한 파일로 — 보내기 좋게."""
    import zipfile
    dist = os.path.abspath(dist)
    out = out or (dist.rstrip('\\/') + '.zip')
    part = out + '.part'
    if os.path.exists(part):
        os.remove(part)
    t0 = time.time()
    n = raw = 0
    root = os.path.dirname(dist)
    # ⚠⚠ **시험 잔재를 담지 않는다** — 앱을 한 번 켜면 `__pycache__`·
    #   `error_log.txt`·`진단결과.txt` 가 생기고 **씨앗 `app_state.json` 이
    #   내 창 상태로 덮인다**(실측 7,041 → 7,420 파일). 묶을 때 걸러 낸다.
    DIRT = ('error_log.txt', '진단결과.txt', '_run.log')
    with zipfile.ZipFile(part, 'w', zipfile.ZIP_DEFLATED,
                         compresslevel=6, allowZip64=True) as z:
        for r, _d, fs in os.walk(dist):
            _d[:] = [x for x in _d if x != '__pycache__']
            for f in fs:
                if f in DIRT:
                    continue
                fp = os.path.join(r, f)
                try:
                    raw += os.path.getsize(fp)
                except OSError:
                    continue
                z.write(fp, os.path.relpath(fp, root))
                n += 1
                if n % 2000 == 0:
                    log('   … %d 파일 · %s' % (n, _mb(os.path.getsize(part))))
    os.replace(part, out)
    sz = os.path.getsize(out)
    log('⇒ %s\n   %s → %s (%.0f%%) · %d 파일 · %.0f초'
        % (out, _mb(raw), _mb(sz), sz * 100.0 / max(raw, 1), n,
           time.time() - t0))
    return out


# ── 계획 ───────────────────────────────────────────────────────────────
def plan(no_video=False, no_voice=False, log=print):
    log('배포 꾸러미 — 무엇을 담고 얼마나 큰가\n')
    rows, tot = [], 0

    P = sys.prefix
    base = 0
    for e in os.listdir(P):
        if e in PY_SKIP_TOP:
            continue
        s = os.path.join(P, e)
        if e == 'Lib':
            for le in os.listdir(s):
                if le not in PY_SKIP_LIB:
                    base += _size(os.path.join(s, le))
        else:
            base += _size(s)
    rows.append(('파이썬 런타임(tkinter·sqlite3 포함)', base))
    tot += base

    for name, why in wanted(no_video, no_voice):
        ps = pkg_paths(name)
        if not ps:
            log('  ⚠ **%s 를 못 찾았다** — %s' % (name, why))
            continue
        sz = sum(_size(p) for p in ps)
        rows.append(('  %s — %s' % (name, why), sz))
        tot += sz

    code = sum(_size(os.path.join(APP_DIR, f)) for f in os.listdir(APP_DIR)
               if f.endswith('.py') and not f.startswith(SKIP_PY))
    code += sum(_size(os.path.join(APP_DIR, d)) for d in APP_DIRS
                if os.path.isdir(os.path.join(APP_DIR, d)))
    rows.append(('앱 코드(.py + admin/icons)', code))
    tot += code

    src = appdb.resolve_db(appdb.MAIN_DB_NAME)
    db = _size(src) if os.path.exists(src) else 0
    rows.append(('bible_master.db (지금 크기 — 다듬으면 준다)', db))
    tot += db

    for nm, sz in rows:
        log('  %-52s %10s' % (nm, _mb(sz)))
    log('  %-52s %10s' % ('합계(다듬기 전)', _mb(tot)))

    # 막는 것 · 놓친 꾸러미
    log('\n놓친 바깥 꾸러미가 있는가 — 코드를 훑어 본다')
    have = {n for n, _w, _t in PKGS}
    extra = {}
    for m, srcs in sorted(third_party().items()):
        if m in have:
            continue
        if m in SKIP_PKGS:
            log('  · %-20s 안 보낸다 — %s' % (m, SKIP_PKGS[m]))
            continue
        try:
            __import__(m)
            extra[m] = srcs
        except Exception:
            pass          # 안 깔린 것 = 이 PC 에서도 안 쓰는 것
    if extra:
        for m, srcs in sorted(extra.items()):
            log('  ⚠ %-20s ← %s' % (m, ', '.join(sorted(srcs)[:3])))
        log('  ⚠ 위는 **이 PC 에 깔려 있고 코드가 부르는** 꾸러미다 —'
            ' 사용자 화면이 쓰는지 확인하고 PKGS 에 넣는다.')
    else:
        log('  놓친 것 없음')

    log('\n막는 것')
    log('  · Qt6WebEngineCore.dll 하나가 202MB — `--no-video` 로 뺄 수 있다'
        '(재생기만 죽는다)')
    log('  · 감사 로그가 배포 DB 에 그대로 실린다 — `--slim-db` 가 걷는다')
    log('  · 이 꾸러미는 **64비트 윈도우 전용**이다(파이썬·Qt 가 그렇게 빌드돼 있다)')
    return tot


# ── 자가검증 ───────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  OK   %s %s' % (name, got))
        else:
            print('  FAIL %s %s' % (name, got))

    # ① 파이썬이 SQLite 를 품고 있는가 — 「SQLite 설치」 걸음이 없다는 근거
    import sqlite3 as _s
    t('① 파이썬이 SQLite 를 품는다(따로 안 보낸다)',
      bool(_s.sqlite_version), 'sqlite %s' % _s.sqlite_version)
    t('② `_sqlite3` 가 DLLs 안에 있다',
      any(f.startswith('_sqlite3') for f in
          os.listdir(os.path.join(sys.prefix, 'DLLs'))))
    # ③ tkinter — 임베더블을 못 쓰는 까닭
    t('③ tcl 폴더가 설치본에 있다(임베더블에는 없다)',
      os.path.isdir(os.path.join(sys.prefix, 'tcl')))
    t('④ 빼는 목록에 tcl·DLLs 가 들어 있지 않다',
      'tcl' not in PY_SKIP_TOP and 'DLLs' not in PY_SKIP_TOP)
    t('⑤ site-packages 는 통째로 안 베낀다(선택한 것만)',
      'site-packages' in PY_SKIP_LIB)

    # ⑥ 꾸러미 찾기
    ps = pkg_paths('PIL')
    t('⑥ 꾸러미 경로를 찾는다(PIL)', bool(ps), os.path.basename(ps[0]) if ps else '')
    ps6 = pkg_paths('PyQt6')
    t('⑦ PyQt6 는 짝 꾸러미까지 함께 잡는다(pyqt6_sip·qt6)',
      len(ps6) >= 3, '%d개' % len(ps6))
    t('⑧ 없는 꾸러미는 빈 목록(조용히 안 죽는다)', pkg_paths('no_such_pkg_x') == [])
    cn = [os.path.basename(x) for x in pkg_paths('charset_normalizer')]
    t('⑧-2 ★★★ **이름이 해시인 곁파일까지 따라온다**(mypyc)',
      any('__mypyc' in x for x in cn), ' '.join(cn))
    sd = [os.path.basename(x) for x in pkg_paths('sounddevice')]
    t('⑧-3 `sounddevice` 의 `_sounddevice*` 짝도 기록으로 잡힌다',
      any(x.startswith('_sounddevice') for x in sd), ' '.join(sd))
    t('⑧-4 설치 기록을 먼저 본다(짐작이 아니다)',
      bool(_by_record('PIL')))

    # ⑨ 갈래 끄기
    t('⑨ --no-video 면 PyQt6 가 빠진다',
      'PyQt6' not in [n for n, _w in wanted(no_video=True)])
    t('⑩ --no-voice 면 numpy 가 빠진다',
      'numpy' not in [n for n, _w in wanted(no_voice=True)])
    t('⑪ 기본은 전부 보낸다', len(wanted()) == len(PKGS))

    # ⑫ 빈 개인 DB — 행이 한 줄도 없어야 한다
    import tempfile
    d = tempfile.mkdtemp(prefix='dist_st_')
    try:
        src = os.path.join(d, 'src.db')
        c = sqlite3.connect(src)
        c.execute('CREATE TABLE user_note(id INTEGER PRIMARY KEY, t TEXT)')
        c.execute('CREATE INDEX ix_n ON user_note(t)')
        c.execute("INSERT INTO user_note(t) VALUES('내 글')")
        c.commit()
        c.close()
        out = os.path.join(d, 'empty.db')
        empty_user_db(out, src=src, log=lambda *a: None)
        c = sqlite3.connect(out)
        n = c.execute('SELECT COUNT(*) FROM user_note').fetchone()[0]
        idx = c.execute("SELECT COUNT(*) FROM sqlite_master "
                        "WHERE type='index' AND name='ix_n'").fetchone()[0]
        c.close()
        t('⑫ 빈 개인 DB — 표는 있고 **행은 0**', n == 0, '%d행' % n)
        t('⑬ 인덱스도 따라온다', idx == 1)

        # ⑭ 배포 DB 다듬기 — 감사 로그·temp_* 가 걷힌다
        src2 = os.path.join(d, 'm.db')
        c = sqlite3.connect(src2)
        c.execute('CREATE TABLE sys_audit_log(audit_id INTEGER PRIMARY KEY, '
                  'old_json TEXT)')
        c.execute('CREATE TABLE temp_backup_x(a TEXT)')
        c.execute('CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY)')
        c.executemany('INSERT INTO sys_audit_log(old_json) VALUES(?)',
                      [('x' * 500,) for _ in range(400)])
        c.execute("INSERT INTO temp_backup_x VALUES('y')")
        c.execute('INSERT INTO bible_index VALUES(1)')
        c.commit()
        c.close()
        out2 = os.path.join(d, 'slim.db')
        slim_db(out2, src=src2, log=lambda *a: None)
        c = sqlite3.connect(out2)
        a = c.execute('SELECT COUNT(*) FROM sys_audit_log').fetchone()[0]
        tb = c.execute("SELECT COUNT(*) FROM sqlite_master WHERE "
                       "name='temp_backup_x'").fetchone()[0]
        bi = c.execute('SELECT COUNT(*) FROM bible_index').fetchone()[0]
        c.close()
        t('⑭ 감사 로그가 비워진다(표는 남는다)', a == 0, '%d행' % a)
        t('⑮ temp_* 백업 표가 걷힌다', tb == 0)
        t('⑯ **본문은 안 건드린다**', bi == 1, 'bible_index %d행' % bi)
        t('⑰ 다듬은 쪽이 더 작다',
          os.path.getsize(out2) < os.path.getsize(src2),
          '%d → %d' % (os.path.getsize(src2), os.path.getsize(out2)))
        t('⑱ 임시 파일이 안 남는다', not os.path.exists(out2 + '.tmp'))
    finally:
        shutil.rmtree(d, ignore_errors=True)

    # ⑲ 실행기 — 경로를 **제 폴더 기준**으로 푼다(CWD 에 안 기댄다)
    t('⑲ 실행 cmd 가 %~dp0 로 제 자리를 잡는다',
      RUN_CMD.count('%~dp0') >= 2)
    t('⑳ ★★★ **pythonw 를 안 쓴다** — 오류를 어디에도 안 적는다',
      'pythonw.exe' not in RUN_CMD and 'python.exe' in RUN_CMD)
    t('⑳-2 실패하면 그 자리에서 보여 주고 멈춘다',
      'pause' in RUN_CMD and 'errorlevel' in RUN_CMD)
    t('⑳-3 오류를 파일로도 남긴다', 'error_log.txt' in RUN_CMD)
    t('⑳-6 ★★ 배치가 쓰는 **파일 이름은 ASCII**(로케일이 달라도 안 깨진다)',
      all(ord(ch) < 128 for ch in 'error_log.txt' + DOCTOR_NAME))
    for _nm, _txt in (('실행', RUN_CMD), ('진단', DIAG_CMD),
                      ('바로가기', _link_cmd())):
        try:
            _txt.encode('cp949')
            _bad = ''
        except UnicodeEncodeError as _e:
            _bad = _txt[_e.start:_e.end]
        t('⑳-7 %s cmd 가 cp949 로 온전히 적힌다' % _nm, not _bad,
          ('못 적는 글자 %r' % _bad) if _bad else '')
    t('⑳-8 압축을 안 풀었을 때를 먼저 말한다(가장 조용한 자리)',
      'runtime' in RUN_CMD and 'exit /b 1' in RUN_CMD)
    t('⑳-4 진단기를 함께 보낸다',
      os.path.exists(os.path.join(APP_DIR, 'hagah_doctor.py'))
      and '진단' in DIAG_CMD and 'python.exe' in DIAG_CMD)
    t('⑳-5 MSVC 런타임을 함께 보낸다(PyQt6·numpy 가 쓴다)',
      'msvcp140.dll' in VC_DLLS
      and os.path.exists(os.path.join(vc_src(), 'msvcp140.dll')))
    ico = app_icon()
    t('㉑ 붙일 아이콘을 실제로 찾았다', bool(ico), ico or '없음')
    t('㉒ 바로가기에 그 아이콘이 들어간다',
      (not ico) or ('IconLocation' in _link_cmd() and ico in _link_cmd()))
    t('㉓ 아이콘이 없으면 그 줄을 걷는다(깨진 바로가기를 안 만든다)',
      bool(ico) or 'IconLocation' not in _link_cmd())
    t('㉔ ⚠ `user_main` 이 찾는 `app_user.ico` 가 실제로 있는가',
      os.path.exists(os.path.join(APP_DIR, 'icons', 'app_user.ico')),
      '없으면 창 아이콘이 조용히 기본값이 된다')

    t('㉗ 하네스·1회성 패치(`temp_*`·`_*`)는 안 보낸다(남의 것을 바꾼다)',
      SKIP_PY == ('temp_', '_'))
    t('㉗-2 그래도 앱이 쓰는 모듈은 안 걸린다(`_` 로 시작하는 import 0)',
      not [f for f in os.listdir(APP_DIR)
           if f.startswith('_') and f.endswith('.py')
           and f[:-3] in third_party()])
    t('㉘ 묶는 문이 있다(보내는 것까지가 이 도구의 몫)',
      callable(zip_up))
    _zs = io.open(os.path.join(APP_DIR, 'db_dist_build.py'),
                  encoding='utf-8').read()
    t('㉘-2 ★ 묶을 때 시험 잔재를 뺀다(`__pycache__`·오류기록)',
      "_d[:] = [x for x in _d if x != '__pycache__']" in _zs
      and 'error_log.txt' in _zs)
    t('㉙ ★★★ 씨앗은 **허용 목록**이다(제외 목록이 아니다)',
      len(SEED_CFG) > 40 and isinstance(SEED_CFG, tuple))
    t('㉚ 개인 자료가 씨앗에 안 섞인다',
      not (set(SEED_CFG) & set(SKIP_CFG)),
      ' '.join(sorted(set(SEED_CFG) & set(SKIP_CFG))))
    for _k in ('SUPPORT_UUID', 'READING_HISTORY', 'COMPOSE_DRAFT',
               'first_run_done', 'ANNOUNCE_LAST_SEEN', 'SUPPORT_EMAIL'):
        t('㉚-2 %s 는 안 보낸다' % _k, _k not in SEED_CFG)
    for _k in ('OC_GEOM', 'FONT_WIN_GEOM', 'P4_NODE_PANEL_WIDTH',
               'rel_edit_pop', 'SYMBOL_POP_XY'):
        t('㉛ 절대 좌표 %s 는 안 보낸다' % _k, _k not in SEED_CFG)
    for _k in ('p1_width', 'p1_height', 'kids_sash'):
        t('㉛-2 칸 나눔 픽셀 %s 는 씨앗에 없다' % _k, _k not in SEED_STATE)
    t('㉜ 안 보내는 것은 까닭이 적혀 있다',
      all(v.strip() for v in SKIP_CFG.values()))
    t('㉝ 색·글꼴·탭 짜임은 보낸다',
      all(k in SEED_CFG for k in ('UI_THEME', 'font_family', 'P4_NODE_MAIN_TABS',
                                  'CANVAS_LINK_LIMIT', 'PREFERRED_VERSIONS')))
    tp = third_party()
    t('㉕ `admin` 을 바깥 꾸러미로 안 센다(우리 폴더다)', 'admin' not in tp)
    t('㉖ 안 보내는 것은 **까닭과 함께** 적어 둔다',
      all(v.strip() for v in SKIP_PKGS.values()) and
      'googleapiclient' in SKIP_PKGS)

    # ★ 「배포앱과 내 앱이 100% 같다」를 재는 문 (2026-09-17 사용자 확정)
    _vsrc = io.open(__file__, encoding='utf-8').read()
    _vfn = _vsrc.split('def verify_code(')[1].split('\ndef ')[0]
    t('㉗ --verify 가 있다', callable(globals().get('verify_code')))
    t('㉘ --verify 가 build 와 **같은 규칙**으로 선택한다(SKIP_PY·APP_DIRS)',
      'SKIP_PY' in _vfn and 'APP_DIRS' in _vfn)
    t('㉙ --verify 는 DB·app_state 를 안 본다(다른 것이 정상이다)',
      all(x in _vfn for x in
          ('bible_master.db', 'user_data.db', 'app_state.json')))
    t('㉚ --verify 가 「꾸러미에만 있는 것」도 잡는다',
      'only_pkg' in _vfn and 'missing' in _vfn)
    t('㉛ --verify 는 앱이 스스로 만드는 파일을 안 센다(한 번 켜 본 꾸러미)',
      'RUNTIME_MADE' in _vfn and
      all(x in RUNTIME_MADE for x in ('.app_running', 'bg.png')))

    print('\ndb_dist_build selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--plan', action='store_true')
    ap.add_argument('--build')
    ap.add_argument('--slim-db')
    ap.add_argument('--empty-user')
    ap.add_argument('--no-video', action='store_true')
    ap.add_argument('--no-voice', action='store_true')
    ap.add_argument('--no-db', action='store_true')
    ap.add_argument('--zip', action='store_true')
    ap.add_argument('--verify',
                    help='꾸러미 코드가 지금 소스와 같은가')
    ap.add_argument('--splash-audit', action='store_true')
    ap.add_argument('--splash-off', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        raise SystemExit(0 if selftest() else 1)
    if a.splash_audit or a.splash_off:
        splash_audit(apply=a.splash_off)
        return
    if a.verify:
        r = verify_code(a.verify)
        raise SystemExit(0 if not (r[1] or r[2] or r[3]) else 1)
    if a.plan:
        plan(a.no_video, a.no_voice)
    elif a.slim_db:
        slim_db(a.slim_db)
    elif a.empty_user:
        empty_user_db(a.empty_user)
    elif a.build:
        build(a.build, a.no_video, a.no_voice, a.no_db)
        if a.zip:
            zip_up(a.build)
    elif a.zip:
        raise SystemExit('--zip 은 --build 와 함께 쓰거나 폴더를 준다')
    else:
        print(__doc__)


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    main()
