# -*- coding: utf-8 -*-
"""태그 체계 — 스키마·시드·이관·검사 (영구 도구, 2026-08-18 사용자 설계 승인)

  python db_tag_system.py --selftest    # 의무
  python db_tag_system.py --init        # 스키마 (멱등)
  python db_tag_system.py --seed        # 6축 78태그 시드 (멱등)
  python db_tag_system.py --migrate     # 옛 도서 태그(sys_book_unit_tag 등) 이관
  python db_tag_system.py --check       # 정합성 검사
  python db_tag_system.py --list        # 현황

설계 (사용자 확정 — 「태그는 분류의 단일 인터페이스, 정체는 세 원천 중 하나」):
  · `sys_tag_asset.tag_kind` = PLAIN(자립) | ENTITY(엔티티 연동) | DICT(사전 연동).
    연동 태그는 **이름을 원천에서 빌린다**(ENTITY_NAME 11언어) — 이중 관리 0.
    tag_name_sid 가 있으면 그것이 덮개(우선), 없으면 원천 이름.
  · 연결은 범용 `sys_tag_link(sys_tag_id, target_type, target_id)` 하나 —
    target_type = VERSE | LENS | NODE | BOOK | BOOK_UNIT | PLAN | REF_UNIT.
    통계·매트릭스·역조회가 이 표 하나로 끝난다.
  · **& 로 묶는 복합 태그 금지** (사용자 지시 「절대로 버려라」) — 한 태그 한 개념.
  · 승격/강등은 tag_kind 만 갈아탄다 — 링크는 sys_tag_id 에 붙어 안 깨진다.
  · 엔티티·사전·주석·구절(1단계)은 태그 대상이 아니다 — 각자 자기 축이 있다.
"""
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')

TARGET_TYPES = ('VERSE', 'LENS', 'NODE', 'BOOK', 'BOOK_UNIT', 'PLAN', 'REF_UNIT',
                'USER_REF')

# ── 축(카테고리) — **여기가 단일 소스다** ─────────────────────────────────
# ⚠ 2026-08-21 이전에는 이 목록이 **세 곳**에 박혀 있었다(여기 ·
#   옛 `admin/panel_tag_manager._CAT_KO` · `tag_picker.AXES`). 축을 하나
#   늘리면 세 곳을 고쳐야 하고, 한 곳을 빠뜨리면 같은 축이 화면마다 다르게
#   보인다. ⇒ 읽는 쪽이 `axes()` 를 부른다.
# ⚠ **관리자 「태그 관리」 화면은 2026-09-18 에 걷었다**(참고코드/) — 배포
#   태그가 0행이고 그 자리를 주요용어가 맡는다. 지금 이 축을 쓰는 곳은
#   `tag_picker`(개인 태그)뿐이다.
#
# 사람이 읽는 이름은 ui_strings `TAGCAT_*`. 아래 값은 그것이 없을 때의 폴백.
CONCEPT_AXES = (
    ('THEME', '신학 주제'), ('PRACTICE', '신앙 실천'), ('PHASE', '심리·국면'),
    ('EVENT', '구속사 사건'), ('LIFE', '삶의 자리'), ('CURATION', '큐레이션'),
)
# ★ **엔티티 유형이 그대로 축이 된다** (2026-08-21 사용자 승인 — 엔티티를
#   대량 승격하면 태그가 79 → 500 을 넘어 6축으로는 못 고른다).
#   ⚠ 이름을 **지어내지 않는다** — 주요용어 화면(`entity_browser._TYPE_LABEL`)이
#     이미 쓰는 말을 그대로 쓴다.
ENTITY_AXES = (
    ('PERSON', '인물'), ('PLACE', '장소'), ('DOCTRINE', '교리'), ('TERM', '용어'),
    ('IDOL', '우상'), ('NATION', '민족'), ('GROUP', '그룹'), ('FEAST', '절기'),
    ('OBJECT', '사물'), ('SYSTEM', '제도'), ('PHASE', '심리·국면'),
)
CATEGORIES = tuple(c for c, _n in CONCEPT_AXES)          # 옛 이름(개념 축만)
# ★★★ **축 = 주요용어 유형 하나다**(2026-09-18 사용자 「용어 분류값에
#   하나 추가하고 주요용어 관리화면에서 모두 관리」).
#   ⚠⚠ 그전에는 **개념 축 여섯이 따로** 있었는데(신학주제·신앙실천·심리국면·
#     구속사사건·삶의자리·큐레이션) 넷은 다른 자산이 이미 맡고 있었다 —
#     신학주제·신앙실천 = `TERM` · 구속사사건 = 말씀흐름(CHAIN) ·
#     큐레이션 = `sys_verse_highlight`. 정말로 비어 있던 **심리·국면**은
#     이제 `entity_type='PHASE'` 가 맡는다(`db_phase_terms.py`).
#   ⚠ `CONCEPT_AXES` 는 **되돌릴 자리로 남긴다** — 읽는 쪽은 안 쓴다.
ALL_AXES = ENTITY_AXES


def axes(conn=None, lang='KO', only_used=False):
    """축 목록 → [(코드, 이름)]. 화면 두 곳이 이것 하나를 부른다.

    only_used=True 면 **태그가 실제로 있는 축만** 준다 — 빈 서랍에 단추를
    만들지 않는다(§태그 관리 4차에서 정한 규칙)."""
    out = []
    used = None
    if only_used and conn is not None:
        used = {r[0] for r in conn.execute(
            "SELECT DISTINCT tag_category FROM sys_tag_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    for code, dflt in ALL_AXES:
        if used is not None and code not in used:
            continue
        nm = dflt
        if conn is not None:
            try:
                r = conn.execute(
                    "SELECT string_value FROM ui_strings WHERE string_id=? "
                    "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 "
                    "ELSE 2 END LIMIT 1", ('TAGCAT_' + code, (lang or 'KO').upper())
                ).fetchone()
                if r and r[0]:
                    nm = r[0]
            except Exception:
                pass
        out.append((code, nm))
    return out


# ── 스키마 ────────────────────────────────────────────────────────────────

def init_schema(conn):
    cols = {r[1] for r in conn.execute("PRAGMA table_info(sys_tag_asset)")}
    if 'tag_kind' not in cols:
        conn.execute("ALTER TABLE sys_tag_asset ADD COLUMN tag_kind TEXT "
                     "DEFAULT 'PLAIN'")
    if 'entity_id' not in cols:
        conn.execute("ALTER TABLE sys_tag_asset ADD COLUMN entity_id INTEGER")
    if 'dict_ref' not in cols:
        conn.execute("ALTER TABLE sys_tag_asset ADD COLUMN dict_ref INTEGER")
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_tag_link (
        link_id       INTEGER PRIMARY KEY AUTOINCREMENT,
        sys_tag_id    INTEGER NOT NULL,
        target_type   TEXT NOT NULL,
        target_id     INTEGER NOT NULL,
        record_status TEXT DEFAULT 'LIVE',
        UNIQUE(sys_tag_id, target_type, target_id))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tag_link_target "
                 "ON sys_tag_link(target_type, target_id)")
    # 같은 원천의 이중 승격 차단 (부분 유니크 — NULL 은 여러 행 허용)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_tag_entity_unq "
                 "ON sys_tag_asset(entity_id) WHERE entity_id IS NOT NULL")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_tag_dict_unq "
                 "ON sys_tag_asset(dict_ref) WHERE dict_ref IS NOT NULL")
    conn.commit()


#: ★★ 2026-08-24 — **태그 연결을 통합 표로 옮겼다**(`db_link_migrate.py`).
#   `sys_link_asset(link_type='TAG_<대상>')` 한 행이다. **A는 늘 태그**다.
#   옛 표 `sys_tag_link` 는 되돌릴 수 있게 남아 있지만 **읽지 않는다.**
LINK_TBL = 'sys_link_asset'
#: 대상 종류 → 자산 코드 넉 자. `link_picker.CODE` 와 겹치는 것은 같은 값이어야 한다.
#: 대상 종류 → **넉 자 코드**. `link_picker.CODE` 와 **같아야 한다**.
#  ⚠⚠ **2026-08-29 — 다섯이 빠져 있었다**(VERSE·ENTITY·PERICOPE·MEDIA·CHAIN).
#    빠지면 `_lt` 의 폴백(`TGT_CODE.get(t, t)`)이 **이름을 그대로** 써서
#    `TAG_VERSE`·`TAG_ENTITY` 라는 **틀린 철자**로 저장했다. 태그 쪽은 같은
#    폴백으로 읽으니 자기 것은 보이지만, `overlay_read`·`link_picker` 는
#    넉 자 코드(`VERS`)로 짝을 맞추므로 **연결 목록·개수에서 갈렸다.**
#    실측 잔재 — `TAG_VERSE` 7행 · `TAG_ENTITY` 1행(전부 HIDE).
#    ⇒ 두 표가 어긋나지 않는지 `link_picker --selftest` 가 잰다.
TGT_CODE = {'BOOK_UNIT': 'BUNT', 'LENS': 'CONT', 'BOOK': 'BOOK', 'NODE': 'NODE',
            'PLAN': 'PLAN', 'REF_UNIT': 'REFU', 'USER_REF': 'UREF',
            'UPLAN': 'UPLN', 'ULENS': 'UCNT', 'UNODE': 'UNOD',
            'VERSE': 'VERS', 'ENTITY': 'ENTI', 'PERICOPE': 'PERI',
            'MEDIA': 'MEDI', 'CHAIN': 'CHAI',
            # ★ 묵상노트 (2026-08-30 자산 승격) — **여기 안 넣으면 폴백이
            #   `TAG_NOTE` 대신 이름을 그대로 써서 조용히 0건이 된다**(§97차
            #   다섯 종류 누락 사고와 같은 자리). 넉 자가 이미 `NOTE` 라 같다.
            'NOTE': 'NOTE'}


def _lt(target_type, head='TAG'):
    """`TAG_BUNT` 꼴. 모르는 종류면 이름 그대로(그러면 아무것도 안 걸린다)."""
    return '%s_%s' % (head, TGT_CODE.get(target_type, target_type))


def _mine_where(head='TAG'):
    """**태그 연결만** 선택하는 조건. ⚠⚠ 이것을 빼고 UPDATE/DELETE 를 돌리면
    통합 표의 **모든 연결**(28,000행)이 함께 바뀐다."""
    ph = ','.join('?' * len(TGT_CODE))
    return ("link_type IN (%s)" % ph,
            tuple('%s_%s' % (head, c) for c in TGT_CODE.values()))


def init_user_schema(db_path=DB):
    """사용자 쪽 — user_tag_asset 은 기존, user_tag_link 만 신설."""
    conn = appdb.connect(db_path)
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS userdb.user_tag_link (
            link_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            tag_source    TEXT NOT NULL DEFAULT 'SYS',
            tag_id        INTEGER NOT NULL,
            target_type   TEXT NOT NULL,
            target_id     INTEGER NOT NULL,
            record_status TEXT DEFAULT 'LIVE',
            UNIQUE(tag_source, tag_id, target_type, target_id))""")
        conn.commit()
    finally:
        conn.close()


# ── 이름 해석 (화면 공용) ─────────────────────────────────────────────────

def short_label(name):
    """태그로 쓸 **짧은 이름** — 원어 병기의 첫 낱말만.

    ★ 2026-08-21 사용자 지시. 엔티티 이름은 원어를 병기한다
      (`사랑 · 아하브 · 아가페` — 평균 10.1자, 107개 중 44개). 주요용어
      화면에서는 그 병기가 필요하지만 **태그 칩에는 길다.**
    ⚠ 이름 자체는 안 바꾼다 — **표시만** 자른다. 검색은 원어까지 걸린다
      (`tag_display_name(..., short=False)` 가 원본을 준다)."""
    s = str(name or '')
    head = s.split('·')[0].strip()
    return head or s


def tag_overlay(conn, sid, kind, eid):
    """태그 덮개 행 — (record_status, 내 이름) 또는 None (2026-08-26 읽기 배선).

    자연 열쇠 = PLAIN 'P|sid' / ENTITY 'E|entity_code' (overlay.TagOverlay 와
    같은 규칙 — entity_id 는 PK 라 안 쓴다). origin_key 없는 내 태그는 덮개 밖."""
    try:
        if (kind or 'PLAIN') == 'ENTITY' and eid:
            r = conn.execute('SELECT entity_code FROM sys_entity_master '
                             'WHERE entity_id=?', (eid,)).fetchone()
            if not r:
                return None
            okey = 'E|%s' % r[0]
        elif sid:
            okey = 'P|%s' % sid
        else:
            return None
        r = conn.execute(
            'SELECT tag_name_sid, record_status FROM user_tag_asset '
            'WHERE origin_key=?', (okey,)).fetchone()
    except Exception:
        return None                          # origin_key 칼럼 없는 옛 DB
    if not r:
        return None
    return (r[1], r[0])


def user_hidden_entity_codes(conn):
    """사용자가 가린 엔티티 code 집합 (user_entity_asset HIDE) — 목록 필터용."""
    try:
        return {r[0] for r in conn.execute(
            "SELECT entity_code FROM user_entity_asset "
            "WHERE record_status='HIDE'")}
    except Exception:
        return set()


def tag_overlay_row(conn, sys_tag_id):
    """overlay.TagOverlay 의 save/hide/revert 에 넘길 row — 없으면 None.

    tag_picker 의 「이름 고치기·숨기기」 입구가 쓴다(2026-08-26)."""
    r = conn.execute(
        "SELECT t.tag_name_sid, t.tag_category, COALESCE(t.tag_kind,'PLAIN'), "
        "e.entity_code FROM sys_tag_asset t "
        "LEFT JOIN sys_entity_master e ON e.entity_id = t.entity_id "
        "WHERE t.sys_tag_id=?", (sys_tag_id,)).fetchone()
    if not r:
        return None
    # ⚠ origin_key 를 **여기서 박아 둔다** — 이름을 바꾼 뒤 저장하면 열쇠가
    #   새 이름으로 계산되어 sys 와 짝이 안 맞는다(실측으로 잡음). 열쇠는
    #   언제나 **원래 정체**(원래 sid / entity_code)다.
    if r[2] == 'ENTITY' and r[3]:
        okey = 'E|%s' % r[3]
    elif r[0]:
        okey = 'P|%s' % r[0]
    else:
        okey = None
    return {'tag_name_sid': r[0], 'tag_category': r[1],
            'tag_kind': r[2], 'entity_code': r[3], 'origin_key': okey}


def tag_display_name(conn, row, lang='KO', short=True):
    """(tag_name_sid, tag_kind, entity_id, dict_ref) → 표시 이름.
    우선순위: **덮개(내 이름)** → tag_name_sid(ui_strings) → 원천(ENTITY_NAME /
    사전 제목) → 키 자체.

    `short=True`(기본) 면 원어 병기의 첫 낱말만 — 화면·관리 공통(사용자 지시).
    `short=False` 면 원본 그대로 — **검색 색인**이 이것을 쓴다."""
    sid, kind, eid, dref = row
    lang = (lang or 'KO').upper()
    _cut = short_label if short else (lambda x: x)
    # ★ 덮개 — 내가 바꾼 이름이 이긴다 (숨김 판정은 목록 쪽 몫)
    ov = tag_overlay(conn, sid, kind, eid)
    if ov is not None and ov[0] != 'HIDE' and (ov[1] or '').strip():
        return _cut(ov[1].strip())
    if sid:
        r = conn.execute(
            "SELECT string_value FROM ui_strings WHERE string_id=? "
            "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 "
            "WHEN 'KO' THEN 2 ELSE 3 END LIMIT 1", (sid, lang)).fetchone()
        if r:
            return _cut(r[0])
    if kind == 'ENTITY' and eid:
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
            "AND clicked_id=? AND record_status='LIVE' "
            "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 "
            "WHEN 'KO' THEN 2 ELSE 3 END LIMIT 1", (eid, lang)).fetchone()
        if r:
            return _cut(r[0])
    if kind == 'DICT' and dref:
        r = conn.execute(
            "SELECT COALESCE(NULLIF((SELECT title FROM sys_ref_text "
            "  WHERE ref_unit_id=u.ref_unit_id AND record_status='LIVE' "
            "  ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 ELSE 1 END "
            "  LIMIT 1), ''), u.unit_label) FROM sys_ref_unit u "
            "WHERE u.ref_unit_id=?", (lang, dref)).fetchone()
        if r and r[0]:
            return _cut(r[0])
    return sid or ('#%s' % (eid or dref or '?'))


def fetch_tags_for(conn, target_type, target_id, lang='KO'):
    """이 자산에 붙은 태그들 → [(sys_tag_id, 이름, kind, category, entity_id)]."""
    out = []
    # ⚠ 원천(엔티티)이 숨으면 그 태그도 안 보인다 — `tag_picker.all_tags` 와
    #   같은 규칙(2026-08-21). 두 곳이 다르면 목록에 없는 태그가 자산에는 붙어
    #   보인다.
    for tid, sid, kind, eid, dref, cat in conn.execute(
            "SELECT t.sys_tag_id, t.tag_name_sid, COALESCE(t.tag_kind,'PLAIN'),"
            " t.entity_id, t.dict_ref, t.tag_category "
            # ★ 2026-08-24 통합 표(`TAG_<대상>`). **A는 늘 태그**다.
            "FROM %s l JOIN sys_tag_asset t "
            "  ON t.sys_tag_id = l.clicked_id "
            "LEFT JOIN sys_entity_master e ON e.entity_id = t.entity_id "
            "WHERE l.link_type=? AND l.target_id=? "
            "AND COALESCE(l.record_status,'LIVE')='LIVE' "
            "AND COALESCE(t.record_status,'LIVE')='LIVE' "
            "AND (t.entity_id IS NULL OR COALESCE(e.record_status,'LIVE')='LIVE') "
            "ORDER BY t.tag_category, t.sys_tag_id" % LINK_TBL,
            (_lt(target_type), target_id)):
        # ★ 덮개 (2026-08-26 읽기 배선) — 내가 숨긴 태그·가린 엔티티의 태그는
        #   칩에서도 뺀다 (all_tags 와 같은 규칙 — 두 곳이 다르면 목록에 없는
        #   태그가 자산에는 붙어 보인다).
        ov = tag_overlay(conn, sid, kind, eid)
        if ov is not None and ov[0] == 'HIDE':
            continue
        if kind == 'ENTITY' and eid is not None:
            _hid = user_hidden_entity_codes(conn)
            if _hid:
                r = conn.execute('SELECT entity_code FROM sys_entity_master '
                                 'WHERE entity_id=?', (eid,)).fetchone()
                if r and r[0] in _hid:
                    continue
        out.append((tid, tag_display_name(conn, (sid, kind, eid, dref), lang),
                    kind, cat, eid))
    return out


def link(conn, tag_id, target_type, target_id):
    """멱등 연결. HIDE 행은 되살린다 (UNIQUE 라 INSERT 만 하면 충돌)."""
    lt = _lt(target_type)
    row = conn.execute(
        "SELECT sys_link_id, COALESCE(record_status,'LIVE') FROM %s "
        "WHERE link_type=? AND clicked_id=? AND target_id=?" % LINK_TBL,
        (lt, tag_id, target_id)).fetchone()
    if row is None:
        conn.execute("INSERT INTO %s (link_type, clicked_id, target_id) "
                     "VALUES (?,?,?)" % LINK_TBL, (lt, tag_id, target_id))
        return 'new'
    if row[1] != 'LIVE':
        conn.execute("UPDATE %s SET record_status='LIVE' "
                     "WHERE sys_link_id=?" % LINK_TBL, (row[0],))
        return 'revived'
    return 'same'


# ── 시드 — 6축 78태그 (사용자 확정: 전부 단일 개념, & 금지) ────────────────

# (tag_name_sid | None, kind, entity_ko_name | None, category)
#  ENTITY 는 KO 이름으로 entity_id 를 실행 시점에 해석한다(번호 하드코딩 금지).
SEED = [
    # A. THEME — 엔티티 연동 16 + 자립 3
    (None, 'ENTITY', '구원', 'THEME'), (None, 'ENTITY', '은혜', 'THEME'),
    (None, 'ENTITY', '믿음', 'THEME'), (None, 'ENTITY', '회개', 'THEME'),
    (None, 'ENTITY', '칭의', 'THEME'), (None, 'ENTITY', '중생', 'THEME'),
    (None, 'ENTITY', '성화', 'THEME'), (None, 'ENTITY', '언약', 'THEME'),
    (None, 'ENTITY', '교회', 'THEME'), (None, 'ENTITY', '구속사', 'THEME'),
    (None, 'ENTITY', '천국', 'THEME'), (None, 'ENTITY', '재림', 'THEME'),
    (None, 'ENTITY', '하나님의 사랑', 'THEME'),
    (None, 'ENTITY', '성령의 은사', 'THEME'),
    (None, 'ENTITY', '성령의 열매', 'THEME'),
    (None, 'ENTITY', '하나님의 속성', 'THEME'),
    ('TAG_GOSPEL', 'PLAIN', None, 'THEME'),
    ('TAG_CHRIST', 'PLAIN', None, 'THEME'),
    ('TAG_SPIRIT', 'PLAIN', None, 'THEME'),
    # B. PRACTICE — 자립 9
    ('TAG_PRAYER', 'PLAIN', None, 'PRACTICE'),
    ('TAG_WORSHIP', 'PLAIN', None, 'PRACTICE'),
    ('TAG_PRAISE', 'PLAIN', None, 'PRACTICE'),
    ('TAG_THANKS', 'PLAIN', None, 'PRACTICE'),
    ('TAG_FORGIVE', 'PLAIN', None, 'PRACTICE'),
    ('TAG_OBEY', 'PLAIN', None, 'PRACTICE'),
    ('TAG_SERVE', 'PLAIN', None, 'PRACTICE'),
    ('TAG_HUMBLE', 'PLAIN', None, 'PRACTICE'),
    ('TAG_EVANGEL', 'PLAIN', None, 'PRACTICE'),
    # C. PHASE — 자가진단 10국면과 코드로 대응(TAG_<국면코드>).
    #   ⚠ DIAGPHASE_* 키 재사용은 폐기 — 그 KO 값이 '불안·두려움' 같은
    #     **묶음 이름**이라 단일 개념 규칙에 걸린다(실측으로 잡음).
    ('TAG_ANXIETY', 'PLAIN', None, 'PHASE'),
    ('TAG_GRIEF', 'PLAIN', None, 'PHASE'),
    ('TAG_SHAME', 'PLAIN', None, 'PHASE'),
    ('TAG_ANGER', 'PLAIN', None, 'PHASE'),
    ('TAG_LONELY', 'PLAIN', None, 'PHASE'),
    ('TAG_DISTANT', 'PLAIN', None, 'PHASE'),
    ('TAG_PRAYERLESS', 'PLAIN', None, 'PHASE'),
    ('TAG_GUILT', 'PLAIN', None, 'PHASE'),
    ('TAG_CALLING', 'PLAIN', None, 'PHASE'),
    ('TAG_STAGNANT', 'PLAIN', None, 'PHASE'),
    ('TAG_FEAR', 'PLAIN', None, 'PHASE'),
    ('TAG_JOY', 'PLAIN', None, 'PHASE'),
    ('TAG_TEMPT', 'PLAIN', None, 'PHASE'),
    ('TAG_SUFFER', 'PLAIN', None, 'PHASE'),
    ('TAG_WAIT', 'PLAIN', None, 'PHASE'),
    ('TAG_COMFORT', 'PLAIN', None, 'PHASE'),
    ('TAG_RESTORE', 'PLAIN', None, 'PHASE'),
    # D. EVENT — 자립 11 + 연동 4
    ('TAG_CREATION', 'PLAIN', None, 'EVENT'),
    (None, 'ENTITY', '타락', 'EVENT'),
    ('TAG_FLOOD', 'PLAIN', None, 'EVENT'),
    ('TAG_EXODUS', 'PLAIN', None, 'EVENT'),
    ('TAG_WILDERNESS', 'PLAIN', None, 'EVENT'),
    ('TAG_CONQUEST', 'PLAIN', None, 'EVENT'),
    ('TAG_KINGDOM_ERA', 'PLAIN', None, 'EVENT'),
    ('TAG_EXILE', 'PLAIN', None, 'EVENT'),
    ('TAG_RETURN', 'PLAIN', None, 'EVENT'),
    (None, 'ENTITY', '성육신', 'EVENT'),
    ('TAG_MINISTRY', 'PLAIN', None, 'EVENT'),
    ('TAG_CROSS', 'PLAIN', None, 'EVENT'),
    (None, 'ENTITY', '그리스도의 부활', 'EVENT'),
    ('TAG_ASCENSION', 'PLAIN', None, 'EVENT'),
    (None, 'ENTITY', '오순절', 'EVENT'),
    # E. LIFE — 자립 11 (묶음 전부 분리)
    ('TAG_FAMILY', 'PLAIN', None, 'LIFE'),
    ('TAG_WORKPLACE', 'PLAIN', None, 'LIFE'),
    ('TAG_RELATION', 'PLAIN', None, 'LIFE'),
    ('TAG_COMMUNITY', 'PLAIN', None, 'LIFE'),
    ('TAG_MONEY', 'PLAIN', None, 'LIFE'),
    ('TAG_ILLNESS', 'PLAIN', None, 'LIFE'),
    ('TAG_LOSS', 'PLAIN', None, 'LIFE'),
    ('TAG_MARRIAGE', 'PLAIN', None, 'LIFE'),
    ('TAG_CHILDREN', 'PLAIN', None, 'LIFE'),
    ('TAG_YOUTH', 'PLAIN', None, 'LIFE'),
    ('TAG_AGING', 'PLAIN', None, 'LIFE'),
    # F. CURATION — 자립 7
    ('TAG_TOP30', 'PLAIN', None, 'CURATION'),
    ('TAG_TOP100', 'PLAIN', None, 'CURATION'),
    ('TAG_NEWCOMER', 'PLAIN', None, 'CURATION'),
    ('TAG_NEWYEAR', 'PLAIN', None, 'CURATION'),
    ('TAG_CHRISTMAS', 'PLAIN', None, 'CURATION'),
    ('TAG_EASTER', 'PLAIN', None, 'CURATION'),
    ('TAG_THANKSGIVING', 'PLAIN', None, 'CURATION'),
]

# 자립 태그의 KO/EN 이름 (DIAGPHASE_* 는 기존 11언어 그대로 — 여기 없음)
UI_NAMES = {
    'TAG_GOSPEL': ('복음', 'Gospel'),
    'TAG_CHRIST': ('그리스도', 'Christ'),
    'TAG_SPIRIT': ('성령', 'Holy Spirit'),
    'TAG_PRAYER': ('기도', 'Prayer'),
    'TAG_WORSHIP': ('예배', 'Worship'),
    'TAG_PRAISE': ('찬양', 'Praise'),
    'TAG_THANKS': ('감사', 'Gratitude'),
    'TAG_FORGIVE': ('용서', 'Forgiveness'),
    'TAG_OBEY': ('순종', 'Obedience'),
    'TAG_SERVE': ('섬김', 'Service'),
    'TAG_HUMBLE': ('겸손', 'Humility'),
    'TAG_EVANGEL': ('전도', 'Evangelism'),
    'TAG_ANXIETY': ('불안', 'Anxiety'),
    'TAG_GRIEF': ('슬픔', 'Grief'),
    'TAG_SHAME': ('수치', 'Shame'),
    'TAG_ANGER': ('분노', 'Anger'),
    'TAG_LONELY': ('외로움', 'Loneliness'),
    'TAG_DISTANT': ('거리감', 'Distance from God'),
    'TAG_PRAYERLESS': ('기도 침체', 'Prayerlessness'),
    'TAG_GUILT': ('죄책감', 'Guilt'),
    'TAG_CALLING': ('부르심', 'Calling'),
    'TAG_STAGNANT': ('신앙 정체', 'Stagnation'),
    'TAG_FEAR': ('두려움', 'Fear'),
    'TAG_JOY': ('기쁨', 'Joy'),
    'TAG_TEMPT': ('유혹', 'Temptation'),
    'TAG_SUFFER': ('고난', 'Suffering'),
    'TAG_WAIT': ('기다림', 'Waiting'),
    'TAG_COMFORT': ('위로', 'Comfort'),
    'TAG_RESTORE': ('회복', 'Restoration'),
    'TAG_CREATION': ('창조', 'Creation'),
    'TAG_FLOOD': ('홍수', 'The Flood'),
    'TAG_EXODUS': ('출애굽', 'The Exodus'),
    'TAG_WILDERNESS': ('광야', 'Wilderness'),
    'TAG_CONQUEST': ('정복', 'Conquest'),
    'TAG_KINGDOM_ERA': ('왕정', 'Monarchy'),
    'TAG_EXILE': ('포로', 'Exile'),
    'TAG_RETURN': ('귀환', 'Return'),
    'TAG_MINISTRY': ('공생애', 'Public Ministry'),
    'TAG_CROSS': ('십자가', 'The Cross'),
    'TAG_ASCENSION': ('승천', 'Ascension'),
    'TAG_FAMILY': ('가정', 'Family'),
    'TAG_WORKPLACE': ('일터', 'Workplace'),
    'TAG_RELATION': ('관계', 'Relationships'),
    'TAG_COMMUNITY': ('공동체', 'Community'),
    'TAG_MONEY': ('재물', 'Money'),
    'TAG_ILLNESS': ('질병', 'Illness'),
    'TAG_LOSS': ('상실', 'Loss'),
    'TAG_MARRIAGE': ('결혼', 'Marriage'),
    'TAG_CHILDREN': ('자녀', 'Children'),
    'TAG_YOUTH': ('청년', 'Youth'),
    'TAG_AGING': ('노년', 'Aging'),
    'TAG_TOP30': ('대표 30선', 'Top 30'),
    'TAG_TOP100': ('대표 100선', 'Top 100'),
    'TAG_NEWCOMER': ('새신자', 'New Believers'),
    'TAG_NEWYEAR': ('새해', 'New Year'),
    'TAG_CHRISTMAS': ('성탄절', 'Christmas'),
    'TAG_EASTER': ('부활절', 'Easter'),
    'TAG_THANKSGIVING': ('추수감사', 'Thanksgiving'),
    # 축 이름
    'TAGCAT_THEME': ('신학 주제', 'Theme'),
    'TAGCAT_PRACTICE': ('신앙 실천', 'Practice'),
    'TAGCAT_PHASE': ('심리·국면', 'Inner State'),
    'TAGCAT_EVENT': ('구속사 사건', 'Redemptive Event'),
    'TAGCAT_LIFE': ('삶의 자리', 'Life Setting'),
    'TAGCAT_CURATION': ('큐레이션', 'Curation'),
    # 엔티티 유형 축 (2026-08-21) — 이름은 주요용어 화면의 것을 그대로
    'TAGCAT_PERSON': ('인물', 'Person'),
    'TAGCAT_PLACE': ('장소', 'Place'),
    'TAGCAT_DOCTRINE': ('교리', 'Doctrine'),
    'TAGCAT_TERM': ('용어', 'Term'),
    'TAGCAT_IDOL': ('우상', 'Idol'),
    'TAGCAT_NATION': ('민족', 'Nation'),
    'TAGCAT_GROUP': ('그룹', 'Group'),
    'TAGCAT_FEAST': ('절기', 'Feast'),
    'TAGCAT_OBJECT': ('사물', 'Object'),
    'TAGCAT_SYSTEM': ('제도', 'System'),
}


def _entity_by_ko(conn, ko_name):
    r = conn.execute(
        "SELECT m.entity_id FROM sys_entity_master m "
        "JOIN sys_text_asset t ON t.text_type='ENTITY_NAME' "
        "  AND t.clicked_id=m.entity_id AND t.record_status='LIVE' "
        "WHERE t.contents=? AND UPPER(t.lang_code)='KO' "
        "AND m.record_status='LIVE'", (ko_name,)).fetchone()
    return r[0] if r else None


def seed(conn, quiet=False):
    """멱등 시드 — 열쇠: PLAIN 은 tag_name_sid, ENTITY 는 entity_id."""
    n_new = n_same = n_skip = 0
    for sid, kind, ent_ko, cat in SEED:
        eid = None
        if kind == 'ENTITY':
            eid = _entity_by_ko(conn, ent_ko)
            if eid is None:
                if not quiet:
                    print('  ⚠ 엔티티 없음, 건너뜀:', ent_ko)
                n_skip += 1
                continue
            ex = conn.execute("SELECT sys_tag_id FROM sys_tag_asset "
                              "WHERE entity_id=?", (eid,)).fetchone()
        else:
            ex = conn.execute("SELECT sys_tag_id FROM sys_tag_asset "
                              "WHERE tag_name_sid=? AND "
                              "COALESCE(tag_kind,'PLAIN')='PLAIN'",
                              (sid,)).fetchone()
        if ex:
            n_same += 1
            continue
        conn.execute("INSERT INTO sys_tag_asset (tag_name_sid, tag_kind, "
                     "entity_id, tag_category, record_status) "
                     "VALUES (?,?,?,?,'LIVE')", (sid, kind, eid, cat))
        n_new += 1
    # 자립 태그·축 이름 ui_strings (KO/EN — 나머지 언어는 §0-3 브리지)
    n_str = 0
    for key, (ko, en) in UI_NAMES.items():
        for lang, val in (('KO', ko), ('EN', en)):
            ex = conn.execute("SELECT string_value FROM ui_strings "
                              "WHERE string_id=? AND lang_code=?",
                              (key, lang)).fetchone()
            if ex is None:
                conn.execute("INSERT INTO ui_strings (string_id, lang_code, "
                             "string_value) VALUES (?,?,?)", (key, lang, val))
                n_str += 1
    conn.commit()
    if not quiet:
        print('시드 — 태그 새로 %d · 그대로 %d · 건너뜀 %d · 문구 %d행'
              % (n_new, n_same, n_skip, n_str))
    return n_new


# ── 이관 — 옛 도서 태그 → 새 체계 (원본 표는 보존, 화면만 새 체계를 읽는다) ──

# 옛 값 → 새 태그를 찾는 열쇠 (kind, key). 없는 값은 폐기 목록에 남긴다.
MIGRATE_MAP = {
    ('COLLECTION', 'TOP_30'): [('PLAIN', 'TAG_TOP30')],
    ('COLLECTION', 'TOP_100'): [('PLAIN', 'TAG_TOP100')],
    ('THEME', 'GOD'): [('ENTITY', '하나님의 속성')],
    ('THEME', 'CHRIST'): [('PLAIN', 'TAG_CHRIST')],
    ('THEME', 'SPIRIT'): [('PLAIN', 'TAG_SPIRIT')],
    # & 로 묶였던 옛 값은 **둘로 갈라** 이관한다 (사용자 지시)
    ('THEME', 'GOSPEL_REPENTANCE'): [('PLAIN', 'TAG_GOSPEL'),
                                     ('ENTITY', '회개')],
    ('THEME', 'SALVATION_GRACE'): [('ENTITY', '구원'), ('ENTITY', '은혜')],
    ('THEME', 'LIFE_CHURCH'): [('ENTITY', '교회')],
    ('THEME', 'ETERNITY'): [('ENTITY', '천국')],
    ('THEME', 'NEW_YEAR'): [('PLAIN', 'TAG_NEWYEAR')],
    ('THEME', 'GRACE'): [('ENTITY', '은혜')],
    ('THEME', 'FAITH'): [('ENTITY', '믿음')],
    ('THEME', 'FAITHFULNESS'): [('ENTITY', '하나님의 속성')],
    ('THEME', 'PRAYER'): [('PLAIN', 'TAG_PRAYER')],
    ('THEME', 'EVANGELISM'): [('PLAIN', 'TAG_EVANGEL')],
    ('DIAG_PHASE', 'CALLING'): [('PLAIN', 'TAG_CALLING')],
    # KEYWORD(검색 보조)·장르(DAILY_DEVOTION 등 book_category 와 중복)는 폐기
}


def _tag_by_key(conn, kind, key):
    if kind == 'PLAIN':
        r = conn.execute("SELECT sys_tag_id FROM sys_tag_asset "
                         "WHERE tag_name_sid=?", (key,)).fetchone()
    else:
        eid = _entity_by_ko(conn, key)
        r = conn.execute("SELECT sys_tag_id FROM sys_tag_asset "
                         "WHERE entity_id=?", (eid,)).fetchone() if eid else None
    return r[0] if r else None


def migrate(conn, quiet=False):
    """sys_book_unit_tag(유닛) + sys_book_asset_tag(도서) → sys_tag_link.
    멱등(link 가 멱등) · **원본 표는 지우지 않는다**(감사 원본)."""
    stats = {'new': 0, 'same': 0}
    dropped = {}
    gate = {'BOOK_UNIT': "SELECT 1 FROM sys_book_unit WHERE unit_id=? "
                         "AND record_status='LIVE'",
            'BOOK': "SELECT 1 FROM sys_book_asset WHERE book_id=? "
                    "AND record_status='LIVE'"}
    for tbl, tcol, ttype in (('sys_book_unit_tag', 'unit_id', 'BOOK_UNIT'),
                             ('sys_book_asset_tag', 'book_id', 'BOOK')):
        for tt, tv, tid in conn.execute(
                "SELECT tag_type, tag_value, %s FROM %s "
                "WHERE record_status='LIVE'" % (tcol, tbl)):
            # ⚠ 대상이 죽었으면 링크를 만들지 않는다 — 옛 표가 HIDE 유닛을
            #   가리키는 채로 남아 있었다(실측: unit 122)
            if not conn.execute(gate[ttype], (tid,)).fetchone():
                dropped[('DEAD', '%s %s' % (ttype, tid))] =                     dropped.get(('DEAD', '%s %s' % (ttype, tid)), 0) + 1
                continue
            targets = MIGRATE_MAP.get((tt, tv))
            if not targets:
                dropped[(tt, tv)] = dropped.get((tt, tv), 0) + 1
                continue
            for kind, key in targets:
                tag = _tag_by_key(conn, kind, key)
                if tag is None:
                    dropped[(tt, tv)] = dropped.get((tt, tv), 0) + 1
                    continue
                r = link(conn, tag, ttype, tid)
                stats['new' if r == 'new' else 'same'] += 1
    conn.commit()
    if not quiet:
        print('이관 — 링크 새로 %d · 그대로 %d' % (stats['new'], stats['same']))
        if dropped:
            print('  폐기(의도된 것 — KEYWORD·장르):',
                  {('%s/%s' % k): v for k, v in dropped.items()})
    return stats


# ── 검사 ──────────────────────────────────────────────────────────────────

def check(conn, quiet=False):
    bad = []
    # ① PLAIN 인데 KO 이름 없음
    for (tid, sid) in conn.execute(
            "SELECT sys_tag_id, tag_name_sid FROM sys_tag_asset "
            "WHERE COALESCE(tag_kind,'PLAIN')='PLAIN' "
            "AND COALESCE(record_status,'LIVE')='LIVE'"):
        if not sid:
            bad.append('PLAIN 태그 %d 에 tag_name_sid 가 없다' % tid)
            continue
        r = conn.execute("SELECT 1 FROM ui_strings WHERE string_id=? "
                         "AND lang_code='KO'", (sid,)).fetchone()
        if not r:
            bad.append('PLAIN 태그 %d(%s) 의 KO 이름이 ui_strings 에 없다'
                       % (tid, sid))
    # ② 연동인데 원천이 죽었거나 없음
    for (tid, eid) in conn.execute(
            "SELECT sys_tag_id, entity_id FROM sys_tag_asset "
            "WHERE tag_kind='ENTITY' "
            "AND COALESCE(record_status,'LIVE')='LIVE'"):
        r = conn.execute("SELECT 1 FROM sys_entity_master WHERE entity_id=? "
                         "AND record_status='LIVE'", (eid or -1,)).fetchone()
        if not r:
            bad.append('연동 태그 %d 의 엔티티 %s 가 없다/HIDE 다' % (tid, eid))
    # ③ 링크 대상 실존 (존재 게이트)
    gate = {
        'LENS': "SELECT 1 FROM sys_unit_asset WHERE sys_unit_id=? "
                "AND unit_type='CONTAINER' "
                "AND COALESCE(record_status,'LIVE')='LIVE'",
        'BOOK': "SELECT 1 FROM sys_book_asset WHERE book_id=? "
                "AND record_status='LIVE'",
        'BOOK_UNIT': "SELECT 1 FROM sys_book_unit WHERE unit_id=? "
                     "AND record_status='LIVE'",
        'PLAN': "SELECT 1 FROM sys_bible_plan WHERE plan_id=? "
                "AND record_status='LIVE'",
        'VERSE': "SELECT 1 FROM bible_index WHERE verse_id=?",
        'REF_UNIT': "SELECT 1 FROM sys_ref_unit WHERE ref_unit_id=? "
                    "AND record_status='LIVE'",
        'NODE': "SELECT 1 FROM sys_unit_asset WHERE sys_unit_id=? "
                "AND unit_type='NODE' "
                "AND COALESCE(record_status,'LIVE')='LIVE'",
    }
    _w, _a = _mine_where()
    _rev = {v: k for k, v in TGT_CODE.items()}
    for lk, lt, ti in conn.execute(
            "SELECT sys_link_id, link_type, target_id FROM %s "
            "WHERE %s AND COALESCE(record_status,'LIVE')='LIVE'"
            % (LINK_TBL, _w), _a):
        tt = _rev.get(lt.split('_', 1)[1], lt)
        q = gate.get(tt)
        if q is None:
            bad.append('링크 %d 의 target_type %s 는 허용 목록에 없다' % (lk, tt))
        elif not conn.execute(q, (ti,)).fetchone():
            bad.append('링크 %d 의 대상 %s %s 가 없다/HIDE 다' % (lk, tt, ti))
    # ④ & 복합 이름 (사용자 금지 규칙)
    for (tid, sid) in conn.execute(
            "SELECT t.sys_tag_id, t.tag_name_sid FROM sys_tag_asset t "
            "WHERE COALESCE(t.record_status,'LIVE')='LIVE' "
            "AND t.tag_name_sid IS NOT NULL"):
        r = conn.execute("SELECT string_value FROM ui_strings "
                         "WHERE string_id=? AND lang_code='KO'",
                         (sid,)).fetchone()
        if r and ('&' in r[0] or '과 ' in r[0] or '와 ' in r[0]):
            bad.append('태그 %d(%s) KO 이름에 묶음 흔적: %s' % (tid, sid, r[0]))
    if not quiet:
        print('검사 ' + ('통과' if not bad else '실패 %d건' % len(bad)))
        for b in bad[:20]:
            print('  ✗', b)
    return bad


def show(conn):
    print('태그 %d개 · 링크 %d건' % (
        conn.execute("SELECT COUNT(*) FROM sys_tag_asset "
                     "WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0],
        conn.execute("SELECT COUNT(*) FROM %s WHERE %s "
                     "AND COALESCE(record_status,'LIVE')='LIVE'"
                     % ((LINK_TBL,) + (_mine_where()[0],)),
                     _mine_where()[1]).fetchone()[0]))
    for cat in CATEGORIES:
        rows = conn.execute(
            "SELECT sys_tag_id, tag_name_sid, COALESCE(tag_kind,'PLAIN'), "
            "entity_id, dict_ref FROM sys_tag_asset WHERE tag_category=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sys_tag_id",
            (cat,)).fetchall()
        names = []
        for tid, sid, kind, eid, dref in rows:
            nm = tag_display_name(conn, (sid, kind, eid, dref), 'KO')
            _w2, _a2 = _mine_where()
            n = conn.execute("SELECT COUNT(*) FROM %s WHERE %s AND "
                             "clicked_id=? AND "
                             "COALESCE(record_status,'LIVE')='LIVE'"
                             % (LINK_TBL, _w2), _a2 + (tid,)).fetchone()[0]
            names.append('%s%s%s' % (nm, '◈' if kind != 'PLAIN' else '',
                                     ('(%d)' % n) if n else ''))
        print('%-9s %2d개  %s' % (cat, len(rows), ' · '.join(names)))


# ── selftest — 임시 DB 로 전 과정 + 검사 탐지력(양방향) ────────────────────

def _selftest():
    import sqlite3
    import tempfile
    db = os.path.join(tempfile.gettempdir(), '_tag_selftest.db')
    if os.path.exists(db):
        os.remove(db)
    conn = sqlite3.connect(db)
    conn.executescript("""
      CREATE TABLE sys_tag_asset (sys_tag_id INTEGER PRIMARY KEY AUTOINCREMENT,
        tag_name_sid TEXT, tag_category TEXT, record_status TEXT, origin_id INT);
      CREATE TABLE ui_strings (string_id TEXT, lang_code TEXT, string_value TEXT);
      CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY,
        entity_type TEXT, record_status TEXT);
      CREATE TABLE sys_text_asset (text_type TEXT, clicked_id INT,
        lang_code TEXT, contents TEXT, record_status TEXT);
      CREATE TABLE sys_ref_unit (ref_unit_id INTEGER PRIMARY KEY,
        unit_label TEXT, record_status TEXT);
      CREATE TABLE sys_ref_text (ref_unit_id INT, lang_code TEXT, title TEXT,
        record_status TEXT);
      CREATE TABLE sys_unit_asset (sys_unit_id INTEGER PRIMARY KEY,
        unit_type TEXT, record_status TEXT);
      CREATE TABLE sys_book_asset (book_id INTEGER PRIMARY KEY,
        record_status TEXT);
      CREATE TABLE sys_book_unit (unit_id INTEGER PRIMARY KEY,
        record_status TEXT);
      CREATE TABLE sys_bible_plan (plan_id INTEGER PRIMARY KEY,
        record_status TEXT);
      CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY);
      CREATE TABLE sys_book_unit_tag (tag_type TEXT, tag_value TEXT,
        unit_id INT, record_status TEXT);
      CREATE TABLE sys_book_asset_tag (tag_type TEXT, tag_value TEXT,
        book_id INT, record_status TEXT);
      -- ★ 2026-08-24 — 태그 연결이 사는 통합 표
      CREATE TABLE sys_link_asset (sys_link_id INTEGER PRIMARY KEY AUTOINCREMENT,
        link_type TEXT, clicked_id INTEGER, target_id INTEGER, rel_code TEXT,
        end_id INTEGER, sort_order INTEGER, record_status TEXT,
        origin_id INTEGER, chain_code TEXT, note TEXT, milestone_type TEXT,
        importance INTEGER, is_key INTEGER, source TEXT, confidence TEXT,
        lemma_id INTEGER);
      CREATE UNIQUE INDEX ix_sla ON sys_link_asset
        (link_type, clicked_id, target_id, COALESCE(rel_code,''),
         COALESCE(end_id, target_id))
        WHERE COALESCE(record_status,'LIVE')='LIVE';
    """)
    bad = []
    init_schema(conn)
    # 엔티티 하나 심고 시드 일부 흉내
    conn.execute("INSERT INTO sys_entity_master VALUES (7,'DOCTRINE','LIVE')")
    conn.execute("INSERT INTO sys_text_asset VALUES "
                 "('ENTITY_NAME',7,'KO','은혜','LIVE')")
    conn.execute("INSERT INTO sys_tag_asset (tag_name_sid, tag_kind, "
                 "tag_category, record_status) VALUES "
                 "('TAG_PRAYER','PLAIN','PRACTICE','LIVE')")
    conn.execute("INSERT INTO ui_strings VALUES ('TAG_PRAYER','KO','기도')")
    conn.execute("INSERT INTO sys_tag_asset (tag_kind, entity_id, "
                 "tag_category, record_status) VALUES "
                 "('ENTITY',7,'THEME','LIVE')")
    # 이름 해석
    if tag_display_name(conn, ('TAG_PRAYER', 'PLAIN', None, None)) != '기도':
        bad.append('PLAIN 이름 해석 실패')
    if tag_display_name(conn, (None, 'ENTITY', 7, None)) != '은혜':
        bad.append('ENTITY 이름 차용 실패')
    # 링크 멱등
    conn.execute("INSERT INTO sys_book_unit VALUES (10,'LIVE')")
    assert link(conn, 1, 'BOOK_UNIT', 10) == 'new'
    assert link(conn, 1, 'BOOK_UNIT', 10) == 'same'
    # ⚠⚠ **태그 연결만** 숨긴다. 조건 없이 돌리면 통합 표의 **모든 연결**이
    #   숨는다(진짜 DB 라면 28,000행). 여기는 가짜 DB 지만 습관을 못 박는다.
    _w, _a = _mine_where()
    conn.execute("UPDATE %s SET record_status='HIDE' WHERE %s"
                 % (LINK_TBL, _w), _a)
    if link(conn, 1, 'BOOK_UNIT', 10) != 'revived':
        bad.append('HIDE 링크 되살림 실패')
    # fetch_tags_for
    got = fetch_tags_for(conn, 'BOOK_UNIT', 10)
    if not (len(got) == 1 and got[0][1] == '기도'):
        bad.append('fetch_tags_for 실패: %s' % got)
    # 이관 — 멱등 포함
    conn.execute("INSERT INTO sys_tag_asset (tag_name_sid, tag_kind, "
                 "tag_category, record_status) VALUES "
                 "('TAG_TOP30','PLAIN','CURATION','LIVE')")
    conn.execute("INSERT INTO ui_strings VALUES ('TAG_TOP30','KO','대표 30선')")
    conn.execute("INSERT INTO sys_book_unit_tag VALUES "
                 "('COLLECTION','TOP_30',10,'LIVE')")
    conn.execute("INSERT INTO sys_book_unit_tag VALUES "
                 "('KEYWORD','cross',10,'LIVE')")
    s1 = migrate(conn, quiet=True)
    s2 = migrate(conn, quiet=True)
    if not (s1['new'] == 1 and s2['new'] == 0):
        bad.append('이관 멱등 실패: %s %s' % (s1, s2))
    # 검사 — 깨끗할 때 통과
    if check(conn, quiet=True):
        bad.append('깨끗한 상태를 위반으로 잡았다')
    # 검사 탐지력 — 일부러 어긴 뒤 잡는지 (양방향)
    conn.execute("UPDATE sys_entity_master SET record_status='HIDE' "
                 "WHERE entity_id=7")
    if not any('엔티티' in b for b in check(conn, quiet=True)):
        bad.append('원천 잃은 연동 태그를 못 잡는다')
    conn.execute("UPDATE sys_entity_master SET record_status='LIVE' "
                 "WHERE entity_id=7")
    conn.execute("INSERT INTO ui_strings VALUES ('TAG_BAD','KO','구원과 은혜')")
    conn.execute("INSERT INTO sys_tag_asset (tag_name_sid, tag_kind, "
                 "tag_category, record_status) VALUES "
                 "('TAG_BAD','PLAIN','THEME','LIVE')")
    if not any('묶음' in b for b in check(conn, quiet=True)):
        bad.append('& 복합 이름을 못 잡는다')
    conn.execute("DELETE FROM sys_tag_asset WHERE tag_name_sid='TAG_BAD'")
    conn.execute("INSERT INTO %s (link_type, clicked_id, target_id) "
                 "VALUES ('TAG_BUNT',1,999)" % LINK_TBL)
    if not any('대상' in b for b in check(conn, quiet=True)):
        bad.append('죽은 링크 대상을 못 잡는다')
    # 이중 승격 차단
    try:
        conn.execute("INSERT INTO sys_tag_asset (tag_kind, entity_id, "
                     "tag_category) VALUES ('ENTITY',7,'THEME')")
        bad.append('같은 엔티티 이중 승격이 막히지 않는다')
    except Exception:
        pass
    conn.close()
    os.remove(db)
    print('db_tag_system selftest: ' + ('OK' if not bad else 'FAIL'))
    for b in bad:
        print('  X', b)
    return 1 if bad else 0


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        sys.exit(_selftest())
    conn = appdb.connect(DB)
    try:
        if '--init' in args:
            init_schema(conn)
            init_user_schema(DB)
            print('스키마 OK')
        elif '--seed' in args:
            init_schema(conn)
            seed(conn)
        elif '--migrate' in args:
            migrate(conn)
        elif '--check' in args:
            sys.exit(1 if check(conn) else 0)
        elif '--list' in args:
            show(conn)
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
