# -*- coding: utf-8 -*-
"""shop_view.py — 추천몰(제휴 쇼핑몰·상품) 화면. P4 마지막 탭.

★★ 2026-10-29 여섯째 판 — **폰과 같은 꼴로 통일**(사용자 「통일하라」 · 폰 시안 docs/1.txt 4 합의):
  1단 [상품등록 추천하기][설정][나라 ▾](오른쪽 · 단추는 위)
  2단 상품통합검색(입력 + [찾기] · 찾은 뒤 ✕ = 지우고 카테고리로)
  3단 쇼핑몰 = **아이콘만**(이름 단추 없음 · 이름은 마우스를 올리면 풍선) — On = 테두리 + ✓ ·
      Off = 흑백 흐림(자리 그대로) · 맨 앞 네모 = 모든 쇼핑몰 On/Off
  4단 카테고리 = 모든 용품 · 자주 사는 상품(늘) · 기프트 · 교회(우선) → 나머지 · 어느 쇼핑몰에도 상품이 없는 것만 숨김 ·
      Off 해도 칸은 남고 글자만 흐리다 · 배지 없음 · 보기 = 가로 칩(칸 격자) / 세로 목록(왼쪽 짧은 이름 칸) — [설정]에서
  5단 상품 카드(여기만 굴린다) · 카드 아래 [+ 자주 사는 상품]
  찾기 = 쇼핑몰 아이콘 띠(돋보기 · Off 쇼핑몰도 누를 수 있다 · 그 쇼핑몰 검색 쪽) + 추천 상품 가운데 맞는 것(Off 는 흐리게)
  ⚠ 폰은 화면이 좁아 가로 칩 3열·상품 2열이고 PC 는 넓어 **창 폭만큼** 칸을 늘린다(꼴은 같다).
  ⚠ 옛 판의 왼쪽 쇼핑몰 줄·쇼핑몰마다 검색창(검색창 표시 ★)은 걷었다 — 자료(user_shop_fav)는 그대로 둔다.
  제휴 안내 글은 [설정] 맨 아래 · 제휴 고지는 카드마다(법령).

★ 보일 것을 정하는 문은 `db_shop.view` 하나 — 폰 `shopView` 와 같은 규칙(every = 칸 · items = On 쇼핑몰 것).
★ 탭을 보일지 정하는 수도 `db_shop.item_count` 하나(user_main `_sync_shop_tab`).
⚠ 글꼴·색은 표준(`theme_font.register` · `ui_theme.C`) — 이름·크기를 박지 않는다.
"""
import tkinter as tk
from tkinter import ttk
import webbrowser

import i18n
import ui_theme

CARD_W = 200
THUMB_H = 120
CELL_W = 150        # 가로 칩 카테고리 칸 폭(창 폭만큼 열을 늘린다 · 최소 3열)
CELL_H = 34
RAIL_W = 104        # 세로 목록 보기 왼쪽 칸 폭
TILE = 46           # 쇼핑몰 아이콘 칸
BTN_H = 30          # 상품 카드 아래 단추 칸 높이

_GUIDE_KEYS = (
    ('SHOP_G_H1', '제휴 안내'),
    ('SHOP_G_B1', '여기에 있는 상품은 이 앱이 파는 것이 아닙니다. '
                  '누르면 그 상품을 파는 쇼핑몰로 갑니다.'),
    ('SHOP_G_H3', '수수료'),
    ('SHOP_G_B3', '제휴 상품은 구매하시면 이 앱이 수수료를 받을 수 있습니다. '
                  '그 표시가 상품마다 따로 붙습니다. '
                  '수수료는 앱을 이어 가는 데 씁니다.'),
    ('SHOP_G_H4', '개인정보'),
    ('SHOP_G_B4', '누가 무엇을 눌렀는지 기록하지 않습니다. '
                  '추적 코드도 넣지 않습니다.'),
)


def _t(key, default):
    try:
        return i18n.t(key, default)
    except Exception:
        return default


def _C(role, fallback):
    try:
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


_ICON_CACHE = {}


def _round_rect(cv, x0, y0, x1, y1, r, **kw):
    """캔버스에 둥근 사각 — 아이콘 칸 테두리·「모두」 아이콘(폰과 같은 꼴)."""
    pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r, x1, y1 - r, x1, y1, x1 - r, y1,
           x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
    kw.setdefault('fill', '')
    return cv.create_polygon(pts, smooth=True, **kw)


def _mag_img(size, color):
    """돋보기 그림(PIL) — ⌕ 는 Segoe UI Symbol 에만 있어 글꼴에 기대지 않는다."""
    k = (size, color)
    if k in _ICON_CACHE:
        return _ICON_CACHE[k]
    try:
        from PIL import Image, ImageDraw, ImageTk
        z = 4
        S = size * z
        im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        w = max(2, S // 9)
        r = int(S * 0.30)
        cx = cy = int(S * 0.40)
        d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=color, width=w)
        a = int(r * 0.72)
        d.line((cx + a, cy + a, S - w, S - w), fill=color, width=int(w * 1.4))
        ph = ImageTk.PhotoImage(im.resize((size, size), Image.LANCZOS))
        _ICON_CACHE[k] = ph
        return ph
    except Exception:
        return None


def _logo_img(name, h, store, grey=False, radius=0):
    """쇼핑몰 로고 — grey = 흑백 + 흐림(Off · 폰과 같다)."""
    try:
        import db_shop as SH
        p = SH.img_path(name)
        if not p:
            return None
        from PIL import Image, ImageTk
        im = Image.open(p).convert('RGBA')
        im.thumbnail((h, h), Image.LANCZOS)
        if radius:                                          # 둥근 모서리(폰 아이콘과 같은 꼴)
            from PIL import ImageChops, ImageDraw
            m = Image.new('L', im.size, 0)
            ImageDraw.Draw(m).rounded_rectangle((0, 0, im.size[0] - 1, im.size[1] - 1), radius, fill=255)
            im.putalpha(ImageChops.multiply(im.getchannel('A'), m))
        if grey:
            a = im.getchannel('A').point(lambda x: int(x * 0.45))
            im = im.convert('L').convert('RGBA')
            im.putalpha(a)
        ph = ImageTk.PhotoImage(im)
        store.append(ph)
        return ph
    except Exception:
        return None


def _font(w, db, delta=0, bold=False):
    try:
        import theme_font
        theme_font.register(w, db, 'base', size_delta=delta)
        if bold:
            f = w.cget('font')
            import tkinter.font as tkf
            ff = tkf.Font(font=f)
            w.configure(font=(ff.actual('family'), ff.actual('size'), 'bold'))
    except Exception:
        pass


def _shop_stat(kind, ident):
    """★ 2026-10-25 쇼핑몰 통계 한 번(usage_stats.shop_event · 실패해도 화면은 그대로)"""
    try:
        import usage_stats
        usage_stats.shop_event(kind, ident)
    except Exception:
        pass


class _Tip:
    """마우스를 올리면 이름 풍선 — 쇼핑몰은 아이콘만이라 이름은 여기서 말한다."""

    def __init__(self, w, text):
        self.w, self.text, self.win, self._job = w, text, None, None
        w.bind('<Enter>', self._on, add='+')
        w.bind('<Leave>', self._off, add='+')
        w.bind('<ButtonPress>', self._off, add='+')

    def _on(self, _e=None):
        self._job = self.w.after(350, self._show)

    def _show(self):
        try:
            x = self.w.winfo_rootx() + 4
            y = self.w.winfo_rooty() + self.w.winfo_height() + 4
            self.win = tk.Toplevel(self.w)
            self.win.wm_overrideredirect(True)
            self.win.wm_geometry('+%d+%d' % (x, y))
            lb = tk.Label(self.win, text=self.text, padx=6, pady=2, relief='solid', bd=1,
                          bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'))
            lb.pack()
        except Exception:
            self.win = None

    def _off(self, _e=None):
        if self._job:
            try:
                self.w.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
            self.win = None


class ShopView(tk.Frame):
    def __init__(self, parent, db_path, lang_getter=None, **kw):
        super().__init__(parent, **kw)
        self.db = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._bg = _C('bg', '#E3E6E8')
        self._panel = _C('panel', '#FFFFFF')
        self.configure(bg=self._bg)
        self._cat = ''            # '' = 모든 용품 · 'REP' = 자주 사는 상품 · 그 밖 = 카테고리 코드
        self._fword = ''          # 상품통합검색 낱말('' = 카테고리 보기)
        self._off = set(self._cfg('SHOP_OFF').split(',')) - {''}   # Off 쇼핑몰(이 PC)
        self._allcty = self._cfg('SHOP_ALL_CTY') == '1'             # 나라 「모든 나라」
        self._vert = self._cfg('SHOP_CATVIEW') == 'V'               # 카테고리 보기 = 세로 목록
        self._photos = []
        self._icon_photos = []
        self._v = {'cats': [], 'malls': [], 'count': 0, 'country_malls': [], 'repeat': []}
        self._set_win = None
        self._cols = 0
        self._ccols = 0

        # 1단 — 단추는 위(오른쪽부터 나라 · 설정 · 상품등록 추천하기)
        self._top = tk.Frame(self, bg=self._panel)
        self._top.pack(fill='x')
        # 2단 상품통합검색 = 1단 「추천몰」 오른쪽(2026-10-29 docs/1.txt 5-0)
        # 3·4단 — 쇼핑몰 아이콘 띠 + 카테고리 가로 칩(찾기 때는 쇼핑몰 검색 띠)
        self._mid = tk.Frame(self, bg=self._panel)
        self._mid.pack(fill='x')
        tk.Frame(self, bg=_C('border', '#D5D8DC'), height=1).pack(fill='x')
        # 5단 — (세로 목록이면 왼쪽 칸) + 상품(여기만 굴린다)
        body = tk.Frame(self, bg=self._bg)
        body.pack(fill='both', expand=True)
        self._rail_host = tk.Frame(body, bg=_C('panel_alt', '#EEF2F6'), width=RAIL_W)
        self._rail_host.pack_propagate(False)
        right = tk.Frame(body, bg=self._bg)
        right.pack(side='right', fill='both', expand=True)
        self._right = right
        cv = tk.Canvas(right, bg=self._bg, highlightthickness=0, bd=0)
        sb = ttk.Scrollbar(right, orient='vertical', command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        cv.pack(side='left', fill='both', expand=True)
        self._grid = tk.Frame(cv, bg=self._bg)
        win = cv.create_window((0, 0), window=self._grid, anchor='nw')
        self._cv = cv

        def _cfg(e):
            cv.itemconfigure(win, width=e.width)
            n = max(1, e.width // (CARD_W + 14))
            if n != self._cols:
                self._cols = n
                self._draw_grid()
        cv.bind('<Configure>', _cfg)
        self._grid.bind('<Configure>', lambda _e: cv.configure(scrollregion=cv.bbox('all')))

        def _midcfg(e):
            n = max(3, (e.width - 24) // 40)   # 폭이 40px 넘게 바뀔 때만 다시 깐다(칩은 글자 폭 · 줄바꿈 자리만 바뀐다)
            if n != self._ccols:
                self._ccols = n
                if not self._vert and not self._fword:
                    self._draw_mid()
        self._mid.bind('<Configure>', _midcfg)
        self._wheel(right, cv)                                      # 상품 칸 — 단추·카드 위에서도 굴러간다
        self._draw_top()
        self.refresh()

    def _wheel(self, area, cv):
        """휠 — 그 칸 위(자식 위젯 위 포함)에 있을 때만 그 캔버스를 굴린다(모든 굴림 칸 공통 원칙)."""
        def roll(e):
            try:
                y0, y1 = cv.yview()
                if y0 > 0 or y1 < 1:
                    cv.yview_scroll(-1 if e.delta > 0 else 1, 'units')
            except tk.TclError:
                pass

        def on(_e=None):
            area.bind_all('<MouseWheel>', roll)

        def off(e=None):
            if e is not None and getattr(e, 'detail', '') == 'NotifyInferior':
                return                                          # 자식으로 들어간 것 — 아직 칸 안
            area.unbind_all('<MouseWheel>')
        area.bind('<Enter>', on, add='+')
        area.bind('<Leave>', off, add='+')
        self._wheel_roll = roll

    # ── 자료 ────────────────────────────────────────────────────
    def _load(self):
        try:
            import appdb
            import ads
            import db_shop as SH
            with appdb.connect(self.db) as c:
                p = SH.catalog(c)
                fv = SH.favs(c)
                hd = SH.hides(c)
                mn = SH.mine(c)
                rp = SH.repeats(c)
            self._country = ads.get_country(self.db)
            self._v = SH.view(p, 'ALL' if self._allcty else self._country, self.lang_getter(), fv,
                              hidden=hd, mine=mn, off=self._off, repeat=rp, abroad=self._cfg('SHOP_ABROAD') != '0')
        except Exception as e:                         # noqa: BLE001
            print('[shop] %s' % e)
            self._v = {'cats': [], 'malls': [], 'count': 0, 'country_malls': [], 'repeat': []}

    def _cfg(self, k, v=None):
        """user_config 한 칸 — 이 PC 만(Off 쇼핑몰 · 모든 나라 · 카테고리 보기)."""
        try:
            import appdb
            with appdb.connect(self.db) as c:
                if v is None:
                    r = c.execute('SELECT config_val FROM user_config WHERE config_key=?', (k,)).fetchone()
                    return (r[0] if r else '') or ''
                c.execute('INSERT OR REPLACE INTO user_config(config_key, config_val) VALUES(?,?)', (k, v))
                c.commit()
        except Exception:
            return ''
        return v

    def refresh(self):
        self._load()
        codes = {c['code'] for c in self._v['cats']}
        if self._cat not in ('', 'REP') and self._cat not in codes:
            self._cat = ''
        self._draw_mid()
        self._draw_rail()
        self._draw_grid()
        if self._set_win is not None:
            try:
                self._fill_settings()
            except Exception:
                pass

    def _is_on(self, code):
        for m in self._v['malls']:
            if m['code'] == code:
                return bool(m.get('on', True))
        return True

    # ── 1단: [상품등록 추천하기][설정][나라] ─────────────────────────
    def _draw_top(self):
        """1단(2026-10-29 시안 3) — 「추천몰」 · 검색(낱말 하나) · 찾기 · 쇼핑몰 아이콘 띠 … ⊕ 상품등록 추천 · ⚙ 쇼핑 설정 · 나라 ▾.

        오른쪽 단추는 폰처럼 아이콘(이름은 풍선) — 그 자리를 쇼핑몰 아이콘이 쓴다.
        """
        f = self._top
        for w in f.winfo_children():
            w.destroy()
        try:
            import ads
            codes = ['ALL'] + [c for c, _n in ads.COUNTRIES]
            names = [_t('SHOP_ALL_CTY', '모든 나라')] + [n for _c, n in ads.COUNTRIES]
            cur = 'ALL' if self._allcty else (ads.get_country(self.db) or '')
            mb = tk.Menubutton(f, text='%s ▾' % (_t('SHOP_ALL_CTY', '모든 나라') if cur == 'ALL' else (cur or '?')),
                               relief='solid', bd=1, padx=8, pady=2, cursor='hand2',
                               bg=self._panel, fg=_C('accent', '#1A5276'), activebackground=self._panel)
            mn = tk.Menu(mb, tearoff=0)

            def _ch(i):
                self._allcty = codes[i] == 'ALL'
                self._cfg('SHOP_ALL_CTY', '1' if self._allcty else '0')
                if not self._allcty:
                    ads.set_country(self.db, codes[i])
                self._strip_off = 0
                self._draw_top()
                self.refresh()
            for i, n in enumerate(names):
                mn.add_command(label=n, command=lambda i=i: _ch(i))
            mb.configure(menu=mn)
            mb.pack(side='right', padx=(4, 10), pady=6)
            _font(mb, self.db)
            _Tip(mb, _t('SHOP_COUNTRY', '나라'))
            self._cty_cb = mb
        except Exception:
            pass

        def ibtn(txt, tip, cmd):
            b = tk.Label(f, text=txt, cursor='hand2', padx=7, pady=0, bg=self._panel,
                         fg=_C('accent', '#1A5276'), relief='solid', bd=1)
            b.pack(side='right', padx=(0, 4))
            _font(b, self.db, delta=3)
            b.bind('<Button-1>', lambda _e: cmd())
            _Tip(b, tip)
            return b
        self._set_btn = ibtn('⚙', _t('SHOP_SETTINGS_T2', '쇼핑 설정'), self._open_settings)
        self._reco_btn = ibtn('⊕', _t('SHOP_RECO_BTN', '상품등록 추천하기'), self._open_recommend)
        hd = tk.Label(f, text=_t('M_TAB_SHOP', '추천몰'), bg=self._panel, fg=_C('fg_title', '#2C3E50'))
        hd.pack(side='left', padx=12, pady=6)
        _font(hd, self.db, delta=1, bold=True)
        self._srow = tk.Frame(f, bg=self._panel)
        self._srow.pack(side='left', padx=(0, 10))
        self._draw_search()
        self._strip_host = tk.Frame(f, bg=self._panel)
        self._strip_host.pack(side='left', fill='x', expand=True, padx=(0, 8))

    # ── 2단: 상품통합검색 ───────────────────────────────────────────
    def _draw_search(self):
        f = self._srow
        for w in f.winfo_children():
            w.destroy()
        go = tk.Label(f, text=_t('SHOP_FIND_GO', '찾기'), cursor='hand2', padx=14, pady=3,
                      bg=_C('accent', '#1A5276'), fg=_C('fg_on_dark', '#FFFFFF'))
        go.pack(side='right', padx=(4, 0), pady=6)
        _font(go, self.db, bold=True)
        box = tk.Frame(f, bg=_C('accent', '#1A5276'), padx=1, pady=1)
        box.pack(side='left', pady=6)
        inner = tk.Frame(box, bg=_C('panel', '#FFFFFF'))
        inner.pack(fill='x')
        ic = _mag_img(16, _C('fg_dim', '#7F8C8D'))
        if ic:
            tk.Label(inner, image=ic, bg=_C('panel', '#FFFFFF')).pack(side='left', padx=(6, 0))
        e = tk.Entry(inner, relief='flat', width=14, bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'))
        e.pack(side='left', ipady=4, padx=4)                    # ★ 2026-10-29 낱말 하나 길이(사용자)
        _font(e, self.db)
        e.insert(0, self._fword)
        x = tk.Label(inner, text='✕', cursor='hand2', padx=8, bg=_C('panel', '#FFFFFF'), fg=_C('fg_dim', '#7F8C8D'))
        if self._fword:
            x.pack(side='right')
        _font(x, self.db)
        self._qent, self._qx, self._qgo = e, x, go

        def find(_ev=None):
            self._set_find(e.get().strip())

        def clear(_ev=None):
            e.delete(0, 'end')
            self._set_find('')
        e.bind('<Return>', find)
        go.bind('<Button-1>', find)
        x.bind('<Button-1>', clear)
        _Tip(x, _t('SHOP_FIND_CLEAR', '검색어 지우고 카테고리로'))

    def _set_find(self, w):
        self._fword = w
        try:
            if w:
                self._qx.pack(side='right')
            else:
                self._qx.pack_forget()
        except Exception:
            pass
        self._draw_mid()
        self._draw_rail()
        self._draw_grid()

    # ── 3·4단: 쇼핑몰 아이콘 띠 + 카테고리(또는 찾기 띠) ─────────────
    def _mark(self, host, m, grey):
        """쇼핑몰 아이콘 — 관리자가 올린 로고 · 없으면 이름 첫 글자(이름 단추는 쓰지 않는다)."""
        lg = _logo_img(m.get('logo'), 34, self._icon_photos, grey=grey, radius=7)
        if lg:
            return tk.Label(host, image=lg, bg=host.cget('bg'))
        lb = tk.Label(host, text=(m.get('name') or m.get('code') or '?')[:1], bg=host.cget('bg'),
                      fg=_C('fg_dim', '#95A5A6') if grey else _C('accent', '#1A5276'))
        _font(lb, self.db, delta=4, bold=True)
        return lb

    def _tile(self, host, key, tip, on, make, tap, search=False, partial=False):
        """아이콘 칸 — On = 그대로(테두리·✓ 없음 · 2026-10-30 docs/1.txt 1) · Off = 흑백 흐림(자리 그대로) · 찾기 띠 = 돋보기."""
        cell = tk.Frame(host, bg=self._panel, width=TILE + 12, height=TILE + 12)
        cell.pack(side='left', padx=(0, 4))
        cell.pack_propagate(False)
        lit = on or partial
        sq = tk.Canvas(cell, width=TILE, height=TILE, cursor='hand2', bg=self._panel, highlightthickness=0, bd=0)
        sq.place(x=2, y=8)
        inner = make(sq)
        sq.create_window(TILE // 2, TILE // 2, window=inner)
        badge = None
        if search:
            ic = _mag_img(14, _C('fg_on_dark', '#FFFFFF'))
            badge = tk.Label(cell, image=ic, bg=_C('accent', '#1A5276'), padx=1, pady=1, cursor='hand2') if ic else None
            if badge:
                badge.place(x=TILE - 8, y=TILE - 6)
        for w in (cell, sq, inner) + ((badge,) if badge else ()):
            w.bind('<Button-1>', lambda _e: tap())
        _Tip(sq, tip)
        cell._shop_key = key
        cell._shop_on = on
        cell._shop_tap = tap
        self._tiles[key] = cell
        return cell

    def _draw_strip(self):
        """1단 쇼핑몰 아이콘 띠(2026-10-29) — 「모두」는 맨 왼쪽 고정 · 국내배송 │ 해외배송 묶음 ·
        넘치면 오른쪽 「+N」(안 보이는 수) — 누르면 띠가 왼쪽으로 미끄러지고 왼쪽에 「◀ N」(밀려난 수)."""
        h = getattr(self, '_strip_host', None)
        self._tiles = {}
        self._icon_photos = []
        if h is None:
            return
        for w in h.winfo_children():
            w.destroy()
        malls = self._v.get('malls') or []
        if not malls:
            return
        all_on = all(m.get('on', True) for m in malls)
        none_on = all(not m.get('on', True) for m in malls)

        def all_mark(host):                                     # 폰과 같은 네 칸(둥근 사각 넷)
            col = _C('accent', '#1A5276') if (all_on or not none_on) else _C('fg_dim', '#95A5A6')
            c = tk.Canvas(host, width=24, height=24, bg=host.cget('bg'), highlightthickness=0, bd=0, cursor='hand2')
            for x0, y0 in ((1, 1), (13, 1), (1, 13), (13, 13)):
                _round_rect(c, x0, y0, x0 + 10, y0 + 10, 3, fill=col, outline=col)
            return c
        self._tile(h, 'ALL', _t('SHOP_MALL_ALL', '모든 쇼핑몰 On/Off'), all_on, all_mark,
                   lambda: self._set_all(not all_on), partial=not all_on and not none_on)

        def nav(txt):
            b = tk.Label(h, text=txt, cursor='hand2', padx=5, bg=self._panel, fg=_C('accent', '#1A5276'),
                         relief='solid', bd=1)
            _font(b, self.db, bold=True)
            return b
        self._back_btn = nav('◀')
        self._more_btn = nav('+')
        self._back_btn.bind('<Button-1>', lambda _e: self._strip_page(-1))
        self._more_btn.bind('<Button-1>', lambda _e: self._strip_page(1))
        vp = tk.Frame(h, bg=self._panel, height=TILE + 12)
        vp.pack(side='left', fill='x', expand=True)
        vp.pack_propagate(False)
        tr = tk.Frame(vp, bg=self._panel)
        tr.place(x=-getattr(self, '_strip_off', 0), y=0)
        self._vp, self._track = vp, tr
        last = None
        for m in malls:
            sh = m.get('ship', 'D')
            if sh != last:
                if last is not None:
                    tk.Frame(tr, bg=_C('border', '#D5D8DC'), width=1, height=TILE).pack(side='left', padx=(2, 8), pady=(8, 0))
                gl = tk.Label(tr, text=_t('SHOP_SHIP_X', '해외') if sh == 'X' else _t('SHOP_SHIP_D', '국내'),
                              bg=self._panel, fg=_C('warning', '#B9770E') if sh == 'X' else _C('fg_dim', '#5D6D7E'))
                gl.pack(side='left', padx=(0, 4), pady=(8, 0))
                _font(gl, self.db, delta=-2, bold=True)
                last = sh
            on = bool(m.get('on', True))
            self._tile(tr, m['code'], '%s · %s' % (m['name'], 'On' if on else 'Off'), on,
                       lambda hh, m=m, on=on: self._mark(hh, m, not on),
                       lambda k=m['code'], on=on: self._toggle_on(k, not on))
        # 칸 폭·아이콘 자리가 다 잡힌 뒤에 센다(Configure 그 순간은 아직 옛 폭일 수 있다)
        vp.bind('<Configure>', lambda _e: self.after_idle(self._strip_fit))
        tr.bind('<Configure>', lambda _e: self.after_idle(self._strip_fit))
        self._hwheel(h)
        self.after_idle(self._strip_fit)

    def _strip_tiles(self):
        tr = getattr(self, '_track', None)
        if tr is None or not tr.winfo_exists():
            return []
        return [w for w in tr.winfo_children() if getattr(w, '_shop_key', None)]

    def _strip_fit(self):
        """띠 자리 맞춤 — 밀린 만큼 놓고 「◀ N」·「+N」(안 보이는 쇼핑몰 수)를 적는다 · 다 들면 둘 다 없다."""
        vp, tr = getattr(self, '_vp', None), getattr(self, '_track', None)
        if vp is None or not vp.winfo_exists():
            return
        vw = vp.winfo_width()
        if vw <= 1:
            return
        mx = max(0, tr.winfo_reqwidth() - vw)
        off = min(max(0, getattr(self, '_strip_off', 0)), mx)
        self._strip_off = off
        tr.place_configure(x=-off)
        left = right = 0
        for t in self._strip_tiles():
            x, w = t.winfo_x(), t.winfo_reqwidth()
            if x < off:
                left += 1
            elif x + w > off + vw:
                right += 1
        for b, n, txt, side in ((self._back_btn, left, '◀ %d', 'left'), (self._more_btn, right, '+%d', 'right')):
            if n:
                b.configure(text=txt % n)
                if not b.winfo_ismapped():
                    if side == 'left':
                        b.pack(side='left', padx=(0, 4), before=vp)
                    else:
                        b.pack(side='right', padx=(4, 0), before=vp)
            elif b.winfo_ismapped():
                b.pack_forget()
        self._strip_counts = (left, right)

    def _strip_page(self, d):
        """「+N」 = 가려진 첫 아이콘이 보이도록 왼쪽으로 · 「◀ N」 = 되돌리기 — 미끄러지게."""
        vp = getattr(self, '_vp', None)
        if vp is None or not vp.winfo_exists():
            return
        vw, off = vp.winfo_width(), getattr(self, '_strip_off', 0)
        ts = self._strip_tiles()
        mx = max(0, self._track.winfo_reqwidth() - vw)
        if d > 0:                                           # 가려진(잘린) 첫 아이콘이 맨 왼쪽에 오게
            hid = [t.winfo_x() for t in ts if t.winfo_x() + t.winfo_reqwidth() > off + vw]
            goal = min(hid) - 4 if hid else mx
            goal = max(goal, off + 1)
        else:                                               # 밀려난 마지막 아이콘이 맨 오른쪽에 오게
            hid = [t.winfo_x() + t.winfo_reqwidth() for t in ts if t.winfo_x() < off]
            goal = max(hid) - vw + 4 if hid else 0
            if not [t for t in ts if t.winfo_x() < goal]:
                goal = 0                                    # 앞에 더 숨은 것이 없으면 처음 자리로
        goal = min(max(0, goal), mx)
        self._slide(off, goal, 0)

    def _slide(self, a, b, i, n=8):
        if getattr(self, '_track', None) is None or not self._track.winfo_exists():
            return
        i += 1
        self._strip_off = int(a + (b - a) * i / n)
        self._track.place_configure(x=-self._strip_off)
        if i < n:
            self.after(18, lambda: self._slide(a, b, i, n))
        else:
            self._strip_fit()

    def _hwheel(self, area):
        """띠 위에서 휠 = 좌우로(한 아이콘씩)."""
        def roll(e):
            vp = getattr(self, '_vp', None)
            if vp is None or not vp.winfo_exists():
                return
            mx = max(0, self._track.winfo_reqwidth() - vp.winfo_width())
            self._strip_off = min(mx, max(0, getattr(self, '_strip_off', 0) + (-1 if e.delta > 0 else 1) * (TILE + 16)))
            self._strip_fit()

        def on(_e=None):
            area.bind_all('<MouseWheel>', roll)

        def off(e=None):
            if e is not None and getattr(e, 'detail', '') == 'NotifyInferior':
                return
            area.unbind_all('<MouseWheel>')
        area.bind('<Enter>', on, add='+')
        area.bind('<Leave>', off, add='+')

    def _draw_mid(self):
        self._draw_strip()
        f = self._mid
        for w in f.winfo_children():
            w.destroy()
        self._cells = {}
        malls = self._v.get('malls') or []
        if self._fword:
            self._draw_find_malls(f, malls)
            return
        if not malls:
            return
        if not self._vert:
            self._draw_catgrid(f)
        else:
            # ★ 2026-10-30 가로 칩 → 세로로 바꾸면 빈 칸 높이가 남았다 — Tk 는 마지막 자식을 걷어도 틀이 줄지 않는다
            f.configure(height=1)

    def _draw_find_malls(self, f, malls):
        """찾은 뒤 — 쇼핑몰에서 바로 찾기(아이콘 띠 · Off 쇼핑몰도 누를 수 있다)."""
        box = tk.Frame(f, bg=_C('panel_alt', '#EEF2F6'))
        box.pack(fill='x')
        hd = tk.Label(box, text=_t('SHOP_FIND_MALLS', '쇼핑몰에서 바로 찾기 — 「%s」를 그 쇼핑몰 검색에 넣어 엽니다')
                      .replace('%s', self._fword, 1), bg=box.cget('bg'), fg=_C('fg_dim', '#5D6D7E'), anchor='w')
        hd.pack(fill='x', padx=12, pady=(6, 0))
        _font(hd, self.db, delta=-1)
        strip = tk.Frame(box, bg=box.cget('bg'))
        strip.pack(fill='x', padx=10, pady=(0, 4))
        import db_shop as SH
        for m in malls:
            can = '{q}' in (m.get('search') or '')
            tip = (_t('SHOP_FIND_IN', '%s 에서 찾기') if can else _t('SHOP_OPEN_HOME', '%s 첫 화면')).replace('%s', m['name'], 1)
            url = SH.search_url(m, self._fword) if can else (m.get('home') or '')

            def go(u=url, k=m['code']):
                if u:
                    _shop_stat('search', k)
                    webbrowser.open(u)
            on = bool(m.get('on', True))
            c = self._tile(strip, 'F_' + m['code'], tip, on, lambda h, m=m, on=on: self._mark(h, m, not on),
                           go, search=True)
            c.configure(bg=box.cget('bg'))
        self._find_box = box

    def _cell_list(self):
        """카테고리 칸 = (열쇠, 이름, 짧은 이름, On 상품 수, 우선 칸) — 폰 `_cells` 와 같다."""
        reps = [it for it in self._v.get('repeat') or [] if self._is_on(it.get('mall'))]
        out = [('', _t('SHOP_CAT_ALL', '모든 용품'), _t('SHOP_CAT_ALL_S', '전체'), self._v.get('count') or 0, True),
               ('REP', _t('SHOP_REPEAT', '자주 사는 상품'), _t('SHOP_REPEAT_S', '자주 구매'), len(reps), True)]
        for c in self._v['cats']:
            out.append((c['code'], c['name'], c.get('short') or c['name'], len(c['items']), c['kind'] != 'GENERAL'))
        return out

    def _cat_cell(self, host, x, rail=False):
        code, name, short, n, _pri = x
        sel = self._cat == code
        dim = n == 0
        fg = _C('accent', '#1A5276') if sel else (_C('fg_dim', '#95A5A6') if dim else _C('fg', '#2C3E50'))
        if rail:
            # ★ 2026-10-30 짧은 이름 하나만(사용자 — 풍선에도 긴 이름을 안 보인다)
            b = tk.Label(host, text=short, cursor='hand2', pady=10, wraplength=RAIL_W - 14, justify='center',
                         bg=self._panel if sel else host.cget('bg'), fg=fg)
        else:
            b = tk.Label(host, text=short, cursor='hand2', padx=6, relief='solid', bd=1,
                         bg=self._panel if sel else _C('panel_alt', '#EEF2F6'), fg=fg,
                         highlightthickness=1 if sel else 0, highlightbackground=_C('accent', '#1A5276'))
        _font(b, self.db, bold=sel)
        b.bind('<Button-1>', lambda _e, k=code: self._pick_cat(k))
        b._shop_cat = code
        self._cells[code or 'all'] = b
        return b

    def _draw_catgrid(self, f):
        """4단 가로 칩 — ★ 2026-10-30 글자만큼 폭(짧은 이름) · 한 줄에 차례로 · 넘칠 때만 다음 줄(사용자 「짧은 이름이면 한 줄」).
        옛 격자(칸 폭 고정 · 창 폭 ÷ 칸)는 짧은 이름도 넓은 칸을 차지해 늘 두 줄이 됐다."""
        g = tk.Frame(f, bg=self._panel)
        g.pack(fill='x', padx=12, pady=(2, 8))
        self._catgrid = g
        avail = max(200, (self._mid.winfo_width() or 0) - 24)
        row, used = None, 0
        for x in self._cell_list():
            if row is None:
                row = tk.Frame(g, bg=self._panel)
                row.pack(fill='x', anchor='w')
            b = self._cat_cell(row, x)
            w = b.winfo_reqwidth() + 6
            if used and used + w > avail:
                b.destroy()
                row = tk.Frame(g, bg=self._panel)
                row.pack(fill='x', anchor='w')
                b = self._cat_cell(row, x)
                used = 0
            b.pack(side='left', padx=3, pady=3, ipady=5, ipadx=4)
            used += w

    def _draw_rail(self):
        """4단 세로 목록 — 왼쪽 좁은 칸(짧은 이름 · 우선 칸 다음 구분선 · 이름은 풍선)."""
        h = self._rail_host
        for w in h.winfo_children():
            w.destroy()
        if not self._vert or self._fword or not self._v.get('malls'):
            h.pack_forget()
            return
        h.pack(side='left', fill='y', before=self._right)
        cv = tk.Canvas(h, bg=h.cget('bg'), highlightthickness=0, bd=0, width=RAIL_W)
        cv.pack(fill='both', expand=True)
        inner = tk.Frame(cv, bg=h.cget('bg'))
        win = cv.create_window((0, 0), window=inner, anchor='nw')
        cv.bind('<Configure>', lambda e: cv.itemconfigure(win, width=e.width))
        inner.bind('<Configure>', lambda _e: cv.configure(scrollregion=cv.bbox('all')))
        self._wheel(h, cv)
        cells = self._cell_list()
        last = max([i for i, x in enumerate(cells) if x[4]] or [-1])
        for i, x in enumerate(cells):
            self._cat_cell(inner, x, rail=True).pack(fill='x')
            if i == last and i < len(cells) - 1:
                tk.Frame(inner, bg=_C('border', '#D5D8DC'), height=1).pack(fill='x', padx=10, pady=4)
        self._rail = inner

    def _pick_cat(self, code):
        self._cat = code
        self._draw_mid()
        self._draw_rail()
        self._draw_grid()

    def _set_all(self, on):
        for m in self._v.get('malls') or []:
            (self._off.discard if on else self._off.add)(m['code'])
        self._cfg('SHOP_OFF', ','.join(sorted(self._off)))
        self.refresh()

    def _toggle_on(self, code, on):
        """쇼핑몰 아이콘 — 끄면 그 쇼핑몰 상품이 빠진다(아이콘은 자리 그대로 · 이 PC 만 기억)."""
        (self._off.discard if on else self._off.add)(code)
        self._cfg('SHOP_OFF', ','.join(sorted(self._off)))
        self.refresh()

    def _toggle_mine(self, code, on):
        """내 모음 넣기/빼기 — 모음이 비어 있었으면 지금 놓인 쇼핑몰로 먼저 채운다(놓였던 것이 안 사라지게)."""
        try:
            import appdb
            import db_shop as SH
            with appdb.connect(self.db) as c:
                if not SH.mine(c):
                    for m in self._v.get('country_malls') or []:
                        if m.get('mine'):
                            SH.set_mine(c, m['code'], True)
                SH.set_mine(c, code, on)
        except Exception as e:                         # noqa: BLE001
            print('[shop mine] %s' % e)
        self.refresh()

    def _set_vert(self, v):
        self._vert = bool(v)
        self._cfg('SHOP_CATVIEW', 'V' if self._vert else 'H')
        self._draw_mid()
        self._draw_rail()

    def _open_item(self, it):
        """상품 열기 — 통계(상품·쇼핑몰 · 달마다 수만) 뒤 바깥 브라우저로"""
        u = it.get('url') or ''
        if not u:
            return
        _shop_stat('item', it.get('id'))
        _shop_stat('mall', it.get('mall'))
        webbrowser.open(u)

    def _toggle_repeat(self, item_id, on):
        if on:
            _shop_stat('repeat', item_id)
        try:
            import appdb
            import db_shop as SH
            with appdb.connect(self.db) as c:
                SH.set_repeat(c, item_id, on)
        except Exception as e:                         # noqa: BLE001
            print('[shop repeat] %s' % e)
        self.refresh()

    # ── [상품등록 추천하기] — 관리자 소통 통로(kind SHOP)로 ─────────────
    def _open_recommend(self):
        w = tk.Toplevel(self)
        w.title(_t('SHOP_RECO_BTN', '상품등록 추천하기'))
        w.geometry('460x330')
        w.transient(self.winfo_toplevel())
        w.configure(bg=self._panel)
        self._reco_win = w
        top = tk.Frame(w, bg=self._panel)
        top.pack(fill='x', padx=8, pady=6)
        hd = tk.Label(top, text=_t('SHOP_RECO_BTN', '상품등록 추천하기'), bg=self._panel, fg=_C('fg_title', '#2C3E50'))
        hd.pack(side='left')
        _font(hd, self.db, bold=True)
        cl = tk.Label(top, text=_t('COMMON_CLOSE', '닫기'), cursor='hand2', padx=10, pady=2,
                      bg=self._panel, fg=_C('accent', '#1A5276'), relief='solid', bd=1)
        cl.pack(side='right')
        _font(cl, self.db, delta=-1)
        cl.bind('<Button-1>', lambda _e: w.destroy())
        sd = tk.Label(top, text=_t('SHOP_RECO_SEND', '보내기'), cursor='hand2', padx=12, pady=2,
                      bg=_C('accent', '#1A5276'), fg=_C('fg_on_dark', '#FFFFFF'))
        sd.pack(side='right', padx=(0, 6))
        _font(sd, self.db, bold=True)
        body = tk.Frame(w, bg=self._panel)
        body.pack(fill='both', expand=True, padx=10)
        ents = {}
        for i, (k, key, d) in enumerate((('name', 'SHOP_RECO_NAME', '상품 이름'), ('mall', 'SHOP_RECO_MALL', '쇼핑몰(업체) 이름'),
                                         ('url', 'SHOP_RECO_URL', '상품 링크(주소)'), ('memo', 'SHOP_RECO_MEMO', '메모(선택)'))):
            l = tk.Label(body, text=_t(key, d), bg=self._panel, fg=_C('fg', '#2C3E50'), anchor='w')
            l.grid(row=i, column=0, sticky='w', pady=4)
            _font(l, self.db)
            e = tk.Entry(body, bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'))
            e.grid(row=i, column=1, sticky='ew', padx=(8, 0), pady=4, ipady=3)
            _font(e, self.db)
            ents[k] = e
        body.grid_columnconfigure(1, weight=1)
        msg = tk.Label(w, text=_t('SHOP_RECO_HINT', '관리자가 확인하고 등록합니다. 개인 정보는 적지 마세요.'),
                       bg=self._panel, fg=_C('fg_dim', '#5D6D7E'), anchor='w', justify='left', wraplength=430)
        msg.pack(fill='x', padx=10, pady=(0, 8))
        _font(msg, self.db, delta=-1)
        self._reco_ents = ents
        self._reco_msg = msg

        def send(_e=None):
            nm, ml, u = (ents[k].get().strip() for k in ('name', 'mall', 'url'))
            if not nm or not (ml or u):
                msg.configure(text=_t('SHOP_RECO_NEED', '상품 이름과 쇼핑몰(또는 링크)을 적어 주세요.'),
                              fg=_C('error', '#C0392B'))
                return
            import db_shop as SH
            text = SH.recommend_text(nm, ml, u, ents['memo'].get())

            box = []   # 일꾼은 결과만 담는다 — Tk 는 메인에서만 만진다(§279차 ⑭)
            lang = self.lang_getter()

            def work():
                try:
                    import appdb
                    import user_feedback as F
                    with appdb.connect(self.db) as c:
                        box.append(F.submit(c, 'SHOP', text, lang=lang))
                except Exception as ex:                # noqa: BLE001
                    box.append((False, str(ex)[:80]))

            def poll():
                if box:
                    done(*box[0])
                else:
                    w.after(150, poll)

            def done(ok, err):
                try:
                    msg.configure(text=_t('SHOP_RECO_OK', '보냈습니다. 고맙습니다.') if ok else
                                  _t('SHOP_RECO_FAIL', '보내지 못했습니다: %s') % (err or ''),
                                  fg=_C('fg_dim', '#5D6D7E') if ok else _C('error', '#C0392B'))
                    if ok:
                        for e_ in ents.values():
                            e_.delete(0, 'end')
                except Exception:
                    pass
            msg.configure(text=_t('SHOP_RECO_SENDING', '보내는 중…'))
            import threading
            threading.Thread(target=work, daemon=True).start()
            w.after(150, poll)
        sd.bind('<Button-1>', send)
        self._reco_send = send
        try:
            ui_theme.adopt(w)
        except Exception:
            pass

    # ── [쇼핑 설정] — 카테고리 보기 · 내 쇼핑몰 모음 · 제휴 안내 ────────
    def _open_settings(self):
        if self._set_win is not None:
            try:
                self._set_win.lift()
                return
            except Exception:
                self._set_win = None
        w = tk.Toplevel(self)
        w.title(_t('SHOP_SETTINGS_T2', '쇼핑 설정'))
        w.geometry('520x560')
        w.transient(self.winfo_toplevel())
        w.configure(bg=self._panel)
        self._set_win = w
        top = tk.Frame(w, bg=self._panel)
        top.pack(fill='x')
        hd = tk.Label(top, text=_t('SHOP_SETTINGS_T2', '쇼핑 설정'), bg=self._panel, anchor='w',
                      fg=_C('fg_title', '#2C3E50'), padx=10, pady=6)
        hd.pack(side='left')
        _font(hd, self.db, bold=True)
        cl = tk.Label(top, text=_t('COMMON_CLOSE', '닫기'), cursor='hand2', padx=10, pady=2,
                      bg=self._panel, fg=_C('accent', '#1A5276'), relief='solid', bd=1)
        cl.pack(side='right', padx=8)
        _font(cl, self.db, delta=-1)

        def _close(_e=None):
            self._set_win = None
            w.destroy()
        cl.bind('<Button-1>', _close)
        w.protocol('WM_DELETE_WINDOW', _close)
        self._set_close = _close
        vb = tk.Frame(w, bg=self._panel)
        vb.pack(fill='x', padx=10, pady=(4, 2))
        vt = tk.Label(vb, text=_t('SHOP_VIEW_T', '카테고리 보기'), bg=self._panel, fg=_C('fg_title', '#2C3E50'), anchor='w')
        vt.pack(fill='x')
        _font(vt, self.db, bold=True)
        self._view_var = tk.StringVar(value='V' if self._vert else 'H')
        self._view_radios = {}
        for val, key, d, key2, d2 in (('H', 'SHOP_VIEW_H2', '가로 칩', 'SHOP_VIEW_HD', '카테고리를 위에 칸으로 늘어놓습니다'),
                                      ('V', 'SHOP_VIEW_V2', '세로 목록', 'SHOP_VIEW_VD', '카테고리를 왼쪽에 세로로 — 많을 때 한눈에')):
            rb = tk.Radiobutton(vb, text='%s — %s' % (_t(key, d), _t(key2, d2)), value=val, variable=self._view_var,
                                anchor='w', bg=self._panel, activebackground=self._panel, fg=_C('fg', '#2C3E50'),
                                selectcolor=self._panel, command=lambda: self._set_vert(self._view_var.get() == 'V'))
            rb.pack(fill='x')
            _font(rb, self.db)
            self._view_radios[val] = rb
        self._abroad_var = tk.BooleanVar(value=self._cfg('SHOP_ABROAD') != '0')
        ab = tk.Checkbutton(vb, text=_t('SHOP_ABROAD_ON', '해외배송 쇼핑몰도 보기 — 끄면 해외배송 쇼핑몰 아이콘과 그 상품이 빠집니다'
                                        '(배송에 1~3주 · 관세가 붙을 수 있습니다)'),
                            variable=self._abroad_var, anchor='w', justify='left', wraplength=480,
                            bg=self._panel, activebackground=self._panel, fg=_C('fg', '#2C3E50'), selectcolor=self._panel,
                            command=lambda: self._set_abroad(self._abroad_var.get()))
        ab.pack(fill='x', pady=(6, 0))
        _font(ab, self.db)
        self._abroad_chk = ab
        tk.Frame(w, bg=_C('border', '#D5D8DC'), height=1).pack(fill='x', padx=10, pady=6)
        mt = tk.Label(w, text=_t('SHOP_SET_MINE2', '내 쇼핑몰 모음'), bg=self._panel, fg=_C('fg_title', '#2C3E50'),
                      anchor='w', padx=10)
        mt.pack(fill='x')
        _font(mt, self.db, bold=True)
        hint = tk.Label(w, text=_t('SHOP_SET_HINT3', '여기 체크한 쇼핑몰이 추천몰 위에 아이콘으로 놓입니다. '
                                   '다른 나라 쇼핑몰은 나라 「모든 나라」에서 더합니다. 비워 두면 지금 나라의 쇼핑몰이 놓입니다.'),
                        anchor='w', justify='left', wraplength=480, padx=10, pady=2,
                        bg=self._panel, fg=_C('fg_dim', '#5D6D7E'))
        hint.pack(fill='x')
        _font(hint, self.db, delta=-1)
        guide = tk.Frame(w, bg=self._panel)
        guide.pack(side='bottom', fill='x', padx=10, pady=(4, 8))
        for k, d in _GUIDE_KEYS:
            head = k.startswith('SHOP_G_H')
            gl = tk.Label(guide, text=_t(k, d), bg=self._panel, anchor='w', justify='left', wraplength=480,
                          fg=_C('fg_title', '#2C3E50') if head else _C('fg_dim', '#5D6D7E'))
            gl.pack(fill='x', pady=(4, 0) if head else 0)
            _font(gl, self.db, delta=-1, bold=head)
        self._set_body = tk.Frame(w, bg=self._panel)
        self._set_body.pack(fill='both', expand=True, padx=8, pady=4)
        self._fill_settings()
        try:
            ui_theme.adopt(w)
        except Exception:
            pass

    def _set_abroad(self, on):
        """쇼핑 설정 「해외배송 쇼핑몰도 보기」(이 PC 만 · 처음 = 켬)."""
        self._cfg('SHOP_ABROAD', '1' if on else '0')
        self._strip_off = 0
        self.refresh()
        try:
            self._fill_settings()
        except Exception:
            pass

    def _fill_settings(self):
        b = self._set_body
        for x in b.winfo_children():
            x.destroy()
        self._set_photos = []
        ms = self._v.get('country_malls') or []
        if not ms:
            e = tk.Label(b, text=_t('SHOP_NO_MALL', '이 나라에 등록된 쇼핑몰이 아직 없습니다.'),
                         bg=self._panel, fg=_C('fg_dim', '#7F8C8D'))
            e.grid(row=0, column=0, columnspan=3, sticky='w')
            _font(e, self.db)
        self._set_vars = {}
        for i, m in enumerate(ms):
            vs = tk.BooleanVar(value=bool(m.get('mine')))
            c1 = tk.Checkbutton(b, variable=vs, bg=self._panel, activebackground=self._panel,
                                command=lambda k=m['code'], v=vs: self._toggle_mine(k, v.get()))
            c1.grid(row=i, column=0)
            lg = _logo_img(m.get('logo'), 22, self._set_photos)
            if lg:
                tk.Label(b, image=lg, bg=self._panel).grid(row=i, column=1, sticky='w', padx=(2, 0))
            nm = tk.Label(b, text=m['name'], bg=self._panel, anchor='w',
                          fg=_C('fg', '#2C3E50') if m.get('mine') else _C('fg_dim', '#95A5A6'))
            nm.grid(row=i, column=2, sticky='w', padx=(6, 12))
            _font(nm, self.db)
            self._set_vars[m['code']] = (vs, c1)
        b.grid_columnconfigure(2, weight=1)

    # ── 5단: 상품 ───────────────────────────────────────────────
    def _items(self):
        if self._fword:
            import db_shop as SH
            return SH.find(self._v, self._fword)
        if self._cat == 'REP':
            return [(None, it) for it in self._v.get('repeat') or [] if self._is_on(it.get('mall'))]
        return [(c, it) for c in self._v['cats'] if not self._cat or c['code'] == self._cat for it in c['items']]

    def _draw_grid(self):
        g = self._grid
        for w in g.winfo_children():
            w.destroy()
        for k in range(12):
            g.grid_columnconfigure(k, uniform='', minsize=0, weight=0)
        self._photos = []
        self._repeat_rows = {}
        lst = self._items()
        cols = max(1, self._cols or 4)
        if self._fword:
            h = tk.Label(g, text=_t('SHOP_FIND_N2', '우리 추천 상품 가운데 「%s」 · %d개').replace('%s', self._fword, 1)
                         .replace('%d', str(len(lst)), 1), bg=self._bg, fg=_C('fg_dim', '#5D6D7E'), anchor='w')
            h.grid(row=0, column=0, columnspan=cols, sticky='ew', padx=8, pady=(6, 4))
            _font(h, self.db)
            self._found_head = h
            if not lst:
                e = tk.Label(g, text=_t('SHOP_FIND_NONE2', '추천 상품 가운데에는 없습니다. 위 쇼핑몰을 누르면 그 쇼핑몰에서 바로 찾습니다.'),
                             bg=self._bg, fg=_C('fg_dim', '#7F8C8D'))
                e.grid(row=1, column=0, columnspan=cols, padx=20, pady=24)
                _font(e, self.db)
                self._empty_lbl = e
                return
            self._cards(g, lst, row0=1, dim_off=True)
            return
        if not lst:
            self._draw_empty(g, cols)
            return
        self._cards(g, lst, in_repeat=self._cat == 'REP')
        if self._cat == 'REP':
            for w in g.winfo_children():
                self._repeat_rows[getattr(w, '_item_id', None)] = w

    def _draw_empty(self, g, cols):
        malls = self._v.get('malls') or []
        if malls and all(not m.get('on', True) for m in malls):
            # ★ 쇼핑몰이 모두 Off — 「아직 올린 상품이 없습니다」라 하면 상품이 사라진 것처럼 보인다(폰과 같다)
            e = tk.Label(g, text=_t('SHOP_ALL_OFF2', '쇼핑몰이 모두 Off 입니다. 위 쇼핑몰 아이콘을 눌러 On 하세요.'),
                         bg=self._bg, fg=_C('fg_dim', '#7F8C8D'))
            e.grid(row=0, column=0, columnspan=cols, padx=20, pady=(28, 8))
            _font(e, self.db)
            b = tk.Label(g, text=_t('SHOP_ALL_ON2', '모두 On'), cursor='hand2', padx=14, pady=3,
                         bg=_C('accent', '#1A5276'), fg=_C('fg_on_dark', '#FFFFFF'))
            b.grid(row=1, column=0, columnspan=cols)
            _font(b, self.db, bold=True)
            b.bind('<Button-1>', lambda _e: self._set_all(True))
            self._empty_lbl, self._all_on_btn = e, b
            return
        if not malls:
            msg = _t('SHOP_NO_MALL', '이 나라에 등록된 쇼핑몰이 아직 없습니다.')
        elif self._cat == 'REP':
            msg = _t('SHOP_REP_EMPTY', '상품 카드 아래 [자주 사는 상품]을 누르면 여기 모입니다.')
        elif not self._v.get('count') and not self._cat:
            msg = _t('SHOP_EMPTY', '아직 올린 상품이 없습니다.')
        else:
            msg = _t('SHOP_EMPTY_ON', 'On 쇼핑몰에는 이 카테고리 상품이 없습니다. 다른 쇼핑몰을 On 하면 보입니다.')
        e = tk.Label(g, text=msg, bg=self._bg, fg=_C('fg_dim', '#7F8C8D'))
        e.grid(row=0, column=0, columnspan=cols, padx=20, pady=30)
        _font(e, self.db)
        self._empty_lbl = e

    def _cards(self, g, pairs, row0=0, in_repeat=False, dim_off=False):
        """상품 카드 격자 — 카테고리·찾은 상품·자주 사는 상품이 **같은 카드**(제휴 고지까지 같게)."""
        cols = max(1, self._cols or 4)
        for k in range(cols):
            g.grid_columnconfigure(k, uniform='shopcard', minsize=CARD_W)
        for i, (cat, it) in enumerate(pairs):
            dim = dim_off and not self._is_on(it.get('mall'))
            self._card(g, cat, it, in_repeat=in_repeat, dim=dim).grid(
                row=row0 + i // cols, column=i % cols, padx=6, pady=6, sticky='nsew')

    def _card(self, host, cat, it, in_repeat=False, dim=False):
        try:                              # 보여 준 횟수의 분모 — 이번 실행에 상품마다 한 번(docs/통계_설계.md §7)
            _seen = self.__dict__.setdefault('_shop_seen', set())
            if it.get('id') not in _seen:
                _seen.add(it.get('id'))
                import usage_stats
                usage_stats.engage_hit('shop_view:%s' % it.get('id'))
        except Exception:
            pass
        bg = _C('panel_alt', '#EEF2F6') if dim else self._panel
        card = tk.Frame(host, bg=bg, width=CARD_W, cursor='hand2',
                        highlightthickness=1, highlightbackground=_C('border', '#D5D8DC'))
        kids = [card]
        img = self._thumb(it.get('img'))
        if img is not None:
            li = tk.Label(card, image=img, bg=bg)
            li.pack(fill='x')
            kids.append(li)
        if (cat or {}).get('kind') == 'GIFT' or it.get('gift'):
            tg = tk.Label(card, text=_t('SHOP_KIND_GIFT', '기프트'), anchor='w', padx=6,
                          bg=bg, fg=_C('warning', '#B9770E'))
            tg.pack(fill='x')
            _font(tg, self.db, delta=-2, bold=True)
            kids.append(tg)
        nm = tk.Label(card, text=it.get('name') or '', anchor='w', justify='left', padx=6,
                      wraplength=CARD_W - 12, bg=bg, fg=_C('fg_dim', '#7F8C8D') if dim else _C('fg_title', '#2C3E50'))
        nm.pack(fill='x')
        _font(nm, self.db, bold=True)
        kids.append(nm)
        if it.get('ship') == 'X':                            # ★ 2026-10-29 배송 기간이 다르다는 것을 상품에서도
            sx = tk.Label(card, text=_t('SHOP_SHIP_TAG', '해외배송'), anchor='w', padx=6,
                          bg=bg, fg=_C('warning', '#B9770E'))
            sx.pack(fill='x')
            _font(sx, self.db, delta=-2, bold=True)
            kids.append(sx)
        sub = ' · '.join(x for x in (it.get('mall_name'), it.get('band'), 'Off' if dim else '') if x)
        if sub:
            s = tk.Label(card, text=sub, anchor='w', padx=6, bg=bg, fg=_C('fg_dim', '#5D6D7E'))
            s.pack(fill='x')
            _font(s, self.db, delta=-1)
            kids.append(s)
        if it.get('desc'):
            d = tk.Label(card, text=it['desc'][:90], anchor='w', justify='left', padx=6,
                         wraplength=CARD_W - 12, bg=bg, fg=_C('fg_dim', '#7F8C8D') if dim else _C('fg', '#2C3E50'))
            d.pack(fill='x')
            _font(d, self.db, delta=-1)
            kids.append(d)
        nt = tk.Label(card, text=it.get('notice') or _t('AD_AFFILIATE_NOTICE', '제휴 링크 — 구매 시 수수료를 받을 수 있습니다'),
                      anchor='w', justify='left', padx=6, wraplength=CARD_W - 12,
                      bg=bg, fg=_C('fg_dim', '#AAB7B8'))
        nt.pack(fill='x', pady=(2, 4))
        _font(nt, self.db, delta=-3)
        kids.append(nt)
        # ★ 카드 아래 단추 칸 — 높이 고정 · [+ 자주 사는 상품]
        bx = tk.Frame(card, bg=_C('panel_alt', '#F4F6F8'), height=BTN_H)
        bx.pack(fill='x', side='bottom')
        bx.pack_propagate(False)
        rep_on = str(it.get('id')) in {str(x.get('id')) for x in self._v.get('repeat') or []}
        # ★ 2026-10-27 (docs/1.txt 5-1) 지정 전 = 회색 · 지정 뒤 = 형광색 · 자주 사는 상품 칸에서는 [지정해제]
        if in_repeat:
            rb = tk.Label(bx, text=_t('SHOP_REPEAT_UNSET', '지정해제'), cursor='hand2', padx=8,
                          bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'), relief='solid', bd=1)
        else:
            rb = tk.Label(bx, text=('✓ ' if rep_on else '+ ') + _t('SHOP_REPEAT', '자주 사는 상품'), cursor='hand2', padx=6,
                          bg=_C('warning_bg', '#FFF3C4') if rep_on else _C('panel_alt', '#F4F6F8'),
                          fg=_C('warning', '#8A5A00') if rep_on else _C('fg_dim', '#7F8C8D'))
        rb.pack(side='left', padx=4, pady=3)
        _font(rb, self.db, delta=-1, bold=rep_on and not in_repeat)
        rb.bind('<Button-1>', lambda _e, k=it.get('id'), v=rep_on: self._toggle_repeat(k, not v))
        card._repeat_btn = rb
        card._item_id = it.get('id')
        card._dim = dim
        for w in kids:
            w.bind('<Button-1>', lambda _e, x=it: self._open_item(x))
        return card

    def _thumb(self, name):
        try:
            import db_shop as SH
            p = SH.img_path(name)
            if not p:
                return None
            from PIL import Image, ImageTk
            im = Image.open(p)
            w = CARD_W - 2
            h = max(1, int(im.height * w / im.width))
            if h > THUMB_H:
                h = THUMB_H
                w = max(1, int(im.width * h / im.height))
            ph = ImageTk.PhotoImage(im.resize((w, h)))
            self._photos.append(ph)
            return ph
        except Exception:
            return None


def item_count(db_path, lang='KO'):
    """옛 이름 — `db_shop.item_count` 로 넘긴다(세는 문은 하나)."""
    import db_shop as SH
    return SH.item_count(db_path, lang)


def _selftest():
    ok, bad = [0], [0]

    def t(name, cond):
        if cond:
            ok[0] += 1
            print('  OK   ' + name)
        else:
            bad[0] += 1
            print('  FAIL ' + name)
    import inspect
    src = inspect.getsource(ShopView)
    t('배너(ads 그리기)를 안 쓴다 — 추천몰은 db_shop', 'AdBanner' not in src)
    t('안내에 수수료를 밝힌다', any('수수료' in d for _k, d in _GUIDE_KEYS))
    t('안내에 추적 안 함을 밝힌다', any('추적' in d for _k, d in _GUIDE_KEYS))
    t('세는 문은 db_shop 하나', item_count.__doc__ and 'db_shop' in item_count.__doc__)
    t('쇼핑몰 이름 단추가 없다(아이콘 + 풍선)', '_mall_card' not in src and '_search_box' not in src)
    print('\nshop_view selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return 0 if not bad[0] else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    print('shop_view.py — 추천몰 화면. 점검은 --selftest')
