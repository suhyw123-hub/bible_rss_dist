# -*- coding: utf-8 -*-
"""
db_bounds_import.py — 바운즈 『기도의 능력』 **진본** 적재 (2026-08-22 신설·영구)
===============================================================================
`python db_bounds_import.py --selftest`   — 의무
`python db_bounds_import.py --fetch`      — **두 곳**에서 받는다
`python db_bounds_import.py --check`      — 문지기 + 파싱 검사
`python db_bounds_import.py --preview 1 10 20`
`python db_bounds_import.py --purge --yes` — 위작 41행 제거(백업 후)
`python db_bounds_import.py --apply`      — 적재 (문지기 통과해야만)

━━ 왜 다시 넣는가 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★★★ 여기 있던 20장은 **저자의 글이 아니었다**(2026-08-22 실측). 원인 =
  `참고코드/db_book_bounds.py` 가 원문을 받지 않고 **본문을 스크립트 안에
  글자로 적어** 넣고 「— E.M. Bounds, Power Through Prayer (1907)」를 붙였다.
  · 문장 203개 중 원문에 있는 것 **18개(9%)** — 구텐베르크·CCEL 둘 다 같은 답
  · 장 제목 20개 중 19개가 **이 책에 없는 제목**
  · DB 의 `source_url`(구텐베르크 16905)은 **『The Great Red Frog』** 였다

★★★ **두 곳 일치 규칙** (사용자 지시) — `db_book_source_match.gate()` 를
  반드시 지난다. 한 곳만으로는 적재하지 않는다. 위 16905 사고가 그 이유다.

━━ 원문 두 곳 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  구텐베르크 #65115  https://www.gutenberg.org/cache/epub/65115/pg65115.txt
  CCEL bounds/power  https://ccel.org/ccel/bounds/power/cache/power.txt
  실측 상호 일치 92% / 88%.

⚠ **장마다 제사(epigraph)가 붙어 있다** — 맥체인·웨슬리 등의 인용문이 본문
  앞에 오고 `--이름` 으로 끝난다. 이 책의 특징이라 **본문에 포함해 담는다**
  (옛 위작에는 이것이 통째로 없었다).
⚠ 파싱은 **CCEL 판**으로 한다 — 장 머리글이 `1 Men of Prayer Needed` 꼴로
  깔끔하다. 구텐베르크판은 대조(문지기)에만 쓴다.
"""
import io
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import db_book_source_match as SM

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_bounds_raw')
CCEL = os.path.join(RAW, 'ccel_power.txt')
GUTEN = os.path.join(RAW, 'guten_power.txt')

SRC = [('CCEL', CCEL, 'https://ccel.org/ccel/bounds/power/cache/power.txt'),
       ('구텐베르크#65115', GUTEN,
        'https://www.gutenberg.org/cache/epub/65115/pg65115.txt')]

BOOK_CODE = 'BOUNDS_PTP'

# ── 저작권·출처 표시 (2026-08-22 사용자 지시) ────────────────────────────
# ⚠ **원문이 스스로 밝힌 것만 적는다.** 내 기억으로 연도를 지어내지 않는다.
#   구텐베르크 표제지 실측 — 「POWER THROUGH PRAYER / BY E. M. BOUNDS /
#   WITH FOREWORDS BY REV. A. C. DIXON, D.D., AND MR. ALBERT A. HEAD /
#   _TWELFTH EDITION_ / MARSHALL BROTHERS, LTD. LONDON, EDINBURGH & NEW YORK」.
#   ⇒ **판(edition)은 원문에 적혀 있으므로 쓴다. 초판 연도는 두 원문 어디에도
#     없으므로 쓰지 않는다.**
EDITION = 'Marshall Brothers, 12th ed.'
ATTRIB = ('— E. M. Bounds, "Power Through Prayer" (%s). '
          'Public domain. Source: Project Gutenberg #65115 / CCEL bounds/power.'
          % EDITION)

# 도서 소개문에 붙는 출처 블록 — 사용자가 화면에서 볼 수 있게
PROVENANCE = (
    '\n\n▸ 텍스트 출처\n'
    '  · Project Gutenberg #65115  https://www.gutenberg.org/ebooks/65115\n'
    '  · CCEL  https://ccel.org/ccel/bounds/power\n'
    '  · 판: Marshall Brothers, Ltd. (London·Edinburgh·New York) 제12판\n'
    '  · 저작권: 퍼블릭 도메인 (저자 1835~1913, 저작권 만료)\n'
    '  · 두 곳에서 각각 받아 서로 대조함 (문장 일치 92% / 88%).\n'
    '  · 장마다 앞에 붙는 인용문(제사)은 원서의 일부이며 그대로 담았습니다.\n'
    '  · 현대 영어판·번역본은 두지 않습니다.')
_HEAD = re.compile(r'^(\d{1,2}) ([A-Z].{3,70})\s*$', re.M)
_SEP = '_' * 30


def fetch():
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    ok = True
    for name, path, url in SRC:
        subprocess.run(['curl', '-sL', '--max-time', '120', '-o', path, url],
                       capture_output=True)
        n = os.path.getsize(path) if os.path.exists(path) else 0
        print('  %-18s %9s bytes  %s' % (name, format(n, ','), url))
        if n < 50000:
            ok = False
    return ok


def _paras(block):
    """문단으로 되붙이면서 **구분선을 걷는다**.

    ⚠ 블록 끝을 `rfind(_SEP)` 로 자르는 것만으로는 안 된다 — CCEL 은 구분선을
      **빈 줄 없이** 본문 바로 다음 줄에 붙이는 곳이 있어, 문단으로 되붙일 때
      마지막 문장 꼬리에 밑줄이 딸려 붙는다(실측 1장 8,031자 자리).
      ⇒ 문단 안에서도 밑줄 덩이를 지운다."""
    out = []
    for chunk in re.split(r'\n\s*\n', block):
        t = ' '.join(x.strip() for x in chunk.split('\n')).strip()
        t = re.sub(r'_{4,}', ' ', t).strip()
        if t:
            out.append(t)
    return out


def parse(raw=None):
    s = raw if raw is not None else io.open(CCEL, encoding='utf-8',
                                            errors='replace').read()
    heads = list(_HEAD.finditer(s))
    # 목차 줄(머리글이 촘촘히 몰린 곳)을 버린다 — 본문은 간격이 크다
    heads = [m for i, m in enumerate(heads)
             if i == 0 or m.start() - heads[i - 1].start() > 1500]
    out = []
    for i, m in enumerate(heads):
        b0, b1 = m.end(), (heads[i + 1].start() if i + 1 < len(heads) else len(s))
        block = s[b0:b1]
        k = block.rfind(_SEP)
        if k > len(block) * 0.5:
            block = block[:k]
        ps = _paras(block)
        # 제사 — 맨 앞 문단 중 `--이름` 으로 끝나는 것
        epi = ''
        if ps and re.search(r'--\s*[A-Z][A-Za-z. ]+$', ps[0]):
            epi = ps.pop(0).strip()
        out.append({'seq': int(m.group(1)), 'title': m.group(2).strip(),
                    'epigraph': epi, 'body': '\n'.join(ps).strip()})
    return out


def body_text(e):
    parts = []
    if e['epigraph']:
        parts.append(e['epigraph'])
    parts.append(e['body'])
    parts.append(ATTRIB)
    return '\n\n'.join(x for x in parts if x)


def check(items):
    bad = []
    if len(items) != 20:
        bad.append('장이 20 이 아니다: %d' % len(items))
    if [e['seq'] for e in items] != list(range(1, len(items) + 1)):
        bad.append('번호가 연속이 아니다: %s' % [e['seq'] for e in items])
    for e in items:
        if len(e['body']) < 2000:
            bad.append('%d장 본문이 짧다 (%d자)' % (e['seq'], len(e['body'])))
        if 'file:///' in e['body'] or '____' in e['body']:
            bad.append('%d장 꼬리 잔재' % e['seq'])
    n_epi = sum(1 for e in items if e['epigraph'])
    if n_epi < 15:
        bad.append('제사가 %d장에만 있다 (거의 모든 장에 있어야)' % n_epi)
    return bad


def purge(conn, dry=True):
    """위작 41행을 **백업하고** 제거. 유닛은 남긴다(플랜이 가리킨다)."""
    conn.execute("""CREATE TABLE IF NOT EXISTS temp_fake_book_backup(
        book_code TEXT, unit_id INTEGER, sequence INTEGER, unit_label TEXT,
        text_variant TEXT, lang_code TEXT, body_text TEXT, saved_at TEXT)""")
    rows = conn.execute("""
        SELECT u.unit_id, u.sequence, u.unit_label, x.text_variant,
               x.lang_code, x.body_text
          FROM sys_book_unit u JOIN sys_book_asset b ON b.book_id=u.book_id
          JOIN sys_book_unit_text x ON x.unit_id=u.unit_id
         WHERE b.book_code=?""", (BOOK_CODE,)).fetchall()
    if not dry:
        for r in rows:
            conn.execute(
                "INSERT INTO temp_fake_book_backup(book_code,unit_id,sequence,"
                "unit_label,text_variant,lang_code,body_text,saved_at) "
                "VALUES(?,?,?,?,?,?,?,datetime('now'))", (BOOK_CODE,) + tuple(r))
        conn.execute("""DELETE FROM sys_book_unit_text WHERE unit_id IN
            (SELECT u.unit_id FROM sys_book_unit u
               JOIN sys_book_asset b ON b.book_id=u.book_id
              WHERE b.book_code=?)""", (BOOK_CODE,))
        conn.commit()
    return len(rows)


def apply(conn, items, dry=False):
    """적재 — `(book_id, sequence)` 로 덮어써 `unit_id` 를 지킨다."""
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()[0]
    n_new = n_upd = 0
    for e in items:
        row = conn.execute("SELECT unit_id FROM sys_book_unit "
                           " WHERE book_id=? AND sequence=?",
                           (bid, e['seq'])).fetchone()
        label = 'Chapter %d: %s' % (e['seq'], e['title'])
        if row:
            uid = row[0]
            n_upd += 1
            if not dry:
                conn.execute("UPDATE sys_book_unit SET unit_label=?, "
                             " session_type='CHAPTER', record_status='LIVE' "
                             " WHERE unit_id=?", (label, uid))
        else:
            n_new += 1
            if dry:
                continue
            uid = conn.execute(
                "INSERT INTO sys_book_unit(book_id,sequence,session_type,"
                "unit_label,record_status) VALUES(?,?,'CHAPTER',?,'LIVE')",
                (bid, e['seq'], label)).lastrowid
        if dry:
            continue
        conn.execute("DELETE FROM sys_book_unit_text "
                     " WHERE unit_id=? AND text_variant='ORIGINAL'", (uid,))
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id,text_variant,lang_code,"
            "body_text,record_status) VALUES(?,'ORIGINAL','EN',?,'LIVE')",
            (uid, body_text(e)))
    if not dry:
        set_provenance(conn)
        conn.commit()
    return n_new, n_upd


def set_provenance(conn):
    """저작권·출처 표시를 바로잡는다 (2026-08-22 사용자 지시).

    ⚠ 고치기 전 실태 — `source_url` 이 **16905**(『The Great Red Frog』)였고,
      소개문은 「Project Gutenberg #16905 … MODERN_EN 번역 20챕터 완비」라고
      적고 있었다. **둘 다 사실이 아니다.**"""
    row = conn.execute("SELECT description FROM sys_book_asset "
                       " WHERE book_code=?", (BOOK_CODE,)).fetchone()
    desc = (row[0] or '') if row else ''
    # 옛 출처 블록(▸ 로 시작하는 꼬리)을 걷어 내고 새로 붙인다 — 멱등
    desc = re.split(r'\n\s*▸\s*텍스트', desc)[0].rstrip()
    conn.execute(
        "UPDATE sys_book_asset SET source_url=?, copyright_type='PUBLIC_DOMAIN',"
        "  description=? WHERE book_code=?",
        ('https://www.gutenberg.org/ebooks/65115', desc + PROVENANCE, BOOK_CODE))
    return True


def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        if not cond:
            ok = False

    sample = ('1 Men of Prayer Needed\n\n'
              '   Study universal holiness of life. Give yourself to prayer,\n'
              '   and get your texts from God.--Robert Murray McCheyne\n\n'
              '   ' + ('첫 문단 문장입니다. ' * 120) + '\n\n'
              '     ' + _SEP + '\n\n'
              '2 Our Sufficiency Is of God\n\n'
              '   ' + ('둘째 장 문장입니다. ' * 120) + '\n'
              '     ' + _SEP + '\n')
    it = parse(sample)
    chk('두 장으로 갈린다', len(it) == 2, len(it))
    chk('제목', it[0]['title'] == 'Men of Prayer Needed', it[0]['title'])
    chk('제사를 떼어 낸다', 'McCheyne' in it[0]['epigraph'], it[0]['epigraph'][:30])
    chk('제사는 본문에 안 남는다', 'McCheyne' not in it[0]['body'])
    chk('제사가 저장 본문에는 든다', 'McCheyne' in body_text(it[0]))
    chk('구분선 잔재 없음', '___' not in it[0]['body'])
    t = body_text(it[0])
    chk('출처 줄에 저자·책·판', 'E. M. Bounds' in t and EDITION in t, t[-90:])
    chk('출처 줄에 퍼블릭 도메인', 'Public domain' in t)
    chk('출처 줄에 받은 곳 둘', 'Gutenberg #65115' in t and 'CCEL' in t)
    # ⚠ 원문에 없는 연도를 지어내지 않는다 — 두 원문 어디에도 초판 연도가 없다
    chk('연도를 지어내지 않는다', not re.search(r'\(1[89]\d\d\)', ATTRIB), ATTRIB)

    # 탐지력 — check 가 잡는가
    chk('장 수가 다르면 잡는다', any('20' in b for b in check(it)))
    chk('짧은 본문을 잡는다',
        any('짧다' in b for b in check([dict(it[0], body='짧다')])))

    # 원문이 있으면 전량
    if os.path.exists(CCEL):
        items = parse()
        chk('원문 20장', len(items) == 20, len(items))
        probs = [p for p in check(items)]
        chk('원문 검사 통과', not probs, probs[:3])

    # 문지기를 실제로 지나는가
    have = [(n, p) for n, p, _u in SRC if os.path.exists(p)]
    if len(have) >= 2:
        try:
            w = SM.gate(BOOK_CODE, have, verbose=False)
            chk('두 곳 일치 문지기 통과', w >= SM.CROSS_MIN, '%.0f%%' % (w * 100))
        except SystemExit as e:
            chk('두 곳 일치 문지기 통과', False, e)
    else:
        print('  --   원문이 두 곳에 없다 — 문지기 검사 건너뜀 (--fetch)')
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    if '--fetch' in args:
        raise SystemExit(0 if fetch() else 1)

    have = [(n, p) for n, p, _u in SRC if os.path.exists(p)]
    if '--purge' in args:
        conn = appdb.connect()
        n = purge(conn, dry=('--yes' not in args))
        print('%s %d행 (백업표 temp_fake_book_backup)'
              % ('제거' if '--yes' in args else '제거 대상', n))
        conn.close()
        return
    if not have:
        raise SystemExit('원문이 없다 — `--fetch` 먼저')

    # ★★★ 문지기 — 여기를 못 지나면 아래로 못 간다
    print('두 곳 일치 확인')
    SM.gate(BOOK_CODE, have)
    items = parse()
    probs = check(items)

    if '--check' in args:
        print('\n파싱 %d장' % len(items))
        for e in items:
            print('   %2d  %-52s 제사%s  본문 %6d자'
                  % (e['seq'], e['title'][:50], 'O' if e['epigraph'] else 'X',
                     len(e['body'])))
        print('\n%s' % ('검사 통과' if not probs else '!! 문제 %d건' % len(probs)))
        for p in probs:
            print('   ', p)
        return
    if '--preview' in args:
        i = args.index('--preview')
        for a in args[i + 1:]:
            if not a.isdigit():
                break
            e = next((x for x in items if x['seq'] == int(a)), None)
            if not e:
                continue
            t = body_text(e)
            print('=' * 70)
            print('%d장 · %s' % (e['seq'], e['title']))
            print('=' * 70)
            print(t[:1500] + ('\n…(이하 %d자)' % (len(t) - 1500)
                              if len(t) > 1500 else ''))
            print()
        return
    if '--apply' in args:
        if probs:
            print('!! 검사에서 %d건 — 적재하지 않는다' % len(probs))
            for p in probs[:8]:
                print('   ', p)
            return
        conn = appdb.connect()
        n, u = apply(conn, items)
        print('새로 %d · 덮어씀 %d · source_url 을 65115 로 고쳤다' % (n, u))
        conn.close()
        return
    print(__doc__)


if __name__ == '__main__':
    main()
