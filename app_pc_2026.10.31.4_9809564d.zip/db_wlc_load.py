# -*- coding: utf-8 -*-
"""히브리 원문(WLC) 본문을 배포 DB 에 적재한다 (영구 도구 · 멱등).

⚠⚠ 옛 이름은 `temp_db_wlc_load.py` 였다 — **반복 실행할 도구에 `temp_` 를
  붙이지 말 것**(§0-5). 그 이름 때문에 2026-07-30 정리에서 게이트 다섯이
  통째로 `참고코드/` 로 휩쓸린 전례가 있다. 옛 파일은 `참고코드/` 로 옮겼다.

무엇을 넣나 — **본문만.**
    `wlc_verify.db` 에는 낱말마다 Strong 번호가 붙어 있는데 **그 층은 CC BY 4.0**
    (Open Scriptures)이라 배포하면 표기 의무가 생긴다. **본문 자체는 Public
    Domain**(Christopher Kimball)이므로 `heb` 칸만 떼어 넣는다(§18-10).

⚠ **형태소 구분자 `/` 를 지운다.** WLC 는 `בְּ/רֵאשִׁ֖ית` 처럼 접두사 경계를
  표시하는데 그대로 두면 화면에 사선이 그대로 나온다(실측 2,735회).
  원본은 `wlc_verify.db` 에 그대로 남는다.

⚠ **`coverage_scope` 를 고친다** — 실제로는 구약뿐이라 `OT_ONLY`.

★★★ **빈 칸 두 갈래를 갈라 적는다** (2026-09-24 285차 · §18-8 ④).
  | 갈래 | 자리 | 무엇 |
  |---|---|---|
  | **없는 절** | 느 7:68 · 아 6:14 | 이 판에 그 절이 없다 |
  | **병합** | 시 13:6 · 사 64:1 | 한 히브리 절이 영어 두 칸을 덮는다 |
  뒤엣것에 **`<병합 N:M>`** 표식을 적는다(`verse_text` 가 읽어 짝 절 본문을
  보인다). ⚠ 둘을 한 꼴로 두면 화면이 「없다」고만 말해 **왜 없는지**를 잃는다.
  짝은 `db_wlc_verify.MERGE_PARTNER` 한 곳에서 온다 — 여기서 또 적지 않는다.

쓰는 법
    python -X utf8 db_wlc_load.py --selftest
    python -X utf8 db_wlc_load.py --check      무엇이 들어갈지만 본다
    python -X utf8 db_wlc_load.py --apply      적재 (지우고 다시 넣는다)
"""

import os
import re
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb                                        # noqa: E402
import db_wlc_verify as W                           # noqa: E402

SRC = 'wlc_verify.db'
CODE = 'WLC'


def clean(t):
    """화면에 그대로 쓸 수 있는 본문으로. 형태소 사선을 지우고 공백을 정리한다."""
    if not t:
        return ''
    t = t.replace('/', '')
    return re.sub(r'\s+', ' ', t).strip()


def merge_rows(conn):
    """`<병합 N:M>` 로 적을 칸 → `[(verse_id, 본문)]`.

    ⚠ 표식만 적고 끝내지 않는다 — **짝 절 본문을 함께 굽는다**(§18-8 ④).
      그래야 그 칸을 눌러도 읽을 글이 나온다.
    ⚠ 짝 절이 아직 안 실렸으면 그 줄은 **안 만든다**(빈 표식은 거짓말이다).
    """
    src = os.path.join(os.path.dirname(os.path.abspath(__file__)), SRC)
    if not os.path.exists(src):
        return []
    w = sqlite3.connect(src)
    heb = dict(w.execute('SELECT verse_id, heb FROM wlc_verse'))
    w.close()
    out = []
    for (b, ch, v), (pch, pv) in sorted(W.MERGE_PARTNER.items()):
        me = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=?'
                          ' AND chapter=? AND verse=?', (b, ch, v)).fetchone()
        pa = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=?'
                          ' AND chapter=? AND verse=?', (b, pch, pv)).fetchone()
        if not me or not pa:
            continue
        body = clean(heb.get(pa[0]) or '')
        if not body:
            continue
        out.append((me[0], '<병합 %d:%d> %s' % (pch, pv, body)))
    return out


def read_src():
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), SRC)
    if not os.path.exists(p):
        print('X %s 가 없다 — `db_wlc_verify.py --build` 로 먼저 만든다' % SRC)
        return None
    c = sqlite3.connect(p)
    rows = c.execute('SELECT verse_id, heb FROM wlc_verse '
                     'WHERE heb IS NOT NULL AND heb <> ""').fetchall()
    c.close()
    return [(v, clean(t)) for v, t in rows if clean(t)]


# ── 자가검증 ────────────────────────────────────────────────────────
def selftest():
    n = [0, 0]

    def t(name, cond, got=''):
        n[1] += 1
        if cond:
            n[0] += 1
        print('  %-5s %s %s' % ('OK' if cond else 'FAIL', name, str(got)[:70]))

    t('사선을 지운다', clean('בְּ/רֵאשִׁית') == 'בְּרֵאשִׁית')
    t('공백을 접는다', clean(' a   b ') == 'a b')
    t('빈 글은 빈 글', clean(None) == '')
    t('★ 병합 짝이 둘', len(W.MERGE_PARTNER) == 2, sorted(W.MERGE_PARTNER))

    rows = read_src()
    if rows is None:
        t('원본 읽기', False, '검증 DB 없음')
        print('db_wlc_load selftest %d/%d' % (n[0], n[1]))
        return False
    t('원본을 읽는다', len(rows) > 20000, '%d절' % len(rows))
    t('  사선 0', not any('/' in x[1] for x in rows))

    conn = appdb.connect()
    try:
        mg = merge_rows(conn)
        t('★★ 병합 줄 둘을 만든다', len(mg) == 2, '%d줄' % len(mg))
        rx = W and __import__('verse_text')._RX_MERGE_TAG
        t('★★★ `verse_text` 가 그 표식을 읽는다',
          all(rx.match(x[1]) for x in mg),
          [x[1][:12] for x in mg])
        t('  표식 뒤에 짝 절 본문이 있다',
          all(len(rx.sub('', x[1])) > 20 for x in mg))
        vids = {v for v, _ in rows}
        t('★★★ 병합 칸은 본문 줄과 **겹치지 않는다**',
          not (vids & {v for v, _ in mg}),
          sorted(vids & {v for v, _ in mg}))
        ot = {v for (v,) in conn.execute(
            'SELECT verse_id FROM bible_index WHERE bcode<=39')}
        t('  모두 구약 칸이다', vids | {v for v, _ in mg} <= ot)
    finally:
        conn.close()
    print('db_wlc_load selftest %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


def main():
    if '--selftest' in sys.argv:
        return 0 if selftest() else 1
    apply_ = '--apply' in sys.argv
    rows = read_src()
    if rows is None:
        return 1

    conn = appdb.connect()
    ot = conn.execute("SELECT COUNT(*) FROM bible_index"
                      " WHERE bcode<=39").fetchone()[0]
    have = {r[0] for r in conn.execute("SELECT verse_id FROM bible_index"
                                       " WHERE bcode<=39")}
    miss = [v for v, _ in rows if v not in have]
    mg = merge_rows(conn)

    print('원본 %d절 · 구약 슬롯 %d절 · 빈 칸 %d (그중 병합 %d)'
          % (len(rows), ot, ot - len(rows), len(mg)))
    if miss:
        print('X 구약 슬롯에 없는 verse_id %d건 — 적재 중단' % len(miss))
        conn.close()
        return 1

    print('')
    print('표본 (창 1:1)')
    s = next((t for v, t in rows if v == 1), rows[0][1])
    print('  ', s[:60])
    print('   사선 남음:', '/' in s)
    for v, t in mg:
        r = conn.execute('SELECT bcode, chapter, verse FROM bible_index'
                         ' WHERE verse_id=?', (v,)).fetchone()
        print('  병합 칸 %s → %s' % (r, t[:28]))

    if not apply_:
        print('')
        print('검사만 했다. 적재하려면 --apply')
        conn.close()
        return 0

    conn.execute("DELETE FROM bible_content WHERE version_code=?", (CODE,))
    conn.executemany("INSERT INTO bible_content (verse_id, version_code,"
                     " verse_text) VALUES (?, ?, ?)",
                     [(v, CODE, t) for v, t in rows + mg])
    # 구약뿐이라는 사실을 역본 정보에 반영한다(안 고치면 신약 목록이 빈 채로 뜬다)
    conn.execute("UPDATE bible_version SET coverage_scope='OT_ONLY'"
                 " WHERE version_code=?", (CODE,))
    conn.commit()
    n = conn.execute("SELECT COUNT(*) FROM bible_content"
                     " WHERE version_code=?", (CODE,)).fetchone()[0]
    sc = conn.execute("SELECT coverage_scope FROM bible_version"
                      " WHERE version_code=?", (CODE,)).fetchone()[0]
    conn.close()
    print('')
    print('적재 완료 — %d행 (본문 %d + 병합 %d) · coverage_scope=%s'
          % (n, len(rows), len(mg), sc))
    print('다음: python -X utf8 db_wlc_align_check.py --check')
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                        # noqa: BLE001
        pass
    sys.exit(main())
