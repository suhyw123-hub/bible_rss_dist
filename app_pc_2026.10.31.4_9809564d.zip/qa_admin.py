"""
qa_admin.py
-----------
Q&A 관리(관리자 측) — §33. 사용자 문의(Apps Script→구글 시트)를 **관리자 로컬 DB로 흡수**해
언어·날짜·유형별 분석/답변. 답변은 Apps Script(관리자키)로 시트에 기록 → 트리거가 질문자에게
구글 계정으로 개별 회신 + 사용자앱 폴링.

설계:
 · 저장 = `admin_comm.db`(관리자 PC 전용, **미배포** — 사용자 질문=개인정보. bible_master/user_data 에 안 넣음).
 · 엔드포인트 = sys_config.SUPPORT_ENDPOINT_URL(배포 가능). **ADMIN_KEY = app_state_admin.json(미배포)**.
 · 구글 시트는 임시 창구(흡수 후 [시트 정리]로 비움 가능), 영구기록은 admin_comm.db.
순수 로직(Tk 없음). 외부 의존성 없음(urllib·sqlite3·json).
"""

import os
import json
import sqlite3
import urllib.request
from datetime import datetime

import appdb  # sys_config(엔드포인트) 읽기용
try:
    from admin import admin_state
except ImportError:
    import admin_state

_UA = {'User-Agent': 'BibleMatrix-QAadmin/1.0'}
_TIMEOUT = 25
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'admin_comm.db')


def conn():
    c = sqlite3.connect(DB_PATH)
    c.execute("""CREATE TABLE IF NOT EXISTS qa (
        msg_id TEXT PRIMARY KEY, uuid TEXT, lang TEXT, version TEXT,
        kind TEXT, q_type TEXT, question TEXT, email TEXT, attachments TEXT,
        reply TEXT, replied_at TEXT, ts TEXT, absorbed_at TEXT)""")
    return c


# ── 설정 ────────────────────────────────────────────────────────────────
def endpoint():
    try:
        with appdb.connect('bible_master.db') as bc:
            r = bc.execute("SELECT config_val FROM sys_config WHERE config_key='SUPPORT_ENDPOINT_URL'").fetchone()
        return (r[0].strip() if r and r[0] else '')
    except Exception:
        return ''


def get_admin_key():
    return admin_state.get('qa', 'admin_key', '') or ''


def set_admin_key(v):
    admin_state.set_('qa', 'admin_key', (v or '').strip())


# ── Apps Script 통신 ─────────────────────────────────────────────────────
def fetch_all():
    """관리자키로 전체 Q&A 행 GET. → (rows, err)."""
    url = endpoint()
    if not url:
        return [], 'NOT_CONFIGURED'
    key = get_admin_key()
    if not key:
        return [], 'NO_ADMIN_KEY'
    q = url + ('&' if '?' in url else '?') + 'admin=' + urllib.request.quote(key)
    try:
        with urllib.request.urlopen(urllib.request.Request(q, headers=_UA), timeout=_TIMEOUT) as r:
            data = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        return [], f'수신 실패: {str(e)[:80]}'
    if isinstance(data, dict) and data.get('err') == 'auth':
        return [], 'AUTH_FAIL(관리자키 불일치)'
    return (data.get('rows') or []), None


def send_reply(msg_id, reply):
    """답변을 Apps Script(관리자키)로 시트에 기록 + 로컬 갱신. → (ok, err)."""
    url = endpoint()
    if not url:
        return False, 'NOT_CONFIGURED'
    key = get_admin_key()
    if not key:
        return False, 'NO_ADMIN_KEY'
    payload = json.dumps({'action': 'reply', 'admin_key': key, 'msg_id': msg_id,
                          'reply': reply or ''}, ensure_ascii=False).encode('utf-8')
    try:
        req = urllib.request.Request(url, data=payload,
                                     headers={**_UA, 'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            body = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        return False, f'전송 실패: {str(e)[:80]}'
    if not body.get('ok'):
        return False, body.get('err', 'fail')
    c = conn()
    c.execute("UPDATE qa SET reply=?, replied_at=? WHERE msg_id=?",
              (reply, datetime.now().isoformat(timespec='seconds'), msg_id))
    c.commit(); c.close()
    return True, None


# ── 흡수 / 조회 ──────────────────────────────────────────────────────────
def absorb(rows):
    """시트 행을 admin_comm.db 로 upsert. q_type 은 최초엔 kind, 관리자 지정값은 보존. → 신규 수."""
    c = conn()
    now = datetime.now().isoformat(timespec='seconds')
    new = 0
    for r in rows:
        mid = r.get('msg_id') or ''
        if not mid:
            continue
        ex = c.execute("SELECT q_type FROM qa WHERE msg_id=?", (mid,)).fetchone()
        if ex:
            c.execute("UPDATE qa SET uuid=?, lang=?, version=?, kind=?, question=?, email=?, "
                      "attachments=?, reply=?, replied_at=?, ts=?, absorbed_at=? WHERE msg_id=?",
                      (r.get('uuid', ''), r.get('lang', ''), r.get('version', ''), r.get('kind', ''),
                       r.get('question', ''), r.get('email', ''), r.get('attachments', ''),
                       r.get('reply', ''), r.get('replied_at', ''), r.get('ts', ''), now, mid))
        else:
            c.execute("INSERT INTO qa (msg_id,uuid,lang,version,kind,q_type,question,email,"
                      "attachments,reply,replied_at,ts,absorbed_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (mid, r.get('uuid', ''), r.get('lang', ''), r.get('version', ''),
                       r.get('kind', ''), r.get('kind', ''), r.get('question', ''), r.get('email', ''),
                       r.get('attachments', ''), r.get('reply', ''), r.get('replied_at', ''),
                       r.get('ts', ''), now))
            new += 1
    c.commit(); c.close()
    return new


def list_qa(lang=None, q_type=None, answered=None, search=None):
    """필터 조회. answered: True=답변완료 / False=미답변 / None=전체. → dict 리스트(최신순)."""
    c = conn()
    where, args = ["1=1"], []
    if lang and lang != '전체':
        where.append("lang=?"); args.append(lang)
    if q_type and q_type != '전체':
        where.append("COALESCE(NULLIF(q_type,''),kind)=?"); args.append(q_type)
    if answered is True:
        where.append("COALESCE(reply,'')<>''")
    elif answered is False:
        where.append("COALESCE(reply,'')=''")
    if search:
        where.append("question LIKE ?"); args.append(f'%{search}%')
    rows = c.execute("SELECT msg_id,uuid,lang,kind,q_type,question,email,attachments,reply,"
                     "replied_at,ts FROM qa WHERE " + " AND ".join(where) +
                     " ORDER BY ts DESC, absorbed_at DESC", args).fetchall()
    c.close()
    cols = ['msg_id', 'uuid', 'lang', 'kind', 'q_type', 'question', 'email',
            'attachments', 'reply', 'replied_at', 'ts']
    return [dict(zip(cols, r)) for r in rows]


def set_type(msg_id, q_type):
    c = conn()
    c.execute("UPDATE qa SET q_type=? WHERE msg_id=?", (q_type, msg_id))
    c.commit(); c.close()


def distinct(col):
    c = conn()
    rows = [r[0] for r in c.execute(f"SELECT DISTINCT {col} FROM qa WHERE COALESCE({col},'')<>'' ORDER BY {col}")]
    c.close()
    return rows


def stats():
    c = conn()
    tot = c.execute("SELECT COUNT(*) FROM qa").fetchone()[0]
    unans = c.execute("SELECT COUNT(*) FROM qa WHERE COALESCE(reply,'')=''").fetchone()[0]
    c.close()
    return tot, unans
