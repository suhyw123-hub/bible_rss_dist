"""
genealogy_canvas.py (v5 — 읽기 전용 모드)

좌표는 sys_genealogy_layout 에서 읽어 그대로 렌더링. 사용자/관리자 모두 위치 편집 불가.
재배치가 필요하면 직접 SQL로 수정.

UI 동작 (최소):
  - 노드 좌클릭        → 정보 패널 갱신 + 빨강 점선 선택 ring
  - 노드 더블클릭      → 엔티티 정보 jump
  - 빈 영역 좌클릭+드래그 → 화면 pan
  - 마우스 휠           → 세로 스크롤 / Shift+휠 → 가로 스크롤

카드 표시 (A안 — 배경/테두리 제거):
  - 제목 색은 카드 종류별 유지 (COVENANT 노랑 / EXPLAIN 파랑 / GROUP 보라 / PERICOPE 녹색 / LABEL 빨강)
  - 본문은 회색 텍스트
  - 박스 없음 → 다국어로 폭 넘어가도 가시성 훼손 없음
"""

import os
import i18n
import sqlite3
import appdb
import ui_theme
import tkinter as tk
from tkinter import messagebox

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')


LINE_COLOR_BOTH    = '#F9E79F'
LINE_COLOR_MATTHEW = '#AED6F1'
LINE_COLOR_LUKE    = '#D2B4DE'

CLAN_COLORS = {
    '인류 시조': '#ECEFF1',
    '아담 자손': '#ECEFF1',
    '함 라인':  '#FADBD8',
    '야벳 라인': '#D5F5E3',
    '이집트':   '#F6DDCC',
    '아람':     '#E8DAEF',
    '가나안':   '#F5B7B1',
    '모압':     '#F9E79F',
    '미디안':   '#A2D9CE',
    '에돔 조상': '#F1948A',
    '아랍 조상': '#FDEBD0',
}
CLAN_DEFAULT = '#F2F4F4'

CARD_COLOR = {
    'COVENANT': '#B7791F',  # 진노랑 (가독성 위해 약간 진하게)
    'EXPLAIN':  '#2E86C1',
    'GROUP':    '#7D3C98',
    'PERICOPE': '#117A65',
    'LABEL':    '#C0392B',
}


def _node_bg(matthew, luke, clan):
    if matthew and luke:
        return LINE_COLOR_BOTH
    if matthew:
        return LINE_COLOR_MATTHEW
    if luke:
        return LINE_COLOR_LUKE
    if not clan:
        return CLAN_DEFAULT
    for key in CLAN_COLORS:
        if key in clan:
            return CLAN_COLORS[key]
    return CLAN_DEFAULT


class GenealogyCanvas(tk.Frame):
    NODE_W = 120
    NODE_H = 28

    def __init__(self, parent, db_path=None, lang_provider=None,
                  on_entity_jump=None, lineage_type='MESSIANIC', **kwargs):
        super().__init__(parent, **kwargs)
        self.db_path = db_path or DB
        self.lang_provider = lang_provider or (lambda: 'KO')
        self.on_entity_jump = on_entity_jump
        # 'MESSIANIC' 또는 'DISCIPLE' — lineage_type 필터링
        self.lineage_type = lineage_type
        # 제자 모드는 영문 이름 길어 노드 폭 확대
        if lineage_type == 'DISCIPLE':
            self.NODE_W = 200

        self._persons = []
        self._relations = []
        self._cards = []
        self._positions = {}          # gp_id → (x, y)
        self._card_positions = {}     # card_id → (x, y)
        self._search_var = tk.StringVar()
        self._pan_start = None
        self._selected_gp = None
        # 드래그 상태
        self._drag_target = None      # ('PERSON', gp_id) or ('CARD', cid)
        self._drag_start_mouse = None
        self._drag_start_pos = None

        self._build()
        self._load_data()
        self._apply_saved_layout()
        self._redraw()
        self._refresh_info_panel()
        self.after(150, self._restore_view)

    # ───────── UI 구축 ─────────

    def _build(self):
        tb = tk.Frame(self, bg='#F2F4F4')
        ui_theme.bar_height(tb)         # P4 서브탭 공통 높이(32px)
        tb.pack(side='top', fill='x')
        tk.Label(tb, text=i18n.t('COMMON_SEARCH','검색')+':', bg='#F2F4F4',
                  font=('Malgun Gothic', 9)).pack(side='left', padx=(6, 2))
        e = tk.Entry(tb, textvariable=self._search_var, width=18,
                      font=('Malgun Gothic', 9))
        e.pack(side='left', padx=2)
        e.bind('<Return>', lambda ev: self._search())
        tk.Button(tb, text='검색', font=('Malgun Gothic', 9),
                   command=self._search, padx=4).pack(side='left', padx=2)
        if self.lineage_type == 'MESSIANIC':
            tk.Button(tb, text=i18n.t('GC_P_ADAM','아담'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('아담')).pack(side='left', padx=(8, 2))
            tk.Button(tb, text=i18n.t('GC_P_ABRAHAM','아브라함'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('아브라함')).pack(side='left', padx=2)
            tk.Button(tb, text=i18n.t('GC_P_DAVID','다윗'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('다윗')).pack(side='left', padx=2)
            tk.Button(tb, text=i18n.t('GC_P_JESUS','✝ 예수'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('예수 그리스도')).pack(side='left', padx=2)
        else:  # DISCIPLE
            tk.Button(tb, text=i18n.t('GC_P_JESUS','✝ 예수'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('예수 그리스도')).pack(side='left', padx=(8, 2))
            tk.Button(tb, text=i18n.t('GC_P_PETER','베드로'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('베드로')).pack(side='left', padx=2)
            tk.Button(tb, text=i18n.t('GC_P_PAUL','바울'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('바울')).pack(side='left', padx=2)
            tk.Button(tb, text=i18n.t('GC_P_JOHN','요한'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('요한(사도)')).pack(side='left', padx=2)
            tk.Button(tb, text=i18n.t('GC_P_POLYCARP','폴리캅'), font=('Malgun Gothic', 9),
                       command=lambda: self._focus_name('폴리캅')).pack(side='left', padx=2)
        # ⚠ 매뉴얼 단추를 **뗐다** (2026-08-22) — 신뢰도 4단계(실선/점선) 설명은
        #   **범례 카드가 화면에 이미 있다**(LEGEND_DISCIPLE). 게다가 이 화면은
        #   매뉴얼이 등록된 적이 없어 눌러도 「(매뉴얼 없음)」만 떴다.

        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#D5DBDB')
        pw.pack(side='top', fill='both', expand=True)

        canvas_frm = tk.Frame(pw, bg='#FFFFFF')
        pw.add(canvas_frm, minsize=500, stretch='always')
        vsb = tk.Scrollbar(canvas_frm, orient='vertical')
        hsb = tk.Scrollbar(canvas_frm, orient='horizontal')
        self.canvas = tk.Canvas(canvas_frm, bg='#FFFFFF', highlightthickness=0,
                                  yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.config(command=self.canvas.yview)
        hsb.config(command=self.canvas.xview)
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        self.canvas.pack(side='left', fill='both', expand=True)
        self.canvas.bind('<ButtonPress-1>', self._on_press)
        self.canvas.bind('<B1-Motion>', self._on_motion)
        self.canvas.bind('<ButtonRelease-1>', self._on_release)
        self.canvas.bind('<MouseWheel>', self._on_wheel)

        # 메시아: 주요용어 화면(닫힘 모드) — **오른쪽** 슬라이딩, 초기 숨김
        #   (2026-09-15 · 옛 압축판을 걷고 같은 화면을 쓴다).
        # 제자(DISCIPLE)는 기존 _info_panel 유지.
        self._geneal_pw = pw                       # PanedWindow 참조 (add/forget 용)
        self._geneal_canvas_frm = canvas_frm       # 슬라이딩 패널의 anchor (before=)
        if self.lineage_type == 'MESSIANIC':
            try:
                from entity_browser import EntityBrowserPanel
                self._entity_browser = EntityBrowserPanel(
                    pw, db_path=self.db_path,
                    lang_getter=self.lang_provider,
                    compact=True,
                    on_close=self._hide_entity_browser)
                # 초기에는 pw.add 안 함 — 노드 클릭 시 왼쪽에 add
                self._eb_visible = False
                self._info_panel = None
            except Exception as e:
                print(f'[GenealogyCanvas EntityBrowser embed] {e}')
                self._entity_browser = None
                self._eb_visible = False
                self._info_panel = tk.Frame(pw, bg='#FAFAFA')
                self._info_panel.pack_propagate(False)
                pw.add(self._info_panel, width=280, minsize=220, stretch='never')
                self._build_info_panel()
        else:
            self._entity_browser = None
            self._eb_visible = False
            self._info_panel = tk.Frame(pw, bg='#FAFAFA')
            self._info_panel.pack_propagate(False)
            pw.add(self._info_panel, width=280, minsize=220, stretch='never')
            self._build_info_panel()

    def _show_entity_browser(self):
        """주요용어 화면(닫힘 모드)을 **오른쪽**에 add (2026-09-15 사용자
        「오른쪽에서 표시되는 방식으로 수정하라」 — 그전에는 캔버스 왼쪽)."""
        if self._entity_browser is None or self._eb_visible:
            return
        try:
            self._geneal_pw.add(self._entity_browser,
                                  width=480, minsize=320, stretch='always')
            self._eb_visible = True
        except Exception as e:
            print(f'[show entity_browser] {e}')

    def _hide_entity_browser(self):
        """X 버튼 콜백 — PanedWindow 에서 forget."""
        if self._entity_browser is None or not self._eb_visible:
            return
        try:
            self._geneal_pw.forget(self._entity_browser)
            self._eb_visible = False
        except Exception as e:
            print(f'[hide entity_browser] {e}')

    def _build_info_panel(self):
        head = tk.Frame(self._info_panel, bg='#3498DB', height=32)
        head.pack(fill='x')
        head.pack_propagate(False)
        self._info_title = tk.Label(head, text=i18n.t('GC_PERSONSEL','인물 선택'), bg='#3498DB',
                                      fg='white', font=('Malgun Gothic', 11, 'bold'),
                                      anchor='w', padx=8)
        self._info_title.pack(fill='both', expand=True)
        self._info_basic = tk.Frame(self._info_panel, bg='#FAFAFA')
        self._info_basic.pack(fill='x', padx=6, pady=4)

        tk.Label(self._info_panel, text=i18n.t('GC_PERILINK','페리코프 연결'), bg='#FAFAFA',
                  font=('Malgun Gothic', 9, 'bold'), fg='#566573',
                  anchor='w', padx=6).pack(fill='x', pady=(8, 1))
        peri_frm = tk.Frame(self._info_panel)
        peri_frm.pack(fill='both', expand=True, padx=6, pady=2)
        sb = tk.Scrollbar(peri_frm, orient='vertical')
        sb.pack(side='right', fill='y')
        self._peri_list = tk.Listbox(peri_frm, font=('Malgun Gothic', 9),
                                       yscrollcommand=sb.set, bg='#FFFFFF')
        self._peri_list.pack(side='left', fill='both', expand=True)
        sb.config(command=self._peri_list.yview)

        tk.Label(self._info_panel, text=i18n.t('MYPATH_COL_MEMO','메모'), bg='#FAFAFA',
                  font=('Malgun Gothic', 9, 'bold'), fg='#566573',
                  anchor='w', padx=6).pack(fill='x', pady=(8, 1))
        self._info_notes = tk.Label(self._info_panel, text='', bg='#FCF3CF',
                                      anchor='w', justify='left', wraplength=250,
                                      font=('Malgun Gothic', 9), padx=6, pady=4)
        self._info_notes.pack(fill='x', padx=6, pady=(0, 6))

    # ───────── DB 로드 ─────────

    def _load_data(self):
        with appdb.connect(self.db_path) as c:
            cols = [r[1] for r in c.execute(
                "PRAGMA table_info(sys_genealogy_person)").fetchall()]
            virt = 'is_virtual' if 'is_virtual' in cols else '0 AS is_virtual'
            gid = 'group_card_id' if 'group_card_id' in cols else 'NULL AS group_card_id'
            dko = 'disambig_ko' if 'disambig_ko' in cols else 'NULL AS disambig_ko'
            den = 'disambig_en' if 'disambig_en' in cols else 'NULL AS disambig_en'
            # lineage_type 필터 — MESSIANIC 모드: MESSIANIC + BOTH, DISCIPLE 모드: DISCIPLE + BOTH
            lt_filter = ("COALESCE(lineage_type,'MESSIANIC') IN ('MESSIANIC','BOTH')"
                          if self.lineage_type == 'MESSIANIC'
                          else "COALESCE(lineage_type,'MESSIANIC') IN ('DISCIPLE','BOTH')")
            self._persons = c.execute(
                f"SELECT gp_id, name_ko, name_en, gender, generation, clan, "
                f"       is_messiah_line, matthew_line, luke_line, entity_id, "
                f"       {virt}, {gid}, {dko}, {den} "
                f"  FROM sys_genealogy_person "
                f" WHERE record_status='LIVE' "
                f"   AND {gid} IS NULL "
                f"   AND {lt_filter} "
                f" ORDER BY generation, gp_id").fetchall()
            rcols = [r[1] for r in c.execute(
                "PRAGMA table_info(sys_genealogy_relation)").fetchall()]
            conf = 'confidence' if 'confidence' in rcols else "'BIBLICAL' AS confidence"
            rsub = 'rel_subtype' if 'rel_subtype' in rcols else "NULL AS rel_subtype"
            self._relations = c.execute(
                f"SELECT gr_id, from_id, to_id, rel_type, sequence, spouse_clan, "
                f"       {conf}, {rsub} "
                f"  FROM sys_genealogy_relation "
                f" WHERE record_status='LIVE'").fetchall()
            try:
                lang = (self.lang_provider() or 'KO').upper()
                # 카드도 lineage_type 필터
                card_lt = ("COALESCE(lineage_type,'MESSIANIC') IN ('MESSIANIC','BOTH')"
                            if self.lineage_type == 'MESSIANIC'
                            else "COALESCE(lineage_type,'MESSIANIC') IN ('DISCIPLE','BOTH')")
                self._cards = c.execute(
                    f"SELECT c1.card_id, c1.card_key, c1.card_type, c1.section, "
                    f"       c1.sort_order, c1.title, c1.body "
                    f"  FROM sys_genealogy_card c1 "
                    f" WHERE c1.record_status='LIVE' "
                    f"   AND {card_lt} "
                    f"   AND UPPER(c1.lang_code) = ( "
                    f"       SELECT UPPER(c2.lang_code) FROM sys_genealogy_card c2 "
                    f"        WHERE c2.card_key=c1.card_key AND c2.record_status='LIVE' "
                    f"          AND UPPER(c2.lang_code) IN (?, 'EN') "
                    f"        ORDER BY CASE UPPER(c2.lang_code) WHEN ? THEN 0 ELSE 1 END "
                    f"        LIMIT 1) "
                    f" ORDER BY c1.section, c1.sort_order", (lang, lang)).fetchall()
            except Exception:
                self._cards = []

    # ───────── 저장 좌표 적용 ─────────

    def _apply_saved_layout(self):
        """sys_genealogy_layout에서 좌표 로드. 없으면 fallback."""
        saved = {}
        with appdb.connect(self.db_path) as c:
            try:
                for ttype, tid, x, y in c.execute(
                    "SELECT target_type, target_id, x, y "
                    "  FROM sys_genealogy_layout").fetchall():
                    saved[(ttype, tid)] = (x, y)
            except sqlite3.OperationalError:
                pass

        # DISCIPLE 모드 — era 기반 분산 fallback (모든 인물 gen=0이라 겹침 방지)
        era_map = {}
        if self.lineage_type == 'DISCIPLE':
            with appdb.connect(self.db_path) as c:
                try:
                    for r in c.execute(
                        "SELECT gp_id, COALESCE(era,'APOSTOLIC') "
                        "  FROM sys_genealogy_person").fetchall():
                        era_map[r[0]] = r[1]
                except sqlite3.OperationalError:
                    pass

        ERA_ORDER = ['APOSTOLIC', 'APOSTOLIC_FATHER', 'APOLOGIST', 'ANTE_NICENE_FATHER']
        ERA_BAND_W = 2000     # 시대별 가로 폭
        ROWS_PER_COL = 8      # 격자 한 column당 행 수
        COL_GAP = self.NODE_W + 30
        ROW_GAP = self.NODE_H + 20

        era_count = {era: 0 for era in ERA_ORDER}
        for p in self._persons:
            gp_id = p[0]
            key = ('PERSON', gp_id)
            if key in saved:
                self._positions[gp_id] = saved[key]
                continue
            if self.lineage_type == 'DISCIPLE':
                era = era_map.get(gp_id, 'APOSTOLIC')
                era_idx = ERA_ORDER.index(era) if era in ERA_ORDER else 0
                col = era_count[era] // ROWS_PER_COL
                row = era_count[era] % ROWS_PER_COL
                era_count[era] += 1
                x = era_idx * ERA_BAND_W + col * COL_GAP
                y = (row - ROWS_PER_COL // 2) * ROW_GAP
                self._positions[gp_id] = (x, y)
            else:
                gen = p[4] or 0
                self._positions[gp_id] = (gen * 180, 0)

        # 카드 — fallback: 인물 영역 아래, 좌→우
        cur_x = 0
        max_y = max((y for _, y in self._positions.values()), default=0)
        band_y = max_y + 120
        for c in self._cards:
            cid = c[0]
            key = ('CARD', cid)
            if key in saved:
                self._card_positions[cid] = saved[key]
            else:
                self._card_positions[cid] = (cur_x, band_y)
                cur_x += 320

    def _update_scrollregion(self):
        max_x = max([x + self.NODE_W for x, _ in self._positions.values()] +
                     [x + 300 for x, _ in self._card_positions.values()] +
                     [1000])
        max_y = max([y + self.NODE_H for _, y in self._positions.values()] +
                     [y + 200 for _, y in self._card_positions.values()] +
                     [500])
        min_x = min([x for x, _ in self._positions.values()] +
                     [x for x, _ in self._card_positions.values()] +
                     [-100])
        min_y = min([y for _, y in self._positions.values()] +
                     [y for _, y in self._card_positions.values()] +
                     [-100])
        self.canvas.config(scrollregion=(min_x - 33, min_y - 33,
                                            max_x + 100, max_y + 100))

    # ───────── 그리기 ─────────

    def _redraw(self):
        self.canvas.delete('all')

        # 관계선
        for rel in self._relations:
            gr_id, fid, tid, rtype, seq, sclan = rel[:6]
            confidence = rel[6] if len(rel) > 6 else 'BIBLICAL'
            rel_subtype = rel[7] if len(rel) > 7 else None
            if fid not in self._positions or tid not in self._positions:
                continue
            fx, fy = self._positions[fid]
            tx, ty = self._positions[tid]
            fcx, fcy = fx + self.NODE_W / 2, fy + self.NODE_H / 2
            tcx, tcy = tx + self.NODE_W / 2, ty + self.NODE_H / 2

            if rtype in ('FATHER', 'MOTHER'):
                fr = fx + self.NODE_W
                tl = tx
                mid_x = (fr + tl) / 2
                color = '#5DADE2' if rtype == 'FATHER' else '#C39BD3'
                width = 2 if rtype == 'FATHER' else 1.2
                dash = None if rtype == 'FATHER' else (3, 2)
                kw = dict(fill=color, width=width)
                if dash:
                    kw['dash'] = dash
                self.canvas.create_line(
                    fr, fcy, mid_x, fcy, mid_x, tcy, tl, tcy, **kw)
            elif rtype == 'TEACHER':
                # 스승 → 제자 — 메시아 가계도 FATHER 패턴 (꺾임 직각선)
                # 모든 TEACHER 관계는 파란색 단일 (rel_subtype 색 구분 제거)
                color = '#2980B9'
                if confidence == 'BIBLICAL':
                    width, dash = 1.2, None
                elif confidence == 'EARLY_TRADITION':
                    width, dash = 0.9, None
                elif confidence == 'LATER_TRADITION':
                    width, dash = 0.8, (5, 3)
                else:
                    width, dash = 0.6, (2, 3)
                kw = dict(fill=color, width=width)
                if dash:
                    kw['dash'] = dash
                fr = fx + self.NODE_W
                tl = tx
                mid_x = (fr + tl) / 2 if tl > fr else fr + 30
                self.canvas.create_line(
                    fr, fcy, mid_x, fcy, mid_x, tcy, tl, tcy,
                    arrow='last', arrowshape=(10, 12, 4), **kw)
            elif rtype in ('SPOUSE', 'CONCUBINE', 'INFORMAL'):
                color_map = {'SPOUSE': '#27AE60', 'CONCUBINE': '#E67E22',
                             'INFORMAL': '#C0392B'}
                dash_map = {'SPOUSE': None, 'CONCUBINE': (4, 3),
                            'INFORMAL': (2, 4)}
                kw = dict(fill=color_map[rtype], width=2.2)
                if dash_map[rtype]:
                    kw['dash'] = dash_map[rtype]
                if abs(fx - tx) < 5:
                    # 같은 x — 짧은 세로선
                    if fy < ty:
                        y1, y2 = fy + self.NODE_H, ty
                    else:
                        y1, y2 = ty + self.NODE_H, fy
                    mid_x = fx + self.NODE_W / 2
                    self.canvas.create_line(mid_x, y1, mid_x, y2, **kw)
                else:
                    self.canvas.create_line(fcx, fcy, tcx, tcy, **kw)

        # 인물 노드 (크기 고정)
        lang = (self.lang_provider() or 'KO').upper()
        for p in self._persons:
            (gp_id, name, name_en, gender, gen, clan, _is_m, mt, lk,
             ent_id, is_virtual, _grp, dis_ko, dis_en) = p
            if gp_id not in self._positions:
                continue
            x, y = self._positions[gp_id]
            tag = f'node_{gp_id}'
            if is_virtual:
                # 다이아몬드 + 이름 라벨 (오른쪽에 표시)
                cx = x + self.NODE_W / 2
                cy = y + self.NODE_H / 2
                s = 10
                self.canvas.create_polygon(
                    cx, cy - s, cx + s, cy, cx, cy + s, cx - s, cy,
                    fill='#D5DBDB', outline='#566573', width=1.5,
                    tags=(tag, 'node'))
                disp_name = name if lang == 'KO' else (name_en or name)
                self.canvas.create_text(
                    cx + s + 6, cy, text=disp_name, anchor='w',
                    font=('Malgun Gothic', 9, 'italic'),
                    fill='#566573',
                    tags=(tag, 'node'))
            else:
                bg = _node_bg(mt, lk, clan)
                key_nodes = ('다윗', '스알디엘', '스룹바벨')
                is_key = name in key_nodes
                outline = '#C0392B' if is_key else ''
                width = 2 if is_key else 0
                disp_name = name if lang == 'KO' else (name_en or name)
                self.canvas.create_rectangle(
                    x, y, x + self.NODE_W, y + self.NODE_H,
                    fill=bg, outline=outline, width=width,
                    tags=(tag, 'node'))
                self.canvas.create_text(
                    x + self.NODE_W / 2, y + self.NODE_H / 2,
                    text=disp_name, font=('Malgun Gothic', 9, 'bold'),
                    tags=(tag, 'node'))
                dis = dis_ko if lang == 'KO' else (dis_en or dis_ko)
                if dis:
                    self.canvas.create_text(
                        x + self.NODE_W / 2, y + self.NODE_H + 2,
                        text=dis, anchor='n',
                        font=('Malgun Gothic', 7), fill='#7F8C8D',
                        tags=(tag, 'node'))
            self.canvas.tag_bind(tag, '<Double-1>',
                                   lambda ev, gid=gp_id: self._on_node_double(gid))

            if gp_id == self._selected_gp:
                self.canvas.create_rectangle(
                    x - 3, y - 3, x + self.NODE_W + 3, y + self.NODE_H + 3,
                    outline='#C0392B', width=2, dash=(3, 2),
                    tags=('select_ring',))

        # 카드 — A안: 배경/테두리 제거, 제목 색만 유지
        for card in self._cards:
            cid, key, ctype, sec, sort, title, body = card
            if cid not in self._card_positions:
                continue
            cx, cy = self._card_positions[cid]
            title_color = CARD_COLOR.get(ctype, '#5D6D7E')
            # 본문은 wrap 폭 = 카드 기본 폭 (300) — 박스 없어도 wrap 유지
            self.canvas.create_text(
                cx, cy, text=title, anchor='nw',
                font=('Malgun Gothic', 10, 'bold'),
                fill=title_color, width=300)
            self.canvas.create_text(
                cx, cy + 24, text=body, anchor='nw',
                font=('Malgun Gothic', 9),
                fill='#34495E', width=300)

        self._update_scrollregion()

    # ───────── 이벤트 (읽기 전용) ─────────

    def _on_press(self, ev):
        # 노드/카드 hit → 드래그 시작, 빈 영역 → pan
        cx = self.canvas.canvasx(ev.x)
        cy = self.canvas.canvasy(ev.y)
        items = self.canvas.find_overlapping(cx - 1, cy - 1, cx + 1, cy + 1)
        for item in reversed(items):
            for t in self.canvas.gettags(item):
                if t.startswith('node_'):
                    try:
                        gp_id = int(t.split('_', 1)[1])
                        self._selected_gp = gp_id
                        self._refresh_info_panel()
                        # 드래그 시작
                        self._drag_target = ('PERSON', gp_id)
                        self._drag_start_mouse = (cx, cy)
                        self._drag_start_pos = self._positions.get(gp_id)
                        self._redraw()
                        return
                    except ValueError:
                        pass
                elif t.startswith('card_'):
                    try:
                        cid = int(t.split('_', 1)[1])
                        self._drag_target = ('CARD', cid)
                        self._drag_start_mouse = (cx, cy)
                        pos = self._card_positions.get(cid)
                        self._drag_start_pos = (pos[0], pos[1]) if pos else None
                        return
                    except ValueError:
                        pass
        # 빈 영역 → pan
        self.canvas.scan_mark(ev.x, ev.y)
        self._pan_start = (ev.x, ev.y)

    def _on_motion(self, ev):
        if self._drag_target and self._drag_start_pos:
            cx = self.canvas.canvasx(ev.x)
            cy = self.canvas.canvasy(ev.y)
            sx, sy = self._drag_start_mouse
            ox, oy = self._drag_start_pos
            new_x, new_y = ox + (cx - sx), oy + (cy - sy)
            ttype, tid = self._drag_target
            if ttype == 'PERSON':
                old_x, old_y = self._positions[tid]
                self._positions[tid] = (new_x, new_y)
                self.canvas.move(f'node_{tid}', new_x - old_x, new_y - old_y)
            else:
                old_x, old_y = self._card_positions[tid]
                self._card_positions[tid] = (new_x, new_y)
                self.canvas.move(f'card_{tid}', new_x - old_x, new_y - old_y)
            return
        if self._pan_start:
            self.canvas.scan_dragto(ev.x, ev.y, gain=1)

    def _on_release(self, ev):
        if self._drag_target:
            ttype, tid = self._drag_target
            if ttype == 'PERSON':
                x, y = self._positions[tid]
            else:
                x, y = self._card_positions[tid]
            # DB 저장
            try:
                with appdb.connect(self.db_path) as c:
                    c.execute('''
                        INSERT INTO sys_genealogy_layout
                          (target_type, target_id, x, y, updated_at)
                        VALUES (?, ?, ?, ?, datetime('now'))
                        ON CONFLICT(target_type, target_id) DO UPDATE SET
                            x=excluded.x, y=excluded.y,
                            updated_at=excluded.updated_at
                    ''', (ttype, tid, x, y))
                    c.commit()
            except Exception as e:
                print(f'[save] {e}')
            self._drag_target = None
            self._drag_start_mouse = None
            self._drag_start_pos = None
            self._redraw()
            return
        if self._pan_start:
            self._save_view()
            self._pan_start = None

    def _on_node_double(self, gp_id):
        p = next((p for p in self._persons if p[0] == gp_id), None)
        if p and p[9] and self.on_entity_jump:
            self.on_entity_jump(p[9])

    def _on_wheel(self, ev):
        if ev.state & 0x0001:
            self.canvas.xview_scroll(int(-1 * (ev.delta / 120)), 'units')
        else:
            self.canvas.yview_scroll(int(-1 * (ev.delta / 120)), 'units')
        self._save_view()

    # ───────── 검색·포커스·view 저장 ─────────

    def _search(self):
        q = self._search_var.get().strip()
        if not q:
            return
        for p in self._persons:
            gp_id, name, name_en, *_ = p
            if q in name or (name_en and q.lower() in name_en.lower()):
                if gp_id in self._positions:
                    self._focus_gp(gp_id)
                    self._selected_gp = gp_id
                    self._refresh_info_panel()
                    self._redraw()
                    return
        messagebox.showinfo(i18n.t('COMMON_SEARCH', '검색'), i18n.t('MSG_PERSON_NOTFOUND', '"{q}" 인물을 찾지 못했습니다.').format(q=q))

    def _focus_gp(self, gp_id):
        if gp_id not in self._positions:
            return
        x, y = self._positions[gp_id]
        sx, sy, sex, sey = self.canvas.cget('scrollregion').split()
        sx, sy, sex, sey = float(sx), float(sy), float(sex), float(sey)
        rng_x = sex - sx
        rng_y = sey - sy
        if rng_x > 0 and rng_y > 0:
            cw = self.canvas.winfo_width() or 800
            ch = self.canvas.winfo_height() or 600
            target_x = (x - cw / 2 - sx) / rng_x
            target_y = (y - ch / 2 - sy) / rng_y
            self.canvas.xview_moveto(max(0, min(1, target_x)))
            self.canvas.yview_moveto(max(0, min(1, target_y)))

    def _focus_name(self, name_ko):
        for p in self._persons:
            if p[1] == name_ko:
                self._focus_gp(p[0])
                return

    def _restore_view(self):
        # gp_id=-1 = MESSIANIC view, gp_id=-2 = DISCIPLE view
        view_key = -1 if self.lineage_type == 'MESSIANIC' else -2
        with appdb.connect(self.db_path) as c:
            try:
                r = c.execute(
                    "SELECT x, y FROM user_genealogy_layout WHERE gp_id=?",
                    (view_key,)).fetchone()
            except sqlite3.OperationalError:
                r = None
        if r:
            self.canvas.xview_moveto(r[0])
            self.canvas.yview_moveto(r[1])
        else:
            self._focus_name('예수 그리스도')

    def _save_view(self):
        view_key = -1 if self.lineage_type == 'MESSIANIC' else -2
        try:
            xs = self.canvas.xview()
            ys = self.canvas.yview()
            with appdb.connect(self.db_path) as c:
                cur = c.cursor()
                r = cur.execute(
                    "SELECT 1 FROM user_genealogy_layout WHERE gp_id=?",
                    (view_key,)).fetchone()
                if r:
                    cur.execute(
                        "UPDATE user_genealogy_layout SET x=?, y=?, "
                        "       updated_at=datetime('now') WHERE gp_id=?",
                        (xs[0], ys[0], view_key))
                else:
                    cur.execute(
                        "INSERT INTO user_genealogy_layout "
                        "(gp_id, x, y, updated_at) VALUES (?, ?, ?, datetime('now'))",
                        (view_key, xs[0], ys[0]))
                c.commit()
        except Exception:
            pass

    # ───────── 정보 패널 ─────────

    def _refresh_entity_browser(self):
        """메시아 가계도 우측 — EntityBrowserPanel(compact)에 선택 인물 표시.
        · 엔티티 등록된 인물: load_entity(eid) 호출 (페리코프 없으면 우측 자동 숨김)
        · 그룹 A 인물(entity_id NULL): placeholder 안내 표시
        · 선택 없음: placeholder
        """
        if self._entity_browser is None:
            return
        if not self._selected_gp:
            # 초기 상태 — entity_browser는 빈 상태 유지
            return
        try:
            with appdb.connect(self.db_path) as c:
                row = c.execute(
                    "SELECT entity_id, name_ko, name_en, generation, clan "
                    "  FROM sys_genealogy_person WHERE gp_id=?",
                    (self._selected_gp,)).fetchone()
        except Exception as e:
            print(f'[geneal entity lookup] {e}')
            return
        if not row:
            return
        eid, ko, en, gen, clan = row
        if eid:
            try:
                self._show_entity_browser()
                self._entity_browser.load_entity(eid)
            except Exception as e:
                print(f'[entity_browser load] {e}')
        else:
            # 그룹 A 인물 — 엔티티 미등록. 슬라이딩 패널 안 띄움 (이미 열려 있으면 그대로).
            pass

    def _show_geneal_placeholder(self, ko, en, gen, clan):
        """엔티티 미등록 인물 클릭 시 작은 안내 카드 (EntityBrowser 위에 잠깐).
        현재는 EntityBrowser의 center/right 영역을 그대로 두고 — 사용자가
        '이 인물은 가계도 정보로 충분'으로 인식할 수 있도록 변경 없음.
        향후 별도 안내 박스 필요 시 여기서 처리."""
        # MVP: EntityBrowser 갱신 없음 (이전 선택 인물 정보 유지) — 사용자 인지 가능
        # 또는 EntityBrowser 영역을 비우려면 load_entity(None) 같은 API 필요
        pass

    def _refresh_info_panel(self):
        # [2026-06-04] 메시아 가계도: EntityBrowserPanel(compact)로 분기
        if self._entity_browser is not None:
            self._refresh_entity_browser()
            return
        # 제자 가계도: 기존 _info_panel 로직
        if self._info_panel is None:
            return
        for w in self._info_basic.winfo_children():
            w.destroy()
        self._peri_list.delete(0, 'end')
        self._info_notes.config(text='')

        if not self._selected_gp:
            self._info_title.config(text=i18n.t('GC_PERSONSEL','인물 선택'))
            tk.Label(self._info_basic,
                      text=i18n.t('GC_HELP', '[조작법]\n• 노드 클릭: 정보 표시\n• 노드 더블클릭: 엔티티 정보\n• 빈 영역 드래그: 화면 이동\n• 마우스 휠: 세로 / Shift+휠: 가로\n\n(위치는 고정 — 편집 불가)'),
                      bg='#FAFAFA', fg='#666',
                      font=('Malgun Gothic', 9), justify='left',
                      anchor='w').pack(pady=10, fill='x')
            return

        p = next((p for p in self._persons if p[0] == self._selected_gp), None)
        if not p:
            return
        gp_id, name, name_en, gender, gen, clan, _is_m, mt, lk, ent_id = p[:10]

        with appdb.connect(self.db_path) as c:
            row = c.execute(
                "SELECT name_he, is_in_bible, bible_ref, notes "
                "  FROM sys_genealogy_person WHERE gp_id=?",
                (gp_id,)).fetchone()
        name_he, in_bible, ref, notes = row or (None, 1, None, None)

        self._info_title.config(text=f'{name}  ({name_en or "-"})')

        rows = [
            ('히브리어', name_he or '-'),
            ('성별', {'M': '남', 'F': '여'}.get(gender, '-')),
            ('세대', f'{gen} (아담=0)'),
            ('가문/지파', clan or '-'),
            ('마1 라인', '✓' if mt else '-'),
            ('눅3 라인', '✓' if lk else '-'),
            ('성경 첫 등장', ref or '-'),
        ]
        for k, v in rows:
            r = tk.Frame(self._info_basic, bg='#FAFAFA')
            r.pack(fill='x', pady=1)
            tk.Label(r, text=k, width=10, anchor='w', bg='#FAFAFA',
                      font=('Malgun Gothic', 9, 'bold'),
                      fg='#566573').pack(side='left')
            tk.Label(r, text=v, anchor='w', bg='#FAFAFA',
                      font=('Malgun Gothic', 9)).pack(side='left', fill='x', expand=True)

        _slang = (self.lang_provider() or 'KO').upper()
        with appdb.connect(self.db_path) as c:
            spouse_rows = c.execute(
                "SELECT p.name_ko, p.name_en, r.rel_type, r.sequence, r.spouse_clan "
                "  FROM sys_genealogy_relation r "
                "  JOIN sys_genealogy_person p ON p.gp_id=r.to_id "
                " WHERE r.from_id=? AND r.rel_type IN ('SPOUSE','CONCUBINE','INFORMAL') "
                "   AND r.record_status='LIVE' "
                " ORDER BY r.sequence", (gp_id,)).fetchall()
            inbound_spouse = c.execute(
                "SELECT p.name_ko, p.name_en, r.rel_type, r.sequence, r.spouse_clan "
                "  FROM sys_genealogy_relation r "
                "  JOIN sys_genealogy_person p ON p.gp_id=r.from_id "
                " WHERE r.to_id=? AND r.rel_type IN ('SPOUSE','CONCUBINE','INFORMAL') "
                "   AND r.record_status='LIVE' "
                " ORDER BY r.sequence", (gp_id,)).fetchall()
        if spouse_rows or inbound_spouse:
            tk.Label(self._info_basic, text=i18n.t('GC_MARRIAGE','혼인 관계:'), anchor='w', bg='#FAFAFA',
                      font=('Malgun Gothic', 9, 'bold'),
                      fg='#566573').pack(fill='x', pady=(8, 1))
            for name2_ko, name2_en, rt, seq, sclan in spouse_rows + inbound_spouse:
                name2 = name2_ko if _slang == 'KO' else (name2_en or name2_ko)
                rt_disp = {'SPOUSE': '배우자', 'CONCUBINE': '첩',
                            'INFORMAL': '비혼'}.get(rt, rt)
                txt = f'  • {name2} ({rt_disp}'
                if seq and seq > 1:
                    txt += f', {seq}번째'
                txt += ')'
                if sclan:
                    txt += f' — {sclan}'
                tk.Label(self._info_basic, text=txt, anchor='w', bg='#FAFAFA',
                          font=('Malgun Gothic', 8),
                          wraplength=260, justify='left').pack(fill='x')

        if ent_id:
            with appdb.connect(self.db_path) as c:
                lang = self.lang_provider() or 'KO'
                peri_rows = c.execute(
                    "SELECT ep.target_id, "
                    "       COALESCE((SELECT t.contents FROM sys_text_asset t "
                    "                  WHERE t.clicked_id=ep.pericope_id "
                    "                    AND t.text_type='PERI_TITLE' "
                    "                    AND UPPER(t.lang_code)=UPPER(?) LIMIT 1), "
                    "                (SELECT t.contents FROM sys_text_asset t "
                    "                  WHERE t.clicked_id=ep.target_id "
                    "                    AND t.text_type='PERI_TITLE' "
                    "                    AND UPPER(t.lang_code)='EN' LIMIT 1), "
                    "                p.peri_code) AS title, "
                    "       ep.milestone_type, ep.rel_code "
                    # ★ 2026-08-24 통합 표(`ENTI_PERI`)
                    "  FROM sys_link_asset ep "
                    "  JOIN sys_pericope_asset p ON p.pericope_id=ep.target_id "
                    " WHERE ep.link_type='ENTI_PERI' AND ep.clicked_id=? "
                    "   AND COALESCE(ep.record_status,'LIVE')='LIVE' "
                    " ORDER BY (ep.milestone_type IS NOT NULL) DESC, "
                    "          ep.importance DESC LIMIT 30",
                    (lang, ent_id)).fetchall()
            if peri_rows:
                for pid, title, mtype, role in peri_rows:
                    marker = '★ ' if mtype else '  '
                    self._peri_list.insert('end', f'{marker}{title}')
            else:
                self._peri_list.insert('end', i18n.t('GC_NO_LINKDATA', '  연결 데이터 없음'))
        else:
            self._peri_list.insert('end', i18n.t('GC_NO_LINKDATA2', '  연결 데이터 없음 (entity 미연결)'))

        if notes:
            self._info_notes.config(text=notes)
        else:
            self._info_notes.config(text='-')

    # ───────── 외부 호환 ─────────

    def highlight(self, entity_id):
        if not entity_id:
            return
        for p in self._persons:
            if p[9] == entity_id:
                self._selected_gp = p[0]
                self._focus_gp(p[0])
                self._refresh_info_panel()
                self._redraw()
                return
