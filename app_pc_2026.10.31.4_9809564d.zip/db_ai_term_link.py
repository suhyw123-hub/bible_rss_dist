# -*- coding: utf-8 -*-
"""설교 영상 ↔ 주요용어 연결을 AI 가 심사한다 (2026-10-08 · docs/1.txt 56 후속 · 사용자 「용어연결을 ai 를
통해서 시도하고 정확도를 올려보자 … 내일 ai 가 연결심사 할수 있도록 최적 프롬프트를 만들어보자」).

  python db_ai_term_link.py --selftest
  python db_ai_term_link.py --plan                규칙이 걷을 몫 · AI 가 볼 몫 · 하루 한도로 며칠
  python db_ai_term_link.py --sample N            정답 표본 후보를 _term_eval_todo.txt 로(사람이 판정)
  python db_ai_term_link.py --label <파일>        판정 파일(줄마다 「연결번호 K|D 메모」)을 정답 표에 담는다
  python db_ai_term_link.py --fulldesc            볼 영상의 설명문 전문(50편당 1 unit · 배포 표 불변)
  python db_ai_term_link.py --eval                정답 표본만 AI 에 보낸다(먼저 이것으로 정확도를 잰다)
  python db_ai_term_link.py --run [N]             검토 대기 연결을 N 편 분량 보낸다 — 한도(429)에서 멈춘다 · 멱등
  python db_ai_term_link.py --report              정답 대비 정확도 · 갈래별 판정 분포(_ai_term_report.txt)

★ 무엇을 묻나 — 「이 낱말이 설명문에 있나」가 아니라 **「이 설교가 그 용어를 다루는가」**. 낱말 맞추기는 규칙이
  이미 했고, 그 규칙이 틀리는 자리(다른 뜻 · 책 이름 · 주소 · 해시태그 · 지나가는 언급)가 AI 의 몫이다.
★ 닫힌 물음이다 — 후보 목록 안에서 KEEP(주제)/PASSAGE(본문 등장)/DROP 만 고른다. 이름을 지어내는 찬양 심사와 달리 AI 가 잘하는 꼴이다.
★ 한 번에 영상 여럿(`BATCH`)을 묶어 하루 한도(약 500회)를 넓게 쓴다.
⚠ 연결 표(`sys_link_asset`)는 **이 도구가 바꾸지 않는다** — 판정만 LOCAL 표에 담는다. 반영은 정확도를 본 뒤 따로.
⚠ 이름 없는 원어 낱말 항목(`W_G…` · KO 이름 0)은 AI 에 안 보낸다 — 영어 뜻풀이(this·what)에 걸린 쓰레기다.
"""
import json
import os
import re
import sys
import time

import appdb
import db_ai_worship_test as AT

APP = os.path.dirname(os.path.abspath(__file__))
MODEL = 'gemini-3.1-flash-lite'
T_JUDGE = 'temp_ai_term_judge'
T_EVAL = 'temp_ai_term_eval'
BATCH = 8            # 한 요청에 영상 몇 편
DESC_MAX = 1500      # 설명문 앞부분 몇 자
SNIP = 110           # 낱말 앞뒤 몇 자
DAILY = 480          # 하루 요청 어림(실측 약 500)
#: 판정 세 갈래(2026-10-08 사용자 확정 1.C) — 주제 · 본문 등장 · 뗌
VERDICTS = ('KEEP', 'PASSAGE', 'DROP')

PROMPT = '''너는 기독교 설교 영상에 성경 「주요용어」(인물·장소·교리·사물 등)를 붙이는 일을 검수한다.
기계가 설명문에서 낱말을 찾아 후보를 붙였다. 많이 틀린다. 영상은 보지 않았다 — 제목·채널·설명문만 보고 판단한다.

[물음] 후보마다 셋 가운데 하나로 판정한다.
- KEEP(주제) — 설교의 주제·제목·대지가 그 인물·장소·교리를 다룬다. 보기: 사도행전 16장 설교의 「실라」,
  민수기 1장 설교 목차의 「레위인」, 느헤미야 8장 설교의 「에스라」, 그 족속을 소개하는 영상의 「여부스 족속」,
  기드온이 바알 제단을 허는 사사기 6:25-40 설교의 「바알」.
- PASSAGE(본문 등장) — 그 설교가 읽는 **성경 본문 구절 안에** 그 인물·장소·사물이 실제로 나오지만 설교의 주제는
  아니다. 보기: 세례 요한의 회개를 다루는 마태복음 3:1-12 설교의 「사두개인」(3:7), 사사기 10장 설교의 「바알」(10:6),
  다윗 언약을 다루는 역대상 17장 설교의 「언약궤」(17:1). kind 는 PASSAGE.
  ⚠ 설교의 본문 구절이 아닌 곳(다른 설교 홍보·배경 설명·해시태그·키워드 나열)에만 나오면 PASSAGE 가 아니라 DROP.
- DROP — 다음은 모두 DROP 이다.
  · WRONG_SENSE 다른 뜻·다른 사람: 「Basil of Caesarea」의 Caesarea, 한국어 조사 「~에서」를 인물 「에서」로,
    「만나다」의 「만나」, 「아이」(어린이)를 성 「아이」로.
  · BOOKNAME 성경 책 이름일 뿐: 「마태복음 20:28」의 마태, 「Romans 5」를 로마(나라)로.
  · NOISE 주소·해시태그·구독 안내·채널 소개·후원 문구 안의 낱말: 「twitter.com/Paulnison」, 「#Faith」.
  · MENTION 지나가는 언급: 기도 제목·찬양 목록·다른 설교 홍보에 한 번 나올 뿐 이 설교가 다루지 않는다.
  · GENERIC 거의 모든 설교에 해당하는 넓은 낱말(예수·하나님·믿음·은혜)인데 이 설교가 특별히 그것을 주제로
    삼지 않는다. 제목이나 대지가 그 낱말을 주제로 내세우면 KEEP 이다.
- 판단할 근거가 없으면(설명문에 그 낱말이 안 보이고 제목으로도 알 수 없음) DROP · kind NOEVIDENCE.
- 확실하지 않으면 한 단계 낮춘다(KEEP 이 애매하면 PASSAGE, PASSAGE 가 애매하면 DROP). KEEP 은 사용자 화면에
  「이 설교가 다루는 용어」로 먼저 보이고 PASSAGE 는 「본문에 나오는 용어」로 뒤에 보인다.

[출력] JSON 만. 후보마다 한 줄. why 는 짧게(무엇을 보고 그렇게 봤나).
{{"items":[{{"id":연결번호,"v":"KEEP|PASSAGE|DROP","kind":"THEME|PASSAGE|WRONG_SENSE|BOOKNAME|NOISE|MENTION|GENERIC|NOEVIDENCE","why":""}}]}}

{videos}'''


# ── 표 ─────────────────────────────────────────────────────────────────────
def ensure(conn):
    AT.ensure(conn)
    conn.execute('CREATE TABLE IF NOT EXISTS %s(link_id INTEGER, model TEXT, media_id INTEGER,'
                 ' v TEXT, kind TEXT, why TEXT, at TEXT, PRIMARY KEY(link_id, model))' % T_JUDGE)
    conn.execute('CREATE TABLE IF NOT EXISTS %s(link_id INTEGER PRIMARY KEY, label TEXT, note TEXT,'
                 ' at TEXT)' % T_EVAL)
    conn.commit()


# ── 후보 ───────────────────────────────────────────────────────────────────
_BASE = ("FROM sys_link_asset l JOIN sys_media_asset m ON m.media_id=l.clicked_id"
         " WHERE m.media_type='SERMON' AND COALESCE(m.record_status,'LIVE')='LIVE'"
         "   AND l.link_type='MEDI_ENTI' AND l.record_status='PEND'")
_NAMED = (" AND EXISTS(SELECT 1 FROM sys_text_asset t WHERE t.clicked_id=l.target_id"
          " AND t.text_type='ENTITY_NAME' AND t.lang_code='KO')")


def plan(conn):
    tot = conn.execute('SELECT COUNT(*), COUNT(DISTINCT l.clicked_id) ' + _BASE).fetchone()
    named = conn.execute('SELECT COUNT(*), COUNT(DISTINCT l.clicked_id) ' + _BASE + _NAMED).fetchone()
    return {'links': tot[0], 'videos': tot[1], 'nameless': tot[0] - named[0],
            'ai_links': named[0], 'ai_videos': named[1],
            'requests': -(-named[1] // BATCH), 'days': -(-named[1] // (BATCH * DAILY))}


def names(conn, eid):
    out = {}
    for lg, nm in conn.execute("SELECT lang_code, contents FROM sys_text_asset WHERE clicked_id=?"
                               " AND text_type='ENTITY_NAME' AND lang_code IN ('KO','EN')", (eid,)):
        out[lg] = (nm or '').strip()
    return out


def snippets(desc, word, n=2):
    """설명문 안 그 낱말 둘레 — 없으면 []. 대소문자를 안 가린다."""
    if not desc or not word:
        return []
    out = []
    for mt in re.finditer(re.escape(word), desc, re.I):
        a, b = max(0, mt.start() - SNIP), min(len(desc), mt.end() + SNIP)
        out.append(('…' if a else '') + desc[a:b].replace('\n', ' ') + ('…' if b < len(desc) else ''))
        if len(out) >= n:
            break
    return out


def video_block(conn, mid, links):
    """한 영상 덩이 — 제목·채널·설명문 앞부분·후보(번호·이름·갈래·걸린 낱말·그 둘레)."""
    ti = (conn.execute('SELECT title FROM sys_media_asset WHERE media_id=?', (mid,)).fetchone() or [''])[0]
    chan = AT.stored_desc(conn, mid)[1]
    desc, _full = AT.best_desc(conn, mid)
    lines = ['=== 영상 %d ===' % mid, '[제목] %s' % (ti or ''), '[채널] %s' % chan,
             '[설명문 앞부분] %s' % ((desc or '(없음)')[:DESC_MAX].replace('\n', ' / '))]
    lines.append('[후보]')
    for lid, eid, et, src in links:
        nm = names(conn, eid)
        word = (src or '')[5:] if (src or '').startswith('DESC:') else ''
        sn = snippets(desc, word) if word else []
        lines.append('- id %d · %s / %s · %s · 걸린 낱말 「%s」%s' % (
            lid, nm.get('KO', ''), nm.get('EN', ''), et, word or '(기록 없음)',
            (' · 둘레: ' + ' ‖ '.join(sn)) if sn else ' · 둘레: (설명문 앞부분에 안 보임)'))
    return '\n'.join(lines)


def _links_of(conn, mids):
    out = {}
    if not mids:
        return out
    q = ('SELECT l.clicked_id, l.sys_link_id, l.target_id, e.entity_type, l.source '
         + _BASE.replace('WHERE', 'JOIN sys_entity_master e ON e.entity_id=l.target_id WHERE') + _NAMED
         + ' AND l.clicked_id IN (%s) ORDER BY l.clicked_id, l.sys_link_id' % ','.join('?' * len(mids)))
    for mid, lid, eid, et, src in conn.execute(q, list(mids)):
        out.setdefault(mid, []).append((lid, eid, et, src))
    return out


def todo_videos(conn, limit, only_links=None):
    done = set(r[0] for r in conn.execute('SELECT link_id FROM %s WHERE model=?' % T_JUDGE, (MODEL,)))
    if only_links is not None:
        q = ('SELECT DISTINCT l.clicked_id ' + _BASE + _NAMED
             + ' AND l.sys_link_id IN (%s)' % ','.join('?' * len(only_links)))
        mids = [r[0] for r in conn.execute(q, list(only_links))]
    else:
        mids = [r[0] for r in conn.execute('SELECT DISTINCT l.clicked_id ' + _BASE + _NAMED
                                           + ' ORDER BY l.clicked_id')]
    out = []
    for mid in mids:
        links = _links_of(conn, [mid]).get(mid, [])
        if only_links is not None:
            links = [x for x in links if x[0] in only_links]
        links = [x for x in links if x[0] not in done]
        if links:
            out.append((mid, links))
        if len(out) >= limit:
            break
    return out


# ── 보내기 ─────────────────────────────────────────────────────────────────
def parse(txt):
    d = AT.parse(txt)
    items = (d or {}).get('items') if isinstance(d, dict) else None
    out = {}
    for x in items or []:
        try:
            lid = int(x.get('id'))
        except Exception:
            continue
        v = str(x.get('v', '')).upper()
        if v not in VERDICTS:
            continue
        out[lid] = (v, str(x.get('kind', '')).upper(), str(x.get('why', ''))[:300])
    return out


def run(conn, n_videos=10 ** 6, only_links=None, pace=4.5, on_log=print):
    ensure(conn)
    key, _m = AT.user_key(conn)
    if not key:
        return {'sent': 0, 'why': 'Gemini 키가 없다'}
    work = todo_videos(conn, n_videos, only_links)
    sent = got = 0
    why = ''
    for i in range(0, len(work), BATCH):
        chunk = work[i:i + BATCH]
        body = '\n\n'.join(video_block(conn, mid, links) for mid, links in chunk)
        res = AT.ask(key, MODEL, PROMPT.format(videos=body), maxout=4000)
        sent += 1
        want = {lid: mid for mid, links in chunk for lid, *_ in links}
        if not res['ok']:
            on_log('  실패 %s' % res['why'][:100])
            if res['code'] in (429, 503):
                why = res['why']
                break
            continue
        p = parse(res['text'])
        for lid, mid in want.items():
            if lid in p:
                v, k, w = p[lid]
                conn.execute('INSERT OR REPLACE INTO %s VALUES(?,?,?,?,?,?,datetime("now"))' % T_JUDGE,
                             (lid, MODEL, mid, v, k, w))
                got += 1
        conn.commit()
        on_log('  요청 %d · 영상 %d · 판정 %d/%d · %d/%d토큰' % (sent, len(chunk), len(p), len(want),
                                                       res['tok'], res['out']))
        time.sleep(pace)
    return {'sent': sent, 'got': got, 'why': why}


# ── Claude 로 판정 — Gemini 와 같은 프롬프트(견줌용) ──────────────────────
CLAUDE_MODEL = 'claude-sonnet-5-5'
CLAUDE_SCHEMA = {'type': 'object', 'properties': {'items': {'type': 'array', 'items': {
    'type': 'object', 'properties': {
        'id': {'type': 'integer'}, 'v': {'type': 'string', 'enum': list(VERDICTS)},
        'kind': {'type': 'string'}, 'why': {'type': 'string'}},
    'required': ['id', 'v', 'kind', 'why']}}}, 'required': ['items']}


def run_claude(conn, n_videos=10 ** 6, only_links=None, on_log=print, runner=None):
    """같은 프롬프트를 Claude 에 — 도구 없이(재료는 영상 덩이에 다 들어 있다)."""
    import claude_run
    ensure(conn)
    done = set(r[0] for r in conn.execute('SELECT link_id FROM %s WHERE model=?' % T_JUDGE, (CLAUDE_MODEL,)))
    work = [(m, [x for x in ls if x[0] not in done]) for m, ls in todo_videos(conn, n_videos, only_links)]
    work = [(m, ls) for m, ls in work if ls]
    sent = got = 0
    cost = 0.0
    for i in range(0, len(work), BATCH):
        chunk = work[i:i + BATCH]
        body = '\n\n'.join(video_block(conn, mid, links) for mid, links in chunk)
        res = claude_run.run('TERM_JUDGE', PROMPT.format(videos=body), CLAUDE_SCHEMA,
                             model=CLAUDE_MODEL, budget='1.00', timeout=400, runner=runner)
        sent += 1
        cost += res.get('cost') or 0
        if not res.get('ok'):
            on_log('  실패 %s' % res.get('why', '')[:100])
            continue
        want = {lid: mid for mid, links in chunk for lid, *_ in links}
        n = 0
        for x in (res['data'].get('items') or []):
            try:
                lid = int(x.get('id'))
            except Exception:
                continue
            if lid in want and x.get('v') in VERDICTS:
                conn.execute('INSERT OR REPLACE INTO %s VALUES(?,?,?,?,?,?,datetime("now"))' % T_JUDGE,
                             (lid, CLAUDE_MODEL, want[lid], x['v'], str(x.get('kind', '')).upper(),
                              str(x.get('why', ''))[:300]))
                n += 1
        conn.commit()
        got += n
        on_log('  요청 %d · 영상 %d · 판정 %d/%d · %s초 · $%.3f' % (sent, len(chunk), n, len(want),
                                                          res.get('sec'), res.get('cost') or 0))
    return {'sent': sent, 'got': got, 'cost': round(cost, 3)}


# ── 정답 표본 ─────────────────────────────────────────────────────────────
def sample(conn, n, path):
    """정답 표본 후보 — 갈래(인물·장소·교리·용어 …)를 고르게 섞는다."""
    import random
    random.seed(20261008)
    have = set(r[0] for r in conn.execute('SELECT link_id FROM %s' % T_EVAL))
    rows = conn.execute('SELECT l.sys_link_id, l.clicked_id, e.entity_type ' + _BASE.replace(
        'WHERE', 'JOIN sys_entity_master e ON e.entity_id=l.target_id WHERE') + _NAMED).fetchall()
    by = {}
    for lid, mid, et in rows:
        if lid not in have:
            by.setdefault(et, []).append((lid, mid))
    pick = []
    while len(pick) < n and any(by.values()):
        for et in sorted(by):
            if by[et] and len(pick) < n:
                pick.append(by[et].pop(random.randrange(len(by[et]))))
    with open(path, 'w', encoding='utf-8') as f:
        for lid, mid in pick:
            links = [x for x in _links_of(conn, [mid]).get(mid, []) if x[0] == lid]
            f.write(video_block(conn, mid, links) + '\n판정: %d ?\n\n' % lid)
    return len(pick)


def label(conn, path):
    ensure(conn)
    n = 0
    for ln in open(path, encoding='utf-8'):
        m = re.match(r'\s*(\d+)\s+([KPD])\b\s*(.*)$', ln)
        if not m:
            continue
        conn.execute('INSERT OR REPLACE INTO %s VALUES(?,?,?,datetime("now"))' % T_EVAL,
                     (int(m.group(1)), {'K': 'KEEP', 'P': 'PASSAGE', 'D': 'DROP'}[m.group(2)], m.group(3).strip()))
        n += 1
    conn.commit()
    return n


def _metrics(ev, jd):
    """세 갈래 정확도 — jd 값은 판정 글자(KEEP/PASSAGE/DROP)."""
    both = [l for l in ev if l in jd]
    agree = sum(1 for l in both if ev[l] == jd[l])

    def pr(pos):
        tp = sum(1 for l in both if ev[l] in pos and jd[l] in pos)
        fp = sum(1 for l in both if ev[l] not in pos and jd[l] in pos)
        fn = sum(1 for l in both if ev[l] in pos and jd[l] not in pos)
        return tp / max(1, tp + fp), tp / max(1, tp + fn)
    tp_, tr_ = pr(('KEEP',))
    lp_, lr_ = pr(('KEEP', 'PASSAGE'))
    return {'n': len(both), 'agree': agree, 'prec': tp_, 'recall': tr_, 'link_prec': lp_, 'link_recall': lr_}


def accuracy(conn, model):
    """정답 대비 — {n, agree(세 갈래 일치), prec·recall(주제), link_prec·link_recall(주제+본문 등장)}."""
    ensure(conn)
    ev = dict(conn.execute('SELECT link_id, label FROM %s' % T_EVAL))
    jd = dict(conn.execute('SELECT link_id, v FROM %s WHERE model=?' % T_JUDGE, (model,)))
    return _metrics(ev, jd)


def report(conn, path=None, models=None):
    ensure(conn)
    L = []
    for mdl in (models or [MODEL, 'claude-sonnet-5-5']):
        L += _report_one(conn, mdl)
        L.append('')
    txt = '\n'.join(L)
    with open(path or os.path.join(APP, '_ai_term_report.txt'), 'w', encoding='utf-8') as f:
        f.write(txt)
    return txt


def _report_one(conn, MODEL):
    L = []
    w = L.append
    ev = dict(conn.execute('SELECT link_id, label FROM %s' % T_EVAL))
    jd = {r[0]: r[1:] for r in conn.execute('SELECT link_id, v, kind, why FROM %s WHERE model=?'
                                           % T_JUDGE, (MODEL,))}
    both = [l for l in ev if l in jd]
    w('설교 용어 연결 AI 심사 — 모델 %s' % MODEL)
    w('정답 표본 %d · 그중 AI 판정 받은 것 %d' % (len(ev), len(both)))
    if both:
        m = _metrics(ev, {l: jd[l][0] for l in jd})
        w('세 갈래 일치 %d/%d (%.0f%%)' % (m['agree'], m['n'], 100.0 * m['agree'] / m['n']))
        w('주제(KEEP) — 정밀도 %.0f%% · 찾은 비율 %.0f%%' % (100 * m['prec'], 100 * m['recall']))
        w('연결 전체(주제+본문 등장) — 정밀도 %.0f%% · 찾은 비율 %.0f%%'
          % (100 * m['link_prec'], 100 * m['link_recall']))
        import collections
        cm = collections.Counter((ev[l], jd[l][0]) for l in both)
        w('정답→AI 표: ' + ' · '.join('%s→%s %d' % (a_, b_, n_) for (a_, b_), n_ in sorted(cm.items())))
        w('')
        w('── 어긋난 것 ──')
        for l in both:
            if ev[l] != jd[l][0]:
                w('  %d 정답 %s · AI %s %s · %s' % (l, ev[l], jd[l][0], jd[l][1], jd[l][2]))
    import collections
    k = collections.Counter((v, kd) for v, kd, _ in jd.values())
    w('전체 판정 %d건 — ' % len(jd) + ' · '.join('%s/%s %d' % (a, b, n) for (a, b), n in k.most_common()))
    return L


# ── 자가검증 ──────────────────────────────────────────────────────────────
def selftest():
    n = [0, 0]

    def ck(c, m):
        n[0] += 1
        n[1] += bool(c)
        if not c:
            print('  FAIL', m)
    ck(snippets('From Paul and Silas singing', 'silas') and 'Silas' in snippets('x Paul and Silas y', 'Silas')[0],
       '둘레를 대소문자 없이 찾는다')
    ck(snippets('abc', 'zzz') == [], '없으면 빈 목록')
    ck(len(snippets('a x a x a x', 'x', n=2)) == 2, '둘까지만')
    p = parse('```json\n{"items":[{"id":5,"v":"keep","kind":"THEME","why":"w"},'
              '{"id":"6","v":"DROP","kind":"NOISE"},{"id":7,"v":"MAYBE"}]}\n```')
    ck(p.get(5, ('',))[0] == 'KEEP' and p.get(6, ('',))[0] == 'DROP', '판정을 읽는다')
    ck(7 not in p, '모르는 판정은 버린다')
    ck(parse('엉망') == {}, '못 읽으면 빈 판정')
    ck('{videos}' in PROMPT and '{{"items"' in PROMPT, '프롬프트 자리표')
    ck(PROMPT.format(videos='X').count('X') >= 1, '프롬프트가 채워진다')
    conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
    try:
        ensure(conn)
        pl = plan(conn)
        ck(pl['ai_links'] + pl['nameless'] == pl['links'], '걷을 몫 + AI 몫 = 전체')
        tv = todo_videos(conn, 2)
        ck(len(tv) <= 2, '상한')
        if tv:
            blk = video_block(conn, tv[0][0], tv[0][1])
            ck(('id %d' % tv[0][1][0][0]) in blk and '[제목]' in blk, '영상 덩이에 연결번호·제목')
        before = conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE record_status='PEND'").fetchone()[0]
        ck(before == conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE record_status='PEND'"
                                  ).fetchone()[0], '연결 표 불변')
    finally:
        conn.close()
    print('db_ai_term_link selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
    try:
        ensure(conn)
        if '--plan' in argv:
            print(json.dumps(plan(conn), ensure_ascii=False))
        elif '--sample' in argv:
            i = argv.index('--sample')
            k = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 60
            p = os.path.join(APP, '_term_eval_todo.txt')
            print('%d건 → %s' % (sample(conn, k, p), p))
        elif '--label' in argv:
            print('정답 %d건 담음' % label(conn, argv[argv.index('--label') + 1]))
        elif '--fulldesc' in argv:
            mids = [m for m, _ in todo_videos(conn, 10 ** 6)]
            have = set(r[0] for r in conn.execute('SELECT media_id FROM %s' % AT.T_DESC))
            print('전문 %d편' % AT.fetch_full(conn, [m for m in mids if m not in have], on_log=AT._log))
        elif '--eval' in argv:
            ev = [r[0] for r in conn.execute('SELECT link_id FROM %s' % T_EVAL)]
            print(run(conn, only_links=set(ev)))
            print(report(conn))
        elif '--claude-eval' in argv:
            ev = [r[0] for r in conn.execute('SELECT link_id FROM %s' % T_EVAL)]
            print(run_claude(conn, only_links=set(ev)))
            print(report(conn))
        elif '--run' in argv:
            i = argv.index('--run')
            k = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 10 ** 6
            print(run(conn, n_videos=k))
        elif '--report' in argv:
            print(report(conn))
        else:
            print(__doc__)
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
