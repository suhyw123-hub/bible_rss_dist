# -*- coding: utf-8 -*-
"""다국어 비교 편집 — 공용 규칙과 (뒤에) 공용 부품.

**2-A 단계 = 자물쇠만**(2026-08-25). 부품 본체는 2-B 에서 이 파일에 붙는다.

★★★ **왜 자물쇠가 먼저인가** — 실측(2026-08-25): 관리자 화면 **일곱 곳**에
  좌/우 비교 편집이 손으로 지어져 있는데 **원문 저장을 막는 코드가 한 줄도 없다.**
  화면에서 「원문」을 고르고 [저장] 을 누르면 그대로 덮인다:
      variant = self._left_variant_var.get()      # ORIGINAL
      UPDATE sys_book_unit_text SET body_text=?   # 원문 행을 덮는다
  **열려 있던 원문 = 도서·설교 6,863편 + 주석 64,238편 = 71,101편**
  (도서는 좌·우 **양쪽**에서 가능했다).
  ⚠ 이것이 §0-1b 가 「저자 위작」이라 부른 자리다 — 바운즈 20장 사고와 같은 계열.

★ **규칙 둘은 서로 다른 것이다**(2026-08-25 사용자 확정).
  | | |
  |---|---|
  | **자리 규칙** | 왼쪽 = 기준(읽기 전용) · 오른쪽 = 고치는 자리 |
  | **잠금 규칙** | `ORIGINAL` 은 **어디에 있든** 못 고친다 |
  둘은 직교한다 — 왼쪽 한국어 · 오른쪽 중국어로 **중국어를 고치는 것은 된다.**
  왼쪽을 원문으로 고정하지 않는다.
  ⚠ **자리 규칙은 2-C(부품 교체)에서** 건다. 지금 손으로 지은 화면의 왼쪽
    [저장] 을 떼면 그 화면의 흐름이 바뀌는데, 위험한 것은 잠금 쪽이다.

⚠ **적재 도구는 막지 않는다.** 원문을 바꿀 일이 생기면 스크립트로 한다
  (백업·게이트·`--restore` 가 붙는다). 화면에서 고치면 사전 자료집처럼
  **기록조차 안 남는 표**가 있다.

⚠ **유닛을 새로 만들며 원문을 함께 넣는 것은 막지 않는다** — 그것은 덮어쓰기가
  아니라 처음 넣는 것이다(`panel_book_manager._add_unit`).

⚠ **「티어」는 잠그지 않는다.** `sys_text_asset` 의 `text_variant` 는
  `LAY`/`EXPERT` 로 **둘 다 우리 글**이다. 같은 칸 이름인데 뜻이 다르다 —
  도서·주석은 **판본**, 설명문은 **독자 수준**.
"""
import sys

# 어디에 있든 못 고치는 변형. **남의 글**이라 우리가 손댈 수 없다.
LOCKED_VARIANTS = ('ORIGINAL',)

# 화면에 내는 말 — 왜 막혔는지 알려 준다(조용히 아무 일도 안 하지 않는다).
LOCK_TITLE = '원문은 고칠 수 없습니다'
#: 대상이 아직 안 골라졌을 때 — **조용히 아무 일도 안 하지 않는다**(§0-1).
NO_TARGET = '먼저 위 목록에서 대상을 선택하세요.'

LOCK_MSG = ('「원문」은 저자가 쓴 글이라 고치거나 지울 수 없습니다.\n'
            '번역·현대어·요약을 선택하면 편집할 수 있습니다.\n\n'
            '원문 자체를 바로잡아야 한다면 적재 도구로 하십시오 '
            '(백업과 되돌리기가 함께 갑니다).')


def locked(variant):
    """이 변형이 잠긴 것인가. `None`·빈값은 잠기지 않는다(변형 축이 없는 자산)."""
    return (variant or '').strip().upper() in LOCKED_VARIANTS


def guard(variant, parent=None, action='save'):
    """저장·삭제 앞에 부른다. **막혔으면 True** 를 돌려준다(알린 뒤).

    쓰는 법 —
        if lang_compare.guard(variant, self):
            return
    """
    if not locked(variant):
        return False
    # ⚠⚠ **창이 없으면 창을 띄우지 않는다.** `messagebox` 는 root 가 없으면
    #   제가 하나 만들어 **모달로 영영 기다린다** — headless selftest 가
    #   그 자리에서 멈춘다(실제로 멈춰서 프로세스를 죽였다).
    #   §19-1 이 `journey_builder`·`prayer_builder` 로 두 번 겪은 함정이다.
    try:
        import tkinter as tk
        if getattr(tk, '_default_root', None) is None and parent is None:
            raise RuntimeError('no tk root')
        from tkinter import messagebox
        messagebox.showwarning(LOCK_TITLE, LOCK_MSG, parent=parent)
    except Exception:
        print('[lang_compare] %s 막힘 — %s' % (variant, action))
    return True


# ══════════════════════════════════════════════════════════════════
#  2-B — 어댑터 넷
#
#  ★ **부품은 저장소를 모른다.** 글이 사는 표가 넷인데 열쇠도 글 칸도 다 다르다:
#      sys_book_unit_text    unit_id      body_text
#      sys_commentary_text   entry_id     body_text
#      sys_ref_text          ref_unit_id  body_text + title
#      sys_text_asset        clicked_id + text_type   contents **또는** title
#    ⇒ 표마다 작은 어댑터를 두고, 부품은 어댑터에게만 말한다.
# ══════════════════════════════════════════════════════════════════

# 변형 목록 — **설계 기준으로 못 박는다. DB 를 묻지 않는다**(§0-3 lang_combo 와 같은
# 정신). 지금 없는 변형도 골라서 새로 쓸 수 있어야 한다.
BOOK_VARIANTS = ('ORIGINAL', 'MODERN_EN', 'TRANSLATED', 'SUMMARY')
# ⚠ 실측(2026-08-25) — 도서 넷 다 씀 / 주석·사전은 ORIGINAL·MODERN_EN 만 쓰고
#   있으나 **번역·요약을 새로 쓸 자리는 있어야** 하므로 같은 넷을 준다.

# `sys_text_asset` 에서 **티어**(LAY/EXPERT)를 쓰는 유형. 실측 셋뿐이다.
# ⚠ 여기 변형은 **판본이 아니라 독자 수준**이라 **잠그지 않는다.**
TIER_TYPES = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER')
TIERS = ('LAY', 'EXPERT')

# `sys_text_asset` 에서 **`title` 칸이 본문**인 유형.
# ⚠ 실측(2026-08-25) — PERI_TITLE 37,355 · PLAN_FOCUS 2,638 · PLAN_QUESTION 823 ·
#   WEEK_TITLE 96. **그런데 섞여 있다**(PLAN_FOCUS 는 contents 쪽도 770행).
#   ⇒ 읽기는 「contents 먼저, 비면 title」, 쓰기는 **그 행이 이미 쓰던 칸**에 한다.
#     이 목록은 **새 행을 만들 때만** 쓴다.
TITLE_TYPES = ('PERI_TITLE', 'PLAN_FOCUS', 'PLAN_QUESTION', 'WEEK_TITLE')


def langs():
    """언어 축 — 화면 언어 목록 그대로(§0-3). DB 를 묻지 않는다."""
    try:
        import lang_combo
        return tuple(code for _v, code in lang_combo.lang_items())
    except Exception:
        return ('EN', 'KO', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT')


class _Base(object):
    """어댑터 공통. `conn_fn` 은 **열 때마다 새 연결**을 주는 함수다."""

    has_title = False

    def __init__(self, conn_fn):
        self._conn_fn = conn_fn

    def ready(self):
        """대상이 정해졌는가 — **아직 아무것도 안 골랐을 때** 쓰기를 막는다.

        ⚠ 목록에서 줄을 고르기 전에도 편집기는 이미 화면에 있다. 그때 열쇠가
          비어 있는데 저장을 받으면 **주인 없는 행**이 생긴다(2026-09-22).
        """
        return True

    def variants(self):
        return ()

    def langs(self):
        return langs()

    def locked(self, variant):
        return locked(variant)

    # 아래 셋은 하위 클래스가 채운다
    def load(self, variant, lang):
        raise NotImplementedError

    def save(self, variant, lang, body, title=None):
        raise NotImplementedError

    def hide(self, variant, lang):
        raise NotImplementedError


class _SimpleText(_Base):
    """`(열쇠, text_variant, lang_code) → body_text` 꼴 표 셋의 공통 부분.

    ⚠⚠ **PK 이름을 박지 않는다 — 스키마에 묻는다.** 2026-08-25 에 실제로 틀렸다:
      `sys_ref_text` 의 PK 를 `ref_text_id` 로 짐작했는데 **`text_id`** 였다.
      §B단계가 이미 같은 것을 겪었다(`sys_text_id` ↔ `user_text_id`).
    ⚠⚠ **그리고 selftest 가 그것을 못 잡았다** — 가짜 표를 손으로 만들면서
      **틀린 이름 그대로 적었기 때문**이다. §0-5 가 경고한 자리다.
      ⇒ 이제 PK 를 스키마에서 읽으므로 가짜 표 이름이 무엇이든 따라온다.
    """

    TBL = KEY = None

    def __init__(self, conn_fn, key_value):
        _Base.__init__(self, conn_fn)
        self.key_value = key_value
        self._pk = None

    def ready(self):
        return bool(self.key_value)

    def variants(self):
        return BOOK_VARIANTS

    def pk(self, c):
        if self._pk is None:
            rows = list(c.execute('PRAGMA table_info(%s)' % self.TBL))
            hit = [r[1] for r in rows if r[5]]
            self._pk = hit[0] if hit else 'rowid'
        return self._pk

    def _row(self, c, variant, lang):
        return c.execute(
            'SELECT %s, body_text%s FROM %s WHERE %s=? AND text_variant=? '
            "AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % (self.pk(c), ', title' if self.has_title else '',
               self.TBL, self.KEY),
            (self.key_value, variant, (lang or '').upper())).fetchone()

    def load(self, variant, lang):
        c = self._conn_fn()
        try:
            r = self._row(c, variant, lang)
        finally:
            c.close()
        if not r:
            return ('', '')
        return ((r[2] or '') if self.has_title else '', r[1] or '')

    def save(self, variant, lang, body, title=None):
        if self.locked(variant):
            raise PermissionError(LOCK_TITLE)
        if not self.ready():
            return                       # 주인 없는 행을 만들지 않는다
        c = self._conn_fn()
        try:
            r = self._row(c, variant, lang)
            if r:
                if self.has_title:
                    c.execute('UPDATE %s SET body_text=?, title=? WHERE %s=?'
                              % (self.TBL, self.pk(c)),
                              (body, title or None, r[0]))
                else:
                    c.execute('UPDATE %s SET body_text=? WHERE %s=?'
                              % (self.TBL, self.pk(c)), (body, r[0]))
            else:
                cols = '%s, text_variant, lang_code, body_text, record_status' % self.KEY
                vals = [self.key_value, variant, (lang or '').upper(), body, 'LIVE']
                if self.has_title:
                    cols += ', title'
                    vals.append(title or None)
                c.execute('INSERT INTO %s (%s) VALUES (%s)'
                          % (self.TBL, cols, ','.join('?' * len(vals))), vals)
            c.commit()
        finally:
            c.close()

    def hide(self, variant, lang):
        if self.locked(variant):
            raise PermissionError(LOCK_TITLE)
        c = self._conn_fn()
        try:
            c.execute("UPDATE %s SET record_status='HIDE' WHERE %s=? "
                      'AND text_variant=? AND UPPER(lang_code)=?'
                      % (self.TBL, self.KEY),
                      (self.key_value, variant, (lang or '').upper()))
            c.commit()
        finally:
            c.close()


class BookUnitAdapter(_SimpleText):
    """도서·설교집 편 본문."""
    TBL, KEY = 'sys_book_unit_text', 'unit_id'


class CommentaryAdapter(_SimpleText):
    """주석 항목 본문."""
    TBL, KEY = 'sys_commentary_text', 'entry_id'


class RefTextAdapter(_SimpleText):
    """사전·교리문답·연구 글. ⚠ **이 표만 `title` 이 있다**(649/649 채워져 있다)."""
    TBL, KEY = 'sys_ref_text', 'ref_unit_id'
    has_title = True


class TextAssetAdapter(_Base):
    """설명문 등 `sys_text_asset` 36유형.

    ⚠⚠ **글이 든 칸이 유형마다 다르다** — 모르면 **빈 칸을 보여 주고 그 위에
      덮어쓴다.** 읽기는 「contents 먼저, 비면 title」(번역 대시보드와 같은 규칙),
      쓰기는 **그 행이 이미 쓰던 칸**에 한다.
    ⚠ 변형은 **티어**(LAY/EXPERT)라 **잠그지 않는다** — 둘 다 우리 글이다.
    """

    def __init__(self, conn_fn, clicked_id, text_type):
        _Base.__init__(self, conn_fn)
        self.clicked_id = clicked_id
        self.text_type = text_type

    def ready(self):
        return bool(self.clicked_id)

    def variants(self):
        return TIERS if self.text_type in TIER_TYPES else ()

    def _row(self, c, variant, lang):
        v = variant or None
        return c.execute(
            'SELECT sys_text_id, contents, title FROM sys_text_asset '
            'WHERE clicked_id=? AND text_type=? AND UPPER(lang_code)=? '
            '  AND (text_variant IS ? OR COALESCE(text_variant,?)=?) '
            "  AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
            (self.clicked_id, self.text_type, (lang or '').upper(),
             v, '', v or '')).fetchone()

    def load(self, variant, lang):
        c = self._conn_fn()
        try:
            r = self._row(c, variant, lang)
        finally:
            c.close()
        if not r:
            return ('', '')
        return ('', (r[1] or r[2] or ''))   # contents 먼저, 비면 title

    def save(self, variant, lang, body, title=None):
        if not self.ready():
            return
        c = self._conn_fn()
        try:
            r = self._row(c, variant, lang)
            if r:
                # ★ **그 행이 이미 쓰던 칸에 쓴다** — 안 그러면 한 행에 글이 둘이 된다
                col = 'title' if (not (r[1] or '').strip()
                                  and (r[2] or '').strip()) else 'contents'
                c.execute('UPDATE sys_text_asset SET %s=? WHERE sys_text_id=?'
                          % col, (body, r[0]))
            else:
                col = 'title' if self.text_type in TITLE_TYPES else 'contents'
                c.execute(
                    'INSERT INTO sys_text_asset '
                    '(clicked_id, text_type, lang_code, text_variant, %s, '
                    " record_status) VALUES (?,?,?,?,?,'LIVE')" % col,
                    (self.clicked_id, self.text_type, (lang or '').upper(),
                     variant or None, body))
            c.commit()
        finally:
            c.close()

    def hide(self, variant, lang):
        c = self._conn_fn()
        try:
            r = self._row(c, variant, lang)
            if r:
                c.execute("UPDATE sys_text_asset SET record_status='HIDE' "
                          'WHERE sys_text_id=?', (r[0],))
                c.commit()
        finally:
            c.close()


# ══════════════════════════════════════════════════════════════════
#  창 부품 — 왼쪽 기준 / 오른쪽 편집
# ══════════════════════════════════════════════════════════════════

def _C(role, fallback):
    """§36 — 색은 역할로. 팔레트에 없으면 폴백."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


class CompareEditor(object):
    """좌/우 비교 편집 — **열 화면이 함께 쓴다.**

    ★ 규칙 둘은 직교한다:
      · **자리** — 왼쪽은 늘 읽기 전용(기준), 오른쪽이 고치는 자리
      · **잠금** — `ORIGINAL` 은 **어디에 있든** 못 고친다
      그래서 왼쪽 한국어 · 오른쪽 중국어로 **중국어를 고치는 것은 된다.**

    ⚠ 변형 축이 없는 자산(사전·렌즈·플랜)에서는 **변형 콤보를 감춘다.**
    ⚠ 제목 칸은 `adapter.has_title` 일 때만 뜬다.
    """

    def __init__(self, parent, adapter, db_path=None, on_saved=None,
                 left=('ORIGINAL', 'EN'), right=('TRANSLATED', 'KO'),
                 title_adapter=None, show_meta=True, text_height=None):
        """`title_adapter` — **제목이 다른 표에 있을 때** 넘긴다.

        ⚠ 실측(2026-08-25): 도서 편 제목은 본문 표(`sys_book_unit_text`)가 아니라
          **`sys_text_asset` 의 `BOOK_UNIT_LABEL`** 에 있다. 본문 어댑터 하나로는
          못 다룬다 — 제목용 어댑터를 따로 받아 **같은 (변형, 언어)** 로 읽고 쓴다.
          ⇒ `title_adapter=TextAssetAdapter(fn, unit_id, 'BOOK_UNIT_LABEL')`
        """
        import tkinter as tk
        from tkinter import ttk
        self.tk, self.ttk = tk, ttk
        self.ad = adapter
        # ⚠ `theme_font.register` 는 경로가 비면 글꼴을 못 건다(경고만 내고 지나간다).
        #   호출부가 안 넘겨도 되게 여기서 찾는다 — `appdb.resolve_db(None)` 은
        #   **None 을 돌려주므로** 그것에 기대지 말 것(실측).
        if not db_path:
            try:
                import appdb
                db_path = appdb.MAIN_DB
            except Exception:
                db_path = None
        self.db_path = db_path
        self.on_saved = on_saved
        self.tad = title_adapter          # 제목이 다른 표에 있을 때
        self.show_meta = show_meta
        #: 글상자 줄 수 — 안 주면 Tk 기본(24줄)이라 좁은 칸에서는 화면을 먹는다.
        self.text_height = text_height
        self._vars = adapter.variants()
        self._langs = adapter.langs()

        self.frame = ttk.Frame(parent)
        pw = ttk.PanedWindow(self.frame, orient='horizontal')
        pw.pack(fill='both', expand=True)

        self._L = self._side(pw, '기준 (좌)', left, editable=False)
        self._R = self._side(pw, '수정 (우)', right, editable=True)
        self.reload()

    # ── 한 쪽 만들기 ────────────────────────────────────────────────
    def _side(self, pw, caption, init, editable):
        tk, ttk = self.tk, self.ttk
        f = ttk.LabelFrame(pw, text=' %s ' % caption)
        pw.add(f, weight=1)
        s = {'editable': editable}

        bar = ttk.Frame(f)
        bar.pack(fill='x', padx=4, pady=(4, 2))

        s['var'] = tk.StringVar(value=init[0] if self._vars else '')
        if self._vars:
            cb = ttk.Combobox(bar, textvariable=s['var'], values=list(self._vars),
                              width=12, state='readonly')
            cb.pack(side='left')
            cb.bind('<<ComboboxSelected>>', lambda _e: self.reload())
        s['lang'] = tk.StringVar(value=init[1])
        cb2 = ttk.Combobox(bar, textvariable=s['lang'], values=list(self._langs),
                           width=6, state='readonly')
        cb2.pack(side='left', padx=(4, 0))
        cb2.bind('<<ComboboxSelected>>', lambda _e: self.reload())

        if editable:
            ttk.Button(bar, text='저장', width=6,
                       command=self._save).pack(side='left', padx=(8, 0))
            ttk.Button(bar, text='지움', width=6,
                       command=self._hide).pack(side='left', padx=(4, 0))
        s['note'] = ttk.Label(bar, text='', foreground=_C('fg_dim', '#7F8C8D'))
        s['note'].pack(side='left', padx=(8, 0))

        if self.ad.has_title or self.tad is not None:
            tf = ttk.Frame(f)
            tf.pack(fill='x', padx=4, pady=(0, 2))
            ttk.Label(tf, text='제목:', width=5, anchor='e').pack(side='left')
            s['title'] = tk.StringVar()
            e = ttk.Entry(tf, textvariable=s['title'])
            e.pack(side='left', fill='x', expand=True, padx=(4, 0))
            if not editable:
                e.config(state='readonly')
            s['title_entry'] = e

        if self.show_meta:
            s['meta'] = ttk.Label(f, text='',
                                  foreground=_C('fg_dim', '#7F8C8D'))
            s['meta'].pack(anchor='w', padx=6)

        wrap = ttk.Frame(f)
        wrap.pack(fill='both', expand=True, padx=4, pady=(0, 4))
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        # ⚠ §36 — 글꼴 이름을 적지 않는다. 색은 역할로.
        kw = {'height': self.text_height} if self.text_height else {}
        txt = tk.Text(wrap, wrap='word', relief='flat',
                      bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'),
                      insertbackground=_C('fg', '#2C3E50'),
                      yscrollcommand=vsb.set, **kw)
        vsb.config(command=txt.yview)
        txt.pack(fill='both', expand=True)
        try:
            import theme_font
            theme_font.register(txt, self.db_path, 'prose')
        except Exception:
            pass
        s['txt'] = txt
        return s

    # ── 상태 ────────────────────────────────────────────────────────
    def _pick(self, s):
        return (s['var'].get() or None), s['lang'].get()

    def _readonly(self, s):
        """왼쪽은 늘 · 오른쪽은 잠긴 변형일 때."""
        v, _ = self._pick(s)
        return (not s['editable']) or self.ad.locked(v)

    def reload(self):
        for s in (self._L, self._R):
            v, lg = self._pick(s)
            title, body = self.ad.load(v, lg)
            if self.tad is not None:
                # ⚠ **제목은 변형 축이 없다 — 언어만 쓴다**(실측 2026-08-25:
                #   BOOK_UNIT_LABEL·PLAN_TITLE·ENTITY_NAME·PLAN_CAT_NAME 전부
                #   `text_variant` 가 NULL). 본문 변형으로 물으면 **늘 빈칸**이다.
                title = self.tad.load(None, lg)[1]
            t = s['txt']
            t.config(state='normal')
            t.delete('1.0', 'end')
            t.insert('1.0', body or '')
            ro = self._readonly(s)
            t.config(state='disabled' if ro else 'normal')
            if 'title' in s:
                s['title'].set(title or '')
                s['title_entry'].config(
                    state='readonly' if ro else 'normal')
            if self.ad.locked(v):
                s['note'].config(text='🔒 원문 — 고칠 수 없습니다',
                                 foreground=_C('danger', '#C0392B'))
            elif not s['editable']:
                s['note'].config(text='기준 — 읽기 전용',
                                 foreground=_C('fg_dim', '#7F8C8D'))
            else:
                s['note'].config(text='', foreground=_C('fg_dim', '#7F8C8D'))
            if 'meta' in s:
                n = len(body or '')
                s['meta'].config(
                    text=('%s · %s · %s자' % (v or '-', lg, format(n, ',')))
                    if n else ('%s · %s · 아직 없습니다' % (v or '-', lg)))

    # ── 저장·지움 ───────────────────────────────────────────────────
    def _save(self):
        s = self._R
        v, lg = self._pick(s)
        if guard(v, self.frame, 'save'):
            return
        if not self.ad.ready():
            from tkinter import messagebox
            messagebox.showinfo('대상 없음', NO_TARGET, parent=self.frame)
            return
        body = s['txt'].get('1.0', 'end-1c').strip()
        if not body:
            from tkinter import messagebox
            messagebox.showwarning('내용 없음',
                                   '저장할 내용이 없습니다. 지우려면 [지움].',
                                   parent=self.frame)
            return
        title = s['title'].get().strip() if 'title' in s else None
        self.ad.save(v, lg, body, title if self.ad.has_title else None)
        if self.tad is not None and title is not None:
            # ⚠ 제목이 다른 표에 있으면 **거기에** 쓴다 — 본문 표에 안 밀어 넣는다.
            #   그리고 **변형 없이 언어만**(위 참조).
            self.tad.save(None, lg, title)
        s['note'].config(text='저장됨', foreground=_C('success', '#27AE60'))
        if self.on_saved:
            self.on_saved(v, lg)

    def _hide(self):
        s = self._R
        v, lg = self._pick(s)
        if guard(v, self.frame, 'delete'):
            return
        from tkinter import messagebox
        if not self.ad.ready():
            messagebox.showinfo('대상 없음', NO_TARGET, parent=self.frame)
            return
        if not messagebox.askyesno('지움 확인',
                                   '%s(%s) 을(를) 지우겠습니까?' % (v or '-', lg),
                                   parent=self.frame):
            return
        self.ad.hide(v, lg)
        self.reload()
        s['note'].config(text='지웠습니다', foreground=_C('fg_dim', '#7F8C8D'))
        if self.on_saved:
            self.on_saved(v, lg)

    def select(self, side='right', variant=None, lang=None):
        """밖에서 좌·우 상태를 넣는다 — **번역 대시보드 점프**가 쓴다.

        ⚠ 그 화면들은 지금 위젯 변수를 **직접** 만지고 있다(`receive_jump`).
          부품으로 바꿀 때 이 문을 쓰면 안쪽을 안 열어도 된다.
        """
        s = self._R if side == 'right' else self._L
        if variant is not None and self._vars:
            s['var'].set(variant)
        if lang is not None:
            s['lang'].set(lang)
        self.reload()

    def set_adapter(self, adapter, title_adapter=None):
        """선택한 대상이 바뀌었을 때 — 콤보는 그대로 두고 내용만 갈아 끼운다."""
        self.ad = adapter
        if title_adapter is not None:
            self.tad = title_adapter
        self.reload()

    def pack(self, **kw):
        self.frame.pack(**kw)
        return self


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    t('ORIGINAL 은 잠긴다', locked('ORIGINAL'))
    t('소문자·공백도 잠긴다', locked('  original '))
    t('MODERN_EN 은 안 잠긴다', not locked('MODERN_EN'))
    t('TRANSLATED 는 안 잠긴다', not locked('TRANSLATED'))
    t('SUMMARY 는 안 잠긴다', not locked('SUMMARY'))
    t('★ 티어는 안 잠긴다 (LAY)', not locked('LAY'))
    t('★ 티어는 안 잠긴다 (EXPERT)', not locked('EXPERT'))
    t('변형 축이 없으면 안 잠긴다 (None)', not locked(None))
    t('변형 축이 없으면 안 잠긴다 (빈값)', not locked(''))

    # guard 는 Tk 없이도 죽지 않아야 한다 (headless selftest)
    t('★ guard 가 막는다', guard('ORIGINAL') is True)
    t('★ guard 가 안 막는다', guard('TRANSLATED') is False)

    # 탐지력 — 목록을 비우면 안 막아야 한다(검사가 실제로 목록을 본다)
    global LOCKED_VARIANTS
    keep = LOCKED_VARIANTS
    LOCKED_VARIANTS = ()
    t('★ 목록을 비우면 안 막는다 (검사가 살아 있다)', not locked('ORIGINAL'))
    LOCKED_VARIANTS = keep
    t('되돌아왔다', locked('ORIGINAL'))

    # ── 어댑터 넷 — 가짜 DB 로 왕복 ────────────────────────────────
    import sqlite3
    db = sqlite3.connect(':memory:')
    db.execute('CREATE TABLE sys_book_unit_text (text_id INTEGER PRIMARY KEY, '
               'unit_id INT, text_variant TEXT, lang_code TEXT, body_text TEXT,'
               ' record_status TEXT)')
    db.execute('CREATE TABLE sys_commentary_text (text_id INTEGER PRIMARY KEY, '
               'entry_id INT, text_variant TEXT, lang_code TEXT, body_text TEXT,'
               ' record_status TEXT)')
    # ⚠ 일부러 실제와 **다른 PK 이름**을 쓴다 — 스키마에 묻는지 증명하려고.
    db.execute('CREATE TABLE sys_ref_text (weird_pk INTEGER PRIMARY KEY, '
               'ref_unit_id INT, text_variant TEXT, lang_code TEXT, '
               'body_text TEXT, title TEXT, record_status TEXT)')
    db.execute('CREATE TABLE sys_text_asset (sys_text_id INTEGER PRIMARY KEY, '
               'clicked_id INT, text_type TEXT, lang_code TEXT, '
               'text_variant TEXT, title TEXT, contents TEXT, '
               'record_status TEXT)')
    db.execute("INSERT INTO sys_book_unit_text VALUES "
               "(1,7,'ORIGINAL','EN','저자의 글','LIVE')")
    # 글이 title 에 든 행 (PERI_TITLE 꼴) · contents 에 든 행 (VERS_DESC 꼴)
    db.execute("INSERT INTO sys_text_asset VALUES "
               "(1,5,'PERI_TITLE','KO',NULL,'제목이 여기','','LIVE')")
    db.execute("INSERT INTO sys_text_asset VALUES "
               "(2,9,'VERS_DESC','KO','LAY','','본문이 여기','LIVE')")
    db.commit()

    class _NoClose(object):          # selftest 용 — close() 를 삼킨다
        def __init__(self, c):
            self._c = c

        def __getattr__(self, n):
            return getattr(self._c, n)

        def close(self):
            pass

    fn = lambda: _NoClose(db)

    bk = BookUnitAdapter(fn, 7)
    t('도서 변형 넷', bk.variants() == BOOK_VARIANTS, bk.variants())
    t('도서 언어 11', len(bk.langs()) == 11, len(bk.langs()))
    t('도서 원문 읽기', bk.load('ORIGINAL', 'EN')[1] == '저자의 글')
    try:
        bk.save('ORIGINAL', 'EN', '침입')
        t('★ 어댑터가 원문 저장을 막는다', False, '안 막힘')
    except PermissionError:
        t('★ 어댑터가 원문 저장을 막는다', True)
    try:
        bk.hide('ORIGINAL', 'EN')
        t('★ 어댑터가 원문 삭제를 막는다', False, '안 막힘')
    except PermissionError:
        t('★ 어댑터가 원문 삭제를 막는다', True)
    t('막힌 뒤 원문 그대로', bk.load('ORIGINAL', 'EN')[1] == '저자의 글')
    bk.save('TRANSLATED', 'KO', '번역문')
    t('★ 번역은 새로 만들어진다', bk.load('TRANSLATED', 'KO')[1] == '번역문')
    bk.save('TRANSLATED', 'KO', '고친 번역')
    t('★ 두 번째는 덮어쓴다 (행이 안 는다)',
      bk.load('TRANSLATED', 'KO')[1] == '고친 번역'
      and db.execute("SELECT COUNT(*) FROM sys_book_unit_text "
                     "WHERE text_variant='TRANSLATED'").fetchone()[0] == 1)
    bk.hide('TRANSLATED', 'KO')
    t('번역 숨기기', bk.load('TRANSLATED', 'KO')[1] == '')

    rf = RefTextAdapter(fn, 3)
    t('사전만 제목 칸이 있다', rf.has_title and not bk.has_title)
    rf.save('TRANSLATED', 'KO', '본문', '제목')
    t('제목·본문 왕복', rf.load('TRANSLATED', 'KO') == ('제목', '본문'),
      rf.load('TRANSLATED', 'KO'))

    ta = TextAssetAdapter(fn, 5, 'PERI_TITLE')
    t('★ title 에 든 글을 읽는다', ta.load(None, 'KO')[1] == '제목이 여기',
      ta.load(None, 'KO'))
    t('변형 축이 없다 (PERI_TITLE)', ta.variants() == ())
    ta.save(None, 'KO', '고친 제목')
    r = db.execute('SELECT title, contents FROM sys_text_asset '
                   'WHERE sys_text_id=1').fetchone()
    t('★ 쓰던 칸(title)에 쓴다 — contents 를 안 만든다',
      r[0] == '고친 제목' and not (r[1] or '').strip(), r)

    td = TextAssetAdapter(fn, 9, 'VERS_DESC')
    t('티어가 변형이 된다', td.variants() == TIERS, td.variants())
    t('★ 티어는 안 잠긴다', not td.locked('LAY'))
    t('contents 에 든 글을 읽는다', td.load('LAY', 'KO')[1] == '본문이 여기')
    td.save('LAY', 'KO', '고친 본문')
    r = db.execute('SELECT title, contents FROM sys_text_asset '
                   'WHERE sys_text_id=2').fetchone()
    t('★ 쓰던 칸(contents)에 쓴다', r[1] == '고친 본문' and not (r[0] or '').strip(), r)
    td.save('EXPERT', 'KO', '전문 설명')
    t('★ 새 티어는 새 행', td.load('EXPERT', 'KO')[1] == '전문 설명'
      and td.load('LAY', 'KO')[1] == '고친 본문')
    n = db.execute("SELECT COUNT(*) FROM sys_text_asset "
                   "WHERE clicked_id=9").fetchone()[0]
    t('행이 둘 (LAY·EXPERT)', n == 2, n)

    # ── 2-C — 제목이 **다른 표**에 있을 때 ──────────────────────────
    # 도서 편 제목이 그렇다: 본문은 sys_book_unit_text, 제목은
    # sys_text_asset('BOOK_UNIT_LABEL'). 한 어댑터로는 못 다룬다.
    tad = TextAssetAdapter(fn, 7, 'BOOK_UNIT_LABEL')
    # ⚠ **변형 없이 언어만** — 실측상 제목 유형은 text_variant 가 NULL 이다
    tad.save(None, 'KO', '한국어 제목')
    t('★ 제목 어댑터가 딴 표에 쓴다', tad.load(None, 'KO')[1] == '한국어 제목')
    t('★ 제목은 변형 축이 없다 (변형으로 물으면 안 나온다)',
      tad.load('TRANSLATED', 'KO')[1] == '', tad.load('TRANSLATED', 'KO'))
    t('★ 본문 표는 안 건드렸다',
      db.execute("SELECT COUNT(*) FROM sys_book_unit_text "
                 "WHERE body_text='한국어 제목'").fetchone()[0] == 0)
    t('★ 제목 표에 들어갔다',
      db.execute("SELECT COUNT(*) FROM sys_text_asset "
                 "WHERE text_type='BOOK_UNIT_LABEL'").fetchone()[0] == 1)
    db.close()

    print('lang_compare selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    print(__doc__)
