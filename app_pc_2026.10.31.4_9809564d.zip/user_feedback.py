"""
user_feedback.py
----------------
사용자 ↔ 관리자 1:1 소통(문의·버그·개선요청) 클라이언트 로직 — 순수 로직(Tk 없음).

설계(§상호소통):
  · 익명 UUID(앱 자가생성, user_config) — ID 발급/이메일 입력 강요 없음.
  · 상행(사용자→관리자) = Google Apps Script 웹앱으로 HTTPS POST(피드백+첨부 base64).
  · 하행(관리자→사용자) = 같은 웹앱에 uuid 로 GET(내 답변만, 비공개). 공개 RSS 안 씀.
  · 이메일은 폼의 '선택' 칸 — 적은 사람만, 답변 메일은 Apps Script(MailApp)가 발송.
  · 앱 핵심 데이터는 서버로 안 감 — 서버엔 [문의·답변·첨부·선택적 이메일]만.

외부 의존성 없음(urllib·json·base64·uuid·datetime 표준). 엔드포인트 미설정 시 graceful.

저장(userdb):
  user_feedback        — 보낸 문의 로그(msg_id 로 스레드 식별)
  user_feedback_reply  — 받은 답변(seen 플래그 → 미열람 배지)
설정:
  sys_config.SUPPORT_ENDPOINT_URL / SUPPORT_SECRET  (배포 — URL·약한키는 비밀 아님)
  user_config.SUPPORT_UUID / SUPPORT_EMAIL          (로컬)
"""

import json
import base64
import uuid as _uuid
import os
import urllib.request
from datetime import datetime

import appdb

_UA = {'User-Agent': 'BibleMatrix-Feedback/1.0'}
_TIMEOUT = 20
MAX_FILE_BYTES = 2 * 1024 * 1024        # 첨부 1개 상한 2MB
MAX_TOTAL_BYTES = 8 * 1024 * 1024       # 첨부 합계 상한 8MB
FEEDBACK_KINDS = ('BUG', 'FEATURE', 'QUESTION', 'OTHER', 'SHOP', 'CHANNEL', 'SITE', 'CRASH')   # SITE = 사이트 추천 · CRASH = 폰 앱이 닫힌 까닭(2026-10-29)


# ── 테이블 (userdb 명시 — 배포 DB 오염 방지) ────────────────────────────

def ensure_tables(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS userdb.user_feedback (
            fb_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            msg_id     TEXT UNIQUE NOT NULL,
            kind       TEXT,
            text       TEXT,
            email      TEXT,
            attach     TEXT,          -- 첨부 파일명 요약(표시용)
            created_at TEXT NOT NULL,
            sent_ok    INTEGER DEFAULT 0
        )""")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS userdb.user_feedback_reply (
            reply_id   TEXT PRIMARY KEY,   -- 서버측 고유(없으면 msg_id+ts)
            msg_id     TEXT,
            body       TEXT,
            replied_at TEXT,
            seen       INTEGER DEFAULT 0
        )""")
    conn.commit()


# ── 설정·식별 ───────────────────────────────────────────────────────────

def _sys(conn, key, default=''):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (key,)).fetchone()
    return (r[0] if r and r[0] is not None else default)


def _ucfg_get(conn, key, default=''):
    r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
    return (r[0] if r and r[0] is not None else default)


def _ucfg_set(conn, key, val):
    conn.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?) "
                 "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val", (key, val))
    conn.commit()


def get_uuid(conn):
    """익명 UUID(앱 자가생성). 없으면 만들어 저장. 사용자는 입력/등록 안 함."""
    u = _ucfg_get(conn, 'SUPPORT_UUID')
    if not u:
        u = _uuid.uuid4().hex
        _ucfg_set(conn, 'SUPPORT_UUID', u)
    return u


def get_email(conn):
    return _ucfg_get(conn, 'SUPPORT_EMAIL')


def set_email(conn, email):
    _ucfg_set(conn, 'SUPPORT_EMAIL', (email or '').strip())


def endpoint(conn):
    return _sys(conn, 'SUPPORT_ENDPOINT_URL').strip()


def is_configured(conn):
    return bool(endpoint(conn))


def app_version(conn):
    return _sys(conn, 'APP_VERSION', '1.0')


# ── 첨부 ────────────────────────────────────────────────────────────────

def _read_attachments(paths):
    """[경로...] → ([{name,b64,size}], 표시요약, err). 상한 초과/누락 시 err."""
    out, names, total = [], [], 0
    for p in (paths or []):
        try:
            sz = os.path.getsize(p)
        except OSError:
            return [], '', f'파일을 찾을 수 없습니다: {os.path.basename(p)}'
        if sz > MAX_FILE_BYTES:
            return [], '', f'파일이 너무 큽니다(2MB 초과): {os.path.basename(p)}'
        total += sz
        if total > MAX_TOTAL_BYTES:
            return [], '', '첨부 합계가 8MB를 초과합니다.'
        with open(p, 'rb') as f:
            b64 = base64.b64encode(f.read()).decode('ascii')
        nm = os.path.basename(p)
        out.append({'name': nm, 'b64': b64, 'size': sz})
        names.append(nm)
    return out, ', '.join(names), None


# ── 상행: 문의 전송 ──────────────────────────────────────────────────────

def submit(conn, kind, text, attach_paths=None, email=None, lang='KO'):
    """문의 전송. → (ok, err). err='NOT_CONFIGURED' 면 지원 채널 미설정.
    email 을 주면 그 값으로 갱신 저장(선택). 첨부는 base64 로 동봉(에러 로그 등)."""
    url = endpoint(conn)
    if not url:
        return False, 'NOT_CONFIGURED'
    import gcloud_gate as _GG                      # 구글 클라우드 일시 중단(2026-09-16) — Apps Script 도 함께 멈춘다
    if _GG.paused(conn):
        return False, _GG.MSG
    if not (text or '').strip() and not attach_paths:
        return False, '내용이나 첨부를 입력하세요.'
    atts, names, aerr = _read_attachments(attach_paths)
    if aerr:
        return False, aerr
    if email is not None:
        set_email(conn, email)
    msg_id = _uuid.uuid4().hex[:16]
    payload = {
        'secret': _sys(conn, 'SUPPORT_SECRET'),
        'uuid': get_uuid(conn),
        'msg_id': msg_id,
        'kind': kind if kind in FEEDBACK_KINDS else 'OTHER',
        'text': text or '',
        'email': (email if email is not None else get_email(conn)) or '',
        'lang': lang or 'KO',
        'app_version': app_version(conn),
        'attachments': atts,
    }
    data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    try:
        req = urllib.request.Request(url, data=data,
                                     headers={**_UA, 'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
            got, why = answer_ok(r.read())
        if not got:
            raise RuntimeError('스크립트가 받지 않았습니다(%s)' % why)
    except Exception as e:
        # 전송 실패해도 로컬엔 미발송으로 기록(나중에 재시도 가능)
        _log_local(conn, msg_id, kind, text, payload['email'], names, sent_ok=0)
        return False, f'전송 실패: {str(e)[:80]}'
    _log_local(conn, msg_id, kind, text, payload['email'], names, sent_ok=1)
    return True, None


def answer_ok(body):
    """스크립트의 답 → (받았나, 까닭). ★ 2026-10-24 실측 — 시트 ID 가 틀려도 HTTP 는 200 이었다.
    답이 `{"ok":true}` 일 때만 받은 것이다 · JSON 이 아니면(구글 오류 쪽) 못 받은 것."""
    try:
        d = json.loads((body or b'').decode('utf-8', 'ignore') if isinstance(body, bytes) else (body or ''))
    except Exception:
        return False, 'BAD_REPLY'
    if isinstance(d, dict) and d.get('ok') is True:
        return True, None
    return False, str((d or {}).get('err') or 'BAD_REPLY')[:80] if isinstance(d, dict) else 'BAD_REPLY'


RESEND_KINDS = ('CHANNEL', 'SHOP', 'SITE')


def resend_unsent(conn, kinds=RESEND_KINDS, post=None):
    """못 보낸 추천(채널·상품)을 다시 보낸다 → 보낸 수.
    ★ 2026-10-24 — 소통 통로가 막혀 있던 동안(Apps Script 404) 담아 둔 것을 통로가 살아나면 그대로 보낸다.
      **같은 msg_id 로** 보낸다(서버가 겹친 것을 가를 수 있게) · 새 줄을 만들지 않는다 · 첨부 없는 갈래만."""
    url = endpoint(conn)
    if not url:
        return 0
    try:
        import gcloud_gate as _GG
        if _GG.paused(conn):
            return 0
    except Exception:
        pass
    ensure_tables(conn)
    q = ','.join('?' * len(kinds))
    rows = conn.execute('SELECT msg_id, kind, text, email FROM userdb.user_feedback '
                        'WHERE COALESCE(sent_ok,0)=0 AND kind IN (%s) ORDER BY created_at' % q, kinds).fetchall()
    sent = 0
    for msg_id, kind, text, email in rows:
        payload = {'secret': _sys(conn, 'SUPPORT_SECRET'), 'uuid': get_uuid(conn), 'msg_id': msg_id,
                   'kind': kind, 'text': text or '', 'email': email or '', 'lang': 'KO',
                   'app_version': app_version(conn), 'attachments': []}
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        try:
            if post:
                body = post(url, data)
            else:
                req = urllib.request.Request(url, data=data, headers={**_UA, 'Content-Type': 'application/json'})
                with urllib.request.urlopen(req, timeout=_TIMEOUT) as r:
                    body = r.read()
            if not answer_ok(body)[0]:
                break
        except Exception:
            break                      # 통로가 아직 막혔다 — 나머지도 다음에
        conn.execute('UPDATE userdb.user_feedback SET sent_ok=1 WHERE msg_id=?', (msg_id,))
        sent += 1
    conn.commit()
    return sent


def _log_local(conn, msg_id, kind, text, email, names, sent_ok):
    conn.execute(
        "INSERT OR REPLACE INTO user_feedback(msg_id,kind,text,email,attach,created_at,sent_ok) "
        "VALUES(?,?,?,?,?,?,?)",
        (msg_id, kind, text or '', email or '', names or '',
         datetime.now().isoformat(timespec='seconds'), sent_ok))
    conn.commit()


# ── 하행: 답변 수신(내 uuid로만) ────────────────────────────────────────

def sync_replies(conn):
    """관리자 답변을 GET(uuid)으로 받아 로컬 누적. → (new_count, err)."""
    url = endpoint(conn)
    if not url:
        return 0, 'NOT_CONFIGURED'
    import gcloud_gate as _GG                      # 구글 클라우드 일시 중단(2026-09-16)
    if _GG.paused(conn):
        return 0, 'PAUSED'
    q = url + ('&' if '?' in url else '?') + 'uuid=' + get_uuid(conn)
    try:
        with urllib.request.urlopen(urllib.request.Request(q, headers=_UA), timeout=_TIMEOUT) as r:
            data = json.loads(r.read().decode('utf-8'))
    except Exception as e:
        return 0, f'수신 실패: {str(e)[:80]}'
    new = 0
    for rep in (data.get('replies') or []):
        rid = str(rep.get('reply_id') or f"{rep.get('msg_id', '')}_{rep.get('when', '')}")
        cur = conn.execute(
            "INSERT OR IGNORE INTO user_feedback_reply(reply_id,msg_id,body,replied_at,seen) "
            "VALUES(?,?,?,?,0)",
            (rid, rep.get('msg_id', ''), rep.get('a') or rep.get('body') or '',
             rep.get('when') or rep.get('replied_at') or ''))
        new += cur.rowcount or 0
    conn.commit()
    return new, None


def unread_count(conn):
    try:
        return conn.execute("SELECT COUNT(*) FROM user_feedback_reply WHERE seen=0").fetchone()[0]
    except Exception:
        return 0


def mark_seen(conn):
    conn.execute("UPDATE user_feedback_reply SET seen=1 WHERE seen=0")
    conn.commit()


def threads(conn):
    """보낸 문의 + 각 문의의 답변을 스레드로. [{msg_id,kind,text,created_at,sent_ok,attach,replies:[...]}]."""
    out = []
    for fb_id, msg_id, kind, text, email, attach, created, sent in conn.execute(
            "SELECT fb_id,msg_id,kind,text,email,attach,created_at,sent_ok "
            "FROM user_feedback ORDER BY created_at DESC"):
        reps = [{'body': b, 'replied_at': w}
                for b, w in conn.execute(
                    "SELECT body,replied_at FROM user_feedback_reply WHERE msg_id=? "
                    "ORDER BY replied_at", (msg_id,))]
        out.append({'msg_id': msg_id, 'kind': kind, 'text': text, 'email': email,
                    'attach': attach, 'created_at': created, 'sent_ok': sent, 'replies': reps})
    return out
