# -*- coding: utf-8 -*-
"""scene_pick.py — 사진을 넣을 때 **제목과 장면을 한 번에** 받는 창
(2026-09-05 신설 · `--selftest` 의무).

★★★ 왜 (사용자 지시) — 「**사용자의 시작화면 탭이 좁다.** 사진 첨부할 때
  **장면선택을 편리하게** 하도록 개발하라」.
  ⇒ 좁은 탭에 칸을 늘리지 않는다. **넣는 순간에 한 번 묻는다.**

★★ **38을 늘어놓지 않는다** — 팩 일곱으로 접고, 고른 팩의 장면만 편다.
  실측 38개를 한 목록에 두면 고르기가 일이 된다.

★★ **결을 함께 보인다** — 「폭포·장대비 — 성령·부어짐」. 장면 이름만으로는
  무엇을 고르는지 모른다.

⚠ **안 고르는 것을 허용한다**(사용자 확정 「어느 정도의 의미연관성」). 장면이
  없으면 시작화면이 그 사진을 **아무 구절에나** 쓴다 — 못 쓰는 것이 아니다.
  창이 그 사실을 한 줄로 말한다.

⚠ 여기서 저장하지 않는다 — 부르는 쪽이 DB 에 쓴다(데이터 층과 화면을 가른다).
"""
import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ui_theme                                                 # noqa: E402
import db_splash_scene as SC                                    # noqa: E402

try:
    import i18n
except Exception:                                               # pragma: no cover
    i18n = None


def _t(k, d):
    try:
        return i18n.t(k, d) if i18n else d
    except Exception:
        return d


class ScenePickDialog(tk.Toplevel):
    """제목 + **설명** + 장면. `result` = (제목, 장면코드|None, 설명) · 취소면 None.

    ★ **고칠 때도 이 창을 쓴다**(2026-09-05 사용자 지시 — 「올린 사진에 대해
      **수정할 화면 자체가 없다**」). 지금 값을 받아 채우고 돌려준다.
    ⚠ **넣을 때와 고칠 때 창이 둘이면** 담기는 값이 갈린다.
    """

    def __init__(self, parent, name='', scene='', desc=''):
        super().__init__(parent)
        self.result = None
        self._init_scene = scene or ''
        self.title(_t('SP_TITLE', '사진 정보'))
        self.transient(parent)
        try:
            ui_theme.adopt(self)
        except Exception:
            pass
        self._build(name, desc)
        self.update_idletasks()
        try:                       # 부모 가운데 (구석에 뜨지 않게)
            x = parent.winfo_rootx() + (parent.winfo_width()
                                        - self.winfo_width()) // 2
            y = parent.winfo_rooty() + 60
            self.geometry('+%d+%d' % (max(0, x), max(0, y)))
        except Exception:
            pass
        self.grab_set()
        self._nm.focus_set()

    def _build(self, name, desc=''):
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=12, pady=10)

        ttk.Label(f, text=_t('SP_NAME', '사진 제목 (선택)')).pack(anchor='w')
        self._nm = ttk.Entry(f, width=40)
        self._nm.insert(0, name or '')
        self._nm.pack(fill='x', pady=(2, 8))

        # ★ **설명 칸**(2026-09-05 사용자 — 「사진 추가하는 팝업 화면에서도
        #   사진에 대해 **설명문을 입력하는 공간도 없다**」).
        #   ⚠ 시작 화면 띠에는 **한 줄**만 나온다 — 그 사실을 적는다.
        ttk.Label(f, text=_t('SP_DESC', '사진 설명 (선택 · 한 줄로 보입니다)')
                  ).pack(anchor='w')
        self._ds = ttk.Entry(f, width=40)
        self._ds.insert(0, desc or '')
        self._ds.pack(fill='x', pady=(2, 10))

        ttk.Label(f, text=_t('SP_SCENE', '이 사진은 어떤 장면인가요?'),
                  font=('', 10, 'bold')).pack(anchor='w')
        ttk.Label(f, wraplength=380, justify='left', foreground='#666',
                  text=_t('SP_WHY',
                          '장면을 선택하면 그 뜻에 어울리는 구절이 나올 때 이 '
                          '사진이 보입니다. 안 선택해도 됩니다 — 그러면 아무 '
                          '구절에나 쓰입니다.')).pack(anchor='w', pady=(0, 6))

        row = ttk.Frame(f)
        row.pack(fill='x')
        ttk.Label(row, text=_t('SP_PACK', '분류')).pack(side='left')
        self._packs = [(c, n) for c, n, _d in SC.SCENE_PACKS]
        self._pk = ttk.Combobox(row, state='readonly', width=14,
                                values=[_t('SP_NONE', '(선택하지 않음)')]
                                + [n for _c, n in self._packs])
        self._pk.current(0)
        self._pk.pack(side='left', padx=(6, 0))
        self._pk.bind('<<ComboboxSelected>>', self._on_pack)

        self._lb = tk.Listbox(f, height=8, exportselection=False)
        self._lb.pack(fill='both', expand=True, pady=(6, 0))
        self._lb.bind('<<ListboxSelect>>', lambda _e: self._sync())
        self._codes = []

        self._pick = ttk.Label(f, text='', foreground='#1A5276')
        self._pick.pack(anchor='w', pady=(6, 0))
        # ★ 고칠 때는 **지금 장면**을 골라 둔다 — 다시 찾게 하지 않는다.
        sc0 = getattr(self, '_init_scene', '')
        if sc0 and sc0 in SC.SCENE_BY:
            pk = SC.SCENE_BY[sc0][1]
            codes = [c for c, _n in self._packs]
            if pk in codes:
                self._pk.current(codes.index(pk) + 1)

        bar = ttk.Frame(f)
        bar.pack(fill='x', pady=(10, 0))
        tk.Button(bar, **ui_theme.flat_btn(
            text=_t('COMMON_OK', '확인'), command=self._ok)).pack(side='left')
        tk.Button(bar, **ui_theme.flat_btn(
            text=_t('COMMON_CANCEL', '취소'),
            command=self.destroy)).pack(side='left', padx=(6, 0))
        self.bind('<Escape>', lambda _e: self.destroy())
        self._on_pack()
        sc0 = getattr(self, '_init_scene', '')
        if sc0 and sc0 in getattr(self, '_codes', []):
            self._lb.selection_set(self._codes.index(sc0))
            self._lb.see(self._codes.index(sc0))
            self._sync()

    def _on_pack(self, _e=None):
        self._lb.delete(0, 'end')
        self._codes = []
        i = self._pk.current()
        if i <= 0:
            self._lb.insert('end', _t('SP_PICK_PACK',
                                      '위에서 분류를 먼저 선택하세요'))
            self._sync()
            return
        pcode = self._packs[i - 1][0]
        for code, pk, nm, hint in SC.SCENES:
            if pk != pcode:
                continue
            self._codes.append(code)
            self._lb.insert('end', '%s — %s' % (nm, hint))
        self._sync()

    def _sel(self):
        s = self._lb.curselection()
        if not s or not self._codes:
            return None
        return self._codes[s[0]]

    def _sync(self):
        code = self._sel()
        self._pick.configure(
            text=(_t('SP_SEL', '선택한 장면') + ': ' + SC.SCENE_BY[code][2])
            if code else _t('SP_SEL_NONE', '장면 없음 — 아무 구절에나 쓰입니다'))

    def _ok(self):
        self.result = ((self._nm.get() or '').strip(), self._sel(),
                       (self._ds.get() or '').strip())
        self.destroy()


def ask(parent, name='', scene='', desc=''):
    """창을 띄우고 `(제목, 장면코드|None, 설명)` 또는 `None`(취소)."""
    d = ScenePickDialog(parent, name, scene, desc)
    parent.wait_window(d)
    return d.result


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-52s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-52s %s' % (n, e))

    print('=== scene_pick selftest')
    root = tk.Tk()
    root.withdraw()
    err = []
    root.report_callback_exception = lambda *a: err.append(a)
    d = ScenePickDialog(root, '길')
    root.update()

    t('★ 창이 뜬다', d.winfo_exists())
    t('  제목이 미리 채워진다', d._nm.get() == '길')
    t('★★ **38을 늘어놓지 않는다** — 갈래로 접었다',
      len(d._pk['values']) == len(SC.SCENE_PACKS) + 1,
      '%d줄(선택하지 않음 포함)' % len(d._pk['values']))
    t('★★ **안 선택하는 것이 기본**', d._pk.current() == 0
      and d._sel() is None)
    t('  안 골랐을 때 무슨 일이 나는지 말한다',
      '아무 구절' in d._pick.cget('text'), d._pick.cget('text')[:34])

    # 갈래를 고르면 그 장면만
    d._pk.current(1 + [c for c, _n in d._packs].index('WATER'))
    d._on_pack()
    root.update()
    want = len([1 for _c, pk, _n, _h in SC.SCENES if pk == 'WATER'])
    t('★★ 갈래를 선택하면 그 장면만 편다', len(d._codes) == want,
      '물 %d개' % len(d._codes))
    t('★★ **결을 함께 보인다**(이름만으로는 못 선택한다)',
      '—' in d._lb.get(0), d._lb.get(0)[:34])

    i = d._codes.index('WATERFALL')
    d._lb.selection_set(i)
    d._sync()
    root.update()
    t('  선택하면 그 이름을 말한다', '폭포' in d._pick.cget('text'),
      d._pick.cget('text')[:30])
    d._ok()
    t('★★★ **제목과 장면을 함께 돌려준다**',
      d.result == ('길', 'WATERFALL', ''), str(d.result))

    # 취소
    d2 = ScenePickDialog(root, '')
    root.update()
    d2.destroy()
    t('★ 취소하면 아무것도 안 준다', d2.result is None)
    t('  Tk 오류 0', not err, str(err[:1]))
    root.destroy()
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
