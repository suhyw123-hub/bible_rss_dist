"""
youtube_channel_rss.py
----------------------
YouTube 채널 RSS 미리보기·판단 헬퍼 (영구 런타임 모듈).

**API 키 불필요, 외부 의존성 없음** — urllib + 정규식만 사용(쿼터 0).
채널 핸들/URL → channel_id 정확 해석 → `feeds/videos.xml` 최신 15개 파싱 →
제목·게시일·조회수·좋아요·썸네일·Shorts여부 추출 + 자동 프로파일(언어·빈도·분류·제외후보).

용도:
  · 관리자 '채널 미리보기·등록' 탭 — 등록 전 무료 1차 선별
  · (향후) 발굴 수확기·상시 RSS 수집기에서 재사용

주의: RSS는 채널당 **최신 15개만** 제공하고 description 은 업로더가 비워두면 빈칸이다
      (특히 Shorts). 판단의 주신호는 **제목**이며, 최종 결정은 관리자의 눈(채널 열기)이다.
"""

import re
import urllib.request
from collections import Counter

_UA = {'User-Agent': 'Mozilla/5.0 (compatible; BibleMatrix/1.0)'}
_TIMEOUT = 15
FEED_URL = 'https://www.youtube.com/feeds/videos.xml?channel_id={cid}'


def _get(url, timeout=_TIMEOUT):
    req = urllib.request.Request(url, headers=_UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


# ── 핸들/URL → channel_id (UC...) 정확 해석 ─────────────────────────────

def resolve_channel_id(text):
    """입력(핸들 @x · 채널 URL · UC아이디 · 커스텀명) → (channel_id, channel_url, err).
    UC 아이디는 즉시 반환. 그 외는 채널 페이지 HTML의 canonical/externalId 로 정확 추출."""
    text = (text or '').strip()
    if not text:
        return None, None, '입력이 비어 있습니다.'
    # 이미 UC 아이디
    if re.match(r'^UC[\w-]{20,}$', text):
        return text, f'https://www.youtube.com/channel/{text}', None
    # URL 안의 /channel/UC...
    m = re.search(r'youtube\.com/channel/(UC[\w-]+)', text)
    if m:
        cid = m.group(1)
        return cid, f'https://www.youtube.com/channel/{cid}', None
    # 페이지 URL 결정
    if text.startswith('http'):
        page = text
    elif text.startswith('@'):
        page = 'https://www.youtube.com/' + text
    elif re.search(r'youtube\.com/', text):
        page = ('https://' + text) if not text.startswith('http') else text
    else:
        page = 'https://www.youtube.com/@' + text
    try:
        html = _get(page)
    except Exception as e:
        return None, None, f'채널 페이지 접속 실패: {str(e)[:80]}'
    m = (re.search(r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]+)"', html)
         or re.search(r'"externalId":"(UC[\w-]+)"', html)
         or re.search(r'<meta itemprop="(?:identifier|channelId)" content="(UC[\w-]+)"', html))
    if not m:
        return None, None, '채널 ID를 찾지 못했습니다(핸들·URL 확인).'
    cid = m.group(1)
    return cid, f'https://www.youtube.com/channel/{cid}', None


# ── 채널 RSS 받아 파싱 ─────────────────────────────────────────────────

def _grp(pat, s, flags=re.S):
    m = re.search(pat, s, flags)
    return m.group(1) if m else ''


def fetch_feed(channel_id, timeout=_TIMEOUT):
    """channel_id → {channel_name, channel_id, channel_url, entries:[...], err}.
    entries: [{video_id, title, published(YYYY-MM-DD), views(int), likes(int),
               is_short(bool), url, thumbnail, description}]."""
    out = {'channel_id': channel_id,
           'channel_url': f'https://www.youtube.com/channel/{channel_id}',
           'channel_name': '', 'entries': [], 'err': None}
    try:
        xml = _get(FEED_URL.format(cid=channel_id), timeout)
    except Exception as e:
        out['err'] = f'RSS 수신 실패: {str(e)[:80]}'
        return out
    # 채널명: <author><name> (피드 헤더 title 보다 정확)
    out['channel_name'] = (_grp(r'<author>\s*<name>(.*?)</name>', xml)
                           or _grp(r'<title>(.*?)</title>', xml))
    for e in re.findall(r'<entry>(.*?)</entry>', xml, re.S):
        link = _grp(r'<link rel="alternate" href="(.*?)"', e)
        vid = _grp(r'<yt:videoId>(.*?)</yt:videoId>', e)
        views = _grp(r'<media:statistics views="(\d+)"', e)
        likes = _grp(r'<media:starRating count="(\d+)"', e)
        out['entries'].append({
            'video_id': vid,
            'title': _unescape(_grp(r'<title>(.*?)</title>', e)),
            'published': _grp(r'<published>(.*?)</published>', e)[:10],
            'views': int(views) if views.isdigit() else 0,
            'likes': int(likes) if likes.isdigit() else 0,
            'is_short': '/shorts/' in (link or ''),
            'url': link or (f'https://www.youtube.com/watch?v={vid}' if vid else ''),
            'thumbnail': _grp(r'<media:thumbnail url="(.*?)"', e),
            'description': _unescape(_grp(r'<media:description>(.*?)</media:description>', e)),
        })
    if not out['entries']:
        out['err'] = out['err'] or 'RSS 에 영상이 없습니다(비공개·신규·핸들 오류).'
    return out


def _unescape(s):
    import html
    import unicodedata
    # NFC 정규화 — macOS 등에서 올라온 제목이 분해형(NFD: 'ㅈㅜㅇㅡㅣ…')으로 와도
    # 조합형('주의…')으로 보정. 안 하면 Tkinter 등에서 자모가 풀려 보인다.
    return unicodedata.normalize('NFC', html.unescape(s or '')).strip()


# ── 자동 프로파일 (언어·빈도·분류·제외후보) ─────────────────────────────

def _guess_lang(titles):
    """제목 묶음으로 언어 추정(스크립트 기반 — 라틴은 EN 폴백)."""
    txt = ' '.join(titles)
    if re.search(r'[가-힣]', txt):
        return 'KO'
    if re.search(r'[぀-ヿ]', txt):
        return 'JA'
    if re.search(r'[一-鿿]', txt):
        return 'ZH'
    if re.search(r'[؀-ۿ]', txt):
        return 'AR'
    if re.search(r'[Ѐ-ӿ]', txt):
        return 'RU'
    return 'EN'


def profile(feed, conn=None):
    """fetch_feed 결과 → 등록 판단용 요약 dict.
    {lang, total, shorts, shorts_ratio, avg_views, span_days, per_week,
     class_counts{SERMON,WORSHIP,STUDY,FILM,...}, exclude_hits[(title,kw)], empty_desc}.
    conn 주면 sys_config 의 분류·제외 키워드 사용(없으면 기본값)."""
    entries = feed.get('entries', [])
    titles = [e['title'] for e in entries]
    lang = _guess_lang(titles)
    res = {'lang': lang, 'total': len(entries),
           'shorts': sum(1 for e in entries if e['is_short']),
           'avg_views': 0, 'span_days': 0, 'per_week': 0.0,
           'class_counts': Counter(), 'exclude_hits': [], 'empty_desc': 0}
    if not entries:
        return res
    res['shorts_ratio'] = round(res['shorts'] / res['total'], 2)
    views = [e['views'] for e in entries if e['views']]
    res['avg_views'] = int(sum(views) / len(views)) if views else 0
    res['empty_desc'] = sum(1 for e in entries if not e['description'])
    # 게시 빈도(첫·끝 published 간격)
    dates = sorted([e['published'] for e in entries if e['published']])
    if len(dates) >= 2:
        try:
            from datetime import date as _d
            d0 = _d.fromisoformat(dates[0]); d1 = _d.fromisoformat(dates[-1])
            res['span_days'] = (d1 - d0).days
            if res['span_days'] > 0:
                res['per_week'] = round(res['total'] / (res['span_days'] / 7.0), 1)
        except Exception:
            pass
    # 분류·제외 (제목+설명 기준)
    sets = None
    excl_kw = None
    try:
        import media_taxonomy as tax
        if conn is not None:
            sets = tax.load_classify_sets(conn)
        else:   # conn 없으면 기본 키워드 세트로 분류
            sets = {cat: tax._norm_buckets(None, tax.DEFAULT_CLASSIFY_KW.get(cat))
                    for cat in tax.CLASSIFY_KW_KEYS}
    except Exception:
        tax = None
    try:
        import media_exclude
        excl_kw = media_exclude.get_exclude_map()
    except Exception:
        media_exclude = None
    for e in entries:
        text = (e['title'] + ' ' + e['description']).strip()
        if tax is not None and sets is not None:
            try:
                res['class_counts'][tax.classify_content(text, lang, sets)] += 1
            except Exception:
                pass
        if media_exclude is not None:
            hit = media_exclude.match_exclude(text, excl_kw, lang=lang)
            if hit:
                res['exclude_hits'].append((e['title'][:40], hit))
    return res


# ── 발굴 ① 키워드 검색 (API, search.list type=channel) ──────────────────

def search_channels(keyword, api_key, relevance_lang=None, max_results=50,
                    page_token=None, order=None):
    """일반 기독교 키워드로 '모르는 채널' 발굴. search.list(type=channel)=100 unit/회.
    page_token 으로 다음 페이지(누적)를 받는다(같은 키워드라도 새 50개).
    → (candidates[{channel_id,title,description}], next_page_token, err).
    next_page_token 이 None 이면 더 없음(키워드 소진, YouTube 쿼리당 총 ~500 상한)."""
    if not keyword or not keyword.strip():
        return [], None, '키워드가 비어 있습니다.'
    if not api_key:
        return [], None, 'YouTube API 키가 없습니다(키 관리에서 등록).'
    try:
        from googleapiclient.discovery import build as _build
    except Exception as e:
        return [], None, f'googleapiclient 없음: {e}'
    try:
        yt = _build('youtube', 'v3', developerKey=api_key, cache_discovery=False)
        kw = {'q': keyword, 'type': 'channel', 'part': 'snippet',
              'maxResults': max(1, min(int(max_results), 50))}
        if relevance_lang:
            kw['relevanceLanguage'] = relevance_lang
        if order:
            kw['order'] = order
        if page_token:
            kw['pageToken'] = page_token
        resp = yt.search().list(**kw).execute()
    except Exception as e:
        return [], None, f'검색 실패: {str(e)[:120]}'
    out = []
    for it in resp.get('items', []):
        cid = (it.get('id') or {}).get('channelId', '')
        if not cid:
            continue
        snip = it.get('snippet', {})
        out.append({'channel_id': cid,
                    'title': _unescape(snip.get('channelTitle') or snip.get('title') or ''),
                    'description': _unescape(snip.get('description', ''))})
    return out, resp.get('nextPageToken'), None


# ── 발굴 ② 스노볼 (시드 채널의 featured channels, 무료 HTML 스크레이프) ──

def snowball_featured(channel, timeout=_TIMEOUT):
    """시드 채널(핸들/URL/UC)의 'featured channels' 페이지에서 관련 channelId 수확(쿼터 0).
    → (channel_ids[list], err). 자기 자신 제외, 중복 제거. YouTube 페이지 구조 의존(best-effort)."""
    cid, _curl, err = resolve_channel_id(channel)
    if not cid:
        return [], err or '시드 채널 해석 실패'
    try:
        html = _get(f'https://www.youtube.com/channel/{cid}/channels', timeout)
    except Exception as e:
        return [], f'채널 페이지 접속 실패: {str(e)[:80]}'
    # 모던 YouTube 페이지는 channelId/browseId/canonical 형태가 섞임 → 여럿 시도(best-effort)
    # 유튜브 channel_id 는 정확히 24자(UC+22). 경계로 묶어 base64 블롭 오매칭 차단.
    seen, out = {cid}, []
    pats = (r'"channelId":"(UC[\w-]{22})"', r'"browseId":"(UC[\w-]{22})"',
            r'/channel/(UC[\w-]{22})',
            r'(?<![A-Za-z0-9_-])(UC[A-Za-z0-9_-]{22})(?![A-Za-z0-9_-])')
    for pat in pats:
        for m in re.finditer(pat, html):
            c = m.group(1)
            if c not in seen:
                seen.add(c); out.append(c)
        if out:        # 구조적 키가 잡히면 거기서 멈춤(노이즈 적은 것 우선)
            break
    if not out:
        return [], '연결된(featured) 채널을 찾지 못했습니다(채널이 미설정했을 수 있음).'
    return out, None


# ── CLI 자가검증 (수동 실행) ───────────────────────────────────────────
if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    arg = sys.argv[1] if len(sys.argv) > 1 else '@kngskndr'
    cid, url, err = resolve_channel_id(arg)
    print('resolve:', cid, url, err)
    if cid:
        feed = fetch_feed(cid)
        print('channel:', feed['channel_name'], '| entries:', len(feed['entries']), '| err:', feed['err'])
        for e in feed['entries'][:5]:
            tag = 'SHORT' if e['is_short'] else 'VIDEO'
            print(f"  [{tag}] {e['published']} views={e['views']} likes={e['likes']} | {e['title'][:50]}")
        p = profile(feed)
        print('profile:', dict(lang=p['lang'], total=p['total'], shorts=p['shorts'],
                               avg_views=p['avg_views'], per_week=p['per_week'],
                               classes=dict(p['class_counts']), excl=len(p['exclude_hits']),
                               empty_desc=p['empty_desc']))
