# -*- coding: utf-8 -*-
"""room_admin_view.py — 공동체 묵상 4단계 · **방 관리 화면(방장)** (영구, 2026-09-08).

★★★ 사용자 확정 흐름(2026-09-08):
  「묵상플랜을 교회관리자가 특정한다 … 이 플랜이 방 내부에 공유된다. 처음에
  관리자가 서로 인사하라고 한다. 멤버들이 인사말을 주고 받는다. 관리자가
  지침을 소개한다. 다음날부터 각자 묵상을 시작하고 묵상노트를 기록한다. …
  다 끝나면 관리자가 마지막 인사말을 하고 … 방 관리가 마무리된다. 관리자는
  이 방을 다음 훈련때에도 사용하고 싶다면 **방이름을 바꾸고** 다음에
  참가자를 초청하면 된다. 굳이 그 안에 있는 환경을 리셋할 필요가 없다.
  **이러한 방 관리기능은 My edit 버튼과 별도의 버튼**을 만들어서 진입한다.
  묵상관리자를 위한 별도 화면이 필요하다. 어떤 묵상플랜을 선택할지, **전체
  참가자들의 반응 통계**를 제공한다. 묵상노트 작성여부, 참가자별 출석률 등등」

★★★ **앱에 기수 개념이 없다** — 방 이름이 그 몫이다(`묵상훈련_2029_1기`).
★★★ **폴더는 하나다** — 교재는 게시판 첨부로 올리고 참여자는 앱 안에서 연다.
  참여자가 구글드라이브에 들어갈 일이 없다.
★ 이 창은 **방장에게만** 열린다 — 참여자는 입구(단추)도 없고, 데이터 층
  (`room_core.set_plan`·`rename_room`·`room_share.save_post(LEADER_KINDS)`)도
  막는다. 문을 둘로 막는다.
⚠ 통계의 재료는 **받아 둔 파일**이다 — [받기]를 안 눌렀으면 0 이지 「안 썼다」가
  아니다. 화면이 그 사실을 적는다(§0-1).

사용:  python room_admin_view.py --selftest
"""
import io
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import appdb
import room_core as RC
import room_share as RS

try:
    import i18n
    _t = i18n.t
except Exception:
    def _t(k, d=''):
        return d

try:
    import ui_theme

    def _C(role, fb):
        try:
            return ui_theme.C(role)
        except Exception:
            return fb
except Exception:
    def _C(role, fb):
        return fb


def _tfr(w, db, scope='ui', delta=0):
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=delta)
    except Exception:
        pass


def _quiet(msg):
    try:
        sys.stderr.write(str(msg) + chr(10))
    except Exception:
        pass


#: 게시판 갈래 이름 — **i18n 열쇠**(코드 폴백은 한국어)
KIND_KEYS = (('GREET', 'RM_KIND_GREET', '인사'),
             ('GUIDE', 'RM_KIND_GUIDE', '지침'),
             ('CLOSE', 'RM_KIND_CLOSE', '마무리 인사'),
             ('POST', 'RM_KIND_POST', '글'))


def kind_name(code):
    for c, k, d in KIND_KEYS:
        if c == code:
            return _t(k, d)
    return code


def plan_items(conn, lang='KO'):
    """방에 지정할 수 있는 플랜 → `[(plan_code, 이름)]`(배포 플랜 전부).

    ⚠ 이름은 `plan_label` 한 문에 맡긴다 — 「1년」이 두 번 뜨는 것을 묶음
      이름으로 가른다(§152차 선례).
    """
    rows = list(conn.execute(
        "SELECT plan_id, plan_code, plan_type FROM sys_bible_plan "
        "WHERE record_status='LIVE' ORDER BY cat_id, plan_id"))
    titles = {}
    try:
        import plan_label
        titles = plan_label.titles_of(conn, [r[0] for r in rows], lang) or {}
    except Exception:
        titles = {}
    out = []
    for pid, code, ptype in rows:
        ttl = titles.get(pid) or code
        try:
            import plan_label
            ttl = plan_label.full(ptype, ttl, ambiguous=True) or ttl
        except Exception:
            pass
        out.append((code, ttl))
    return out


def upto_day(conn, room_id, plan_code):
    """통계 기준일 — 내 등록의 `current_day`, 없으면 글이 있는 마지막 날, 없으면 1."""
    try:
        r = conn.execute(
            "SELECT e.current_day FROM user_plan_enrollment e "
            "JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
            "WHERE p.plan_code=? AND e.enrollment_status='ACTIVE' LIMIT 1",
            (plan_code,)).fetchone()
        if r and r[0]:
            return int(r[0])
    except Exception:
        pass
    try:
        days = [d for pc, d, _n in RS.days_with_notes(conn, room_id)
                if pc == plan_code]
        if days:
            return max(days)
    except Exception:
        pass
    return 1


class RoomAdminWin(tk.Toplevel):
    """방 관리 — 방장 전용 창."""

    def __init__(self, parent, db_path, room_id, lang_getter=None, on_changed=None):
        super().__init__(parent)
        self.db_path = db_path
        self.room_id = room_id
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_changed = on_changed
        self._files = []
        self._room = None
        self.title(_t('RM_ADMIN', '방 관리'))
        self.transient(parent.winfo_toplevel())
        self.resizable(True, True)
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        self._build()
        self.reload()
        try:
            p = parent.winfo_toplevel()
            self.geometry('760x720+%d+%d' % (p.winfo_rootx() + 40,
                                            p.winfo_rooty() + 30))
        except Exception:
            self.geometry('760x720')

    # ── 화면 ────────────────────────────────────────────────────
    def _build(self):
        pad = 10
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=pad, pady=pad)

        # 단추는 **맨 위**(§0)
        bar = ttk.Frame(f)
        bar.pack(fill='x', pady=(0, 6))
        ttk.Button(bar, text=_t('RA_PUSH', '올리기 (내 글·게시판·방 설정)'),
                   command=self._push).pack(side='left')
        ttk.Button(bar, text=_t('RA_PULL', '받기'),
                   command=self._pull).pack(side='left', padx=6)
        ttk.Button(bar, text=_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                   command=self._invite).pack(side='left')
        # ★ M 은 그 줄의 **맨 오른쪽**(§ user_main._manual_at 규칙)
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar, 'U_ROOM_ADMIN',
                               lang_provider=lambda: (self.lang_getter() or 'KO')
                               ).pack(side='right', padx=(4, 0))
        except Exception as e:
            _quiet('[ra manual] %s' % e)
        ttk.Button(bar, text=_t('COMMON_CLOSE', '닫기'),
                   command=self.destroy).pack(side='right')
        self._sync_var = tk.StringVar(value='')
        tk.Label(bar, textvariable=self._sync_var, fg=_C('fg_dim', '#666')
                 ).pack(side='right', padx=8)

        self._head = tk.StringVar(value='')
        h = tk.Label(f, textvariable=self._head, anchor='w',
                     fg=_C('fg_title', '#1A5276'))
        h.pack(fill='x')
        _tfr(h, self.db_path, 'ui', 3)

        # ── 방 — 이름 · 폴더 · 플랜 ──────────────────────────────
        rf = ttk.LabelFrame(f, text=' ' + _t('RA_SEC_ROOM', '방') + ' ')
        rf.pack(fill='x', pady=(6, 4))
        g = ttk.Frame(rf)
        g.pack(fill='x', padx=8, pady=6)
        g.columnconfigure(1, weight=1)
        r = 0
        ttk.Label(g, text=_t('RA_NAME', '방 이름')).grid(row=r, column=0, sticky='w')
        self._name_var = tk.StringVar()
        ttk.Entry(g, textvariable=self._name_var).grid(row=r, column=1, sticky='we',
                                                      padx=6)
        self._btn_rename = ttk.Button(g, text=_t('RA_RENAME', '이름 바꾸기'),
                                      command=self._rename)
        self._btn_rename.grid(row=r, column=2)
        r += 1
        hn = tk.Label(g, text=_t('RA_RENAME_HINT',
                      '다음 훈련에도 이 방을 쓰려면 이름만 바꾸고 다시 초대하세요. '
                      '안의 글과 자료는 그대로 남습니다. (보기: 묵상훈련_2029_1기)'),
                      anchor='w', justify='left', wraplength=640,
                      fg=_C('fg_dim', '#888'))
        hn.grid(row=r, column=1, columnspan=2, sticky='w', pady=(0, 6))
        _tfr(hn, self.db_path, 'ui', -2)
        r += 1
        ttk.Label(g, text=_t('RA_FOLDER', '방 폴더')).grid(row=r, column=0, sticky='w')
        self._fold_var = tk.StringVar()
        ttk.Entry(g, textvariable=self._fold_var).grid(row=r, column=1, sticky='we',
                                                      padx=6)
        self._btn_fold = ttk.Button(g, text=_t('COMMON_SAVE', '저장'),
                                    command=self._save_folder)
        self._btn_fold.grid(row=r, column=2)
        r += 1
        hf = tk.Label(g, text=_t('ROOM_FOLDER_HINT2',
                      '폴더 하나면 됩니다(구글드라이브·OneDrive 가 만든 동기화 폴더). '
                      '교재는 아래 게시판에 첨부해 올립니다. 참여자는 이 앱 안에서 '
                      '받으므로 드라이브를 직접 열 필요가 없습니다.'),
                      anchor='w', justify='left', wraplength=640,
                      fg=_C('fg_dim', '#888'))
        hf.grid(row=r, column=1, columnspan=2, sticky='w', pady=(0, 6))
        _tfr(hf, self.db_path, 'ui', -2)
        r += 1
        ttk.Label(g, text=_t('RA_SEC_PLAN', '묵상플랜')).grid(row=r, column=0, sticky='w')
        self._plan_var = tk.StringVar()
        self._plan_cb = ttk.Combobox(g, textvariable=self._plan_var,
                                     state='readonly')
        self._plan_cb.grid(row=r, column=1, sticky='we', padx=6)
        self._btn_plan = ttk.Button(g, text=_t('COMMON_SAVE', '저장'),
                                    command=self._save_plan)
        self._btn_plan.grid(row=r, column=2)
        r += 1
        # ★★★ 시작일 — **방장이 정하고 모두 같은 날 시작**(사용자 확정)
        ttk.Label(g, text=_t('RA_PLAN_START', '시작일')).grid(row=r, column=0,
                                                            sticky='w')
        self._start_var = tk.StringVar()
        sr = ttk.Frame(g)
        sr.grid(row=r, column=1, sticky='w', padx=6)
        ttk.Entry(sr, textvariable=self._start_var, width=12).pack(side='left')
        self._today_var = tk.StringVar(value='')
        tk.Label(sr, textvariable=self._today_var, fg=_C('fg_dim', '#666')
                 ).pack(side='left', padx=8)
        self._btn_start = ttk.Button(g, text=_t('COMMON_SAVE', '저장'),
                                     command=self._save_start)
        self._btn_start.grid(row=r, column=2)
        r += 1
        hst = tk.Label(g, text=_t('RA_START_HINT',
                       'YYYY-MM-DD. 모든 참여자가 같은 날 시작합니다 — 참여자의 '
                       '「오늘」은 이 날짜에서 셉니다(각자 플랜 등록과 무관).'),
                       anchor='w', justify='left', wraplength=640,
                       fg=_C('fg_dim', '#888'))
        hst.grid(row=r, column=1, columnspan=2, sticky='w', pady=(0, 6))
        _tfr(hst, self.db_path, 'ui', -2)
        r += 1
        hp = tk.Label(g, text=_t('RA_PLAN_HINT',
                      '여기서 정한 플랜이 이 방의 묵상 단위가 됩니다. [올리기]를 '
                      '해야 참여자에게 전해지고, 참여자의 「함께 묵상」 화면에 이 '
                      '플랜이 먼저 뜹니다.'),
                      anchor='w', justify='left', wraplength=640,
                      fg=_C('fg_dim', '#888'))
        hp.grid(row=r, column=1, columnspan=2, sticky='w')
        _tfr(hp, self.db_path, 'ui', -2)
        r += 1
        # ★ 5단계 — 방 마무리(수료 처리). 글·자료·폴더는 그대로, 진도 재촉만 멈춘다.
        ttk.Label(g, text=_t('RA_STATUS', '상태')).grid(row=r, column=0, sticky='w',
                                                     pady=(6, 0))
        self._st_var = tk.StringVar(value='')
        tk.Label(g, textvariable=self._st_var, anchor='w',
                 fg=_C('fg_dim', '#666')).grid(row=r, column=1, sticky='w',
                                               padx=6, pady=(6, 0))
        self._close_btn = ttk.Button(g, text=_t('RA_CLOSE', '방 마무리'),
                                     command=self._toggle_close)
        self._close_btn.grid(row=r, column=2, pady=(6, 0))

        # ── 게시판 글쓰기 ─────────────────────────────────────────
        bf = ttk.LabelFrame(f, text=' ' + _t('RA_SEC_BOARD', '게시판 글쓰기') + ' ')
        bf.pack(fill='x', pady=(4, 4))
        b1 = ttk.Frame(bf)
        b1.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Label(b1, text=_t('RM_KIND', '갈래')).pack(side='left')
        self._kinds = [(c, _t(k, d)) for c, k, d in KIND_KEYS]
        self._kind_var = tk.StringVar(value=self._kinds[0][1])
        ttk.Combobox(b1, textvariable=self._kind_var, state='readonly', width=14,
                     values=[n for _c, n in self._kinds]).pack(side='left', padx=6)
        ttk.Label(b1, text=_t('RA_TITLE_F', '제목')).pack(side='left', padx=(10, 0))
        self._title_var = tk.StringVar()
        ttk.Entry(b1, textvariable=self._title_var).pack(side='left', fill='x',
                                                        expand=True, padx=6)
        ttk.Button(b1, text=_t('COMMON_SAVE', '저장'),
                   command=self._save_post).pack(side='left')
        self._body = tk.Text(bf, height=5, wrap='word', undo=True)
        self._body.pack(fill='x', padx=8, pady=2)
        _tfr(self._body, self.db_path, 'prose')
        b2 = ttk.Frame(bf)
        b2.pack(fill='x', padx=8, pady=(2, 6))
        ttk.Label(b2, text=_t('RM_ATTACH', '첨부')).pack(side='left')
        self._files_var = tk.StringVar(value='')
        tk.Label(b2, textvariable=self._files_var, anchor='w',
                 fg=_C('fg_dim', '#666')).pack(side='left', padx=6, fill='x',
                                               expand=True)
        ttk.Button(b2, text=_t('RM_ATTACH_ADD', '파일 첨부'),
                   command=self._add_file).pack(side='left')
        ttk.Button(b2, text=_t('RM_ATTACH_CLEAR', '첨부 비우기'),
                   command=self._clear_files).pack(side='left', padx=6)
        hb = tk.Label(bf, text=_t('RA_BOARD_HINT',
                      '인사 → 지침(교재 첨부) → 날마다 묵상 → 마무리 인사. '
                      '지침과 마무리 인사는 방장만 쓸 수 있습니다. 저장한 글은 '
                      '[올리기]를 해야 참여자에게 전해집니다.'),
                      anchor='w', justify='left', wraplength=700,
                      fg=_C('fg_dim', '#888'))
        hb.pack(fill='x', padx=8, pady=(0, 6))
        _tfr(hb, self.db_path, 'ui', -2)

        # ── 참가자 현황 ───────────────────────────────────────────
        sf = ttk.LabelFrame(f, text=' ' + _t('RA_SEC_STATS', '참가자 현황') + ' ')
        sf.pack(fill='both', expand=True, pady=(4, 0))
        s1 = ttk.Frame(sf)
        s1.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Label(s1, text=_t('RA_UPTO', '기준 일차')).pack(side='left')
        self._upto_var = tk.IntVar(value=1)
        ttk.Spinbox(s1, from_=1, to=3000, width=6, textvariable=self._upto_var,
                    command=self._fill_stats).pack(side='left', padx=6)
        ttk.Button(s1, text=_t('COMMON_REFRESH', '새로고침'),
                   command=self._fill_stats).pack(side='left')
        ttk.Label(s1, text=_t('RA_THRESHOLD', '수료 기준(%)')).pack(side='left',
                                                                 padx=(12, 0))
        self._thr_var = tk.IntVar(value=80)
        ttk.Spinbox(s1, from_=0, to=100, increment=5, width=5,
                    textvariable=self._thr_var, command=self._fill_stats
                    ).pack(side='left', padx=6)
        self._stat_sum = tk.StringVar(value='')
        tk.Label(s1, textvariable=self._stat_sum, fg=_C('fg_dim', '#666')
                 ).pack(side='left', padx=(12, 0))
        s2 = ttk.Frame(sf)
        s2.pack(fill='x', padx=8, pady=(0, 2))
        ttk.Button(s2, text=_t('RA_HIDE', '가리기'),
                   command=lambda: self._hide(True)).pack(side='left')
        ttk.Button(s2, text=_t('RA_UNHIDE', '가림 풀기'),
                   command=lambda: self._hide(False)).pack(side='left', padx=6)
        ttk.Button(s2, text=_t('RA_GRAD_SAVE', '수료 명단 저장'),
                   command=self._save_grad).pack(side='left', padx=(12, 0))
        # ★★★ 부방장 — 방장만 지정·해제
        self._btn_co = ttk.Button(s2, text=_t('RA_CO_SET', '부방장 지정'),
                                  command=lambda: self._co(True))
        self._btn_co.pack(side='left', padx=(12, 0))
        self._btn_co_off = ttk.Button(s2, text=_t('RA_CO_UNSET', '부방장 해제'),
                                      command=lambda: self._co(False))
        self._btn_co_off.pack(side='left', padx=6)
        cols = ('name', 'role', 'days', 'rate', 'done', 'linked', 'greet', 'last')
        self._tv = ttk.Treeview(sf, columns=cols, show='headings', height=7)
        for cid, key, dflt, w, anc in (
                ('name', 'RA_COL_NAME', '이름', 150, 'w'),
                ('role', 'RA_COL_ROLE', '역할', 60, 'center'),
                ('days', 'RA_COL_DAYS', '쓴 날', 80, 'center'),
                ('rate', 'RA_COL_RATE', '출석률', 70, 'center'),
                ('done', 'RA_COL_DONE', '수료', 50, 'center'),
                ('linked', 'RA_COL_LINKED', '구절 연결', 70, 'center'),
                ('greet', 'RA_COL_GREET', '인사', 50, 'center'),
                ('last', 'RA_COL_LAST', '마지막 글', 110, 'center')):
            self._tv.heading(cid, text=_t(key, dflt))
            self._tv.column(cid, width=w, anchor=anc, stretch=(cid == 'name'))
        sb = ttk.Scrollbar(sf, command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y', pady=(0, 6))
        self._tv.pack(fill='both', expand=True, padx=(8, 0), pady=(0, 6))
        try:
            import theme_font
            theme_font.list_style('RoomAdmin.Treeview', self.db_path)
            self._tv.configure(style='RoomAdmin.Treeview')
        except Exception:
            pass
        hs = tk.Label(sf, text=_t('RA_STATS_HINT',
                      '받아 둔 파일을 셉니다 — [받기]를 누른 뒤의 값입니다. '
                      '「쓴 날」은 기준 일차까지 묵상을 쓴 날 수, 「출석률」은 그 '
                      '비율입니다. 아직 파일을 안 올린 분은 목록에 없습니다.')
                      + ' ' + _t('RA_HIDE_HINT',
                                 '[가리기]는 앱 안에서만 가립니다 — 폴더 접근을 '
                                 '막으려면 드라이브 공유에서 그 분을 빼세요.'),
                      anchor='w', justify='left', wraplength=700,
                      fg=_C('fg_dim', '#888'))
        hs.pack(fill='x', padx=8, pady=(0, 6))
        _tfr(hs, self.db_path, 'ui', -2)

        # ── 지우기 — 맨 아래, 따로 ────────────────────────────────
        df = ttk.Frame(f)
        df.pack(fill='x', pady=(6, 0))
        self._btn_del = ttk.Button(df, text=_t('RA_DELETE', '방 지우기'),
                                   command=self._delete)
        self._btn_del.pack(side='right')

    # ── 채우기 ─────────────────────────────────────────────────
    def reload(self):
        try:
            with appdb.connect(self.db_path) as conn:
                self._room = RC.room(conn, self.room_id)
                lang = (self.lang_getter() or 'KO').upper()
                self._plans = plan_items(conn, lang)
        except Exception as e:
            _quiet('[ra] %s' % e)
            self._room, self._plans = None, []
        if not self._room:
            self._head.set(_t('ROOM_ERR_BROKEN', '방을 찾을 수 없습니다.'))
            return
        if self._room['my_role'] not in RC.MANAGER_ROLES:
            # ⚠ 입구가 막혀 있어도 **여기서 한 번 더** 말한다(§97차 규칙)
            self._head.set(_t('RA_NOT_LEADER', '방장·부방장만 쓰는 화면입니다.'))
            return
        r = self._room
        self._lead = (r['my_role'] == RC.ROLE_LEADER)
        head = _t('RA_HEAD', '방 관리 — %s') % r['room_name']
        if not self._lead:
            head += '  (' + _t('ROOM_ROLE_CO', '부방장') + ')'
        # ★ 방장 전용 단추는 부방장에게 잠긴다 — 잠긴 까닭은 머리에 적는다
        for b in (self._btn_rename, self._btn_fold, self._btn_plan, self._btn_start,
                  self._btn_del, self._btn_co, self._btn_co_off):
            try:
                b.state(['!disabled'] if self._lead else ['disabled'])
            except Exception:
                pass
        if not self._lead:
            head += '  — ' + _t('RA_CO_NOTE', '부방장은 게시판·공지·현황·가리기·마무리를 맡습니다')
        self._start_var.set(r.get('plan_start') or '')
        td = RC.today_day(r)
        self._today_var.set((_t('RA_TODAY_DAY', '오늘 %d일차') % td) if td else
                            _t('RA_START_NONE', '(시작일 없음)'))
        self._blocked = None
        try:
            with appdb.connect(self.db_path) as conn:
                self._blocked = RC.blocked(conn, self.room_id)
        except Exception:
            pass
        if self._blocked:
            head += '  —  ' + _t('RA_BLOCKED', '관리자가 이 방을 막았습니다: %s') % self._blocked
        self._head.set(head)
        if RC.is_closed(r):
            self._st_var.set(_t('RA_CLOSED_AT', '마무리됨 %s') % (r.get('closed_at') or ''))
            self._close_btn.config(text=_t('RA_REOPEN', '다시 열기'))
        else:
            self._st_var.set(_t('RA_STATUS_OPEN', '진행 중'))
            self._close_btn.config(text=_t('RA_CLOSE', '방 마무리'))
        self._name_var.set(r['room_name'] or '')
        self._fold_var.set(RC.folder_of(r))
        vals = [_t('RA_PLAN_NONE', '(정하지 않음)')] + [n for _c, n in self._plans]
        self._plan_cb.config(values=vals)
        cur = r.get('plan_code') or ''
        nm = next((n for c, n in self._plans if c == cur), None)
        self._plan_var.set(nm or vals[0])
        try:
            td = RC.today_day(r)
            with appdb.connect(self.db_path) as conn:
                self._upto_var.set(td or (upto_day(conn, self.room_id, cur) if cur else 1))
        except Exception:
            self._upto_var.set(1)
        self._fill_stats()

    def _fill_stats(self):
        self._tv.delete(*self._tv.get_children())
        r = self._room
        if not r:
            return
        pc = r.get('plan_code') or ''
        try:
            upto = max(1, int(self._upto_var.get() or 1))
        except Exception:
            upto = 1
        try:
            with appdb.connect(self.db_path) as conn:
                rows = RS.member_stats(conn, self.room_id, pc, upto, self.db_path)
        except Exception as e:
            _quiet('[ra stats] %s' % e)
            rows = []
        wrote = 0
        try:
            thr = int(self._thr_var.get())
        except Exception:
            thr = 80
        for x in rows:
            nm = x['name'] + (' ' + _t('RM_ME', '(나)') if x['mine'] else '')
            role = {'LEADER': _t('ROOM_ROLE_LEADER', '방장'),
                    'CO_LEADER': _t('ROOM_ROLE_CO', '부방장')}.get(x.get('role'), '')
            if x.get('hidden'):
                self._tv.insert('', 'end', iid=x['member_id'] or nm, values=(
                    nm + ' ' + _t('RA_HIDDEN_MARK', '(가림)'), role, '', '', '', '',
                    '', ''))
                continue
            done = x['rate'] * 100 >= thr
            self._tv.insert('', 'end', iid=x['member_id'] or nm, values=(
                nm, role, '%d / %d' % (x['days'], upto),
                '%d%%' % int(round(x['rate'] * 100)), '●' if done else '',
                x['linked'], '●' if x['greeted'] else '',
                (x['last_at'] or '')[:10]))
            wrote += 1 if x['days'] else 0
        self._stat_rows = rows
        if not pc:
            self._stat_sum.set(_t('RA_STATS_NOPLAN', '플랜을 먼저 정해 주세요'))
        else:
            self._stat_sum.set(_t('RA_STATS_SUM', '%d명 · 쓴 사람 %d')
                               % (len(rows), wrote))

    # ── 동작 ───────────────────────────────────────────────────
    def _notify(self):
        if callable(self.on_changed):
            try:
                self.on_changed()
            except Exception as e:
                _quiet('[ra cb] %s' % e)

    def _rename(self):
        nm = (self._name_var.get() or '').strip()
        if not nm:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RC.rename_room(conn, self.room_id, nm)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()
        self._tell_synced(_t('RA_RENAMED2', '이름을 바꿨습니다.'))

    def _save_folder(self):
        try:
            with appdb.connect(self.db_path) as conn:
                RC.set_folder(conn, self.room_id, self._fold_var.get())
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()

    def _save_start(self):
        try:
            with appdb.connect(self.db_path) as conn:
                RC.set_plan_start(conn, self.room_id, self._start_var.get())
        except ValueError as e:
            if 'NOT_LEADER' in str(e):
                messagebox.showerror(_t('RM_ADMIN', '방 관리'),
                                     _t('RA_NOT_LEADER', '방장·부방장만 쓰는 화면입니다.'),
                                     parent=self)
            else:
                messagebox.showwarning(_t('RM_ADMIN', '방 관리'),
                                       _t('RA_START_BAD', '날짜는 YYYY-MM-DD 꼴로 적어 주세요.'),
                                       parent=self)
            return
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()
        self._tell_synced(_t('RA_START_SAVED', '시작일을 정했습니다.'))

    def _co(self, on):
        sel = self._tv.selection()
        if not sel:
            return
        mid = sel[0]
        row = next((x for x in getattr(self, '_stat_rows', []) if x['member_id'] == mid),
                   None)
        if not row or row.get('mine'):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RC.set_co_leader(conn, self.room_id, mid, on)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()
        self._tell_synced(_t('RA_CO_DONE', '「%s」 님을 부방장으로 지정했습니다.') % row['name']
                          if on else
                          _t('RA_CO_UNDONE', '「%s」 님의 부방장을 해제했습니다.') % row['name'])

    def _sync_quiet(self):
        """바꾼 것을 곧바로 올리고 받는다 — 폴더가 없으면 조용히 건너뛴다.
        → 됐나(bool). 「[올리기]를 눌러야」라는 말을 화면이 안 하게 하는 장치."""
        if getattr(self, '_blocked', None):
            return False
        f = RC.folder_of(self._room)
        if not f or not os.path.isdir(f):
            return False
        try:
            with appdb.connect(self.db_path) as conn:
                RS.push(conn, self.room_id, f, self._room['my_name'] or '', self.db_path)
                who, notes, _b = RS.pull(conn, self.room_id, f, self.db_path)
            from datetime import datetime as _dt
            self._sync_var.set(_t('RM_SYNC', '동기화 %s') % _dt.now().strftime('%H:%M'))
            self._fill_stats()
            return True
        except Exception as e:
            _quiet('[ra sync] %s' % e)
            return False

    def _tell_synced(self, msg):
        ok = self._sync_quiet()
        messagebox.showinfo(_t('RM_ADMIN', '방 관리'),
                            msg + ' ' + (_t('RA_SYNCED', '참여자에게 전했습니다.') if ok
                                         else _t('RA_SYNC_LATER',
                                                 '[올리기]를 하면 참여자에게 전해집니다.')),
                            parent=self)

    def _save_plan(self):
        v = self._plan_var.get()
        code = next((c for c, n in self._plans if n == v), '')
        try:
            with appdb.connect(self.db_path) as conn:
                RC.set_plan(conn, self.room_id, code)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()
        self._tell_synced(_t('RA_PLAN_SAVED2', '플랜을 정했습니다.'))

    def _folder(self):
        if getattr(self, '_blocked', None):
            messagebox.showinfo(_t('RM_ADMIN', '방 관리'),
                                _t('RM_BLOCKED_STOP',
                                   '관리자가 이 방을 막아 올리고 받을 수 없습니다: %s')
                                % self._blocked, parent=self)
            return None
        f = RC.folder_of(self._room)
        if not f or not os.path.isdir(f):
            messagebox.showinfo(
                _t('RM_ADMIN', '방 관리'),
                _t('RA_NEED_FOLDER',
                   '방 폴더를 먼저 정해 주세요 — 내 PC 에서 보이는 동기화 폴더 '
                   '경로여야 합니다(웹 주소는 열 수 없습니다).'),
                parent=self)
            return None
        return f

    def _add_file(self):
        f = self._folder()
        if not f:
            return
        p = filedialog.askopenfilename(parent=self,
                                       title=_t('RM_ATTACH_ADD', '파일 첨부'))
        if not p:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                uid = RC.my_uuid(conn)
            name = RS.attach_file(f, uid, p)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self._files.append(name)
        self._files_var.set(' · '.join(x.split('_', 2)[-1] for x in self._files))

    def _clear_files(self):
        self._files = []
        self._files_var.set('')

    def _save_post(self):
        body = self._body.get('1.0', 'end').strip()
        kind = next((c for c, n in self._kinds if n == self._kind_var.get()), 'POST')
        if not body and not self._files:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RS.save_post(conn, self.room_id, kind, body,
                             title=self._title_var.get(), files=self._files,
                             lang=(self.lang_getter() or 'KO'))
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self._body.delete('1.0', 'end')
        self._title_var.set('')
        self._clear_files()
        self._notify()
        self._tell_synced(_t('ROOM_SAVED', '저장했습니다.'))

    def _push(self):
        f = self._folder()
        if not f:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                name, cnt, _sk = RS.push(conn, self.room_id, f,
                                         self._room['my_name'] or '', self.db_path)
                who, notes, _bad = RS.pull(conn, self.room_id, f, self.db_path)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:250], parent=self)
            return
        self._fill_stats()
        self._notify()
        messagebox.showinfo(_t('RM_ADMIN', '방 관리'),
                            _t('RM_PUSHED', '%d편을 올리고 %d명의 글 %d편을 받았습니다.')
                            % (cnt, who, notes), parent=self)

    def _pull(self):
        f = self._folder()
        if not f:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                who, notes, bad = RS.pull(conn, self.room_id, f, self.db_path)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:250], parent=self)
            return
        self._fill_stats()
        self._notify()
        msg = _t('ROOM_PULL_OK', '%d명의 글 %d편을 받았습니다.') % (who, notes)
        if bad:
            msg += '\n' + _t('ROOM_PULL_BAD', '구절을 찾지 못해 못 받은 것 %d편') % bad
        messagebox.showinfo(_t('RM_ADMIN', '방 관리'), msg, parent=self)

    def _invite(self):
        r = self._room
        safe = ''.join(ch for ch in (r['room_name'] or '')
                       if ch not in '\\/:*?"<>|').strip() or 'room'
        p = filedialog.asksaveasfilename(
            parent=self, title=_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
            initialfile=safe + RC.EXT, defaultextension=RC.EXT,
            filetypes=[(_t('ROOM_FILE_INVITE', '초대 파일'), '*.hagah')])
        if not p:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                out = RC.write_invite(conn, self.room_id, p)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                                 str(e)[:200], parent=self)
            return
        messagebox.showinfo(_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                            (_t('ROOM_INVITE_OK', '만들었습니다.\n%s') % out) + '\n\n'
                            + _t('ROOM_INVITE_WARN',
                                 '⚠ 이 파일에는 폴더 주소가 들어 있습니다. 받은 '
                                 '사람은 누구나 그 방에 들어올 수 있으니 아는 '
                                 '분들에게만 보내세요.'),
                            parent=self)

    def _toggle_close(self):
        r = self._room
        if not r:
            return
        closing = not RC.is_closed(r)
        if closing and not messagebox.askyesno(
                _t('RA_CLOSE', '방 마무리'),
                _t('RA_CLOSE_ASK',
                   '「%s」 방을 마무리합니다.\n\n글·자료·폴더는 그대로 남고, 참여자 '
                   '화면에 「마무리됨」이 표시되며 「아직 안 썼습니다」 줄이 사라집니다. '
                   '[올리기]를 하면 참여자에게 전해집니다. 언제든 [다시 열기]로 '
                   '되돌립니다.') % r['room_name'], parent=self):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RC.close_room(conn, self.room_id, closed=closing)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self.reload()
        self._notify()
        self._sync_quiet()

    def _hide(self, hidden):
        sel = self._tv.selection()
        if not sel:
            return
        mid = sel[0]
        row = next((x for x in getattr(self, '_stat_rows', []) if x['member_id'] == mid),
                   None)
        if not row or row.get('mine'):
            messagebox.showinfo(_t('RM_ADMIN', '방 관리'),
                                _t('RA_HIDE_SELF', '나 자신은 가릴 수 없습니다.'),
                                parent=self)
            return
        if hidden and not messagebox.askyesno(
                _t('RA_HIDE', '가리기'),
                _t('RA_HIDE_ASK',
                   '「%s」 님을 가립니다.\n\n이 방의 모든 참여자 화면에서 그 분의 글이 '
                   '사라지고, 그 분의 파일을 더 받지 않습니다([올리기]로 전해집니다). '
                   '되돌릴 수 있습니다.\n\n⚠ 앱 안에서만 가려집니다 — 폴더 파일은 '
                   '그대로 있고, 폴더 접근을 막으려면 드라이브 공유에서 그 분을 빼야 '
                   '합니다.') % row['name'], parent=self):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RS.set_member_hidden(conn, self.room_id, mid, hidden, self.db_path)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200], parent=self)
            return
        self._fill_stats()
        self._notify()
        self._sync_quiet()

    def _save_grad(self):
        rows = getattr(self, '_stat_rows', [])
        if not rows:
            return
        try:
            upto = max(1, int(self._upto_var.get() or 1))
            thr = int(self._thr_var.get())
        except Exception:
            upto, thr = 1, 80
        lines = RS.graduation_lines(rows, upto, thr)
        safe = ''.join(ch for ch in (self._room['room_name'] or '')
                       if ch not in '\\/:*?"<>|').strip() or 'room'
        p = filedialog.asksaveasfilename(
            parent=self, title=_t('RA_GRAD_SAVE', '수료 명단 저장'),
            initialfile=safe + '_수료.txt', defaultextension='.txt',
            filetypes=[('txt', '*.txt')])
        if not p:
            return
        try:
            with io.open(p, 'w', encoding='utf-8') as f:
                f.write((_t('RA_GRAD_HEAD', '%s — 수료 명단 (기준 %d일차 · %d%%)')
                         % (self._room['room_name'], upto, thr)) + chr(10))
                f.write(chr(10).join(lines) + chr(10))
        except Exception as e:
            messagebox.showerror(_t('RA_GRAD_SAVE', '수료 명단 저장'), str(e)[:200],
                                 parent=self)
            return
        messagebox.showinfo(_t('RA_GRAD_SAVE', '수료 명단 저장'),
                            _t('ROOM_EXPORT_OK', '만들었습니다.\n%s') % p, parent=self)

    def _delete(self):
        r = self._room
        if not r:
            return
        # ★ 몇 개가 사라지는지 먼저 센다(§0 규칙) — 되돌릴 수 없는 일이다.
        try:
            with appdb.connect(self.db_path) as conn:
                n_notes = len(RS.my_notes(conn, self.room_id))
                n_posts = len(RS.my_posts(conn, self.room_id))
        except Exception:
            n_notes = n_posts = 0
        if not messagebox.askyesno(
                _t('RA_DELETE', '방 지우기'),
                _t('RA_DELETE_ASK',
                   '「%s」 방을 지웁니다.\n\n이 PC 의 방 기록과 연락처가 사라집니다. '
                   '내가 쓴 글(묵상 %d편 · 게시판 %d편)은 내 자료로 남고, '
                   '폴더의 파일은 그대로 있습니다. 참여자의 앱에서는 사라지지 '
                   '않습니다.\n\n다음 훈련에 다시 쓰려면 지우지 말고 이름만 '
                   '바꾸세요.') % (r['room_name'], n_notes, n_posts),
                parent=self):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                RS.detach(conn)
                RC.delete_room(conn, self.room_id)
            RS.forget_room(self.room_id, self.db_path)
        except Exception as e:
            messagebox.showerror(_t('RA_DELETE', '방 지우기'), str(e)[:200], parent=self)
            return
        self._notify()
        self.destroy()


def open_room_admin(parent, db_path, room_id, lang_getter=None, on_changed=None):
    """방 관리 창을 연다 — **방장이 아니면 안 열고 왜인지 말한다**(§0-1)."""
    try:
        with appdb.connect(db_path) as conn:
            lead = RC.is_manager(conn, room_id)
    except Exception:
        lead = False
    if not lead:
        messagebox.showinfo(_t('RM_ADMIN', '방 관리'),
                            _t('RA_NOT_LEADER', '방장·부방장만 쓰는 화면입니다.'),
                            parent=parent.winfo_toplevel())
        return None
    return RoomAdminWin(parent, db_path, room_id, lang_getter, on_changed)


# ── 자가 검증 ──────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    import sqlite3
    import tempfile
    import shutil
    errs = []
    root = tk.Tk()
    root.withdraw()
    tk.Tk.report_callback_exception = lambda s, e, v, tb: errs.append(
        '%s: %s' % (e.__name__, v))
    d = tempfile.mkdtemp(prefix='rav_')
    dbp = os.path.join(d, 'bible_master.db')
    udb = os.path.join(d, 'user_data.db')
    udb2 = os.path.join(d, 'user2.db')
    share = os.path.join(d, 'share')
    os.makedirs(share)
    opened = []
    _orig = appdb.connect
    import tkinter.messagebox as _MB
    _mb = (_MB.showinfo, _MB.showerror, _MB.askyesno, _MB.showwarning)
    _MB.showwarning = lambda *a, **k: None
    _MB.showinfo = lambda *a, **k: None
    _MB.showerror = lambda *a, **k: errs.append('showerror: %s' % (a[1:2],))
    _MB.askyesno = lambda *a, **k: True

    def fake_for(u):
        def fake(path=None, *a, **k):
            c = sqlite3.connect(dbp)
            c.execute("ATTACH ? AS userdb", (u,))
            opened.append(c)
            return c
        return fake
    try:
        c0 = sqlite3.connect(dbp)
        c0.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY,"
                   " bcode INTEGER, chapter INTEGER, verse INTEGER)")
        c0.execute("CREATE TABLE book_names(book_code INTEGER, lang_code TEXT,"
                   " full_name TEXT, short_name TEXT)")
        c0.executemany("INSERT INTO bible_index VALUES(?,?,?,?)",
                       [(i, 1, 1, i) for i in range(1, 9)])
        c0.execute("INSERT INTO book_names VALUES(1,'KO','창세기','창')")
        c0.execute("CREATE TABLE sys_bible_plan(plan_id INTEGER PRIMARY KEY,"
                   " plan_code TEXT, plan_type TEXT, cat_id INTEGER,"
                   " duration_days INTEGER, record_status TEXT)")
        c0.execute("CREATE TABLE sys_plan_schedule(plan_id INTEGER, day INTEGER,"
                   " start_vid INTEGER, end_vid INTEGER, sort_order INTEGER)")
        c0.execute("INSERT INTO sys_bible_plan VALUES(1,'P1','THEMATIC',2,30,'LIVE')")
        c0.execute("INSERT INTO sys_bible_plan VALUES(2,'P2','THEMATIC',2,7,'LIVE')")
        c0.executemany("INSERT INTO sys_plan_schedule VALUES(?,?,?,?,?)",
                       [(1, 1, 1, 3, 1), (1, 2, 4, 5, 1)])
        c0.commit()
        c0.close()
        for u in (udb, udb2):
            cu = sqlite3.connect(u)
            cu.execute("CREATE TABLE user_text_asset(user_text_id INTEGER PRIMARY "
                       "KEY, clicked_id INTEGER, target_id INTEGER, text_type "
                       "TEXT, title TEXT, contents TEXT, lang_code TEXT,"
                       " record_status TEXT, created_at TEXT, updated_at TEXT)")
            cu.execute("CREATE TABLE user_config(config_key TEXT PRIMARY KEY,"
                       " config_val TEXT)")
            cu.execute("CREATE TABLE user_feedback(id INTEGER PRIMARY KEY)")
            cu.execute("CREATE TABLE user_plan_enrollment(enrollment_id INTEGER "
                       "PRIMARY KEY, plan_id INTEGER, user_plan_id INTEGER,"
                       " current_day INTEGER, enrollment_status TEXT)")
            cu.commit()
            cu.close()
        appdb.connect = fake_for(udb)
        with appdb.connect(dbp) as c:
            rid = RC.create_room(c, '묵상훈련_2026_1기', 'CHURCH_TR', '김전도사',
                                 terms_ok=True)
            RC.set_my_name(c, rid, '김전도사')
            RC.set_folder(c, rid, share)
            c.execute("INSERT INTO userdb.user_plan_enrollment VALUES(1,1,NULL,"
                      "4,'ACTIVE')")
            c.commit()

        # 참여자는 못 연다
        with appdb.connect(dbp) as c:
            inv = RC.invite_body(c, rid)
        appdb.connect = fake_for(udb2)
        with appdb.connect(dbp) as c:
            RC.join_room(c, inv, '박청년')
        w0 = open_room_admin(root, dbp, rid)
        t('★★ 참여자에게는 방 관리 창이 안 열린다', w0 is None)
        appdb.connect = fake_for(udb)

        w = open_room_admin(root, dbp, rid, lambda: 'KO')
        root.update()
        t('★ 방장에게 방 관리 창이 뜬다', w is not None and w.winfo_exists())
        t('  머리에 방 이름', '묵상훈련_2026_1기' in w._head.get(), w._head.get())
        t('  플랜 콤보에 배포 플랜 둘 + 정하지 않음',
          len(w._plan_cb.cget('values')) == 3, w._plan_cb.cget('values'))
        t('  폴더가 칸에 들어온다', w._fold_var.get() == share)

        # 플랜 정하기
        w._plan_var.set([n for c_, n in w._plans if c_ == 'P1'][0])
        w._save_plan()
        with appdb.connect(dbp) as c:
            t('★★★ 플랜을 정하면 방에 적힌다',
              RC.room(c, rid)['plan_code'] == 'P1', RC.room(c, rid).get('plan_code'))
        t('  기준 일차가 내 등록(current_day=4)을 따른다',
          w._upto_var.get() == 4, w._upto_var.get())

        # 이름 바꾸기 — 기수는 이름이 맡는다
        w._name_var.set('묵상훈련_2027_1기')
        w._rename()
        with appdb.connect(dbp) as c:
            t('★★ 이름을 바꾸면 방이 그대로 다음 기수가 된다',
              RC.room(c, rid)['room_name'] == '묵상훈련_2027_1기')

        # 게시판 — 지침 + 첨부
        src = os.path.join(d, '교재.txt')
        io.open(src, 'w', encoding='utf-8').write('교재 본문')
        with appdb.connect(dbp) as c:
            uid = RC.my_uuid(c)
        w._files = [RS.attach_file(share, uid, src)]
        w._kind_var.set(kind_name('GUIDE'))
        w._body.insert('1.0', '이번 훈련의 지침입니다')
        w._save_post()
        with appdb.connect(dbp) as c:
            mp = RS.my_posts(c, rid)
        t('★★ 지침 글이 첨부와 함께 저장된다',
          len(mp) == 1 and mp[0]['kind'] == 'GUIDE' and len(mp[0]['files']) == 1,
          mp)
        t('  저장 뒤 글칸·첨부가 비워진다',
          w._body.get('1.0', 'end').strip() == '' and w._files == [])

        # 올리기 → 참여자가 받으면 이름·플랜·게시판이 온다
        w._push()
        appdb.connect = fake_for(udb2)
        with appdb.connect(dbp) as c:
            RS.pull(c, rid, share, udb2)
            rb = RC.room(c, rid)
            bp = RS.posts(c, rid, udb2)
        t('★★★ 참여자가 방 이름·플랜을 받아 적는다',
          rb['room_name'] == '묵상훈련_2027_1기' and rb['plan_code'] == 'P1',
          (rb['room_name'], rb.get('plan_code')))
        t('★★★ 참여자 게시판에 지침과 교재 첨부가 도착한다',
          any(p['kind'] == 'GUIDE' and p['files'] for p in bp),
          [(p['kind'], p['files']) for p in bp])
        # 참여자가 글을 쓰고 올리면 통계에 잡힌다
        with appdb.connect(dbp) as c:
            RS.save_note(c, rid, 'P1', 1, '첫날 묵상', verse_id=2)
            RS.save_post(c, rid, 'GREET', '안녕하세요')
            RS.push(c, rid, share, '박청년', udb2)
        appdb.connect = fake_for(udb)
        w._pull()
        root.update()
        rows = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('★★★ 참가자 현황 — 참여자 줄이 뜬다(쓴 날 1/4 · 25%)',
          any(r[0] == '박청년' and r[2] == '1 / 4' and r[3] == '25%'
              and str(r[5]) == '1' and r[6] == '●' for r in rows), rows)
        t('  나(방장)도 목록에 있다', any('(나)' in r[0] for r in rows))
        t('  요약 줄', '2명' in w._stat_sum.get(), w._stat_sum.get())
        w._upto_var.set(2)
        w._fill_stats()
        rows2 = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('  기준 일차를 바꾸면 출석률이 따라온다',
          any(r[0] == '박청년' and r[3] == '50%' for r in rows2), rows2)

        # ── 5단계 — 수료 · 가리기 · 마무리 · 차단 ─────────────────────
        w._thr_var.set(20)
        w._fill_stats()
        rows3 = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('★ 수료 기준을 넘으면 수료 표식', any(r[0] == '박청년' and r[4] == '●'
                                              for r in rows3), rows3)
        w._thr_var.set(80)
        w._fill_stats()
        rows4 = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('  기준을 올리면 표식이 사라진다', all(r[4] == '' for r in rows4))
        gl = RS.graduation_lines(w._stat_rows, 2, 20)
        t('  수료 명단 줄에 박청년이 수료', any('박청년' in x and '수료' in x for x in gl), gl)
        # 가리기 — 박청년 줄을 골라
        mid_b = next(x['member_id'] for x in w._stat_rows if x['name'] == '박청년')
        w._tv.selection_set(mid_b)
        w._hide(True)
        root.update()
        rows5 = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('★★ 가리면 현황에 (가림) 표식만 남는다',
          any('박청년' in r[0] and '가림' in r[0] and r[2] == '' for r in rows5), rows5)
        with appdb.connect(dbp) as c:
            t('  방 파일에 가림 목록', mid_b in RS.hidden_members(c, rid, dbp))
        w._tv.selection_set(mid_b)
        w._hide(False)
        root.update()
        with appdb.connect(dbp) as c:
            t('  풀면 목록에서 빠진다', mid_b not in RS.hidden_members(c, rid, dbp))
        # ── 시작일 · 부방장 ─────────────────────────────────────
        w._start_var.set('9월1일')
        w._save_start()
        with appdb.connect(dbp) as c:
            t('★ 틀린 날짜 꼴은 저장 안 된다', not RC.room(c, rid)['plan_start'])
        w._start_var.set('2026-09-01')
        w._save_start()
        with appdb.connect(dbp) as c:
            t('★★★ 시작일을 정한다(모두 같은 날 시작)',
              RC.room(c, rid)['plan_start'] == '2026-09-01')
        t('  오늘 일차가 머리에 뜬다', '일차' in w._today_var.get(), w._today_var.get())
        w._tv.selection_set(mid_b)
        w._co(True)
        root.update()
        with appdb.connect(dbp) as c:
            t('★★★ 부방장을 지정한다', mid_b in RC.co_leaders(RC.room(c, rid)))
        rows6 = [w._tv.item(i, 'values') for i in w._tv.get_children()]
        t('  역할 칸에 부방장', any(r[0] == '박청년' and '부방장' in r[1] for r in rows6), rows6)
        # 부방장 PC 에서 방 관리 창을 열면 — 방장 전용 단추가 잠긴다
        appdb.connect = fake_for(udb2)
        with appdb.connect(dbp) as c:
            RS.pull(c, rid, share, udb2)
            t('  참여자 앱이 부방장 역할을 받았다', RC.room(c, rid)['my_role'] == RC.ROLE_CO)
        w2 = open_room_admin(root, dbp, rid, lambda: 'KO')
        root.update()
        t('★★ 부방장에게 방 관리 창이 열린다', w2 is not None and w2.winfo_exists())
        t('  방장 전용 단추가 잠긴다',
          'disabled' in w2._btn_rename.state() and 'disabled' in w2._btn_co.state()
          and 'disabled' in w2._btn_del.state())
        t('  머리에 부방장 표식', '부방장' in w2._head.get(), w2._head.get())
        w2.destroy()
        appdb.connect = fake_for(udb)
        w._tv.selection_set(mid_b)
        w._co(False)
        root.update()
        with appdb.connect(dbp) as c:
            t('  해제', mid_b not in RC.co_leaders(RC.room(c, rid)))

        # 마무리 — askyesno 는 True
        w._toggle_close()
        root.update()
        with appdb.connect(dbp) as c:
            t('★ [방 마무리]로 마무리된다', RC.is_closed(RC.room(c, rid)))
        t('  단추가 [다시 열기]로 바뀐다',
          w._close_btn.cget('text') == _t('RA_REOPEN', '다시 열기'))
        w._toggle_close()
        with appdb.connect(dbp) as c:
            t('  다시 열린다', not RC.is_closed(RC.room(c, rid)))
        # 차단 — 취소 목록에 넣으면 머리에 사유 · 올리기 거부
        with appdb.connect(dbp) as c:
            c.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY,"
                      " config_val TEXT)")
            import json as _j
            c.execute("INSERT OR REPLACE INTO sys_config VALUES(?,?)",
                      (RC.BLOCK_KEY, _j.dumps({rid: {'reason': '저작권 신고'}})))
            c.commit()
        w.reload()
        root.update()
        t('★★ 막힌 방은 머리에 사유가 뜬다', '저작권 신고' in w._head.get(), w._head.get())
        t('  막힌 방은 올리기 폴더를 안 낸다', w._folder() is None)
        with appdb.connect(dbp) as c:
            c.execute("DELETE FROM sys_config WHERE config_key=?", (RC.BLOCK_KEY,))
            c.commit()
        w.reload()

        # 지우기 — 몇 개 사라지는지 세고 묻는다(askyesno 는 True)
        w._delete()
        root.update()
        with appdb.connect(dbp) as c:
            t('★ 방 지우기', RC.room(c, rid) is None)
        t('  창이 닫힌다', not w.winfo_exists())
        t('  Tk 오류 0', len(errs) == 0, errs[:2])
        src_ = io.open(os.path.abspath(__file__), encoding='utf-8').read()
        t('★★ 기수 개념이 없다', 'coh' + 'ort' not in src_.replace('묵상훈련', ''))
        _my = 'my_' + 'edit'
        t('★ My Edit 과 별개의 입구다(My Edit 을 안 부른다)', _my not in src_)
    finally:
        appdb.connect = _orig
        _MB.showinfo, _MB.showerror, _MB.askyesno, _MB.showwarning = _mb
        try:
            root.destroy()
        except Exception:
            pass
        for c in opened:
            try:
                c.close()
            except Exception:
                pass
        shutil.rmtree(d, ignore_errors=True)
    print('room_admin_view selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('room_admin_view — 방 관리 창은 함께 묵상 화면의 [방 관리] 단추로 연다')
