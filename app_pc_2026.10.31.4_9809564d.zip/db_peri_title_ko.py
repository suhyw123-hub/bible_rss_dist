# -*- coding: utf-8 -*-
"""KO 페리코프 제목의 기계번역 흔적을 패턴으로 잡는다.

누가 154개를 손으로 훑어 88건을 고치면서 나온 유형만 넣었다.
`db_peri_title_lang` 은 제목 낱말을 그 언어 성경 본문에 정박시키는 도구라
요약형 제목을 가리지 못한다(§8-2). 이쪽은 정박이 아니라 **한국어 문체**를 본다.
"""
import sys, os, re, collections
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

# ── 1. KRV 와 표기가 어긋난 낱말 (누가·마태에서 실제로 고친 것) ──
WORD = {
    '카이사르': '가이사', '산헤드린': '공회', '올리브산': '감람산', '올리브 산': '감람산',
    '나병': '문둥병', '맹인': '소경', '악마': '귀신', '악령': '귀신', '경비병': '파수꾼',
    '테오필루스': '데오빌로', '엘리자베스': '엘리사벳',
    # ⚠ `스가랴 → 사가랴` 를 넣지 말 것. KRV 는 **구약이 스가랴, 신약만 사가랴**다.
    #   왕하 15:8 여로보암의 아들 스가랴 · 슥 1:1 선지자 스가랴 · 눅 1:5 제사장 사가랴.
    #   누가에서 고친 것은 세례 요한의 아버지 하나뿐이다.
    '세례자 요한': '세례 요한', '예언자': '선지자', '율법학자': '율법사',
    '소작인': '농부', '연회': '잔치', '바리새파': '바리새인', '사두개파': '사두개인',
    '갈릴래아': '갈릴리', '베일': '휘장', '개선문': '(오역)', '변모': '변형',
    '사제': '제사장', '법률': '규례', '법규': '규례', '지침': '규례',
    '곰팡이': '색점', '처벌': '벌', '제한 사항': '금한 것',
}
# ── 2. 번역투 어미·구조 ──
PAT = [
    (r'[?？]\s*$',                       '물음표로 끝난다'),
    (r'(?:했다|였다|이었다|았다|겼다)\s*$', '평서 과거로 끝난다'),
    (r'(?:한다|된다|진다|온다|난다|간다|본다|든다)\s*$', '평서 현재로 끝난다'),
    (r'(?:하기|되기|삼기|보기|받기|주기|짓기|쌓기|판단하기)\s*$', '명사형 「~하기」로 끝난다'),
    (r'에 대한|에 관한|에 대하여|에 관하여',  '「~에 대한」 번역투'),
    # ⚠ 맨 `로의`·`에서의` 는 쓰지 말 것 — 바로의·이드로의·에서의(에서=인명)를 잡는다
    (r'(?:으로의|과 함께하는|와 함께하는|에 있어서)', '조사 겹침 번역투'),
    (r'및 기타|기타 |그리고 기타',           '「및 기타」 번역투'),
    (r'시도하다|선택한다|동의했다|정화하시다|축복하시다|증거함', '번역기 동사'),
    (r'하며\s*$|하면서\s*$|하는\s*$|되는\s*$', '끝맺지 않고 잘렸다'),
    (r'(?:은|는)\s+[^ ]+(?:다|음|함)\s*$',  '주어에 「은·는」이 붙은 평서문'),
]
# ── 3. 한국어 제목에 섞이면 안 되는 글자 ──
BAD_CHAR = re.compile(r'[一-鿿぀-ヿЀ-ӿ؀-ۿ]')

# ── 4. 잡으면 안 되는 것 (2026-08-04 실측으로 확인) ──
#  ① 예언서 신탁 제목 「X에 대한 심판/예언/경고」 — 한국어로 자연스럽고 오역이 아니다.
#  ② 시편·서신서의 본문 인용형 명제 — 「더 큰 사랑은 없다」(요15:13) 같은 것.
#  ③ 역사서의 왕위 계승 요약 「X가 Y의 뒤를 이었다」 — 삼상~대하에 걸쳐 일관된 편집이다.
#
# ⚠ OK_ORACLE 을 예언서에만 걸었더니 「우상숭배에 대한 경고」(신)·「배교에 대한 경고」(딤전)·
#   「엘리 가문에 대한 예언」(삼상) 이 줄줄이 걸렸다. 「X에 대한 심판/경고/예언」은
#   **책을 가리지 않고** 자연스러운 한국어다. 그래서 전권에 건다. 대신 목록에 없는 말
#   (부담·충성심·복수·관심·응징 …)은 그대로 잡힌다 — 그것이 진짜 번역투다.
#   꼬리 설명(「모압에 대한 심판 — 그모스가 …」)과 앞 꾸밈말(「최종 심판」)도 통과시킨다.
OK_ORACLE = re.compile(
    r'에 (?:대한|관한) (?:\S+ )?(?:심판|예언|경고|책망|비난|판결|묵시|계시|저주)'
    r'(?:\s*[—–-].*)?\s*$')
QUOTE_BOOKS = {18, 19, 20, 21, 22,           # 욥·시·잠·전·아
               43,                           # 요 — 「더 큰 사랑은 없다」(15:13)
               45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,  # 롬~히
               59, 60, 61, 62, 63, 64, 65, 66}                          # 약~계
SUCCESSION = re.compile(r'뒤를 이었다\s*$')
HIST_BOOKS = {9, 10, 11, 12, 13, 14}         # 삼상·삼하·왕상·왕하·대상·대하

def main():
    c = appdb.connect(); q = c.cursor()
    q.execute("""SELECT a.clicked_id, a.title, i.bcode, i.chapter, i.verse
                 FROM sys_text_asset a
                 JOIN sys_pericope_asset p ON p.pericope_id = a.clicked_id
                 JOIN bible_index i ON i.verse_id = p.start_vid
                 WHERE a.text_type='PERI_TITLE' AND a.lang_code='KO'
                   AND COALESCE(a.record_status,'LIVE')='LIVE'
                   AND COALESCE(p.record_status,'LIVE')='LIVE'
                 ORDER BY i.bcode, i.chapter, i.verse""")
    rows = q.fetchall()
    bk = {}
    q.execute("SELECT book_code, short_name FROM book_names WHERE lang_code='KO'")
    for b, n in q.fetchall(): bk[b] = n

    hits = []
    for pid, title, bcode, ch, vs in rows:
        t = (title or '').strip()
        if not t: continue
        why = []
        m = BAD_CHAR.search(t)
        if m: why.append('한글 아닌 글자 「%s」' % m.group())
        for w, right in WORD.items():
            if w in t:
                why.append('%s → %s' % (w, right) if right else '%s (확인)' % w)
        for rx, msg in PAT:
            if not re.search(rx, t): continue
            # 신탁 제목 「X에 대한 심판/경고/예언」은 전권에서 정상이다
            if OK_ORACLE.search(t): continue
            # 시가서·서신서의 인용형 명제·물음은 정상이다 (본문을 그대로 옮긴 제목)
            if bcode in QUOTE_BOOKS and msg.startswith(('주어에', '평서', '물음표')): continue
            # 역사서의 왕위 계승 요약은 일관된 편집이다
            if bcode in HIST_BOOKS and SUCCESSION.search(t): continue
            why.append(msg); break
        if why:
            hits.append((bcode, ch, vs, pid, t, ' · '.join(why)))

    per = collections.Counter(h[0] for h in hits)
    print('KO 제목 %d개 중 %d건 후보\n' % (len(rows), len(hits)))
    print('── 책별 ──')
    for b, n in sorted(per.items(), key=lambda x: -x[1]):
        print('  %-10s %3d' % (bk.get(b, str(b)), n))
    lim = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    print('\n── 앞 %d건 ──' % lim)
    for bcode, ch, vs, pid, t, why in hits[:lim]:
        print('  %-5s %3s:%-3s peri %-5s %-28s | %s' % (bk.get(bcode, bcode), ch, vs, pid, t, why))

main()
