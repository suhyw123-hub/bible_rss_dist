"""
voice_play_bar.py  —  재생 공용 유틸리티

PlaySettings  : 재생 옵션 컨테이너 (앱 세션 동안 유지)
open_play_settings_popup() : 설정 팝업 열기
build_playlist_from_settings() : 플레이리스트 생성
"""
import sqlite3
import appdb
import i18n
import tkinter as tk
from tkinter import ttk
from pathlib import Path

from voice_bible import Player, voice_path, existing_file

# ── 모드 정의 ─────────────────────────────────────────────────────────────────
PLAY_MODES = [
    ("Solo",          "SOLO"),
    ("Chapter Echo",  "CHAPTER_ECHO"),
    ("Verse Echo",    "VERSE_ECHO"),
    ("Verse Relay",   "VERSE_RELAY"),
    ("Chapter Relay", "CHAPTER_RELAY"),
]
_LABEL_TO_CODE = {lbl: code for lbl, code in PLAY_MODES}
_CODE_TO_LABEL = {code: lbl for lbl, code in PLAY_MODES}


# ── 설정 컨테이너 ─────────────────────────────────────────────────────────────

class PlaySettings:
    """재생 옵션을 보관. 앱 재시작 전까지 직전 값이 유지된다."""

    def __init__(self):
        self.mode       = "SOLO"    # 재생 방식 코드
        self.owners: list[str] = [] # 선택된 owner 목록 (순서 = Relay 순서)
        self.gap_sec    = 0.5       # 구절 간 무음 (초)
        self.repeat     = 1         # 반복 횟수 (0 = 무한 — [■] 를 누를 때까지)
        # ★ 2026-10-25 (docs/1.txt 1-2) 「반복 2 로 해도 한 번만 재생하고 지나간다」 — 반복이 범위 통째에만 걸려
        #   한 구절을 거듭 듣는 길이 없었고 ∞ 는 아무 일도 안 했다 ⇒ 반복 단위: VERSE(구절마다) · RANGE(장 통째)
        self.repeat_unit = 'VERSE'
        self.highlight  = True      # 재생 중 P1 구절 자동 하이라이트
        # ★ 2026-10-25 이 값을 읽는 곳이 없어 P1 은 늘 다음 장으로 넘어갔다 — 이제 읽는다(기본 켬 = 지금까지의 동작)
        self.auto_next  = True      # 장 완료 후 다음 장 자동 이동

# 구절 단위 ∞ — 그 구절을 이만큼 되풀이한다([■] 로 멈춘다)
VERSE_LOOP = 200


# ── 팝업 ─────────────────────────────────────────────────────────────────────

def open_play_settings_popup(anchor_widget, db_path: str, version: str,
                             verse_ids: list[int],
                             settings: PlaySettings,
                             on_confirm):
    """
    anchor_widget 아래에 재생 옵션 설정 팝업(Toplevel)을 연다.
    확인 시 settings 가 갱신된 뒤 on_confirm(settings) 이 호출된다.
    """
    # 현재 verse_ids 에 녹음이 있는 owner 목록 조회
    owners: list[str] = []
    if verse_ids:
        ph = ",".join("?" * len(verse_ids))
        try:
            with appdb.connect(db_path) as conn:
                owners = [r[0] for r in conn.execute(
                    f"SELECT DISTINCT voice_owner FROM user_voice_asset "
                    f"WHERE verse_id IN ({ph}) AND bible_version=? "
                    f"ORDER BY voice_owner",
                    (*verse_ids, version)
                ).fetchall()]
        except Exception:
            pass

    pop = tk.Toplevel(anchor_widget)
    pop.title(i18n.t('WIN_PLAY_OPTIONS', "재생 옵션"))
    pop.resizable(False, False)
    pop.grab_set()

    # 팝업 위치: anchor 바로 아래
    anchor_widget.update_idletasks()
    ax = anchor_widget.winfo_rootx()
    ay = anchor_widget.winfo_rooty() + anchor_widget.winfo_height() + 2
    pop.geometry(f"+{ax}+{ay}")

    bg = "#F8F9FA"
    pop.configure(bg=bg)

    def sec_label(text):
        tk.Label(pop, text=text, bg=bg,
                 font=("Malgun Gothic", 9, "bold")).pack(
            anchor="w", padx=10, pady=(8, 2))

    # ── 재생 방식 ──────────────────────────────────────────────────────────────
    sec_label("재생 방식")
    mode_var = tk.StringVar(value=_CODE_TO_LABEL.get(settings.mode, "Solo"))
    ttk.Combobox(pop, textvariable=mode_var,
                 values=[lbl for lbl, _ in PLAY_MODES],
                 state="readonly", width=16,
                 font=("Malgun Gothic", 9)
                 ).pack(anchor="w", padx=14, pady=2)

    # ── 참여자 (체크박스) ──────────────────────────────────────────────────────
    sec_label("참여자")
    owner_vars: dict[str, tk.BooleanVar] = {}
    if owners:
        for o in owners:
            var = tk.BooleanVar(value=(o in settings.owners))
            owner_vars[o] = var
            tk.Checkbutton(pop, text=o, variable=var, bg=bg,
                           font=("Malgun Gothic", 9)).pack(
                anchor="w", padx=22)
    else:
        tk.Label(pop, text=i18n.t('VPB_NOREC','  (이 구절의 녹음 없음)'), bg=bg, fg="#888",
                 font=("Malgun Gothic", 9)).pack(anchor="w", padx=22)

    # ── 구분선 ────────────────────────────────────────────────────────────────
    tk.Frame(pop, height=1, bg="#D5D8DC").pack(fill="x", padx=10, pady=6)

    # ── 추가 옵션 ─────────────────────────────────────────────────────────────
    sec_label("추가 옵션")
    opts_f = tk.Frame(pop, bg=bg)
    opts_f.pack(anchor="w", padx=14, pady=2)

    tk.Label(opts_f, text=i18n.t('VPB_SILENCE','구절 간 무음:'), bg=bg,
             font=("Malgun Gothic", 9)).grid(row=0, column=0, sticky="w")
    gap_var = tk.StringVar(value=str(settings.gap_sec))
    ttk.Combobox(opts_f, textvariable=gap_var,
                 values=["0", "0.5", "1", "1.5", "2", "3"],
                 state="readonly", width=5,
                 font=("Malgun Gothic", 9)).grid(row=0, column=1, padx=6)
    tk.Label(opts_f, text=i18n.t('VPB_SEC','초'), bg=bg,
             font=("Malgun Gothic", 9)).grid(row=0, column=2, sticky="w")

    tk.Label(opts_f, text=i18n.t('VPB_REPEAT','반복 횟수:'), bg=bg,
             font=("Malgun Gothic", 9)).grid(row=1, column=0, sticky="w", pady=3)
    rep_var = tk.StringVar(value="∞" if settings.repeat == 0 else str(settings.repeat))
    ttk.Combobox(opts_f, textvariable=rep_var,
                 values=["1", "2", "3", "5", "10", "∞"],
                 state="readonly", width=5,
                 font=("Malgun Gothic", 9)).grid(row=1, column=1, padx=6)
    _units = [('VERSE', i18n.t('VPB_UNIT_VERSE', '구절마다')), ('RANGE', i18n.t('VPB_UNIT_RANGE', '장 전체'))]
    unit_var = tk.StringVar(value=dict(_units).get(getattr(settings, 'repeat_unit', 'VERSE'), _units[0][1]))
    ttk.Combobox(opts_f, textvariable=unit_var, values=[n for _, n in _units],
                 state="readonly", width=9,
                 font=("Malgun Gothic", 9)).grid(row=1, column=2, padx=2, sticky="w")

    hl_var = tk.BooleanVar(value=settings.highlight)
    tk.Checkbutton(opts_f, text=i18n.t('VPB_AUTOHL','성경구절 자동 하이라이트'),
                   variable=hl_var, bg=bg,
                   font=("Malgun Gothic", 9)).grid(
        row=2, column=0, columnspan=3, sticky="w", pady=2)

    an_var = tk.BooleanVar(value=settings.auto_next)
    tk.Checkbutton(opts_f, text=i18n.t('VPB_AUTONEXT','장 완료 후 자동 다음 장'),
                   variable=an_var, bg=bg,
                   font=("Malgun Gothic", 9)).grid(
        row=3, column=0, columnspan=3, sticky="w")

    # ── 확인 버튼 ─────────────────────────────────────────────────────────────
    tk.Frame(pop, height=1, bg="#D5D8DC").pack(fill="x", padx=10, pady=6)

    def _confirm():
        settings.mode    = _LABEL_TO_CODE.get(mode_var.get(), "SOLO")
        settings.owners  = [o for o, v in owner_vars.items() if v.get()]
        try:
            settings.gap_sec = float(gap_var.get())
        except ValueError:
            settings.gap_sec = 0.0
        settings.repeat    = 0 if rep_var.get() == "∞" else int(rep_var.get())
        settings.repeat_unit = next((c for c, n in _units if n == unit_var.get()), 'VERSE')
        settings.highlight = hl_var.get()
        settings.auto_next = an_var.get()
        on_confirm(settings)
        pop.destroy()

    tk.Button(pop, text='✓ '+i18n.t('COMMON_CONFIRM','확인'), command=_confirm,
              bg="#1A5276", fg="white",
              font=("Malgun Gothic", 9, "bold"),
              bd=0, padx=16, pady=4).pack(pady=8)

    pop.focus_set()


# ── 플레이리스트 생성 ─────────────────────────────────────────────────────────

def build_playlist(db_path: str, verse_ids: list[int],
                   version: str, settings: PlaySettings
                   ) -> list[tuple[int, Path]]:
    """
    PlaySettings 에 따라 (verse_id, file_path) 재생 목록을 반환한다.
    """
    mode   = settings.mode
    owners = settings.owners
    vids   = verse_ids

    if not owners or not vids:
        return []

    def fp(owner, vid):
        # ★ 87 — 폰에서 온 Opus(.ogg)도 · 파일이 없으면(진척만) 없는 경로를 돌려 아래 exists() 가 거른다
        return existing_file(owner, version, vid, db_path) or voice_path(owner, version, vid, db_path)

    result: list[tuple[int, Path]] = []

    if mode == "SOLO":
        o = owners[0]
        for v in vids:
            p = fp(o, v)
            if p.exists(): result.append((v, p))

    elif mode == "CHAPTER_ECHO":
        a = owners[0]
        b = owners[1] if len(owners) > 1 else a
        for v in vids:
            p = fp(a, v)
            if p.exists(): result.append((v, p))
        for v in vids:
            p = fp(b, v)
            if p.exists(): result.append((v, p))

    elif mode == "VERSE_ECHO":
        a = owners[0]
        b = owners[1] if len(owners) > 1 else a
        for v in vids:
            for o in (a, b):
                p = fp(o, v)
                if p.exists(): result.append((v, p))

    elif mode in ("VERSE_RELAY", "CHAPTER_RELAY"):
        # ★ 2026-10-25 차례를 **절·장 번호**로 정한다 — 그전에는 목록 안의 자리(i)로 정해, 누른 구절에 따라
        #   누가 어느 절을 읽는지가 바뀌었고(절 릴레이) P1 은 늘 한 장만 넘겨 장 릴레이는 언제나 첫 목소리였다
        n = len(owners)
        ph = ",".join("?" * len(vids))
        try:
            with appdb.connect(db_path) as conn:
                pos = {r[0]: (r[1], r[2]) for r in conn.execute(
                    f"SELECT verse_id, chapter, verse FROM bible_index "
                    f"WHERE verse_id IN ({ph})", vids
                ).fetchall()}
        except Exception:
            pos = {}
        for i, v in enumerate(vids):
            ch, vs = pos.get(v, (1, i + 1))
            k = (vs - 1) if mode == "VERSE_RELAY" else (ch - 1)
            p = fp(owners[k % n], v)
            if p.exists(): result.append((v, p))

    return apply_repeat(result, settings)


def apply_repeat(result, settings):
    """반복 — 구절마다(같은 절 묶음을 N 번 잇달아) 또는 장 통째(N 번).
    ∞(0) — 구절마다면 그 절을 VERSE_LOOP 번 · 장 통째면 한 벌(되풀이는 P1 이 장 끝에서 같은 장을 다시 튼다)."""
    rep = settings.repeat
    if not result or rep == 1:
        return result
    if getattr(settings, 'repeat_unit', 'VERSE') == 'RANGE':
        return result * rep if rep > 1 else result
    n = VERSE_LOOP if rep == 0 else rep
    out, i = [], 0
    while i < len(result):
        j = i
        while j < len(result) and result[j][0] == result[i][0]:
            j += 1
        out += result[i:j] * n          # 메아리(두 목소리)는 두 목소리째로 되풀이한다
        i = j
    return out


def selftest():
    s = PlaySettings()
    a = [(1, 'a1'), (2, 'a2')]
    ok = []
    ok.append(apply_repeat(a, s) == a)
    s.repeat = 2
    ok.append(apply_repeat(a, s) == [(1, 'a1'), (1, 'a1'), (2, 'a2'), (2, 'a2')])
    s.repeat_unit = 'RANGE'
    ok.append(apply_repeat(a, s) == a + a)
    s.repeat = 0
    ok.append(apply_repeat(a, s) == a)
    s.repeat_unit = 'VERSE'
    ok.append(len(apply_repeat(a, s)) == 2 * VERSE_LOOP)
    echo = [(1, 'a1'), (1, 'b1'), (2, 'a2'), (2, 'b2')]
    s.repeat = 2
    ok.append(apply_repeat(echo, s)[:4] == [(1, 'a1'), (1, 'b1'), (1, 'a1'), (1, 'b1')])
    print('voice_play_bar selftest %d/%d' % (sum(ok), len(ok)))
    return all(ok)


def default_source(db_path: str, verse_ids: list, version: str):
    """목소리를 아직 고르지 않았을 때 — 이 절들에 녹음이 가장 많은 (목소리, 역본).
    지금 역본에 녹음이 있으면 그것을 먼저 · 없으면 다른 역본 녹음이라도. 없으면 (None, None).
    ★ 2026-10-13 (docs/1.txt 74-1) — 목소리를 안 골랐으면 재생 목록이 비어 [▶] 가 아무 일도 안 했다."""
    vids = [int(v) for v in verse_ids or ()]
    if not vids:
        return None, None
    ph = ','.join('?' * len(vids))
    try:
        with appdb.connect(db_path) as conn:
            rows = conn.execute(
                'SELECT voice_owner, bible_version, COUNT(*) FROM user_voice_asset'
                ' WHERE verse_id IN (%s) GROUP BY voice_owner, bible_version' % ph, vids).fetchall()
    except Exception:
        return None, None
    if not rows:
        return None, None
    rows.sort(key=lambda r: (r[1] != version, -r[2]))
    return rows[0][0], rows[0][1]


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
