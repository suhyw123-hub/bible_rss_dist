# -*- coding: utf-8 -*-
"""CHAP_DESC(장 설명문) 초안 검증 · 적재 (영구 도구)

  python -X utf8 db_chap_load.py --check <draft.json>    # 검증만, DB 무변경
  python -X utf8 db_chap_load.py --apply <draft.json>    # 검증 + 적재 + 책 전체 재검사
  python -X utf8 db_chap_load.py --book 43               # 이미 적재된 책을 다시 검사

draft.json
{
  "book": 43,
  "chaps": { "21": {"KO": "...", "EN": "..."} }
}

문체 검사는 `db_peri_gate.check(kind='CHAP')` 를 그대로 쓴다(단일 소스). 페리코프와
갈리는 것은 분량 기준뿐이고, 딱딱함을 막는 규칙은 층이 달라도 같기 때문이다.

**본문 어휘 겹침은 실패로 걸지 않고 숫자만 띄운다**(chapter.md §8). 장 설명문은 구절을
인용할 일이 거의 없고 배경이 주력이라 어휘가 본래 갈린다 — 페리코프 상한(18%)을 그대로
가져오면 규칙이 아니라 장식이 된다. 대신 경고선(13%)을 넘으면 낱말을 찍어 준다.
"""
import argparse
import datetime
import io
import json
import re
import sys

import appdb
import db_peri_gate as g
import verse_tier

DB = 'bible_master.db'


def chap_span(conn, bcode, chapter):
    """(start_vid, end_vid, 마지막 절 번호). 없는 장이면 SystemExit."""
    r = conn.execute("SELECT MIN(verse_id), MAX(verse_id), MAX(verse) FROM bible_index "
                     "WHERE bcode=? AND chapter=?", (bcode, chapter)).fetchone()
    if not r or r[0] is None:
        raise SystemExit(f'bcode {bcode} {chapter}장이 bible_index 에 없다.')
    return r


def build_rows(conn, bcode, chaps):
    """게이트가 먹는 행 + 겹침용 vid 표. chaps = {chapter(int): {lang: text}}"""
    rows, vids = [], {}
    for ch in sorted(chaps):
        sv, ev, last = chap_span(conn, bcode, ch)
        key = verse_tier.chap_key(bcode, ch)
        ref = f'{bcode} {ch}:1-{ch}:{last}'
        vids[key] = (sv, ev)
        for lang in ('KO', 'EN'):
            t = (chaps[ch].get(lang) or '').strip()
            if not t:
                raise SystemExit(f'{bcode} {ch}장 {lang} 이 비어 있다.')
            # 제목 자리는 None — 장 설명문에는 제목이 없으므로 제목 재진술 검사가 꺼진다.
            rows.append((key, ref, None, None, lang, None, t))
    return rows, vids


def validate(conn, rows, vids, verbose=True):
    if verbose:
        for key in sorted({r[0] for r in rows}):
            bc, ch = verse_tier.chap_of_key(key)
            for lang in ('KO', 'EN'):
                t = next(r[6] for r in rows if r[0] == key and r[4] == lang)
                sents = [x for x in re.split(r'(?<=[.!?])\s+', t) if x.strip()]
                avg = len(t) / len(sents) if sents else 0
                extra = ''
                if lang == 'KO':
                    sv, ev = vids[key]
                    pct, hit = g.overlap_pct(conn, t, sv, ev)
                    extra = f' · 겹침 {pct}%'
                    if pct > g.OVERLAP_WARN:
                        extra += f' ⚠({" · ".join(hit)})'
                    # 서술 균형 — 목표 배경 0.3+ · 의미 1.5+ · 나열 1.0-
                    # 장 설명문은 배경(C 블록)이 주력이라 배경 수치를 특히 본다.
                    b, m, e = (len(p.findall(t)) / len(t) * 1000
                               for _, p, _, _ in g.BALANCE)
                    extra += f' · 배경 {b:.1f}/의미 {m:.1f}/나열 {e:.1f}'
                print(f'  {bc} {ch}장 {lang}: {len(t)}자 · {len(sents)}문장 · '
                      f'평균 {avg:.1f}자{extra}')
    bad = g.check(conn, rows, kind='CHAP') + pair_check(rows)
    if verbose and g.LAST_WARNS:
        print()
        for tag, msg in g.LAST_WARNS:
            print(f'  ! {tag}: {msg}')
    if bad:
        print(f'\n검증 FAIL — 위반 {len(bad)}건')
        for tag, msg in bad:
            print(f'  X {tag} {msg}')
        return False
    print('\n검증 PASS — 위반 0건')
    return True


def pair_check(rows):
    seen = {}
    for key, ref, *rest in rows:
        seen.setdefault((key, ref), set()).add(rest[2])
    return [(f'chap {key} [{ref}]', f'언어 누락 — 보유 {sorted(lg)}')
            for (key, ref), lg in seen.items() if lg != {'KO', 'EN'}]


def apply(conn, bcode, chaps):
    ts = datetime.date.today().isoformat() + 'T00:00:00'
    dele = ins = 0
    for ch in sorted(chaps):
        key = verse_tier.chap_key(bcode, ch)
        cur = conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? "
                           "AND text_type='CHAP_DESC'", (key,))
        dele += cur.rowcount
        for lang in ('KO', 'EN'):
            conn.execute(
                "INSERT INTO sys_text_asset (clicked_id, text_type, contents, lang_code, "
                "record_status, created_at, text_variant) VALUES (?,?,?,?,'LIVE',?,NULL)",
                (key, 'CHAP_DESC', chaps[ch][lang].strip(), lang, ts))
            ins += 1
    conn.commit()
    print(f'삭제 {dele}행 · 삽입 {ins}행')


def load_book(conn, bcode):
    """DB 에 적재된 그 책의 CHAP_DESC 를 검사용 행으로."""
    lo = verse_tier.chap_key(bcode, 0)
    hi = verse_tier.chap_key(bcode, verse_tier.CHAP_KEY_UNIT - 1)
    got = {}
    for key, lang, txt in conn.execute(
            "SELECT clicked_id, lang_code, contents FROM sys_text_asset "
            "WHERE text_type='CHAP_DESC' AND clicked_id BETWEEN ? AND ? "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (lo, hi)):
        got.setdefault(verse_tier.chap_of_key(key)[1], {})[lang] = txt
    return got


def coverage(conn, bcode):
    total = conn.execute("SELECT COUNT(DISTINCT chapter) FROM bible_index WHERE bcode=?",
                         (bcode,)).fetchone()[0]
    return total, len(load_book(conn, bcode))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', metavar='DRAFT')
    ap.add_argument('--apply', metavar='DRAFT')
    ap.add_argument('--book', type=int)
    a = ap.parse_args()
    conn = appdb.connect(DB)

    if a.book and not (a.check or a.apply):
        chaps = load_book(conn, a.book)
        if not chaps:
            print(f'bcode {a.book}: CHAP_DESC 없음'); sys.exit(0)
        rows, vids = build_rows(conn, a.book, chaps)
        total, done = coverage(conn, a.book)
        print(f'bcode {a.book}: {done}/{total}장 검사')
        sys.exit(0 if validate(conn, rows, vids) else 1)

    path = a.check or a.apply
    if not path:
        ap.error('--check / --apply / --book 중 하나가 필요하다')
    draft = json.loads(io.open(path, encoding='utf-8').read())
    bcode = draft['book']
    chaps = {int(k): v for k, v in draft['chaps'].items()}
    rows, vids = build_rows(conn, bcode, chaps)

    ok = validate(conn, rows, vids)
    if not ok or a.check:
        sys.exit(0 if ok else 1)

    print()
    apply(conn, bcode, chaps)
    total, done = coverage(conn, bcode)
    print(f'  bcode {bcode}: {done}/{total}장 완료')


if __name__ == '__main__':
    main()
