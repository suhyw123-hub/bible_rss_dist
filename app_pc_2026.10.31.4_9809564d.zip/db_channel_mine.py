# -*- coding: utf-8 -*-
"""채널 발굴 — 씨앗 낱말 · 발굴 이력 · 발굴 결과 (영구 도구)

2026-09-06 신설. 사용자 지시:
  「채널발굴 탭의 구조를 이런 흐름으로 재설계하라. 제목만 보고 판단하기
   힘들었다. 그리고 발굴한 후 사라지는 것도 말이 안된다. 키워드별로 스크린
   한 이력을 관리해야 다른 키워드와 공평하게 발굴할 수 있다.」

★ 세 가지를 담는다 — 그전에는 셋 다 없었다:
  ① **씨앗 낱말**  어느 낱말로 발굴할까(`media_taxonomy` 380개 중 고른 것)
  ② **발굴 이력**  그 낱말을 언제 돌았고 무엇을 얻었나 → **공평한 차례**
  ③ **발굴 결과**  찾은 채널을 담아 둔다 — `_cands` 메모리 dict 라
     탭을 나가면 통째로 사라지던 것(사용자 지적)

⚠ **화면이 SQL 을 직접 쓰지 않는다** — 그러면 「발굴 실행」과 「결과 목록」이
  서로 다른 규칙을 쓰게 된다(§95차 사고). 이 모듈이 단일 소스다.

⚠ **씨앗 낱말을 여기서 새로 적지 않는다** — `media_taxonomy` 의 11언어 380개가
  이미 실측으로 다듬어진 것이다(§203차). 여기서는 **그중 무엇을 씨앗으로
  쓸지**만 정한다. 낱말을 두 곳에 적으면 한쪽만 고쳐진다.

⚠ 네트워크를 쓰지 않는다 — 실제 발굴은 화면이 `db_yt_rss_collect`·YouTube API 로
  하고, 이 모듈은 **무엇을 돌지 정하고 결과를 담는다**.
"""
from __future__ import annotations

import sys
import sqlite3

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

# ── 낱말 — 화면 전부가 이 표를 쓴다 (2026-09-09 사용자 「용어의 일관성을 지켜라」)
#   ★ **「발굴」 하나다.** 그전에는 탭 이름은 「채널 발굴」인데 실행 탭은 「채굴」이라
#     같은 일에 낱말이 둘이었다. 채널을 찾는 일 전체 = 발굴, 그 한 번의 실행도 발굴.
#   ★ 채널에 대한 판단 셋은 뜻이 다르다 — 갈라 쓴다:
#     · ~~제외~~   **폐기**(2026-09-09 사용자 확정 「제외 개념 제거한다」) — 발굴에서만
#                  빼고 수집은 계속하던 중간 상태였다. 실측 제외한 채널의 영상 9편이
#                  살아 있어 「제외했는데 계속 담긴다」는 모순이 났다. **차단이 흡수**한다.
#     · **수집 멈춤** 채널 목록에 두되 당분간 안 담는다(`sys_media_channel.enabled=0`)
#     · **차단**   모든 수집 경로에서 거른다(`sys_media_excluded_channel` — RSS·
#                  구절·용어 수집기·저밀도·최신 발행 전부. 옛 이름 「완전차단」)
WORDS = {
    # ★ 2026-09-16 1.txt 17-1 (4) 사용자 — 「발굴 결과」→「기존 수집분 재심사」
    #   (이미 찾은 후보를 다시 심사하는 자리다 · 발굴 실행 = 새로 찾기 + 즉시 심사).
    'mine': '발굴', 'seed': '씨앗 낱말', 'result': '기존 수집분 재심사',
    'assign': '지정', 'unassign': '지정 해제',
    'register': '채널 등록', 'hold': '보류', 'block': '차단',
    'pause': '수집 멈춤', 'resume': '수집 재개',
}

# ── 상태 ───────────────────────────────────────────────────────────────
ST_NEW = 'NEW'        # 발굴됨 · 아직 판단 안 함
ST_REG = 'REG'        # 등록함(sys_media_channel 로 갔다)
ST_BLOCK = 'BLOCK'    # 차단함 — 모든 수집 경로에서 거른다
ST_SKIP = 'SKIP'      # 보류 — 나중에 다시 본다
STATUSES = (ST_NEW, ST_REG, ST_BLOCK, ST_SKIP)
#: 옛 이름 — DB 에 'REJ' 로 남은 행이 있을 수 있다(`migrate_reject` 가 옮긴다).
ST_REJ = ST_BLOCK

ST_NAME = {
    ST_NEW: '미검토',
    ST_REG: '등록함',
    ST_BLOCK: '차단함',
    ST_SKIP: '보류',
}

# 씨앗 후보를 뽑을 분류 — 「기독교 채널인가」를 가리는 데 쓸 만한 것만.
# ⚠ KIDS 는 뺀다 — 그것은 채널을 찾는 낱말이 아니라 이미 담은 것을 가르는 낱말이다.
SEED_CATS = ('SERMON', 'WORSHIP', 'STUDY')


# ── 스키마 ─────────────────────────────────────────────────────────────
_DDL = [
    """CREATE TABLE IF NOT EXISTS sys_mine_keyword (
         kw_id     INTEGER PRIMARY KEY AUTOINCREMENT,
         lang      TEXT NOT NULL,
         kw        TEXT NOT NULL,
         enabled   INTEGER NOT NULL DEFAULT 0,
         last_run  TEXT,
         n_run     INTEGER NOT NULL DEFAULT 0,
         n_seen    INTEGER NOT NULL DEFAULT 0,
         n_new     INTEGER NOT NULL DEFAULT 0,
         note      TEXT,
         domain    TEXT NOT NULL DEFAULT 'COMMON',
         UNIQUE (lang, kw))""",
    """CREATE TABLE IF NOT EXISTS sys_mine_channel (
         channel_id TEXT PRIMARY KEY,
         title      TEXT,
         descr      TEXT,
         lang       TEXT,
         found_by   TEXT,
         found_at   TEXT,
         seen_at    TEXT,
         n_hit      INTEGER NOT NULL DEFAULT 1,
         subs       INTEGER,
         n_video    INTEGER,
         last_video TEXT,
         samples    TEXT,
         status     TEXT NOT NULL DEFAULT 'NEW',
         note       TEXT)""",
    "CREATE INDEX IF NOT EXISTS idx_mine_ch_st ON sys_mine_channel(status, lang)",
    "CREATE INDEX IF NOT EXISTS idx_mine_kw_run ON sys_mine_keyword(lang, enabled, last_run)",
]


def init(conn) -> None:
    """표를 만든다(멱등)."""
    for sql in _DDL:
        conn.execute(sql)
    # ★★★ **분야 칸**(2026-09-10) — 씨앗은 「무엇을 찾나」를 묻는 층이라
    #   분야를 탄다. `COMMON` 331개는 그대로 있고 겨냥 낱말만 분야를 갖는다.
    #   ⚠ 옛 DB 에 칸을 붙인다 — `ALTER` 는 있으면 터지므로 먼저 센다.
    try:
        have = {r[1] for r in conn.execute("PRAGMA table_info(sys_mine_keyword)")}
        if 'domain' not in have:
            conn.execute("ALTER TABLE sys_mine_keyword"
                         " ADD COLUMN domain TEXT NOT NULL DEFAULT 'COMMON'")
    except Exception:
        pass
    conn.commit()


def _has(conn, tbl: str) -> bool:
    r = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (tbl,)
    ).fetchone()
    return bool(r)


def _now(conn) -> str:
    return conn.execute("SELECT datetime('now','localtime')").fetchone()[0]


# ── ① 씨앗 낱말 ─────────────────────────────────────────────────────────
def seed_candidates(lang: str, db_path=None, conn=None):
    """그 언어로 쓸 수 있는 씨앗 후보를 낸다 — `media_taxonomy` 에서 가져온다.

    ★ COMMON 버킷을 함께 준다 — 그것이 영어를 담고 **모든 언어에 걸린다**
      (§203차). 그래서 EN 버킷을 따로 안 만들었다.
    ⚠⚠ **`load_classify_sets` 는 연결을 받는다.** 예전에는 여기에 파일 경로를
      그대로 넘겨 예외가 나고 **코드 기본값 낱말표로 조용히 물러섰다** — 키워드
      규칙 화면에서 고친 낱말이 씨앗에 한 번도 안 왔다(2026-09-08 실측: DB 에서
      뺀 「경배와찬양·답사」가 들어오고 더한 「성지순례」는 안 왔다). 이제 연결을
      받고, 경로면 여기서 연다. 둘 다 없으면 기본값.
    """
    try:
        import media_taxonomy as MT
    except Exception:
        return []
    sets, own = None, None
    try:
        if conn is None and db_path:
            own = sqlite3.connect(db_path)
            conn = own
        sets = MT.load_classify_sets(conn) if conn is not None else MT.DEFAULT_CLASSIFY_KW
    except Exception:
        sets = MT.DEFAULT_CLASSIFY_KW
    finally:
        if own is not None:
            try:
                own.close()
            except Exception:
                pass
    out, seen = [], set()
    for cat in SEED_CATS:
        buckets = sets.get(cat) or {}
        if not isinstance(buckets, dict):
            continue
        # ★ COMMON(영어 낱말)은 **EN 씨앗에만** 넣는다(2026-09-09 사용자 「일반적
        #   용어들이 너무 많다」). 분류(담은 뒤 이름표)에서는 영어가 모든 언어에
        #   걸려도 되지만 발굴(찾기)에서는 「devotional」로 한국 채널을 못 찾는다 —
        #   실측 KO 씨앗 54개 중 영어 31개가 그렇게 섞여 들어와 있었다.
        for bk in (('COMMON', lang) if str(lang).upper() == 'EN' else (lang,)):
            for w in (buckets.get(bk) or []):
                w = (w or '').strip()
                if w and w.lower() not in seen:
                    seen.add(w.lower())
                    out.append(w)
    return out


def sync_seeds(conn, lang: str, db_path=None) -> int:
    """후보를 표에 담는다(멱등 · **켜지는 않는다**).

    ⚠ 새 낱말을 저절로 켜지 않는다 — 켜는 순간 쿼터를 쓴다.
      사람이 골라서 켠다.
    """
    init(conn)
    n = 0
    for w in seed_candidates(lang, conn=conn):
        cur = conn.execute(
            "INSERT OR IGNORE INTO sys_mine_keyword (lang, kw) VALUES (?, ?)",
            (lang, w),
        )
        n += cur.rowcount or 0
    conn.commit()
    return n


def add_keyword(conn, lang: str, kw: str, enabled: bool = True,
                domain: str = None) -> int:
    """사람이 손으로 낱말을 더한다(분류 낱말에 없는 것도 쓸 수 있어야 한다).

    ⚠ `domain` — **분야별 씨앗**(§237차). 안 주면 공통(`COMMON`)이다.
      찬양 검색어를 공통에 넣으면 구절·용어 수집까지 그 말로 돌게 된다.
    """
    kw = (kw or '').strip()
    if not kw:
        return 0
    init(conn)
    conn.execute(
        "INSERT OR IGNORE INTO sys_mine_keyword (lang, kw, enabled, domain)"
        " VALUES (?,?,?,?)",
        (lang, kw, 1 if enabled else 0, (domain or 'COMMON')),
    )
    if enabled:
        conn.execute(
            "UPDATE sys_mine_keyword SET enabled=1 WHERE lang=? AND kw=?",
            (lang, kw),
        )
    conn.commit()
    r = conn.execute(
        "SELECT kw_id FROM sys_mine_keyword WHERE lang=? AND kw=?", (lang, kw)
    ).fetchone()
    return int(r[0]) if r else 0


def set_enabled(conn, kw_ids, on: bool) -> int:
    """지정/지정 해제. ★ 다시 지정하면 **자동 해제 표식을 걷고 횟수를 0 부터** 센다 —
    안 그러면 `record_run` 이 그 자리에서 다시 푼다(2026-09-16)."""
    if on and kw_ids:
        try:
            ids = [int(k) for k in kw_ids]
            conn.execute("UPDATE sys_mine_keyword SET n_run=0, n_seen=0, n_new=0, "
                         "note=NULLIF(TRIM(REPLACE(REPLACE(COALESCE(note,''), ' · '||?, ''), ?, '')), '') "
                         "WHERE kw_id IN (%s) AND n_run>=? AND n_new=0" % ','.join('?' * len(ids)),
                         [AUTO_OFF_NOTE % AUTO_OFF_RUNS, AUTO_OFF_NOTE % AUTO_OFF_RUNS] + ids + [AUTO_OFF_RUNS])
        except Exception:
            pass
    return _set_enabled(conn, kw_ids, on)


def _set_enabled(conn, kw_ids, on: bool) -> int:
    if not kw_ids:
        return 0
    q = ','.join('?' * len(kw_ids))
    cur = conn.execute(
        "UPDATE sys_mine_keyword SET enabled=? WHERE kw_id IN (%s)" % q,
        [1 if on else 0] + list(kw_ids),
    )
    conn.commit()
    return cur.rowcount or 0


def delete_keyword(conn, kw_ids) -> int:
    """씨앗을 지운다 — 발굴 표(`sys_mine_channel.found_by`)는 남는다(이력).

    ★ 지울지는 `keyword_outcomes` 가 근거다(사용자 「제거할 필요가 있는지 여부를
      어떻게 판단하는가? 그 단어로 수집한 결과 … 통계를 보여주어야」).
    """
    if not kw_ids:
        return 0
    q = ','.join('?' * len(kw_ids))
    cur = conn.execute("DELETE FROM sys_mine_keyword WHERE kw_id IN (%s)" % q,
                       list(kw_ids))
    conn.commit()
    return cur.rowcount or 0


def keyword_outcomes(conn):
    """낱말 → {상태: 채널 수} — 그 낱말이 물어 온 채널이 어떻게 판단됐나.

    ★ 「본 채널·새로 찾음」은 양이고 이것은 **질**이다 — 등록이 0 이고 제외만
      쌓이는 낱말은 지울 근거가 된다. 재료는 발굴 표의 `found_by`.
    """
    out = {}
    if not _has(conn, 'sys_mine_channel'):
        return out
    for kw, st, n in conn.execute(
            "SELECT COALESCE(found_by,''), status, COUNT(*) FROM sys_mine_channel "
            "GROUP BY 1, 2"):
        out.setdefault(kw, {})[st] = int(n)
    return out


def seed_counts(conn):
    """언어 → (낱말 수, 지정 수) — 언어 줄(배지)이 쓴다."""
    out = {}
    if not _has(conn, 'sys_mine_keyword'):
        return out
    for lang, n, on in conn.execute(
            "SELECT lang, COUNT(*), SUM(enabled) FROM sys_mine_keyword GROUP BY lang"):
        out[str(lang).upper()] = (int(n), int(on or 0))
    return out


def translate_seeds(conn, kw_ids, target: str, translator=None):
    """지정한 씨앗을 다른 언어로 옮겨 **꺼진 채로** 담는다 → (담은 수, 못 옮긴 낱말).

    ★ 사용자 「이것(정비한 KO 씨앗)을 다국어 모드로 입력하라」의 도구. 기계 번역은
      초안일 뿐이라 켜지 않는다 — 그 나라 채널 제목의 실제 표기를 보고 사람이 켠다.
    ⚠ 번역기는 밖에서 받는다(`admin_translate.translate`) — 이 모듈은 네트워크를 안 쓴다.
    """
    if not kw_ids or not target:
        return 0, []
    target = str(target).upper()
    if translator is None:
        try:
            import admin_translate as AT
            translator = lambda t, tl, sl: AT.translate(t, target=tl, src=sl)
        except Exception:
            return 0, ['(번역기 없음)']
    q = ','.join('?' * len(kw_ids))
    rows = conn.execute("SELECT kw, lang FROM sys_mine_keyword WHERE kw_id IN (%s)" % q,
                        list(kw_ids)).fetchall()
    n, miss = 0, []
    for kw, src in rows:
        if str(src).upper() == target:
            continue
        try:
            got = translator(kw, target, src)
        except Exception:
            got = None
        got = (got or '').strip()
        if not got:
            miss.append(kw)
            continue
        if got.lower() == str(kw).lower():
            # ★ 번역이 제 말과 같다 = **이미 그 언어의 말**이다(KO 칸에 든 'sermon').
            #   2026-09-16 · 1.txt 17번 사용자 「KO 로 분류한 씨앗낱말 중 영어로 된 것을
            #   EN 으로 옮기기 하려고 하는데 안된다」 — 그전에는 이것을 실패로 셌다.
            #   ⇒ 줄을 **그 언어로 옮긴다**(칸만 바꾼다). 대상에 같은 말이 이미 있으면
            #     합친다 — 켜짐은 둘 중 하나라도 켜져 있으면 켜진 것으로, 돈 횟수는 더한다.
            kid = conn.execute("SELECT kw_id FROM sys_mine_keyword WHERE kw=? AND lang=?",
                               (kw, src)).fetchone()
            dup = conn.execute("SELECT kw_id FROM sys_mine_keyword WHERE lower(kw)=lower(?) AND lang=?",
                               (kw, target)).fetchone()
            if kid is None:
                miss.append(kw)
                continue
            if dup:
                conn.execute("UPDATE sys_mine_keyword SET enabled=MAX(COALESCE(enabled,0),"
                             " (SELECT COALESCE(enabled,0) FROM sys_mine_keyword WHERE kw_id=?)),"
                             " n_run=COALESCE(n_run,0)+(SELECT COALESCE(n_run,0) FROM sys_mine_keyword WHERE kw_id=?),"
                             " n_seen=COALESCE(n_seen,0)+(SELECT COALESCE(n_seen,0) FROM sys_mine_keyword WHERE kw_id=?),"
                             " n_new=COALESCE(n_new,0)+(SELECT COALESCE(n_new,0) FROM sys_mine_keyword WHERE kw_id=?)"
                             " WHERE kw_id=?", (kid[0], kid[0], kid[0], kid[0], dup[0]))
                conn.execute("DELETE FROM sys_mine_keyword WHERE kw_id=?", (kid[0],))
            else:
                conn.execute("UPDATE sys_mine_keyword SET lang=?, note=COALESCE(note,'')||? WHERE kw_id=?",
                             (target, ' [칸 옮김 ← %s]' % src, kid[0]))
            n += 1
            continue
        cur = conn.execute("INSERT OR IGNORE INTO sys_mine_keyword (lang, kw, enabled, note) "
                           "VALUES (?,?,0,?)", (target, got, '옮김 ← %s:%s' % (src, kw)))
        n += cur.rowcount or 0
    conn.commit()
    return n, miss


def keywords(conn, lang: str = None, only_on: bool = False, domain: str = None):
    """씨앗 목록 — **공평한 차례로** 낸다(안 돈 것 먼저 · 오래된 것 먼저).

    ★★ `domain` — 안 주면 **전부**(옛 동작). 주면 그 분야 + `COMMON`.
      ⚠ 「그 분야만」이 아니라 **공통을 함께** 낸다 — 공통 낱말은 어느 분야에서
        찾아도 쓸모가 있고, 분야별 표를 통째로 복제하면 갈라진다.
    """
    if not _has(conn, 'sys_mine_keyword'):
        return []
    col = ('domain' if 'domain' in
           {r[1] for r in conn.execute("PRAGMA table_info(sys_mine_keyword)")}
           else "'COMMON'")
    sql = ("SELECT kw_id, lang, kw, enabled, last_run, n_run, n_seen, n_new,"
           " note, %s FROM sys_mine_keyword WHERE 1=1" % col)
    args = []
    if lang:
        sql += " AND lang=?"
        args.append(lang)
    if only_on:
        sql += " AND enabled=1"
    if domain and col == 'domain':
        sql += " AND (domain=? OR domain='COMMON')"
        args.append(str(domain).upper())
    sql += " ORDER BY (last_run IS NOT NULL), last_run, kw"
    return [dict(zip(
        ('kw_id', 'lang', 'kw', 'enabled', 'last_run', 'n_run', 'n_seen',
         'n_new', 'note', 'domain'), r
    )) for r in conn.execute(sql, args).fetchall()]


def next_keywords(conn, lang: str, n: int = 5, domain: str = None):
    """이번에 돌 낱말 — **가장 오래 안 돈 것부터**.

    ★ 이것이 「공평한 발굴」이다(사용자 지시). 목록 차례대로 돌면 앞의 낱말만
      계속 돌고 뒤는 영영 안 돈다 — §194차 균형 수집과 같은 자리다.
    """
    return keywords(conn, lang, only_on=True,
                    domain=domain)[:max(0, int(n or 0))]


#: ★ 씨앗 자기 교정(2026-09-16 사용자 「불필요하게 반복 수집하는 데이터가 있다면 수집
#:   키워드 자체를 수정해야 한다」) — **이 횟수를 돌아 새것이 0 이면 지정을 푼다.**
#:   실측 성경듣기 씨앗 14개가 27번 돌아 675편을 보고 **새것 0**(첫 쪽 25편 중 21편이
#:   이미 있는 영상) — 검색 한 번 100 units 를 그냥 버리고 있었다. 사람이 다시 지정하면
#:   횟수가 0 부터다.
AUTO_OFF_RUNS = 3
AUTO_OFF_NOTE = '자동 지정 해제 — %d번 돌아 새것 0'


def record_run(conn, kw_id: int, seen: int, new: int) -> None:
    """돈 사실을 남긴다 — **0건이어도 남긴다**(그것이 이 표의 존재 이유다).
    ★ 그리고 `AUTO_OFF_RUNS` 번 돌아 새것이 0 이면 **지정을 푼다**(note 에 까닭) →
      다음 바퀴가 그 낱말을 건너뛰고 다른 낱말이 돈다. 되돌리기 = 사람이 다시 지정."""
    conn.execute(
        "UPDATE sys_mine_keyword SET last_run=datetime('now','localtime'), "
        "n_run=n_run+1, n_seen=n_seen+?, n_new=n_new+? WHERE kw_id=?",
        (int(seen or 0), int(new or 0), int(kw_id)),
    )
    auto_off(conn, kw_id)
    conn.commit()


def auto_off(conn, kw_id=None) -> int:
    """`AUTO_OFF_RUNS` 번 이상 돌아 새것 0 인 지정 낱말을 푼다 → 푼 수. `kw_id` 없으면 전부."""
    sql = ("UPDATE sys_mine_keyword SET enabled=0, "
           "note=CASE WHEN COALESCE(note,'')='' THEN ? ELSE note||' · '||? END "
           "WHERE enabled=1 AND n_run>=? AND n_new=0")
    args = [AUTO_OFF_NOTE % AUTO_OFF_RUNS, AUTO_OFF_NOTE % AUTO_OFF_RUNS, AUTO_OFF_RUNS]
    if kw_id is not None:
        sql += " AND kw_id=?"
        args.append(int(kw_id))
    cur = conn.execute(sql, args)
    return cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0


# ── ② 발굴 결과 ─────────────────────────────────────────────────────────
def known_ids(conn):
    """이미 판단이 끝난 채널 — 등록·제외 + 발굴 표의 것.

    ⚠ **등록·제외 표를 함께 본다** — 그것을 안 보면 이미 쓰는 채널을 매번
      「새로 찾았다」고 낸다.
    ⚠⚠ **칼럼 이름을 짐작하지 말 것**(2026-09-07 실측으로 잡았다) —
      `sys_media_channel.channel_id` 는 **내부 PK** 이고 유튜브 채널 id 는
      `channel_ext_id` 다. PK 를 읽으면 절대 안 맞아 **조용히 0건**이 된다.
    ⚠ `sys_media_excluded_channel` 에는 **채널 id 칸이 아예 없다** —
      이름으로 거른다(§203차). 축이 달라 여기서는 안 본다.
    """
    out = set()
    for tbl, col in (('sys_media_channel', 'channel_ext_id'),
                     ('sys_media_rejected_channel', 'channel_ext_id')):
        if not _has(conn, tbl):
            continue
        try:
            for (cid,) in conn.execute(
                "SELECT %s FROM %s WHERE %s IS NOT NULL" % (col, tbl, col)
            ):
                if cid:
                    out.add(str(cid).strip())
        except Exception:
            pass
    return out


def migrate_reject(conn, db_path=None) -> tuple:
    """옛 「제외」를 차단으로 흡수한다 → (옮긴 수, 이미 있던 수). 멱등.

    2026-09-09 사용자 확정 「제외 개념 제거한다」. 옛 표(`sys_media_rejected_channel`)는
    **지우지 않고** 읽지 않는다 — 되돌릴 근거로 남긴다.
    ⚠ 등록된 채널은 안 옮긴다(등록이 더 나중 판단이다).
    ⚠ 발굴 표의 옛 상태 'REJ' 도 함께 'BLOCK' 으로 바꾼다."""
    init(conn)
    if not _has(conn, 'sys_media_rejected_channel'):
        return (0, 0)
    moved = dup = 0
    have_id = blocked_ids(conn)
    have_nm = blocked_names(conn)
    reg = {r[0] for r in conn.execute(
        "SELECT channel_ext_id FROM sys_media_channel WHERE record_status='LIVE'") if r[0]} \
        if _has(conn, 'sys_media_channel') else set()
    for cid, nm, note, when in conn.execute(
            "SELECT channel_ext_id, channel_name, COALESCE(note,''), COALESCE(rejected_at,'')"
            " FROM sys_media_rejected_channel WHERE record_status='LIVE'").fetchall():
        cid = (cid or '').strip()
        nm = (nm or cid or '').strip()
        if not nm or cid in reg:
            continue
        if (cid and cid in have_id) or nm.lower() in have_nm:
            dup += 1
            continue
        conn.execute(
            "INSERT INTO sys_media_excluded_channel (channel_name, reason_code, reason_detail,"
            " excluded_at, excluded_by, record_status, channel_ext_id) VALUES (?,?,?,?,?,?,?)",
            (nm, 'OTHER', ('옛 제외 이관' + ((' · ' + note) if note else '')),
             when or _now(conn)[:10], 'MIGRATE', 'LIVE', cid or None))
        if cid:
            have_id.add(cid)
        have_nm.add(nm.lower())
        moved += 1
    conn.execute("UPDATE sys_mine_channel SET status=? WHERE status='REJ'", (ST_BLOCK,))
    conn.commit()
    return (moved, dup)


def blocked_ids(conn):
    """차단 채널의 유튜브 id 집합 — `sys_media_excluded_channel.channel_ext_id`.

    ⚠ 그 표는 원래 **이름**으로만 막았다(id 칸이 없었다). 2026-09-09 에 id 칸을
      더해 여기서 차단한 채널이 발굴에 「미검토」로 다시 올라오지 않게 한다.
      옛 행(id 없음)은 이름으로만 거른다 — `blocked_names`.
    """
    out = set()
    if not _has(conn, 'sys_media_excluded_channel'):
        return out
    try:
        for (cid,) in conn.execute(
                "SELECT channel_ext_id FROM sys_media_excluded_channel "
                "WHERE COALESCE(record_status,'LIVE')='LIVE' AND channel_ext_id IS NOT NULL"):
            if cid:
                out.add(str(cid).strip())
    except Exception:
        pass
    return out


def blocked_names(conn):
    out = set()
    if not _has(conn, 'sys_media_excluded_channel'):
        return out
    try:
        for (nm,) in conn.execute(
                "SELECT channel_name FROM sys_media_excluded_channel "
                "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            if nm:
                out.add(str(nm).strip().lower())
    except Exception:
        pass
    return out


def channel_kw_hit(lang, *texts, db_path=None):
    """채널 거르는 말(`media_exclude.CHANNEL_KW_LANG`)에 걸리나 → 낱말 또는 None.
    발굴 후보의 이름·설명·표본 제목을 함께 본다. **수집 문지기와 같은 문**."""
    try:
        import media_exclude as MX
        txt = chr(10).join(str(t) for t in texts if t)
        if not txt.strip():
            return None
        kw = {}
        if db_path:
            kw = MX.get_channel_map(db_path)
        else:
            kw = MX.get_channel_map()
        return MX.match_channel(txt, kw_list=kw, lang=(lang or None))
    except Exception:
        return None


def apply_channel_kw(conn, db_path=None) -> int:
    """미검토·보류 후보를 채널 거르는 말로 다시 훑어 걸린 것을 **제외**로(사유 = 낱말).
    낱말을 늘린 뒤 [거르는 말 다시 적용]이 부른다. 돌려주는 값 = 바뀐 수."""
    init(conn)
    n = 0
    for r in conn.execute("SELECT channel_id, title, descr, samples, lang FROM sys_mine_channel "
                          "WHERE status IN (?,?)", (ST_NEW, ST_SKIP)).fetchall():
        hit = channel_kw_hit(r[4], r[1], r[2], r[3], db_path=db_path)
        if hit:
            conn.execute("UPDATE sys_mine_channel SET status=?, note=? WHERE channel_id=?",
                         (ST_BLOCK, '거르는 말: %s' % hit, r[0]))
            n += 1
    conn.commit()
    return n


def upsert_channel(conn, channel_id: str, title: str = None, descr: str = None,
                   lang: str = None, found_by: str = None, **extra) -> str:
    """발굴 결과를 담는다. 돌려주는 값 = `'NEW'`(처음) 또는 `'DUP'`(이미 있음).

    ⚠ **이미 있으면 덮어쓰지 않는다** — 사람이 정한 status·note 를 지우면 안 된다.
      다시 만난 사실은 `n_hit` 와 `seen_at` 이 적는다(그 낱말이 잘 걸린다는 증거다).
    """
    channel_id = (channel_id or '').strip()
    if not channel_id:
        return 'DUP'
    init(conn)
    row = conn.execute(
        "SELECT 1 FROM sys_mine_channel WHERE channel_id=?", (channel_id,)
    ).fetchone()
    if row:
        conn.execute(
            "UPDATE sys_mine_channel SET n_hit=n_hit+1, "
            "seen_at=datetime('now','localtime') WHERE channel_id=?", (channel_id,)
        )
        conn.commit()
        return 'DUP'
    note = None
    if channel_id in blocked_ids(conn) or (
            title and title.strip().lower() in blocked_names(conn)):
        st, note = ST_BLOCK, WORDS['block']        # 차단된 채널은 후보가 아니다
    elif channel_kw_hit(lang, title, descr, extra.get('samples'), db_path=extra.get('db_path')):
        # ★ 이단·타종교 단체 표기 — 후보에 안 올리고 제외로 담는다(사유 = 낱말).
        #   목록에서 사라지지 않고 「제외 채널」 탭에서 사람이 뒤집을 수 있다.
        st, note = ST_BLOCK, '거르는 말: %s' % channel_kw_hit(
            lang, title, descr, extra.get('samples'), db_path=extra.get('db_path'))
    elif channel_id in known_ids(conn):
        st = ST_REG
    else:
        st = ST_NEW
    conn.execute(
        "INSERT INTO sys_mine_channel (channel_id, title, descr, lang, found_by, "
        "found_at, seen_at, subs, n_video, last_video, samples, status, note) "
        "VALUES (?,?,?,?,?, datetime('now','localtime'), datetime('now','localtime'), "
        "?,?,?,?,?,?)",
        (channel_id, title, descr, lang, found_by,
         extra.get('subs'), extra.get('n_video'), extra.get('last_video'),
         extra.get('samples'), st, note),
    )
    conn.commit()
    return 'NEW'


def fill_profile(conn, channel_id: str, **kw) -> None:
    """판단 재료를 채운다 — 설명문 · 최근 제목 · 구독자 수.

    ★ **이것이 「제목만 보고 판단하기 힘들다」의 답**이다(사용자 지시).
      RSS 는 쿼터 0으로 설명문과 최근 15개 제목을 준다.
    ⚠ **빈 값으로 덮지 않는다** — 한 번 채운 것을 다음 조회가 지우면 안 된다.
    """
    sets, args = [], []
    for col in ('descr', 'subs', 'n_video', 'last_video', 'samples', 'title', 'lang'):
        if col in kw and kw[col] not in (None, ''):
            sets.append('%s=?' % col)
            args.append(kw[col])
    if not sets:
        return
    args.append(channel_id)
    conn.execute(
        "UPDATE sys_mine_channel SET %s WHERE channel_id=?" % ','.join(sets), args
    )
    # ★ 재료가 채워지면 채널 거르는 말을 다시 본다 — 이름에는 없고 설명·표본
    #   제목에만 단체 표기가 있는 채널(몰몬 일본어 채널의 실태)이 그때 걸린다.
    #   미검토·보류만 — 사람이 등록·제외한 것은 안 건드린다.
    try:
        r = conn.execute("SELECT title, descr, samples, lang, status FROM sys_mine_channel "
                         "WHERE channel_id=?", (channel_id,)).fetchone()
        if r and r[4] in (ST_NEW, ST_SKIP):
            hit = channel_kw_hit(r[3], r[0], r[1], r[2], db_path=kw.get('db_path'))
            if hit:
                conn.execute("UPDATE sys_mine_channel SET status=?, note=? WHERE channel_id=?",
                             (ST_BLOCK, '거르는 말: %s' % hit, channel_id))
    except Exception:
        pass
    conn.commit()


# ── 채널 자동 발굴 한 바퀴 (2026-09-16 · 1.txt 17-1 (3) 「채널자동수집 기능」) ──
#: 켜고 끄기 · 한 바퀴에 돌릴 씨앗 수(검색 한 번 = search.list 100 units)
DISCOVER_ON_KEY = 'CHANNEL_DISCOVER_ON'
DISCOVER_N_KEY = 'CHANNEL_DISCOVER_KW'
DISCOVER_DEFAULT_N = 5
AUTO_TAG = '자동'       # found_by 앞에 붙여 사람이 돌린 것과 가른다
VET_NOTE = '자동심사'   # note 앞말 — 후보 표의 「사유·메모」에 등급·까닭이 보인다


def _cfg(conn, key, default=None):
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (key,)).fetchone()
        return r[0] if r and r[0] not in (None, '') else default
    except Exception:
        return default


def discover_plan(conn, n=None):
    """이번 바퀴에 돌 씨앗 — **지정된 COMMON 낱말** 가운데 오래 안 돈 것부터,
    언어를 번갈아 뽑는다(한 언어가 몫을 독식하지 않게 — §242차 찬양 한 바퀴와 같은 결).

    ✅ 실측(2026-09-16) COMMON 305개 중 **296개가 한 번도 안 돌았다** — 사람이 씨앗을
      골라 [발굴 실행]을 눌러야 돌았기 때문이다. 이 문이 그 물음의 답이다.
    """
    init(conn)
    try:
        n = int(n if n is not None else _cfg(conn, DISCOVER_N_KEY, DISCOVER_DEFAULT_N))
    except Exception:
        n = DISCOVER_DEFAULT_N
    rows = [r for r in keywords(conn, only_on=True, domain='COMMON')
            if (r.get('domain') or 'COMMON') == 'COMMON']
    rows.sort(key=lambda r: (r.get('last_run') is not None, r.get('last_run') or '', r.get('n_run') or 0))
    by = {}
    for r in rows:
        by.setdefault(r['lang'], []).append(r)
    langs = sorted(by, key=lambda L: (by[L][0].get('last_run') is not None, by[L][0].get('last_run') or ''))
    out = []
    while len(out) < n and any(by.values()):
        for L in langs:
            if by[L] and len(out) < n:
                out.append(by[L].pop(0))
    return out


def auto_discover(conn, keys, n=None, log=print, search_fn=None, feed_fn=None,
                  judge_fn=None, sleep=1.0, db_path=None):
    """★★★ **채널 자동 발굴 한 바퀴** — 씨앗 몇 개로 새 채널을 찾아 후보에 담고 **즉시
    심사**한다. **등록은 하지 않는다** — 후보 표(`sys_mine_channel`)에 `found_by='자동:낱말'`
    · `note='자동심사 등급 — 까닭'` 으로 남아 사람이 「기존 수집분 재심사」에서 본다.

    ★ 자동 등록을 안 하는 까닭 — §249차 ③ 한 편이 우연히 걸린 채널을 등록했더니 기타
      장비 리뷰·세속 음악 믹스가 들어왔다. 심사 등급은 재료이지 결정이 아니다.
    ⚠ 쿼터 — 씨앗 하나 = `search.list` **100 units**. 기본 5개(500). 켜고 끄기는
      `sys_config[CHANNEL_DISCOVER_ON]`, 개수는 `[CHANNEL_DISCOVER_KW]`.
    ⚠ RSS 는 쉬어 가며(§251차 ④ — 몰아치면 404/500) · 「돌았다」는 0건이어도 남긴다.
    ⚠ 시험용 주입 — `search_fn(kw, key, relevance_lang, max_results)` → (items, token, err) ·
      `feed_fn(cid)` → feed dict · `judge_fn(conn, cid, lang, titles)` → (grade, why).
    """
    import time as _t
    if str(_cfg(conn, DISCOVER_ON_KEY, '1')).strip() in ('0', 'off', 'OFF'):
        log('  [채널 발굴] 꺼져 있습니다(sys_config %s=0).' % DISCOVER_ON_KEY)
        return {'skipped': 'OFF'}
    plan = discover_plan(conn, n)
    out = {'kw': len(plan), 'seen': 0, 'new': 0, 'vetted': 0, 'units': 0,
           'grades': {}, 'err': [], 'rows': []}
    if not plan:
        log('  [채널 발굴] 지정된 씨앗 낱말이 없습니다 — ① 채널 ▸ 낱말 관리에서 지정하세요.')
        return out
    if search_fn is None:
        import youtube_channel_rss as _y
        search_fn = lambda kw, key, rl, mx: _y.search_channels(kw, key, relevance_lang=rl, max_results=mx)
    if feed_fn is None:
        import youtube_channel_rss as _y
        feed_fn = _y.fetch_feed
    if judge_fn is None:
        import db_channel_vet as _CV
        import media_taxonomy as _MT
        _sets = _MT.load_classify_sets(conn)
        _names = _CV.name_index(conn)
        def judge_fn(conn_, cid, lang, titles):
            rs = _CV.score(conn_, cid, lang, _sets, _names, titles=titles)
            col = _CV.collected(conn_, cid)
            p = {'cid': cid, 'name': '', 'lang': lang, 'col': col, 'rss': rs,
                 'scale': _CV.scale(conn_, cid), 'med_views': _CV._median(col['views'])}
            return _CV.judge(conn_, p)
    keys = list(keys or [])
    if not keys:
        log('  [채널 발굴] API 키가 없습니다.')
        out['skipped'] = 'NO_KEY'
        return out
    try:
        import lang_config as _lc
    except Exception:
        _lc = None
    ki = 0
    newly = []
    for r in plan:
        kw, lang = r['kw'], r['lang']
        rl = None
        try:
            rl = _lc.relevance_lang(lang) if _lc else None
        except Exception:
            rl = None
        items, err = [], None
        for _try in range(max(1, len(keys))):
            items, _tok, err = search_fn(kw, keys[ki % len(keys)], rl, 50)
            if not err:
                break
            ki += 1
        out['units'] += 100
        if err:
            out['err'].append('%s: %s' % (kw, str(err)[:80]))
            log('  [채널 발굴] "%s"(%s) 오류 — %s' % (kw, lang, str(err)[:80]))
            record_run(conn, r['kw_id'], 0, 0)
            continue
        seen = new = 0
        for it in items or []:
            cid = (it.get('channel_id') or '').strip()
            if not cid:
                continue
            seen += 1
            if upsert_channel(conn, cid, it.get('title'), it.get('description'), lang=lang,
                              found_by='%s:%s' % (AUTO_TAG, kw), db_path=db_path) == 'NEW':
                new += 1
                newly.append((cid, lang))
        record_run(conn, r['kw_id'], seen, new)
        out['seen'] += seen; out['new'] += new
        out['rows'].append((kw, lang, seen, new))
        log('  [채널 발굴] "%s"(%s) 본 것 %d · 새 후보 %d' % (kw, lang, seen, new))
    # 새 후보만 프로파일(RSS · 쿼터 0) + 심사 — 사람이 볼 재료를 채운다
    for cid, lang in newly:
        st = conn.execute("SELECT status FROM sys_mine_channel WHERE channel_id=?", (cid,)).fetchone()
        if not st or st[0] != ST_NEW:
            continue
        try:
            feed = feed_fn(cid)
        except Exception as e:
            feed = {'err': str(e), 'entries': []}
        ents = (feed or {}).get('entries') or []
        if ents:
            fill_profile(conn, cid, title=feed.get('channel_name') or None, lang=lang,
                         n_video=len(ents), last_video=(ents[0].get('published') or None),
                         samples=' | '.join((e.get('title') or '') for e in ents[:8]),
                         descr=(ents[0].get('description') or '')[:400] or None, db_path=db_path)
        try:
            grade, why = judge_fn(conn, cid, lang, [(e.get('title') or '') for e in ents])
            import db_channel_vet as _CV2
            gname = _CV2.GRADES.get(grade, grade)
        except Exception as e:
            grade, why, gname = 'UNKNOWN', ['심사 실패: %s' % str(e)[:60]], '판단 못 함'
        out['grades'][grade] = out['grades'].get(grade, 0) + 1
        out['vetted'] += 1
        note = '%s %s — %s' % (VET_NOTE, gname, ' · '.join(why or [])[:160])
        conn.execute("UPDATE sys_mine_channel SET note=? WHERE channel_id=? AND status=? "
                     "AND (note IS NULL OR note='')", (note, cid, ST_NEW))
        conn.commit()
        if sleep:
            _t.sleep(sleep)
    log('  [채널 발굴] 씨앗 %d · 본 것 %d · 새 후보 %d · 심사 %d(%s) · %d units'
        % (out['kw'], out['seen'], out['new'], out['vetted'],
           ', '.join('%s %d' % kv for kv in out['grades'].items()) or '-', out['units']))
    return out


def channels(conn, lang: str = None, status: str = None, q: str = None,
             limit: int = 500):
    if not _has(conn, 'sys_mine_channel'):
        return []
    sql = ("SELECT channel_id, title, descr, lang, found_by, found_at, seen_at, "
           "n_hit, subs, n_video, last_video, samples, status, note "
           "FROM sys_mine_channel WHERE 1=1")
    args = []
    if lang:
        sql += " AND lang=?"
        args.append(lang)
    if status:
        sql += " AND status=?"
        args.append(status)
    if q:
        sql += " AND (title LIKE ? OR descr LIKE ? OR found_by LIKE ?)"
        args += ['%%%s%%' % q] * 3
    sql += " ORDER BY (status='NEW') DESC, found_at DESC LIMIT ?"
    args.append(int(limit))
    cols = ('channel_id', 'title', 'descr', 'lang', 'found_by', 'found_at',
            'seen_at', 'n_hit', 'subs', 'n_video', 'last_video', 'samples',
            'status', 'note')
    return [dict(zip(cols, r)) for r in conn.execute(sql, args).fetchall()]


def set_status(conn, channel_ids, status: str, note: str = None) -> int:
    if status not in STATUSES:
        raise ValueError('모르는 상태: %r' % (status,))
    ids = [str(x).strip() for x in (channel_ids or []) if str(x).strip()]
    if not ids:
        return 0
    q = ','.join('?' * len(ids))
    if note is None:
        cur = conn.execute(
            "UPDATE sys_mine_channel SET status=? WHERE channel_id IN (%s)" % q,
            [status] + ids)
    else:
        cur = conn.execute(
            "UPDATE sys_mine_channel SET status=?, note=? WHERE channel_id IN (%s)" % q,
            [status, note] + ids)
    conn.commit()
    return cur.rowcount or 0


def stats(conn):
    """현황 — 화면 머리줄이 쓴다."""
    out = {'kw_total': 0, 'kw_on': 0, 'kw_never': 0,
           'ch_total': 0, 'by_status': {}, 'langs': []}
    if _has(conn, 'sys_mine_keyword'):
        r = conn.execute(
            "SELECT COUNT(*), SUM(enabled), SUM(last_run IS NULL AND enabled=1) "
            "FROM sys_mine_keyword").fetchone()
        out['kw_total'] = int(r[0] or 0)
        out['kw_on'] = int(r[1] or 0)
        out['kw_never'] = int(r[2] or 0)
        out['langs'] = [x[0] for x in conn.execute(
            "SELECT DISTINCT lang FROM sys_mine_keyword ORDER BY lang")]
    if _has(conn, 'sys_mine_channel'):
        out['ch_total'] = int(conn.execute(
            "SELECT COUNT(*) FROM sys_mine_channel").fetchone()[0] or 0)
        for st, n in conn.execute(
                "SELECT status, COUNT(*) FROM sys_mine_channel GROUP BY status"):
            out['by_status'][st] = int(n)
    return out


# ── selftest ───────────────────────────────────────────────────────────
def _selftest() -> int:
    ok, bad = [], []

    def chk(name, cond):
        (ok if cond else bad).append(name)

    c = sqlite3.connect(':memory:')
    init(c)
    init(c)
    chk('init 멱등', True)

    # 씨앗 후보 — media_taxonomy 에서 온다
    cand_ko = seed_candidates('KO')
    cand_ru = seed_candidates('RU')
    chk('씨앗 후보 KO 있음', len(cand_ko) > 5)
    chk('언어마다 다르다', set(cand_ko) != set(cand_ru))
    chk('★ COMMON(영어)은 KO 씨앗에 안 섞인다', not any(w.isascii() for w in cand_ko))
    chk('  EN 씨앗에는 COMMON 이 든다', any(w.isascii() for w in seed_candidates('EN')))

    n = sync_seeds(c, 'KO')
    chk('씨앗 담김', n == len(cand_ko) and n > 0)
    chk('sync 멱등', sync_seeds(c, 'KO') == 0)
    # ★★★ 씨앗은 **그 DB 의 키워드 규칙**에서 온다 — 코드 기본값이 아니다
    import json as _j
    c.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
    import media_taxonomy as _MT
    _key = _MT.CLASSIFY_KW_KEYS['SERMON']
    c.execute("INSERT OR REPLACE INTO sys_config VALUES(?,?)",
              (_key, _j.dumps({'COMMON': ['sermon'], 'KO': ['시험전용씨앗낱말']})))
    c.commit()
    chk('★★★ 규칙 화면에서 더한 낱말이 씨앗에 온다(기본값 폴백 아님)',
        '시험전용씨앗낱말' in seed_candidates('KO', conn=c))
    chk('  sync 가 새 낱말을 담는다', sync_seeds(c, 'KO') >= 1
        and any(k['kw'] == '시험전용씨앗낱말' for k in keywords(c, 'KO')))

    kws = keywords(c, 'KO')
    chk('기본은 꺼져 있다', all(k['enabled'] == 0 for k in kws))
    chk('켜지 않으면 돌 것이 없다', next_keywords(c, 'KO', 5) == [])

    ids = [k['kw_id'] for k in kws[:3]]
    set_enabled(c, ids, True)
    nx = next_keywords(c, 'KO', 5)
    chk('켠 것만 돈다', len(nx) == 3)

    # 공평한 차례 — 돈 것은 뒤로 간다
    first = nx[0]['kw_id']
    record_run(c, first, seen=10, new=2)
    nx2 = next_keywords(c, 'KO', 5)
    chk('돈 낱말은 뒤로', nx2[0]['kw_id'] != first and nx2[-1]['kw_id'] == first)
    row = [k for k in keywords(c, 'KO') if k['kw_id'] == first][0]
    chk('이력이 남는다', row['n_run'] == 1 and row['n_seen'] == 10 and row['n_new'] == 2)
    record_run(c, first, seen=3, new=0)
    row = [k for k in keywords(c, 'KO') if k['kw_id'] == first][0]
    chk('0건도 기록된다', row['n_run'] == 2 and row['n_seen'] == 13)

    # 손으로 더하기
    kid = add_keyword(c, 'KO', '새벽기도')
    chk('손 낱말 추가', kid > 0)
    chk('손 낱말은 켜진 채', any(k['kw_id'] == kid and k['enabled'] == 1
                                for k in keywords(c, 'KO')))
    chk('중복 추가 안 늘어남',
        add_keyword(c, 'KO', '새벽기도') == kid)

    # 발굴 결과
    chk('처음은 NEW', upsert_channel(c, 'UC1', '어떤교회', lang='KO',
                                     found_by='설교') == 'NEW')
    chk('두 번째는 DUP', upsert_channel(c, 'UC1', '어떤교회', lang='KO',
                                        found_by='예배') == 'DUP')
    row = channels(c)[0]
    chk('다시 만나면 n_hit 늘어남', row['n_hit'] == 2)
    chk('덮어쓰지 않는다', row['found_by'] == '설교')

    # 판단 재료
    fill_profile(c, 'UC1', descr='주일 설교를 올립니다', samples='a|b|c', subs=1200)
    row = channels(c)[0]
    chk('프로필 채워짐', row['descr'] and row['subs'] == 1200)
    fill_profile(c, 'UC1', descr='', subs=None)
    row = channels(c)[0]
    chk('빈 값으로 안 덮음', row['descr'] == '주일 설교를 올립니다' and row['subs'] == 1200)

    # 상태
    upsert_channel(c, 'UC2', '딴채널', lang='KO', found_by='찬양')
    chk('미검토 둘', len(channels(c, status=ST_NEW)) == 2)
    set_status(c, ['UC2'], ST_BLOCK, note='타종교')
    chk('차단함', len(channels(c, status=ST_BLOCK)) == 1)
    chk('미검토 하나 남음', len(channels(c, status=ST_NEW)) == 1)
    chk('사라지지 않는다', len(channels(c)) == 2)
    try:
        set_status(c, ['UC2'], 'WHAT')
        chk('모르는 상태 거부', False)
    except ValueError:
        chk('모르는 상태 거부', True)

    # 이미 등록된 채널은 처음부터 REG
    # ⚠ 칸 이름이 실제와 같아야 이 시험이 뜻이 있다(channel_id 는 내부 PK)
    c.execute("CREATE TABLE sys_media_channel (channel_id INTEGER, channel_ext_id TEXT)")
    c.execute("INSERT INTO sys_media_channel VALUES (1, 'UC9')")
    upsert_channel(c, 'UC9', '이미쓰는채널', lang='KO', found_by='설교')
    got = [x for x in channels(c) if x['channel_id'] == 'UC9'][0]
    chk('이미 쓰는 채널은 REG', got['status'] == ST_REG)
    chk('known_ids 가 등록표를 본다', 'UC9' in known_ids(c))
    # 탐지력 — 내부 PK 를 읽으면 못 찾아야 한다(그 실수를 잡는 항목)
    chk('내부 PK 는 안 본다', '1' not in known_ids(c))

    st = stats(c)
    chk('현황 낱말', st['kw_on'] == 4 and st['kw_total'] == len(cand_ko) + 2)  # +1 손 추가 · +1 규칙 시험 낱말
    chk('현황 채널', st['ch_total'] == 3 and st['by_status'].get(ST_NEW) == 1)

    # ── 낱말별 결과 통계 · 삭제 · 언어별 현황 (2026-09-09)
    oc = keyword_outcomes(c)
    chk('★ 낱말별 결과 — 「찬양」이 물어 온 채널은 제외 1',
        oc.get('찬양', {}).get(ST_BLOCK) == 1 and oc.get('설교', {}).get(ST_NEW) == 1)
    sc = seed_counts(c)
    chk('언어별 현황', sc.get('KO', (0, 0))[0] == st['kw_total'] and sc['KO'][1] == 4)
    n_del = delete_keyword(c, [kid])
    chk('삭제', n_del == 1 and not any(k['kw_id'] == kid for k in keywords(c, 'KO')))
    chk('  발굴 표는 남는다', len(channels(c)) == 3)
    # 옮기기 — 번역기를 주입한다(네트워크 없이)
    ids = [k['kw_id'] for k in keywords(c, 'KO')[:2]]
    n_tr, miss = translate_seeds(c, ids, 'JA', translator=lambda t, tl, sl: t + '(ja)')
    chk('★ 다른 언어로 옮기면 꺼진 채로 담긴다', n_tr == 2 and miss == []
        and all(k['enabled'] == 0 for k in keywords(c, 'JA')))
    chk('  두 번 옮겨도 안 는다', translate_seeds(c, ids, 'JA', translator=lambda t, tl, sl: t + '(ja)')[0] == 0)
    # 차단 채널은 발굴 후보가 아니다
    c.execute("CREATE TABLE sys_media_excluded_channel (excl_id INTEGER PRIMARY KEY, channel_name TEXT, "
              "reason_code TEXT, reason_detail TEXT, excluded_at TEXT, excluded_by TEXT, "
              "record_status TEXT, channel_ext_id TEXT)")
    c.execute("INSERT INTO sys_media_excluded_channel (excl_id, channel_name, channel_ext_id,"
              " record_status) VALUES (1, '이단채널', 'UCBLOCK', 'LIVE')")
    c.execute("INSERT INTO sys_media_excluded_channel (excl_id, channel_name, channel_ext_id,"
              " record_status) VALUES (2, '옛이름차단', NULL, 'LIVE')")
    upsert_channel(c, 'UCBLOCK', '이름은 달라도', lang='KO', found_by='설교')
    upsert_channel(c, 'UCBLK2', '옛이름차단', lang='KO', found_by='설교')
    got = {x['channel_id']: x for x in channels(c)}
    chk('★ 차단 id 는 처음부터 차단', got['UCBLOCK']['status'] == ST_BLOCK
        and got['UCBLOCK']['note'] == WORDS['block'])
    chk('  옛 이름 차단도 거른다', got['UCBLK2']['status'] == ST_BLOCK)
    chk('  미검토에 안 뜬다', not any(x['channel_id'] in ('UCBLOCK', 'UCBLK2')
                                   for x in channels(c, status=ST_NEW)))
    # ★★★ 채널 거르는 말 — 발굴 첫 단계에서 이단 단체를 제외로(2026-09-09 사용자 지시)
    upsert_channel(c, 'UCLDS1', '책 읽어주는 후기 성도', lang='KO', found_by='설교')
    upsert_channel(c, 'UCLDS2', 'norio koyama', lang='JA', found_by='聖書')
    upsert_channel(c, 'UCOK1', 'Lawton Church of God', lang='EN', found_by='sermon')
    got = {x['channel_id']: x for x in channels(c)}
    chk('★ 이름에 단체 표기가 있으면 처음부터 차단(사유 = 낱말)',
        got['UCLDS1']['status'] == ST_BLOCK and got['UCLDS1']['note'].startswith('거르는 말'))
    chk('  홑낱말 Church of God 은 정통 교단이라 미검토', got['UCOK1']['status'] == ST_NEW)
    chk('  이름만으로는 안 걸리는 채널은 일단 미검토', got['UCLDS2']['status'] == ST_NEW)
    fill_profile(c, 'UCLDS2', descr='末日聖徒イエス・キリスト教会の聖典を学ぶ')
    got = {x['channel_id']: x for x in channels(c)}
    chk('★ 재료(설명)가 채워지면 다시 보고 차단으로', got['UCLDS2']['status'] == ST_BLOCK)
    set_status(c, ['UCOK1'], ST_SKIP)
    chk('  다시 적용해도 정통 채널은 안 바뀐다', apply_channel_kw(c) == 0
        and channels(c, status=ST_SKIP)[0]['channel_id'] == 'UCOK1')

    # ★★★ 상태 셋 — 제외 폐기(2026-09-09 사용자 확정)
    chk('★ 상태는 넷뿐이고 제외가 없다',
        set(STATUSES) == {ST_NEW, ST_REG, ST_BLOCK, ST_SKIP} and 'REJ' not in STATUSES)
    chk('  낱말표에 「제외」가 없다', 'exclude' not in WORDS
        and '제외' not in ''.join(WORDS.values()))
    # ★ 옛 제외 → 차단 이관(멱등 · 등록된 채널은 안 옮긴다)
    c.execute("CREATE TABLE IF NOT EXISTS sys_media_rejected_channel (rej_id INTEGER PRIMARY KEY,"
              " channel_ext_id TEXT, channel_name TEXT, channel_url TEXT, lang_code TEXT,"
              " note TEXT, rejected_at TEXT, record_status TEXT DEFAULT 'LIVE')")
    c.execute("INSERT INTO sys_media_rejected_channel (channel_ext_id, channel_name, note, rejected_at,"
              " record_status) VALUES ('UCOLD1','옛제외채널','타종교','2026-01-01','LIVE')")
    c.execute("INSERT INTO sys_media_rejected_channel (channel_ext_id, channel_name, record_status)"
              " VALUES ('UCBLOCK','이미차단','LIVE')")
    c.execute("INSERT INTO sys_media_rejected_channel (channel_ext_id, channel_name, record_status)"
              " VALUES ('UCREG1','등록된채널','LIVE')")
    try:
        c.execute("ALTER TABLE sys_media_channel ADD COLUMN record_status TEXT DEFAULT 'LIVE'")
    except Exception:
        pass
    c.execute("INSERT INTO sys_media_channel (channel_id, channel_ext_id, record_status)"
              " VALUES (99,'UCREG1','LIVE')")
    c.commit()
    _mv, _dup = migrate_reject(c)
    chk('★★ 옛 제외를 차단으로 옮긴다(이미 차단된 것은 건너뛴다) %r' % ((_mv, _dup),), (_mv, _dup) == (1, 1))
    chk('  등록된 채널은 안 옮긴다', not c.execute(
        "SELECT 1 FROM sys_media_excluded_channel WHERE channel_ext_id='UCREG1'").fetchone())
    chk('  사유를 잃지 않는다', '타종교' in (c.execute(
        "SELECT reason_detail FROM sys_media_excluded_channel WHERE channel_ext_id='UCOLD1'"
    ).fetchone() or [''])[0])
    chk('  두 번 돌려도 안 는다(멱등)', migrate_reject(c)[0] == 0)
    chk('  옛 표는 그대로 둔다(되돌릴 근거)', c.execute(
        "SELECT COUNT(*) FROM sys_media_rejected_channel").fetchone()[0] == 3)

    # ★★ 채널 자동 발굴 한 바퀴(2026-09-16) — 검색·RSS·심사를 주입해 쿼터 0
    c.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
    c.execute("UPDATE sys_mine_keyword SET enabled=0")      # 앞 시험의 씨앗을 계획에서 뺀다
    for _lg, _kw in (('KO', '자동씨앗ㄱ'), ('KO', '자동씨앗ㄴ'), ('EN', 'auto seed a')):
        add_keyword(c, _lg, _kw, enabled=True)
    _plan = discover_plan(c, 2)
    chk('★ 계획 — 언어를 번갈아 뽑는다(KO 하나 · EN 하나)', sorted(p['lang'] for p in _plan) == ['EN', 'KO'])
    _calls = []
    def _srch(kw, key, rl, mx):
        _calls.append((kw, key, rl))
        return ([{'channel_id': 'UCAUTO_' + kw[-1], 'title': '채널 ' + kw},
                 {'channel_id': 'UC1', 'title': '이미 있는'}], None, None)
    def _feed(cid):
        return {'channel_name': '피드 ' + cid, 'entries': [
            {'title': '주일설교 창세기 1장', 'published': '2026-09-01', 'description': '설명'},
            {'title': '수요예배 요한복음 3장', 'published': '2026-08-25'}]}
    _judged = []
    def _judge(conn_, cid, lang, titles):
        _judged.append((cid, lang, len(titles)))
        return 'GOOD', ['시험 까닭']
    r = auto_discover(c, ['K1'], n=2, log=lambda *_a: None, search_fn=_srch, feed_fn=_feed,
                      judge_fn=_judge, sleep=0)
    chk('★ 한 바퀴 — 씨앗 2 · 본 것 4 · 새 후보 2 · 심사 2 · 200 units',
        (r['kw'], r['seen'], r['new'], r['vetted'], r['units']) == (2, 4, 2, 2, 200))
    chk('  후보에 found_by=자동:낱말 · note=자동심사 등급 — 까닭 · 등록은 안 한다',
        c.execute("SELECT found_by, note, status FROM sys_mine_channel WHERE channel_id='UCAUTO_ㄱ'").fetchone()
        == ('자동:자동씨앗ㄱ', '자동심사 등록 권함 — 시험 까닭', ST_NEW)
        and not c.execute("SELECT 1 FROM sys_media_channel WHERE channel_ext_id='UCAUTO_ㄱ'").fetchone())
    chk('  프로파일이 채워진다(표본 제목·영상 수)', c.execute(
        "SELECT n_video, samples FROM sys_mine_channel WHERE channel_id='UCAUTO_a'").fetchone()[0] == 2)
    chk('  「돌았다」가 남는다(n_run 1 · 다음 계획은 안 돈 것부터)',
        [p['kw'] for p in discover_plan(c, 1)] == ['자동씨앗ㄴ'])
    c.execute("INSERT OR REPLACE INTO sys_config VALUES(?, '0')", (DISCOVER_ON_KEY,))
    chk('  스위치를 끄면 안 돈다', auto_discover(c, ['K1'], log=lambda *_a: None, search_fn=_srch,
                                        feed_fn=_feed, judge_fn=_judge, sleep=0).get('skipped') == 'OFF')
    c.execute("DELETE FROM sys_config WHERE config_key=?", (DISCOVER_ON_KEY,))
    _calls.clear()
    r2 = auto_discover(c, ['K1', 'K2'], n=1, log=lambda *_a: None,
                       search_fn=lambda kw, key, rl, mx: (([], None, 'quota') if key == 'K1' else _srch(kw, key, rl, mx)),
                       feed_fn=_feed, judge_fn=_judge, sleep=0)
    chk('  키 하나가 막히면 다음 키로 넘어간다', r2['err'] == [] and _calls and _calls[-1][1] == 'K2')

    # ★ 씨앗 자기 교정(2026-09-16) — 세 번 돌아 새것 0 이면 지정이 풀린다
    _kid = add_keyword(c, 'KO', '헛도는씨앗', enabled=True)
    for _ in range(AUTO_OFF_RUNS - 1):
        record_run(c, _kid, 25, 0)
    chk('  두 번까지는 지정 그대로', c.execute("SELECT enabled FROM sys_mine_keyword WHERE kw_id=?", (_kid,)).fetchone()[0] == 1)
    record_run(c, _kid, 25, 0)
    _r = c.execute("SELECT enabled, note FROM sys_mine_keyword WHERE kw_id=?", (_kid,)).fetchone()
    chk('★ 세 번 돌아 새것 0 → 지정 해제 + 까닭', _r[0] == 0 and '자동 지정 해제' in (_r[1] or ''))
    _kid2 = add_keyword(c, 'KO', '잘도는씨앗', enabled=True)
    for _ in range(AUTO_OFF_RUNS + 1):
        record_run(c, _kid2, 25, 1)
    chk('  새것이 하나라도 있으면 안 푼다', c.execute("SELECT enabled FROM sys_mine_keyword WHERE kw_id=?", (_kid2,)).fetchone()[0] == 1)
    set_enabled(c, [_kid], True)
    _r = c.execute("SELECT enabled, n_run, note FROM sys_mine_keyword WHERE kw_id=?", (_kid,)).fetchone()
    chk('  다시 지정하면 표식을 걷고 횟수 0 부터', _r[0] == 1 and _r[1] == 0 and not _r[2])

    # 표가 없어도 조회는 돈다
    c2 = sqlite3.connect(':memory:')
    chk('표 없어도 안 터짐',
        channels(c2) == [] and keywords(c2) == [] and stats(c2)['ch_total'] == 0)

    print('db_channel_mine selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    for b in bad:
        print('  FAIL:', b)
    return 0 if not bad else 1


# ── CLI ────────────────────────────────────────────────────────────────
def _conn(db=None):
    if appdb is not None:
        return appdb.connect(db or 'bible_master.db')
    return sqlite3.connect(db or 'bible_master.db')


def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = _conn()
    if '--init' in argv:
        init(c)
        print('표 준비 완료')
        return 0
    if '--sync' in argv:
        i = argv.index('--sync')
        lang = argv[i + 1] if len(argv) > i + 1 else 'KO'
        n = sync_seeds(c, lang, 'bible_master.db')
        print('%s 씨앗 후보 %d개 담음(전부 꺼진 상태)' % (lang, n))
        return 0
    st = stats(c)
    print('씨앗 낱말 %d (켬 %d · 한 번도 안 돈 것 %d)'
          % (st['kw_total'], st['kw_on'], st['kw_never']))
    print('발굴 채널 %d  %s' % (st['ch_total'], st['by_status']))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
