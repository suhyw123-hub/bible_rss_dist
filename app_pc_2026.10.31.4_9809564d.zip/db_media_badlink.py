# -*- coding: utf-8 -*-
"""낱말 경계를 어겨 잘못 걸린 **영상↔용어 연결**을 걷는다.

★ 왜 만들었나 (2026-09-08 사용자 지시 — 「풀 재연결 수리하고 오연결 정리하라」).
  `media_text_linker.analyze` 3패스가 **부분 문자열**로 이름을 찾아
  낱말 속에 우연히 든 글자를 이름으로 읽었다. 실측 상위:

  | 용어 | 걸린 글자 | 실제로 어디에 | 건수 |
  |---|---|---|---|
  | 엘 | `Er` | chapt**er** · Nev**er** | 2,024 |
  | 아이 | `Ai` | Expl**ai**ned · Ag**ai**n | 1,773 |
  | 레아 | `Lea`·`Lia` | Cl**ea**ring · Ju**lia** | 1,221 |
  | 하와 | `Eve`·`Eva` | N**eve**r · **Eve**ry | 813 |
  | 벨 | `Bel` | A**bel** | 381 |
  | 함 | `Ham` | Abra**ham** | 153 |
  | 셈 | `Sem` | Geth**sem**ane | 178 |
  | 에서 | `에서` | 방주**에서** | 202 |

  뿌리는 `media_text_linker` 에서 고쳤다(경계 판정 = `db_media_range.name_ok`).
  **이미 쌓인 것**을 걷는 것이 이 도구의 몫이다.

★★★ **잣대 = 「지금 규칙으로 다시 만들어지는가」** — 판정을 여기서 새로 쓰지
  않고 **`analyze` 를 그대로 부른다**. 두 벌이면 화면이 만드는 연결과 이
  도구가 지우는 연결이 갈린다(§199차).
⚠⚠ **글자가 아예 없는 것은 안 걷는다** — 키워드로 수집해 붙인 것
  (`also_entity`)은 제목에 이름이 없어도 정당하다. **경계만 어긴 것**,
  곧 「경계 없이는 걸리는데 경계로는 안 걸리는 것」만 골라낸다(§195차 잣대).
⚠⚠ **`MANUAL` 은 손대지 않는다** — 사람이 이은 연결이다.
⚠ **지우지 않고 `HIDE`** — 까닭을 `note` 에 적어 되돌릴 수 있게 둔다.
⚠ 걷고 나서 **연결이 0 이 된 승인 영상은 보관함**으로 — 어디에도 안 걸린
  영상이 화면 밖에 남으면 다시 볼 길이 없다(§195차 전례).

--selftest | --check | --apply | --undo
--ranges [--apply|--undo]   구간(MEDI_VERS) 갈래 — 2026-09-09 신설

★★★ **구간 갈래**(2026-09-09 구절 연결 전수 조사에서) — 책 약명 앞에 글자가 붙은
  것을 책으로 읽었다: 「오전 11시」→전도서 11장 · 「사도행전 2:1」→전2:1 ·
  「고전6:1」→전6:1 · 「요나1장」→나훔 1장 · 「역사 8: 16」→사8:16. 실측 살아 있는
  구간 연결 9,057 중 **202건**(전도서 154). 뿌리는 `media_text_linker._book_ok`
  + 소비 검사로 고쳤고, 쌓인 것은 이 갈래가 걷는다. 잣대는 용어 갈래와 같다 —
  **경계 없이는 걸리는데 경계로는 안 걸리는 것**(`TL.BOOK_STRICT` 를 잠깐 꺼서 잰다).
"""

import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import media_link
import media_text_linker as TL
import db_media_range as MR

#: 걷은 줄에 적는 까닭 — `--undo` 가 이 글자로 찾는다
NOTE = 'BADLINK_BOUNDARY_20260908'
NOTE_R = 'BADLINK_RANGE_20260909'    # 구간 갈래(약명 앞 글자)
NOTE_T = 'BADLINK_TERMNAME_20261010'  # 용어·이름 갈래(설명문 없는 용어 · 사역자 이름)


def _raw_terms(ent_terms):
    """경계 규칙 **전** 이름표 — 「옛 규칙으로는 걸렸나」를 재는 데만 쓴다."""
    out = {}
    for eid, terms in (ent_terms or {}).items():
        keep = set()
        for t in terms:
            for part in str(t or '').split('·'):
                part = part.strip()
                if len(part) >= 2:
                    keep.add(part)
        if keep:
            out[eid] = keep
    return out


def scan(conn, log=print):
    """→ (걷을 것, 글자 없는 것, 살아남는 수). 쓰기 0."""
    from admin import media_entity_link as MEL
    ty = media_link.lt('ENTITY')
    rows = conn.execute(
        "SELECT l.sys_link_id, l.clicked_id, l.target_id,"
        "       COALESCE(l.confidence,''), a.is_active, a.title,"
        "       COALESCE(a.description,''), COALESCE(a.lang_code,'KO')"
        "  FROM %s l JOIN sys_media_asset a ON a.media_id = l.clicked_id"
        " WHERE l.link_type=? AND l.record_status='LIVE'"
        "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
        % media_link.TBL, (ty,)).fetchall()
    log('영상↔용어 연결 %d건' % len(rows))

    by_media = {}
    for lid, mid, eid, conf, act, ti, dj, lg in rows:
        by_media.setdefault((lg or 'KO').upper(), {}).setdefault(
            mid, [ti, dj, act, []])[3].append((lid, eid, conf))

    raw = _raw_terms(MEL.load_entity_terms(conn, types=TL.ENTITY_TYPES))
    bad, notxt, keep = [], [], 0
    for lang, media in by_media.items():
        ctx = TL.build_context(conn, lang, types=TL.ENTITY_TYPES)
        log('[%s] 영상 %d개…' % (lang, len(media)))
        for mid, (ti, dj, act, links) in media.items():
            txt = ti or ''
            try:
                txt += ' ' + str((json.loads(dj) or {}).get('yt_desc', '') or '')
            except Exception:
                pass
            now = set(TL.analyze(conn, txt, ctx)['entity'])
            low = txt.lower()
            for lid, eid, conf in links:
                if (conf or '').upper() == 'MANUAL' or eid in now:
                    keep += 1
                    continue
                loose = None
                for term in raw.get(eid, ()):
                    if term.lower() in low:
                        loose = term
                        break
                (bad if loose else notxt).append((lid, mid, eid, act, loose))
    return bad, notxt, keep


def _ranges_of(conn, txt, ctx):
    return {(int(x[0]), int(x[1])) for x in (TL.analyze(conn, txt, ctx).get('ranges') or [])}


def scan_ranges(conn, log=print):
    """구간 연결 → (걷을 것 [(link_id, media_id, (lo,hi), is_active)], 살아남는 수, 판정 밖 수).

    · 지금 규칙(경계 켬)이 그 구간을 다시 내면 **유지**
    · 못 내는데 경계를 끈 옛 규칙은 내면 **걷는다**(약명 앞 글자 오독)
    · 둘 다 못 내면 **판정 밖**(사람이 이은 것·옛 수집기·실마리 연결) — 손대지 않는다
    ⚠ MANUAL 은 처음부터 밖.
    """
    ty = media_link.lt('VERSE')
    rows = conn.execute(
        "SELECT l.sys_link_id, l.clicked_id, l.target_id, COALESCE(l.end_id,l.target_id),"
        "       COALESCE(l.confidence,''), a.is_active, a.title,"
        "       COALESCE(a.description,''), COALESCE(a.lang_code,'KO')"
        "  FROM %s l JOIN sys_media_asset a ON a.media_id = l.clicked_id"
        " WHERE l.link_type=? AND l.record_status='LIVE'"
        "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
        % media_link.TBL, (ty,)).fetchall()
    log('영상↔구간 연결 %d건' % len(rows))
    by_media = {}
    for lid, mid, lo, hi, conf, act, ti, dj, lg in rows:
        by_media.setdefault((lg or 'KO').upper(), {}).setdefault(
            mid, [ti, dj, act, []])[3].append((lid, (int(lo), int(hi)), conf))
    bad, keep, outside = [], 0, 0
    for lang, media in by_media.items():
        ctx = TL.build_context(conn, lang, types=TL.ENTITY_TYPES)
        log('[%s] 영상 %d개…' % (lang, len(media)))
        for mid, (ti, dj, act, links) in media.items():
            txt = ti or ''
            try:
                txt += ' ' + str((json.loads(dj) or {}).get('yt_desc', '') or '')
            except Exception:
                pass
            strict = _ranges_of(conn, txt, ctx)
            miss = [(lid, sp) for lid, sp, conf in links
                    if (conf or '').upper() != 'MANUAL' and sp not in strict]
            keep += len(links) - len(miss)
            if not miss:
                continue
            TL.BOOK_STRICT = False
            try:
                loose = _ranges_of(conn, txt, ctx)
            finally:
                TL.BOOK_STRICT = True
            for lid, sp in miss:
                if sp in loose:
                    bad.append((lid, mid, sp, act))
                else:
                    outside += 1
    return bad, keep, outside


def report_ranges(conn, log=print):
    bad, keep, outside = scan_ranges(conn, log)
    log('걷을 것 %d · 유지 %d · 판정 밖(사람·옛 수집) %d' % (len(bad), keep, outside))
    for lid, mid, sp, act in bad[:30]:
        log('  %s %s  %s' % ('승인' if act else '미검토', MR.span_label(conn, *sp),
                             (conn.execute("SELECT title FROM sys_media_asset WHERE media_id=?",
                                           (mid,)).fetchone() or [''])[0][:60]))
    return bad


def apply_ranges(conn, log=print, dry_run=False):
    bad, _k, _o = scan_ranges(conn, log)
    if not bad:
        log('걷을 것이 없습니다.')
        return 0, 0
    ids = [x[0] for x in bad]
    if dry_run:
        log('[dry] %d건을 걷습니다.' % len(ids))
        return len(ids), 0
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        conn.execute("UPDATE %s SET record_status='HIDE', note=COALESCE(note,'')||?"
                     " WHERE sys_link_id IN (%s)" % (media_link.TBL, ','.join('?' * len(chunk))),
                     [NOTE_R] + chunk)
    conn.commit()
    log('구간 연결 %d건을 걷었습니다(HIDE · %s).' % (len(ids), NOTE_R))
    held = 0
    try:
        MR.init(conn)
        for mid in {x[1] for x in bad if x[3]}:
            n = conn.execute("SELECT COUNT(*) FROM %s WHERE clicked_id=? AND record_status='LIVE'"
                             % media_link.TBL, (mid,)).fetchone()[0]
            if n == 0:
                MR.hold(conn, mid, 'PERI', MR.R_NONE, note='약명 오독 구간을 걷고 나니 연결이 없습니다')
                held += 1
        conn.commit()
    except Exception as e:
        log('[보관함] %s' % e)
    log('연결이 0 이 된 승인 영상 %d건을 보관함에 담았습니다.' % held)
    return len(ids), held


# ── 용어·이름 갈래(2026-10-10 찬양 연결 점검) ─────────────────────────
#
# ★★★ 고친 규칙 둘(`media_text_linker`)로 **다시 안 만들어지는 것**만 걷는다:
#   ⓐ 설명문 없는 TERM·DOCTRINE(`TL._curated`) — 뜻풀이 낱말(worship·daily·what)
#   ⓑ 사역자·채널 이름 안에 든 이름(`TL._owner_names`) — 다윗과요나단 → 다윗
# ⚠ 사람이 이은 것(MANUAL)·제목/설명문 근거가 아닌 것(SEED·SONG·빈칸)은 안 본다.
# ⚠ 찬양 주제(TOPIC)는 다른 길로 걸린다 — 안 본다.
# ⚠ 까닭이 이 둘이 아닌데 안 만들어지는 것은 **걷지 않는다**(다른 규칙의 몫).
def scan_terms(conn, log=print):
    """→ ([(link_id, media_id, eid, is_active, 까닭, 걸린 말)], 유지 수)."""
    ty = media_link.lt('ENTITY')
    rows = conn.execute(
        "SELECT l.sys_link_id, l.clicked_id, l.target_id, COALESCE(l.source,''),"
        "       a.is_active, a.title, COALESCE(a.description,''),"
        "       COALESCE(a.lang_code,'KO'), em.entity_type,"
        "       COALESCE(json_extract(em.json_detail,'$.subtype'),'')"
        "  FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        "  JOIN sys_entity_master em ON em.entity_id=l.target_id"
        " WHERE l.link_type=? AND l.record_status='LIVE'"
        "   AND COALESCE(l.confidence,'')<>'MANUAL'"
        "   AND (l.source LIKE 'TITLE:%%' OR l.source LIKE 'DESC:%%')"
        "   AND COALESCE(a.record_status,'LIVE')='LIVE'" % media_link.TBL,
        (ty,)).fetchall()
    log('제목·설명문 근거 용어 연결 %d건' % len(rows))
    allids = {r[2] for r in rows}
    cur = set(TL._curated(conn, {e: {'x'} for e in allids}))
    by = {}
    for lid, mid, eid, src, act, ti, dj, lg, et, sub in rows:
        by.setdefault((lg or 'KO').upper(), {}).setdefault(
            mid, [ti, dj, act, []])[3].append((lid, eid, src, et, sub))
    bad, keep = [], 0
    for lang, media in by.items():
        ctx = TL.build_context(conn, lang)
        bare = dict(ctx, owner_names=[])
        log('[%s] 영상 %d개…' % (lang, len(media)))
        for mid, (ti, dj, act, links) in media.items():
            txt = ti or ''
            try:
                txt += ' ' + str((json.loads(dj) or {}).get('yt_desc', '') or '')
            except Exception:
                pass
            now = set(TL.analyze(conn, txt, ctx)['entity'])
            loose = None
            for lid, eid, src, et, sub in links:
                word = src.split(':', 1)[1] if ':' in src else ''
                if eid in now:
                    keep += 1
                    continue
                if et in TL.CURATED_TYPES and sub != 'TOPIC' and eid not in cur:
                    bad.append((lid, mid, eid, act, 'NODESC', word))
                    continue
                if loose is None:
                    loose = set(TL.analyze(conn, txt, bare)['entity'])
                if eid in loose:
                    bad.append((lid, mid, eid, act, 'OWNER', word))
                else:
                    keep += 1          # 다른 까닭 — 이 갈래의 몫이 아니다
    return bad, keep


def report_terms(conn, log=print):
    bad, keep = scan_terms(conn, log)
    agg = {}
    for lid, mid, eid, act, why, word in bad:
        k = (why, word)
        a = agg.setdefault(k, [0, 0])
        a[0] += 1
        a[1] += 1 if act else 0
    log('걷을 것 %d(승인 %d) · 유지 %d' % (len(bad), sum(1 for x in bad if x[3]), keep))
    for why in ('NODESC', 'OWNER'):
        n = sum(1 for x in bad if x[4] == why)
        log('  %s %d' % ({'NODESC': '설명문 없는 용어', 'OWNER': '사역자·채널 이름 속'}[why], n))
        for (w, word), (n1, n2) in sorted(agg.items(), key=lambda x: -x[1][0]):
            if w == why and n1 >= 3:
                log('     %-24s %5d (승인 %d)' % (word[:24], n1, n2))
    return bad


def apply_terms(conn, log=print, dry_run=False):
    bad, _k = scan_terms(conn, log)
    if not bad:
        log('걷을 것이 없습니다.')
        return 0, 0
    ids = [x[0] for x in bad]
    if dry_run:
        log('[dry] %d건을 걷습니다.' % len(ids))
        return len(ids), 0
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        conn.execute("UPDATE %s SET record_status='HIDE', note=COALESCE(note,'')||?"
                     " WHERE sys_link_id IN (%s)" % (media_link.TBL, ','.join('?' * len(chunk))),
                     [NOTE_T] + chunk)
    conn.commit()
    log('용어 연결 %d건을 걷었습니다(HIDE · %s).' % (len(ids), NOTE_T))
    held = 0
    try:
        MR.init(conn)
        for mid in {x[1] for x in bad if x[3]}:
            n = conn.execute("SELECT COUNT(*) FROM %s WHERE clicked_id=? AND record_status='LIVE'"
                             % media_link.TBL, (mid,)).fetchone()[0]
            if n == 0:
                MR.hold(conn, mid, 'ENTI', MR.R_NONE,
                        note='뜻풀이·사역자 이름 연결을 걷고 나니 연결이 없습니다')
                held += 1
        conn.commit()
    except Exception as e:
        log('[보관함] %s' % e)
    log('연결이 0 이 된 승인 영상 %d건을 보관함에 담았습니다.' % held)
    return len(ids), held


def _names(conn, eids):
    out = {}
    for e in eids:
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=?"
            " AND text_type='ENTITY_NAME' AND lang_code='KO'", (e,)).fetchone()
        out[e] = r[0] if r else str(e)
    return out


def report(conn, log=print):
    bad, notxt, keep = scan(conn, log)
    log('')
    log('살아남음        %6d' % keep)
    log('★ 경계만 어긴 것 %6d  ← 걷는다 (승인분 %d)'
        % (len(bad), sum(1 for x in bad if x[3])))
    log('  글자가 없는 것 %6d  ← 안 건드린다(키워드 수집 등, 승인분 %d)'
        % (len(notxt), sum(1 for x in notxt if x[3])))
    agg = {}
    for lid, mid, eid, act, loose in bad:
        agg[(eid, loose)] = agg.get((eid, loose), 0) + 1
    nm = _names(conn, {e for e, _l in agg})
    log('')
    log('  용어             걸린 글자      건수')
    for (eid, loose), n in sorted(agg.items(), key=lambda x: -x[1])[:20]:
        log('  %-16s %-12s %5d' % (str(nm.get(eid, eid))[:16], str(loose)[:12], n))
    return bad, notxt, keep


def apply_(conn, log=print, dry_run=False):
    bad, _notxt, _keep = scan(conn, log)
    if not bad:
        log('걷을 것이 없습니다.')
        return 0, 0
    ids = [x[0] for x in bad]
    if dry_run:
        log('[dry] %d건을 걷습니다.' % len(ids))
        return len(ids), 0
    for i in range(0, len(ids), 500):
        chunk = ids[i:i + 500]
        conn.execute(
            "UPDATE %s SET record_status='HIDE',"
            " note=COALESCE(note,'')||? WHERE sys_link_id IN (%s)"
            % (media_link.TBL, ','.join('?' * len(chunk))),
            [NOTE] + chunk)
    conn.commit()
    log('연결 %d건을 걷었습니다(HIDE).' % len(ids))

    # 걷고 나서 연결이 0 이 된 **승인** 영상 → 보관함
    held = 0
    try:
        MR.init(conn)
        for mid in {x[1] for x in bad if x[3]}:
            n = conn.execute(
                "SELECT COUNT(*) FROM %s WHERE clicked_id=?"
                " AND record_status='LIVE'" % media_link.TBL, (mid,)).fetchone()[0]
            if n == 0:
                MR.hold(conn, mid, 'ENTI', MR.R_NONE,
                        note='경계 오연결을 걷고 나니 연결이 없습니다')
                held += 1
        conn.commit()
    except Exception as e:
        log('[보관함] %s' % e)
    log('연결이 0 이 된 승인 영상 %d건을 보관함에 담았습니다.' % held)
    return len(ids), held


def undo(conn, log=print, note=NOTE):
    n = conn.execute(
        "UPDATE %s SET record_status='LIVE',"
        " note=REPLACE(COALESCE(note,''),?,'') WHERE note LIKE ?"
        % media_link.TBL, (note, '%' + note + '%')).rowcount
    conn.commit()
    log('되살린 연결 %d건(%s)' % (n, note))
    return n


def selftest():
    import shutil
    import sqlite3
    import tempfile
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra))

    t('걷은 표식이 있다', bool(NOTE) and NOTE.isupper() or '_' in NOTE)
    t('★ 경계 판정을 제 손으로 짜지 않는다',
      'name_ok' not in open(__file__, encoding='utf-8').read().split(
          'def scan')[0].split('"""')[-1])
    t('★ 판정을 analyze 에 맡긴다',
      'TL.analyze' in open(__file__, encoding='utf-8').read())
    # ── 구간 갈래(2026-09-09) — 경계 스위치가 실제로 옛 규칙을 되살리는가
    t('★ 링커에 약명 경계 스위치가 있고 기본은 켬', getattr(TL, 'BOOK_STRICT', None) is True)
    try:
        import appdb as _ap
        _c = _ap.connect()
        try:
            _cx = TL.build_context(_c, 'KO', types=TL.ENTITY_TYPES)
            _on = _ranges_of(_c, '주일 오전 11:00 예배', _cx)
            TL.BOOK_STRICT = False
            try:
                _off = _ranges_of(_c, '주일 오전 11:00 예배', _cx)
            finally:
                TL.BOOK_STRICT = True
            t('★★★ 「오전 11:00」 — 경계 켜면 0 · 끄면 전도서(그 차이가 걷는 잣대)',
              not _on and bool(_off), (_on, _off))
            t('  스위치를 되돌려 둔다', TL.BOOK_STRICT is True)
        finally:
            _c.close()
    except Exception as _e:
        t('  (실 DB 없음 — 구간 갈래 실측 건너뜀)', True, str(_e)[:40])

    # 경계 없는 이름표는 「옛 규칙」 재기용일 뿐
    raw = _raw_terms({1: {'가인 · Cain'}, 2: {'엘 · Er'}})
    # ⚠ 한 글자(「엘」)는 2자 하한에 걸려 빠진다 — 그것이 맞다.
    t('  가운뎃점을 가른다', raw[1] == {'가인', 'Cain'} and raw[2] == {'Er'}, raw)

    d = tempfile.mkdtemp()
    try:
        p = os.path.join(d, 't.db')
        c = sqlite3.connect(p)
        c.execute("CREATE TABLE %s(sys_link_id INTEGER PRIMARY KEY,"
                  " link_type TEXT, clicked_id INT, target_id INT,"
                  " record_status TEXT, note TEXT, confidence TEXT)"
                  % media_link.TBL)
        c.execute("INSERT INTO %s VALUES(1,'MEDI_ENTI',9,9,'LIVE',NULL,NULL)"
                  % media_link.TBL)
        c.execute("UPDATE %s SET record_status='HIDE',"
                  " note=COALESCE(note,'')||? WHERE sys_link_id=1"
                  % media_link.TBL, (NOTE,))
        c.commit()
        n = undo(c, log=lambda *a: None)
        r = c.execute("SELECT record_status, COALESCE(note,'') FROM %s"
                      % media_link.TBL).fetchone()
        t('★ 되돌리면 살아나고 표식이 지워진다',
          n == 1 and r[0] == 'LIVE' and NOTE not in r[1], r)
        c.execute("INSERT INTO %s VALUES(2,'MEDI_VERS',9,100,'HIDE',?,NULL)" % media_link.TBL, (NOTE_R,))
        c.commit()
        n2 = undo(c, log=lambda *a: None, note=NOTE_R)
        t('★ 구간 갈래도 제 표식으로 되돌린다', n2 == 1 and
          c.execute("SELECT record_status FROM %s WHERE sys_link_id=2" % media_link.TBL).fetchone()[0] == 'LIVE'
          and c.execute("SELECT record_status FROM %s WHERE sys_link_id=1" % media_link.TBL).fetchone()[0] == 'LIVE')

        # ── 풀 재연결 백업이 구간 범위를 담는가 (2026-09-08) ──────────
        # ⚠⚠ `end_id` 칸이 없으면 **구간 링크를 되살릴 수 없다** — 범위가
        #   사라진다. 구간 축을 백업 범위에 넣은 날 함께 열어야 했던 자리다.
        import media_text_linker as _TL
        _TL._ensure_backup_tbl(c)
        _cols = [x[1] for x in c.execute(
            "PRAGMA table_info(sys_media_link_backup)")]
        t('★ 백업표가 구간 범위(end_id)를 담는다', 'end_id' in _cols, _cols[-2:])
        t('★ 되돌리는 문이 있다',
          hasattr(_TL, 'restore_backup') and hasattr(_TL, 'backup_rounds'))
        c.close()
    finally:
        shutil.rmtree(d, ignore_errors=True)

    # ── 용어·이름 갈래(2026-10-10) — 새 규칙이 실제로 도는가
    try:
        import appdb as _ap
        _c = _ap.connect()
        try:
            _cx = TL.build_context(_c, 'EN')
            _w = TL.analyze(_c, 'Peaceful Worship Music for Prayer', _cx)['entity_why']
            t('★★★ 뜻풀이 낱말(worship·prayer)이 용어로 안 걸린다',
              not any(v[0].lower() in ('worship', 'prayer', 'peaceful') for v in _w.values()), _w)
            _w2 = TL.analyze(_c, 'Elevation Worship - Praise', _cx)['entity_why']
            t('★ 사역자 이름(Elevation Worship) 자리는 소비된다', not _w2, _w2)
            _w3 = TL.analyze(_c, 'David and Goliath', _cx)['entity']
            t('  진짜 이름은 그대로 걸린다(다윗·골리앗)', len(_w3) >= 2, _w3)
            t('  표식이 셋 다 다르다', len({NOTE, NOTE_R, NOTE_T}) == 3)
        finally:
            _c.close()
    except Exception as _e:
        t('  (실 DB 없음 — 용어 갈래 실측 건너뜀)', True, str(_e)[:40])
    print('db_media_badlink selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    try:
        if '--terms' in sys.argv:
            if '--apply' in sys.argv:
                apply_terms(conn, dry_run='--dry' in sys.argv)
            elif '--undo' in sys.argv:
                undo(conn, note=NOTE_T)
            else:
                report_terms(conn)
        elif '--ranges' in sys.argv:
            if '--apply' in sys.argv:
                apply_ranges(conn, dry_run='--dry' in sys.argv)
            elif '--undo' in sys.argv:
                undo(conn, note=NOTE_R)
            else:
                report_ranges(conn)
        elif '--apply' in sys.argv:
            apply_(conn, dry_run='--dry' in sys.argv)
        elif '--undo' in sys.argv:
            undo(conn)
        else:
            report(conn)
    finally:
        conn.close()
