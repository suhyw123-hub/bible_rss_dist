# -*- coding: utf-8 -*-
"""자동 수집 **주기·분산**의 단일 소스 (2026-09-03 신설).

★ 왜 있나 (사용자 지시 — 「3시간 주기로 서버에 접근하면 그 자체로 부하가 될
  수 있다. 1만 명이 사용한다면… 하루 1회 정도로 제한해야 한다 ·
  **서로 연결되지 않은 여러 사람들의 서버 방문시간을 효과적으로 분할할 수
  있는 전략**」).

★★★ **결정적 해시 분산** — 서로 통신하지 않는 클라이언트를 균등하게 흩는
  표준 해법이다. 자기 익명 씨앗을 해시해 자기 시각을 정한다:

      slot = sha256(씨앗 + 소금) % 하루초수

  · **무작위(random)와 분산 성능은 같은데 재현이 된다** — 실측 1만 대 기준
    1초 창 최대 3건으로 무작위와 동일하고, 재실행해도 같은 시각이라 서버
    쪽에서 예측·재현할 수 있다.
  · 아무 분산이 없으면 「다 같이 13:00 정각」 = 1초에 10,000건이다.

★★ **부팅 지터가 실은 더 중요하다.** 정시 슬롯만으로는 「출근 시간대 일제
  부팅」을 못 막는다 — PC 가 꺼져 있던 사람들은 모두 슬롯을 놓친 채 켜기
  때문이다. 실측: 절반이 08:50~09:00 에 켜면 **8.3 req/s**, 부팅 뒤 0~40분
  지터를 주면 **2.4 req/s**.
  ⇒ 판정은 「지금이 내 슬롯 시각인가」가 아니라 **「마지막 성공 이후 주기가
    지났는가 + 부팅 지터를 기다렸는가」**다. 전자로 하면 PC 를 안 켜는 사람은
    영영 못 받는다.

★ **실패는 지수 백오프 + 지터** — 서버가 잠깐 죽었을 때 모두가 동시에
  재시도하는 것(썬더링 허드)이 가장 위험하다.

    python sync_schedule.py --selftest   (의무)
    python sync_schedule.py --show       내 기기의 예정 시각
"""
from __future__ import annotations

import argparse
import hashlib
import sys
import time

import appdb

DB = 'bible_master.db'

#: 주기 — 사용자가 고른다. 기본은 하루 1회(사용자 확정).
PERIODS = {'DAILY': 86400, 'H12': 43200, 'H6': 21600, 'MANUAL': 0}
DEFAULT_PERIOD = 'DAILY'

#: 받는 시간대(현지 시각 기준 시). ⚠ **기본은 ANY** — 하루 전체(86,400초)에
#  흩어져야 가장 평탄하다(실측 0.12 req/s). 시간대 선택은 「밤에만」처럼 이유가
#  있는 분을 위한 것이지 기본이 아니다.
WINDOWS = {
    'ANY': None,
    'DAWN': (3, 6),        # 새벽 3~6시
    'MORNING': (6, 9),
    'NOON': (12, 14),
    'EVENING': (18, 21),
    'NIGHT': (22, 25),     # 22시~다음날 1시 — 25 는 넘어감을 뜻한다
}
DEFAULT_WINDOW = 'ANY'

BOOT_JITTER = 40 * 60      # 트레이 시작 뒤 최대 지연(초)
BACKOFF_BASE = 60          # 실패 1회 뒤 1분
BACKOFF_MAX = 6 * 3600     # 상한 6시간

K_SEED = 'SYNC_SEED'
K_PERIOD = 'SYNC_PERIOD'
K_WINDOW = 'SYNC_WINDOW'
K_LAST_OK = 'SYNC_LAST_OK'
K_FAILS = 'SYNC_FAILS'


# ── 설정 읽고 쓰기 ────────────────────────────────────────────────────────────
def _get(conn, key, dflt=''):
    try:
        r = conn.execute("SELECT config_val FROM user_config"
                         " WHERE config_key=?", (key,)).fetchone()
        return r[0] if r and r[0] is not None else dflt
    except Exception:
        return dflt


def _set(conn, key, val):
    cur = conn.execute("UPDATE user_config SET config_val=?"
                       " WHERE config_key=?", (str(val), key))
    if cur.rowcount == 0:
        conn.execute("INSERT INTO user_config(config_key, config_val)"
                     " VALUES(?,?)", (key, str(val)))


def seed(conn):
    """이 기기의 분산 씨앗 — 없으면 만든다.

    ⚠ **문의 통로의 `SUPPORT_UUID` 를 그대로 쓰지 않는다** — 목적이 다른 두
      기능이 한 값에 얽히면, 한쪽을 지우거나 바꿀 때 다른 쪽이 조용히 따라
      바뀐다. 여기 전용 씨앗을 둔다(밖으로 나가지 않는다).
    """
    s = _get(conn, K_SEED)
    if not s:
        import uuid
        s = uuid.uuid4().hex
        _set(conn, K_SEED, s)
        conn.commit()
    return s


def period(conn):
    v = _get(conn, K_PERIOD, DEFAULT_PERIOD)
    return v if v in PERIODS else DEFAULT_PERIOD


def window(conn):
    v = _get(conn, K_WINDOW, DEFAULT_WINDOW)
    return v if v in WINDOWS else DEFAULT_WINDOW


def set_period(conn, v):
    if v not in PERIODS:
        raise ValueError('모르는 주기: %r' % v)
    _set(conn, K_PERIOD, v)
    conn.commit()


def set_window(conn, v):
    if v not in WINDOWS:
        raise ValueError('모르는 시간대: %r' % v)
    _set(conn, K_WINDOW, v)
    conn.commit()


# ── 해시 분산 ────────────────────────────────────────────────────────────────
def bucket(seed_str, span, salt='slot'):
    """씨앗 → 0..span-1 의 **결정적** 값. 같은 씨앗은 늘 같은 값."""
    if span <= 0:
        return 0
    h = hashlib.sha256(('%s|%s' % (seed_str, salt)).encode('utf-8')).digest()
    return int.from_bytes(h[:8], 'big') % span


def slot_sec(seed_str, win=DEFAULT_WINDOW):
    """이 기기가 받을 **하루 중 시각**(0~86399초, 현지 시각 기준).

    시간대를 골랐으면 그 구간 안에서, 안 골랐으면 하루 전체에서 흩는다.
    """
    rng = WINDOWS.get(win)
    if not rng:
        return bucket(seed_str, 86400)
    lo, hi = rng
    span = (hi - lo) * 3600
    return (lo * 3600 + bucket(seed_str, span)) % 86400


def boot_delay(seed_str):
    """트레이가 막 떴을 때 기다릴 시간(초) — 일제 부팅을 흩는다."""
    return bucket(seed_str, BOOT_JITTER, salt='boot')


def backoff(seed_str, fails):
    """실패 n회 뒤 다음 시도까지(초). 지수 + ±20% 지터."""
    if fails <= 0:
        return 0
    base = min(BACKOFF_BASE * (2 ** (fails - 1)), BACKOFF_MAX)
    j = bucket(seed_str, 41, salt='bo%d' % fails) - 20      # -20..+20
    return int(base * (1 + j / 100.0))


# ── 판정 ─────────────────────────────────────────────────────────────────────
def should_fetch(conn, started_at, now=None):
    """지금 받을까? → (받을까, 이유).

    ★ 「지금이 내 슬롯 시각인가」가 아니라 **「주기가 지났는가」**로 본다 —
      PC 를 안 켜는 사람도 켠 김에 따라잡을 수 있어야 한다.
    """
    now = now or time.time()
    s = seed(conn)
    p = period(conn)
    if p == 'MANUAL':
        return False, 'MANUAL'
    wait = boot_delay(s)
    if now - started_at < wait:
        return False, 'BOOT_JITTER(%ds 남음)' % int(wait - (now - started_at))
    try:
        fails = int(_get(conn, K_FAILS, '0') or 0)
    except ValueError:
        fails = 0
    try:
        last = float(_get(conn, K_LAST_OK, '0') or 0)
    except ValueError:
        last = 0.0
    if fails:
        if now - last < backoff(s, fails):
            return False, 'BACKOFF(%d회 실패)' % fails
        return True, 'RETRY(%d회 실패 뒤)' % fails
    need = PERIODS[p]
    if last and now - last < need:
        return False, 'TOO_SOON(%dh 남음)' % int((need - (now - last)) / 3600)
    return True, 'DUE'


def seconds_until(conn, started_at, now=None):
    """다음 받을 차례까지 **몇 초** → 0(지금) · 초 · None(MANUAL — 영영 아님).

    ★ 앱이 「지금 받을까」를 10분마다 묻던 것을 걷었다(2026-09-29 사용자 「10분마다
      판정하는 것은 과도하다」). `should_fetch` 와 **같은 잣대**로 다음 때를 계산해
      그때 한 번만 깨어난다.
    """
    now = now or time.time()
    s = seed(conn)
    p = period(conn)
    if p == 'MANUAL':
        return None
    wait = boot_delay(s)
    if now - started_at < wait:
        return int(wait - (now - started_at)) + 1
    try:
        fails = int(_get(conn, K_FAILS, '0') or 0)
    except ValueError:
        fails = 0
    try:
        last = float(_get(conn, K_LAST_OK, '0') or 0)
    except ValueError:
        last = 0.0
    if fails:
        left = backoff(s, fails) - (now - last)
        return int(left) + 1 if left > 0 else 0
    need = PERIODS[p]
    if last and now - last < need:
        return int(need - (now - last)) + 1
    return 0


def mark_ok(conn, now=None):
    _set(conn, K_LAST_OK, '%.0f' % (now or time.time()))
    _set(conn, K_FAILS, '0')
    conn.commit()


def mark_fail(conn):
    try:
        n = int(_get(conn, K_FAILS, '0') or 0)
    except ValueError:
        n = 0
    _set(conn, K_FAILS, str(n + 1))
    conn.commit()
    return n + 1


def describe(conn):
    """사용자에게 보일 한 줄 — 「오전 4시 17분경에 받습니다」.

    ★ 추상적인 설정만 보이면 무슨 일이 일어나는지 모른다. **자기 시각**을
      계산해서 보인다.
    """
    p = period(conn)
    if p == 'MANUAL':
        return None
    s = slot_sec(seed(conn), window(conn))
    return (s // 3600) % 24, (s % 3600) // 60


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    import uuid
    from collections import Counter

    # ── 분산이 정말 균등한가 (1만 대 시뮬레이션) ──
    ids = [uuid.uuid4().hex for _ in range(10000)]
    slots = [slot_sec(i, 'ANY') for i in ids]
    per_sec = Counter(slots)
    per_min = Counter(s // 60 for s in slots)
    t('★ 1초 창 최대 5건 이하', max(per_sec.values()) <= 5,
      '%d건' % max(per_sec.values()))
    t('★ 1분 창 최대 40건 이하', max(per_min.values()) <= 40,
      '%d건' % max(per_min.values()))
    t('★ 하루 1,440분을 거의 다 쓴다', len(per_min) >= 1400,
      '%d분' % len(per_min))

    # 시간대를 고르면 그 안에만
    for w, (lo, hi) in ((k, v) for k, v in WINDOWS.items() if v):
        ss = [slot_sec(i, w) for i in ids[:500]]
        inside = all(lo * 3600 <= x < hi * 3600 or
                     (hi > 24 and (x >= lo * 3600 or x < (hi - 24) * 3600))
                     for x in ss)
        t('시간대 %s 안에만' % w, inside)
    nn = [slot_sec(i, 'NIGHT') for i in ids[:2000]]
    t('★ NIGHT 는 자정을 넘는다',
      any(x >= 22 * 3600 for x in nn) and any(x < 3600 for x in nn))

    # 결정적 — 같은 씨앗은 늘 같은 값
    a = slot_sec('abc', 'ANY')
    t('★ 같은 씨앗은 늘 같은 시각', all(slot_sec('abc', 'ANY') == a
                                        for _ in range(5)))
    t('★ 다른 씨앗은 다른 시각(대부분)',
      len({slot_sec(i, 'ANY') for i in ids[:200]}) > 190)

    # 백오프
    s = 'seed1'
    bs = [backoff(s, n) for n in range(1, 9)]
    t('백오프가 커진다', all(bs[i] < bs[i + 1] for i in range(4)), str(bs[:5]))
    t('백오프 상한', max(backoff(s, n) for n in range(1, 30)) <= BACKOFF_MAX * 1.2)
    t('실패 0이면 0', backoff(s, 0) == 0)
    t('★ 백오프에도 지터가 있다',
      len({backoff(str(i), 3) for i in range(50)}) > 10)
    t('부팅 지연이 한도 안', all(0 <= boot_delay(str(i)) < BOOT_JITTER
                                 for i in range(200)))

    # ── 판정 ──
    # ⚠⚠⚠ **`BEGIN`/`ROLLBACK` 으로는 못 막는다**(2026-09-03 실제로 당했다) —
    #   `set_period` 등이 안에서 `commit()` 을 부르므로 트랜잭션이 그 자리에서
    #   끝나고, 뒤의 ROLLBACK 은 「돌릴 것이 없다」로 죽는다. 그동안 값은
    #   **실 DB 에 그대로 쓰였다**(실측 SYNC_PERIOD 가 MANUAL 로 바뀌어 자동
    #   수집이 꺼졌다). §0-5 「selftest 는 실데이터를 안 건드린다」.
    #   ⇒ **시험 전 스냅샷 → 시험 → 원래대로**(없던 키는 지운다).
    conn = appdb.connect(DB)
    _keys = (K_SEED, K_PERIOD, K_WINDOW, K_LAST_OK, K_FAILS)
    _before = {}
    for _k in _keys:
        _r = conn.execute("SELECT config_val FROM user_config"
                          " WHERE config_key=?", (_k,)).fetchone()
        _before[_k] = _r[0] if _r else None
    try:
        sd = seed(conn)
        t('씨앗이 만들어진다', bool(sd) and len(sd) >= 16)
        t('씨앗은 두 번 불러도 같다', seed(conn) == sd)

        set_period(conn, 'DAILY')
        set_window(conn, 'ANY')
        now = 1_700_000_000.0
        boot = now - 10                     # 막 떴다
        go, why = should_fetch(conn, boot, now)
        t('★ 부팅 직후엔 안 받는다(지터)', not go and 'BOOT' in why, why)

        boot = now - BOOT_JITTER - 1        # 지터를 다 기다렸다
        _set(conn, K_LAST_OK, '0')
        _set(conn, K_FAILS, '0')
        go, why = should_fetch(conn, boot, now)
        t('★ 처음이면 받는다', go and why == 'DUE', why)

        mark_ok(conn, now)
        go, why = should_fetch(conn, boot, now + 3600)
        t('★ 1시간 뒤엔 안 받는다(하루 1회)', not go and 'TOO_SOON' in why, why)
        go, why = should_fetch(conn, boot, now + 86401)
        t('★ 하루 뒤엔 받는다', go, why)

        set_period(conn, 'MANUAL')
        go, why = should_fetch(conn, boot, now + 999999)
        t('★ 수동만이면 절대 안 받는다', not go and why == 'MANUAL', why)
        set_period(conn, 'DAILY')

        # 실패 → 백오프
        mark_ok(conn, now)
        n = mark_fail(conn)
        t('실패 셈', n == 1)
        go, why = should_fetch(conn, boot, now + 10)
        t('★ 실패 직후엔 기다린다', not go and 'BACKOFF' in why, why)
        go, why = should_fetch(conn, boot, now + backoff(sd, 1) + 1)
        t('★ 백오프가 끝나면 다시 시도', go and 'RETRY' in why, why)
        mark_ok(conn, now)
        t('성공하면 실패 셈이 0', _get(conn, K_FAILS) == '0')

        h, m = describe(conn)
        t('★ 사람이 읽을 시각을 낸다', 0 <= h < 24 and 0 <= m < 60,
          '%02d:%02d' % (h, m))
        set_period(conn, 'MANUAL')
        t('수동만이면 시각이 없다', describe(conn) is None)

        try:
            set_period(conn, 'BOGUS')
            bad = True
        except ValueError:
            bad = False
        t('★ 모르는 주기는 거부', not bad)
    finally:
        for _k, _v in _before.items():
            if _v is None:
                conn.execute("DELETE FROM user_config WHERE config_key=?",
                             (_k,))
            else:
                _set(conn, _k, _v)
        conn.commit()
    conn.close()

    # ★ 정말 원래대로인가 — 새 연결로 다시 읽어 대조한다
    c2 = appdb.connect(DB)
    now_vals = {}
    for _k in _keys:
        _r = c2.execute("SELECT config_val FROM user_config"
                        " WHERE config_key=?", (_k,)).fetchone()
        now_vals[_k] = _r[0] if _r else None
    c2.close()
    diff = [k for k in _keys if now_vals[k] != _before[k]]
    t('★ 시험 전 상태로 원복', not diff, str(diff) if diff else '5키 일치')
    print('sync_schedule selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--show', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if a.show:
        d = describe(conn)
        print('주기: %s · 시간대: %s' % (period(conn), window(conn)))
        print('씨앗: %s…' % seed(conn)[:8])
        if d:
            print('이 기기는 매일 약 %02d시 %02d분에 받습니다.' % d)
        else:
            print('자동 수집을 하지 않습니다(수동만).')
        go, why = should_fetch(conn, time.time() - BOOT_JITTER - 1)
        print('지금 받을까: %s (%s)' % (go, why))
    else:
        ap.print_help()
    conn.close()


if __name__ == '__main__':
    main()
