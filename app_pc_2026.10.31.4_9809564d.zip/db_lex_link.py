# -*- coding: utf-8 -*-
"""낱말↔절 연결 — 원어 낱말이 **어느 절에 있는지**를 양방향으로 담는다.

2026-09-12 사용자 지시 — 「시1:1의 복=아쉐르, 다른 곳의 복=바라크 …
**우리 용어사전이 매우 빈약하다** · 승격되지 않은 히브리어·헬라어 단어들을
활용할 방법」 → 「**속도에 지장이 없다면 진행하라** · 조사 같은 것들은 당연히
제거한다 · **동사, 형용사는 포함** · 겨, 나무, 물, 시내… **이런 것들 모두
추가하라**」.

  --check     무엇이 들어가는지 센다(쓰지 않는다)
  --apply     만든다(멱등 — 다시 돌리면 같은 값)
  --undo      표를 비운다(칸은 남긴다)
  --verse     한 절의 낱말을 본다      예) --verse 시1:1
  --word      한 낱말의 절을 본다      예) --word H835
  --selftest  자가검증(의무)

★★★ **표가 둘이고 방향마다 하나다** — 한 표로는 못 한다(실측).
  ```
  절 → 낱말   sys_verse_lemma(verse_id PK, strongs TEXT)   "H835 H376 …"
  낱말 → 절   sys_lemma_master 의 칸 둘(n_verse, verse_ids BLOB)
  ```
  ⚠⚠ 압축한 쪽만 두면 「이 절의 낱말」을 **못 낸다** — 낱말마다 묶여 있어
    뒤집을 수 없다. 두 방향을 다 쓰므로 표가 둘이라야 한다.
  ✅ 실측 — 합 **3.14 MB** · 절→낱말 22ms/천번 · 낱말→절 58ms/천번.
    짝마다 한 줄로 하면 12.4 MB · 지금 `sys_entity_verse` 꼴이면 **14.6 MB** 에
    낱말 조회가 **3배 느리다**.

⚠⚠⚠ **`sys_entity_verse` 에 넣지 않는다** — 거기는 **사람이 만든 용어 578개**의
  자리(18,868행)다. 30만 줄이 들어오면 덮어 버리고, `entity_id` 를 쓰려면
  `LEX` 엔티티 10,892개를 유지해야 해서 마스터·이름·앵커 **세 표**가 부푼다.

★★★ **낱말은 거르고 절은 거르지 않는다**(사용자 걱정 「구절을 선별하다 보면
  중요한 것이 누락될 위험」의 답). 잣대로 절을 자르면 사용자가 물은 **「겨」가
  빠진다 — 8절짜리**다. 3 MB 면 다 넣어도 되므로 **고르지 않는 것이 가장 싸다.**

⚠ 원어 본문은 **로컬 전용**이다(§18-10 · `wlc_verify.db`·`gnt_verify.db`).
  여기서 뽑는 것은 **Strong 번호뿐**이고 본문 글자는 안 싣는다.
  ⚠ 번호 층이 CC BY 4.0(OSHB)이라 배포하면 **표기 의무**가 생긴다 —
    `license_info.py` 에 한 줄(§12-0 이 이미 그렇게 적었다).
"""
import collections
import io
import os
import re
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb                                                  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
#: 원어 본문 — **로컬 전용**. 없으면 만들 수 없다(조용히 0건이 되지 않는다).
SOURCES = (('wlc_verify.db', 'wlc_verse'), ('gnt_verify.db', 'gnt_verse'))

#: ★ **빼는 품사 ① 조사·전치사·접속사류**(사용자 「조사 같은 것들은 당연히
#:   제거한다」). 실측 **낱말 156개가 짝 41,913개**를 먹는다 — 빼는 값이 가장 크다.
#:   `inj` 19개는 전부 「오!·아!·슬프도다」다(실측).
GRAM_POS = frozenset(('prt', 'prep', 'r', 'adv', 'conj', 'x', 'inj'))

#: ★ **빼는 품사 ② 고유명사** — **이미 용어로 있다**(다윗·예루살렘·모세).
#:   실측 낱말 2,369개 · 짝 28,963개. 넣으면 같은 것이 두 자리에 생긴다.
NAME_POS = frozenset(('n-pr-m', 'n-pr-loc', 'n-pr-f', 'n-pr',
                      'n-pr-m n-pr-loc'))

#: ⚠ **`kôl`(H3605 「모든」)은 뺄까 망설였으나 넣었다** — 품사가 `n-m`(명사)라
#:   잣대(품사 하나)로는 안 걸린다. **예외 목록을 만들면 잣대가 둘이 되어
#:   다음에 고칠 수 없다.** 짝의 1.6%라 잡음보다 잃는 것이 크다
#:   (「**모든** 육체」·「**모든** 민족」은 뜻이 있는 자리다).

_RX_STRONG = re.compile(r'[^HG0-9]+')


def keep_pos(pos: str) -> bool:
    """이 품사를 넣나. ★ **잣대는 품사 하나뿐** — 낱말을 손으로 선택하지 않는다.

    ⚠ 헬라어는 `pos` 가 **통째로 비어 있다**(실측 EL 5,417개 전부). 빈칸을
      「빼기」로 읽으면 신약이 통째로 사라지므로 **넣는 쪽으로** 읽는다.
      헬라어 문법어 거르기는 품사를 채운 뒤의 **별도 걸음**이다.
    """
    p = (pos or '').strip()
    return p not in GRAM_POS and p not in NAME_POS


def pack(vids) -> bytes:
    """절 번호 목록 → 바이트. **앞 절과의 차이**를 가변 길이 정수로 적는다.

    ★ 절 번호가 오름차순이라 차이가 대개 한 자리다 — 그래서 0.76 MB 에 들어간다.
    """
    prev, out = 0, bytearray()
    for v in vids:
        d = int(v) - prev
        if d < 0:
            raise ValueError('오름차순이 아니다: %d 뒤에 %d' % (prev, v))
        prev = int(v)
        while d >= 0x80:
            out.append((d & 0x7F) | 0x80)
            d >>= 7
        out.append(d)
    return bytes(out)


def unpack(blob) -> list:
    """`pack` 을 되돌린다."""
    out, prev, cur, sh = [], 0, 0, 0
    for b in (blob or b''):
        cur |= (b & 0x7F) << sh
        if b & 0x80:
            sh += 7
        else:
            prev += cur
            out.append(prev)
            cur, sh = 0, 0
    return out


def ensure(conn):
    """표와 칸을 만든다(멱등)."""
    conn.execute("CREATE TABLE IF NOT EXISTS sys_verse_lemma("
                 " verse_id INTEGER PRIMARY KEY, strongs TEXT)")
    have = {r[1] for r in conn.execute("PRAGMA table_info(sys_lemma_master)")}
    if 'n_verse' not in have:
        conn.execute("ALTER TABLE sys_lemma_master ADD COLUMN n_verse INTEGER")
    if 'verse_ids' not in have:
        conn.execute("ALTER TABLE sys_lemma_master ADD COLUMN verse_ids BLOB")


#: ★★★ **가려진 낱말은 화면에 안 낸다 — 상태 래칫이 그 자리에서 잡았다**
#:   (2026-09-12). `sys_lemma_master` 에 `record_status='HIDE'` 가 **124개**
#:   있고 그것은 **사람이 일부러 가린 것**이다(§195차 「엘」 사건 — `ʼêl`
#:   「이것들」·`ʼôw`「또는」 같은 지시·접속 낱말이 정통 자료를 먹었다).
#: ⚠⚠ **만드는 쪽과 읽는 쪽을 다 고친다** — 만드는 쪽만 고치면 나중에 누가
#:   가려도 **다시 만들기 전까지 그대로 뜬다**(§121차 덮개 원칙).
_LIVE = "COALESCE(record_status,'LIVE')='LIVE'"


def _pos_map(conn):
    """낱말 → 품사. ⚠ **가려진 것도 담는다** — 가리는 일은 `_hidden` 이 한다."""
    return dict(conn.execute(
        # status-ok: 가리는 일은 `_hidden` 이 맡는다 — 여기서 또 걸면 자리가
        #   둘이 되어 「어느 쪽이 진짜인가」를 나중에 못 가른다. 이 표는
        #   **품사를 묻는 것**이고 가려진 낱말은 `scan` 이 먼저 버린다.
        "SELECT strong, COALESCE(pos,'') FROM sys_lemma_master"))


def _hidden(conn):
    """가려진 낱말 번호. ⚠⚠ **「사전에 없는 낱말」과 섞지 말 것** — 첫 판이
    「품사 표에 있는 것만」으로 막았다가 **짝 120,953개를 함께 버렸다**(실측).
    사전에 없는 낱말은 가려진 것이 아니라 **아직 안 담긴 것**이다."""
    return {r[0] for r in conn.execute(
        "SELECT strong FROM sys_lemma_master WHERE NOT (" + _LIVE + ")")}


def scan(pos_map=None, src_dir=HERE, hidden=None):
    """원어 본문을 훑어 → (절→낱말 dict, 낱말→절 dict, 통계).

    ⚠ **본문 차례를 지킨다** — 절 쪽은 나온 순서 그대로 적는다(중복은 뺀다).
    """
    pos_map = pos_map if pos_map is not None else {}
    per_verse, by_word = {}, collections.defaultdict(list)
    stat = collections.Counter()
    missing = []
    for fn, tbl in SOURCES:
        p = os.path.join(src_dir, fn)
        if not os.path.exists(p):
            missing.append(fn)
            continue
        c = sqlite3.connect(p)
        try:
            rows = c.execute("SELECT verse_id, strongs FROM %s" % tbl).fetchall()
        finally:
            c.close()
        for vid, s in rows:
            seen, keep = set(), []
            for st in _RX_STRONG.split(s or ''):
                if len(st) < 2 or st[0] not in 'HG':
                    continue
                stat['짝(전체)'] += 1
                # ★★★ **가려진 낱말을 뺀다**(실측 — HIDE 69개가 절을 갖고
                #   화면에 떠 있었다). ⚠ `keep_pos` 는 품사 빈칸을 「넣기」로
                #   읽으므로(헬라어가 통째로 사라지지 않게) 여기서 따로 본다.
                if hidden and st in hidden:
                    stat['가려진 짝'] += 1
                    continue
                if not keep_pos(pos_map.get(st, '')):
                    stat['뺀 짝'] += 1
                    continue
                if st in seen:
                    continue
                seen.add(st)
                keep.append(st)
            if keep:
                per_verse[vid] = ' '.join(keep)
                for st in keep:
                    by_word[st].append(vid)
    for k in by_word:
        by_word[k].sort()
    stat['절'] = len(per_verse)
    stat['낱말'] = len(by_word)
    stat['짝(넣을 것)'] = sum(len(v) for v in by_word.values())
    return per_verse, by_word, stat, missing


def build(conn, dry=False, src_dir=HERE, log=print):
    """만든다. 멱등 — 다시 돌리면 같은 값이 된다."""
    ensure(conn)
    per_verse, by_word, stat, missing = scan(
        _pos_map(conn), src_dir, hidden=_hidden(conn))
    if missing:
        log('⚠ 원어 본문이 없다: %s — 만들 수 없다' % ', '.join(missing))
        if not per_verse:
            return stat
    for k in ('짝(전체)', '뺀 짝', '가려진 짝', '짝(넣을 것)', '절', '낱말'):
        log('  %-12s %s' % (k, format(stat.get(k, 0), ',')))
    if dry:
        return stat
    conn.execute("DELETE FROM sys_verse_lemma")
    conn.executemany("INSERT INTO sys_verse_lemma(verse_id, strongs) VALUES(?,?)",
                     sorted(per_verse.items()))
    conn.execute("UPDATE sys_lemma_master SET n_verse=NULL, verse_ids=NULL")
    conn.executemany(
        "UPDATE sys_lemma_master SET n_verse=?, verse_ids=? WHERE strong=?",
        [(len(v), pack(v), k) for k, v in by_word.items()])
    conn.commit()
    return stat


def undo(conn, log=print):
    """표를 비운다. ⚠ **칸은 남긴다** — 지우려면 표를 다시 지어야 한다."""
    try:
        conn.execute("DELETE FROM sys_verse_lemma")
        conn.execute("UPDATE sys_lemma_master SET n_verse=NULL, verse_ids=NULL")
        conn.commit()
        log('비웠다')
    except sqlite3.OperationalError as e:
        log('없다: %s' % e)


# ── 읽는 문 — 화면은 이 둘만 쓴다 ───────────────────────────────────────
def lemma_key(strong) -> int:
    """스트롱 번호 → 정수 열쇠(`sys_text_asset.clicked_id` 용) — H835 → 1000835 ·
    G907 → 2000907. 장 설명문의 `bcode*1000+장` 과 같은 방식(§3-1). 스트롱
    사전 번역문(`LEMMA_DEF`)이 이 열쇠로 언어별 행을 갖는다(2026-09-15).
    ⚠ **이 함수 밖에서 열쇠를 계산하지 말 것.**"""
    s = str(strong or '').strip().upper()
    if not s or s[0] not in 'HG' or not s[1:].isdigit():
        raise ValueError('스트롱 번호가 아니다: %r' % (strong,))
    return (1000000 if s[0] == 'H' else 2000000) + int(s[1:])


def strong_of_key(key) -> str:
    """`lemma_key` 의 거울."""
    key = int(key)
    return ('H%d' % (key - 1000000)) if key < 2000000 else ('G%d' % (key - 2000000))


def lemmas_of(conn, verse_id) -> list:
    """그 절의 낱말 번호 — **본문에 나온 차례**."""
    r = conn.execute("SELECT strongs FROM sys_verse_lemma WHERE verse_id=?",
                     (verse_id,)).fetchone()
    return (r[0] or '').split() if r else []


def verses_of(conn, strong) -> list:
    """그 낱말이 있는 절 — 오름차순."""
    r = conn.execute("SELECT verse_ids FROM sys_lemma_master WHERE strong=?"
                     "   AND " + _LIVE, (strong,)).fetchone()
    return unpack(r[0]) if r and r[0] else []


def word_info(conn, strong):
    """화면에 보일 것 — 원어 글자·음역·뜻·절 수. ⚠ **한국어 이름은 없다**."""
    r = conn.execute(
        "SELECT COALESCE(form,''), COALESCE(translit,''), COALESCE(gloss,''),"
        "       COALESCE(pos,''), COALESCE(n_verse,0)"
        "  FROM sys_lemma_master WHERE strong=? AND " + _LIVE,
        (strong,)).fetchone()
    if not r:
        return None
    return {'strong': strong, 'form': r[0], 'translit': r[1],
            'gloss': r[2], 'pos': r[3], 'n_verse': r[4]}


# ── 자가검증 ───────────────────────────────────────────────────────────
def selftest():
    # ★ 열쇠 왕복 (2026-09-15)
    assert lemma_key('H835') == 1000835 and lemma_key('G907') == 2000907
    assert strong_of_key(1000835) == 'H835' and strong_of_key(2000907) == 'G907'
    assert _raises(lambda: lemma_key('X1')) and _raises(lambda: lemma_key('H'))
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    # ① 압축 왕복
    for vs in ([], [1], [1, 2, 3], [5, 300, 70000, 70001],
               list(range(1, 400)), [31104]):
        t('압축 왕복 %d개' % len(vs), unpack(pack(vs)) == vs, vs[:5])
    t('★ 오름차순이 아니면 거부한다',
      _raises(lambda: pack([5, 3])))
    t('  빈 것은 빈 것', unpack(pack([])) == [])
    big = pack(list(range(1, 1001)))
    t('★ 압축이 실제로 작다(1,000절이 1KB 안)', len(big) <= 1100, len(big))

    # ② 품사 잣대
    t('★ 조사·전치사를 뺀다',
      not keep_pos('prep') and not keep_pos('conj') and not keep_pos('prt')
      and not keep_pos('adv') and not keep_pos('r') and not keep_pos('inj'))
    t('★★ **동사·형용사·명사는 넣는다**(사용자 지시)',
      keep_pos('v') and keep_pos('a') and keep_pos('n-m')
      and keep_pos('n-f') and keep_pos('n'))
    t('★ 고유명사는 뺀다(이미 용어로 있다)',
      not keep_pos('n-pr-m') and not keep_pos('n-pr-loc')
      and not keep_pos('n-pr-f'))
    t('★★★ **품사가 비면 넣는다**(헬라어가 통째로 사라지지 않게)',
      keep_pos('') and keep_pos(None))

    # ③ 메모리 DB 로 왕복
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_lemma_master(strong TEXT PRIMARY KEY,"
              " form TEXT, translit TEXT, gloss TEXT, pos TEXT,"
              " record_status TEXT DEFAULT 'LIVE')")
    c.executemany("INSERT INTO sys_lemma_master"
                  "(strong, form, translit, gloss, pos) VALUES(?,?,?,?,?)", [
        ('H835', 'אֶשֶׁר', 'ʼesher', 'happiness', 'n-m'),
        ('H4671', 'מֹץ', 'môts', 'chaff', 'n-m'),
        ('H1288', 'בָּרַךְ', 'bârak', 'to kneel; to bless', 'v'),
        ('H853', 'אֵת', 'ʼêth', '(et)', 'prt'),
        ('H1732', 'דָּוִד', 'Dâvid', 'David', 'n-pr-m'),
        ('G3107', 'μακάριος', 'makários', 'supremely blest', ''),
    ])
    ensure(c)
    have = {r[1] for r in c.execute("PRAGMA table_info(sys_lemma_master)")}
    t('칸 둘이 생겼다', 'n_verse' in have and 'verse_ids' in have)
    ensure(c)      # 두 번 불러도 터지지 않는다
    t('★ 멱등 — 두 번 불러도 된다', True)

    # 가짜 원어 본문
    d = os.path.join(os.environ.get('TEMP', '.'), '_lexlink_t')
    os.makedirs(d, exist_ok=True)
    for fn, tbl, rows in (
            ('wlc_verify.db', 'wlc_verse',
             [(10, 'H835 H853 H1732 H1288'), (11, 'H4671 H853'),
              (12, 'H1288 H1288 H835')]),
            ('gnt_verify.db', 'gnt_verse', [(900, 'G3107 G3107')])):
        p = os.path.join(d, fn)
        if os.path.exists(p):
            os.remove(p)
        x = sqlite3.connect(p)
        x.execute("CREATE TABLE %s(verse_id INTEGER, grk TEXT, strongs TEXT)"
                  % tbl if tbl == 'gnt_verse' else
                  "CREATE TABLE %s(verse_id INTEGER, heb TEXT, strongs TEXT)" % tbl)
        x.executemany("INSERT INTO %s VALUES(?,'',?)" % tbl, rows)
        x.commit()
        x.close()
    build(c, src_dir=d, log=lambda *_a: None)

    t('★★★ 절→낱말 — 조사와 고유명사가 빠진다',
      lemmas_of(c, 10) == ['H835', 'H1288'], lemmas_of(c, 10))
    t('  ⚠ **본문 차례를 지킨다**', lemmas_of(c, 10)[0] == 'H835')
    t('  같은 낱말이 두 번 나와도 한 번만',
      lemmas_of(c, 12) == ['H1288', 'H835'], lemmas_of(c, 12))
    t('★ 낱말만 남으면 그 절도 남는다', lemmas_of(c, 11) == ['H4671'])
    t('★★★ 낱말→절', verses_of(c, 'H1288') == [10, 12], verses_of(c, 'H1288'))
    t('  겨는 한 절', verses_of(c, 'H4671') == [11])
    t('★★ **조사는 아무 절도 없다**', verses_of(c, 'H853') == [])
    t('★★ **고유명사도 없다**(용어가 맡는다)', verses_of(c, 'H1732') == [])
    t('★★★ **품사 빈 헬라어는 들어간다**', verses_of(c, 'G3107') == [900])
    # ★★★ **가려진 낱말** — 상태 래칫이 실제 DB 에서 69개를 잡았다
    c.execute("UPDATE sys_lemma_master SET record_status='HIDE'"
              " WHERE strong='H4671'")
    build(c, src_dir=d, log=lambda *_a: None)
    t('★★ **사전에 없는 낱말은 그대로 넣는다**(가린 것과 다르다)',
      verses_of(c, 'G3107') == [900], verses_of(c, 'G3107'))
    t('★★★ **가려진 낱말은 절이 안 붙는다**', verses_of(c, 'H4671') == [],
      verses_of(c, 'H4671'))
    t('  ★ 그 절의 낱말 목록에서도 빠진다', 'H4671' not in lemmas_of(c, 11),
      lemmas_of(c, 11))
    t('  ★ 정보도 안 낸다', word_info(c, 'H4671') is None)
    t('  ⚠ 안 가린 낱말은 그대로', verses_of(c, 'H1288') == [10, 12])
    c.execute("UPDATE sys_lemma_master SET record_status='LIVE'"
              " WHERE strong='H4671'")
    build(c, src_dir=d, log=lambda *_a: None)
    t('★ 되살리면 돌아온다', verses_of(c, 'H4671') == [11])
    # ⚠⚠ **읽는 쪽도 듣는다** — 다시 만들기 전에 가려도 즉시(§121차)
    c.execute("UPDATE sys_lemma_master SET record_status='HIDE'"
              " WHERE strong='H1288'")
    t('★★★ **다시 만들지 않아도 읽는 문이 가린다**',
      verses_of(c, 'H1288') == [] and word_info(c, 'H1288') is None)
    c.execute("UPDATE sys_lemma_master SET record_status='LIVE'"
              " WHERE strong='H1288'")
    t('  두 방향이 서로 맞는다',
      all(v in verses_of(c, 'H835') for v in (10, 12))
      and 'H835' in lemmas_of(c, 10))
    i = word_info(c, 'H4671')
    t('★ 화면 재료 — 원어 글자·음역·뜻',
      i and i['form'] == 'מֹץ' and i['translit'] == 'môts'
      and i['n_verse'] == 1, i)
    t('  ⚠ 한국어 이름은 **안 만든다**(기계로 지으면 절반이 틀린다)',
      'name_ko' not in (i or {}))

    # 멱등 — 다시 돌려도 같다
    a = (sorted(c.execute("SELECT * FROM sys_verse_lemma")),
         sorted(c.execute("SELECT strong, n_verse FROM sys_lemma_master")))
    build(c, src_dir=d, log=lambda *_a: None)
    b = (sorted(c.execute("SELECT * FROM sys_verse_lemma")),
         sorted(c.execute("SELECT strong, n_verse FROM sys_lemma_master")))
    t('★★ **멱등 — 다시 돌리면 같은 값**', a == b)

    # 되돌리기
    undo(c, log=lambda *_a: None)
    t('★ 되돌리면 비는다',
      not lemmas_of(c, 10) and not verses_of(c, 'H1288')
      and c.execute("SELECT COUNT(*) FROM sys_verse_lemma").fetchone()[0] == 0)
    t('  ⚠ 칸은 남는다(되돌릴 자리)',
      'verse_ids' in {r[1] for r in
                      c.execute("PRAGMA table_info(sys_lemma_master)")})
    build(c, src_dir=d, log=lambda *_a: None)
    t('★ 되돌린 뒤 다시 만들어진다', verses_of(c, 'H1288') == [10, 12])

    # ④ 없는 것을 물으면
    t('없는 낱말은 빈 목록', verses_of(c, 'H99999') == [])
    t('없는 절도 빈 목록', lemmas_of(c, 99999) == [])
    t('없는 낱말 정보는 None', word_info(c, 'H99999') is None)

    # ⑤ 원어 본문이 없으면 — **조용히 0건이 되지 않는다**
    msg = []
    c2 = sqlite3.connect(':memory:')
    c2.execute("CREATE TABLE sys_lemma_master(strong TEXT PRIMARY KEY,"
               " form TEXT, translit TEXT, gloss TEXT, pos TEXT,"
               " record_status TEXT DEFAULT 'LIVE')")
    build(c2, src_dir=os.path.join(d, '_none'), log=msg.append)
    t('★★★ **원어 본문이 없으면 말한다**(§0-1)',
      any('없다' in str(x) for x in msg), msg[:1])
    c2.close()
    c.close()

    # ⑥ 배포 분류가 있는가 — §196차 장치
    try:
        src = io.open(os.path.join(HERE, 'db_pack_catalog.py'),
                      encoding='utf-8').read()
        t('★ 배포 분류에 새 표가 있다', 'sys_verse_lemma' in src)
    except Exception as e:
        t('배포 분류 확인', False, e)

    print('db_lex_link selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def _raises(fn):
    try:
        fn()
        return False
    except Exception:
        return True


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    conn.execute("PRAGMA busy_timeout=60000")
    try:
        if '--undo' in argv:
            undo(conn)
        elif '--apply' in argv:
            build(conn)
            print('완료')
        elif '--verse' in argv:
            import scripture_ref_kr as SR
            ref = argv[argv.index('--verse') + 1]
            bc, ch, vs = SR.resolve(ref)[0], None, None
            print(ref, '→', lemmas_of(conn, int(ref)) if ref.isdigit() else '(번호로 주세요)')
        elif '--word' in argv:
            st = argv[argv.index('--word') + 1]
            i = word_info(conn, st)
            vs = verses_of(conn, st)
            print('%s %s %s — %s' % (st, (i or {}).get('form', ''),
                                     (i or {}).get('translit', ''),
                                     (i or {}).get('gloss', '')[:50]))
            print('  %d절: %s%s' % (len(vs), vs[:20], ' …' if len(vs) > 20 else ''))
        else:
            build(conn, dry=True)
    finally:
        conn.close()


if __name__ == '__main__':
    main(sys.argv[1:])
