# -*- coding: utf-8 -*-
"""PERI_DESC 초안 검증 · 적재 (영구 도구)

  python -X utf8 db_peri_load.py --check <draft.json>            # 검증만, DB 무변경
  python -X utf8 db_peri_load.py --apply <draft.json>            # 적재 + 게이트 + peri.md
  python -X utf8 db_peri_load.py --apply <draft.json> --commit   # 위 + 커밋 + 푸시

이전에는 장마다 temp_db_peri_markNN.py 를 새로 만들어 돌렸다. 파일명이 매번
달라져 허용 목록이 다시 물었고, 적재·게이트·peri.md 갱신·커밋이 각각 따로라
한 장에 승인이 열 번 넘게 필요했다. 이름이 고정된 이 도구가 그 전부를 대신한다.

draft.json
{
  "book": 41,
  "peris": { "7499": {"KO": "...", "EN": "..."}, ... },
  "title_fix": { "7500": {"KO": "새 제목"} },          # 선택
  "commit_subject": "content(peri): 마가 14장 ...",     # --commit 일 때 필요
  "commit_body": "여러 줄 본문"
}

검증은 db_peri_gate 의 검사를 그대로 쓴다(단일 소스). 검증을 통과하지 못하면
--apply 라도 DB 를 건드리지 않는다.
"""
import argparse
import datetime
import io
import json
import os
import re
import subprocess
import sys

import appdb
import db_peri_gate as g
import db_peri_prep as prep

DB = 'bible_master.db'
PERI_MD = 'peri.md'


# ── 검증 ────────────────────────────────────────────────────────────────────
def build_rows(conn, draft):
    """게이트가 먹는 행 + 겹침용 vid 표를 만든다. 제목은 title_fix 적용 후 값."""
    rows, vids, meta = [], {}, {}
    tfix = {int(k): v for k, v in (draft.get('title_fix') or {}).items()}
    for spid, texts in draft['peris'].items():
        pid = int(spid)
        r = conn.execute(
            """SELECT p.start_vid, p.end_vid, bi.bcode, bi.chapter, bi.verse,
                      bj.chapter, bj.verse
                 FROM sys_pericope_asset p
                 JOIN bible_index bi ON bi.verse_id=p.start_vid
                 JOIN bible_index bj ON bj.verse_id=p.end_vid
                WHERE p.pericope_id=?""", (pid,)).fetchone()
        if not r:
            raise SystemExit(f'peri {pid} 없음')
        sv, ev, bcode, c1, v1, c2, v2 = r
        ref = f'{bcode} {c1}:{v1}-{c2}:{v2}'
        vids[pid] = (sv, ev)
        meta[pid] = (ref, c1, ev - sv + 1)
        tko = conn.execute("SELECT title FROM sys_text_asset WHERE clicked_id=? "
                           "AND text_type='PERI_TITLE' AND lang_code='KO'", (pid,)).fetchone()
        ten = conn.execute("SELECT title FROM sys_text_asset WHERE clicked_id=? "
                           "AND text_type='PERI_TITLE' AND lang_code='EN'", (pid,)).fetchone()
        tko = tko[0] if tko else None
        ten = ten[0] if ten else None
        if pid in tfix:
            tko = tfix[pid].get('KO', tko)
            ten = tfix[pid].get('EN', ten)
        for lang in ('KO', 'EN'):
            t = (texts.get(lang) or '').strip()
            if not t:
                raise SystemExit(f'peri {pid} {lang} 이 비어 있다.')
            rows.append((pid, ref, tko, ten, lang, None, t))
    return rows, vids, meta


def claim_notice(conn, draft):
    """본문 밖 사실을 주장하는 문장을 **적재 전에** 눈앞에 띄운다 (2026-08-03 신설).

    사용자 지시: *"반드시 기억이 아니라 자료에 근거해서 확인한 것만 기록하라."*
    행 23:1 에서 파라미터에서 나온 인물평을 `그 시대 기록에 … 남아 있으니` 라고
    출처가 있는 것처럼 단언한 일이 있었다. 문체 게이트는 이런 것을 전혀 보지 못한다.

    **실패로 걸지 않는다.** 기계가 한국어 설명문과 영어 주석을 대조할 수 없어
    판정이 불가능하기 때문이다. 대신 **확인 없이 지나가는 일은 막는다** —
    목록이 눈앞에 뜨면 `comm_*.md` 에서 찾아보게 된다(peri.md §3-3b).
    """
    try:
        import db_claim_audit as ca
    except Exception:
        return
    hits = []
    for spid, texts in draft['peris'].items():
        for grade, kind, s in ca.claims(texts.get('KO') or ''):
            hits.append((spid, grade, kind, s))
    if not hits:
        return
    hard = sum(1 for h in hits if h[1] == 'HARD')
    print(f'\n  ── 본문 밖 사실 주장 {len(hits)}건(강 {hard}) — '
          f'적재 전에 주석에서 확인할 것 ' + '─' * 12)
    for spid, grade, kind, s in hits:
        print(f'  [{grade}/{kind}] peri {spid}: {s.strip()[:110]}')
    print('  근거를 못 찾으면 빼거나 본문이 받쳐 주는 것으로 바꾼다 (peri.md §3-3b).')


def validate(conn, draft, verbose=True):
    rows, vids, meta = build_rows(conn, draft)
    if verbose:
        for pid in sorted({r[0] for r in rows}):
            sv, ev = vids[pid]
            for lang in ('KO', 'EN'):
                t = next(r[6] for r in rows if r[0] == pid and r[4] == lang)
                sents = [x for x in re.split(r'(?<=[.!?])\s+', t) if x.strip()]
                avg = len(t) / len(sents) if sents else 0
                extra = ''
                if lang == 'KO':
                    pct, _ = g.overlap_pct(conn, t, sv, ev)
                    extra = f' · 겹침 {pct}%'
                    # 서술 균형(peri.md §3-3) — 목표 배경 0.3+ · 의미 1.5+ · 나열 1.0-
                    # 실패로 걸지 않고 매번 눈앞에 띄운다. 낱말 대리 지표라 상한을
                    # 걸면 낱말을 바꿔치기하는 쪽으로 도망가기 때문이다.
                    b, m, e = (len(p.findall(t)) / len(t) * 1000
                               for _, p, _, _ in g.BALANCE)
                    extra += f' · 배경 {b:.1f}/의미 {m:.1f}/나열 {e:.1f}'
                print(f'  peri {pid} {lang}: {len(t)}자 · {len(sents)}문장 · '
                      f'평균 {avg:.1f}자{extra}')
    ov_fail, ov_warn = g.overlap_scan(conn, rows, vids)
    bad = g.check(conn, rows) + g.pair_check(rows) + ov_fail
    if verbose:
        print()
        for tag, msg in ov_warn:
            print(f'  ! {tag}: {msg}')
        claim_notice(conn, draft)
    if bad:
        print(f'검증 FAIL — 위반 {len(bad)}건')
        for tag, msg in bad:
            print(f'  X {tag} {msg}')
        return False, meta
    print('검증 PASS — 위반 0건'
          + (f' (겹침 경고 {len(ov_warn)}건 — 낱말 확인 후 판단)' if ov_warn else ''))
    return True, meta


# ── 적재 ────────────────────────────────────────────────────────────────────
def apply(conn, draft):
    tfix = {int(k): v for k, v in (draft.get('title_fix') or {}).items()}
    for pid, langs in sorted(tfix.items()):
        for lang, new in langs.items():
            old = conn.execute("SELECT title FROM sys_text_asset WHERE clicked_id=? "
                               "AND text_type='PERI_TITLE' AND lang_code=?",
                               (pid, lang)).fetchone()
            if old and old[0] != new:
                conn.execute("UPDATE sys_text_asset SET title=? WHERE clicked_id=? "
                             "AND text_type='PERI_TITLE' AND lang_code=?", (new, pid, lang))
                print(f'  제목 {pid} [{lang}]: {old[0]} -> {new}')
    ts = datetime.date.today().isoformat() + 'T00:00:00'
    dele = ins = 0
    for spid, texts in draft['peris'].items():
        pid = int(spid)
        cur = conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? "
                           "AND text_type='PERI_DESC'", (pid,))
        dele += cur.rowcount
        for lang in ('KO', 'EN'):
            conn.execute(
                "INSERT INTO sys_text_asset (clicked_id, text_type, contents, lang_code, "
                "record_status, created_at, text_variant) VALUES (?,?,?,?,'LIVE',?,NULL)",
                (pid, 'PERI_DESC', texts[lang].strip(), lang, ts))
            ins += 1
    conn.commit()
    print(f'삭제 {dele}행 · 삽입 {ins}행')


# ── 진행상태 ────────────────────────────────────────────────────────────────
def coverage(conn, bcode):
    rows = conn.execute(
        """SELECT bi.chapter, p.pericope_id,
                  (SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=p.pericope_id
                    AND text_type='PERI_DESC' AND COALESCE(record_status,'LIVE')='LIVE')
             FROM sys_pericope_asset p JOIN bible_index bi ON bi.verse_id=p.start_vid
            WHERE p.peri_type='BODY' AND bi.bcode=?
              AND COALESCE(p.record_status,'LIVE')='LIVE'""", (bcode,)).fetchall()
    total = len(rows)
    done = sum(1 for r in rows if r[2] > 0)
    by_ch = {}
    for ch, _pid, n in rows:
        by_ch.setdefault(ch, []).append(n > 0)
    full = 0
    for ch in sorted(by_ch):
        if all(by_ch[ch]):
            full = ch
        else:
            break
    return total, done, full


def update_peri_md(conn, bcode):
    if not os.path.exists(PERI_MD):
        print(f'  ! {PERI_MD} 없음 — 진행상태 갱신 생략'); return
    total, done, full = coverage(conn, bcode)
    remain = total - done
    s = io.open(PERI_MD, encoding='utf-8').read()
    orig = s
    today = datetime.date.today().isoformat()
    hits = []

    # 책 진행 행:  | 마가복음(41) | 96 | **진행 중** — **1~13장 74개 완료**(2026-08-02, …
    def fix_row(m):
        body = m.group(3)
        body = re.sub(r'\*\*\d+~\d+장 \d+개 완료\*\*',
                      f'**1~{full}장 {done}개 완료**', body)
        body = re.sub(r'\((\d{4}-\d{2}-\d{2})', f'({today}', body, count=1)
        return f'{m.group(1)}{m.group(2)}{body}'

    pat = re.compile(r'(^\|[^|\n]*\(%d\)\s*\|)([^|\n]*\|)([^\n]*)$' % bcode, re.M)
    s, n = pat.subn(fix_row, s)
    hits.append(('책 진행 행', n))

    # 잔여 건수는 진행표의 '대기' 행과 '다음 작업' 줄에만 있다. 전역 치환하면
    # 무관한 문단('RU·AR 잔여 12·112건' 등)까지 바꾼다 — 줄 단위로 좁힌다.
    def fix_remain(line):
        if '잔여' not in line or not ('대기' in line or '다음 작업' in line):
            return line, 0
        return re.subn(r'(잔여\s*)\d+', lambda m: f'{m.group(1)}{remain}', line)

    lines, n = [], 0
    for line in s.split('\n'):
        line, k = fix_remain(line)
        n += k
        lines.append(line)
    s = '\n'.join(lines)
    hits.append(('잔여 건수', n))

    nxt = conn.execute(
        """SELECT bi.chapter, MIN(p.pericope_id) FROM sys_pericope_asset p
             JOIN bible_index bi ON bi.verse_id=p.start_vid
            WHERE p.peri_type='BODY' AND bi.bcode=?
              AND COALESCE(p.record_status,'LIVE')='LIVE'
              AND NOT EXISTS (SELECT 1 FROM sys_text_asset WHERE clicked_id=p.pericope_id
                    AND text_type='PERI_DESC' AND COALESCE(record_status,'LIVE')='LIVE')
            GROUP BY bi.chapter ORDER BY bi.chapter LIMIT 1""", (bcode,)).fetchone()
    if nxt:
        # 책 이름에 공백이 있을 수 있으므로(`마가복음 14장`) \S*? 로는 못 넘는다.
        s, n = re.subn(r'(\*\*다음 작업\*\*:[^\n]*?)\d+장\(peri \d+~\)',
                       lambda m: f'{m.group(1)}{nxt[0]}장(peri {nxt[1]}~)', s)
        hits.append(('다음 작업', n))

    if s != orig:
        io.open(PERI_MD, 'w', encoding='utf-8').write(s)
    print(f'  peri.md: 1~{full}장 {done}/{total} 완료 · 잔여 {remain}  '
          + ' · '.join(f'{k}{"OK" if v else " 미매치"}' for k, v in hits))
    for k, v in hits:
        if not v:
            print(f'  ! peri.md 의 "{k}" 패턴을 못 찾았다 — 직접 확인할 것')
    if not any(v for _k, v in hits):
        # 새 책의 첫 배치에서는 진행표에 그 책 행이 아직 없다.
        print(f'  ! {prep.book_name(conn, bcode)}({bcode}) 행이 진행표에 없다 — '
              f'새로 추가할 것:')
        print(f'     | {prep.book_name(conn, bcode)}({bcode}) | {total} | '
              f'**진행 중** — **1~{full}장 {done}개 완료**({today}) |')
    if remain == 0:
        # 책이 끝나면 진행표 문구가 '진행 중' 에서 '완료' 로 바뀌어야 하고
        # 다음 책을 무엇으로 할지는 사람이 정한다. 산문을 정규식으로 고쳐 쓰면
        # 표현이 뭉개지므로 자동화하지 않고 할 일만 명시한다.
        print(f'\n  ** {prep.book_name(conn, bcode)} 완간 ({done}/{total}) — '
              f'peri.md 를 직접 고칠 것 **')
        print(f'     1) 책 진행 행: **진행 중** -> **✅ 완료 ({today})** — KO·EN 100%')
        print(f'     2) "그 외 신약" 행에서 이 책을 빼고 합계를 줄일 것')
        print(f'     3) "다음 작업" 을 다음 책으로 (db_peri_prep.py --book <bcode> --todo)')


def run(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', metavar='DRAFT')
    ap.add_argument('--apply', metavar='DRAFT')
    ap.add_argument('--commit', action='store_true')
    ap.add_argument('--no-push', action='store_true')
    a = ap.parse_args()
    path = a.check or a.apply
    if not path:
        ap.error('--check 또는 --apply 가 필요하다')
    draft = json.loads(io.open(path, encoding='utf-8').read())
    conn = appdb.connect(DB)

    ok, meta = validate(conn, draft)
    if not ok or a.check:
        sys.exit(0 if ok else 1)

    print()
    apply(conn, draft)
    bcode = draft['book']

    print()
    r = run([sys.executable, '-X', 'utf8', 'db_peri_gate.py', '--book', str(bcode)])
    if r.returncode != 0:
        print('게이트 FAIL — 적재는 됐으나 커밋하지 않는다. 위 위반을 고치고 다시 --apply 할 것.')
        sys.exit(1)

    update_peri_md(conn, bcode)

    if not a.commit:
        print('\n(커밋하려면 --commit 을 함께 준다)')
        return
    subj = draft.get('commit_subject')
    if not subj:
        print('! commit_subject 가 없어 커밋을 건너뛴다.'); return
    msg = subj + ('\n\n' + draft['commit_body'] if draft.get('commit_body') else '')
    print()
    if run(['git', 'add', PERI_MD]).returncode:
        sys.exit(1)
    if subprocess.run(['git', 'diff', '--cached', '--quiet']).returncode == 0:
        # peri.md 가 안 바뀌었으면 커밋할 것이 없다. DB 적재는 이미 끝났고
        # 게이트도 통과했으므로 실패가 아니다 — 진행표를 손보고 직접 커밋한다.
        print('커밋 생략 — peri.md 에 변경이 없다(위 안내대로 진행표를 고친 뒤 직접 커밋).')
        return
    p = subprocess.run(['git', 'commit', '-q', '-F', '-'],
                       input=msg.encode('utf-8'))
    if p.returncode:
        print('커밋 실패'); sys.exit(1)
    run(['git', '--no-pager', 'log', '--oneline', '-1'])
    if not a.no_push:
        if run(['git', 'push', '-q', 'origin', 'master']).returncode == 0:
            print('push OK')


if __name__ == '__main__':
    main()
