"""voice_sync.py — 녹음 파일을 폰 ↔ PC 로 주고받는다 (`--selftest`).

★ 2026-10-14 docs/1.txt 87 (사용자 「모바일 폰으로 구절마다 녹음하고 PC와 동기화 · 양방향 ·
  주고받더라도, 삭제하더라도 녹음 진척도를 기억해야 한다」 · 형식 = Opus 32 kbps 모노).

  · **진척 = PC 의 `user_voice_asset` 한 줄**(voice_bible 이 정본) — 파일은 그 줄에 딸린 것.
    폰은 그 표를 사본(MIRROR_TABLES)으로 받아 「이 절은 녹음됨」을 안다 · 폰은 제 녹음을 `phone_voice` 에 적는다.
  · 폰 → PC(`pull`) — 사본을 보내기 **전에** 돈다(그래야 새 진척이 같은 동기화에 폰으로 돌아간다).
      폰 녹음(origin PHONE)에 파일이 있고 PC 에 없거나 폰 것이 더 새것이면 받아 `.ogg` 로 담는다.
      폰이 파일을 이미 지웠으면 **진척만** 적는다(file 없음).
      PC 에서 사람이 진척을 지웠으면(기록 지우기) 폰의 그 녹음도 걷게 한다(받은 적이 있는 것만 — `sent`).
  · PC → 폰(`push`) — 팩 뒤에 돈다. ④ 에서 고른 (목소리 · 역본 · 책)만 · Opus 로 바꿔 보낸다.
      고른 목록에서 빠진 책의 **PC 에서 보낸 사본**은 폰에서 걷는다(폰에서 녹음한 것은 안 건드린다).
  · 열쇠 = 「목소리|역본|verse_id」.
  · 규격 = docs/mobile_sync.md §9 · 폰 쪽 참조 구현 = `mobile_sync.PhoneRef`(voice_* 연산).
"""
import base64
import hashlib
import json
import os
from pathlib import Path

CHUNK = 384 * 1024
SEND_KEY = 'MOBILE_SEND_VOICE'        # JSON ["목소리|역본|책번호", …] — ④ 에서 고른 녹음


def key_of(owner, version, vid):
    return '%s|%s|%d' % (owner, version, int(vid))


def split_key(k):
    o, v, vid = str(k).rsplit('|', 2)
    return o, v, int(vid)


def sha16(b):
    return hashlib.sha1(b).hexdigest()[:16]


def ensure(conn):
    """진척 칸(voice_bible.ensure_cols) — 소리 장치를 못 여는 PC 에서도 동기화는 돈다."""
    try:
        import voice_bible as VB
        VB.ensure_cols(conn)
    except Exception:                                     # noqa: BLE001
        pass


# ── 고른 것(④) ─────────────────────────────────────────────────────────
def _cfg(conn, k, d=''):
    r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (k,)).fetchone()
    return (r[0] if r and r[0] is not None else d)


def get_send(conn):
    try:
        return sorted({str(x) for x in json.loads(_cfg(conn, SEND_KEY, '[]') or '[]')})
    except ValueError:
        return []


def set_send(conn, items):
    v = json.dumps(sorted(set(items)), ensure_ascii=False)
    if conn.execute("SELECT 1 FROM user_config WHERE config_key=?", (SEND_KEY,)).fetchone():
        conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (v, SEND_KEY))
    else:
        conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (SEND_KEY, v))


def shelf(conn):
    """PC 녹음을 (목소리, 역본, 책)으로 묶는다 → [{'id','owner','version','bcode','n','files','bytes'}]."""
    ensure(conn)
    out = []        # ⚠ voice_bible 을 부르지 않는다(numpy·sounddevice 를 끌어와 화면이 느려진다 · 쓰지도 않았다)
    rows = conn.execute(
        "SELECT va.voice_owner, va.bible_version, bi.bcode, COUNT(*),"
        " SUM(CASE WHEN COALESCE(va.has_file,1)=1 THEN 1 ELSE 0 END)"
        " FROM user_voice_asset va JOIN bible_index bi ON bi.verse_id=va.verse_id"
        " GROUP BY 1,2,3 ORDER BY 1,2,3").fetchall()
    for o, v, b, n, nf in rows:
        out.append({'id': '%s|%s|%d' % (o, v, b), 'owner': o, 'version': v, 'bcode': b,
                    'n': n, 'files': nf or 0,
                    'bytes': int((nf or 0) * 30000)})      # Opus 32kbps · 절당 약 7초 어림
    return out


# ── 폰 → PC ───────────────────────────────────────────────────────────
def _pc_row(conn, owner, version, vid):
    return conn.execute(
        "SELECT id, COALESCE(has_file,1), file_sha, created_at, file_path FROM user_voice_asset"
        " WHERE voice_owner=? AND bible_version=? AND verse_id=?", (owner, version, vid)).fetchone()


def _fetch(call, k, size):
    """폰에서 녹음 한 개를 조각으로 받는다 → bytes."""
    buf, part, parts = [], 0, 1
    while part < parts:
        a = call('voice_get', {'key': k, 'part': part}) or {}
        parts = int(a.get('parts') or 1)
        buf.append(base64.b64decode(a.get('b64') or ''))
        part += 1
    return b''.join(buf)


def pull(conn, call, say=None):
    """폰의 녹음 → PC. → {'got','progress','gone','phone'} (가져온 파일 · 진척만 · 폰에 걷게 한 것 · 폰 목록 수)."""
    import voice_bible as VB
    ensure(conn)
    say = say or (lambda m: None)
    rep = {'got': 0, 'progress': 0, 'gone': 0, 'phone': 0}
    try:
        items = call('voice_list').get('voices') or []
    except Exception as e:                                # noqa: BLE001
        if 'UNKNOWN_OP' in str(e):
            return rep                                    # 옛 폰 — 녹음 기능이 없다
        raise
    rep['phone'] = len(items)
    got, drop = [], []
    on_phone = set()
    for it in items:
        try:
            o, v, vid = split_key(it.get('key'))
        except Exception:                                 # noqa: BLE001
            continue
        row = _pc_row(conn, o, v, vid)
        mine = (it.get('origin') or 'PHONE') == 'PHONE'
        if row is None and it.get('sent'):
            drop.append(it['key'])                        # PC 에서 사람이 진척을 지웠다
            continue
        if not mine and row is None:
            drop.append(it['key'])                        # PC 가 보냈던 것인데 PC 에 진척이 없다
            continue
        # ★ PC 가 이미 받은 뒤 일부러 지운 파일(has_file=0 · sent)은 다시 끌어오지 않는다 — 더 새 녹음일 때만
        want_file = mine and it.get('has_file') and (
            row is None or (not row[1] and not it.get('sent')) or
            (it.get('sha') != row[2] and (it.get('made_at') or '') > (row[3] or '')))
        if want_file:
            say('녹음 받는 중 %s' % it['key'])
            data = _fetch(call, it['key'], it.get('size') or 0)
            if sha16(data) != it.get('sha'):
                continue                                  # 깨졌다 — 다음 동기화에 다시
            mp3 = VB.voice_path(o, v, vid, '')
            try:
                r2 = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                                  (vid,)).fetchone()
                if r2:
                    mp3 = VB.VOICES_ROOT / o / ('%s_%s_%03d_%03d_%03d.mp3' % (o, v, r2[0], r2[1], r2[2]))
            except Exception:                             # noqa: BLE001
                pass
            ogg = mp3.with_suffix('.ogg')
            ogg.parent.mkdir(parents=True, exist_ok=True)
            tmp = ogg.with_name(ogg.stem + '.~part.ogg')
            tmp.write_bytes(data)
            os.replace(tmp, ogg)
            for old in (mp3, mp3.with_suffix('.wav')):    # 폰의 새 녹음이 옛 PC 녹음을 갈음한다
                try:
                    old.unlink(missing_ok=True)
                except Exception:                         # noqa: BLE001
                    pass
            VB.save_voice_record('', vid, o, v, str(ogg), 'OPUS', origin='PHONE',
                                 made_at=it.get('made_at') or '', conn=conn)
            rep['got'] += 1
            got.append(it['key'])
        elif row is None and mine:
            VB.save_voice_record('', vid, o, v, '', origin='PHONE', made_at=it.get('made_at') or '',
                                 conn=conn)
            rep['progress'] += 1
            got.append(it['key'])
        elif mine and not it.get('sent'):
            got.append(it['key'])                         # 이미 같은 것이 있다 — 받은 것으로 친다
        if it.get('has_file'):
            on_phone.add((o, v, vid))
    # ★ 값이 바뀐 줄만 고친다 — 고칠 때마다 사본 변경이 적혀 동기화마다 같은 줄이 다시 간다
    for rid, o, v, vid, ph in conn.execute(
            "SELECT id, voice_owner, bible_version, verse_id, COALESCE(phone_has,0) FROM user_voice_asset").fetchall():
        want = 1 if (o, v, vid) in on_phone else 0
        if ph != want:
            conn.execute("UPDATE user_voice_asset SET phone_has=? WHERE id=?", (want, rid))
    conn.commit()
    if got:
        call('voice_got', {'keys': got})
    for k in drop:
        call('voice_del', {'key': k, 'all': True})
        rep['gone'] += 1
    return rep


# ── PC → 폰 ───────────────────────────────────────────────────────────
def push(conn, call, say=None, kbps=32):
    """④ 에서 고른 녹음을 폰에 보낸다(Opus) · 빠진 책의 PC 사본은 폰에서 걷는다 → {'sent','bytes','gone'}."""
    import voice_bible as VB
    ensure(conn)
    say = say or (lambda m: None)
    rep = {'sent': 0, 'bytes': 0, 'gone': 0}
    try:
        items = call('voice_list').get('voices') or []
    except Exception as e:                                # noqa: BLE001
        if 'UNKNOWN_OP' in str(e):
            return rep
        raise
    have = {it['key']: it for it in items if it.get('key')}
    want = set(get_send(conn))
    keep = set()
    for wid in sorted(want):
        try:
            o, v, b = wid.rsplit('|', 2)
            b = int(b)
        except ValueError:
            continue
        rows = conn.execute(
            "SELECT va.verse_id, va.file_path, va.created_at FROM user_voice_asset va"
            " JOIN bible_index bi ON bi.verse_id=va.verse_id"
            " WHERE va.voice_owner=? AND va.bible_version=? AND bi.bcode=? AND COALESCE(va.has_file,1)=1"
            " ORDER BY va.verse_id", (o, v, b)).fetchall()
        for vid, fp, made in rows:
            k = key_of(o, v, vid)
            keep.add(k)
            h = have.get(k)
            if h and h.get('has_file') and (h.get('made_at') or '') >= (made or ''):
                continue
            p = VB.resolve(fp) if fp else None
            if not p or not p.exists():
                continue
            data = VB.to_opus(p, kbps)
            sha = sha16(data)
            if h and h.get('has_file') and h.get('sha') == sha:
                continue
            parts = max(1, -(-len(data) // CHUNK))
            say('녹음 보내는 중 %s' % k)
            for i in range(parts):
                call('voice_put', {'key': k, 'owner': o, 'version': v, 'vid': vid, 'sha': sha,
                                   'made_at': made or '', 'part': i, 'parts': parts,
                                   'b64': base64.b64encode(data[i * CHUNK:(i + 1) * CHUNK]).decode('ascii')})
            conn.execute("UPDATE user_voice_asset SET phone_has=1 WHERE voice_owner=? AND bible_version=?"
                         " AND verse_id=? AND COALESCE(phone_has,0)<>1", (o, v, vid))
            rep['sent'] += 1
            rep['bytes'] += len(data)
    for k, h in have.items():
        if (h.get('origin') or '') == 'PC' and h.get('has_file') and k not in keep:
            call('voice_del', {'key': k})
            rep['gone'] += 1
    conn.commit()
    return rep


# ══════════════════════════════════════════════════════════════════════
def selftest():
    """폰(PhoneRef 의 voice_* 를 흉내 낸 메모리 폰) ↔ 임시 개인 DB 로 왕복을 잰다."""
    import sqlite3
    import shutil
    import numpy as np
    import soundfile as sf
    import voice_bible as VB
    ok = []

    def ck(c, m, got=''):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m + ('' if c else '  got=%r' % (got,)))

    OW = '__vsync_test__'
    root = VB.VOICES_ROOT / OW

    class Phone(object):                                  # mobile_sync.PhoneRef 의 voice_* 와 같은 동작
        def __init__(self):
            self.v = {}

        def rec(self, vid, data, made, origin='PHONE'):
            self.v[key_of(OW, 'KJV', vid)] = {'data': data, 'sha': sha16(data), 'made_at': made,
                                              'origin': origin, 'has_file': 1, 'sent': 0}

        def call(self, op, d=None):
            d = d or {}
            if op == 'voice_list':
                return {'voices': [{'key': k, 'sha': x['sha'], 'size': len(x['data'] or b''),
                                    'made_at': x['made_at'], 'origin': x['origin'],
                                    'has_file': x['has_file'], 'sent': x['sent']} for k, x in self.v.items()]}
            if op == 'voice_get':
                x = self.v[d['key']]
                data, i = x['data'], int(d.get('part') or 0)
                parts = max(1, -(-len(data) // CHUNK))
                return {'parts': parts, 'b64': base64.b64encode(data[i * CHUNK:(i + 1) * CHUNK]).decode()}
            if op == 'voice_got':
                for k in d.get('keys') or []:
                    if k in self.v:
                        self.v[k]['sent'] = 1
                return {}
            if op == 'voice_put':
                x = self.v.setdefault(d['key'], {'data': b'', 'origin': 'PC', 'sent': 1})
                if int(d['part']) == 0:
                    x['buf'] = b''
                x['buf'] = x.get('buf', b'') + base64.b64decode(d['b64'])
                if int(d['part']) + 1 == int(d['parts']):
                    x.update(data=x.pop('buf'), sha=d['sha'], made_at=d['made_at'], has_file=1, origin='PC')
                return {}
            if op == 'voice_del':
                x = self.v.get(d['key'])
                if x and (d.get('all') or x['origin'] == 'PC'):
                    self.v.pop(d['key'])
                return {}
            raise RuntimeError('UNKNOWN_OP')

    conn = sqlite3.connect(':memory:')
    conn.execute("ATTACH ':memory:' AS userdb")
    conn.execute("CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, bcode INT, chapter INT, verse INT)")
    conn.executemany("INSERT INTO bible_index VALUES (?,1,1,?)", [(i, i) for i in range(1, 6)])
    conn.execute("CREATE TABLE user_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
    shutil.rmtree(root, ignore_errors=True)
    try:
        ensure(conn)
        a = (np.sin(np.linspace(0, 800, 48000)) * 0.2).astype('float32')
        import io as _io
        b = _io.BytesIO()
        sf.write(b, a, 48000, format='OGG', subtype='OPUS', compression_level=0.88)
        clip = b.getvalue()
        ph = Phone()
        ph.rec(1, clip, '2026-10-14 09:00:00')
        ph.rec(2, clip + b'', '2026-10-14 09:01:00')
        r = pull(conn, ph.call)
        ck(r['got'] == 2, '폰 녹음 둘을 PC 로 받는다', r)
        ck((root / ('%s_KJV_001_001_001.ogg' % OW)).exists(), 'Opus 파일로 담긴다')
        ck(conn.execute("SELECT COUNT(*) FROM user_voice_asset WHERE origin='PHONE' AND has_file=1").fetchone()[0] == 2,
           '진척 줄 둘 · 출처 PHONE')
        ck(all(x['sent'] for x in ph.v.values()), '폰에 「받았다」를 알린다')
        r = pull(conn, ph.call)
        ck(r['got'] == 0 and r['progress'] == 0, '두 번째는 아무것도 안 받는다(멱등)', r)
        # 폰이 파일을 지웠다(진척은 폰 줄로 남음) → 아직 PC 로 안 간 녹음 3
        ph.rec(3, clip, '2026-10-14 09:02:00')
        ph.v[key_of(OW, 'KJV', 3)].update(has_file=0, data=b'')
        r = pull(conn, ph.call)
        ck(r['progress'] == 1 and conn.execute("SELECT has_file FROM user_voice_asset WHERE verse_id=3").fetchone()[0] == 0,
           '★ 폰이 파일을 지워도 진척은 PC 에 남는다', r)
        # PC 가 파일만 지웠다 → 진척은 남는다
        VB.forget_file('', 1, OW, 'KJV', conn=conn)
        ck(conn.execute("SELECT COUNT(*) FROM user_voice_asset WHERE voice_owner=?", (OW,)).fetchone()[0] == 3,
           '★ PC 에서 파일을 지워도 진척 줄 셋 그대로')
        r = pull(conn, ph.call)
        ck(r['got'] == 0 and not (root / ('%s_KJV_001_001_001.ogg' % OW)).exists(),
           'PC 에서 일부러 지운 파일은 다시 끌어오지 않는다', r)
        # PC → 폰 — 고른 책만 · Opus
        mp3 = root / ('%s_KJV_001_001_004.mp3' % OW)
        VB.save_take(a, mp3, 48000)
        VB.save_voice_record('', 4, OW, 'KJV', str(mp3), 'MP3', conn=conn)
        r = push(conn, ph.call)
        ck(r['sent'] == 0, '고르지 않았으면 안 보낸다', r)
        set_send(conn, ['%s|KJV|1' % OW])
        r = push(conn, ph.call)
        k4 = key_of(OW, 'KJV', 4)
        ck(r['sent'] == 1 and ph.v.get(k4, {}).get('data', b'')[:4] == b'OggS', 'PC 녹음을 Opus 로 바꿔 보낸다', r)
        r = push(conn, ph.call)
        ck(r['sent'] == 0, '폰에 같은 것이 있으면 다시 안 보낸다', r)
        ck(any(x['id'] == '%s|KJV|1' % OW and x['n'] == 4 for x in shelf(conn)), 'PC 보관함에 (목소리·역본·책) 한 줄')
        set_send(conn, [])
        r = push(conn, ph.call)
        ck(r['gone'] == 1 and k4 not in ph.v and key_of(OW, 'KJV', 2) in ph.v,
           '고른 것에서 빼면 PC 사본만 폰에서 걷는다(폰 녹음은 그대로)', r)
        # PC 에서 사람이 진척을 지웠다 → 폰의 그 녹음도 걷는다
        VB.delete_voice_record('', 2, OW, 'KJV') if False else conn.execute(
            "DELETE FROM user_voice_asset WHERE verse_id=2 AND voice_owner=?", (OW,))
        r = pull(conn, ph.call)
        ck(r['gone'] == 1 and key_of(OW, 'KJV', 2) not in ph.v, 'PC 에서 진척을 지우면 폰에서도 걷는다', r)
        # 폰에서 다시 녹음(더 새것) → PC 의 옛 녹음을 갈음한다
        b2 = _io.BytesIO()
        sf.write(b2, a[:24000], 48000, format='OGG', subtype='OPUS', compression_level=0.88)
        ph.rec(1, b2.getvalue(), '2026-10-14 10:00:00')
        r = pull(conn, ph.call)
        ck(r['got'] == 1 and conn.execute("SELECT file_sha FROM user_voice_asset WHERE verse_id=1").fetchone()[0]
           == sha16(b2.getvalue()), '폰에서 다시 녹음하면 PC 것을 갈음한다', r)
        ck(push.__doc__ and pull.__doc__, '문이 둘(받기·보내기)')
    finally:
        shutil.rmtree(root, ignore_errors=True)
    ck(not root.exists(), '시험 자국 0')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
