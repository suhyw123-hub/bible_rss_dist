# -*- coding: utf-8 -*-
"""ai_result_win.py — **AI결과 창**(317차-8 · 사용자 설계).

사용자 지시 —
  「AI 1의 답이 2의 답과 다르다 … 가운데 화면은 통째로 탭 구조로 … 첫 질문만 동일하면 된다」 →
  「2개 탭을 왔다갔다 하면 혼란스럽다 … 채팅보내기 이후에는 답비교 팝업과 유사한 것을 표시해서 모든 AI를
   한눈에 비교하고 각각 프롬프트로 대화 … 오른쪽 대화목록 화면은 삭제/필터링 기능 이외에 필요할 것이 없다 …
   대화목록을 클릭하면 팝업이 표시 … 이어지는 대화인지 통합한 자료인지 구분하는 필터」 →
  「후속질문 : 2칸 · **한 AI만 골라서 통합하고 그것을 기준본으로 해서 다른 AI에서 복사해서 수정한 것을
   최종본으로 저장** · 모든 AI통합 · 각 AI 자체 대화 통합 · 저장되면 구절연결은 자동」.

짜임(단추는 위 §0 · 칸 사이 경계를 끌어 크기를 바꾼다 · 창 자체도 크기 조절):
  위(좌) — [첫 프롬프트][통합프롬프트] | 그 글(첫 프롬프트는 읽기 전용 · 통합프롬프트는 고친다)
  위(우) — [모든AI 대화내용 통합] 통합 담당 … [닫기] / 화면표시 ☑AI별 칸 ☑모든AI 통합 칸 /
           저장할 곳 ▾ (칸 체크 · 붙일 구절/용어 · 제목) / [최종본 저장] 진행 줄
  칸 — **현재원본** | AI 이름(마지막 답 · [대화내용][통합결과][대화 통합] · [전송] 2줄) |
       **모든AI 대화내용 통합** | **최종본**(☑현재원본 ☑AI대화+통합 으로 가져와 고친 뒤 저장)  (317차-11)

★ 저장 문은 화면이 새로 짜지 않는다 — `AIChatView._do_save`(연구자료는 `save_as_ref` 가 구절을 저절로 잇는다).
★ 덮어 놓는 판이 아니라 **따로 뜨는 창**이다 — 덮는 판은 아래 위젯이 비쳐 나오고 크기를 못 바꿨다
  (사용자 「마우스를 움직이면 화면 배경색이 잘 표시되지 않는 문제 · 리사이즈가 안된다」).
"""
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk

import user_ai as UA

try:
    import ui_theme
except Exception:                                         # noqa: BLE001
    ui_theme = None


def _mods():
    import ai_chat_view as V
    return V


class AIResultWin(tk.Toplevel):
    """AI결과 창 — 한 번에 하나(주인 화면이 들고 있다)."""

    def __init__(self, view):
        V = _mods()
        self.V = V
        super().__init__(view)
        self.view = view
        T = V.T
        self.title(T('AI_RES_WIN2', '대화통합화면'))
        self._bg = V._C('bg', '#F4F6F7')
        self.configure(bg=self._bg)
        try:
            with view._conn() as c:
                g = UA.get_setting(c, 'AI_RESULT_GEOM', '') or ''
        except Exception:                                 # noqa: BLE001
            g = ''
        self.geometry(g or '1280x720')
        self.minsize(640, 360)
        self.protocol('WM_DELETE_WINDOW', self.close)
        self._q = queue.Queue()
        self._job = None
        self._t0 = 0
        self._cols = []
        self._final_txt = ''
        self._verse_rows = []
        self._term_rows = []
        self._pick_vid = None
        self._pick_eid = None
        self._build()
        if ui_theme:
            try:
                ui_theme.adopt(self)
            except Exception:                             # noqa: BLE001
                pass
        self.refresh()

    # ── 짜임 ────────────────────────────────────────────────────────
    def _build(self):
        """위 = **좌우 두 칸**(317차-11 · 사용자 「좌: 첫 프롬프트/통합 프롬프트 버튼 + 프롬프트 내용 · 우: 나머지 단추·콤보」).

        좌 — [첫 프롬프트] [통합프롬프트] 단추(고른 쪽이 눌린 모양) + 오른쪽에 그 글
             (첫 프롬프트는 읽기 전용 · 통합프롬프트는 고칠 수 있고 다른 곳을 누르면 저장).
        우 — [모든AI 대화내용 통합] 통합 담당 … [닫기] / 화면표시 체크 / 저장할 곳 ▾ … / [최종본 저장] 진행 줄.
        """
        V, T, bg = self.V, self.V.T, self._bg
        top = tk.PanedWindow(self, orient='horizontal', bg=V._C('border', '#D5DBDB'),
                             sashwidth=4, sashrelief='flat', bd=0)
        top.pack(fill='x', padx=4, pady=(4, 2))
        self._top = top
        L = tk.Frame(top, bg=bg)
        R = tk.Frame(top, bg=bg)
        top.add(L, minsize=320, stretch='always', width=560)
        top.add(R, minsize=380, stretch='always')
        # 좌 — 단추 기둥 + 프롬프트 글
        lb = tk.Frame(L, bg=bg)
        lb.pack(side='left', fill='y', padx=(0, 4))
        self._fq_btn = V._btn(lb, T('AI_FIRST_Q', '첫 프롬프트'), lambda: self._show_prompt('FIRST'))
        self._fq_btn.pack(side='top', fill='x')
        self._integ_tg = V._btn(lb, T('AI_INTEG_PROMPT_BTN', '통합프롬프트'), lambda: self._show_prompt('INTEG'))
        self._integ_tg.pack(side='top', fill='x', pady=(2, 0))
        self._integ_def_btn = V._btn(lb, T('AI_INTEG_DEFAULT', '기본으로'), self._integ_default)
        self._pt = tk.Text(L, height=5, wrap='word', undo=True, bg=V._C('view_bg', '#FFFFFF'), width=20)
        _sb = ttk.Scrollbar(L, orient='vertical', command=self._pt.yview)
        self._pt.configure(yscrollcommand=_sb.set)
        _sb.pack(side='right', fill='y')
        self._pt.pack(side='left', fill='both', expand=True)
        self._pt.bind('<FocusOut>', lambda _e: self._integ_save(), add='+')
        self._fq_txt = self._pt          # 옛 이름(첫 프롬프트 칸)
        self._ip_txt = self._pt          # 옛 이름(통합프롬프트 칸)
        self._pmode = 'FIRST'
        self._first_txt = ''
        # 우 — 줄 넷
        ra = tk.Frame(R, bg=bg)
        ra.pack(fill='x')
        self._integ_btn = V._btn(ra, T('AI_INTEG_ALL2', '모든AI 대화내용 통합'), self.integrate_all)
        self._integ_btn.pack(side='left')
        # ★ 317차-9 — 통합 담당 AI 는 [설정] 팝업이 정한다 · 여기서는 누구인지만 보인다
        self._integ_who = tk.Label(ra, text='', bg=bg, fg=V._C('fg_dim', '#7F8C8D'))
        self._integ_who.pack(side='left', padx=(4, 0))
        V._btn(ra, T('AI_CLOSE', '닫기'), self.close).pack(side='right')
        # ★ 2026-10-21 사용자 「통합팝업화면에서 어떻게 해야 하는지 모르겠다」 — 지금 대화에 맞는 차례를 한 줄로
        # ⚠ 오른쪽 칸 안에 두었더니 그 칸 높이를 먹어 아래 단추 줄([최종본 저장])이 가려졌다(사용자) —
        #   창 전체 폭의 한 줄로 위 칸들 **아래**에 둔다(가로 자리는 넉넉하다)
        self._guide = tk.Label(self, text='', bg=bg, fg=V._C('accent', '#1A5276'), anchor='w', justify='left')
        self._guide.pack(fill='x', padx=6, after=top)
        rb = tk.Frame(R, bg=bg)
        rb.pack(fill='x', pady=(2, 0))
        tk.Label(rb, text=T('AI_RES_VIEW2', '화면표시'), bg=bg).pack(side='left')
        self._v_ai = tk.BooleanVar(value=True)
        self._v_in = tk.BooleanVar(value=True)
        tk.Checkbutton(rb, text=T('AI_RES_V_AI2', 'AI별 칸'), variable=self._v_ai, bg=bg,
                       command=self._apply_view).pack(side='left')
        tk.Checkbutton(rb, text=T('AI_RES_V_IN2', '모든AI 통합 칸'), variable=self._v_in, bg=bg,
                       command=self._apply_view).pack(side='left')
        r2 = tk.Frame(R, bg=bg)
        r2.pack(fill='x', pady=(2, 0))
        self._r2 = r2
        tk.Label(r2, text=T('AI_CMP_SAVE_AS', '저장할 곳'), bg=bg).pack(side='left')
        self._kind_cb = ttk.Combobox(r2, state='readonly', width=16)
        self._kind_cb.pack(side='left', padx=(2, 4))
        self._kind_cb.bind('<<ComboboxSelected>>', lambda _e: self._kind_changed())
        self._extra = tk.Frame(r2, bg=bg)       # 칸 체크 · 구절 · 용어 · 제목 — 저장할 곳에 따라
        self._extra.pack(side='left')
        rd = tk.Frame(R, bg=bg)
        rd.pack(fill='x', pady=(2, 0))
        # ★ 2026-10-16 저장/공유할 때 자동 검증 — 검증이 답을 고쳤으면 저장하지 않고 칸을 다시 그린다(최종본을 다시 보게)
        self._save_btn = V._btn(rd, T('AI_SAVE_FINAL', '최종본 저장'),
                                lambda: self.view.gated(self.save_final, on_changed=self._verified_changed,
                                                        say=self._say))
        self._save_btn.pack(side='left')
        self._msg = tk.Label(rd, text='', bg=bg, fg=V._C('accent', '#1A5276'), anchor='w', justify='left')
        self._msg.pack(side='left', fill='x', expand=True, padx=8)
        self._fq = L
        self._heads = []
        self._body = tk.Frame(self, bg=bg)
        self._body.pack(fill='both', expand=True, padx=4, pady=(2, 4))
        self._pw = None
        self._mark_prompt()

    # ── 다시 그리기 ─────────────────────────────────────────────────
    def refresh(self):
        """지금 채팅으로 칸을 다시 짓는다 — 최종본 글과 칸 너비는 지킨다."""
        V, T, bg = self.V, self.V.T, self._bg
        view = self.view
        if self._pw is not None:
            try:
                self._final_txt = self._final.get('1.0', 'end-1c')
            except Exception:                             # noqa: BLE001
                pass
            self._pw.destroy()
        cid = view._chat_id
        if cid != getattr(self, '_for_chat', None):
            # ★ 다른 채팅이면 최종본·저장할 곳·고른 구절/용어를 **새로** — 앞 채팅의 글이 넘어오면 안 된다
            self._for_chat = cid
            self._final_txt = ''
            self._pick_vid = self._pick_eid = None
            self._kind_cb.set('')
        with view._conn() as c:
            accts = UA.enabled_accounts(c)
            ais = UA.chat_ais(c, cid) if cid else []
            first = UA.first_question(c, cid) if cid else ''
            integ = UA.latest_integ(c, cid) if cid else None
            latest = {UA.acct_key(p_, md): UA.latest_of(c, cid, UA.acct_key(p_, md)) for p_, md in ais}
            n_turn = {UA.acct_key(p_, md): sum(1 for r, _b in UA.thread_of(c, cid, UA.acct_key(p_, md)) if r == 'ai')
                      for p_, md in ais}
            # ★ 2026-10-15 — 칸에 보이는 답이 검증하지 못한 원본인가(그 AI 의 마지막 답 · 마지막 통합본)
            vfail, integ_vfail = set(), False
            for m in (UA.msg_rows(c, cid) if cid else []):
                if m['role'] != 'ai':
                    continue
                if m['mkind'] == 'INTEG':
                    integ_vfail = m.get('verify') == 'FAIL'
                elif m['mkind'] in ('', 'SELF'):
                    k_ = UA.acct_key(m['provider'], m['model'])
                    (vfail.add if m.get('verify') == 'FAIL' else vfail.discard)(k_)
        self._integ_keys = [UA.acct_key(a) for a in accts]
        self._paint_integ_who()
        _n_ai = len(ais)
        try:
            if _n_ai <= 1:
                self._guide.configure(text=T('AI_RES_GUIDE1',
                    'AI 하나와 나눈 대화입니다 — ① AI 칸의 [대화 통합]을 누르면 대화 전체가 한 글이 됩니다 '
                    '② 최종본의 「AI대화+통합」을 체크하면 그 글을 가져옵니다 ③ 저장할 곳을 고르고 [최종본 저장]'))
                self._integ_btn.configure(state='disabled')
            else:
                self._guide.configure(text=T('AI_RES_GUIDE2',
                    'AI %d곳의 대화입니다 — ① [모든AI 대화내용 통합] ② 최종본의 「AI대화+통합」 체크 '
                    '③ 저장할 곳을 고르고 [최종본 저장]') % _n_ai)
                self._integ_btn.configure(state='normal')
        except Exception:                                 # noqa: BLE001
            pass
        # 저장할 곳
        kinds = list(view._saves()) if hasattr(view, '_saves') else list(UA.saves_for(view._scope))
        self._kinds = kinds
        knames = [T(*view.SAVE_NAMES[k]) for k in kinds]
        ck = self._kind_cb.get()
        self._kind_cb.configure(values=knames)
        if knames:
            dk = view._default_save_kind() if hasattr(view, '_default_save_kind') else kinds[0]
            self._kind_cb.current(knames.index(ck) if ck in knames else (kinds.index(dk) if dk in kinds else 0))
        self._kind_extra()
        # 첫 프롬프트
        self._first_txt = first or T('AI_FIRST_Q_NONE', '(아직 보낸 프롬프트가 없습니다)')
        if self._pmode == 'FIRST':
            self._show_prompt('FIRST')
        # 칸
        pw = tk.PanedWindow(self._body, orient='horizontal', bg=V._C('border', '#D5DBDB'),
                            sashwidth=5, sashrelief='flat', bd=0)
        pw.pack(fill='both', expand=True)
        self._pw = pw
        self._cols = []
        self._heads = []
        ol, ot = self._orig()
        self._add_col('ORIG', None, ol, ot, editable=False)
        fails = []
        lf = getattr(view, '_last_fails', None)
        if lf and lf[0] == cid:
            fails = lf[1]
        akeys = [UA.acct_key(p_, md) for p_, md in ais]
        for (p_, md), k in zip(ais, akeys):
            body, mk = latest[k]
            nm = UA.short_name({'provider': p_, 'model': md}) or md or p_ or 'AI'
            sub = ''
            if mk == 'SELF':
                sub = T('AI_SELF_DONE', '대화 통합본')
            elif n_turn.get(k, 0) > 1:
                sub = T('AI_TURN_N', '%d번째 답') % n_turn[k]
            if k in vfail:
                sub = ((sub + ' · ') if sub else '') + '⚠ ' + T('AI_VFAIL', '검증하지 못한 답변 원본입니다')
            self._add_col('AI', k, (nm, sub), body, editable=True, can_send=k in self._integ_keys)
        for p_, md, why in fails:
            if UA.acct_key(p_, md) in akeys:
                continue
            nm = UA.short_name({'provider': p_, 'model': md}) or md or p_
            self._add_col('FAIL', None, (nm, T('AI_GOT_FAIL', '못 받음')),
                          T('AI_GOT_FAIL', '못 받음') + ' — ' + view._why_short(why), editable=False)
        if integ:
            inm = UA.short_name({'provider': integ['provider'], 'model': integ['model']}) or integ['model']
            self._add_col('INTEG', None, (T('AI_INTEG_COL2', '모든AI 대화내용 통합'),
                                          T('AI_INTEG_BY', '담당 %s') % inm
                                          + ('  (' + integ['map'] + ')' if integ['map'] else '')
                                          + ('  ⚠ ' + T('AI_VFAIL', '검증하지 못한 답변 원본입니다')
                                             if integ_vfail else '')),
                          integ['body'], editable=True)
        self._integ_body = integ['body'] if integ else ''
        # ★ 317차-11 — 최종본 = 다른 칸에서 **가져와** 여기서 고친 뒤 저장(사용자 「설명이 반대로 된 것 같다」)
        self._add_col('FINAL', None, (T('AI_FINAL_COL2', '최종본'),
                                      T('AI_FINAL_SUB', '다른 칸에서 가져와 여기서 수정한 뒤 [최종본 저장]')),
                      self._final_txt, editable=True)
        self._final = self._cols[-1]['text']
        self._final.bind('<KeyRelease>', lambda _e: self._paint_soon(), add='+')
        self._apply_view()
        # ★ 317차-12 — 다시 지은 칸에도 테마를 입힌다. `adopt` 는 창을 처음 띄울 때 **한 번만** 돌아
        #   (멱등 표식) 그 뒤 `refresh` 가 새로 지은 칸은 시스템 기본색(흰 입력 칸 · 밝은 체크 바탕)으로 남았다
        #   (사용자 「팝업 각 화면마다 글자의 배경색이 제멋대로」 · 검정 테마 실측).
        if ui_theme:
            try:
                ui_theme.paint(self._pw)
            except Exception:                             # noqa: BLE001
                pass
        self._paint()
        try:
            view._refont()
        except Exception:                                 # noqa: BLE001
            pass
        self._bold_heads()

    def _bold_heads(self):
        """칸 이름을 굵게 — 화면 글꼴 그대로(크기 하드코딩 없음)."""
        import tkinter.font as tkfont
        for w in list(self._heads) + [self._fq_btn, self._integ_tg]:
            try:
                f = tkfont.Font(font=w.cget('font'))
                w.configure(font=(f.actual('family'), f.actual('size'), 'bold'))
            except Exception:                             # noqa: BLE001
                pass

    def _add_col(self, kind, key, label, text, editable=True, can_send=False):
        """칸 하나 — 머리 = **이름(굵게)** + 덧말(흐리게)(317차-11 · 사용자 「AI 의 이름을 명시적으로」).

        `label` 은 `(이름, 덧말)` 또는 글 하나(옛 모양 — 원본 칸).
        """
        V, T, bg = self.V, self.V.T, self._bg
        f = tk.Frame(self._pw, bg=bg)
        self._pw.add(f, minsize=150, stretch='always', width=300)
        if isinstance(label, tuple):
            name, sub = label
        else:
            name, sub = self._split_orig(label)
        h = tk.Frame(f, bg=bg)
        h.pack(fill='x')
        hw = tk.Label(h, text=name, bg=bg, anchor='w', justify='left',
                      fg=V._C('accent', '#1A5276') if kind in ('FINAL', 'INTEG') else V._C('fg_title', '#2C3E50'))
        hw.pack(side='top', fill='x', padx=2)
        self._heads.append(hw)
        lw = tk.Label(h, text=sub or '', bg=bg, anchor='w', justify='left', wraplength=280,
                      fg=V._C('fg_dim', '#7F8C8D'))
        if sub:
            lw.pack(side='top', fill='x', padx=2)
        col = {'kind': kind, 'key': key, 'frame': f, 'thread': False, 'lbl': lw, 'head': hw}
        if kind == 'AI':
            # ★ 317차-11 — [기준본으로] 걷음 · 첫 줄 [대화내용][통합결과][대화 통합] · 둘째 줄 [전송] | 2줄 입력
            #   (사용자 「가운데 화면 "전송"버튼을 프롬프트 입력창의 왼쪽에」)
            fh = tk.Frame(f, bg=bg)
            fh.pack(fill='x', pady=(2, 0))
            col['th_btn'] = V._btn(fh, T('AI_THREAD2', '대화내용'), lambda col=col: self.show_thread(col))
            col['th_btn'].pack(side='left', padx=1)
            col['res_btn'] = V._btn(fh, T('AI_RESULT_VIEW', '통합결과'), lambda col=col: self.show_result(col))
            col['res_btn'].pack(side='left', padx=1)
            col['self_btn'] = V._btn(fh, T('AI_SELF_MERGE', '대화 통합'), lambda k=key: self.self_merge(k))
            col['self_btn'].pack(side='left', padx=(6, 1))
            fr = tk.Frame(f, bg=bg)
            fr.pack(fill='x', pady=(1, 2))
            fi = tk.Text(fr, height=2, wrap='word', undo=True, relief='solid', bd=1, width=10)
            sb = V._btn(fr, T('AI_SEND2', '전송'), lambda k=key, w=fi: self.follow_up(k, w))
            sb.pack(side='left', anchor='n', padx=(1, 2))
            fi.pack(side='left', fill='x', expand=True, padx=(0, 2))
            fi.bind('<Control-Return>', lambda _e, k=key, w=fi: (self.follow_up(k, w), 'break')[1])
            if not can_send:
                fi.configure(state='disabled')
                sb.configure(state='disabled')
            col['follow'] = fi
            col['send_btn'] = sb
        if kind == 'FINAL':
            # ★ 317차-11 — 최종본 = 체크상자(현재원본 / AI대화+통합) · 고르면 그 글을 이 칸으로 가져온다
            ff = tk.Frame(f, bg=bg)
            ff.pack(fill='x', pady=(2, 0))
            self._fin_or = tk.BooleanVar(value=False)
            self._fin_in = tk.BooleanVar(value=False)
            tk.Checkbutton(ff, text=T('AI_FIN_ORIG', '현재원본'), variable=self._fin_or, bg=bg,
                           command=self._fill_final).pack(side='left')
            tk.Checkbutton(ff, text=T('AI_FIN_INTEG', 'AI대화+통합'), variable=self._fin_in, bg=bg,
                           command=self._fill_final).pack(side='left')
        if kind in ('INTEG', 'AI'):
            col['cite'] = tk.Label(f, text='', bg=bg, fg=V._C('warning', '#B9770E'), anchor='w', justify='left',
                                   wraplength=280)
            col['cite'].pack(fill='x', padx=2)
        t = tk.Text(f, wrap='word', undo=True, bg=V._C('view_bg', '#FFFFFF'), width=10, height=5)
        s = ttk.Scrollbar(f, orient='vertical', command=t.yview)
        t.configure(yscrollcommand=s.set)
        s.pack(side='right', fill='y')
        t.pack(fill='both', expand=True, padx=(2, 0))
        t.insert('1.0', text or '')
        t.tag_configure('chg', background=V._C('success_bg', '#D5F5E3'))   # ★ 2026-10-21 녹색(눈부시지 않게)
        if not editable:
            t.configure(state='disabled')
        col['text'] = t
        col['body'] = text or ''
        self._cols.append(col)
        if kind in ('INTEG', 'AI'):
            self._cite_check(col)
        return col

    def _split_orig(self, label):
        """원본 칸 이름 — 「현재원본」을 크게, 어디서 온 글인지는 덧말로."""
        T = self.V.T
        name = T('AI_ORIG_HEAD', '현재원본')
        sub = label or ''
        for k, d in (('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글'), ('AI_ORIG_REF', '원본 — 이 채팅이 담은 연구자료'),
                     ('AI_ORIG_NOTE', '원본 — 묵상노트')):
            w = T(k, d)
            if sub.startswith(w):
                sub = w.split('—', 1)[-1].strip() + sub[len(w):]
                break
        return name, sub

    def _apply_view(self):
        """보기 — AI 대화 칸 · 통합본 칸을 보이거나 감춘다(이어지는 대화 / 통합 자료 거르개)."""
        for col in self._cols:
            hide = ((col['kind'] in ('AI', 'FAIL') and not self._v_ai.get())
                    or (col['kind'] == 'INTEG' and not self._v_in.get()))
            try:
                self._pw.paneconfigure(col['frame'], hide=hide)
            except Exception:                             # noqa: BLE001
                pass

    # ── 원본(저장할 곳에 따라) ──────────────────────────────────────
    def _kind(self):
        try:
            return self._kinds[self._kind_cb.current()]
        except Exception:                                 # noqa: BLE001
            return 'REF'

    def _kind_changed(self):
        self._kind_extra()
        self._kind_changed_orig_only()

    def _orig(self):
        """원본 칸 — **P2 에 보이는 지금 글**(설명문) · 이 채팅이 담은 연구자료 · 노트는 새로 담는다."""
        T, view = self.V.T, self.view
        kind = self._kind()
        lang = view._lang()
        none = T('AI_CMP_ORIG_NONE', '(아직 없음)')
        try:
            with view._conn() as c:
                if kind == 'VDESC':
                    vid = self._vid()
                    if not vid:
                        return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글'),
                                T('AI_PICK_VERSE_FIRST', '(붙일 구절을 선택하면 그 구절의 지금 글이 보입니다)'))
                    cur = UA.desc_join(UA.desc_current(c, vid, lang), lang)
                    return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글') + ' · ' + UA.range_label(c, vid, vid, lang),
                            cur or none)
                if kind == 'TDESC':
                    eid = self._eid()
                    if not eid:
                        return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글'),
                                T('AI_PICK_TERM_FIRST', '(붙일 용어를 선택하면 그 용어의 지금 글이 보입니다)'))
                    return (T('AI_CMP_ORIG2', '원본 — P2 에 보이는 지금 글') + ' · ' + UA.term_name(c, eid, lang),
                            UA.term_desc_current(c, eid, lang) or none)
                if kind == 'REF':
                    rid = UA.ref_of(c, view._chat_id) if view._chat_id else None
                    if rid:
                        import db_user_ref_schema as U
                        return (T('AI_ORIG_REF', '원본 — 이 채팅이 담은 연구/설교노트') + ' (#%s)' % rid,
                                U.fetch_text(c, rid, lang)[1] or none)
                    return (T('AI_ORIG_REF', '원본 — 이 채팅이 담은 연구/설교노트'),
                            T('AI_ORIG_REF_NEW', '(새 연구/설교노트로 담깁니다)'))
                if kind == 'NOTE':
                    return (T('AI_ORIG_NOTE', '원본 — 묵상노트'),
                            T('AI_ORIG_NOTE_NEW', '(새 묵상노트로 담깁니다 — 내가 쓴 노트는 그대로입니다)'))
        except Exception as e:                            # noqa: BLE001
            print('[ai_result orig] %s' % e)
        return (T('AI_CMP_ORIG2', '원본'), none)

    def _kind_extra(self):
        """저장할 곳에 딸린 칸 — 설명문 칸 체크 · 붙일 구절(Free) · 붙일 용어(Free)."""
        V, T, bg = self.V, self.V.T, self._bg
        for w in self._extra.winfo_children():
            w.destroy()
        kind, view = self._kind(), self.view
        self._sec_vars = {}
        if kind == 'VDESC':
            # ★ 칸마다 — 끄면 그 칸은 지금 글 그대로(사용자 「어떤 것은 수정이, 어떤 것은 원본이 마음에 든다면」)
            marks = UA.DESC_MARKS.get(view._lang().upper()) or UA.DESC_MARKS['EN']
            for (k, _tt, _v), m in zip(UA.DESC_SAVE, marks):
                v = tk.BooleanVar(value=True)
                self._sec_vars[k] = v
                tk.Checkbutton(self._extra, text=m, variable=v, bg=bg).pack(side='left')
            if not (view._scope == 'VERSE' and view._start):
                tk.Label(self._extra, text=' ' + T('AI_CMP_WHICH', '붙일 구절'), bg=bg).pack(side='left')
                cb = ttk.Combobox(self._extra, state='readonly', width=12)
                cb.pack(side='left')
                cb.bind('<<ComboboxSelected>>', lambda _e: self._verse_picked())
                V._btn(self._extra, T('AI_PICK_FIND', '찾기'), self._find_verses).pack(side='left', padx=1)
                self._verse_cb = cb
        elif kind in ('REF', 'NOTE'):
            # ★ 317차-10 — 제목 칸(사용자 「연구자료/묵상분석 제목 입력 기능이 없다」)
            tk.Label(self._extra, text=T('AI_SAVE_TITLE', '제목'), bg=bg).pack(side='left')
            self._title_e = ttk.Entry(self._extra, width=28)
            self._title_e.pack(side='left', padx=(2, 0))
            try:
                with view._conn() as c:
                    if kind == 'REF':
                        tv = view.chat_title() or UA.default_ref_title(c, view._chat_id, view._lang())
                    else:
                        tv = T('AI_NOTE_TITLE', 'AI 묵상분석')
                self._title_e.insert(0, tv or '')
            except Exception:                             # noqa: BLE001
                pass
        elif kind == 'TDESC' and not (view._scope == 'TERM' and view._eid):
            tk.Label(self._extra, text=T('AI_CMP_TERM', '붙일 용어'), bg=bg).pack(side='left')
            q = ttk.Entry(self._extra, width=10)
            q.pack(side='left')
            cb = ttk.Combobox(self._extra, state='readonly', width=14)
            cb.pack(side='left', padx=1)
            q.bind('<Return>', lambda _e: self._find_terms(q.get(), cb))
            V._btn(self._extra, T('AI_PICK_FIND', '찾기'), lambda: self._find_terms(q.get(), cb)).pack(side='left')
            cb.bind('<<ComboboxSelected>>', lambda _e: self._term_picked(cb))

    def _title(self):
        try:
            return (self._title_e.get() or '').strip()
        except Exception:                                 # noqa: BLE001
            return ''

    def _vid(self):
        v = self.view
        if v._scope == 'VERSE' and v._start:
            return v._start
        return self._pick_vid

    def _eid(self):
        v = self.view
        if v._scope == 'TERM' and v._eid:
            return v._eid
        return self._pick_eid

    def _find_verses(self):
        txt = (self._final.get('1.0', 'end') if self._final.get('1.0', 'end').strip()
               else ' '.join(c['body'] for c in self._cols if c['kind'] in ('AI', 'INTEG')))
        vids = self.view._desc_verses(txt)
        self._verse_rows = vids
        with self.view._conn() as c:
            names = [UA.range_label(c, v, v, self.view._lang()) for v in vids]
        self._verse_cb.configure(values=names)
        if vids:
            self._verse_cb.current(0)
            self._verse_picked()
        else:
            self._say(self.V.T('AI_NO_VERSE_IN', '글에서 구절을 찾지 못했습니다'))

    def _verse_picked(self):
        i = self._verse_cb.current()
        if 0 <= i < len(self._verse_rows):
            self._pick_vid = self._verse_rows[i]
            self._kind_changed_orig_only()

    def _find_terms(self, q, cb):
        try:
            import asset_pick as AP
            with self.view._conn() as c:
                self._term_rows = list(AP.candidates(c, 'ENTITY', (q or '').strip(), self.view._lang(), 40))
        except Exception:                                 # noqa: BLE001
            self._term_rows = []
        cb.configure(values=[nm for _e, nm in self._term_rows])
        if self._term_rows:
            cb.current(0)
            self._term_picked(cb)

    def _term_picked(self, cb):
        i = cb.current()
        if 0 <= i < len(self._term_rows):
            self._pick_eid = int(self._term_rows[i][0])
            self._kind_changed_orig_only()

    def _kind_changed_orig_only(self):
        col = next((c for c in self._cols if c['kind'] == 'ORIG'), None)
        if col:
            ol, ot = self._orig()
            t = col['text']
            t.configure(state='normal')
            t.delete('1.0', 'end')
            t.insert('1.0', ot)
            t.configure(state='disabled')
            col['body'] = ot
            _nm, _sub = self._split_orig(ol)
            col['lbl'].configure(text=_sub)
            if _sub and not col['lbl'].winfo_manager():
                col['lbl'].pack(side='top', fill='x', padx=2)
        self._paint()

    # ── 기준본 · 색칠 ───────────────────────────────────────────────
    def as_base(self, col):
        """(옛 문 · 단추는 걷었다 317차-11) 그 칸의 글을 최종본으로 옮긴다 — 알림 줄 없음."""
        txt = col['text'].get('1.0', 'end-1c')
        self._final.delete('1.0', 'end')
        self._final.insert('1.0', txt)
        self._final_txt = txt
        self._final_auto = txt
        self._paint()

    def _fill_final(self):
        """최종본 체크 — 선택한 것(현재원본 · AI대화+통합)을 이어 최종본 칸에 넣는다.

        ⚠ **사람이 최종본을 고쳤으면 덮지 않는다** — 그 칸이 지난번 체크로 넣은 글 그대로(또는 비었을)
          때만 바꾼다. 덮을 수 없으면 그렇다고 말한다(고친 글이 조용히 사라지면 안 된다).
        """
        T = self.V.T
        cur = self._final.get('1.0', 'end-1c')
        if cur.strip() and cur != getattr(self, '_final_auto', None):
            self._say(T('AI_FIN_KEEP', '최종본을 이미 고쳤습니다 — 덮지 않았습니다(비우고 다시 선택하면 가져옵니다)'))
            return
        parts = []
        if self._fin_or.get():
            o = next((c for c in self._cols if c['kind'] == 'ORIG'), None)
            b = (o['body'] if o else '').strip()
            if b and not b.startswith('('):
                parts.append(b)
            else:
                self._say(T('AI_FIN_NO_ORIG', '현재원본이 아직 없습니다'))
        if self._fin_in.get():
            ais = [c for c in self._cols if c['kind'] == 'AI' and (c.get('body') or '').strip()]
            if (getattr(self, '_integ_body', '') or '').strip():
                parts.append(self._integ_body.strip())
            elif len(ais) == 1:
                # ★ 2026-10-21 사용자 「최종본으로 가져와서 저장해야 한다고 말하는 것 같다. 가져올 수 없다」 —
                #   AI 가 하나면 통합할 것이 없다 → 그 AI 의 답을 그대로 가져온다
                parts.append(UA.strip_next(ais[0]['body']).strip())
            else:
                self._say(T('AI_FIN_NO_INTEG', '아직 모든AI 대화내용 통합이 없습니다 — 위 [모든AI 대화내용 통합]을 누르세요'))
        txt = (chr(10) * 2).join(parts)
        self._final.delete('1.0', 'end')
        self._final.insert('1.0', txt)
        self._final_txt = txt
        self._final_auto = txt
        self._paint()

    def _paint_soon(self):
        try:
            self.after_cancel(self._pjob)
        except Exception:                                 # noqa: BLE001
            pass
        self._pjob = self.after(400, self._paint)

    def _paint(self):
        """최종본(있으면) 또는 원본과 **다른 낱말**에 색 — 각 AI 칸 · 통합본 칸."""
        import difflib
        import re as _re
        base = self._final.get('1.0', 'end-1c').strip() if self._cols else ''
        if not base:
            o = next((c for c in self._cols if c['kind'] == 'ORIG'), None)
            b = (o['body'] if o else '').strip()
            if b and not b.startswith('('):
                base = b
        ta = [m.group() for m in _re.finditer(r'\S+', base)]
        for col in self._cols:
            if col['kind'] not in ('AI', 'INTEG') or col.get('thread'):
                continue
            t = col['text']
            t.tag_remove('chg', '1.0', 'end')
            if not ta:
                continue
            tb = [m for m in _re.finditer(r'\S+', t.get('1.0', 'end-1c'))]
            sm = difflib.SequenceMatcher(None, ta, [m.group() for m in tb], autojunk=False)
            for op, _i1, _i2, j1, j2 in sm.get_opcodes():
                if op != 'equal' and j2 > j1:
                    t.tag_add('chg', '1.0+%dc' % tb[j1].start(), '1.0+%dc' % tb[j2 - 1].end())

    def _toggle_thread(self, col):
        """(옛 문) 대화내용 ↔ 통합결과."""
        if col['thread']:
            self.show_result(col)
        else:
            self.show_thread(col)

    def _mark_view(self, col):
        """지금 보이는 쪽 단추를 눌린 모양으로."""
        for k, on in (('th_btn', col['thread']), ('res_btn', not col['thread'])):
            try:
                col[k].configure(relief=('sunken' if on else 'raised'))
            except Exception:                             # noqa: BLE001
                pass

    def show_result(self, col):
        """[통합결과] — 그 AI 의 마지막 결과(대화 통합본이 있으면 그것 · 없으면 마지막 답 · 고칠 수 있다)."""
        if col['thread']:
            t = col['text']
            t.configure(state='normal')
            t.delete('1.0', 'end')
            t.insert('1.0', col['body'])
            col['thread'] = False
            self._paint()
        self._mark_view(col)

    def show_thread(self, col):
        """[대화내용] — 그 AI 와 주고받은 말 전부(읽기 전용 · 굴러간다)."""
        T, view = self.V.T, self.view
        t = col['text']
        if not col['thread']:
            col['body'] = t.get('1.0', 'end-1c')
            with view._conn() as c:
                th = UA.thread_of(c, view._chat_id, col['key'])
            t.configure(state='normal')
            t.delete('1.0', 'end')
            for r, b in th:
                t.insert('end', ('▶ ' + T('AI_ME', '나') if r == 'user' else '◀ AI') + chr(10))
                t.insert('end', (b or '').strip() + chr(10) + chr(10))
            t.configure(state='disabled')
            col['thread'] = True
        self._mark_view(col)

    # ── 인용 대조(기계) ─────────────────────────────────────────────
    def _cite_check(self, col):
        """AI 답·통합본의 성경 인용을 **우리 역본 본문과 글자로** 견준다(AI 검증을 믿지 않는다).

        ★ 317차-11 — **모든 언어**(사용자 지시) · 그 언어 약명으로 출처를 찾고 그 언어 기준 역본으로 잰다
          (`db_cite_gate.check_lang` — 한국어는 옛 문 · 그 밖은 `check_any`).
        """
        try:
            import db_cite_gate as CG
            with self.view._conn() as c:
                ls = CG.check_lang(c, col['body'] or '', self.view._lang())
        except Exception:                                 # noqa: BLE001
            ls = []
        bad = [l for l in ls if not str(l).startswith('(')]
        if bad:
            col['cite'].configure(text=self.V.T('AI_CITE_BAD', '⚠ 인용이 우리 역본과 다른 곳 %d — ') % len(bad)
                                  + ' / '.join(str(x)[:60] for x in bad[:3]))
        elif col.get('cite') is not None:
            col['cite'].pack_forget()

    # ── 보내기 · 통합(일꾼 스레드) ──────────────────────────────────
    def _busy(self, on, what=''):
        st = 'disabled' if on else 'normal'
        for w in [self._integ_btn, self._save_btn] + [c.get('send_btn') for c in self._cols] + \
                [c.get('self_btn') for c in self._cols]:
            if w is not None:
                try:
                    w.configure(state=st)
                except Exception:                         # noqa: BLE001
                    pass
        if on:
            self._t0 = time.time()
            self._what = what
            self._say(what)

    def _run(self, fn, what):
        if self._job is not None:
            return
        self._busy(True, what)
        db = self.view.db_path

        def _work():
            import appdb
            try:
                c = appdb.connect(db)
                try:
                    r = fn(c)
                finally:
                    c.close()
            except Exception as e:                        # noqa: BLE001
                r = {'ok': False, 'why': str(e)}
            self._q.put(r)
        self._job = threading.Thread(target=_work, daemon=True)
        self._job.start()
        self._pump()

    def _pump(self):
        try:
            if not self.winfo_exists():
                return
        except Exception:                                 # noqa: BLE001
            return
        try:
            r = self._q.get_nowait()
        except queue.Empty:
            self._say('%s … %d초' % (self._what, int(time.time() - self._t0)))
            self.after(150, self._pump)
            return
        self._job = None
        self._busy(False)
        T = self.V.T
        if r.get('ok') or r.get('results'):
            fails = [x for x in (r.get('results') or []) if not x.get('ok')]
            if fails:
                self.view._last_fails = (self.view._chat_id, [(x.get('provider', ''), x.get('model', ''),
                                                               x.get('why', '')) for x in fails])
            self.refresh()
            self._say(T('AI_RES_DONE', '받았습니다') + ' · %d초' % int(time.time() - self._t0))
        else:
            self._say(T('AI_FAILED', '못 받았습니다: ') + self.view._why_short(r.get('why', '')))
        try:
            self.view._paint_transcript()
            self.view._load_chats()
        except Exception:                                 # noqa: BLE001
            pass

    def follow_up(self, key, w):
        """그 AI 에게만 후속 질문(사용자 「후속질문 : 2칸」)."""
        view = self.view
        view._commit_ime(w) if hasattr(view, '_commit_ime') else None
        txt = w.get('1.0', 'end').strip()
        if not txt or not view._chat_id:
            return
        w.delete('1.0', 'end')
        cid = view._chat_id
        self._run(lambda c: UA.send(c, cid, txt, only=[key]), self.V.T('AI_SENDING', '보냈습니다'))

    def _paint_integ_who(self):
        """「통합 담당: 이름 (설정)」 — 바꾸는 곳은 [설정] 팝업."""
        T = self.V.T
        try:
            with self.view._conn() as c:
                k = UA.integ_account(c)
                a = UA._acct_of(c, k) if k else None
            nm = (UA.short_name(a) or a.get('model')) if a else T('AI_INTEG_NONE', '없음')
            self._integ_who.configure(text='%s: %s (%s)' % (T('AI_INTEG_WHO', '통합 담당'), nm,
                                                            T('AI_INTEG_IN_SET', '[설정]에서 바꿈')))
        except Exception:                                 # noqa: BLE001
            pass

    def integrate_all(self):
        """[모든 AI 통합] — 통합 담당 AI 하나에게(답 이름을 가리고 · 검증 칸과 함께)."""
        with self.view._conn() as c:
            key = UA.integ_account(c)
        cid = self.view._chat_id
        if not key or not cid:
            self._say(self.V.T('AI_INTEG_NEED', '통합 담당 AI 를 선택하세요'))
            return
        self._integ_save()
        self._run(lambda c: UA.integrate(c, cid, key), self.V.T('AI_INTEGRATING', '통합 중'))

    def self_merge(self, key):
        """[대화 통합] — 그 AI 의 대화를 그 AI 가 한 편으로."""
        cid = self.view._chat_id
        if not cid:
            return
        self._run(lambda c: UA.self_merge(c, cid, key), self.V.T('AI_INTEGRATING', '통합 중'))

    # ── 통합프롬프트 ──────────────────────────────────────────────────
    def _toggle_integ(self):
        """(옛 문) 통합프롬프트 ↔ 첫 프롬프트."""
        self._show_prompt('FIRST' if self._integ_open else 'INTEG')

    @property
    def _integ_open(self):
        return getattr(self, '_pmode', 'FIRST') == 'INTEG'

    def _mark_prompt(self):
        for b, m in ((self._fq_btn, 'FIRST'), (self._integ_tg, 'INTEG')):
            try:
                b.configure(relief=('sunken' if self._pmode == m else 'raised'))
            except Exception:                             # noqa: BLE001
                pass
        try:
            if self._pmode == 'INTEG':
                self._integ_def_btn.pack(side='top', fill='x', pady=(2, 0))
            else:
                self._integ_def_btn.pack_forget()
        except Exception:                                 # noqa: BLE001
            pass

    def _show_prompt(self, mode):
        """왼쪽 프롬프트 칸 — 첫 프롬프트(읽기 전용) 또는 통합프롬프트(고칠 수 있다)."""
        if self._pmode == 'INTEG' and mode != 'INTEG':
            self._integ_save()
        t = self._pt
        t.configure(state='normal')
        t.delete('1.0', 'end')
        if mode == 'INTEG':
            with self.view._conn() as c:
                t.insert('1.0', UA.integ_prompt(c, self.view._lang()))
        else:
            t.insert('1.0', self._first_txt or '')
            t.configure(state='disabled')
        self._pmode = mode
        self._mark_prompt()

    def _integ_save(self):
        if not self._integ_open:
            return
        txt = self._ip_txt.get('1.0', 'end').strip()
        with self.view._conn() as c:
            default = UA.INTEG_SEED.get(self.view._lang().upper()) or UA.INTEG_SEED['EN']
            UA.set_setting(c, 'AI_INTEG_PROMPT', '' if txt == default.strip() else txt)

    def _integ_default(self):
        with self.view._conn() as c:
            UA.set_setting(c, 'AI_INTEG_PROMPT', '')
        self._show_prompt('INTEG')

    def _verified_changed(self, r):
        """★ 2026-10-21 검증이 답을 고쳤다 — 최종본에 든 그 답을 고친 글로 바꾼 것과 견주어 한 번에 고르게 한다.
        (그전에는 저장하지 않고 「다시 저장하세요」만 했고, 다시 눌러도 최종본은 **고치기 전 글**이라 고친 것이 안 담겼다)"""
        T = self.V.T
        try:
            self.refresh()
        except Exception:                                 # noqa: BLE001
            pass
        fin = self._final.get('1.0', 'end-1c')
        new = fin
        for _mid, old, nc in r.get('diffs') or []:
            o = (old or '').strip()
            if o and o in new:
                new = new.replace(o, (nc or '').strip())
        if new == fin:
            # 최종본을 사람이 고쳤거나 다른 답에서 왔다 — 최종본은 그대로 담는다(말한다)
            self.save_final()
            self._say(T('AI_VCMP_KEPT', '검증이 AI 답을 고쳤지만 최종본은 직접 정한 글이라 그대로 저장했습니다.'))
            return

        def _new():
            self._final.delete('1.0', 'end')
            self._final.insert('1.0', new)
            self._final_txt = self._final_auto = new
            self.save_final()

        def _old():
            with self.view._conn() as c:
                UA.keep_original(c, r.get('changed') or [])
            self.save_final()
        self.view.verify_compare([(T('AI_FINAL_COL2', '최종본'), fin, new)], on_new=_new, on_old=_old, say=self._say)

    # ── 저장 ───────────────────────────────────────────────────────
    def save_final(self):
        """[최종본 저장] — 저장할 곳에 담는다. 연구자료는 구절이 저절로 이어진다(`save_as_ref`)."""
        T, view = self.V.T, self.view
        txt = self._final.get('1.0', 'end').strip()
        if not txt:
            self._say(T('AI_FINAL_EMPTY2', '최종본이 비었습니다 — 최종본 칸의 체크로 가져오거나 다른 칸에서 복사해 넣으세요'))
            return None
        kind = self._kind()
        lang = view._lang()
        if kind == 'VDESC':
            vid = self._vid()
            if not vid:
                self._say(T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                return None
            sp, _w = UA.split_desc(txt, lang)
            parts = sp or {'DESC': txt}
            keep = {k: v for k, v in parts.items() if self._sec_vars.get(k) is None or self._sec_vars[k].get()}
            if not any((v or '').strip() for v in keep.values()):
                self._say(T('AI_NO_SECTION', '담을 칸이 없습니다 — 칸 체크를 보세요'))
                return None
            view._cmp_vid = vid
            view._cmp_vids = [vid]
            r = view._do_save('VDESC', UA.desc_join(keep, lang))
        elif kind == 'TDESC':
            eid = self._eid()
            if not eid:
                self._say(T('AI_CMP_TERM_NEED', '붙일 용어를 먼저 선택하세요'))
                return None
            view._cmp_eid = eid
            r = view._do_save('TDESC', txt)
        elif kind == 'REF':
            title = self._title()
            with view._conn() as c:
                title = title or view.chat_title() or UA.default_ref_title(c, view._chat_id, lang)
                clash = UA.ref_title_clash(c, title, view._chat_id)
            if clash:
                self._say(T('AI_TITLE_CLASH2', '제목 「%s」은 다른 채팅이 만든 연구/설교노트(#%s)가 이미 씁니다 — 제목을 바꾸고 다시 저장하세요.')
                          % (title, clash))
                return None
            r = view._do_save('REF', txt, title=title)
        elif kind == 'NOTE':
            if not view._start:
                self._say(T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                return None
            r = view._do_save('NOTE', txt, title=self._title() or None)
        elif kind == 'ROLE':
            # ★ 2026-10-21 분야 도움말 — 그전에는 이 갈래가 없어 [최종본 저장]이 아무 말 없이 끝났다
            if not view._start:
                self._say(T('AI_NO_ANCHOR', '구절을 먼저 선택하세요'))
                return None
            r = view._do_save('ROLE', UA.strip_next(txt).strip())
        else:
            self._say(T('AI_SAVE_NOKIND', '이 저장할 곳은 여기서 담지 못합니다 — 가운데 [저장 ▾]를 쓰세요'))
            return None
        try:
            self._say(view._status.cget('text'))
        except Exception:                                 # noqa: BLE001
            pass
        if r:
            try:
                view.mark_popup_saved()              # ★ 2026-10-21 가운데 [저장 ▾]를 감춘다
            except Exception:                             # noqa: BLE001
                pass
        self._kind_changed_orig_only()
        return r

    # ── 기타 ───────────────────────────────────────────────────────
    def _say(self, msg):
        try:
            self._msg.configure(text=msg or '')
        except Exception:                                 # noqa: BLE001
            pass

    def close(self):
        try:
            self._integ_save()
            with self.view._conn() as c:
                UA.set_setting(c, 'AI_RESULT_GEOM', self.geometry())
        except Exception:                                 # noqa: BLE001
            pass
        try:
            self.view._result_win = None
        except Exception:                                 # noqa: BLE001
            pass
        self.destroy()
