# -*- coding: utf-8 -*-
"""찬양 영상 → 용어 → 구절 **간접 연결** (2026-09-16 신설·영구 · 1.txt 18번).

사용자 지시 — 「직접 연결(찬양-구절)에 더해 **간접 연결(찬양-용어-구절)**: 찬양
유튜브가 주요용어(엔티티)와 연결됐는데 그 용어가 P1 구절과 연결되었다면, 그 구절과
찬양 유튜브를 연결한다」 · 「lexical 연결에 대해서는 나도 공감한다. 인물/장소 등
과거의 엔티티 개념은 모두 연결해도 과도하지 않을 것이다. TERM 분류 중에서도
의미있는 것들이 있다는 점이 핵심이다」.

규칙 — **무엇을 타고 가나**
    · 인물·장소·사물·절기·민족·집단·제도·우상(PERSON_LIKE) — 그 엔티티의
      **단락 연결 전부**(`sys_entity_pericope`, 사람이 고른 것) + 대표 절(`is_key`).
    · 용어·교리(TERM_LIKE) — **대표 절**(`ENTI_VERS is_key=1` · `sys_entity_verse
      is_key=1`) + 사람이 이은 뜻 연결(THEMATIC) + 단락 연결. **낱말 연결(LEXICAL
      비대표)은 타지 않는다** — 여호와 5,786절 · 하나님 2,300절 · 다바르 1,608절이
      찬양 한 편에 붙어 절마다 같은 영상이 뜬다(실측 2026-09-16).
    실측 — 승인 찬양 487편이 닿는 엔티티: 인물 28(단락 91 · 최다 9) · 교리 12(단락 149
      · 대표 절 29) · 용어 19(대표 절 118) · 장소 6(단락 3) …. 영상 한 편에 수십 줄이다.
어떻게 남기나
    `sys_link_asset` 에 **직접 연결과 같은 꼴**(`MEDI_VERS` · target=시작 절 ·
    end_id=끝 절 · LIVE)로 넣는다 — 그래야 P2 영상 · P4 · 배지가 코드 한 줄 없이
    함께 본다. 근거는 `source='INDIRECT:<entity_id>'` · `confidence='RULE'` —
    `--undo` 가 그것만 걷는다(직접 연결은 안 건드린다).
⚠ 같은 영상·같은 시작 절에 이미 줄이 있으면(직접 연결 등) **안 넣는다** —
  UNIQUE(link_type, clicked_id, target_id, rel_code) 에도 걸린다.
⚠ 승인(`is_active=1`)된 영상 · 살아 있는(LIVE) 용어 연결만 탄다 — 검토중(PEND)
  연결에서 절을 만들면 사람이 아직 안 본 것이 사용자에게 나간다(§194차 「승인=연결」).
⚠ 멱등 — 두 번 돌리면 0건.

CLI
  python db_song_indirect.py --selftest
  python db_song_indirect.py --check          # 무엇이 생길지(쓰지 않는다)
  python db_song_indirect.py --apply
  python db_song_indirect.py --undo
"""
from __future__ import annotations
import sys

PERSON_LIKE = ('PERSON', 'PLACE', 'OBJECT', 'FEAST', 'GROUP', 'NATION', 'SYSTEM', 'IDOL')
TERM_LIKE = ('TERM', 'DOCTRINE')

#: **대표 절만 탄다**(2026-09-25) — 단락 연결(PERI)·인물의 모든 절(ALL)은
#  「그 인물이 나오는 장면」이지 「그 노래가 말하는 것」이 아니다.
#  ⚠ `False` 로 놓으면 옛 규칙(2026-09-16)이 그대로 돌아온다.
KEY_ONLY = True
#: **대표 절이 이보다 많은 용어는 아예 안 탄다** — 넓은 용어는 아무 말도
#  하지 않는다(실측 삼위일체 31 · 교회 25 · 믿음 24 · 은혜 19).
#  ⚠ 0 이면 상한 없음.
MAX_KEYS = 6
SRC_KIND = 'INDIRECT'
LT_VERS = 'MEDI_VERS'
LT_ENTI = 'MEDI_ENTI'
LT_ENTI_VERS = 'ENTI_VERS'


def _src(eid):
    return '%s:%d' % (SRC_KIND, int(eid))


def _entity_ranges(conn, eid, etype):
    """엔티티 하나가 닿는 (시작, 끝, 까닭) — 규칙(모듈 머리) 그대로."""
    out = {}
    # 단락 연결(사람이 고른 것) — 모든 유형
    for s, e in conn.execute(
            "SELECT p.start_vid, COALESCE(p.end_vid, p.start_vid)"
            "  FROM sys_entity_pericope ep JOIN sys_pericope_asset p ON p.pericope_id=ep.pericope_id"
            " WHERE ep.entity_id=? AND COALESCE(ep.record_status,'LIVE')='LIVE'"
            "   AND COALESCE(p.record_status,'LIVE')='LIVE' AND p.start_vid IS NOT NULL",
            (eid,)):
        out.setdefault(int(s), (int(s), int(e), 'PERI'))
    # 대표 절(ENTI_VERS is_key) — 모든 유형
    for s, e in conn.execute(
            "SELECT target_id, COALESCE(end_id, target_id) FROM sys_link_asset"
            " WHERE link_type=? AND clicked_id=? AND record_status='LIVE' AND COALESCE(is_key,0)=1",
            (LT_ENTI_VERS, eid)):
        out.setdefault(int(s), (int(s), int(e), 'KEY'))
    # 대표 절 · 뜻 연결(sys_entity_verse) — 낱말 연결(LEXICAL 비대표)은 **안 탄다**
    try:
        for (v,) in conn.execute(
                "SELECT verse_id FROM sys_entity_verse WHERE entity_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'"
                "   AND (COALESCE(is_key,0)=1 OR link_kind='THEMATIC')", (eid,)):
            out.setdefault(int(v), (int(v), int(v), 'KEY'))
    except Exception:
        pass
    if etype in PERSON_LIKE:
        # 인물·장소 등은 **모든** 절 연결도 탄다(사용자 「모두 연결해도 과도하지 않다」)
        for s, e in conn.execute(
                "SELECT target_id, COALESCE(end_id, target_id) FROM sys_link_asset"
                " WHERE link_type=? AND clicked_id=? AND record_status='LIVE'",
                (LT_ENTI_VERS, eid)):
            out.setdefault(int(s), (int(s), int(e), 'ALL'))
    return list(out.values())


def candidates(conn, media_type='WORSHIP'):
    """→ [{'media_id','entity_id','etype','start','end','why'}] — 아직 없는 것만."""
    rows = conn.execute(
        "SELECT DISTINCT m.media_id, l.target_id, e.entity_type"
        "  FROM sys_media_asset m"
        "  JOIN sys_link_asset l ON l.clicked_id=m.media_id AND l.link_type=? AND l.record_status='LIVE'"
        "  JOIN sys_entity_master e ON e.entity_id=l.target_id"
        " WHERE m.media_type=? AND COALESCE(m.is_active,0)=1"
        "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
        "   AND COALESCE(e.record_status,'LIVE')='LIVE'",
        (LT_ENTI, media_type)).fetchall()
    cache = {}
    have = {}
    out = []
    for mid, eid, etype in rows:
        etype = (etype or '').upper()
        if etype not in PERSON_LIKE and etype not in TERM_LIKE:
            continue
        if eid not in cache:
            cache[eid] = _entity_ranges(conn, eid, etype)
        if mid not in have:
            have[mid] = {int(r[0]) for r in conn.execute(
                "SELECT target_id FROM sys_link_asset WHERE link_type=? AND clicked_id=?",
                (LT_VERS, mid))}
        rng = cache[eid]
        if KEY_ONLY:
            # ★ 대표 절만 — 단락·전체 절은 「그 노래가 말하는 것」이 아니다
            rng = [r for r in rng if r[2] == 'KEY']
        if MAX_KEYS and len(rng) > MAX_KEYS:
            # ★ 넓은 용어는 통째로 건너뛴다 — 일부만 고르면 **무엇을 골랐는지
            #   설명할 수 없다**(근거를 화면이 적어야 하므로 §0-1).
            continue
        for s, e, why in rng:
            if s in have[mid]:
                continue
            have[mid].add(s)
            out.append({'media_id': int(mid), 'entity_id': int(eid), 'etype': etype,
                        'start': s, 'end': e, 'why': why})
    return out


def apply(conn, cands=None, media_type='WORSHIP'):
    if cands is None:
        cands = candidates(conn, media_type)
    n = 0
    for c in cands:
        cur = conn.execute(
            "INSERT OR IGNORE INTO sys_link_asset(clicked_id, target_id, link_type, end_id,"
            " record_status, source, confidence)"
            " VALUES(?,?,?,?, 'LIVE', ?, 'RULE')",
            (c['media_id'], c['start'], LT_VERS, c['end'], _src(c['entity_id'])))
        n += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
    conn.commit()
    return n


def undo(conn):
    """규칙이 만든 것만 걷는다.

    ⚠⚠ **사람이 뗀 것(`confidence<>'RULE'`)은 안 건드린다** — 지우면 다음
      `apply` 가 **되살려** 사람의 판단을 없던 일로 만든다(실측 27건).
    """
    cur = conn.execute(
        "DELETE FROM sys_link_asset WHERE link_type=? AND source LIKE ?"
        "   AND COALESCE(confidence,'')='RULE'",
        (LT_VERS, SRC_KIND + ':%'))
    conn.commit()
    return cur.rowcount


def summary(cands):
    by_type, by_media = {}, {}
    for c in cands:
        by_type[c['etype']] = by_type.get(c['etype'], 0) + 1
        by_media[c['media_id']] = by_media.get(c['media_id'], 0) + 1
    per = sorted(by_media.values())
    return {'links': len(cands), 'videos': len(by_media), 'by_type': by_type,
            'per_video_max': (per[-1] if per else 0),
            'per_video_median': (per[len(per) // 2] if per else 0)}


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, media_type TEXT, is_active INT, record_status TEXT);
    CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_type TEXT, record_status TEXT);
    CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY AUTOINCREMENT, clicked_id INT, target_id INT,
        link_type TEXT, rel_code TEXT, end_id INT, record_status TEXT, source TEXT, confidence TEXT, is_key INT);
    CREATE UNIQUE INDEX ux ON sys_link_asset(link_type, clicked_id, target_id, rel_code);
    CREATE TABLE sys_entity_pericope(ep_id INTEGER PRIMARY KEY, entity_id INT, pericope_id INT, record_status TEXT);
    CREATE TABLE sys_pericope_asset(pericope_id INTEGER PRIMARY KEY, start_vid INT, end_vid INT, record_status TEXT);
    CREATE TABLE sys_entity_verse(ev_id INTEGER PRIMARY KEY, entity_id INT, verse_id INT, link_kind TEXT, is_key INT, record_status TEXT);
    """)
    return c


def selftest():
    ok = [0, 0]

    def t(name, cond, got=None):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  OK   ' + name)
        else:
            print('  FAIL ' + name + ('' if got is None else ' %r' % (got,)))
    c = _mem()
    # 영상 둘 — 1 승인 · 2 미승인 · 3 승인이지만 설교
    c.executemany("INSERT INTO " + "sys_media_asset VALUES(?,?,?,'LIVE')",   # 감사기(§242차 ⑤) — 시험 표
                  [(1, 'WORSHIP', 1), (2, 'WORSHIP', 0), (3, 'SERMON', 1)])
    # 엔티티 — 10 인물 · 20 용어 · 30 낱말(LEX 가 아니라 TERM 이지만 대표 절 없음)
    c.executemany("INSERT INTO sys_entity_master VALUES(?,?, 'LIVE')",
                  [(10, 'PERSON'), (20, 'TERM'), (30, 'TERM')])
    # 영상↔용어 — 1: 인물10(LIVE)·용어20(LIVE)·용어30(PEND) / 2: 인물10 / 3: 인물10
    c.executemany("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,record_status) VALUES(?,?,'MEDI_ENTI',?)",
                  [(1, 10, 'LIVE'), (1, 20, 'LIVE'), (1, 30, 'PEND'), (2, 10, 'LIVE'), (3, 10, 'LIVE')])
    # 인물10 — 단락 둘(100~105 · 200~203) + 절 연결 하나(300 · 비대표)
    c.executemany("INSERT INTO sys_pericope_asset VALUES(?,?,?,'LIVE')", [(1, 100, 105), (2, 200, 203)])
    c.executemany("INSERT INTO sys_entity_pericope VALUES(NULL,?,?,'LIVE')", [(10, 1), (10, 2)])
    c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,record_status,is_key) VALUES(10,300,'ENTI_VERS','LIVE',0)")
    # 용어20 — 대표 절 둘(400·401) + 낱말 연결 500개(비대표 · 타면 안 된다) + 뜻 연결 1(450)
    c.executemany("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,record_status,is_key) VALUES(20,?,'ENTI_VERS','LIVE',?)",
                  [(400, 1), (401, 1)] + [(1000 + i, 0) for i in range(500)])
    c.execute("INSERT INTO sys_entity_verse VALUES(NULL,20,450,'THEMATIC',0,'LIVE')")
    # 용어30(PEND 연결) — 대표 절 하나(600)
    c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,record_status,is_key) VALUES(30,600,'ENTI_VERS','LIVE',1)")
    # 영상1 에 직접 연결이 이미 있다 — 200 시작(단락 2 와 같은 시작)
    c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,end_id,record_status) VALUES(1,200,'MEDI_VERS',203,'LIVE')")

    cs = candidates(c)
    mids = {x['media_id'] for x in cs}
    t('승인된 찬양만 탄다(미승인 2 · 설교 3 은 없다)', mids == {1}, mids)
    starts = sorted(x['start'] for x in cs)
    # ★★★ **대표 절만 탄다**(2026-09-25) — 단락(100·200)·비대표 절(300)은 안 탄다.
    #   실측이 시킨 규칙이다: 부채꼴 8 로 걸러도 「야곱 → 창29:31(레아 출산)」이
    #   축복 찬양에 붙었고, 그것이 전부 단락 연결에서 왔다.
    t('★ 인물의 단락(100·200)은 **안 탄다**',
      100 not in starts and 200 not in starts, starts)
    t('★ 인물의 비대표 절(300)도 **안 탄다**', 300 not in starts, starts)
    t('용어 — 대표 절 400·401 · 뜻 연결 450', all(v in starts for v in (400, 401, 450)))
    # ⚠ 양방향 — 옛 규칙으로 되돌리면 단락이 다시 탄다(상수가 실제로 듣는가)
    global KEY_ONLY
    KEY_ONLY = False
    _old = sorted(x['start'] for x in candidates(c))
    KEY_ONLY = True
    t('★ `KEY_ONLY=False` 면 옛 규칙이 돌아온다(단락 100 이 탄다)',
      100 in _old, _old[:6])
    # ⚠ 부채꼴 상한 — 대표 절이 많은 용어는 통째로 안 탄다
    global MAX_KEYS
    MAX_KEYS = 1
    _few = [x for x in candidates(c) if x['entity_id'] == 20]
    MAX_KEYS = 6
    t('★ 대표 절이 상한을 넘는 용어(20)는 **통째로** 안 탄다', not _few, _few)
    t('★ 용어의 낱말 연결 500개는 **타지 않는다**', not any(1000 <= s < 1600 for s in starts), len(starts))
    t('검토중(PEND) 용어 연결은 안 탄다(600 없음)', 600 not in starts)
    t('이미 있는 직접 연결(200)은 다시 안 만든다', 200 not in starts)
    sm = summary(cs)
    t('요약 — 영상 1 · 줄 %d' % sm['links'], sm['videos'] == 1 and sm['links'] == len(cs))
    n = apply(c, cs)
    t('apply 가 그 수만큼 넣는다', n == len(cs), (n, len(cs)))
    row = c.execute("SELECT end_id, source, confidence, record_status FROM sys_link_asset"
                    " WHERE link_type='MEDI_VERS' AND clicked_id=1 AND target_id=400").fetchone()
    t('꼴 — 직접 연결과 같은 MEDI_VERS · 끝 절 · INDIRECT:20 · RULE · LIVE',
      row == (400, 'INDIRECT:20', 'RULE', 'LIVE'), row)
    t('멱등 — 다시 돌리면 0', apply(c) == 0)
    # ⚠⚠ **사람이 뗀 것은 `undo` 가 안 건드린다** — 지우면 다음 apply 가
    #   되살려 사람의 판단이 없던 일이 된다(실측 27건이 그 상태였다).
    c.execute("UPDATE sys_link_asset SET record_status='HIDE', confidence='MANUAL'"
              " WHERE link_type='MEDI_VERS' AND clicked_id=1 AND target_id=400")
    d = undo(c)
    t('undo — 규칙이 만든 것만 걷는다(직접 연결 200 은 남는다)',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='MEDI_VERS'"
                " AND COALESCE(source,'') NOT LIKE 'INDIRECT:%'").fetchone()[0] == 1, d)
    t('★ 사람이 뗀 간접 연결은 **안 지운다**',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='MEDI_VERS'"
                " AND confidence='MANUAL'").fetchone()[0] == 1)
    t('★ 그래서 다시 apply 해도 **안 되살아난다**',
      (apply(c) or True) and c.execute(
          "SELECT record_status FROM sys_link_asset WHERE link_type='MEDI_VERS'"
          " AND clicked_id=1 AND target_id=400").fetchone()[0] == 'HIDE')
    print('db_song_indirect selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    try:
        if '--undo' in sys.argv:
            print('걷음 %d' % undo(conn))
        else:
            cs = candidates(conn)
            sm = summary(cs)
            print('간접 연결 후보 — 줄 %(links)d · 영상 %(videos)d · 유형 %(by_type)s · 영상당 최다 %(per_video_max)d · 중앙값 %(per_video_median)d' % sm)
            if '--apply' in sys.argv:
                print('넣음 %d' % apply(conn, cs))
            else:
                print('(--apply 로 넣는다)')
    finally:
        conn.close()
