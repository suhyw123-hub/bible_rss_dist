# -*- coding: utf-8 -*-
"""db_vers_gate.py — 절별자산(VERS_DESC·VERS_QUESTION·VERS_PRAYER) 품질 게이트 (영구 도구).

    python -X utf8 db_vers_gate.py <bcode> <ch_lo> [ch_hi]     # 전 검사
    python -X utf8 db_vers_gate.py <bcode> <ch> --only yoche   # 하나만
    python -X utf8 db_vers_gate.py --selftest                  # 탐지력 확인 (의무)
    python -X utf8 db_vers_gate.py <bcode> <ch> --inventory    # 검토용 목록(합불 없음)

왜 있나 — data.md §드리프트 근본차단:
  산문 정책을 문서에 아무리 써도 드리프트가 재발한다. **생성 시점에 나는 정책 문서가 아니라
  직전 배치에 앵커링하기 때문이다.** 유일한 근본 해결은 규격을 기계가 매 장 강제하는 것이다.

내력 (2026-08-04 통합):
  본래 `temp_code_tier_gate` · `_greek_check` · `_verserep_check` · `_yoche_gate` · `_simcheck`
  다섯 개였는데, **2026-07-30 코드 정리 때 `temp_code_*` 이름이라 통째로 `참고코드/` 로 휩쓸렸다.**
  data.md 가 "매 장 필수"라고 못 박은 도구들이 실행조차 되지 않는 상태로 넉 달 있었다.
  ⇒ 하나의 `db_*` 영구 도구로 합치고 **CLAUDE.md §0-5 KEEP 목록에 등재**한다.

  ★ 이름이 수명을 정한다. 반복 실행할 도구에 `temp_` 를 붙이지 말 것.

포팅하며 고친 것:
  ① `verserep`·`yoche` 가 `sqlite3.connect('bible_master.db')` 를 직접 열고 있었다.
     CLAUDE.md §1 위반 — `appdb.connect()` 로 바꿨다(워크트리에서 빈 DB 를 만드는 사고를 막는다).
  ② greek 어휘집이 신약 세 권(딛·골·몬)에서만 만들어진다. **구약에서는 이 어휘집이 비고,
     비면 위반이 0으로 나온다.** 그것을 PASS 로 보고하면 §18-9 의 실패를 되풀이한다
     (탐지력 없는 검사가 수십 번 PASS 를 찍은 전례). ⇒ 어휘집이 임계 미만이면 `SKIP` 으로
     보고하고 **전체 결과를 PASS 로 만들지 않는다.**
  ③ 다섯 도구가 임계값을 각자 갖고 있었다. 한곳(`TH`)에 모았다.
"""
import sys, re, difflib, statistics as st
import appdb

# ── 임계값 (clean 코퍼스 실측 기반 — 근거는 data.md) ────────────────────────
#
# ★ 2026-08-05 — **유사도는 판정에서 내렸다.** 세 가지가 한꺼번에 드러났다.
#   ① `difflib` 의 autojunk 가 언어마다 다르게 문다. b 가 200자를 넘으면 1% 넘게 나오는
#      글자를 매칭에서 빼는데, 영어는 알파벳 26자라 **글자의 92%가 버려지고** 한국어는
#      음절이 139종이라 47%만 버려진다. 그래서 같은 번역문인데 KO 0.587 · EN 0.322 로
#      갈렸다(autojunk 를 끄면 0.644 · 0.658 로 같아진다). 넉 달간 영어는 사실상
#      검사되지 않고 있었다.
#   ② **지표가 삭제를 보상한다.** 주제를 지워도 점수가 좋아지므로 「주제를 생략하지 말라」는
#      규칙을 사람이 손으로 붙여야 했다. 손 규칙으로 피해를 막아야 하는 지표는 틀린 것을 잰다.
#   ③ **EXPERT 대비 비율은 기준선이 책마다 움직인다.** 서신서는 EXPERT 문장이 이미 31자라
#      문장길이비가 1.0 인데 결함이 아니다. 창세기는 EXPERT 가 72자라 0.58 이 나온다.
#   ⇒ **원하는 것을 절대값으로 직접 잰다**: LAY 에 절 인용이 있는가(0) · 새로 쓴 글인가
#      (신출 어휘비) · 주제를 지키는가(고유명사 잔존). 유사도는 경고로만 남긴다.
TH = dict(
    SIM_MAX=0.55,          # 경고선. autojunk=False 기준(재작성분 0.45 / 미작업 0.64)
    LEN_RATIO_MAX=0.75,    # 절별 LAY/EXPERT 길이비 상한
    LEN_RATIO_AVG=0.65,    # 장평균 길이비 상한 (LAY 실질 압축 강제)
    APPARATUS_COVER=0.80,  # EXPERT 학술장치 보유 절 비율 하한
    GREEK_MAX_VERSE=2,     # 절당 원어 괄호 상한 (하한만 있고 천장이 없어 2.2개까지 팽창했다)
    GREEK_AVG_MAX=1.2,     # 장평균 원어 괄호 상한
    SENT_PER_PARA_MIN=2.0, # 장평균 문단당 문장 수 하한 (2026-08-09 2.5→2.0)
                           #   분량 기준을 폐기하면서 내렸다(lay.md §2). 짧은 절은
                           #   「2문단 4문장」이 정상이다 — 2.5 는 없는 말을 지어내 채우게 했다.
                           #   `db_verse_text_loader.PARA_DENS_MIN` 과 **같은 값이어야 한다.**
    VERSEREP=0.70,         # 한 문장이 본문과 이만큼 같으면 재진술
    YOCHE_ZERO=True,       # 요체는 무관용. 비율 기준(15%)은 장당 1~2건을 0% 로 통과시켰다
    LEXICON_MIN=40,        # greek 어휘집 최소 크기 — 미만이면 검사 불가로 본다
    LAY_CITE_MAX=0,        # ★ LAY 에 남은 절 인용 표기 — 절대 기준, 0
    NEWWORD_MIN=0.15,      # ★ 신출 어휘비 하한 — 판정. **표본 검증으로 0.25 에서 내렸다**
    NEWWORD_REVIEW=0.30,   #   경고선. 0.15~0.30 은 사람이 본다 (아래 7-1 주석)
    # ⚠ 신출 어휘비에 **천장**을 두어 오배치를 잡으려 했으나 폐기했다 (2026-08-06).
    #   근거: 전권 9,848쌍 실측에서 0.80 초과가 119건. EXPERT 가 짧으면 어휘가 적어
    #   비율이 저절로 올라간다 — 잘 쓴 글을 오배치로 몰게 된다.
    #   ⇒ 오배치는 비율이 아니라 **초안 vid 를 재료 파일과 대조**해서 잡는다
    #     (`db_vers_lay_prep.check_draft`). 자료가 스스로 정답을 갖고 있는데
    #     통계로 추정할 이유가 없다.
    KEEP_MIN=0.20,         # 내용 보존 — **경고선**. 판정 아님(아래 주석)
)

# ── LAY 절대 기준 3종 (2026-08-05 신설) ──────────────────────────────────────
# 유사도 하나를 대신한다. **셋이 서로 반대 방향으로 당겨서 어느 쪽으로도 조작되지 않는다** —
# 베끼면 신출 어휘비가 떨어지고, 지우면 내용 보존이 떨어진다. 유사도는 둘을 구별하지 못했다.
LAY_CITE = re.compile(r'\([^)]{0,60}?\d{1,3}\s?:\s?\d{1,3}[^)]{0,60}?\)'
                      r'|(?<![(\d])[가-힣]{1,4}\s?\d{1,3}\s?:\s?\d{1,3}')
_QUOTE_RX = re.compile(r'["“][^"”]{2,400}["”]|[\'‘][^\'’]{2,200}[\'’]')
_WORD = re.compile(r'[가-힣]{2,}')
# ⚠ **일반 낱말로 내용 보존을 재면 안 된다 (2026-08-05 실측으로 확인).**
#   「세 글자 이상 한글 낱말이 LAY 에 남았는가」로 재 보니 전권 중앙 0.23 이 나왔고,
#   **가장 잘 쓰인 요한복음이 0.06 으로 꼴찌**였다. 당연하다 — 새 낱말로 다시 쓰면
#   EXPERT 의 낱말은 사라진다. 그것을 벌주면 표면 겹침을 다시 재는 셈이고,
#   유사도가 저지른 잘못을 이름만 바꿔 되풀이하는 것이다.
#   ⇒ **기계로 확인할 수 있는 것은 고유명사와 숫자뿐이다.** 이름과 수는 글을 다시 써도
#     남아야 한다(느부갓네살은 여전히 느부갓네살이다). 주제 보존 자체는 사람이 본다.
_NUM = re.compile(r'\d+')
_PROPER = None


def _proper_nouns():
    """고유명사 사전 — sys_text_asset 의 ENTITY_NAME(KO) 과 책 이름에서 만든다."""
    global _PROPER
    if _PROPER is None:
        s = set()
        for (t,) in conn().execute(
                "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
                "AND lang_code='KO' AND COALESCE(record_status,'LIVE')='LIVE'"):
            for w in re.findall(r'[가-힣]{2,}', t or ''):
                s.add(w)
        for (t,) in conn().execute("SELECT full_name FROM book_names WHERE lang_code='KO'"):
            s.add((t or '').strip())
        _PROPER = {w for w in s if len(w) >= 2}
    return _PROPER


def lay_cites(txt):
    """LAY 에 남은 절 인용 표기 수. 성경 인용부호 안은 세지 않는다(그 안은 불변)."""
    m = _QUOTE_RX.sub(lambda x: '\x00' * (x.end() - x.start()), txt or '')
    return len(LAY_CITE.findall(m))


def new_word_ratio(expert, lay):
    """LAY 낱말 가운데 EXPERT 에 없는 것의 비율. 조사·어미가 붙으므로 앞 두 글자로 본다."""
    se = set(w[:2] for w in _WORD.findall(expert or ''))
    sl = set(w[:2] for w in _WORD.findall(lay or ''))
    return len(sl - se) / len(sl) if sl else 0.0


_WORD_EN = re.compile(r'[A-Za-z]{3,}')


def new_word_ratio_en(expert, lay):
    """영어판 신출 어휘비. 어형 변화를 대충 흡수하려고 앞 다섯 글자로 본다."""
    se = set(w.lower()[:5] for w in _WORD_EN.findall(expert or ''))
    sl = set(w.lower()[:5] for w in _WORD_EN.findall(lay or ''))
    return len(sl - se) / len(sl) if sl else 0.0


def keep_ratio(expert, lay):
    """EXPERT 의 고유명사·숫자 가운데 LAY 에 살아 있는 비율 — 주제를 지웠는지 본다."""
    e, l = expert or '', lay or ''
    ke = {w for w in _proper_nouns() if w in e} | set(_NUM.findall(e))
    if not ke:
        return 1.0
    return sum(1 for k in ke if k in l) / len(ke)

# ★ 「10행/절 고정」 폐기 (2026-08-09 사용자 결정, lay.md §5).
#   묵상질문·묵상기도는 **선택**이다 — 이름만 열거하는 절에 질문을 달면 낱말을 세어
#   억지 물음을 만들게 된다(민 1~4장에서 실제로 그랬다). 기도문도 마찬가지다.
#   ⇒ 개수를 세지 않고 **짝이 맞는지**를 본다. 진짜 규율은 이것이다:
#     ① VERS_DESC 는 KO·EN 둘 다 있어야 한다 (한 언어만 있으면 반쪽이다)
#     ② 어떤 자산을 넣었으면 두 언어에 다 넣는다 (KO 에만 있는 질문은 EN 사용자에게 구멍)
#   기도문은 예외 — `text_variant=NULL` 단일 행이라 언어별로 하나씩이면 맞다.
REQUIRED = ('VERS_DESC',)          # 모든 절에 있어야 하는 자산
OPTIONAL = ('VERS_QUESTION', 'VERS_PRAYER')   # 절 성격에 따라 없어도 된다

# 문단 나눔을 요구하는 최소 문장 수 (2026-08-05 신설, 같은 날 4→5 로 정정).
# **5 인 이유는 밀도 하한에서 나온다.** 나누면 3+2 라 문단당 2.5문장이 되어
# `SENT_PER_PARA_MIN` 과 정확히 맞는다. 4 로 두면 2+2 = 2.0 이라, 나누는 순간
# 스스로 다른 위반을 만든다 — 첫 시행에서 실제로 문단당 2.3문장이 나왔다.
# `db_vers_norm.py` 가 이 값을 import 한다. **둘을 따로 두지 말 것** — 검사기가 잡는데
# 고치는 도구가 손대지 않으면 영원히 남는 위반이 된다.
PARA_MIN_SENT = 5

CIRC = set('①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮')
PNUM = re.compile(r'\([1-9]\)')
BANNED = ['칼뱅', '칼빈', '칼뱅주의', '개혁주의', '개혁파', '알미니안', '장로교',
          'Calvin', 'Reformed', 'Calvinist', '루터파']          # §28-11 교단 중립
THEO = ('신학적으로 이', 'Theologically this', 'Theologically,')  # 재인용 요약 시작
APPLY_BLOCK = re.compile(r'적용하(면|여 보|자|라|시|는 것)|우리 삶에 적용|삶에 적용|적용해')
SENT_SPLIT = re.compile(r'(?<=[.?!])\s+')

# ⚠ SENT_SPLIT 만으로는 `cf. Ps 148:4` 같은 약어 뒤에서 문장을 끊는다 (2026-08-05 발견).
#   세기만 할 때는 오차지만, 이 경계로 **문단을 나누면 문장 한가운데가 갈린다**
#   (`db_vers_norm` 첫 시행에서 실제로 창 1:6 이 `…cf.` / `Ps 148:4…` 로 쪼개졌다).
#   그래서 약어 뒤는 경계로 치지 않는다. 세는 쪽과 나누는 쪽이 **같은 함수**를 쓴다.
# ★ 2026-08-09 — 약어 목록을 **두 갈래로 나눴다.**
#   예전에는 한 목록이라 **성경 책 약어가 사람·지파 이름과 겹쳐** 문장을 못 나눴다.
#   「Asher camps beside Dan. This tribe…」에서 `Dan.` 을 다니엘서로 보아 두 문장을
#   하나로 붙였고, 그 바람에 문단밀도가 실제보다 낮게 나와 멀쩡한 글이 게이트에 걸렸다.
#   겹치는 이름 11개 — Dan·Gen·Amos·Joel·Jonah·Mal·Ezra·Neh·Song·Ps·Rev.
#   ⇒ **책 약어는 뒤에 장·절 숫자가 올 때만 약어로 친다.** 대문자 한 글자(이니셜)도 같다.
ABBR_ALWAYS = re.compile(r'\b(?:cf|cp|e\.g|i\.e|etc|viz|vv|chs|vol|pp)\.$', re.I)
ABBR_REF = re.compile(
    r'(?:\b(?:v|ch|no|p|Mt|Mk|Lk|Jn|Rom|'
    r'Gen|Exod|Ex|Lev|Num|Deut|Josh|Judg|Sam|Kgs|Chr|Ezra|Neh|Esth|Ps|Pss|Prov|'
    r'Eccl|Song|Isa|Jer|Lam|Ezek|Dan|Hos|Joel|Amos|Obad|Jonah|Mic|Nah|Hab|Zeph|'
    r'Hag|Zech|Mal|Acts|Cor|Gal|Eph|Phil|Col|Thess|Tim|Tit|Phlm|Heb|Jas|Pet|Rev)'
    r'|\b[A-Z])\.$')
ABBR_END = ABBR_REF                    # 하위 호환 — 다른 모듈이 참조할 수 있다
_NEXT_NUM = re.compile(r'^\s*\d')


def sentences(text):
    """문장으로 자른다. 약어 뒤는 경계로 치지 않는다. **세기와 나누기의 단일 소스.**"""
    parts = SENT_SPLIT.split(text or '')
    out = []
    for p in parts:
        prev = out[-1].rstrip() if out else ''
        merge = bool(out) and (
            ABBR_ALWAYS.search(prev)                             # cf. · etc. — 늘 약어
            or (ABBR_REF.search(prev) and _NEXT_NUM.match(p)))   # Dan. 7:13 — 숫자가 와야 약어
        if merge:
            out[-1] = out[-1] + ' ' + p
        else:
            out.append(p)
    return [s.strip() for s in out if s.strip()]
GREEK_PAREN = re.compile(r'[가-힣]\(([가-힣]{2,}(?:\s[가-힣]+)?)\)')
PAREN = re.compile(r'\(([^()]{1,120})\)')
QUOTED = re.compile(r"'([^']{1,220})'")
HANGUL = re.compile(r'[가-힣]+')

BOOKS = ('창|출|레|민|신|수|삿|룻|삼상|삼하|왕상|왕하|대상|대하|스|느|에|욥|시|잠|전|아|사|렘|애|겔|단|'
         '호|욜|암|옵|욘|미|나|합|습|학|슥|말|마|막|눅|요|행|롬|고전|고후|갈|엡|빌|골|살전|살후|'
         '딤전|딤후|딛|몬|히|약|벧전|벧후|요일|요이|요삼|유|계')
CROSSREF = re.compile(r'(?:' + BOOKS + r')\s?\d+[:：]\d+(?:-\d+)?')

# ★ 학술장치 검사 보강 (2026-08-07) — 검출기가 **신약 표기만 알고** 만들어져 있었다.
#   창세기 97건이 「학술장치없음」으로 떴는데 실측하니 **86건이 오탐**이었다.
#   원인은 구약 EXPERT 가 신약과 다른 표기를 쓰기 때문이다(전권 실측):
#     신약 7,958절 — 표준꼴 `하늘(샤마임)` 63% · 원문 문자 병기 0%(1건)
#     창세기 1,533절 — 따옴표꼴 `'하늘'(샤마임, שָׁמַיִם)` 88% · 원문 병기 11%
#   `GREEK_PAREN` 은 ① 괄호 앞이 한글 ② 괄호 안이 한글만 을 동시에 요구하는데
#   구약 표기는 따옴표와 히브리 문자 때문에 **둘 다** 어긴다.
#   ⚠ 이것은 표준 위반이 아니다. §28-11 이 금지한 것은 **역순**(`카타크리마(정죄)`)과
#     **절 전체 음독**이고, 구약 표기는 둘 다 어기지 않는다 — 원문 문자를 더했을 뿐이다.
#     더 풍부한 표기가 검사에 걸리고 있었다.
#   ⚠ `GREEK_PAREN` 자체는 건드리지 않는다 — 원어 과밀(`greek_count`) 계산이 흔들린다.
SCRIPT = re.compile(r'[֐-׿Ͱ-Ͽ]')      # 히브리 · 헬라 원문 문자
QUOTE_PAREN = re.compile(r'[\'’"”]\s*\([^)]{1,60}\)')  # '하늘'(샤마임, …)
# 같은 책·같은 장 안 참조 — 책약명을 안 붙이는 것이 이 자산의 관행이다(`3:15` · `16절`).
SAMEBOOK_REF = re.compile(r'(?<!\d)\d{1,3}[:：]\d{1,3}(?!\d)|(?<!\d)\d{1,3}\s?절')
CONCEPTS = ('예표', '모형', '예표론', '구속사', '칭의', '전가', '대속', '화목', '성취', '언약',
            '종말', '재림', '성육신', '그리스도론', '대제사장', '반차', '중보', '속죄', '견인',
            '성화', '의롭다', '원어', '헬라어', '히브리어', '수사', '논증', '대조', '평행',
            '문맥', '신학적', '구약', '신약', '인용', '상징', '묵시', '서사', '수신자',
            '원의미', '본문 비평', '전승', '원문')
_PART = ('이니라', '으로써', '하시고', '에게서', '으로', '에게', '에서', '까지', '부터', '이라',
         '이요', '하여', '하고', '하니', '의', '을', '를', '은', '는', '이', '가', '과', '와',
         '도', '로', '만', '에', '라', '며', '니', '고')

# ★★★ **스레드마다 제 연결**(2026-09-29 294차 · 1.txt 1번 7)).
#   옛 판은 모듈 전역 `_CONN` 하나였다. 검수 탭이 [전송하기]를 **일꾼
#   스레드**로 돌리므로(§279차 ⑭) 게이트가 그 스레드에서 이 연결을 처음
#   열고, 다음에 화면 스레드가 같은 객체를 쓰면 SQLite 가
#   「objects created in a thread can only be used in that same thread」로
#   터진다. 그 오류가 게이트 줄에 「게이트를 못 돌렸습니다」로만 남아
#   무엇이 없는지 알 수 없었다.
import threading as _thr
_TLS = _thr.local()


def conn():
    c = getattr(_TLS, 'conn', None)
    if c is None:
        c = _TLS.conn = appdb.connect()
    return c


# ── 어휘 사전 ────────────────────────────────────────────────────────────────
_KRV = None
def krv_vocab():
    """KRV 본문에 실제로 나오는 한국어 낱말.

    ⚠ `[가-힣]\\([가-힣]+\\)` 은 '한글(한글)' 을 전부 원어로 센다. 그래서 `(무덤)`·`(풍랑)`
      같은 **평범한 한국어 괄호주석**이 원어로 집계돼 멀쩡한 절이 '원어과밀' 로 걸렸다.
      판별 근거: **음역(엑세스테산·아뷔소스)은 성경 본문에 결코 나오지 않고,
      한국어 주석어(무덤·풍랑)는 나온다.** KRV 를 한국어 사전 대용으로 쓴다.
      ※ LAY 코퍼스를 사전으로 쓰지 말 것 — 정리 안 된 책의 음역이 섞여 사전을 오염시킨다.
    """
    global _KRV
    if _KRV is None:
        v = set(CONCEPTS)
        for cw in CONCEPTS:
            v.update(cw.split())
        v.update(('완전수', '수미상관', '평행법', '사본', '이문', '어간', '음역', '신적',
                  '수동태', '능동태', '완료형', '미래형', '현재형', '부정과거', '명령형',
                  '관용구', '아람'))
        for (t,) in conn().execute("SELECT verse_text FROM bible_content WHERE version_code='KRV'"):
            for w in re.findall(r'[가-힣]+', t or ''):
                v.add(w)
                for p in _PART:
                    if len(w) > len(p) + 1 and w.endswith(p):
                        v.add(w[:-len(p)])
        _KRV = v
    return _KRV


_ENG = None
def eng_vocab():
    """영어 성경 어휘. 음역은 영어 성경에 나오지 않으므로 진짜 음역만 남기는 데 쓴다.

    ⚠ 그리스어 어미 규칙만으로 판정하면 **평범한 영어 낱말이 헬라어로 집계된다**
      (cares·riches·pleasures 는 -es, confession 은 -on 으로 매칭).
    """
    global _ENG
    if _ENG is None:
        v = set()
        for (t,) in conn().execute("SELECT verse_text FROM bible_content "
                                   "WHERE version_code IN ('KJV','BSB','WEB')"):
            for w in re.findall(r"[A-Za-z]+", t or ''):
                v.add(w.lower())
        v.update(('cares', 'riches', 'pleasures', 'confession', 'public', 'crisis', 'thesis',
                  'analysis', 'emphasis', 'basis', 'series', 'process', 'access', 'status',
                  'focus', 'genesis', 'diagnosis', 'narrative', 'motif', 'chiasm', 'irony'))
        _ENG = v
    return _ENG


def is_translit(s):
    """괄호 안 문자열이 원어 음역인가(= 한국어 낱말이 하나도 없는가)."""
    v = krv_vocab()
    def kor(tok):
        return tok in v or any(len(tok) > len(p) + 1 and tok.endswith(p) and tok[:-len(p)] in v
                               for p in _PART)
    toks = (s or '').split()
    return bool(toks) and not any(kor(t) for t in toks)


def greek_count(txt):
    return sum(1 for m in GREEK_PAREN.findall(txt or '') if is_translit(m))


def has_apparatus(txt):
    """EXPERT 에 학술장치(원어·상호참조·신학 용어)가 있는가.

    표기를 한 가지로 강제하지 않는다 — 신약꼴과 구약꼴을 모두 인정한다(위 주석).
    """
    if not txt:
        return False
    return bool(GREEK_PAREN.search(txt)         # 하늘(샤마임)       — 신약 표기
                or SCRIPT.search(txt)           # שָׁמַיִם · λόγος      — 구약 원문 병기
                or QUOTE_PAREN.search(txt)      # '하늘'(샤마임, …)   — 구약 음역 표기
                or CROSSREF.search(txt)         # 창 2:16            — 다른 책 참조
                or SAMEBOOK_REF.search(txt)     # 3:15 · 16절        — 같은 책·장 참조
                or any(w in txt for w in CONCEPTS))


def _verses(bcode, lo, hi):
    return conn().execute(
        "SELECT verse_id, chapter, verse FROM bible_index "
        "WHERE bcode=? AND chapter BETWEEN ? AND ? ORDER BY chapter, verse",
        (bcode, lo, hi)).fetchall()


# ══════════════════════════════════════════════════════════════════
#  초안 겹치기 — **적재하기 전에** 재려고 (2026-09-23 277차)
# ══════════════════════════════════════════════════════════════════
#
#  ★★★ 왜 있나 — AI 가 쓴 글을 **배포 DB 에 넣기 전에** 이 게이트로 걸러야
#    하는데, 게이트 여섯이 전부 `sys_text_asset` 을 읽고 있었다. 넣고 재면
#    미검수 글이 사용자 화면에 뜨고, 상태값을 새로 만들면 읽는 자리 47곳을
#    전수로 봐야 한다(실측). ⇒ **읽는 자리에 초안을 끼운다.**
#
#  ⚠ 읽는 자리는 **셋**이다 — `_assets`(넷이 함께 쓴다) · `check_greek` ·
#    `check_verserep`. 네 번째가 생기면 여기 `_draft_of` 를 함께 쓴다.
#  ⚠ **DB 를 이긴다** — 묻는 것은 「지금 쓴 글이 규격에 맞나」다.
#  ⚠ **끼운 채로 두지 않는다** — `clear_draft()` 또는 `with draft(...)`.

_DRAFT = {}          # {(vid, text_type, lang, variant): contents}


def set_draft(rows):
    """초안을 끼운다. `rows` = `[(vid, text_type, lang, variant, 글), ...]`
    또는 `{(vid, text_type, lang, variant): 글}`.

    `variant` 가 없는 자산(`VERS_PRAYER`)은 `None` 을 준다.
    """
    _DRAFT.clear()
    it = rows.items() if isinstance(rows, dict) else (
        ((r[0], r[1], r[2], r[3]), r[4]) for r in rows)
    for k, v in it:
        vid, tt, lang, var = k
        _DRAFT[(int(vid), str(tt), str(lang).upper(),
                (str(var).upper() if var else None))] = v or ''
    return len(_DRAFT)


def clear_draft():
    _DRAFT.clear()


class draft(object):
    """`with draft(rows): ...` — 나갈 때 반드시 걷는다."""

    def __init__(self, rows):
        self._rows = rows

    def __enter__(self):
        set_draft(self._rows)
        return self

    def __exit__(self, *a):
        clear_draft()
        return False


def _draft_of(vid):
    """그 절에 끼운 초안 — `[(text_type, lang, variant, 글)]`."""
    return [(tt, lg, var, txt)
            for (v, tt, lg, var), txt in _DRAFT.items() if v == int(vid)]


def _merge(db_rows, dr_rows):
    """DB 줄 위에 초안을 덮는다 — 열쇠는 `(유형, 언어, 변형)`."""
    if not dr_rows:
        return db_rows
    out = {}
    for tt, lg, var, txt in db_rows:
        out[(tt, (lg or '').upper(), (var or None))] = txt
    for tt, lg, var, txt in dr_rows:
        out[(tt, (lg or '').upper(), (var or None))] = txt
    return [(tt, lg, var, txt) for (tt, lg, var), txt in out.items()]


def _assets(vid):
    rows = conn().execute(
        "SELECT text_type,lang_code,text_variant,contents FROM sys_text_asset "
        "WHERE clicked_id=? AND text_type IN ('VERS_DESC','VERS_QUESTION','VERS_PRAYER') "
        "AND COALESCE(record_status,'LIVE')='LIVE'", (vid,)).fetchall()
    return _merge(rows, _draft_of(vid))


# ── ① 구조 + 티어 차별화 ─────────────────────────────────────────────────────
def _paras(txt):
    """문단 목록과 「나뉘어 있나」 — `(문단들, 나뉘었나)`.

    ★★★ **문단 경계는 이제 홑 엔터다**(2026-09-24 실측으로 정정).
      2026-08-17 사용자 지시로 이중 엔터를 전부 걷었고(§28-11) 화면이
      `spacing1` 로 문단 간격을 준다. 실측 — 설명문 KO **13,460편 가운데
      빈 줄로 나눈 것은 7편**이고 **12,817편이 홑 엔터**다.
    ⚠⚠⚠ **그런데 이 검사는 빈 줄만 문단으로 보고 있었다** — 그래서 사실상
      **모든 설명문에 「문단없음」이 울었다**. 옛 모델로 재던 자리다(§238차).
      거짓 흠은 그 옆의 진짜 흠을 묻는다(§238차 ⑫ 「깨진 래칫은 못 지킨다」).
    ⚠ 빈 줄로 나눈 옛 글도 그대로 받는다 — 둘 다 문단 경계로 본다.
    """
    t = (txt or '').replace(chr(10) + chr(10), chr(10))
    ps = [p for p in t.split(chr(10)) if p.strip()]
    return ps, len(ps) > 1


def check_structure(bcode, lo, hi, out):
    ok = True
    total = appar_ok = appar_tot = 0
    sims, ratios, greeks, para = [], [], [], {}
    review = []          # 판정하지 않고 사람에게 넘기는 것 (LAY원어 등)
    for vid, ch, vs in _verses(bcode, lo, hi):
        rows = _assets(vid)
        if not rows:
            continue
        total += 1
        d = {(tt, lang, var): txt for tt, lang, var, txt in rows}
        f = []
        kinds = {}                     # text_type → 있는 언어들
        for tt, lang, var, _ in rows:
            kinds.setdefault(tt, set()).add(lang)
        for tt in REQUIRED:
            miss = {'KO', 'EN'} - kinds.get(tt, set())
            if miss:
                f.append('%s 없음(%s)' % (tt, '·'.join(sorted(miss))))
        for tt in OPTIONAL:
            have = kinds.get(tt)
            if have and have != {'KO', 'EN'}:
                f.append('%s 한쪽만(%s)' % (tt, '·'.join(sorted(have))))
        for tt, lang, var, txt in rows:
            txt = txt or ''
            if any(c in CIRC for c in txt):
                f.append('동그라미번호')
            if PNUM.search(txt):
                f.append('괄호번호')
            if chr(92) in txt:
                f.append('백슬래시')
            if '�' in txt or '‍' in txt:
                f.append('치환문자')
            for b in BANNED:
                if b in txt:
                    f.append('교단어:' + b)
            if tt == 'VERS_DESC':
                if lang == 'KO' and APPLY_BLOCK.search(txt):
                    f.append('설명문내적용')
                if not _paras(txt)[1]:
                    # ⚠ 짧은 글에는 나눌 자리가 없다 (2026-08-05 정정).
                    # 창세기 실측 947행 중 360행(38%)이 4문장 미만이었다.
                    # 3문장을 두 문단으로 쪼개면 한쪽이 한 문장뿐인 조각이 된다.
                    # lay.md §3 에 이 규칙을 둔 근거는 "안 넣으면 2천 자가 한 덩어리 벽이
                    # 된다" 인데 206자는 벽이 아니다. **하한을 검사기에 넣는다** —
                    # 고칠 수 없는 것을 잡지 않는다(문단 나누기 도구도 4문장 미만은 손대지 않는다).
                    if len(sentences(txt)) >= PARA_MIN_SENT:
                        f.append('문단없음')
                else:
                    ps = _paras(txt)[0]
                    para.setdefault('%s.%s' % (lang, var), []).append(
                        sum(len(sentences(p)) for p in ps) / max(len(ps), 1))
                for p in _paras(txt)[0]:
                    if p.strip().startswith(THEO):
                        f.append('재인용요약')
        de, dl = d.get(('VERS_DESC', 'KO', 'EXPERT')), d.get(('VERS_DESC', 'KO', 'LAY'))
        if de and dl:
            # 유사도는 **판정하지 않는다**(위 TH 주석). 사람이 볼 목록만 좁힌다.
            s = difflib.SequenceMatcher(None, de, dl, autojunk=False).ratio(); sims.append(s)
            if s >= TH['SIM_MAX']:
                review.append('%d:%d 유사도? %.2f' % (ch, vs, s))
            # ★ LAY 절대 기준 3종 — 이쪽이 판정한다
            nc = lay_cites(dl)
            if nc > TH['LAY_CITE_MAX']:
                f.append('LAY절인용=%d' % nc)
            nw = new_word_ratio(de, dl)
            if nw < TH['NEWWORD_MIN']:
                f.append('신출어휘=%.2f' % nw)
            elif nw < TH['NEWWORD_REVIEW']:
                review.append('%d:%d 신출어휘? %.2f' % (ch, vs, nw))
            # ⚠ 내용 보존은 **판정하지 않는다.** 고유명사로 좁혀 재 봐도 가장 잘 쓰인
            #   요한복음이 최하(0.08)로 나온다 — 압축을 벌준다. 주제를 지켰는지는
            #   기계가 답할 수 없는 물음이라 사람에게 넘긴다.
            kp = keep_ratio(de, dl)
            if kp < TH['KEEP_MIN']:
                review.append('%d:%d 내용보존? %.2f' % (ch, vs, kp))
            r = len(dl) / len(de) if de else 9; ratios.append(r)
            if r > TH['LEN_RATIO_MAX']:
                f.append('길이비=%.2f' % r)
            appar_tot += 1
            if has_apparatus(de):
                appar_ok += 1
            else:
                f.append('학술장치없음')
            gk = greek_count(de); greeks.append(gk)
            if gk > TH['GREEK_MAX_VERSE']:
                f.append('원어과밀=%d' % gk)
            # ⚠ LAY원어는 **위반이 아니라 검토 목록**이다 (2026-08-05 강등).
            #   `is_translit` 은 「괄호 안에 KRV 낱말이 하나도 없으면 음역」으로 판정하는데,
            #   KRV 는 1961년 성경이라 **현대 한국어가 전부 그물을 빠져나간다.**
            #   창세기 실측 51종 가운데 진짜 음역은 7종뿐이었다(오탐 86%) —
            #   위기·불신·처형·폭력·사해·베일·근친상간·에티오피아·샌들 끈 …이 다 걸렸다.
            #   빈도·괄호밖 등장 등 자동 신호로도 갈리지 않았다(헤세드 10회 · 샬롬 22회로
            #   흔한 한국어와 겹친다). ⇒ 사람이 보라고 띄우되 판정하지 않는다.
            #   §8-2 가 중국어 제목을 ERROR 로 올리지 않고 CHECK 까지만 하는 것과 같은 처리다.
            if greek_count(dl):
                review.append('%d:%d LAY원어? %s'
                              % (ch, vs, ' · '.join(m for m in GREEK_PAREN.findall(dl)
                                                    if is_translit(m))))
        dee, dle = d.get(('VERS_DESC', 'EN', 'EXPERT')), d.get(('VERS_DESC', 'EN', 'LAY'))
        if dee and dle:
            # KO 와 같은 잣대를 쓴다. autojunk 를 켜면 영어는 글자의 92%가 버려져
            # 사실상 검사되지 않는다(위 TH 주석). 판정하지 않고 경고만 낸다.
            s2 = difflib.SequenceMatcher(None, dee, dle, autojunk=False).ratio()
            if s2 >= TH['SIM_MAX']:
                review.append('%d:%d EN유사도? %.2f' % (ch, vs, s2))
            nw2 = new_word_ratio_en(dee, dle)
            if nw2 < TH['NEWWORD_MIN']:
                f.append('EN신출어휘=%.2f' % nw2)
            elif nw2 < TH['NEWWORD_REVIEW']:
                review.append('%d:%d EN신출어휘? %.2f' % (ch, vs, nw2))
            r2 = len(dle) / len(dee) if dee else 9
            if r2 > TH['LEN_RATIO_MAX']:
                f.append('EN길이비=%.2f' % r2)
        if f:
            ok = False
            out.append('  %d:%d  %s' % (ch, vs, ' · '.join(dict.fromkeys(f))))
    if not total:
        out.append('  (자산 없음 — 검사할 것이 없다)')
        return None
    # ★ 분모는 **EXPERT 를 가진 절**이다 (2026-08-09 정정).
    #   전체 절수로 나누면 EXPERT 가 아직 없는 장이 통째로 「학술장치 0%」로 걸린다.
    #   구약은 LAY 를 전권 먼저 쓰기로 했으므로(lay.md §1-1) 그 상태가 정상이고 오래 간다.
    #   EXPERT 가 하나도 없으면 EXPERT 검사 자체를 건너뛴다 — 없는 것을 벌하지 않는다.
    cover = (appar_ok / appar_tot) if appar_tot else None
    out.append('  %d절 · EXPERT %d절 · 유사도 %.2f · 길이비 %.2f · 학술장치 %s · 원어/절 %.2f'
               % (total, appar_tot, st.mean(sims) if sims else 0,
                  st.mean(ratios) if ratios else 0,
                  '%.0f%%' % (cover * 100) if cover is not None else '—',
                  st.mean(greeks) if greeks else 0))
    if cover is not None and cover < TH['APPARATUS_COVER']:
        ok = False
        out.append('  <<< 학술장치 커버 %.0f%% < %.0f%%' % (cover * 100, TH['APPARATUS_COVER'] * 100))
    if greeks and st.mean(greeks) > TH['GREEK_AVG_MAX']:
        ok = False
        out.append('  <<< 원어 과밀: 절당 %.2f > %.1f' % (st.mean(greeks), TH['GREEK_AVG_MAX']))
    if ratios and st.mean(ratios) > TH['LEN_RATIO_AVG']:
        ok = False
        out.append('  <<< LAY 압축 부족: 장평균 %.2f > %.2f' % (st.mean(ratios), TH['LEN_RATIO_AVG']))
    for lane in sorted(para):
        m = st.mean(para[lane])
        if m < TH['SENT_PER_PARA_MIN']:
            ok = False
            out.append('  <<< 문단 잘게 쪼갬: %s 문단당 %.2f문장 < %.1f'
                       % (lane, m, TH['SENT_PER_PARA_MIN']))
    if review:
        out.append('  ── 검토 목록 %d건 (판정 아님 — 대부분 한국어 뜻풀이다) ──' % len(review))
        for r in review[:20]:
            out.append('     ' + r)
        if len(review) > 20:
            out.append('     … +%d건' % (len(review) - 20))
    return ok


# ── ② 원어 표기 ─────────────────────────────────────────────────────────────
_LEX = None
def greek_lexicon():
    """음역 어휘집. 정상 코퍼스(딛·골·몬)의 괄호 안 순수 한글 토큰에서 만든다."""
    global _LEX
    if _LEX is None:
        g = set()
        for bc in (56, 51, 57):
            r = conn().execute('SELECT MIN(verse_id),MAX(verse_id) FROM bible_index WHERE bcode=?',
                               (bc,)).fetchone()
            if not r or r[0] is None:
                continue
            for _, _, lang, txt in conn().execute(
                    "SELECT clicked_id,text_type,lang_code,contents FROM sys_text_asset "
                    "WHERE clicked_id BETWEEN ? AND ? AND text_variant='EXPERT' "
                    "AND text_type IN ('VERS_DESC','VERS_QUESTION') "
                    "AND COALESCE(record_status,'LIVE')='LIVE'", (r[0], r[1])):
                if lang != 'KO':
                    continue
                for m in PAREN.finditer(txt or ''):
                    for t in re.split(r'[ ·,]+', m.group(1).strip()):
                        if t and HANGUL.fullmatch(t) and 2 <= len(t) <= 8:
                            g.add(t)
        g -= set('그것 이것 저것 사람 하나님 그리스도 예수 우리 너희 자기 모든 것을 것이 함을 함이'.split())
        _LEX = g
    return _LEX


GK_END = re.compile(r'(os|on|is|ei|ai|es|us|oi|ou|to|the|sis|mai|sthe|theis|omen|ontos|eos)$')
ENG_COMMON = set('the of to and in a for is that be by not or from with as it he we they '
                 'his who our your this so all'.split())


# 한국어 활용 어미 — 음역에는 붙지 않는다.
_KO_TAIL = re.compile(r'(?:하다|되다|시키다|리다|뜨리다|이다|었다|았다|겠다|거나|지만|면서|'
                      r'는데|으며|하며|하고|하니|한|된|인|음|임|심|함|기|게|히|이|적|들|'
                      r'째|처럼|같이|보다|마다|조차|밖에|름|됨|짐|힘|델|체와|체의|체를)$')


def _is_gk_ko(t):
    """이 한글 토큰이 원어 음역인가.

    ⚠ 어휘집은 괄호 뜻풀이에서 만들어져 한국어가 절반쯤 섞여 있다. KRV 대조만으로는
      **개역한글(1961)에 없는 현대 한국어**가 그대로 통과한다 — 자가 검증에서 실측했다:
      「진짜 음역」 774개 가운데 `가정과`·`대속의`·`집안을`·`훔쳤거나`·`절박한`·`올바름` 처럼
      명백한 한국어가 절반이었다. 원인은 `is_translit` 과 달리 여기서 **조사·어미를 떼지 않은 것**.
      ⇒ ① 조사를 뗀 어간이 KRV 에 있으면 한국어 ② 한국어 활용 어미로 끝나면 한국어.
    """
    if t not in greek_lexicon():
        return False
    v = krv_vocab()
    if t in v:
        return False
    if _KO_TAIL.search(t):
        return False
    for p in _PART:                       # 조사를 떼고 다시 본다 (가정과 → 가정)
        if len(t) > len(p) + 1 and t.endswith(p) and t[:-len(p)] in v:
            return False
    return True


def _is_gk_en(t):
    t2 = t.strip('.,;').lower()
    if not re.fullmatch(r'[a-z]{2,}', t2) or t2 in ENG_COMMON or t2 in eng_vocab():
        return False
    return bool(GK_END.search(t2))


def check_greek(bcode, lo, hi, out):
    """역순(원어(한글)) · 절 전체 음독 검사.

    ⚠ 어휘집이 비면 위반이 0으로 나온다. 그것을 PASS 로 보고하면 §18-9 의 실패다.
      ⇒ 임계 미만이면 None(=SKIP) 을 돌려주고 전체 판정에 넣지 않는다.
    """
    if len(greek_lexicon()) < TH['LEXICON_MIN']:
        out.append('  SKIP — 음역 어휘집 %d개(< %d). 정상 코퍼스(딛·골·몬 EXPERT)가 없으면 '
                   '이 검사는 탐지력이 없다. 구약에서는 히브리어 코퍼스가 생긴 뒤 다시 건다.'
                   % (len(greek_lexicon()), TH['LEXICON_MIN']))
        return None
    ok = True
    for ch in range(lo, hi + 1):
        r = conn().execute('SELECT MIN(verse_id),MAX(verse_id) FROM bible_index '
                           'WHERE bcode=? AND chapter=?', (bcode, ch)).fetchone()
        if not r or r[0] is None:
            continue
        rev = whole = 0
        # ⚠ **초안도 함께 본다**(2026-09-23) — 적재 전에 재려면 여기도 겹쳐야
        #   한다. 이 조회만 `_assets` 를 안 쓰고 구간으로 훑는다(절마다 물으면
        #   장 하나에 수십 번이다).
        _g = list(conn().execute(
                "SELECT clicked_id,text_type,lang_code,contents FROM sys_text_asset "
                "WHERE clicked_id BETWEEN ? AND ? AND text_variant='EXPERT' "
                "AND text_type IN ('VERS_DESC','VERS_QUESTION') "
                "AND COALESCE(record_status,'LIVE')='LIVE'", (r[0], r[1])))
        if _DRAFT:
            _seen = {(a, b, (c or '').upper()) for a, b, c, _d in _g}
            _g = [(a, b, c, d) for a, b, c, d in _g
                  if (a, b, (c or '').upper()) not in
                  {(v, tt, lg) for (v, tt, lg, var) in _DRAFT
                   if var == 'EXPERT' and tt in ('VERS_DESC', 'VERS_QUESTION')
                   and r[0] <= v <= r[1]}]
            _g += [(v, tt, lg, txt) for (v, tt, lg, var), txt in _DRAFT.items()
                   if var == 'EXPERT' and tt in ('VERS_DESC', 'VERS_QUESTION')
                   and r[0] <= v <= r[1]]
            del _seen
        for _, _, lang, txt in _g:
            txt = txt or ''
            # 전체 음독 — 본문의 모든 괄호를 본다(인용부호 의존을 버렸다. 영어 소유격
            #   아포스트로피가 인용 시작으로 읽혀 문장이 통째로 잡히던 오탐 때문).
            for pm in PAREN.finditer(txt):
                it = [t for t in re.split(r'[ ·,]+', pm.group(1).strip()) if t]
                n = sum(1 for t in it if (_is_gk_ko(t) if lang == 'KO' else _is_gk_en(t)))
                if n >= 3:
                    whole += 1
                    out.append('    전체음독 %d장 «%s»' % (ch, txt[max(0, pm.start() - 40):pm.end()]
                                                            .replace('\n', ' ')))
            # 역순 — 인용 구간 안의 짧은 용어에 한정한다(넓히면 오탐이 폭증한다).
            for qm in QUOTED.finditer(txt):
                q = qm.group(1)
                pm = PAREN.search(q)
                if not pm:
                    continue
                lt = [t for t in re.split(r'[ ·,]+', q[:pm.start()].strip()) if t]
                it = [t for t in re.split(r'[ ·,]+', pm.group(1).strip()) if t]
                if lang == 'KO':
                    hit = (lt and _is_gk_ko(lt[-1]) and len(lt) <= 3
                           and HANGUL.search(pm.group(1))
                           and not any(_is_gk_ko(t) for t in it))
                else:
                    inner_eng = any(t.strip('.,;').lower() in ENG_COMMON
                                    or (re.fullmatch(r'[a-z]{2,}', t.strip('.,;').lower())
                                        and not _is_gk_en(t)) for t in it)
                    hit = (lt and all(_is_gk_en(t) for t in lt) and inner_eng
                           and not any(_is_gk_en(t) for t in it))
                if hit:
                    rev += 1
                    out.append('    역순 %d장 «%s»' % (ch, q[:70]))
        if rev or whole:
            ok = False
    out.append('  어휘집 %d개 · %s' % (len(greek_lexicon()), '위반 0건' if ok else '위반 있음'))
    return ok


# ── ③ 본문 재진술 ────────────────────────────────────────────────────────────
def _norm(s):
    import unicodedata
    return unicodedata.normalize('NFC', re.sub(r'\s+', '', s or ''))


def check_verserep(bcode, lo, hi, out):
    """DESC 안에 본문을 거의 그대로 옮긴 문장이 있는가.
    따옴표 없이 옮겨 적은 verbatim 평서문을 잡는다 — 인용부호 검사로는 안 걸린다."""
    ok = True
    n = 0
    for vid, ch, vs in _verses(bcode, lo, hi):
        ref = {}
        for code, lang in (('KRV', 'KO'), ('BSB', 'EN')):
            r = conn().execute("SELECT verse_text FROM bible_content "
                               "WHERE verse_id=? AND version_code=?", (vid, code)).fetchone()
            ref[lang] = _norm(r[0]) if r else ''
        for lang, var in (('KO', 'EXPERT'), ('KO', 'LAY'), ('EN', 'EXPERT'), ('EN', 'LAY')):
            # ⚠ **초안이 DB 를 이긴다**(2026-09-23)
            _d = _DRAFT.get((int(vid), 'VERS_DESC', lang, var))
            if _d is not None:
                r = (_d,)
            else:
                r = conn().execute(
                    "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_DESC' "
                    "AND lang_code=? AND text_variant=? AND COALESCE(record_status,'LIVE')='LIVE'",
                    (vid, lang, var)).fetchone()
            if not r or len(ref[lang]) < 12:
                continue
            n += 1
            best, bs = 0.0, ''
            for p in (r[0] or '').split('\n\n'):
                for s in SENT_SPLIT.split(p):
                    sn = _norm(s)
                    if len(sn) < 12:
                        continue
                    ratio = difflib.SequenceMatcher(None, sn, ref[lang]).ratio()
                    if ratio > best:
                        best, bs = ratio, s.strip()
            if best >= TH['VERSEREP']:
                ok = False
                out.append('  %d:%d %s.%s  %.2f  «%s»' % (ch, vs, lang, var, best, bs[:50]))
    out.append('  %d개 검사 · %s' % (n, '위반 0건' if ok else '위반 있음'))
    return ok if n else None


# ── ④ 자기 절 직접 인용 ─────────────────────────────────────────────────────
# ★ 2026-08-10 신설 (사용자 지시). 설명문 안에 **그 절 본문을 그대로 따다 붙이는** 버릇을
#   잡는다. `③ 본문 재진술` 은 문장 통째의 유사도라 문장 한복판에 박힌 짧은 인용을 못 본다 —
#   민 13:33 `우리는 스스로 보기에도 메뚜기 같다 — 여기까지는…` 이 그렇게 통과했다.
#
#   왜 금지인가: 독자는 바로 위에 본문을 보고 있다. 그대로 옮기면 같은 글자를 두 번 읽힌다.
#   ⚠ **자기 절만** 본다. 다른 절을 인용하는 것은 상호참조라 오히려 권장된다(lay.md §7).
QUOTE_MIN_KO = 10        # 공백 제거 후 글자 수
QUOTE_MIN_EN = 6         # 낱말 수
QUOTED_TYPES = ('VERS_DESC', 'VERS_QUESTION')
_EN_W = re.compile(r"[a-z']+")
_KO_PART = re.compile(r'[와과의이가은는를을에서도로만]')
_EN_STOP = {'the', 'of', 'and', 'a', 'an', 'in', 'to', 'is', 'are', 'was', 'were', 'his',
            'her', 'its', 'their', 'for', 'with', 'on', 'at', 'from', 'by', 'be', 'as',
            'that', 'this', 'it', 'they', 'we', 'you', 'he', 'she', 'i', 'all', 'not',
            'but', 'or', 'so', 'shall', 'will', 'into', 'out', 'up', 'down', 'them', 'him'}

# ⚠ **이름 나열은 뺀다.** 「아므람과 이스할과 헤브론과 웃시엘」을 안 쓰고 그 절을 설명할 수는
#   없다. 인명·지명은 인용이 아니라 가리키는 말이다. 빼지 않으면 명단 장(민 1·3·7·10·26·33)이
#   통째로 위반이 되어 검사기가 쓸모를 잃는다 — 못 지킬 문턱은 안 지켜진다.


_KO_SON = re.compile(r'([가-힣]{2,})의 아들 ([가-힣]{2,})')


def _names_ko(ref):
    """이 절에 나오는 고유명사. 사전 + 「X의 아들 Y」 꼴.

    ⚠ 사전(`_proper_nouns`)만으로는 모자란다 — 족장 명단의 이름 상당수가
      ENTITY_NAME 에 없어서 민 10:14~26 이 통째로 오탐이 됐다. 계보 어법을 함께 본다.
    """
    P = _proper_nouns()
    out = set()
    for tok in re.findall(r'[가-힣]+', ref or ''):
        for L in range(len(tok), 1, -1):
            if tok[:L] in P:
                out.add(tok[:L])
                break
    for m in _KO_SON.finditer(ref or ''):
        out.add(m.group(1))
        out.add(m.group(2))
    out.add('아들')
    return sorted(out, key=len, reverse=True)


def _names_en(ref):
    """문장 첫 낱말이 아닌데 대문자로 시작하면 고유명사로 본다."""
    out, start = set(), True
    for m in re.finditer(r"[A-Za-z']+|[.?!]", ref or ''):
        t = m.group(0)
        if t in '.?!':
            start = True
            continue
        if not start and t[0].isupper():
            out.add(t.lower())
        start = False
    return out


def _name_run(frag, ref, lang):
    """이 조각이 사실상 이름 나열인가."""
    if lang == 'EN':
        names = _names_en(ref)
        return len([w for w in frag.split()
                    if w not in _EN_STOP and w not in names]) < 2
    # 「A와 B와 C」 꼴 나열 — 항목이 셋 이상이고 하나하나가 짧으면 이름/품목 나열로 본다.
    #   사전에 없는 이름(민 3:19 아므람·이스할·헤브론·웃시엘)이 많아 사전만으로는 못 걸러진다.
    parts = re.split(r'[와과]', frag)
    if len(parts) >= 3 and all(len(p) <= 7 for p in parts):
        return True
    s = frag
    for w in _names_ko(ref):
        s = s.replace(w, '')
    return len(_KO_PART.sub('', s)) < 4


def self_quotes(desc, ref, lang):
    """설명문에서 그 절 본문을 그대로 옮긴 구간 [(크기, 조각), ...]."""
    if not desc or not ref:
        return []
    if lang == 'EN':
        wa, wb = _EN_W.findall(desc.lower()), _EN_W.findall(ref.lower())
        sm = difflib.SequenceMatcher(None, wa, wb, autojunk=False)
        hits = [(n, ' '.join(wa[i:i + n]))
                for i, _j, n in sm.get_matching_blocks() if n >= QUOTE_MIN_EN]
    else:
        a, b = _norm(desc), _norm(ref)
        sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
        hits = [(n, a[i:i + n])
                for i, _j, n in sm.get_matching_blocks() if n >= QUOTE_MIN_KO]
    return [(n, f) for n, f in hits if not _name_run(f, ref, lang)]


def check_selfquote(bcode, lo, hi, out):
    ok = True
    n = 0
    for vid, ch, vs in _verses(bcode, lo, hi):
        ref = {}
        for code, lang in (('KRV', 'KO'), ('BSB', 'EN')):
            r = conn().execute("SELECT verse_text FROM bible_content"
                               " WHERE verse_id=? AND version_code=?", (vid, code)).fetchone()
            ref[lang] = r[0] if r else ''
        for tt, lang, var, txt in _assets(vid):
            if tt not in QUOTED_TYPES or lang not in ref or not ref[lang]:
                continue
            n += 1
            for size, frag in self_quotes(txt, ref[lang], lang):
                ok = False
                out.append('  %d:%d %s.%s  %d  «%s»' % (ch, vs, lang, var or '-', size, frag[:60]))
    out.append('  %d개 검사 · %s' % (n, '위반 0건' if ok else '위반 있음'))
    return ok if n else None


# ── ⑤ 줄표 ──────────────────────────────────────────────────────────────────
# ★ 2026-08-10 신설 (사용자 지시). 설명문에 **줄표(— –)를 쓰지 않는다.**
#   왜: 줄표는 뒤에 오는 말을 툭 붙여 놓기 좋아서 **본문 인용을 불러들인다** — 실제로
#   민 13:33 `메뚜기 같다 — 여기까지는…` 이 그렇게 들어왔다. 그리고 읽는 사람에게는
#   앞뒤 관계를 스스로 이으라고 떠넘기는 부호다. 마침표·쉼표·콜론으로 관계를 밝힌다.
#   ⚠ 붙임표(-)는 건드리지 않는다 — `Ex. 4:15-16` · `year-old` 가 정상이다. 띄어 쓴
#     ` - ` 만 줄표로 본다.
DASH_RX = re.compile(r'[—–]|(?<= )-(?= )')


def check_dash(bcode, lo, hi, out):
    ok = True
    n = 0
    for vid, ch, vs in _verses(bcode, lo, hi):
        for tt, lang, var, txt in _assets(vid):
            if tt not in QUOTED_TYPES and tt != 'VERS_PRAYER':
                continue
            n += 1
            for m in DASH_RX.finditer(txt or ''):
                ok = False
                i = m.start()
                out.append('  %d:%d %s.%s  «%s»'
                           % (ch, vs, lang, var or '-',
                              (txt[max(0, i - 24):i + 26]).replace('\n', ' ')))
    out.append('  %d개 검사 · %s' % (n, '위반 0건' if ok else '위반 있음'))
    return ok if n else None


# ── ⑥ 요체 ──────────────────────────────────────────────────────────────────
SENT_RX = re.compile(r'[^.?!\n]*[.?!]')
QUOTE_RX = re.compile(r"['‘“][^'‘’“”]{2,120}['’”]")


# `요` 로 끝나지만 해요체가 아닌 명사. 앞 글자까지 묶어 봐야 가려진다.
# ⚠ `가요`·`서요`·`와요` 는 넣지 말 것 — 동사 활용과 겹친다.
_NOUN_YO = re.compile(r'(?:풍요|필요|중요|주요|고요|수요|소요|동요|민요|개요|강요|긴요|요요)$')


def _is_yoche(s):
    """문장 끝이 요/죠 인가 — **평서문에 한한다**.

    ★ 성경 인용은 절대 건드리지 않는다(사용자 지시). 게이트가 인용을 잡으면 그것을 고치라는
      압력이 되고, 실제로 그렇게 고어체 '~이요' 가 '~이다' 로 바뀐 전례가 있다(마 5:8 등).
      뚫렸던 두 자리를 함께 막는다 — ① 인용부호 뒤 닫는 괄호 ② 인용 안에서 잘린 문장.

    ★ **물음형 요체(`~하나요?`·`~할까요?`)도 위반이다 (2026-08-04 사용자 결정).**
      한 문단 안에서 평서문은 `합니다`(하십시오체), 물음은 `하나요`(해요체)면 격식체가 갈린다.
      나머지 전부가 합니다체이므로 물음도 `합니까?` 로 쓴다.
      · **묵상질문**은 `합니까?` 로 (`있나요?`→`있습니까?` · `무엇인가요?`→`무엇입니까?`)
      · **설명문 안의 자문**은 물음을 없애고 평서문으로 (설명문은 독자에게 말 거는 자리가 아니다)

      되돌아보기: 이 규칙을 세우기 전 잠시 물음표를 면제했는데, 그때 근거는
      「정상 코퍼스인 롬 8이 요체 90건으로 FAIL 한다」였다. 그런데 그 90건이 사실
      **정상이 아니라 코퍼스 전체에 퍼진 격식체 혼용**이었다. 코퍼스를 기준으로 규칙을
      느슨히 하면 이렇게 된다 — **기준은 코퍼스가 아니라 규격이다.**

    ⚠ 소급 대상 5,010건(묵상질문 4,707 · 설명문 303). 별건으로 남겨 두었다 — data.md §1-b.
    """
    s = s.strip()
    if (s.count('"') + s.count('“') + s.count('”')) % 2 == 1:
        return False
    core = re.sub(r'[.?!]+$', '', s)
    core = re.sub(r'\s*\([^()]*\)$', '', core)
    if re.search(r"[요죠]['\"”’][)\]]*$", core):
        return False
    core = re.sub(r'["\'”’)\]]*$', '', core)
    if not (core.endswith('요') or core.endswith('죠')):
        return False

    # ★ 여기서부터는 오탐 제거다 (2026-08-04, 구약 착수 때 실측으로 추가).
    #   탐지기가 성경 인용과 명사를 계속 물어 오면 **진짜 위반이 그 소음에 가린다.**
    #   내용을 고칠 일이 아니라 탐지기를 고칠 일이다.

    # ① 개역한글 고전 연결어미 `~이요` — 해요체가 아니다.
    #    실례: 창 32:14 '암염소가 이백이요 숫염소가 이십이요'(KRV 그대로).
    #    현대 해요체는 `~이에요` 라 그것만 남겨 둔다.
    if core.endswith('이요') and not core.endswith('이에요'):
        return False

    # ② `요` 로 끝나는 **명사**. 실례: 창 49:12·49:25 '…농업·목축의 풍요.'
    #    ⚠ `가요`·`서요` 는 넣지 않는다 — '옮겨 가요'·'함께 서요' 가 진짜 해요체였다.
    if _NOUN_YO.search(core):
        return False
    return True


def check_yoche(bcode, lo, hi, out):
    """요체 무관용. 평서형과 물음형을 나누어 보고한다 — 고치는 방법이 다르기 때문이다.
    평서형은 어미만 바꾸면 되고, 물음형은 묵상질문이면 `합니까?`, 설명문이면 평서문으로 고친다."""
    ok = True
    tot = 0
    hits = {'평서': [], '물음': []}
    for vid, ch, vs in _verses(bcode, lo, hi):
        for tt, lang, var, txt in _assets(vid):
            if lang != 'KO' or not txt:
                continue
            body = QUOTE_RX.sub(' ', txt)          # 인용 구간은 통째로 제외
            for para in body.split('\n'):
                for m in SENT_RX.finditer(para):
                    s = m.group(0).strip()
                    if not s:
                        continue
                    tot += 1
                    if _is_yoche(s):
                        ok = False
                        kind = '물음' if s.rstrip().endswith(('?', '？')) else '평서'
                        hits[kind].append('  [%s] %d:%d %s.%s  «%s»'
                                          % (kind, ch, vs, tt, var or '-', s[-40:]))
    yo = len(hits['평서']) + len(hits['물음'])
    for k in ('평서', '물음'):
        out.extend(hits[k][:12])
        if len(hits[k]) > 12:
            out.append('  [%s] … 외 %d건' % (k, len(hits[k]) - 12))
    out.append('  문장 %d개 · 요체 %d개 (평서 %d · 물음 %d) · %s'
               % (tot, yo, len(hits['평서']), len(hits['물음']),
                  '위반 0건' if ok else '무관용 기준 위반'))
    return ok if tot else None


# ── ⑤ 검토용 목록 (합불 없음) ────────────────────────────────────────────────
IMG_KW = ['그물', '음악', '접착제', '거울', '주사위', '불화살', '징이 박', '옷을 벗', '옷을 입',
          '배처럼', '파도', '나무처럼', '건물', '농부', '씨를', '갓난', '젖', '운동', '경주',
          '군사', '병사']
GL = re.compile(r'[가-힣]{2,}\(([가-힣A-Za-z][^)]*)\)')
FRAME = ['여기에', '그러므로신자', '그러므로우리', '다음절', '앞절', '이절은', '바울은', '밝힌다', '뜻한다']


def inventory(bcode, lo, hi):
    for ch in range(lo, hi + 1):
        vv = conn().execute("SELECT verse_id,verse FROM bible_index WHERE bcode=? AND chapter=? "
                            "ORDER BY verse", (bcode, ch)).fetchall()
        if not vv:
            continue
        gl, xr, img, frag = {}, {}, [], {}
        for vid, vs in vv:
            for (txt,) in conn().execute(
                    "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_DESC' "
                    "AND lang_code='KO' AND text_variant IN ('EXPERT','LAY') "
                    "AND COALESCE(record_status,'LIVE')='LIVE'", (vid,)):
                txt = txt or ''
                for m in GL.finditer(txt):
                    gl.setdefault(m.group(0)[:m.group(0).index('(')] + '(' + m.group(1) + ')',
                                  set()).add(vs)
                for x in CROSSREF.findall(txt):
                    xr.setdefault(x, set()).add(vs)
                for sent in re.split(r'(?<=다[.\s])', txt):
                    if any(k in sent for k in IMG_KW) and sent.strip():
                        img.append((vs, sent.strip()[:100]))
                clean = re.sub(r'\s+', '', txt)
                for i in range(0, max(0, len(clean) - 20), 10):
                    frag.setdefault(clean[i:i + 20], set()).add(vs)
        print('\n===== bcode %d %d장 (%d절) =====' % (bcode, ch, len(vv)))
        print('  [원어 글로스] ' + (', '.join(sorted(gl)) or '(없음)'))
        print('  [상호참조]   ' + (', '.join(sorted(xr)) or '(없음)'))
        print('  [비유/예화]  ' + ('' if img else '(없음)'))
        for vs, s in img:
            print('     %d:%d  %s' % (ch, vs, s))
        reps = {f: sorted(v) for f, v in frag.items()
                if len(v) >= 3 and not any(k in f for k in FRAME)}
        print('  [절간 반복 20자+/3절+] ' + ('' if reps else '(없음)'))
        for f, v in list(reps.items())[:15]:
            print('     %s  «%s»' % (v, f))


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    """★ 의무. 탐지력 없는 검사가 PASS 를 찍는 것이 가장 나쁘다(§18-9).
    각 검사에 인위 결함을 넣어 실제로 걸리는지 본다. DB 는 건드리지 않는다."""
    print('db_vers_gate 자가 검증')
    bad = []

    # ⓪ **초안 겹치기** (2026-09-23 · 적재하기 전에 재려고 신설)
    #   ⚠ 양방향 — 끼우면 보이고, 걷으면 안 보이고, **DB 는 안 바뀐다.**
    try:
        _v = conn().execute(
            "SELECT clicked_id FROM sys_text_asset WHERE text_type='VERS_DESC' "
            "AND text_variant='LAY' AND lang_code='KO' "
            "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
        if not _v:
            bad.append('초안 검사: 견줄 절이 없다')
        else:
            _vid = int(_v[0])
            _n0 = conn().execute(
                "SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
            _db = {(t, l, x): c for t, l, x, c in _assets(_vid)}
            _key = ('VERS_DESC', 'KO', 'LAY')
            if _key not in _db:
                bad.append('초안 검사: 그 절에 KO LAY 가 없다')
            else:
                _mark = '__초안겹치기시험__'
                with draft([(_vid, 'VERS_DESC', 'KO', 'LAY', _mark)]):
                    _got = {(t, l, x): c for t, l, x, c in _assets(_vid)}
                    if _got.get(_key) != _mark:
                        bad.append('초안을 끼웠는데 게이트가 DB 를 본다')
                    if len(_got) < len(_db):
                        bad.append('초안을 끼우니 다른 자리가 사라졌다')
                    # verserep 의 제 조회도 초안을 봐야 한다
                    if _DRAFT.get((_vid, 'VERS_DESC', 'KO', 'LAY')) != _mark:
                        bad.append('초안 자리표가 안 실렸다')
                    # 없던 자리도 더할 수 있다(신규 작성)
                    set_draft([(_vid, 'VERS_PRAYER', 'KO', None, _mark)])
                    if not any(t == 'VERS_PRAYER' and c == _mark
                               for t, _l, _x, c in _assets(_vid)):
                        bad.append('없던 자리에 초안을 못 더한다')
                _back = {(t, l, x): c for t, l, x, c in _assets(_vid)}
                if _back != _db:
                    bad.append('with 를 나왔는데 초안이 남아 있다')
                if _DRAFT:
                    bad.append('clear_draft 가 안 걷는다')
            _n1 = conn().execute(
                "SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
            if _n0 != _n1:
                bad.append('초안 검사가 DB 를 건드렸다: %s → %s' % (_n0, _n1))
    except Exception as _e:                               # noqa: BLE001
        bad.append('초안 검사에서 터졌다: %s' % _e)
    finally:
        clear_draft()

    # ① 구조 — 하위 판정 함수를 직접 친다
    if not any(c in CIRC for c in '첫째 ① 둘째'):
        bad.append('동그라미 번호 미탐지')
    if not PNUM.search('첫째 (1) 둘째'):
        bad.append('괄호 번호 미탐지')
    if not APPLY_BLOCK.search('이것을 우리 삶에 적용해 봅시다'):
        bad.append('설명문 내 적용 미탐지')
    if not any(b in '칼뱅이 말한 대로' for b in BANNED):
        bad.append('교단어 미탐지')
    if difflib.SequenceMatcher(None, '같은 문장입니다.', '같은 문장입니다.').ratio() < TH['SIM_MAX']:
        bad.append('유사도 기준 이상')

    # ①-a 문단 경계 — **홑 엔터도 문단이다** (2026-09-24 정정).
    #   ⚠ 빈 줄만 보던 옛 잣대는 실측 설명문 13,460편 가운데 13,453편에
    #     「문단없음」을 울렸다. 양방향으로 못 박는다.
    _p1 = '첫 문단입니다.' + chr(10) + '둘째 문단입니다.'
    _p2 = '첫 문단입니다.' + chr(10) + chr(10) + '둘째 문단입니다.'
    _p3 = '한 덩이입니다. 나눌 자리가 없습니다.'
    if not _paras(_p1)[1]:
        bad.append('홑 엔터를 문단으로 안 본다')
    if not _paras(_p2)[1]:
        bad.append('빈 줄로 나눈 옛 글을 문단으로 안 본다')
    if _paras(_p3)[1]:
        bad.append('한 덩이를 문단으로 본다')
    if len(_paras(_p1)[0]) != 2 or len(_paras(_p2)[0]) != 2:
        bad.append('문단 수를 잘못 센다')

    # ①-b 문단없음 하한 — 양방향으로 확인한다 (2026-08-05 신설).
    #   느슨하게만 검증하면 "고칠 수 없는 것을 안 잡는다" 는 취지가 뒤집혀
    #   진짜 '벽' 까지 놓치게 된다. 그래서 **잡아야 하는 쪽도 함께 본다.**
    _n = lambda t: len(sentences(t))

    short4 = '첫 문장이다. 둘째 문장이다. 셋째 문장이다. 넷째 문장이다.'
    long5 = short4 + ' 다섯째 문장이다.'
    if _n(short4) != 4:
        bad.append('문장 세기 오류 — 4문장을 %d 로 셌다' % _n(short4))
    if _n(long5) != 5:
        bad.append('문장 세기 오류 — 5문장을 %d 로 셌다' % _n(long5))
    if _n(short4) >= PARA_MIN_SENT:
        bad.append('4문장을 문단없음으로 잡는다 — 나누면 2+2 라 밀도 하한에 걸린다')
    if _n(long5) < PARA_MIN_SENT:
        bad.append('5문장짜리 한 덩어리를 놓친다 — 이것이 진짜 벽이다')
    if _n('One. Two. Three. Four. Five.') < PARA_MIN_SENT:
        bad.append('영어 5문장을 놓친다')

    # ★ 약어 뒤를 문장 끝으로 치면 문단이 문장 한가운데서 갈린다 (실제로 당했다)
    if _n("God's command (cf. Ps 148:4) stands firm.") != 1:
        bad.append('`cf.` 를 문장 끝으로 친다 — 문단이 문장 안에서 갈린다')
    if _n('It rests on Gen 1:1. Then it moves on.') != 2:
        bad.append('약어 보호가 지나쳐 진짜 문장 경계를 놓친다')

    # ①-c 학술장치 — **양방향**이 의무다 (2026-08-07 신설).
    #   넓히기만 하고 「잡아야 하는 것」을 고정하지 않으면 무조건 통과하는 껍데기가 된다.
    #   창세기 97건 오탐 사건이 정확히 그 반대 방향의 실패였다(위 SCRIPT 주석).
    for _t, _why in (
        ('정죄(카타크리마)는 법정 용어로', '신약 표준 표기'),
        ("'하늘'(샤마임, שָׁמַיִם)이라는 명명", '구약 원문 병기 표기'),
        ("'창일'(가바르 — 압도하다·우세하다)의 반복", '따옴표 음역만 있는 경우'),
        ('3:9 「네가 어디 있느냐」와 같은 추적', '같은 책 안 장:절 참조'),
        ('16절의 명령과 합쳐 읽어야 한다', '같은 장 안 N절 참조'),
        ('언약의 성취로 읽힌다', '신학 용어'),
    ):
        if not has_apparatus(_t):
            bad.append('학술장치를 놓쳤다 — %s' % _why)
    # ★ 이것이 없으면 검사가 죽는다. 창 5:7 원문 그대로 — 원어도 참조도 없다.
    _bare = ('정형구 둘째 요소 — 에노스를 낳은 후 807년의 평범한 세월·자녀들. '
             '기록은 짧으나 그 안에 무수한 일상이 담겼다.')
    if has_apparatus(_bare):
        bad.append('학술장치 없는 글을 통과시킨다 — 검사가 껍데기가 됐다')
    if _n('See e.g. Rom 8:1 for this. A second sentence follows.') != 2:
        bad.append('`e.g.` 처리 오류')

    # ② 원어 — 어휘집이 살아 있는지부터
    lex = greek_lexicon()
    print('  음역 어휘집: %d개' % len(lex))
    if len(lex) < TH['LEXICON_MIN']:
        print('  ! 어휘집이 작아 원어 검사는 SKIP 으로 동작한다(구약에서 정상).')
    else:
        # ⚠ 어휘집에는 한국어가 섞여 있는 것이 정상이다(괄호 뜻풀이에서 만들어지므로).
        #   KRV 필터가 그것을 걸러 낸다. 그러니 아무 항목이나 집어 검사하면 안 된다
        #   (첫 실행에서 '뿌리고' 를 집어 자가 검증이 헛되이 FAIL 했다).
        #   확인해야 할 것은 **걸러 내고도 진짜 음역이 남아 있는가** 이다.
        real = [t for t in lex if _is_gk_ko(t)]
        print('  그 가운데 진짜 음역: %d개 (예: %s)'
              % (len(real), ', '.join(sorted(real)[:4]) if real else '-'))
        if len(real) < 20:
            bad.append('음역 판별력 없음 — KRV 필터 뒤 %d개만 남았다' % len(real))
        if any(_is_gk_ko(w) for w in ('하나님', '사람', '말씀')):
            bad.append('평범한 한국어를 음역으로 오판')
        if _is_gk_en('the'):
            bad.append('영어 흔한 낱말을 음역으로 오판')
        if _is_gk_en('riches'):
            bad.append('영어 성경 낱말(riches)을 음역으로 오판')
        # ※ EN 판정은 그리스어 어미 규칙이라 -ma 로 끝나는 것(katakrima)은 원래 못 잡는다.
        #   설계상의 한계이지 결함이 아니다. 잡을 수 있어야 하는 형태로만 검증한다.
        for w in ('logos', 'doulos', 'dikaiosis'):
            if not _is_gk_en(w):
                bad.append('실제 음역(%s)을 못 잡는다' % w)

    # ②-b LAY 절대 기준 3종 — 탐지력 확인 (2026-08-05 신설)
    if lay_cites('그는 형을 믿지 않았습니다(요 7:5). 그러나 달라졌습니다.') != 1:
        bad.append('LAY 절 인용을 못 잡는다')
    if lay_cites('앞 절이 말한 뜻(1:9)을 따릅니다.') != 1:
        bad.append('책 이름 없는 절 인용을 못 잡는다')
    if lay_cites('"내가 이르노니(요 3:16) 그러하다"고 하셨습니다.') != 0:
        bad.append('성경 인용 안의 표기를 위반으로 잡는다 — 인용 보호가 뚫렸다')
    if lay_cites('절 인용이 전혀 없는 평범한 설명 문장입니다.') != 0:
        bad.append('절 인용 오탐')
    #   베낀 글은 신출 어휘비가 낮고, 새로 쓴 글은 높아야 한다
    ex = '하나님은 때와 기한을 주관하시며 왕들을 폐하시고 세우신다. 역사의 주인은 제국이 아니다.'
    if new_word_ratio(ex, '하나님은 때와 기한을 주관하시며 왕들을 폐하시고 세우십니다.') > 0.30:
        bad.append('베낀 글의 신출 어휘비가 높게 나온다')
    if new_word_ratio(ex, '달력을 손에 쥔 분이 따로 계십니다. 왕좌를 올리고 내리는 힘은 궁궐 밖에 있습니다.') < 0.60:
        bad.append('새로 쓴 글의 신출 어휘비가 낮게 나온다')
    #   주제를 지우면 내용 보존이 떨어져야 한다
    if keep_ratio('느부갓네살이 예루살렘을 치고 여호야김을 끌어갔다', '느부갓네살이 예루살렘을 치고 여호야김을 끌어갔습니다') < 0.9:
        bad.append('주제를 지키는 글의 내용 보존이 낮게 나온다')
    if keep_ratio('느부갓네살이 예루살렘을 치고 여호야김을 끌어갔다', '한 왕이 다른 왕을 이겼습니다') > 0.5:
        bad.append('주제를 지운 글의 내용 보존이 높게 나온다 — 삭제를 못 잡는다')

    # ③ 본문 재진술 — 본문을 그대로 옮긴 문장이 임계를 넘는가
    r = conn().execute("SELECT verse_text FROM bible_content WHERE version_code='KRV' "
                       "AND LENGTH(verse_text)>40 LIMIT 1").fetchone()
    if r:
        ref = _norm(r[0])
        if difflib.SequenceMatcher(None, ref, ref).ratio() < TH['VERSEREP']:
            bad.append('재진술 기준 이상')
        if difflib.SequenceMatcher(None, _norm('전혀 다른 설명 문장을 여기 둡니다'), ref).ratio() >= TH['VERSEREP']:
            bad.append('재진술 오탐: 다른 문장을 본문으로 판정')
    else:
        bad.append('KRV 본문 없음 — 재진술 검사 불가')

    # ④ 자기 절 직접 인용 — **양방향**. 잡아야 할 것과 봐줘야 할 것을 함께 고정한다.
    KREF = '이 사람 모세는 온유함이 지면의 모든 사람보다 승하더라'
    if not self_quotes('그런데 이 사람 모세는 온유함이 지면의 모든 사람보다 승하더라 합니다.',
                       KREF, 'KO'):
        bad.append('KO 자기 절 직접 인용을 통과시킨다')
    if self_quotes('스스로를 변호하지 않는 사람이었다고 적습니다.', KREF, 'KO'):
        bad.append('KO 자기 절 인용 오탐: 다시 쓴 문장을 인용으로 본다')
    #   이름 나열은 봐준다 — 안 그러면 명단 장이 통째로 위반이 되어 문턱이 안 지켜진다
    NREF = '고핫의 아들들은 아므람과 이스할과 헤브론과 웃시엘이요'
    if self_quotes('고핫에게서 아므람과 이스할과 헤브론과 웃시엘이 났습니다.', NREF, 'KO'):
        bad.append('이름 나열을 인용으로 잡는다 — 명단 장이 통째로 걸린다')
    SREF = '유다 자손 진기가 그 군대는 암미나답의 아들 나손이 영솔하였고'
    if self_quotes('앞장선 것은 암미나답의 아들 나손이었습니다.', SREF, 'KO'):
        bad.append('「X의 아들 Y」 계보 어법을 인용으로 잡는다')
    EREF = 'We seemed like grasshoppers in our own sight, and so we seemed to them.'
    if not self_quotes('They said they seemed like grasshoppers in our own sight.', EREF, 'EN'):
        bad.append('EN 자기 절 직접 인용을 통과시킨다')
    if self_quotes('Fear had already settled the question for them.', EREF, 'EN'):
        bad.append('EN 자기 절 인용 오탐')

    # ⑤ 줄표 — 잡아야 할 셋과 봐줘야 할 둘
    for s in ('메뚜기 같다 — 여기까지는', 'a name – that you are', '앞의 셋과 다릅니다 - 모으는'):
        if not DASH_RX.search(s):
            bad.append('줄표를 통과시킨다: %s' % s)
    for s in ('출애굽기 12:46 과 같다', 'a five-year-old lamb (Ex. 4:15-16)'):
        if DASH_RX.search(s):
            bad.append('붙임표를 줄표로 잡는다: %s' % s)

    # ④ 요체 — 평서형·물음형 둘 다 잡아야 한다
    if not _is_yoche('그렇게 하신 것이지요.'):
        bad.append('평서 요체 미탐지')
    if not _is_yoche('나는 어느 쪽인가요?'):
        bad.append('물음 요체 미탐지 — 물음표 면제가 되살아났다')
    if not _is_yoche('무엇을 확신할까요?'):
        bad.append('물음 요체(할까요) 미탐지')
    if _is_yoche('나는 어느 쪽입니까?'):
        bad.append('합니까? 를 요체로 오판')
    if _is_yoche('이것은 설명 문장입니다.'):
        bad.append('요체 오탐')
    # 2026-08-04 구약 착수 때 실측으로 드러난 오탐 두 갈래.
    # 탐지기가 성경 인용과 명사를 계속 물어 오면 진짜 위반이 그 소음에 가린다.
    if _is_yoche('암염소가 이백이요 숫염소가 이십이요(32:14).'):
        bad.append('개역한글 고전 연결어미 `~이요` 를 요체로 오판 (성경 인용 훼손 위험)')
    if _is_yoche('유다 지파의 영토가 누릴 농업·목축의 풍요.'):
        bad.append('명사 `풍요` 를 요체로 오판')
    if _is_yoche('이 일에 그의 도움이 필요.'):
        bad.append('명사 `필요` 를 요체로 오판')
    # ↑ 오탐을 막되 동사 활용은 놓치면 안 된다
    if not _is_yoche('이제 아버지의 무덤 앞에 함께 서요.'):
        bad.append('`서요`(서다 해요체) 미탐지 — 명사 예외가 너무 넓다')
    if not _is_yoche('영광은 다른 도시로 옮겨 가요.'):
        bad.append('`가요`(가다 해요체) 미탐지 — 명사 예외가 너무 넓다')
    if not _is_yoche('그것이 이 단락의 중심이에요.'):
        bad.append('`이에요` 미탐지 — `이요` 예외가 너무 넓다')
    if _is_yoche('그가 이르되 "이는 내 아들이요."'):
        bad.append('성경 인용을 요체로 잡음 — 인용 보호가 뚫렸다')
    if _is_yoche('사람이 떡으로만 살 것이 아니요"'):
        bad.append('인용 안에서 잘린 문장을 요체로 잡음')

    # ⑤ 사전
    if '하나님' not in krv_vocab():
        bad.append('KRV 사전 비었음')
    if 'love' not in eng_vocab():
        bad.append('영어 성경 사전 비었음')

    for m in bad:
        print('  X ' + m)
    print('자가 검증 %s' % ('PASS' if not bad else 'FAIL — %d건' % len(bad)))
    return not bad


# ── 진입점 ──────────────────────────────────────────────────────────────────
CHECKS = [('구조·티어', check_structure), ('원어 표기', check_greek),
          ('본문 재진술', check_verserep), ('자기 절 인용', check_selfquote),
          ('줄표', check_dash), ('요체', check_yoche)]


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    a = sys.argv[1:]
    if not a or a[0] in ('-h', '--help'):
        print(__doc__)
        return 0
    if a[0] == '--selftest':
        return 0 if selftest() else 1
    if len(a) < 2:
        print('usage: db_vers_gate.py <bcode> <ch_lo> [ch_hi] [--only NAME] [--inventory]')
        return 2
    bcode, lo = int(a[0]), int(a[1])
    hi = int(a[2]) if len(a) > 2 and a[2].isdigit() else lo
    if '--inventory' in a:
        inventory(bcode, lo, hi)
        return 0
    only = a[a.index('--only') + 1] if '--only' in a else None

    print('bcode %d · %d~%d장' % (bcode, lo, hi))
    verdict = []
    for name, fn in CHECKS:
        if only and only not in name and only not in fn.__name__:
            continue
        out = []
        res = fn(bcode, lo, hi, out)
        mark = {True: 'PASS', False: 'FAIL', None: 'SKIP'}[res]
        print('\n[%s] %s' % (name, mark))
        for line in out:
            print(line)
        verdict.append((name, res))

    fails = [n for n, r in verdict if r is False]
    skips = [n for n, r in verdict if r is None]
    print('\n' + '=' * 60)
    if fails:
        print('GATE: FAIL — %s' % ', '.join(fails))
    elif skips and len(skips) == len(verdict):
        print('GATE: 판정 불가 — 모든 검사가 SKIP (%s)' % ', '.join(skips))
    elif skips:
        print('GATE: PASS (다만 %s 는 SKIP — 그만큼 덜 확인된 것이다)' % ', '.join(skips))
    else:
        print('GATE: PASS')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
