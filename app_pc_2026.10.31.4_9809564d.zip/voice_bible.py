"""
voice_bible.py  —  녹음/재생 엔진 (`--selftest`)

★★ 2026-10-13 (docs/1.txt 74-1 「녹음 오류가 사용자 환경과 관계없이 예방할 수 있는 근본적 방법」) —
  실측 오류 = `PermissionError: 'voices'`(작업 폴더 기준 상대 경로 — 바로가기로 켜면 System32 에 만들려 했다) +
  mp3 가 **바깥 프로그램 ffmpeg.exe** 에 매여 있었다(이 PC·배포 꾸러미 어디에도 없다 → 변환·재생이 조용히 실패).
  막는 자리 다섯 —
  ① **저장 폴더는 쓸 수 있는지 시험해서 고른다**(`voices_root`): 앱 폴더 `voices` → 안 되면 사용자 폴더
     (`%LOCALAPPDATA%\\HagahDabar\\voices`). 작업 폴더와 무관한 **절대 경로**다.
  ② **DB 에는 그 폴더 기준 상대 경로**(`owner/파일`)를 적고 읽을 때 `resolve` 로 푼다 — 폴더를 옮겨도 산다.
     옛 기록(`voices\\…` · 절대 경로)도 그대로 읽는다.
  ③ **mp3 는 soundfile(libsndfile)이 직접 만든다** — 바깥 프로그램이 없다(꾸러미에 이미 실린다). 임시 이름으로 다 쓴 뒤
     다시 읽어 확인하고서야 제 이름을 준다. mp3 를 못 만들면 **WAV 로라도 저장**한다(녹음본을 잃지 않는다).
  ④ 재생도 soundfile 이 직접 읽는다(mp3·wav).
  ⑤ **녹음 전 점검**(`preflight`) — 마이크 · 쓸 수 있는 폴더 · mp3 저장. 화면이 시작 전에 부르고 사람 말로 알린다.

파일 명명 규칙:  {owner}_{version}_{bcode:03d}_{chapter:03d}_{verse:03d}.mp3   (폰에서 온 것은 .ogg — Opus)
저장 폴더:       voices_root()/{owner}/

★★ 2026-10-14 (docs/1.txt 87 — 모바일 녹음 · 사용자 「양쪽에서 주고받더라도, 삭제하더라도 녹음 진척도를 기억해야 한다」)
  · **진척과 파일을 가른다** — 「녹음했다」는 `user_voice_asset` 한 줄이고 파일은 그 줄에 딸린 것이다.
    칸 `has_file`(이 PC 에 파일이 있나) · `origin`(PC|PHONE) · `file_sha` · `phone_has`(폰에 파일이 있나).
    파일을 지워도(`forget_file`) 줄은 남아 진척이 그대로다 — 진척에서 빼는 것은 `delete_voice_record` 뿐(사람이 고른 일).
  · 폰과 주고받는 형식 = **Opus(OGG) 32 kbps 모노**(사용자 확정 · AAC 는 이 PC 장치가 못 만든다) — `to_opus`.
"""
import hashlib
import io
import os
import tempfile
import threading
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf

import appdb

# ── 상수 ─────────────────────────────────────────────────────────────────────

SAMPLERATE   = 44100
CHANNELS     = 1
DTYPE        = "float32"


def _writable(d: Path) -> bool:
    try:
        d.mkdir(parents=True, exist_ok=True)
        fd, p = tempfile.mkstemp(dir=str(d), prefix='.w_')
        os.close(fd)
        os.remove(p)
        return True
    except Exception:
        return False


def _candidates():
    yield Path(appdb.app_path('voices'))
    base = os.environ.get('LOCALAPPDATA') or os.environ.get('APPDATA') or os.path.expanduser('~')
    yield Path(base) / 'HagahDabar' / 'voices'


def voices_root() -> Path:
    """쓸 수 있는 녹음 폴더(절대 경로). 아무 데도 못 쓰면 앱 폴더를 돌려준다(점검이 그 사실을 알린다)."""
    for d in _candidates():
        if _writable(d):
            return d.resolve()
    return Path(appdb.app_path('voices'))


VOICES_ROOT = voices_root()


def resolve(fp) -> Path:
    """DB 에 적힌 경로 → 실제 파일. 상대 경로(`owner/파일` · 옛 `voices\\owner\\파일`)는 녹음 폴더 기준."""
    if not fp:
        return Path('')
    p = Path(str(fp).replace('\\', '/'))
    if p.is_absolute():
        if p.exists():
            return p
        parts = p.parts[-2:]                               # 폴더를 옮겼으면 owner/파일 로 다시 찾는다
        return VOICES_ROOT.joinpath(*parts)
    parts = p.parts[1:] if p.parts and p.parts[0].lower() == 'voices' else p.parts
    for root in [VOICES_ROOT] + [d for d in _candidates()]:
        q = Path(root).joinpath(*parts)
        if q.exists():
            return q
    return VOICES_ROOT.joinpath(*parts)


def rel(path: Path) -> str:
    """녹음 폴더 기준 상대 경로(`owner/파일`) — DB 에 적는 꼴."""
    path = Path(path)
    try:
        return path.resolve().relative_to(VOICES_ROOT).as_posix()
    except Exception:
        return '/'.join(path.parts[-2:])


def mp3_ok() -> bool:
    """이 PC 에서 mp3 를 직접 만들 수 있는가."""
    try:
        return 'MP3' in sf.available_formats()
    except Exception:
        return False


def ffmpeg_available() -> bool:
    """옛 이름(점검 화면) — 이제 바깥 프로그램이 필요 없다. mp3 를 만들 수 있는가와 같다."""
    return mp3_ok()


def input_devices():
    try:
        return [d['name'] for d in sd.query_devices() if d.get('max_input_channels', 0) > 0]
    except Exception:
        return []


def preflight() -> list:
    """녹음 전 점검 → [(열쇠, 막는가)]. 빈 목록이면 문제 없음.
    열쇠 NO_MIC(마이크 없음 · 막음) · NO_WRITE(저장 폴더 없음 · 막음) · NO_MP3(WAV 로 저장 · 알림)."""
    out = []
    if not input_devices():
        out.append(('NO_MIC', True))
    if not _writable(VOICES_ROOT):
        out.append(('NO_WRITE', True))
    if not mp3_ok():
        out.append(('NO_MP3', False))
    return out


# ── 진척 칸(2026-10-14 · 87) ──────────────────────────────────────────────────
VOICE_COLS = (('origin', "TEXT DEFAULT 'PC'"), ('has_file', 'INTEGER DEFAULT 1'),
              ('file_sha', 'TEXT'), ('phone_has', 'INTEGER DEFAULT 0'))
OPUS_RATE = 48000            # Opus 가 받는 표본율(libsndfile — 8/12/16/24/48 kHz)
OPUS_LEVEL = {32: 0.88, 24: 0.93}   # soundfile compression_level → 말소리 kbps(실측 · 2026-10-14)


def ensure_cols(conn):
    """`user_voice_asset` 에 진척 칸을 단다(멱등) · 표가 없으면 만든다."""
    conn.execute("""CREATE TABLE IF NOT EXISTS userdb.user_voice_asset (
        id INTEGER PRIMARY KEY AUTOINCREMENT, verse_id INTEGER NOT NULL, file_type TEXT, file_path TEXT,
        voice_owner TEXT, bible_version TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)""")
    have = {r[1] for r in conn.execute('PRAGMA userdb.table_info(user_voice_asset)')}
    for c, t in VOICE_COLS:
        if c not in have:
            conn.execute('ALTER TABLE userdb.user_voice_asset ADD COLUMN %s %s' % (c, t))


def sha16(path) -> str:
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 16), b''):
            h.update(b)
    return h.hexdigest()[:16]


def to_opus(path, kbps=32) -> bytes:
    """녹음 파일(mp3·wav·ogg) → Opus(OGG) 모노 바이트 — 폰으로 보낼 꼴. 이미 Opus 면 그대로."""
    path = Path(path)
    if path.suffix.lower() == '.ogg':
        return path.read_bytes()
    a, sr = sf.read(str(path), dtype=DTYPE)
    if getattr(a, 'ndim', 1) > 1:
        a = a.mean(axis=1)
    if sr != OPUS_RATE and len(a):
        n = max(1, int(round(len(a) * OPUS_RATE / float(sr))))
        a = np.interp(np.linspace(0, len(a) - 1, n), np.arange(len(a)), a).astype(DTYPE)
    bio = io.BytesIO()
    sf.write(bio, a, OPUS_RATE, format='OGG', subtype='OPUS',
             compression_level=OPUS_LEVEL.get(int(kbps), OPUS_LEVEL[32]))
    return bio.getvalue()


def existing_file(owner, version, verse_id, db_path):
    """그 절의 실제 녹음 파일(mp3 → wav → ogg) · 없으면 None. 기록의 경로가 먼저다."""
    rec = get_voice_record(db_path, verse_id, owner, version)
    if rec and rec[1]:
        p = resolve(rec[1])
        if p.exists():
            return p
    m = voice_path(owner, version, verse_id, db_path)
    for p in (m, m.with_suffix('.wav'), m.with_suffix('.ogg')):
        if p.exists():
            return p
    return None


# ── 파일 경로 계산 ────────────────────────────────────────────────────────────

def voice_path(owner: str, version: str, verse_id: int, db_path: str) -> Path:
    """verse_id → voices_root()/{owner}/{owner}_{version}_{bcode:03d}_{chap:03d}_{verse:03d}.mp3"""
    try:
        with appdb.connect(db_path) as conn:
            row = conn.execute(
                "SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                (verse_id,)
            ).fetchone()
    except Exception:
        row = None
    if not row:
        return VOICES_ROOT / owner / f"{owner}_{version}_{verse_id}.mp3"
    bcode, chap, verse = row
    fname = f"{owner}_{version}_{bcode:03d}_{chap:03d}_{verse:03d}.mp3"
    return VOICES_ROOT / owner / fname


def wav_path(owner: str, version: str, verse_id: int, db_path: str) -> Path:
    mp3 = voice_path(owner, version, verse_id, db_path)
    return mp3.with_suffix(".wav")


# ── 저장 ─────────────────────────────────────────────────────────────────────

def save_take(audio, mp3: Path, samplerate=SAMPLERATE):
    """녹음 한 토막을 저장한다 → (실제 경로, 'MP3'|'WAV'). 못 쓰면 OSError.

    ★ 임시 이름으로 다 쓰고 **다시 읽어 확인한 뒤** 제 이름을 준다 — 반쯤 쓴 파일이 남지 않는다.
    ★ mp3 를 못 만들면 같은 자리에 WAV — 녹음본을 잃지 않는다.
    """
    mp3 = Path(mp3)
    mp3.parent.mkdir(parents=True, exist_ok=True)
    audio = np.asarray(audio, dtype=DTYPE)
    for target, fmt in ((mp3, 'MP3'), (mp3.with_suffix('.wav'), 'WAV')):
        if fmt == 'MP3' and not mp3_ok():
            continue
        tmp = target.with_name(target.stem + '.~part' + target.suffix)
        try:
            sf.write(str(tmp), audio, samplerate, format=fmt)
            if sf.info(str(tmp)).frames <= 0:
                raise OSError('empty')
            os.replace(tmp, target)
            other = mp3.with_suffix('.wav') if fmt == 'MP3' else None
            if other is not None and other.exists():          # 옛 WAV 가 남아 있으면 걷는다
                other.unlink(missing_ok=True)
            return target, fmt
        except Exception:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
    raise OSError('cannot write ' + str(mp3.parent))


def wav_to_mp3(wav: Path, mp3: Path) -> bool:
    """WAV → MP3(바깥 프로그램 없이). 성공하면 WAV 를 지운다."""
    try:
        data, sr = sf.read(str(wav), dtype=DTYPE)
        path, fmt = save_take(data, mp3, sr)
        if fmt == 'MP3':
            Path(wav).unlink(missing_ok=True)
            return True
    except Exception as e:
        print(f"[VoiceBible] mp3 error: {e}")
    return False


# ── DB 헬퍼 ──────────────────────────────────────────────────────────────────

def get_voice_record(db_path: str, verse_id: int, owner: str, version: str):
    """user_voice_asset 행 반환 (없으면 None)."""
    try:
        with appdb.connect(db_path) as conn:
            return conn.execute(
                "SELECT id, file_path FROM user_voice_asset "
                "WHERE verse_id=? AND voice_owner=? AND bible_version=?",
                (verse_id, owner, version)
            ).fetchone()
    except Exception:
        return None


def save_voice_record(db_path: str, verse_id: int, owner: str,
                      version: str, file_path: str, file_type: str = 'MP3',
                      origin: str = 'PC', made_at: str = '', conn=None):
    """INSERT or UPDATE user_voice_asset — 경로는 녹음 폴더 기준 상대 경로로 적는다.
    ★ 87 — 파일이 있으면 `has_file=1`·`file_sha` · 파일 없이(진척만) 적으려면 file_path='' ."""
    fp = ''
    sha = None
    if file_path:
        fp = rel(Path(file_path)) if os.path.isabs(str(file_path)) else str(file_path).replace('\\', '/')
        src = Path(file_path) if os.path.isabs(str(file_path)) and Path(file_path).exists() else resolve(fp)
        try:
            sha = sha16(src)
        except Exception:
            sha = None
    has = 1 if (fp and sha) else 0
    when = made_at or None

    def _do(c):
        ensure_cols(c)
        existing = c.execute(
            "SELECT id FROM user_voice_asset "
            "WHERE verse_id=? AND voice_owner=? AND bible_version=?",
            (verse_id, owner, version)
        ).fetchone()
        if existing:
            if fp:
                c.execute(
                    "UPDATE user_voice_asset SET file_path=?, file_type=?, origin=?, has_file=?, file_sha=?,"
                    " created_at=COALESCE(?, datetime('now')) WHERE id=?",
                    (fp, file_type, origin, has, sha, when, existing[0]))
            return existing[0]
        cur = c.execute(
            "INSERT INTO user_voice_asset "
            "(verse_id, file_type, file_path, voice_owner, bible_version, origin, has_file, file_sha, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, datetime('now')))",
            (verse_id, file_type if fp else None, fp or None, owner, version, origin, has, sha, when))
        return cur.lastrowid
    if conn is not None:
        return _do(conn)
    with appdb.connect(db_path) as c:
        return _do(c)


def forget_file(db_path: str, verse_id: int, owner: str, version: str, conn=None):
    """파일만 지운다 — **진척(기록 줄)은 남는다**(87 · 사용자 「삭제하더라도 진척도를 기억」)."""
    def _do(c):
        ensure_cols(c)
        r = c.execute("SELECT id, file_path FROM user_voice_asset WHERE verse_id=? AND voice_owner=?"
                      " AND bible_version=?", (verse_id, owner, version)).fetchone()
        if not r:
            return False
        if r[1]:
            try:
                resolve(r[1]).unlink(missing_ok=True)
            except Exception:
                pass
        c.execute("UPDATE user_voice_asset SET has_file=0 WHERE id=?", (r[0],))
        return True
    if conn is not None:
        return _do(conn)
    with appdb.connect(db_path) as c:
        return _do(c)


def delete_voice_record(db_path: str, verse_id: int, owner: str, version: str):
    try:
        with appdb.connect(db_path) as conn:
            conn.execute(
                "DELETE FROM user_voice_asset "
                "WHERE verse_id=? AND voice_owner=? AND bible_version=?",
                (verse_id, owner, version)
            )
    except Exception as e:
        print(f"[VoiceBible] DB delete error: {e}")


def get_recorded_verses(db_path: str, owner: str, version: str,
                        bcode: int, chapter: int) -> set:
    """특정 책/장에서 녹음 완료된 verse_id 집합."""
    try:
        with appdb.connect(db_path) as conn:
            # ★ 2026-10-28 (docs/1.txt 1-(3)) 「PC 에서 삭제해도 녹음 표식이 남는다」 — [삭제]는 파일만 지우고 진척 줄을 남긴다(87).
            #   표식 = 지금 파일이 있는 녹음(폰과 같다) · 진척(녹음 진도율)은 줄을 그대로 센다.
            ensure_cols(conn)
            rows = conn.execute(
                "SELECT va.verse_id FROM user_voice_asset va "
                "JOIN bible_index bi ON bi.verse_id=va.verse_id "
                "WHERE va.voice_owner=? AND va.bible_version=? AND COALESCE(va.has_file,1)=1 "
                "AND bi.bcode=? AND bi.chapter=?",
                (owner, version, bcode, chapter)
            ).fetchall()
        return {r[0] for r in rows}
    except Exception:
        return set()


def repair(db_path: str) -> dict:
    """옛 녹음 정리(멱등) — WAV 로 남은 것을 mp3 로 · DB 경로를 상대 경로로 · 파일이 있는데 기록이 없는 mp3 를 기록.
    → {'mp3': n, 'path': n, 'added': n}"""
    out = {'mp3': 0, 'path': 0, 'added': 0}
    try:
        with appdb.connect(db_path) as conn:
            rows = conn.execute("SELECT id, file_path FROM user_voice_asset").fetchall()
            for rid, fp in rows:
                p = resolve(fp)
                ftype = 'MP3'
                if p.suffix.lower() == '.wav' and p.exists() and mp3_ok():
                    if wav_to_mp3(p, p.with_suffix('.mp3')):
                        p = p.with_suffix('.mp3')
                        out['mp3'] += 1
                if p.suffix.lower() == '.wav':
                    ftype = 'WAV'
                new = rel(p)
                if new != fp:
                    conn.execute("UPDATE user_voice_asset SET file_path=?, file_type=? WHERE id=?",
                                 (new, ftype, rid))
                    out['path'] += 1
            have = {resolve(r[1]).name for r in conn.execute("SELECT id, file_path FROM user_voice_asset")}
            for owner_dir in (VOICES_ROOT.iterdir() if VOICES_ROOT.exists() else ()):
                if not owner_dir.is_dir():
                    continue
                for f in owner_dir.glob('*.mp3'):
                    parts = f.stem.split('_')
                    if f.name in have or len(parts) < 5 or '.~part' in f.name:
                        continue
                    try:
                        b, c, v = int(parts[-3]), int(parts[-2]), int(parts[-1])
                    except ValueError:
                        continue
                    r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                                     (b, c, v)).fetchone()
                    if r:
                        conn.execute("INSERT INTO user_voice_asset (verse_id, file_type, file_path, voice_owner, "
                                     "bible_version, created_at) VALUES (?, 'MP3', ?, ?, ?, datetime('now'))",
                                     (r[0], rel(f), owner_dir.name, '_'.join(parts[len(owner_dir.name.split('_')):-3])))
                        out['added'] += 1
    except Exception as e:
        print(f"[VoiceBible] repair error: {e}")
    return out


# ── 녹음 엔진 ─────────────────────────────────────────────────────────────────

class Recorder:
    """단일 구절 녹음 관리자."""

    def __init__(self):
        self._frames: list[np.ndarray] = []
        self._stream = None
        self.is_recording = False
        self._level_cb = None   # 레벨 미터 콜백 (float 0.0~1.0)
        self.last_audio = None  # 마지막 녹음 — 저장에 실패해도 남는다(다시 저장할 수 있게)
        self.level = 0.0        # 지금 소리 크기(0~1) — 소리 스레드가 적고 화면이 읽는다

    def set_level_callback(self, cb):
        self._level_cb = cb

    def start(self):
        """마이크를 연다. 못 열면 예외(화면이 사람 말로 알린다)."""
        if self.is_recording:
            return
        self._frames = []

        # ⚠⚠ 이 함수는 **소리 장치의 스레드**에서 불린다 — 여기서 화면(Tk)을 만지면 앱이 통째로 꺼진다
        #   (2026-10-13 사용자 「연속 녹음을 처음 할 때 앱이 저절로 닫혔다」 — 레벨 미터를 여기서 그리고 있었다).
        #   레벨은 값만 적고, 화면은 자기 스레드에서 그 값을 읽어 그린다(`level`).
        def callback(indata, frames, time, status):
            self._frames.append(indata.copy())
            self.level = min(float(np.abs(indata).mean()) * 6, 1.0)

        self._stream = sd.InputStream(
            samplerate=SAMPLERATE, channels=CHANNELS,
            dtype=DTYPE, callback=callback
        )
        self._stream.start()
        self.is_recording = True

    def stop(self):
        """멈추고 녹음 소리를 돌려준다(없으면 None)."""
        if not self.is_recording:
            return None
        self.is_recording = False
        self.level = 0.0
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            finally:
                self._stream = None
        if self._level_cb:
            self._level_cb(0.0)
        if not self._frames:
            return None
        self.last_audio = np.concatenate(self._frames, axis=0)
        return self.last_audio

    def stop_and_save(self, out: Path) -> bool:
        """옛 이름 — 멈추고 저장. 성공 여부."""
        audio = self.stop()
        if audio is None:
            return False
        save_take(audio, Path(out).with_suffix('.mp3'))
        return True

    def cancel(self):
        self.is_recording = False
        if self._stream:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None
        self._frames = []


# ── 재생 엔진 ─────────────────────────────────────────────────────────────────

class Player:
    """단일/연속 구절 재생기."""

    def __init__(self):
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self.on_verse_start = None  # callback(verse_id)
        self.on_done = None         # callback()

    @property
    def is_playing(self):
        return self._thread is not None and self._thread.is_alive()

    def play_file(self, path: Path):
        """단일 파일 동기 재생 (스레드 내부용) — mp3·wav 를 soundfile 이 직접 읽는다."""
        path = resolve(path) if not Path(path).exists() else Path(path)
        if not path.exists():
            return
        try:
            data, sr = sf.read(str(path), dtype=DTYPE)
            sd.play(data, sr)
            while sd.get_stream().active:
                if self._stop_event.is_set():
                    sd.stop()
                    return
                sd.sleep(50)
        except Exception as e:
            print(f"[VoiceBible] play error: {e}")

    def play_sequence(self, verse_paths: list[tuple[int, Path]],
                      gap_sec: float = 0.0,
                      on_verse_start=None, on_done=None):
        """(verse_id, path) 목록을 순서대로 재생. gap_sec: 구절 간 무음(초)."""
        import time
        self.stop()
        self._stop_event.clear()
        self.on_verse_start = on_verse_start
        self.on_done = on_done

        def _run():
            for i, (vid, path) in enumerate(verse_paths):
                if self._stop_event.is_set():
                    break
                if on_verse_start:
                    on_verse_start(vid)
                self.play_file(path)
                if gap_sec > 0 and i < len(verse_paths) - 1:
                    end_t = time.time() + gap_sec
                    while time.time() < end_t:
                        if self._stop_event.is_set():
                            break
                        time.sleep(0.05)
            if on_done:
                on_done()

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        try:
            sd.stop()
        except Exception:
            pass
        if self._thread:
            self._thread.join(timeout=1)
        self._thread = None
        self._stop_event.clear()


def selftest():
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)
    ck(VOICES_ROOT.is_absolute(), '녹음 폴더 = 절대 경로 %s' % VOICES_ROOT)
    cwd = os.getcwd()
    try:
        os.chdir(os.environ.get('SystemRoot', 'C:/Windows'))
        ck(voices_root() == VOICES_ROOT, '작업 폴더가 바뀌어도 같은 폴더(System32 에서 켠 경우)')
    finally:
        os.chdir(cwd)
    ck(mp3_ok(), 'mp3 를 바깥 프로그램 없이 만든다')
    d = Path(tempfile.mkdtemp())
    audio = (np.sin(np.linspace(0, 900, SAMPLERATE)) * 0.2).astype(DTYPE)
    p, fmt = save_take(audio, d / 'o' / 'o_KJV_001_001_001.mp3')
    ck(fmt == 'MP3' and p.exists() and sf.info(str(p)).frames > 0, '저장 → mp3 · 다시 읽힌다')
    ck(not list((d / 'o').glob('*.~part*')), '반쯤 쓴 파일이 안 남는다')
    data, sr = sf.read(str(p), dtype=DTYPE)
    ck(sr == SAMPLERATE and len(data) > SAMPLERATE * 0.9, '재생용으로 읽힌다(바깥 프로그램 없음)')
    w = d / 'o' / 'w.wav'
    sf.write(str(w), audio, SAMPLERATE)
    ck(wav_to_mp3(w, w.with_suffix('.mp3')) and not w.exists(), '옛 WAV → mp3')
    # 폴더에 쓸 수 없으면 예외로 알린다(조용히 안 넘긴다)
    try:
        save_take(audio, Path('Z:/nonexistent_drive_xx/a.mp3'))
        ck(False, '쓸 수 없는 곳 — 예외')
    except OSError:
        ck(True, '쓸 수 없는 곳 — 예외로 알린다')
    ck(resolve('voices\\OkJoo\\x.mp3') == VOICES_ROOT / 'OkJoo' / 'x.mp3' or resolve('voices\\OkJoo\\x.mp3').name == 'x.mp3',
       '옛 상대 경로(voices\\…)를 읽는다')
    ck(rel(VOICES_ROOT / 'A' / 'b.mp3') == 'A/b.mp3', 'DB 에는 폴더 기준 상대 경로')
    ck(isinstance(preflight(), list), '녹음 전 점검이 돈다 %s' % preflight())
    # ★ 87 — 폰과 주고받는 Opus
    ob = to_opus(p)
    ck(ob[:4] == b'OggS', 'mp3 → Opus(OGG) 로 바뀐다')
    og = VOICES_ROOT / '__selftest__' / '__selftest___KJV_001_001_002.ogg'   # 실제 녹음 폴더 — 끝에 걷는다
    og.parent.mkdir(parents=True, exist_ok=True)
    og.write_bytes(ob)
    x, sr2 = sf.read(str(og), dtype=DTYPE)
    ck(sr2 == OPUS_RATE and abs(len(x) / sr2 - 1.0) < 0.1, 'Opus 를 다시 읽는다(길이 그대로)')
    ck(to_opus(og) == ob, '이미 Opus 면 그대로 보낸다')
    # 진척과 파일 — 임시 개인 DB 에서
    import sqlite3
    mem = sqlite3.connect(':memory:')
    mem.execute("ATTACH ':memory:' AS userdb")
    ensure_cols(mem)
    ensure_cols(mem)
    cols = {r[1] for r in mem.execute('PRAGMA userdb.table_info(user_voice_asset)')}
    ck({'origin', 'has_file', 'file_sha', 'phone_has'} <= cols, '진척 칸이 붙는다(멱등)')
    rid = save_voice_record('', 3, 'o', 'KJV', str(og), 'OPUS', origin='PHONE', conn=mem)
    row = mem.execute('SELECT has_file, origin, file_sha FROM user_voice_asset WHERE id=?', (rid,)).fetchone()
    ck(row[0] == 1 and row[1] == 'PHONE' and row[2] == sha16(og), '파일과 함께 적힌다(출처·sha)')
    ck(forget_file('', 3, 'o', 'KJV', conn=mem) and not og.exists(), '파일만 지운다')
    ck(mem.execute('SELECT has_file FROM user_voice_asset WHERE id=?', (rid,)).fetchone()[0] == 0,
       '★ 파일을 지워도 진척 줄은 남는다')
    save_voice_record('', 4, 'o', 'KJV', '', origin='PHONE', conn=mem)
    ck(mem.execute('SELECT has_file FROM user_voice_asset WHERE verse_id=4').fetchone()[0] == 0,
       '파일 없이 진척만 적을 수 있다')
    import shutil
    shutil.rmtree(VOICES_ROOT / '__selftest__', ignore_errors=True)
    ck(not (VOICES_ROOT / '__selftest__').exists(), '시험 자국 0')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--repair' in sys.argv:
        print(repair(appdb.MAIN_DB))
