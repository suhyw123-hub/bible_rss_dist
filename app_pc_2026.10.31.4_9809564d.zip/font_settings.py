# -*- coding: utf-8 -*-
"""폰트 설정 창 (2026-08-13 · `font.md` 3단계).

★ 두 번째 설계다. 첫 판은 **사용자 반려** — 「팝업 UI 자체가 복잡하다」.
    구역 7개를 세로로 늘어놓고 각각 콤보 5개를 달았더니 **한 화면에 컨트롤이 40개**가 되고
    스크롤까지 생겼다. 「무엇을 테스트해야 할지 모르겠다」는 말이 그 결과였다.

  ⇒ **구역을 늘어놓지 않고 「적용 대상」 콤보 하나로 고른다.**
    화면 크기가 늘 같고 컨트롤이 절반 이하다. 대부분의 사용자는 **크기 하나**만 만진다.

왜 창인가 — 탭이 아니다
    「지원/설정 ▸ 폰트」 탭에 두면 **P1 자리를 차지해 성경 본문을 보면서 조절할 수 없다.**
    실측 레이아웃이 `[P1 | P2]` 위 / `P4` 아래라 P2·P4 는 안 가려지지만 P1 이 가려진다.
    ⇒ 작은 별도 창(모달 아님). 옆으로 치우면 전부 보이고 값을 만질 때마다 실물이 바뀐다.

한 벌만 존재한다
    어디서 열든 같은 창(`_instance`). 위젯이 한 벌뿐이라 중복도 동기화 문제도 없다.
"""

import tkinter as tk
from tkinter import ttk

import theme_font as TF

try:
    import i18n
except Exception:                                   # 단독 실행 대비
    class i18n:                                     # noqa: N801
        @staticmethod
        def t(key, dflt=''):
            return dflt

GEOM_KEY = 'FONT_WIN_GEOM'
BG = '#FAFAFA'


def _C(role, fallback):
    """역할 색 — 팔레트에 없으면 폴백 (§0 하드코딩 금지)."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

# 적용 대상.
# ★ **탭 헤더와 같은 i18n 키를 그대로 쓴다** (2026-08-13 사용자 지시).
#   「사용자는 P1, P4 등이 무엇인지 모른다. 탭 헤더의 이름을 그대로 사용해야 한다.
#    탭 헤더 이름을 바꾸면 이 화면에서도 자동으로 바뀌어야 한다.」
#   ⇒ 화면 이름을 여기에 적지 않는다. 키만 두고 **그릴 때 `i18n.t` 로 조립**한다.
# ⚠ 모듈 레벨에서 `i18n.t` 를 부르면 안 된다 — import 시점에 값이 굳어 언어를 바꿔도
#   안 따라온다(CLAUDE.md §A4). 그래서 `targets()` 함수로 둔다.
_TABS = {
    'bible':  [('TAB_P1_BIBLE', '성경읽기'), ('TAB_P4_COMPARE', '역본 비교'),
               ('TAB_P1_PLAN', '묵상 플랜'), ('TAB_PLAN_WHOLE', '전체묵상/주제묵상'),
               ('TAB_PLAN_DIAG', '회복묵상'),
               # ⚠ 도서묵상 탭은 2026-08-30 에 걷었다 — 도서/설교가 그 자리다.
               ('TAB_PLAN_LENS', '렌즈묵상')],
    'desc':   [('TAB_DESC', '설명'), ('TAB_P4_LINK', '구절 연결'),
               ('TAB_P4_TERMS', '주요용어')],
    'ref':    [('TAB_COMMENTARY', '주석'), ('TAB_INTERNAL', '내부자료'),
               ('TAB_RESEARCH', '연구자료'),
               ('TAB_NOTE', '구절노트'), ('TAB_P4_REF', '자료'),
               ('TAB_P1_DAILY', '최신 콘텐츠'), ('TAB_P1_ANNOUNCE', '공지사항'),
               ('TAB_P1_FEEDBACK', '지원/설정')],
    'book':   [('TAB_P1_READING', '도서/설교')],
    'canvas': [('TAB_P4_LINK', '구절 연결'), ('TAB_P4_GENEAL_M', '메시아 가계도'),
               ('TAB_P4_PILGRIM', '믿음의 발자취')],
}
# 화면 이름으로 셀 수 없는 둘 — 전 화면에 걸린다
_ALL = {'list': ('FS_W_LIST', '모든 화면의 목록과 표'),
        'ui':   ('FS_W_UI', '모든 화면의 라벨 · 버튼 · 탭 이름 · 콤보 · 안내문')}

_NAMES = {
    'base':  ('FS_SC_BASE',  '기본'),
    'bible': ('FS_SC_BIBLE', '성경'),
    'prose': ('FS_SC_PROSE', '문장'),
    'list':  ('FS_SC_LIST',  '목록'),
    'meta':  ('FS_SC_META',  '딸림글'),
    'ui':    ('FS_SC_UI',    'UI'),
}
_WHERE = {
    'base':  ('FS_W_BASE',  '모든 항목에 공통으로 적용됨'),
    'bible': ('FS_W_BIBLE', '성경읽기, 구절단락, 묵상플랜, 역본비교 등'),
    'prose': ('FS_W_PROSE', '설명문, 주석, 도서, 설교, 내부자료, 묵상노트'),
    'list':  ('FS_W_LIST',  '표에 열거된 목록 (성경구절은 성경을 따름)'),
    'meta':  ('FS_W_META',  '절 번호, 출처, 개수, 날짜 등 작은 글자'),
    'ui':    ('FS_W_UI',    '탭 이름, 버튼, 라벨, 콤보'),
}
ROLES = ('base', 'bible', 'prose', 'list', 'meta', 'ui')

# 읽는 글만 줄간격·여백을 갖는다 — 버튼·목록에 문단 간격은 뜻이 없다
READING = ('base', 'bible', 'prose')


def targets():
    """(역할, 이름, 적용되는 곳) — **그릴 때마다 i18n 으로 조립**한다.

    ⚠ 적용되는 곳을 **몇 개만 예시하지 않는다**(사용자 지시). 그 역할에 걸리는 것을
      **전부** 적는다.
    """
    T = i18n.t
    return [(k, T(*_NAMES[k]), T(*_WHERE[k])) for k in ROLES]


SCRIPTS = [('he', '히브리어'), ('el', '헬라어'), ('ar', '아랍어'), ('cop', '콥트어')]

# 값을 넓히는 단추가 콤보보다 낫다 — 한 번 누를 때마다 실물이 바뀌는 것이 보인다.
STEPS = [('size', '크기', 1, 7, 30),
         ('line_gap', '줄간격', 1, 0, 14),
         ('para_gap', '문단간격', 2, 0, 20),
         ('margin', '좌우여백', 5, 0, 60),
         # ★ 읽기 서식 둘 (2026-08-14) — 책 조판이 하는 일이다.
         #   들여쓰기: 문단 첫 줄만 들여써 **문단이 어디서 시작하는지** 보인다.
         #   읽는 폭: 창을 넓혀도 한 줄이 그 이상 길어지지 않는다(0=제한 없음).
         ('first_indent', '들여쓰기', 2, 0, 40),
         ('read_width', '읽는 폭', 5, 0, 120)]


class FontSettingsWindow(tk.Toplevel):

    _instance = None

    @classmethod
    def open(cls, parent, db_path, scope=None, on_change=None):
        w = cls._instance
        if w is not None:
            try:
                if w.winfo_exists():
                    w.deiconify(); w.lift(); w.focus_force()
                    if on_change:
                        w._on_change = on_change
                    if scope:
                        w.select_target(scope)
                    return w
            except Exception:
                pass
        w = cls(parent, db_path, on_change)
        cls._instance = w
        if scope:
            w.select_target(scope)
        return w

    def __init__(self, parent, db_path, on_change=None):
        super().__init__(parent)
        self.db_path = db_path
        self._on_change = on_change
        self._after = None
        self.title(i18n.t('FS_TITLE', '폰트'))
        self.configure(bg=BG)
        self.transient(parent)
        # ⚠ 칸이 여덟이라 좁으면 잘린다 — **넉넉히 잡고 사용자가 늘릴 수 있게** 둔다
        #   (2026-08-13 사용자 지시 「팝업 박스가 작아 보인다」).
        self.resizable(True, True)
        self.minsize(1220, 340)
        self._restore_geom()
        self.protocol('WM_DELETE_WINDOW', self._close)

        pad = dict(padx=12)

        # ★ **여섯 항목의 이름이 첫 화면에 다 드러난다** (2026-08-13 사용자 지시:
        #   「폰트 적용대상 항목의 이름이 명시적으로 첫 화면에 드러나야 한다.
        #     뭔가 클릭하면 대상항목이 나타나는 이전방식은 안된다」).
        #   ⚠ 예전에는 왼쪽 목록에서 **골라야만** 그 항목의 값이 보였다. 이름은 보였지만
        #     값은 하나씩만 보여서, 사용자가 이름을 기준으로 바로 손댈 수 없었다.
        #   ⇒ 한 역할이 한 줄이고, 그 줄에 글꼴·크기가 함께 있다.
        # ★★ **공간을 둘로 나눈다 — 전체 적용 / 선택 적용** (2026-08-13 사용자 설계).
        #   「두 영역을 배타적인 체크박스 개념으로 분리해야 할 것 같다」
        #     · 전체 적용에서 값을 만지면 → 체크가 그쪽으로 가고,
        #       **선택 적용의 모든 값이 자동으로 같아진다**(역할 값을 무시하므로).
        #     · 선택 적용에서 값을 만지면 → 체크가 그쪽으로 가고 **선택 적용만** 작동한다.
        #   ⚠ 모드를 바꿀 때 **역할 값을 지우지 않는다.** 지우면 전체 적용으로 갔다
        #     돌아올 때 공들여 맞춘 값을 잃는다. 무시할 뿐 그대로 둔다.
        self._mode = tk.StringVar(value=TF.get_mode(self.db_path))
        self._row = {}
        self._blocks = {}

        for mode, key, ko, hint in (
                (TF.MODE_ALL, 'FS_MODE_ALL', '전체 적용',
                 '한 벌을 화면 전체에 씁니다. 아래 항목은 이 값을 그대로 따릅니다.'),
                (TF.MODE_EACH, 'FS_MODE_EACH', '선택 적용',
                 '항목마다 따로 정합니다. 전체 적용 값은 쓰이지 않습니다.')):
            blk = tk.Frame(self, bg=BG, highlightthickness=2,
                           highlightbackground=BG)
            blk.pack(fill='both', expand=(mode == TF.MODE_EACH), padx=10,
                     pady=(10 if mode == TF.MODE_ALL else 6, 0))
            self._blocks[mode] = blk
            hd = tk.Frame(blk, bg=BG); hd.pack(fill='x', padx=8, pady=(6, 2))
            tk.Radiobutton(hd, text=i18n.t(key, ko), value=mode,
                           variable=self._mode, bg=BG, font=('', 11, 'bold'),
                           command=self._on_mode).pack(side='left')

            grid = tk.Frame(blk, bg=BG)
            grid.pack(fill='both', expand=True, padx=8, pady=(0, 8))
            # ⚠ 두 영역의 칸 폭이 **같아야** 위아래로 줄이 맞는다
            #   (사용자 지적 「좌우 배치가 흐트러져 있다」).
            for c, w in enumerate((8, 26, 18, 11, 11, 11, 11, 11, 11, 11)):
                grid.grid_columnconfigure(c, minsize=w * 7)
            hdr = (('', ''), ('', ''),
                   ('FS_FAMILY', '글꼴'), ('FS_SIZE', '크기'),
                   ('FS_LINE_GAP', '줄간격'), ('FS_PARA_GAP', '문단간격'),
                   ('FS_MARGIN', '좌우여백'), ('FS_FIRST_INDENT', '들여쓰기'),
                   ('FS_READ_WIDTH', '읽는 폭'), ('FS_COLOR', '글자색'))
            for c, (k2, d2) in enumerate(hdr):
                if d2:
                    tk.Label(grid, text=i18n.t(k2, d2), bg=BG, fg='#999',
                             font=('', 8)).grid(row=0, column=c, sticky='w', padx=2)

            if mode == TF.MODE_EACH:
                # ★ **지우는 단추는 지워질 것 옆에 둔다** (2026-08-13 사용자 지시).
                #   창 맨 아래에 있으니 무엇을 지우는 단추인지 알기 어려웠다.
                # ⚠ 원어(히브리어 등)는 **지우지 않는다** — 역할과 다른 축이라
                #   여기서 함께 날리면 애써 고른 성서 히브리어 폰트를 잃는다.
                self._all_btn = tk.Button(
                    hd, text=i18n.t('FS_RESET_ALL', '선택 적용 값 모두 지우기'),
                    font=('', 8), command=self._reset_all)
                self._all_btn.pack(side='right')

            names = ([('base',)] if mode == TF.MODE_ALL
                     else [(k,) for k in ROLES if k != 'base'])
            for r, (sc, ) in enumerate(names, start=1):
                _t = next(x for x in targets() if x[0] == sc)
                self._row[sc] = self._make_row(grid, r, sc, _t[1], _t[2], mode)

        ttk.Separator(self, orient='horizontal').pack(fill='x', pady=(8, 0), **pad)
        # ── 원어 ────────────────────────────────────────────────────────────
        # ★ **네 문자를 한 줄씩 늘어놓는다** (2026-08-13 사용자 지시
        #   「자동지정한 폰트 이름을 텍스트로 열거해주는 것으로 충분한 것 아닌가?」).
        #   전에는 콤보로 문자를 고르고 **또** 콤보로 폰트를 골라야 해서, 지금 무엇이
        #   쓰이는지 펼쳐 보기 전에는 알 수 없었다.
        # ⚠ **콤보를 없애지는 않는다.** 실측 — 히브리 15개·헬라 55개이고 그 차이가 크다
        #   (Ezra SIL·SBL Hebrew 는 니쿠드가 제자리에 붙고 Arial 은 뭉갠다).
        #   다만 **고를 것이 하나뿐이면 콤보를 잠가** 이름만 보이게 한다(콥트어).
        r2 = tk.Frame(self, bg=BG); r2.pack(fill='x', pady=(6, 2), **pad)
        tk.Label(r2, text=i18n.t('FS_SCRIPT', '원어'), bg=BG,
                 font=('', 11, 'bold')).pack(anchor='w')
        sg = tk.Frame(r2, bg=BG); sg.pack(fill='x', padx=8, pady=(2, 0))
        for c, w in enumerate((8, 36, 22)):
            sg.grid_columnconfigure(c, minsize=w * 7)
        self._sc_rows = {}
        for r, (key, ko) in enumerate(SCRIPTS):
            tk.Label(sg, text=i18n.t('FS_SCRIPT_' + key.upper(), ko), bg=BG,
                     anchor='w', font=('', 10)).grid(row=r, column=0, sticky='w', pady=2)
            auto = tk.Label(sg, text='', bg=BG, fg='#777', anchor='w', font=('', 9))
            auto.grid(row=r, column=1, sticky='w', padx=2)
            cb = ttk.Combobox(sg, state='readonly', width=20)
            cb.grid(row=r, column=2, sticky='w', padx=2)
            cb.bind('<<ComboboxSelected>>', lambda e, k=key: self._on_script_family(k))
            self._sc_rows[key] = {'auto': auto, 'cb': cb}

        r3 = tk.Frame(self, bg=BG); r3.pack(fill='x', pady=(4, 12), **pad)
        tk.Label(r3, text=i18n.t('FS_NOSAVE', '따로 저장하지 않아도 됩니다'),
                 bg=BG, fg='#777', font=('', 8)).pack(side='left')

        # ⚠ 맨 끝에서 부른다 — 이 안에서 원어 콤보(`_sc_pick`)를 읽으므로
        #   위에서 부르면 아직 없다(실제로 그렇게 터졌다).
        self._on_mode(save=False)

        self._load()

    # ── 한 줄 만들기 ──────────────────────────────────────────────────────────
    def _make_row(self, grid, r, sc, name, where, mode):
        """한 역할의 줄. **전체 적용 줄과 선택 적용 줄이 생김새가 같다.**"""
        box = {'mode': mode}
        # ⚠ 이 라벨을 상자에 담아 둔다 — 「가」 버튼이 **어느 줄을 보라**고 표시할 때 쓴다.
        #   담지 않았다가 `select_target` 이 `KeyError: 'name'` 으로 터졌다(2026-08-13).
        nm = tk.Label(grid, text=name, bg=BG, anchor='w',
                      font=('', 10, 'bold' if sc == 'base' else 'normal'))
        nm.grid(row=r, column=0, sticky='w', padx=4, pady=5)
        box['name'] = nm
        tk.Label(grid, text=where, bg=BG, fg='#888', anchor='w',
                 font=('', 8)).grid(row=r, column=1, sticky='w', padx=2)

        fam = ttk.Combobox(grid, state='readonly', width=20)
        fam.grid(row=r, column=2, sticky='w', padx=2)
        fam.bind('<<ComboboxSelected>>', lambda e, k=sc: self._on_family(k))
        box['fam'] = fam

        for c, key in ((3, 'size'), (4, 'line_gap'), (5, 'para_gap'),
                       (6, 'margin'), (7, 'first_indent'), (8, 'read_width')):
            if key != 'size' and sc not in READING:
                continue          # 버튼·목록에 줄·문단 간격은 뜻이 없다
            # ⚠ 칸과 칸 사이를 벌린다 — 붙어 있으면 옆 항목의 ＋를 잘못 누른다
            #   (사용자 지적 「+- 버튼 간격이 너무 좁아서 잘못 클릭할 수 있다」).
            f = tk.Frame(grid, bg=BG)
            f.grid(row=r, column=c, sticky='w', padx=(0, 14))
            tk.Button(f, text='－', width=2, font=('', 8),
                      command=lambda k=key, s2=sc: self._bump(s2, k, -1)).pack(side='left')
            v = tk.Label(f, text='', bg='white', width=3, relief='solid', bd=1,
                         font=('', 9))
            v.pack(side='left', padx=2)
            tk.Button(f, text='＋', width=2, font=('', 8),
                      command=lambda k=key, s2=sc: self._bump(s2, k, 1)).pack(side='left')
            box[key] = v

        # ★ 글자색 (2026-08-14 사용자 지시). **비워 두면 테마 색을 따른다.**
        # ⚠ 앞서 이 칸을 넣으려다 삽입 지점이 안 맞아 **조용히 빠졌다** —
        #   「칸은 만들었지만 팔레트가 없다」가 그래서 났다.
        cf = tk.Frame(grid, bg=BG)
        cf.grid(row=r, column=9, sticky='w', padx=(0, 6))
        # ⚠ 견본이 작으면 **무슨 색인지 안 보이고 누르기도 어렵다**(2026-08-14 지시).
        #   넓이 4배 — `tk` 의 width 는 글자 수라 픽셀로 못 박으려면 틀을 쓴다.
        _box = tk.Frame(cf, width=46, height=22, bd=1, relief='solid')
        _box.pack(side='left')
        _box.pack_propagate(False)
        sw = tk.Label(_box, text='', cursor='hand2')
        sw.pack(fill='both', expand=True)
        # ⚠ 견본은 테마가 칠하면 안 된다 — 고른 색이 딴 색으로 번역돼 보였다
        try:
            import ui_theme as _ut
            setattr(sw, _ut.SAMPLE, True)
            setattr(_box, _ut.SAMPLE, True)
        except Exception:
            pass
        for _w in (_box, sw):
            _w.bind('<Button-1>', lambda e, k=sc: self._pick_color(k))
        tk.Button(cf, text='✕', font=('', 9, 'bold'), bd=1, relief='solid',
                  width=2, cursor='hand2',
                  command=lambda k=sc: self._clear_color(k)).pack(side='left', padx=2)
        box['color'] = sw

        return box

    # ── 모드 ────────────────────────────────────────────────────────────────
    def _on_mode(self, save=True):
        """선택한 영역을 도드라지게. **둘 중 하나만 작동한다.**"""
        m = self._mode.get()
        if save:
            TF.set_mode(self.db_path, m)
        for mode, blk in self._blocks.items():
            on = (mode == m)
            # ⚠⚠ **여기는 창을 지은 뒤 고를 때마다 다시 칠하는 자리다** —
            #   `ui_theme.paint` 가 따라갈 수 없다(칠한 뒤에 색이 바뀐다).
            #   그래서 굳은 색을 쓰면 다크 모드에서 **61자리가 흰 채로 남는다**
            #   (2026-08-30 실측). ⇒ **그릴 때마다 역할을 읽는다**(§0 · §36-5b
            #   Text 태그 색과 같은 문법).
            _on_bg = _C('warning_bg', '#FFF8EE')
            _off_bg = _C('bg', BG)
            _hi = _C('warning', '#E67E22')
            try:
                blk.config(highlightbackground=_hi if on else _off_bg,
                           bg=_on_bg if on else _off_bg)
                for w in blk.winfo_children():
                    self._tint(w, _on_bg if on else _off_bg)
            except Exception:
                pass
        self._load()
        if save:
            self._notify()

    def _tint(self, w, bg):
        try:
            if w.winfo_class() in ('Frame', 'Label', 'Radiobutton'):
                w.config(bg=bg)
        except Exception:
            pass
        for c in w.winfo_children():
            self._tint(c, bg)

    def _switch(self, mode):
        """값을 만진 쪽으로 **체크가 저절로 옮겨간다** (사용자 설계)."""
        if self._mode.get() != mode:
            self._mode.set(mode)
            TF.set_mode(self.db_path, mode)
            self._on_mode(save=False)

    # ── 화면 채우기 ──────────────────────────────────────────────────────────
    def _load(self):
        """여섯 줄을 **한꺼번에** 채운다. 선택한 줄만 채우지 않는다."""
        cfg = TF.load(self.db_path)['font']
        fams = sorted(TF.families())
        for sc, box in self._row.items():
            d = TF.resolve(self.db_path, sc)
            own = (cfg.get(sc) or {}) if TF.get_mode(self.db_path) == TF.MODE_EACH else {}
            # ⚠ 글꼴 칸을 비워 두면 **지금 무슨 글꼴이 쓰이는지 알 수 없다**.
            #   고르지 않은 상태를 「자동」으로 보이고 실제 적용값을 괄호에 붙인다.
            auto = i18n.t('FS_AUTO', '자동 ({f})').format(f=d.get('family') or '기본')
            box['fam']['values'] = [auto] + fams
            box['fam'].set(own.get('family') or auto)
            for key in ('size', 'line_gap', 'para_gap', 'margin',
                        'first_indent', 'read_width'):
                v = box.get(key)
                if v is None:
                    continue
                # 「기본」은 값이 늘 들어 있어 색으로 구분할 것이 없다.
                # 역할에서 **따로 지정한 항목**만 주황으로 보인다.
                mine = (sc != 'base') and (key in own)
                v.config(text=str(d.get(key, '')), fg='#B26A00' if mine else '#333')
            sw = box.get('color')
            if sw is not None:
                own_c = own.get('color') or ''
                # ⚠ 비어 있으면 **테마 색**을 보여 준다 — 「무엇이 쓰이는지」가 보여야 한다
                shown = own_c or self._theme_fg()
                try:
                    sw.config(bg=shown, text='  ' if own_c else ' · ')
                except Exception:
                    pass

            b = box.get('reset')
            if b is not None:
                # ⚠ 이미 기본을 따르는데 [기본으로]가 눌리면 무엇이 달라지는지 알 수 없다.
                b.config(state='normal' if own else 'disabled')
        # [선택 적용 값 지우기] — 선택 적용 모드에서 값이 있을 때만 뜻이 있다
        try:
            self._all_btn.config(
                state='normal' if (TF.get_mode(self.db_path) == TF.MODE_EACH and
                                   any(cfg.get(k) for k in ROLES if k != 'base'))
                else 'disabled')
        except Exception:
            pass
        self._load_script()

    def _load_script(self):
        """원어 네 줄을 채운다 — **자동 지정된 이름을 글자로** 보인다."""
        cfg = (TF.load(self.db_path)['font'].get('script') or {})
        for key, _ko in SCRIPTS:
            row = self._sc_rows[key]
            got = TF.fonts_for(key)
            picked = cfg.get(key, '')
            auto = TF.resolve_family('', key) or '(없음)'
            row['auto'].config(
                text=(i18n.t('FS_SC_PICKED', '고름: {f}').format(f=picked) if picked
                      else i18n.t('FS_SC_AUTO', '자동: {f}').format(f=auto)),
                fg='#B26A00' if picked else '#777')
            row['cb']['values'] = [i18n.t('FS_SC_AUTOONLY', '자동')] + got
            row['cb'].set(picked or i18n.t('FS_SC_AUTOONLY', '자동'))
            # 고를 것이 하나뿐이면 잠근다 (사용자 지시: 「폰트가 하나라면 기본 지정하면 된다」)
            row['cb'].config(state='disabled' if len(got) <= 1 else 'readonly')

    # ── 조작 ─────────────────────────────────────────────────────────────────
    def _on_family(self, scope):
        self._switch(self._row[scope]['mode'])
        v = self._row[scope]['fam'].get()
        TF.save(self.db_path, scope,
                family=None if v.startswith(i18n.t('FS_AUTO', '자동')[:2]) else v)
        if scope == 'base':
            TF.sync_roles(self.db_path)   # 선택 적용 값도 **똑같이** 맞춘다
        self._load(); self._notify()

    def _bump(self, scope, key, sign):
        """한 번 누를 때 **항목마다 알맞은 폭**으로 움직인다.

        ⚠ 전부 1씩 움직이면 좌우여백(0~60)은 60번 눌러야 한다 — `STEPS` 의 폭을 쓴다.
        """
        self._switch(self._row[scope]['mode'])
        d = TF.resolve(self.db_path, scope)
        step, lo, hi = next((st, l, h) for k, _lb, st, l, h in STEPS if k == key)
        TF.save(self.db_path, scope,
                **{key: max(lo, min(hi, int(d.get(key, 0)) + step * sign))})
        if scope == 'base':
            TF.sync_roles(self.db_path)   # 선택 적용 값도 **똑같이** 맞춘다
        self._load(); self._notify()

    def _on_script_family(self, key):
        v = self._sc_rows[key]['cb'].get()
        d = TF.load(self.db_path)
        sc = d['font'].setdefault('script', {})
        if v == i18n.t('FS_SC_AUTOONLY', '자동'):
            sc.pop(key, None)
        else:
            sc[key] = v
        TF._write(self.db_path, d)
        self._load_script(); self._notify()

    def _reset(self, scope):
        """그 역할을 비워 **기본 값을 따르게** 한다.

        ⚠ 이것이 없으면 값이 한 번 들어간 구역은 전체를 바꿔도 따라오지 않는다.
          「일단 통일하고 나중에 개별 수정」이 그 순간 깨진다.
        """
        TF.clear(self.db_path, scope)
        self._load(); self._notify()

    def _theme_fg(self):
        try:
            import ui_theme
            return ui_theme.C('fg')
        except Exception:
            return '#000000'

    def _pick_color(self, scope):
        """글자색을 선택한다. **바탕색은 다루지 않는다** — 그건 테마의 몫이다."""
        from tkinter import colorchooser
        cur = (TF.load(self.db_path)['font'].get(scope) or {}).get('color')             or self._theme_fg()
        got = colorchooser.askcolor(color=cur, parent=self,
                                    title=i18n.t('FS_COLOR', '글자색'))
        if got and got[1]:
            self._switch(self._row[scope]['mode'])
            TF.save(self.db_path, scope, color=got[1])
            if scope == 'base':
                TF.sync_roles(self.db_path)
            self._load(); self._notify()

    def _clear_color(self, scope):
        """색을 비워 **테마 색을 따르게** 한다."""
        TF.save(self.db_path, scope, color=None)
        self._load(); self._notify()

    def _reset_all(self):
        """모든 역할을 비워 **기본 하나만 남긴다.**

        ⚠ 이것이 없으면 「기본만 바꿔도 전체가 따라온다」가 거짓말이 된다 —
          역할에 값이 남아 있는 한 그 역할은 영영 안 따라온다(사용자가 실제로 겪었다).
        """
        for k in ROLES:
            if k != 'base':
                TF.clear(self.db_path, k)
        self._load(); self._notify()

    # ── 알림 ─────────────────────────────────────────────────────────────────
    def _notify(self):
        if self._after:
            try:
                self.after_cancel(self._after)
            except Exception:
                pass
        self._after = self.after(60, self._fire)

    def _fire(self):
        self._after = None
        if callable(self._on_change):
            try:
                self._on_change()
            except Exception:
                pass

    # ── 화면의 「가」 버튼이 부른다 ───────────────────────────────────────────
    def select_target(self, scope):
        """화면의 「가」 버튼이 부른다 — **그 줄을 눈에 띄게** 한다.

        ⚠ 예전에는 목록에서 그 항목을 골랐다. 이제 여섯 줄이 다 보이므로
          고를 것이 없고, 대신 **어느 줄을 보라는 것인지** 잠깐 표시한다.
        """
        scope = TF._scope(scope)
        box = self._row.get(scope)
        if not box:
            return
        lbl = box.get('name')
        if lbl is None:
            return
        # ⚠⚠ **굳은 색을 여기 쓰면 그 위젯이 영영 안 칠해진다** (2026-08-30 실측).
        #   `ui_theme.paint` 는 **처음 본 색을 원본으로 기억**하는데, 그 색이
        #   색→역할 표에 없으면 역할을 못 찾아 건너뛴다. 그러면 잠깐 강조했다
        #   되돌린 뒤에도 그 라벨만 흰 바탕으로 남는다 — 실제로 그랬다.
        #   ⇒ 강조색·되돌릴 색 **둘 다 역할로** 읽는다.
        try:
            lbl.config(bg=_C('warning_bg', '#FFE082'))
            self.after(1200, lambda: lbl.config(bg=_C('bg', BG)))
        except Exception:
            pass

    # ── 창 자리 ──────────────────────────────────────────────────────────────
    def _restore_geom(self):
        g = None
        try:
            c = TF._connect(self.db_path)      # ⚠ sqlite3 직접 X — user_config 는 userdb 에 있다
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (GEOM_KEY,)).fetchone()
            c.close()
            g = r[0] if r else None
        except Exception:
            pass
        if g and '+' in g:
            self.geometry('+' + g.split('+', 1)[1])       # 자리만 기억 (크기는 고정)
        else:
            self.geometry('+120+80')

    def _close(self):
        try:
            c = TF._connect(self.db_path)
            c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                      "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                      (GEOM_KEY, self.geometry()))
            c.commit(); c.close()
        except Exception:
            pass
        type(self)._instance = None
        self.destroy()


def open_font_settings(parent, db_path, scope=None, on_change=None):
    """화면의 「가」 버튼이 부르는 단 하나의 진입점."""
    return FontSettingsWindow.open(parent, db_path, scope, on_change)
