"""db_pilgrim_gplace.py — 순례 장소마다 구글 장소 번호(place_id)를 찾아 둔다 (2026-10-30 신설·영구)

★ 왜 — 폰의 [구글 지도]가 이름(영어)으로 찾으면 흔한 이름은 엉뚱한 곳이 열린다. 장소 번호가 있으면 그 장소 카드
  (사진·영업시간·전화·홈페이지·예약)가 정확히 열린다. 그 정보는 구글의 것이라 **우리는 번호만** 담는다
  (구글 정책상 place_id 는 오래 보관해도 된다 · 그 밖의 내용은 담지 않는다).
★ 찾는 법 — Places API(New) Text Search: 「영어 이름」 + 그 자리 둘레 반경 1km 를 치우침(locationBias)으로 주고
  가장 앞 후보의 자리를 우리 좌표와 견준다. 가까우면(OK_M) 받고, 멀면 사람이 보도록 CHECK 로 둔다(지어내지 않는다).
★ 열쇠 = secret_store 'GPLACES_KEY'(관리자 PC 에만 · 배포 안 됨). 없으면 아무것도 안 하고 그렇다고 말한다.
★ 칸 — sys_pilgrim_site.gplace(번호) · gplace_m(우리 좌표와의 거리 m) · gplace_st(OK · CHECK · NONE)
  · 다시 돌려도 사람이 고친 것(gplace_st='MINE')은 안 덮는다.

  --selftest(가짜 서버) · --find [--limit N] [--redo] · --status · --set <site_id> <place_id>(사람이 정함) · --clear <site_id>
"""
import json
import math
import os
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

import appdb  # noqa: E402

URL = 'https://places.googleapis.com/v1/places:searchText'
FIELDS = 'places.id,places.displayName,places.location'
OK_M = {'ARCH': 700, 'MOUNT': 1500, 'TOMB': 400}   # 유적·산은 넓다 — 그 밖 300m
OK_DEFAULT = 300


def ensure(conn):
    cols = {r[1] for r in conn.execute('PRAGMA table_info(sys_pilgrim_site)')}
    for c, t in (('gplace', 'TEXT'), ('gplace_m', 'INTEGER'), ('gplace_st', 'TEXT')):
        if c not in cols:
            conn.execute('ALTER TABLE sys_pilgrim_site ADD COLUMN %s %s' % (c, t))


def dist_m(la1, lo1, la2, lo2):
    return math.hypot((la2 - la1) * 111000, (lo2 - lo1) * 111000 * math.cos(math.radians((la1 + la2) / 2)))


def _post(key, body, url=URL, timeout=20):
    req = urllib.request.Request(url, data=json.dumps(body).encode('utf-8'), method='POST', headers={
        'Content-Type': 'application/json', 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': FIELDS})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def judge(kind, lat, lng, places):
    """후보 가운데 우리 좌표에 가장 가까운 것 → (place_id, 거리 m, 'OK'|'CHECK'|'NONE')"""
    best = None
    for p in places or []:
        loc = p.get('location') or {}
        if 'latitude' not in loc:
            continue
        d = dist_m(lat, lng, loc['latitude'], loc['longitude'])
        if best is None or d < best[1]:
            best = (p.get('id', ''), d)
    if best is None or not best[0]:
        return '', None, 'NONE'
    return best[0], round(best[1]), 'OK' if best[1] <= OK_M.get(kind, OK_DEFAULT) else 'CHECK'


def find(conn, key=None, limit=None, redo=False, post=None, say=print):
    ensure(conn)
    if key is None:
        import secret_store as SS
        key = (SS.get('GPLACES_KEY') or '').strip()
    if not key:
        say('구글 Places 열쇠가 없습니다 — secret_store 에 GPLACES_KEY 를 담으세요(관리자 PC 에만).')
        return {}
    post = post or (lambda body: _post(key, body))
    q = ("SELECT site_id, kind, lat, lng, names FROM sys_pilgrim_site WHERE status='LIVE' AND COALESCE(same_place,0)=0"
         " AND COALESCE(gplace_st,'')<>'MINE'")
    if not redo:
        q += " AND COALESCE(gplace,'')=''"
    rows = conn.execute(q + ' ORDER BY links DESC, site_id').fetchall()
    if limit:
        rows = rows[:limit]
    cnt = {'OK': 0, 'CHECK': 0, 'NONE': 0, 'ERR': 0}
    for sid, kind, lat, lng, names in rows:
        n = json.loads(names or '{}')
        name = n.get('EN') or next(iter(n.values()), '')
        try:
            res = post({'textQuery': name, 'maxResultCount': 5,
                        'locationBias': {'circle': {'center': {'latitude': lat, 'longitude': lng}, 'radius': 1000.0}}})
        except Exception as e:                                      # noqa: BLE001
            cnt['ERR'] += 1
            say('  ⚠ %s %s — %s' % (sid, name, str(e)[:80]))
            continue
        pid, d, st = judge(kind, lat, lng, res.get('places'))
        if st != 'OK':
            # 치우침만으로는 다른 나라의 같은 이름이 나온다(실측: 멤피스 → 미국 테네시) — 둘레 사각형 안으로 좁혀 한 번 더
            r = 0.06 if kind in ('MOUNT', 'ARCH') else 0.03
            try:
                res2 = post({'textQuery': name, 'maxResultCount': 5, 'locationRestriction': {'rectangle': {
                    'low': {'latitude': lat - r, 'longitude': lng - r}, 'high': {'latitude': lat + r, 'longitude': lng + r}}}})
                p2, d2, s2 = judge(kind, lat, lng, res2.get('places'))
                if p2 and (d is None or d2 < d):
                    pid, d, st = p2, d2, s2
            except Exception:                                          # noqa: BLE001
                pass
        conn.execute('UPDATE sys_pilgrim_site SET gplace=?, gplace_m=?, gplace_st=? WHERE site_id=?', (pid, d, st, sid))
        cnt[st] += 1
        if st != 'OK':
            say('  %s %-40s %s %s' % (st, name[:40], '' if d is None else '%dm' % d, pid))
    conn.commit()
    say('받음 %(OK)d · 사람이 볼 것 %(CHECK)d · 못 찾음 %(NONE)d · 오류 %(ERR)d' % cnt)
    return cnt


def retry(conn, key=None, post=None, say=print):
    """CHECK·NONE 을 다른 검색어로 다시 — ① 영어 이름 + 가까운 거점 도시 ② 그 밖 언어 이름(히브리·아랍·현지)
    ③ 둘레 사각형(±0.02°) 안으로만. 가까운 것이 나오면 OK 로 바꾼다 · 끝내 없으면 그대로(폰은 좌표로 연다)."""
    ensure(conn)
    if key is None:
        import secret_store as SS
        key = (SS.get('GPLACES_KEY') or '').strip()
    if not key:
        say('구글 Places 열쇠가 없습니다.')
        return {}
    post = post or (lambda body: _post(key, body))
    bases = []
    try:
        for code, names, la, lo in conn.execute('SELECT code, names, lat, lng FROM sys_pilgrim_base'):
            bases.append((json.loads(names or '{}').get('EN') or code, la, lo))
    except Exception:                                               # noqa: BLE001
        pass
    rows = conn.execute("SELECT site_id, kind, lat, lng, names, gplace, gplace_m, gplace_st FROM sys_pilgrim_site"
                        " WHERE status='LIVE' AND COALESCE(same_place,0)=0 AND gplace_st IN ('CHECK','NONE')").fetchall()
    fixed = 0
    for sid, kind, lat, lng, names, gp, gm, st in rows:
        n = json.loads(names or '{}')
        en = n.get('EN') or ''
        city = min(bases, key=lambda b: dist_m(lat, lng, b[1], b[2]))[0] if bases else ''
        city = city.split(' (')[0]
        qs = [q for q in ([en + ', ' + city] if en and city else []) +
              [v for k2, v in n.items() if k2 not in ('EN', 'KO') and v and v != en][:3] if q]
        best = (gp, gm if gm is not None else 10 ** 9, st)
        r = 0.02
        for q in qs:
            try:
                res = post({'textQuery': q, 'maxResultCount': 5, 'locationRestriction': {'rectangle': {
                    'low': {'latitude': lat - r, 'longitude': lng - r}, 'high': {'latitude': lat + r, 'longitude': lng + r}}}})
            except Exception:                                       # noqa: BLE001
                continue
            pid, d, s2 = judge(kind, lat, lng, res.get('places'))
            if pid and d is not None and d < best[1]:
                best = (pid, d, s2)
            if best[2] == 'OK':
                break
        if best[2] == 'OK' and st != 'OK':
            fixed += 1
        conn.execute('UPDATE sys_pilgrim_site SET gplace=?, gplace_m=?, gplace_st=? WHERE site_id=?',
                     (best[0], None if best[1] == 10 ** 9 else best[1], best[2], sid))
        say('  %-5s %-34s %s' % (best[2], en[:34], '' if best[1] == 10 ** 9 else '%dm' % best[1]))
    conn.commit()
    say('다시 물어 바로잡음 %d / %d' % (fixed, len(rows)))
    return {'fixed': fixed, 'tried': len(rows)}


def set_mine(conn, site_id, place_id):
    ensure(conn)
    conn.execute("UPDATE sys_pilgrim_site SET gplace=?, gplace_m=NULL, gplace_st=? WHERE site_id=?",
                 (place_id.strip(), 'MINE' if place_id.strip() else '', int(site_id)))
    conn.commit()


def status(conn):
    ensure(conn)
    for st, n in conn.execute("SELECT COALESCE(NULLIF(gplace_st,''),'(아직)'), COUNT(*) FROM sys_pilgrim_site"
                              " WHERE status='LIVE' AND COALESCE(same_place,0)=0 GROUP BY 1"):
        print('%-6s %d' % (st, n))


def selftest():
    import sqlite3
    ok, bad = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(m)
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_pilgrim_site (site_id INTEGER PRIMARY KEY, kind TEXT, lat REAL, lng REAL, names TEXT,"
              " status TEXT, same_place INTEGER, links INTEGER)")
    rows = [(1, 'CHURCH', 31.7784, 35.2298, '{"EN":"Church of the Holy Sepulchre"}'),
            (2, 'CHURCH', 31.7784, 35.2298, '{"EN":"Far Church"}'),
            (3, 'ARCH', 31.7784, 35.2298, '{"EN":"Nothing"}'),
            (4, 'CHURCH', 31.7784, 35.2298, '{"EN":"Mine"}')]
    for r in rows:
        c.execute("INSERT INTO sys_pilgrim_site VALUES(?,?,?,?,?,'LIVE',0,0)", r)
    ensure(c)
    set_mine(c, 4, 'ChIJmine')
    sent = []

    def fake(body):
        sent.append(body)
        n = body['textQuery']
        if n.startswith('Church of'):
            return {'places': [{'id': 'far', 'location': {'latitude': 31.80, 'longitude': 35.23}},
                               {'id': 'ChIJsep', 'location': {'latitude': 31.7785, 'longitude': 35.2297}}]}
        if n == 'Far Church':
            if 'locationRestriction' in body:
                return {'places': [{'id': 'ChIJnear', 'location': {'latitude': 31.7786, 'longitude': 35.2298}}]}
            return {'places': [{'id': 'ChIJfar', 'location': {'latitude': 31.79, 'longitude': 35.2298}}]}
        return {'places': []}
    cnt = find(c, key='x', post=fake, say=lambda *_: None)
    g = {r[0]: r[1:] for r in c.execute('SELECT site_id, gplace, gplace_st, gplace_m FROM sys_pilgrim_site')}
    ck(g[1][:2] == ('ChIJsep', 'OK'), '가장 가까운 후보를 받는다 %s' % (g[1],))
    ck(g[2][:2] == ('ChIJnear', 'OK'), '멀면 둘레 안으로 좁혀 다시 묻고 가까운 것을 받는다 %s' % (g[2],))
    ck(g[3][:2] == ('', 'NONE'), '없으면 NONE · 지어내지 않는다')
    ck(g[4][:2] == ('ChIJmine', 'MINE'), '사람이 정한 것은 안 건드린다')
    ck(len([b for b in sent if 'locationBias' in b]) == 3, '사람이 정한 것은 묻지도 않는다 · 자리 치우침')
    ck(cnt == {'OK': 2, 'CHECK': 0, 'NONE': 1, 'ERR': 0}, '셈 %s' % cnt)
    sent.clear()
    find(c, key='x', post=fake, say=lambda *_: None)
    ck(len([b for b in sent if 'locationBias' in b]) == 1, '다시 돌리면 번호가 빈 것(NONE)만 다시 묻는다 — CHECK 는 사람이 본다')
    ck(find(c, key='', say=lambda *_: None) == {}, '열쇠가 없으면 아무것도 안 한다')
    ck(judge('ARCH', 31.0, 35.0, [{'id': 'a', 'location': {'latitude': 31.005, 'longitude': 35.0}}])[2] == 'OK', '유적은 700m 까지')
    for m in bad:
        print('FAIL', m)
    print('db_pilgrim_gplace %d/%d %s' % (ok, ok + len(bad), 'PASS' if not bad else 'FAIL'))
    return not bad


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    if '--find' in a:
        lim = int(a[a.index('--limit') + 1]) if '--limit' in a else None
        find(c, limit=lim, redo='--redo' in a)
    elif '--retry' in a:
        retry(c)
    elif '--set' in a:
        i = a.index('--set')
        set_mine(c, a[i + 1], a[i + 2])
    elif '--clear' in a:
        set_mine(c, a[a.index('--clear') + 1], '')
    else:
        status(c)
