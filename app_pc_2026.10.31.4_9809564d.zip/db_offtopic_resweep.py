# -*- coding: utf-8 -*-
"""db_offtopic_resweep.py — 관련성 필터를 **지금 규칙**으로 다시 걸어, 담기지 말았어야 할
미승인 영상을 삭제 보관함으로 내린다(영구 도구 · 2026-09-16).

왜 — 미승인 점검(2026-09-16)에서 관련성 낱말(주일예배·새벽기도회·ccm …)이 든 영상 6,119편
가운데 **용어 이름(은혜·하나님·마음·사랑·기도·예수 …)이 앵커로 쳐져 통과한 것이 1,960편**이었고
그 승인률은 8%(좌표로 통과한 것은 43%)였다. 그래서 문지기의 앵커를 **좌표·곡 이름**으로 좁혔다
(`media_intake.screen`). 이 도구는 **이미 담긴 것**에 같은 규칙을 걸어 정리한다.

규칙
· 대상 = LIVE · 미승인(is_active=0) · 휴면 아님 · **승인된 것은 절대 안 건드린다**.
· 문지기와 **같은 문**(`media_intake.screen`)을 쓴다 — 여기서 다시 짜지 않는다(§237차 ③).
  등록 채널 영상은 `domain='CHANNEL'` — **관련성 필터를 아예 안 거친다**(2026-09-16 저녁 ·
  제로 베이스 재검토), 찬양·성경듣기로 담긴 것은 WORSHIP, 나머지는 기본 판정.
· 지우지 않는다 — `record_status='HIDE'` + description `swept='OFFTOPIC_RESWEEP:날짜'`.
  삭제 보관함(④ 연결심사)에서 [복원]되고, `--undo` 가 한꺼번에 되돌린다(§222차).
· 사람이 이은 연결(`MANUAL`)이 있는 영상은 건드리지 않는다 — 사람이 본 것이다.

쓰는 법
  python db_offtopic_resweep.py --selftest
  python db_offtopic_resweep.py --scan            # 무엇이 걸리나(낱말·채널별) — 아무것도 안 바꾼다
  python db_offtopic_resweep.py --apply
  python db_offtopic_resweep.py --undo
"""
import sys, json, sqlite3, collections
from datetime import date

try:
    import appdb
except Exception:
    appdb = None

TAG = 'OFFTOPIC_RESWEEP'


def _rows(conn):
    """대상 미승인 영상 — (media_id, title, lang, description dict)."""
    out = []
    for mid, t, lang, d, mt in conn.execute(
            "SELECT media_id, title, lang_code, description, COALESCE(media_type,'') FROM sys_media_asset"
            " WHERE COALESCE(record_status,'LIVE')='LIVE' AND is_active=0"
            "   AND description LIKE '{%'"):
        try:
            j = json.loads(d)
        except Exception:
            continue
        out.append((mid, t or '', lang, j, mt))
    return out


def _manual_ids(conn):
    try:
        return {r[0] for r in conn.execute(
            "SELECT DISTINCT clicked_id FROM sys_link_asset WHERE link_type IN ('MEDI_VERS','MEDI_ENTI')"
            "   AND COALESCE(confidence,'')='MANUAL'")}
    except Exception:
        return set()


def _registered(conn):
    ids, names = set(), set()
    try:
        for e, n in conn.execute("SELECT channel_ext_id, channel_name FROM sys_media_channel"
                                 " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            if e:
                ids.add(e)
            if n:
                names.add(n.strip().lower())
    except Exception:
        pass
    return ids, names


def _dormant_ids(conn):
    try:
        import db_media_linkcheck as LC
        return {r[0] for r in conn.execute(
            "SELECT a.media_id FROM sys_media_asset a WHERE NOT (%s)" % LC.not_dormant('a'))}
    except Exception:
        return set()


def scan(conn, screen_fn=None):
    """지금 규칙으로 걸리는 미승인 영상 → [(media_id, why, channel, title)] · 낱말 분포."""
    import media_intake as MI
    gate = MI.Gate(conn) if screen_fn is None else None
    reg_ids, reg_names = _registered(conn)
    manual = _manual_ids(conn)
    dormant = _dormant_ids(conn)
    hits = []
    for mid, title, lang, j, mt in _rows(conn):
        if mid in manual or mid in dormant:
            continue
        cid = (j.get('channel_id') or '').strip()
        ch = (j.get('channel') or '').strip()
        reg = (cid and cid in reg_ids) or (ch.lower() in reg_names)
        row = {'title': title, 'url': '', 'lang_code': lang, 'channel': ch, 'channel_id': cid,
               'yt_desc': j.get('yt_desc') or ''}
        # 담을 때의 의도대로 판정한다 — 등록 채널은 CHANNEL, 찬양·성경듣기로 담긴 것은 WORSHIP
        #   (찬양 한 바퀴가 그 분야로 담았다 — 「worship song」·「choir」 면제가 들어야 한다).
        #   ⚠ 안 그러면 찬양 검색어로 담은 정당한 찬양이 여기서 통째로 걸린다(첫 미리보기 115편).
        dom = 'CHANNEL' if reg else ('WORSHIP' if mt in ('WORSHIP', 'READING') else None)
        try:
            act = screen_fn(row, dom) if screen_fn else MI.screen(gate, row, domain=dom)
        except Exception:
            act = None
        if act == MI.SKIP_OFFTOPIC:
            why = ''
            try:
                import media_exclude as MX
                why = MX.match_offtopic('%s\n%s' % (title, (j.get('yt_desc') or '')[:600]),
                                        has_anchor=False, kw_list=MX.kw_for(gate.off_kw if gate else MX.get_offtopic_map(), lang),
                                        lang=lang, domain=dom,
                                        dmap=getattr(gate, 'off_domain', None)) or ''
            except Exception:
                why = ''
            hits.append((mid, why, ch, title))
    return hits


def apply(conn, dry=False, screen_fn=None, today=None):
    today = today or date.today().isoformat()
    hits = scan(conn, screen_fn)
    if not dry:
        for mid, why, _ch, _t in hits:
            d = conn.execute("SELECT description FROM sys_media_asset WHERE media_id=?", (mid,)).fetchone()
            try:
                j = json.loads(d[0]) if d and d[0] else {}
            except Exception:
                j = {}
            j['swept'] = '%s:%s' % (TAG, today)
            j['offtopic_kw'] = why
            conn.execute("UPDATE sys_media_asset SET record_status='HIDE', description=? WHERE media_id=?",
                         (json.dumps(j, ensure_ascii=False), mid))
        conn.commit()
    words = collections.Counter(w for _m, w, _c, _t in hits)
    chans = collections.Counter(c for _m, _w, c, _t in hits)
    return {'n': len(hits), 'words': words, 'channels': chans, 'hits': hits}


def undo(conn):
    n = 0
    for mid, d in conn.execute("SELECT media_id, description FROM sys_media_asset"
                               " WHERE description LIKE ?", ('%"swept": "' + TAG + ':%',)).fetchall():
        try:
            j = json.loads(d)
        except Exception:
            continue
        if not str(j.get('swept', '')).startswith(TAG):
            continue
        j.pop('swept', None); j.pop('offtopic_kw', None)
        conn.execute("UPDATE sys_media_asset SET record_status='LIVE', description=? WHERE media_id=?",
                     (json.dumps(j, ensure_ascii=False), mid))
        n += 1
    conn.commit()
    return n


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT, lang_code TEXT, media_type TEXT,
        description TEXT, is_active INTEGER, record_status TEXT DEFAULT 'LIVE', last_checked TEXT, fail_count INT);
      CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY, channel_ext_id TEXT, channel_name TEXT, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_link_asset(clicked_id INT, link_type TEXT, confidence TEXT);
      INSERT INTO sys_media_channel(channel_ext_id, channel_name) VALUES('UCREG','등록교회');
    """)
    def add(mid, title, ch, act, cid='', manual=False):
        c.execute("INSERT INTO " + "sys_media_asset(media_id,title,lang_code,description,is_active) VALUES(?,?,?,?,?)",
                  (mid, title, 'KO', json.dumps({'channel': ch, 'channel_id': cid, 'yt_desc': ''}), act))
        if manual:
            c.execute("INSERT INTO sys_link_asset VALUES(?,?,?)", (mid, 'MEDI_VERS', 'MANUAL'))
    add(1, '2026년 5월 3일 주일예배', '동네교회', 0)          # 걸린다
    add(2, '주일예배 창세기 1:1 설교', '동네교회', 0)          # 좌표 — 안 걸린다(문지기가 통과시킨다)
    add(3, '2026년 5월 3일 주일예배', '동네교회', 1)          # 승인 — 안 건드린다
    add(4, 'CCM 플레이리스트', '등록교회', 0, 'UCREG')        # 등록 채널 — 찬양 면제 낱말 → 안 걸린다
    add(5, 'CCM 플레이리스트', '딴채널', 0)                  # 미등록 — 걸린다
    add(6, '2026년 5월 10일 주일예배', '동네교회', 0, manual=True)   # 사람이 이은 것 — 안 건드린다
    add(7, 'CCM 플레이리스트 2', '찬양채널', 0)                       # 찬양으로 담긴 것 — 면제
    c.execute("UPDATE sys_media_asset SET media_type='WORSHIP' WHERE media_id=7")
    c.commit()
    # 문지기 대역 — 실제 규칙과 같은 결(좌표 통과 · CHANNEL 은 찬양 면제)
    import media_intake as MI
    def fake_screen(row, dom):
        title = row['title']
        if '창세기 1:1' in title:
            return None
        if dom == 'CHANNEL':
            return None                      # 등록 채널은 안 묻는다(2026-09-16)
        words = ['주일예배', 'ccm']
        if dom == 'WORSHIP':
            words = [w for w in words if w != 'ccm']
        return MI.SKIP_OFFTOPIC if any(w in title.lower() for w in words) else None
    r = apply(c, dry=True, screen_fn=fake_screen)
    t('★ 미리보기 — 걸리는 것 = 1·5 (좌표 2 · 승인 3 · 등록채널 CCM 4 · 사람 연결 6 · 찬양 CCM 7 은 제외)',
      sorted(h[0] for h in r['hits']) == [1, 5], [h[0] for h in r['hits']])
    t('  미리보기는 아무것도 안 바꾼다', c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE record_status='HIDE'").fetchone()[0] == 0)
    r = apply(c, screen_fn=fake_screen, today='2026-09-16')
    t('★ 적용 — 둘을 보관함으로 · 표식', r['n'] == 2 and c.execute(
        "SELECT COUNT(*) FROM sys_media_asset WHERE record_status='HIDE' AND description LIKE '%OFFTOPIC_RESWEEP:2026-09-16%'").fetchone()[0] == 2)
    t('  승인된 3번은 그대로 LIVE·승인', c.execute("SELECT record_status, is_active FROM sys_media_asset WHERE media_id=3").fetchone() == ('LIVE', 1))
    t('  두 번 돌려도 안 는다', apply(c, screen_fn=fake_screen)['n'] == 0)
    n = undo(c)
    t('★ 되돌림 — 둘 다 LIVE · 표식 0', n == 2 and c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE record_status='HIDE'").fetchone()[0] == 0
      and c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE description LIKE '%swept%'").fetchone()[0] == 0)
    print('db_offtopic_resweep selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return 0 if not ok[1] else 1


def main(argv):
    if '--selftest' in argv:
        return selftest()
    conn = appdb.connect('bible_master.db') if appdb else sqlite3.connect('bible_master.db')
    conn.execute("PRAGMA busy_timeout=30000")
    if '--undo' in argv:
        print('되돌림 %d편' % undo(conn))
        return 0
    dry = '--apply' not in argv
    r = apply(conn, dry=dry)
    print('%s — 걸리는 미승인 영상 %d편' % ('미리보기' if dry else '적용', r['n']))
    print('  낱말별:', r['words'].most_common(15))
    print('  채널별:', r['channels'].most_common(12))
    if dry:
        print('  실제로 내리려면 --apply · 되돌리려면 --undo')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
