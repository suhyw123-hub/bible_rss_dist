# -*- coding: utf-8 -*-
"""내 연구/설교노트(`user_ref_asset`)의 **유형 · 출처** 단일 소스 (2026-10-16 · docs/1.txt 2-2).

사용자 지시 — 「유형은 **내용**에 따라서 분류하자. 나머지 유형은 제거하라 · 연구(study) = 연구자료 AI 도우미 결과 저장장소 ·
설교(sermon) = 설교작성 AI 도우미 결과 저장장소 · 참고자료(reference) · **출처분류를 별도 값**으로 — 내가 작성 / AI 작성 /
외부수집(URL·출처·지은이)」. AI 로 쓰고 사람이 고친 글은 **출처 = AI 작성 + 「수정함」**(`ai_edited`) — 사실·인용을
확인해야 한다는 필요는 고친 뒤에도 남기 때문이다(조금 고쳤다고 AI 표시가 사라지면 안 된다).

  유형(ref_type)   STUDY 연구 · SERMON 설교 · REFERENCE 참고자료
  출처(ref_origin) MINE 내가 작성 · AI AI 작성 · WEB 외부 수집
  수정함(ai_edited) 1 = AI 가 쓴 글을 사람이 고쳐 저장했다

★ 옛 유형(NOTE·ARTICLE·BLOG·WEB·YOUTUBE·BOOK·COMMENTARY·OTHER·AI)은 `normalize` 가 셋으로 접는다 —
  읽는 쪽도 이 문을 지나므로 옛 행이 남아 있어도 화면은 셋만 본다. `migrate` 가 DB 를 한 번 고친다(멱등).
⚠ 유형·출처 이름을 화면마다 적지 말 것 — `kind_label`·`origin_label` 한 문.
"""
import sys

KINDS = ('STUDY', 'SERMON', 'REFERENCE')
ORIGINS = ('MINE', 'AI', 'WEB')

_KIND_KO = {'STUDY': '연구', 'SERMON': '설교', 'REFERENCE': '참고자료'}
_ORIGIN_KO = {'MINE': '내가 작성', 'AI': 'AI 작성', 'WEB': '외부 수집'}

#: 옛 유형 → (새 유형, 그 행이 따로 출처를 말하지 않을 때의 출처)
_OLD = {
    'STUDY': ('STUDY', 'MINE'),
    'NOTE': ('STUDY', 'MINE'),
    'SERMON': ('SERMON', 'MINE'),
    'AI': ('STUDY', 'AI'),
    'REFERENCE': ('REFERENCE', 'MINE'),
    'ARTICLE': ('REFERENCE', 'WEB'),
    'BLOG': ('REFERENCE', 'WEB'),
    'WEB': ('REFERENCE', 'WEB'),
    'YOUTUBE': ('REFERENCE', 'WEB'),
    'BOOK': ('REFERENCE', 'MINE'),
    'COMMENTARY': ('REFERENCE', 'MINE'),
    'OTHER': ('REFERENCE', 'MINE'),
}


def normalize(ref_type, origin=None, url=''):
    """옛·새 유형 무엇이든 → (유형, 출처). 출처가 이미 적혀 있으면 그것이 이긴다."""
    k, o = _OLD.get(str(ref_type or '').upper(), ('STUDY', 'MINE'))
    if origin in ORIGINS:
        o = origin
    elif o == 'MINE' and (url or '').strip() and k == 'REFERENCE':
        o = 'WEB'
    return k, o


def kind_label(k):
    import i18n
    k = normalize(k)[0]
    return i18n.t('REFK_' + k, _KIND_KO[k])


def origin_label(o, edited=False):
    import i18n
    o = o if o in ORIGINS else 'MINE'
    s = i18n.t('REFO_' + o, _ORIGIN_KO[o])
    if o == 'AI' and edited:
        s += ' · ' + i18n.t('REFO_EDITED', '수정함')
    return s


def ensure(conn):
    """칸 둘을 붙인다(없을 때만)."""
    cols = {r[1] for r in conn.execute('PRAGMA userdb.table_info(user_ref_asset)')}
    if not cols:
        return
    if 'ref_origin' not in cols:
        conn.execute("ALTER TABLE userdb.user_ref_asset ADD COLUMN ref_origin TEXT")
    if 'ai_edited' not in cols:
        conn.execute("ALTER TABLE userdb.user_ref_asset ADD COLUMN ai_edited INTEGER DEFAULT 0")


def migrate(conn):
    """옛 유형을 셋으로 · 출처 칸을 채운다(멱등 — 이미 새 값이면 그대로) → 고친 줄 수."""
    ensure(conn)
    n = 0
    for rid, rt, og, url in conn.execute(
            'SELECT ref_id, ref_type, ref_origin, url FROM userdb.user_ref_asset').fetchall():
        k, o = normalize(rt, og, url)
        if (rt, og) != (k, o):
            conn.execute('UPDATE userdb.user_ref_asset SET ref_type=?, ref_origin=? WHERE ref_id=?', (k, o, rid))
            n += 1
    conn.commit()
    return n


def selftest():
    fails = []

    def ck(c, m):
        if not c:
            fails.append(m)
    ck(normalize('AI') == ('STUDY', 'AI'), 'AI → 연구·AI')
    ck(normalize('NOTE') == ('STUDY', 'MINE'), 'NOTE → 연구·내가')
    ck(normalize('SERMON') == ('SERMON', 'MINE'), '설교 그대로')
    ck(normalize('WEB') == ('REFERENCE', 'WEB'), '웹 → 참고·외부')
    ck(normalize('OTHER', url='https://x') == ('REFERENCE', 'WEB'), '주소가 있으면 외부')
    ck(normalize('SERMON', 'AI') == ('SERMON', 'AI'), '적힌 출처가 이긴다')
    ck(normalize('') == ('STUDY', 'MINE'), '빈 값')
    ck(all(normalize(k)[0] == k for k in KINDS), '새 값 멱등')
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    c.execute('CREATE TABLE userdb.user_ref_asset(ref_id INTEGER PRIMARY KEY, ref_type TEXT, url TEXT)')
    c.executemany('INSERT INTO userdb.user_ref_asset(ref_type,url) VALUES(?,?)',
                  [('AI', ''), ('BLOG', 'https://a'), ('STUDY', '')])
    ck(migrate(c) == 3, '처음엔 셋을 고친다')
    ck(migrate(c) == 0, '두 번째는 0(멱등)')
    ck(c.execute('SELECT ref_type, ref_origin FROM userdb.user_ref_asset ORDER BY ref_id').fetchall()
       == [('STUDY', 'AI'), ('REFERENCE', 'WEB'), ('STUDY', 'MINE')], '옮긴 값')
    print('selftest', 'OK' if not fails else 'FAIL', '%d' % (11 - len(fails)) + '/11', fails)
    return not fails


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--migrate' in sys.argv:
        import appdb
        print('migrated', migrate(appdb.connect()))
