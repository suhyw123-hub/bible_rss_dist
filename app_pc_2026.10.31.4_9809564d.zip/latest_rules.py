# -*- coding: utf-8 -*-
"""latest_rules.py — **최신 콘텐츠 발행 규칙과 점검** (2026-09-06 신설·영구).

★★★ 왜 (사용자 지시):
  「실제로 사용자들에게 표시되는 목록이 어떤 것인지 **관리자가 알 수 있어야
   한다**」 · 「자동배포 시점 이전에 관리자가 모니터링해서 **제외할 것을
   지정**하면 좋겠지. **제외하는 룰엔진**을 만들면 더 좋을 것이다」.

★★ **실측이 그 필요를 증명했다**(2026-09-06 서버의 실제 발행본):
  · `youtube_KO.tsv` 200행의 게시일이 **2023-05-03 · 2022-10-15 · 2023-01-11**
    — 「최신 유튜브」에 **3년 전 영상**이 나가고 있다.
  · 원인은 발행 문이 `ORDER BY media_id DESC`(**저장 순서**)라 「최신」이
    「늦게 담은 것」을 뜻했기 때문이다.
  · 마지막 발행이 **2026-06-14**(items 06-17) — **석 달째 멈춰 있었다.**

★ **거르는 자리는 발행하는 문 하나다** — 화면이 따로 거르면 「보이는 것과
  나가는 것」이 갈린다. `rss_publish` 가 이 모듈을 부르고, 관리자 화면은
  **같은 문**을 불러 미리 본다.

⚠ **자동으로 안 지운다** — 거르는 것은 「최신 목록에 안 싣는다」일 뿐이고
  자산(`sys_media_asset`)은 그대로다. 승인 취소(`is_active=0`)와 **다른 축**:
    · 승인 취소 = 이 영상을 **어디에서도** 안 보인다
    · 여기서 제외 = 구절·용어 연결로는 계속 보이되 **「최신」에는 안 낸다**

    python latest_rules.py --selftest     (의무)
    python latest_rules.py --rules        지금 규칙
    python latest_rules.py --audit        정합성 점검
    python latest_rules.py --preview yt   지금 만들면 나갈 목록(쿼터 0)
"""
import io
import json
import sys
from datetime import datetime, timedelta

# ★ 2026-10-24 창이 있을 때만(pythonw 에서는 [WinError 6] — db_linkpack_build 와 같은 흠)
if sys.stdout is not None and sys.stdout is sys.__stdout__:
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')

CFG_KEY = 'LATEST_PUBLISH_RULES'

#: 기본 규칙. ⚠ **값을 바꾸면 다음 발행부터 먹는다** — 이미 나간 것은 그대로다.
def title_kw_map(rules):
    """`title_kw` → **언어 버킷 dict**. 옛 평면 목록도 받는다.

    ⚠ 옛 저장값(평면 목록)을 그대로 쓰면 그 낱말이 **모든 언어에** 걸린다.
      그것이 옛 동작이므로 `'*'`(언어 무관)으로 옮긴다 — 뜻이 같다.
    """
    v = (rules or {}).get('title_kw')
    if isinstance(v, dict):
        return {str(k).upper() if k != '*' else '*': list(x or [])
                for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return {'*': [k for k in v if k]}
    return {}


def _kw_for(kw_map, lang):
    """그 언어에 걸리는 낱말. **`media_exclude` 문법을 그대로 쓴다.**"""
    try:
        import media_exclude as ME
        return ME.kw_for(kw_map, (lang or '').upper() or None)
    except Exception:
        out = []
        for x in (kw_map or {}).values():
            out.extend(x or [])
        return out


DEFAULT = {
    # ★★★ **게시일이 이보다 오래된 것은 「최신」이 아니다**. 0 이면 안 거른다.
    #   ⚠⚠ 2026-09-12 사용자 「최신 컨텐츠는 **말 그대로 최신**이어야 한다.
    #     오늘로부터 1주일, 1개월 이내의 데이터만 표시되어야 한다」 ⇒ **30**.
    #   ✅ 실측이 30을 받쳤다 — 7일로 좁히면 **KO 274 · EN 13 · 그 밖 4편**
    #     이라 아홉 언어가 통째로 빈다(§0-1). 30일이면 KO 5,420 · EN 3,277.
    'max_age_days': 30,
    # ★ 게시일을 모르는 것 — 최신 목록에서는 자리를 정할 수 없다.
    'drop_no_date': True,
    'exclude_channels': [],      # 사이트/채널 이름 (정확히 일치)
    'exclude_urls': [],          # 개별 주소
    # ★★★ **제목어 제외 — 언어 버킷** (2026-09-06 사용자 0.txt 9번
    #   「제외대상 키워드 입력공간에 **다국어 모드로 입력**하려면 별도
    #   탭화면처럼 크게 구성해야 한다」).
    #   ⚠ 옛 값은 **평면 목록**이었다 — 한 낱말이 열한 언어에 다 걸려
    #     오탐이 났다(§203차 「아홉 언어에서 한 번도 안 걸렸다」의 뒷면).
    #   ⇒ `{'*': [...], 'KO': [...]}` — 판정은 **`'*'` ∪ 그 언어**.
    #   ⚠ **낱말표 문법은 `media_exclude` 것을 그대로 쓴다**(`kw_for`) —
    #     여기서 다시 짜면 두 벌이 되어 한쪽만 고쳐진다.
    'title_kw': {},
    # ★★★ **제외후보 낱말을 여기서도 쓴다**(2026-09-06 사용자 4번 물음
    #   「키워드규칙 탭에 등록된 단어중 **제외후보와는 관계가 없는가**?」).
    #   ⚠ 그전에는 **채널만 공유하고 낱말은 안 봤다** — 수집 문지기가 생기기
    #     전에 담긴 것이 그대로 최신 목록으로 나갔다(실측 140건 · 승인 91건).
    #   ★ **막는 문이 둘이라 값이 있다** — 수집 문지기는 「담을까」를 그때
    #     한 번 보고, 이 규칙은 **나갈 때마다** 본다. 규칙을 고치면 이미
    #     담긴 것에도 곧 먹는다.
    #   ⚠ `media_exclude` 를 부르므로 **언어 축을 그대로 탄다**(그 영상의
    #     lang_code + 언어무관). 여기서 낱말을 다시 적지 않는다 — 두 벌이 된다.
    'use_exclude_kw': True,
    # ★ 같은 채널이 **똑같은 제목**으로 여러 개 올린 것 — 1·2·3부 실황류.
    #   ⚠⚠ **날짜만 다른 시리즈를 묶지 않는다** — 실측으로 그 위험을 봤다.
    #     숫자·괄호를 지우고 견주니 「9.4 새벽기도회」와 「9.1 새벽기도회」가
    #     한 덩이가 됐다(**서로 다른 날의 다른 설교다**). 그래서 **정규화한
    #     제목이 완전히 같을 때만** 묶는다 — 실측 200행 중 **3행**.
    'dedupe_title': True,
    # ★ 한 채널이 목록을 독차지하지 않게. **0 = 안 쓴다**(기본).
    #   ⚠ 실측 지금 최대가 13/200(6%)이라 급하지 않다. 다만 GOODTV 가 하루에
    #     12개를 올리므로, 하루 수집량이 늘면 이 값이 필요해진다.
    'max_per_channel': 0,
    # ★★★ **언어마다 몇 개까지 보일까**(2026-09-12 사용자 「**언어별 30개**를
    #   초과하는 날짜 이전의 데이터는 **삭제하는 것이 아니라** 최신 목록에서
    #   **표시되지 않도록** 하라」). 0 = 안 쓴다.
    #   ★ 「30일」과 **둘 다** 건다 — 30일 안이라도 31번째부터는 안 보이고,
    #     30개가 안 차도 30일이 넘으면 안 보인다. **자산은 그대로 산다.**
    'max_per_lang': 30,
    # ★★★ **등록 채널의 것만 싣는다** (2026-09-06 사용자 확정 — 「최신컨텐츠는
    #   구절/용어와 관련이 없어도 **기독교와 관계만 있어도 충분**하다.
    #   **기독교 무관 사이트만 제거**하면 된다」).
    #   ⚠⚠ 승인(`is_active=1`)을 기다리지 않기로 했으므로 **무엇이 기독교
    #     자료인가를 채널이 말한다** — 관리자가 고른 등록 채널 126곳이 곧
    #     그 판정이다. 이 문을 끄면 아무 데서 온 것이나 나갈 수 있다.
    #   ⚠ 텍스트(items)는 애초에 **등록 피드에서만** 긁으므로 저절로 만족한다.
    'registered_only': True,
}


def get_rules(conn):
    try:
        r = conn.execute("SELECT config_val FROM sys_config"
                         " WHERE config_key=?", (CFG_KEY,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except Exception:
        d = {}
    out = dict(DEFAULT)
    if isinstance(d, dict):
        out.update({k: v for k, v in d.items() if k in DEFAULT})
    return out


def set_rules(conn, d):
    keep = {k: d[k] for k in DEFAULT if k in d}
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val)"
                 " VALUES(?,?)", (CFG_KEY, json.dumps(keep, ensure_ascii=False)))
    conn.commit()


def _date_of(row):
    """게시일 → `YYYY-MM-DD` 또는 ''.

    ⚠ 발행본에는 ISO(`2026-06-13T04:00:00+00:00`)와 날짜만(`2023-05-03`)이
      섞여 있다(실측) — 앞 10글자만 본다.
    """
    p = (row.get('published') or '').strip()
    return p[:10] if len(p) >= 10 and p[4] == '-' else ''


def blocked_names(conn):
    """**구절·용어 수집기에서 제외로 등록한 채널** (2026-09-06 사용자 지시
    「구절용어 수집기에서 **제거대상으로 등록한 채널은 최신컨텐츠에서도
    제거**해야 한다」).

    ★ 목록의 집은 `media_exclude.excluded_channels` 하나다(표
      `sys_media_excluded_channel`). 여기서 다시 읽으면 두 벌이 되고,
      **오늘 그 두 벌 때문에 제외가 한 번도 안 걸리고 있던 것**을 잡았다.
    ⚠⚠ **`db_media_crawler` 를 부르면 안 된다** — 그 순간 수집기 전체가
      사용자 앱 폐포로 딸려 들어온다(실측 4파일 38자리).
    """
    try:
        import media_exclude as MX
        return MX.excluded_channels(conn)
    except Exception:
        return set()


def _exclude_map():
    """제외후보 낱말 → `{언어: [...]}`. 못 읽으면 None(그 규칙을 안 쓴다).

    ⚠ **여기서 낱말을 적지 않는다** — 집은 `media_exclude` 하나다. 베끼면
      수집 문지기와 최신 발행이 서로 다른 말로 거르게 된다.
    """
    try:
        import media_exclude as MX
        return MX.get_exclude_map()
    except Exception:
        return None


def _excluded(title, lang, kw_map):
    """제목에 다른 교파·타종교 낱말이 있나 → 걸린 낱말 또는 None."""
    if not kw_map:
        return None
    try:
        import media_exclude as MX
        return MX.match_exclude(title, kw_list=kw_map, lang=(lang or None))
    except Exception:
        return None


def _chan_map():
    """채널 거르는 말 → `{언어: [...]}`. 못 읽으면 None.

    ⚠⚠ **한 번만 읽는다** — 그전에는 `_chan_kw` 가 줄마다 `get_channel_kw`
      를 불러 **행 수만큼 DB 를 다시 열었다**. 담긴 것이 늘자 미리보기가
      몇 분씩 걸렸다(2026-09-12 실측으로 잡았다).
    """
    try:
        import media_exclude as MX
        return MX.get_channel_map()
    except Exception:
        return None


def _chan_kw(title, site, lang, kw_map=None):
    """채널 거르는 말(이단·타종교 단체) — 제목+채널 이름. **수집기와 같은 문**
    (`media_exclude.match_channel`). 사용자 지시 2026-09-09 「최신 컨텐츠 필터
    규칙도 동일하게 적용해야 한다」.

    ⚠ `kw_map` 을 주면 그것을 쓴다 — 안 주면 옛 동작대로 DB 를 읽는다.
    """
    try:
        import media_exclude as MX
        txt = '%s\n%s' % (site or '', title or '')
        if kw_map is not None:
            return MX.match_channel(txt, kw_list=MX.kw_for(kw_map, (lang or '').upper() or None),
                                    lang=(lang or None))
        return MX.match_channel(txt, lang=(lang or None))
    except Exception:
        return None


def _blocked(name, block):
    """대소문자·공백을 안 따지고 견준다 — **수집기와 같은 문**을 쓴다."""
    try:
        import media_exclude as MX
        return MX.chan_excluded(name, block)
    except Exception:
        return False


def registered_names(conn):
    """등록 채널 이름 집합 — 「기독교 자료인가」의 판정 근거.

    ⚠ 이름으로 견준다(발행 rows 에 채널 번호가 없다). 채널 이름이 바뀌면
      옛 수집분이 잠깐 안 실릴 수 있다 — 그때는 규칙을 끄거나 이름을 맞춘다.
    """
    out = set()
    try:
        out |= {r[0].strip() for r in conn.execute(
            "SELECT channel_name FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'") if r[0]}
    except Exception:
        pass
    # ★ 2026-10-22 텍스트 글(뉴스·묵상)은 관리자가 등록한 RSS 피드가 곧 등록 채널이다 — 유튜브 이름표만 보던 탓에
    #   등록한 뉴스 피드(한국어 7곳 포함)가 「등록 채널이 아닙니다」로 전부 빠졌다(573건 중 543건).
    try:
        out |= {r[0].strip() for r in conn.execute(
            "SELECT site_name FROM sys_rss_feed WHERE record_status='LIVE'") if r[0]}
    except Exception:
        pass
    return out


def apply(rows, rules, today=None, allow_sites=None,
          block_sites=None):
    """규칙을 걸어 (남긴 것, [(행, 왜)]) 로 가른다. **행을 안 고친다.**

    `allow_sites` — `registered_only` 일 때 실을 채널·사이트 이름 집합.
      ⚠ **비어 있으면 그 규칙을 안 쓴다** — 목록을 못 읽었는데 전부 빼면
        최신 콘텐츠가 통째로 비고, 그것이 못 거르는 것보다 나쁘다.
    `block_sites` — **수집 제외로 등록한 채널**(`sys_media_excluded_channel`).
      ★ 이것은 **언제나 이긴다** — 규칙을 꺼도, 등록 채널이어도 뺀다.
        관리자가 「이 채널은 안 쓴다」고 정한 것이기 때문이다.
    """
    today = today or datetime.now()
    keep, drop = [], []
    allow = set(allow_sites or ())
    block = set(block_sites or ())
    cutoff = ''
    if rules.get('max_age_days'):
        cutoff = (today - timedelta(days=int(rules['max_age_days']))
                  ).strftime('%Y-%m-%d')
    exch = set(rules.get('exclude_channels') or [])
    exurl = set(rules.get('exclude_urls') or [])
    kw_map = title_kw_map(rules)
    use_ex = bool(rules.get('use_exclude_kw', True))
    ex_map = _exclude_map() if use_ex else None
    ch_map = _chan_map()          # ⚠ **한 번만** 읽는다(위 경고)
    for r in rows:
        u = (r.get('item_url') or '').strip()
        site = (r.get('site_name') or '').strip()
        title = (r.get('title') or '')
        # ⚠ **그 행의 언어로 고른다** — 한 낱말을 모든 언어에 걸면 오탐이
        #   난다(§203차). 언어를 모르면 전부 본다(`kw_for` 규칙).
        kws = _kw_for(kw_map, (r.get('lang_code') or r.get('lang') or ''))
        d = _date_of(r)
        why = None
        if _blocked(site, block):
            # ★★ **수집 제외 채널은 규칙보다 앞선다** — 끄고 켤 수 없다.
            why = '수집 제외로 등록한 채널입니다: %s' % site
        elif _chan_kw(title, site, r.get('lang_code') or r.get('lang'), ch_map):
            # ★★★ 이단·타종교 단체 표기 — 이것도 규칙보다 앞선다(끌 수 없다)
            why = ('이단·타종교 단체 표기가 있습니다: %s'
                   % _chan_kw(title, site, r.get('lang_code') or r.get('lang'), ch_map))
        elif u and u in exurl:
            why = '이 주소를 뺐습니다'
        elif (rules.get('registered_only') and allow and site
              and site not in allow):
            why = '등록 채널이 아닙니다: %s' % site
        elif site and site in exch:
            why = '채널을 뺐습니다: %s' % site
        elif kws and any(k in title for k in kws):
            why = '제목에 걸렀습니다: %s' % next(k for k in kws if k in title)
        elif use_ex and _excluded(title, r.get('lang'), ex_map):
            why = ('다른 교파·타종교 낱말이 있습니다: %s'
                   % _excluded(title, r.get('lang'), ex_map))
        elif not d and rules.get('drop_no_date'):
            why = '게시일을 모릅니다'
        elif cutoff and d and d < cutoff:
            why = '오래됐습니다: %s (기준 %s)' % (d, cutoff)
        (drop if why else keep).append((r, why) if why else r)

    # ── 자리다툼 규칙은 **남은 것들 사이**에서 판정한다 ──────────────
    #   ⚠ 게시일 내림차순으로 세운 뒤에 자른다 — 안 그러면 「어느 것을
    #     남길까」가 목록 순서에 따라 달라진다.
    if rules.get('dedupe_title') or rules.get('max_per_channel'):
        keep = sort_rows(keep)
        seen_t, per_ch, kept2 = set(), {}, []
        cap = int(rules.get('max_per_channel') or 0)
        for r in keep:
            site = (r.get('site_name') or '').strip()
            if rules.get('dedupe_title'):
                # ★ **완전히 같은 제목**만 묶는다(공백·대소문자만 눌러서).
                tk = (site, ' '.join((r.get('title') or '').lower().split()))
                if tk[1] and tk in seen_t:
                    drop.append((r, '같은 제목이 이미 있습니다'))
                    continue
                seen_t.add(tk)
            if cap and site:
                n = per_ch.get(site, 0)
                if n >= cap:
                    drop.append((r, '한 채널 상한 %d개를 넘었습니다: %s'
                                 % (cap, site)))
                    continue
                per_ch[site] = n + 1
            kept2.append(r)
        keep = kept2
    # ★★★ **언어별 상한은 맨 끝에** — 다른 규칙이 걸러 낸 뒤라야 「남은 것
    #   가운데 최신 30개」가 된다. 먼저 자르면 걸러진 자리가 안 채워진다.
    if rules.get('max_per_lang'):
        before = len(keep)
        keep = cap_by_lang(keep, rules['max_per_lang'])
        if len(keep) < before:
            drop.append(({'title': '(언어별 상한)', 'site_name': '', 'lang': ''},
                         '언어별 %d개를 넘어 안 보입니다: %d행'
                         % (int(rules['max_per_lang']), before - len(keep))))
    return keep, drop


def cap_by_lang(rows, n):
    """**언어마다 최신 n개까지만** 남긴다 → 남은 행.

    ★ 사용자 지시(2026-09-12) — 「언어별 30개를 초과하는 날짜 이전의 데이터는
      **삭제하는 것이 아니라** 표시되지 않도록」. 그래서 여기는 **보이는 것을
      고르는 자리**이고 자산은 건드리지 않는다.
    ⚠ **자르기 전에 게시일로 세운다** — 안 그러면 「최신 30개」가 아니라
      「아무 30개」가 된다.
    """
    if not n:
        return rows
    out, per = [], {}
    for r in sort_rows(rows):
        lang = (r.get('lang_code') or r.get('lang') or '?').upper()
        k = per.get(lang, 0)
        if k >= int(n):
            continue
        per[lang] = k + 1
        out.append(r)
    return out


def sort_rows(rows):
    """**게시일 내림차순** — 「최신」은 게시일이지 저장 순서가 아니다.

    ⚠ 그전에는 `ORDER BY media_id DESC`(저장 순서)였다. 그래서 오래된 영상을
      늦게 담으면 그것이 맨 위에 섰다(실측 3년 전 영상이 1·2·3위).
    """
    return sorted(rows, key=lambda r: (_date_of(r), r.get('collected') or ''),
                  reverse=True)


# ── 정합성 점검 ──────────────────────────────────────────────────
def audit(conn, today=None):
    """관리자가 볼 점검 항목 → [{code, level, n, what, fix}].

    ⚠ **판정(문제)과 사실(참고)을 가른다**(§192차) — 사실을 빨갛게 칠하면
      늘 빨개서 아무도 안 본다.
    """
    today = today or datetime.now()
    out = []

    def add(code, level, n, what, fix):
        out.append({'code': code, 'level': level, 'n': n,
                    'what': what, 'fix': fix})

    # ① 채널 주소 — 사용자 지시 「수집하지 못했다면 데이터 정합성에 문제」
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"
            "   AND COALESCE(channel_url,'')=''").fetchone()[0]
        add('CHAN_NO_URL', 'WARN' if n else 'OK', n,
            '채널 주소가 빈 등록 채널',
            '채널 ID 가 있으면 youtube.com/channel/<ID> 로 채울 수 있습니다.'
            ' 수집 자체는 채널 ID 로 하므로 멈추지는 않습니다.')
    except Exception:
        pass
    # ② 채널 ID 가 UC 꼴이 아니다 — 이것은 **수집이 멈춘다**
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"
            "   AND COALESCE(enabled,1)=1"
            "   AND channel_ext_id NOT LIKE 'UC%'").fetchone()[0]
        add('CHAN_BAD_ID', 'BLOCK' if n else 'OK', n,
            '채널 ID 가 UC 꼴이 아닌 채널',
            '이 채널은 RSS 도 API 도 못 읽습니다(§194차 400 오류).'
            ' 자동크롤러에서 채널을 다시 등록하세요.')
    except Exception:
        pass
    # ③ 승인 영상인데 게시일을 모른다 — 최신 목록에 자리를 못 정한다
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_media_asset"
            " WHERE is_active=1 AND COALESCE(record_status,'LIVE')='LIVE'"
            "   AND COALESCE(json_extract(description,'$.published'),'')=''"
        ).fetchone()[0]
        add('YT_NO_DATE', 'WARN' if n else 'OK', n,
            '게시일을 모르는 승인 영상',
            'RSS 수집기는 게시일을 함께 담습니다'
            '(`db_yt_rss_collect`). 옛 수집분은 비어 있을 수 있습니다.')
    except Exception:
        pass
    # ④ 승인 영상인데 설명문이 없다 — 구간·용어를 되살릴 재료가 없다
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_media_asset"
            " WHERE is_active=1 AND COALESCE(record_status,'LIVE')='LIVE'"
            "   AND COALESCE(json_extract(description,'$.yt_desc'),'')=''"
        ).fetchone()[0]
        add('YT_NO_DESC', 'INFO', n, '설명문이 없는 승인 영상',
            '제목에 좌표가 없으면 되살릴 재료가 없습니다.'
            ' RSS 수집기가 전문을 담습니다.')
    except Exception:
        pass
    # ⑤ 텍스트 피드 — 죽은 피드
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_rss_feed"
            " WHERE COALESCE(is_active,1)=1"
            "   AND COALESCE(last_error,'')<>''").fetchone()[0]
        add('FEED_ERR', 'WARN' if n else 'OK', n, '마지막 수집이 실패한 피드',
            '최신 텍스트 수집기 ▸ 사이트 관리 에서 주소를 확인하세요.')
    except Exception:
        pass
    return out


# ── 미리보기(발행 문을 그대로 부른다) ─────────────────────────────
def preview(conn, kind, limit=200, per_feed=20):
    """**지금 만들면 나갈 목록** → (남긴 것, 걸러진 것, 메모).

    ★ `rss_publish` 의 수집 문을 **그대로** 부른다 — 화면이 자기 SQL 을 쓰면
      「보이는 것과 나가는 것」이 갈린다.
    ⚠ 텍스트(items)는 **피드를 실시간으로 긁는다**(DB 에 없다) — 느리다.
    """
    import rss_publish as P
    note = ''
    # ⚠ **날 것으로 받는다**(`apply_rules=False`) — 여기서 다시 걸러야
    #   「무엇이 왜 빠졌는지」를 화면이 보일 수 있다.
    if kind == 'yt':
        rows = P._collect_youtube_rows(conn, limit, apply_rules=False)
    else:
        rows, fetched, failed = P._collect_item_rows(
            conn, per_feed, apply_rules=False)
        note = '피드 %d개 읽음 · 실패 %d개' % (fetched, failed)
    keep, drop = apply(rows, get_rules(conn),
                       allow_sites=registered_names(conn),
                       block_sites=blocked_names(conn))
    # ⚠ **발행과 똑같이 자른다** — 안 자르면 화면이 실제보다 많이 보인다.
    # ⚠ 언어별 상한이 이미 걸렸으므로 **전역으로 다시 자르지 않는다** —
    #   자르면 한국어가 다른 언어를 밀어낸다(그 자리를 오늘 실측으로 잡았다).
    keep = sort_rows(keep)
    if kind == 'yt' and not get_rules(conn).get('max_per_lang'):
        keep = keep[:int(limit)]
    return keep, drop, note


# ── selftest ─────────────────────────────────────────────────────
def _selftest_lang_cap(t):
    """★★★ **언어별 상한**(2026-09-12 사용자 「언어별 30개를 초과하는 날짜
    이전의 데이터는 **삭제하는 것이 아니라** 표시되지 않도록」)."""
    rows = []
    for i in range(5):
        rows.append({'title': 'ko%d' % i, 'item_url': 'u_ko%d' % i,
                     'site_name': 's', 'lang': 'KO',
                     'published': '2026-09-%02d' % (10 - i)})
    for i in range(2):
        rows.append({'title': 'en%d' % i, 'item_url': 'u_en%d' % i,
                     'site_name': 's', 'lang': 'EN',
                     'published': '2026-09-%02d' % (10 - i)})
    got = cap_by_lang(rows, 3)
    t('언어마다 따로 센다', len(got) == 5)
    t('한국어는 3개까지', sum(1 for r in got if r['lang'] == 'KO') == 3)
    t('영어는 2개 그대로', sum(1 for r in got if r['lang'] == 'EN') == 2)
    t('★ 남는 것은 **최신** 쪽이다',
      {r['item_url'] for r in got if r['lang'] == 'KO'}
      == {'u_ko0', 'u_ko1', 'u_ko2'})
    t('0 이면 안 자른다', len(cap_by_lang(rows, 0)) == len(rows))
    # ⚠ **자산을 안 건드린다** — 고르기만 한다
    t('원래 목록이 그대로다', len(rows) == 7)
    # 규칙으로 걸어도 같은가
    r = dict(DEFAULT)
    r.update({'max_age_days': 0, 'drop_no_date': False, 'registered_only': False,
              'use_exclude_kw': False, 'dedupe_title': False, 'max_per_lang': 3})
    keep, drop = apply(rows, r)
    t('규칙으로도 언어별 3개', len(keep) == 5)
    t('걸린 것을 까닭으로 적는다',
      any('언어별' in w for _x, w in drop))


def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[1] += 1
        ok[0] += 1 if c else 0
        print('  %s %-50s %s' % ('OK  ' if c else 'FAIL', n, e))

    print('=== latest_rules selftest')
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    c.commit()

    # ── 제목어 제외 — 언어 버킷 (0.txt 9번 · 2026-09-06) ────────
    t('★ 옛 평면 목록은 공통(*)으로 읽는다',
      title_kw_map({'title_kw': ['광고']}) == {'*': ['광고']})
    t('★ 버킷은 그대로', title_kw_map({'title_kw': {'KO': ['광고']}}) == {'KO': ['광고']})
    _mk = {'KO': ['광고'], 'EN': ['ad'], '*': ['x']}
    t('★ KO 행은 KO+공통만 본다', sorted(_kw_for(_mk, 'KO')) == ['x', '광고'])
    t('★ 언어를 모르면 전부 본다', len(_kw_for(_mk, '')) == 3)
    _rows = [{'title': '광고 영상', 'lang_code': 'KO', 'item_url': 'u1',
              'site_name': 's', 'published_at': '2026-09-01'},
             {'title': '광고 영상 EN', 'lang_code': 'EN', 'item_url': 'u3',
              'site_name': 's', 'published_at': '2026-09-01'}]
    _R = dict(DEFAULT, title_kw={'KO': ['광고']}, registered_only=False,
              use_exclude_kw=False, drop_no_date=False)
    _k, _d = apply(_rows, _R)
    # ⚠⚠ **이것이 언어 축의 요점이다** — 그전에는 한 낱말이 모든 언어에
    #   걸려 EN 행까지 함께 빠졌다(§203차 「아홉 언어」의 뒷면).
    t('★★ EN 행은 KO 낱말에 안 걸린다', len(_k) == 1 and len(_d) == 1)

    r = get_rules(c)
    t('★ 규칙이 없으면 기본값', r == DEFAULT, r.get('max_age_days'))
    set_rules(c, {'max_age_days': 30, 'exclude_channels': ['나쁜채널'],
                  'zzz': 1})
    r2 = get_rules(c)
    t('★ 저장하고 다시 읽는다', r2['max_age_days'] == 30
      and r2['exclude_channels'] == ['나쁜채널'])
    t('  모르는 열쇠는 안 담는다', 'zzz' not in r2)
    t('  안 적은 열쇠는 기본값이 남는다', r2['drop_no_date'] is True)

    NOW = datetime(2026, 9, 6)
    rows = [
        {'title': '오늘 것', 'item_url': 'u1', 'site_name': '좋은채널',
         'published': '2026-09-05'},
        {'title': '3년 전', 'item_url': 'u2', 'site_name': '좋은채널',
         'published': '2023-05-03'},
        {'title': '날짜 없음', 'item_url': 'u3', 'site_name': '좋은채널',
         'published': ''},
        {'title': '나쁜 채널', 'item_url': 'u4', 'site_name': '나쁜채널',
         'published': '2026-09-01'},
        {'title': '어제 것', 'item_url': 'u5', 'site_name': '좋은채널',
         'published': '2026-09-04T10:00:00+00:00'},
        {'title': '대속죄일의 의미 ▶ 하나님의교회 세계복음선교협회', 'item_url': 'u6',
         'site_name': 'Church of God TUBE', 'lang_code': 'KO', 'published': '2026-09-05'},
    ]
    keep, drop = apply(rows, get_rules(c), NOW)
    t('★★★ 이단 단체 표기는 최신 발행에서도 뺀다(2026-09-09 사용자 지시)',
      not any(x['item_url'] == 'u6' for x in keep)
      and any(x[0]['item_url'] == 'u6' and '이단' in x[1] for x in drop))
    rows = rows[:-1]
    keep, drop = apply(rows, get_rules(c), NOW)
    kt = [x['title'] for x in keep]
    t('★★★ **오래된 것을 뺀다**(실측 3년 전 영상이 최신으로 나갔다)',
      '3년 전' not in kt, kt)
    t('★★ 게시일을 모르는 것을 뺀다', '날짜 없음' not in kt)
    t('★★ 뺀 채널을 뺀다', '나쁜 채널' not in kt)
    t('  남는 것은 둘', kt == ['오늘 것', '어제 것'] or set(kt) ==
      {'오늘 것', '어제 것'}, kt)
    t('★★ **왜 뺐는지 함께 낸다**(§0-1 조용히 버리지 않는다)',
      len(drop) == 3 and all(w for _r, w in drop),
      [w for _r, w in drop])
    t('  ISO 꼴 날짜도 읽는다', _date_of(rows[4]) == '2026-09-04')

    srt = sort_rows(rows)
    t('★★★ **게시일 내림차순**(저장 순서가 아니다)',
      [x['title'] for x in srt][:2] == ['오늘 것', '어제 것'],
      [x['title'] for x in srt])

    set_rules(c, {'max_age_days': 0, 'drop_no_date': False,
                  'dedupe_title': False})
    keep2, drop2 = apply(rows, get_rules(c), NOW)
    t('★ 0 이면 나이로 안 거른다', len(keep2) == 5 and not drop2, len(keep2))

    # ── 자리다툼 규칙 ────────────────────────────────────────────
    R2 = [
        {'title': 'ㄱ교회 실황', 'item_url': 'a1', 'site_name': 'ㄱ교회',
         'published': '2026-09-05'},
        {'title': 'ㄱ교회  실황', 'item_url': 'a2', 'site_name': 'ㄱ교회',
         'published': '2026-09-05'},          # 공백만 다르다 = 같은 제목
        {'title': '9.4 새벽기도회', 'item_url': 'a3', 'site_name': 'ㄴ교회',
         'published': '2026-09-04'},
        {'title': '9.1 새벽기도회', 'item_url': 'a4', 'site_name': 'ㄴ교회',
         'published': '2026-09-01'},          # 날짜만 다르다 = 다른 설교
        {'title': 'ㄴ교회 셋째', 'item_url': 'a5', 'site_name': 'ㄴ교회',
         'published': '2026-08-30'},
    ]
    set_rules(c, {'max_age_days': 0, 'drop_no_date': False,
                  'dedupe_title': True, 'max_per_channel': 0})
    k3, d3 = apply(R2, get_rules(c), NOW)
    t('★★ **똑같은 제목은 하나만**(1·2·3부 실황)',
      len(k3) == 4 and len(d3) == 1, [x['item_url'] for x in k3])
    t('★★★ **날짜만 다른 시리즈는 안 묶는다**(실측으로 잡은 함정)',
      {'a3', 'a4'} <= {x['item_url'] for x in k3})
    set_rules(c, {'max_age_days': 0, 'drop_no_date': False,
                  'dedupe_title': False, 'max_per_channel': 2})
    k4, d4 = apply(R2, get_rules(c), NOW)
    nb = sum(1 for x in k4 if x['site_name'] == 'ㄴ교회')
    t('★★ 채널당 상한을 지킨다(ㄴ교회 3 → 2)', nb == 2, nb)
    t('  상한에 걸린 것도 **왜인지 말한다**',
      any('상한' in w for _r, w in d4), [w for _r, w in d4])
    t('★ 상한 0 이면 안 쓴다',
      len(apply(R2, dict(get_rules(c), max_per_channel=0), NOW)[0]) == 5)

    # ── 등록 채널만 (기독교 무관 제거) ────────────────────────────
    RO = dict(DEFAULT, max_age_days=0, drop_no_date=False,
              dedupe_title=False, registered_only=True)
    k5, d5 = apply(R2, RO, NOW, allow_sites={'ㄱ교회'})
    t('★★★ **등록 채널이 아니면 뺀다**(기독교 무관 제거)',
      {x['site_name'] for x in k5} == {'ㄱ교회'},
      {x['site_name'] for x in k5})
    t('  왜 뺐는지 말한다', any('등록 채널' in w for _r, w in d5))
    t('★★★ **목록이 비면 그 규칙을 안 쓴다**(전부 빼면 최신이 통째로 빈다)',
      len(apply(R2, RO, NOW, allow_sites=set())[0]) == 5)
    t('  규칙을 끄면 안 거른다',
      len(apply(R2, dict(RO, registered_only=False), NOW,
                allow_sites={'ㄱ교회'})[0]) == 5)

    # ── 제외후보 낱말 (수집 문지기와 **같은 표**) ────────────────
    #   ⚠ 그전에는 채널만 공유하고 낱말은 안 봤다 — 문지기가 생기기 전에
    #     담긴 것이 그대로 최신 목록으로 나갔다(실측 140건).
    EXR = dict(DEFAULT, max_age_days=0, drop_no_date=False,
               dedupe_title=False, registered_only=False)
    EXROWS = [
        {'item_url': 'x1', 'site_name': 'ㄱ', 'lang': 'KO',
         'title': '[매일미사 강론] 연중 제34주간', 'published': '2026-09-05'},
        {'item_url': 'x2', 'site_name': 'ㄱ', 'lang': 'KO',
         'title': '주일 2부 예배 (미사강변 우리들교회)', 'published': '2026-09-05'},
        {'item_url': 'x3', 'site_name': 'ㄱ', 'lang': 'RU',
         'title': 'Пасхальная литургия', 'published': '2026-09-05'},
    ]
    ke, de = apply(EXROWS, EXR, NOW)
    #   ⚠ **정교회도 거른다**(2026-09-06 사용자 확정) — 옛 시험은 그 반대를
    #     잠그고 있었다. **결정이 바뀌면 시험도 함께 뒤집는다.**
    t('★★★ **제외후보 낱말이 최신 발행에도 걸린다**(수집 문지기와 같은 표)',
      sorted(r['item_url'] for r, _ in de) == ['x1', 'x3'],
      [r['item_url'] for r, _ in de])
    t('★★ **개신교회 이름은 안 걸린다**(하남 미사동)',
      'x2' in [r['item_url'] for r in ke])
    t('  왜 뺐는지 말한다', bool(de) and '교파' in de[0][1], de[0][1] if de else '')
    t('★ 규칙을 끄면 안 거른다',
      len(apply(EXROWS, dict(EXR, use_exclude_kw=False), NOW)[0]) == 3)
    #   ⚠ **여기서 낱말을 베끼지 않는다** — 집은 media_exclude 하나다.
    t('★★★ 낱말을 여기서 다시 적지 않는다',
      'get_exclude_map' in open(__file__, encoding='utf-8').read())

    # ── 수집 제외 채널 (구절/용어 수집기와 같은 목록) ─────────────
    OFF = dict(DEFAULT, max_age_days=0, drop_no_date=False,
               dedupe_title=False, registered_only=False)
    k6, d6 = apply(R2, OFF, NOW, block_sites={'ㄴ교회'})
    t('★★★ **수집 제외 채널은 최신에서도 빠진다**(사용자 지시)',
      {x['site_name'] for x in k6} == {'ㄱ교회'},
      {x['site_name'] for x in k6})
    t('  왜 뺐는지 말한다',
      any('수집 제외' in w for _r, w in d6), [w for _r, w in d6][:1])
    t('★★★ **규칙보다 앞선다** — 등록 채널이어도 뺀다',
      not apply(R2, dict(OFF, registered_only=True), NOW,
                allow_sites={'ㄱ교회', 'ㄴ교회'},
                block_sites={'ㄴ교회'})[0].__contains__(R2[2]))
    t('★★ **대소문자·공백을 안 따진다**(수집기와 같은 규칙)',
      _blocked(' ㄴ교회 ', {'ㄴ교회'}) and _blocked('ABC', {'abc'})
      and not _blocked('ㄷ교회', {'ㄴ교회'}))

    # 점검 — 표가 없어도 안 죽는다
    a = audit(c)
    t('★★ 표가 없어도 점검이 안 죽는다', isinstance(a, list))
    c.execute("CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY,"
              " channel_ext_id TEXT, channel_url TEXT, enabled INT,"
              " record_status TEXT)")
    c.execute("INSERT INTO sys_media_channel VALUES(1,'UCa','',1,'LIVE')")
    c.execute("INSERT INTO sys_media_channel VALUES(2,'이름','x',1,'LIVE')")
    c.commit()
    a = {x['code']: x for x in audit(c)}
    t('★★ 채널 주소 빈 것을 센다', a['CHAN_NO_URL']['n'] == 1)
    t('★★★ **UC 꼴 아닌 채널은 BLOCK**(수집이 멈춘다)',
      a['CHAN_BAD_ID']['n'] == 1 and a['CHAN_BAD_ID']['level'] == 'BLOCK')
    t('  문제가 없으면 OK 로 낸다',
      audit(c)[0]['level'] in ('OK', 'WARN', 'BLOCK'))
    t('★ 점검마다 **고치는 법**이 있다(§0-1)',
      all(x['fix'] for x in audit(c)))
    c.close()
    _selftest_lang_cap(t)

    print('  %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    try:
        if '--rules' in a:
            for k, v in get_rules(conn).items():
                print('  %-18s %s' % (k, v))
        if '--audit' in a:
            for x in audit(conn):
                print('  [%-5s] %-28s %5d   %s'
                      % (x['level'], x['what'], x['n'], x['code']))
                if x['n']:
                    print('           → %s' % x['fix'])
        if '--preview' in a:
            k = a[a.index('--preview') + 1] if len(a) > a.index('--preview') + 1 else 'yt'
            keep, drop, note = preview(conn, k)
            print('나갈 것 %d · 걸러진 것 %d  %s' % (len(keep), len(drop), note))
            for r in keep[:10]:
                print('  %s  %-22s %s'
                      % (_date_of(r), (r.get('site_name') or '')[:20],
                         (r.get('title') or '')[:56]))
            if drop:
                print()
                print('걸러진 것 (앞 8):')
                for r, w in drop[:8]:
                    print('  %-28s %s' % (w, (r.get('title') or '')[:46]))
        if not a:
            print('  --selftest | --rules | --audit | --preview yt|items')
    finally:
        conn.close()
