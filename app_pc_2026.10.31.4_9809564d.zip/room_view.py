# -*- coding: utf-8 -*-
"""room_view.py — 설정 ▸ 「내 공동체」 (공동체 묵상 2단계 화면, 2026-09-08).

설계 = `정책자료/0.교회묵상.txt` §3-2 · §6-0 · §8 2단계.
데이터 층은 **`room_core.py` 하나** — 여기서 SQL 을 다시 쓰지 않는다.

★★ **이 화면이 하는 일은 「처음 한 번」이다**(§2 배치안 ②) —
  방을 열고 · 초대 파일을 만들고 · 참여하고 · 이름을 정한다.
  매일 쓰는 자리가 아니라서 설정에 둔다.

2단계 범위 — **아직 나눔은 없다**(§8):
  ⚠ **동기화 주기 스위치를 안 만든다** — 동기화할 것이 아직 없다.
    눌러도 아무 일이 없는 스위치는 만들지 않는다(§0-1).
  ⚠ **[방 관리] 갈래(기수·멤버·교재)도 아직 없다** — 4단계다. 대신 방장에게는
    **초대 파일 만들기**와 **폴더 주소**만 먼저 준다.

사용:  python room_view.py --selftest
"""
import io
import json
import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import appdb
import room_core as RC

try:
    import i18n
    _t = i18n.t
except Exception:
    def _t(k, d=''):
        return d

try:
    import ui_theme

    def _C(role, fb):
        try:
            return ui_theme.C(role)
        except Exception:
            return fb
except Exception:
    def _C(role, fb):
        return fb


def _tfr(w, db, scope='ui', delta=0):
    """표준 글꼴 등록(§36) — 실패해도 화면은 뜬다."""
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=delta)
    except Exception:
        pass


class RoomView(ttk.Frame):
    """설정 ▸ 내 공동체."""

    def __init__(self, master, db_path, lang_getter=None):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._rows = []
        self._sel = None
        self._build()
        self.after_idle(self.reload)

    # ── 화면 ─────────────────────────────────────────────────────────
    def _build(self):
        pad = 10
        # 안내 한 줄 — **무엇을 하는 자리인지** 먼저 말한다
        top = ttk.Frame(self)
        top.pack(fill='x', padx=pad, pady=(pad, 4))
        lb = tk.Label(top, text=_t('ROOM_INTRO',
                      '교회·가정·친구끼리 묵상 교재와 자료를 나누는 방입니다. '
                      '방을 열거나, 받은 초대 파일로 참여하세요.'),
                      anchor='w', justify='left',
                      fg=_C('fg_dim', '#666'), wraplength=760)
        lb.pack(side='left', fill='x', expand=True)
        _tfr(lb, self.db_path, 'ui', -1)

        # 단추 줄 — **맨 위**(§0)
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=pad, pady=(0, 6))
        ttk.Button(bar, text=_t('ROOM_BTN_NEW', '방 만들기'),
                   command=self._open_new).pack(side='left')
        ttk.Button(bar, text=_t('ROOM_BTN_JOIN', '초대 파일로 참여하기'),
                   command=self._join).pack(side='left', padx=6)
        # ★ [M] 은 그 줄의 **맨 오른쪽**(user_main._manual_at 규칙) — 처음 오는 사람이
        #   가장 먼저 서는 자리라 방 만들기·참여·폴더·방 관리 입구를 여기서 읽는다.
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar, 'U_SET_ROOM',
                               lang_provider=lambda: (self.lang_getter() or 'KO')
                               ).pack(side='right', padx=(4, 0))
        except Exception as e:
            _quiet('[room manual] %s' % e)
        self._btn_refresh = ttk.Button(bar, text=_t('COMMON_REFRESH', '새로고침'),
                                       command=self.reload)
        self._btn_refresh.pack(side='right')

        # ── 좌우: 방 목록 | 그 방의 상세 ───────────────────────────
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=pad, pady=(0, pad))

        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        self._tv = ttk.Treeview(lf, columns=('type', 'role', 'name'),
                                show='headings', selectmode='browse')
        for cid, key, dflt, w, anc in (
                ('name', 'ROOM_COL_NAME', '공동체', 220, 'w'),
                ('type', 'ROOM_COL_TYPE', '유형', 110, 'center'),
                ('role', 'ROOM_COL_ROLE', '내 역할', 70, 'center')):
            self._tv.heading(cid, text=_t(key, dflt))
        self._tv.configure(displaycolumns=('name', 'type', 'role'))
        self._tv.column('name', width=220, anchor='w', stretch=True)
        self._tv.column('type', width=110, anchor='center', stretch=False)
        self._tv.column('role', width=70, anchor='center', stretch=False)
        sb = ttk.Scrollbar(lf, command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(side='left', fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._on_pick())
        try:
            import theme_font
            theme_font.list_style('Room.Treeview', self.db_path)
            self._tv.configure(style='Room.Treeview')
        except Exception:
            pass

        rf = ttk.Frame(pw)
        pw.add(rf, weight=2)
        self._detail = rf
        self._build_detail(rf)

    def _build_detail(self, p):
        """오른쪽 — 선택한 방의 상세. **아무것도 안 선택했으면 안내를 보인다.**"""
        self._d_head = tk.StringVar(value='')
        h = tk.Label(p, textvariable=self._d_head, anchor='w',
                     fg=_C('fg_title', '#1A5276'))
        h.pack(fill='x')
        _tfr(h, self.db_path, 'ui', 3)

        self._d_meta = tk.StringVar(value='')
        m = tk.Label(p, textvariable=self._d_meta, anchor='w', justify='left',
                     fg=_C('fg_dim', '#666'))
        m.pack(fill='x', pady=(2, 8))
        _tfr(m, self.db_path, 'ui', -1)

        # ── 이 방에서 쓸 이름 — **방마다 따로**(§5-1) ─────────────
        self._body = ttk.Frame(p)
        self._body.pack(fill='both', expand=True)
        nr = ttk.Frame(self._body)
        nr.pack(fill='x', pady=(0, 2))
        ttk.Label(nr, text=_t('ROOM_MY_NAME', '이 방에서 쓸 이름')).pack(side='left')
        self._name_var = tk.StringVar()
        e = ttk.Entry(nr, textvariable=self._name_var, width=22)
        e.pack(side='left', padx=6)
        ttk.Button(nr, text=_t('COMMON_SAVE', '저장'),
                   command=self._save_name).pack(side='left')
        hint = tk.Label(self._body, text=_t('ROOM_MY_NAME_HINT',
                        '방마다 따로 정합니다. 다른 방에는 따라가지 않습니다.'),
                        anchor='w', fg=_C('fg_dim', '#999'))
        hint.pack(fill='x')
        _tfr(hint, self.db_path, 'ui', -2)

        # ── 폴더 주소 — **방장만**(§3-3 폴더 설정) ────────────────
        # ★★★ **폴더는 하나다**(2026-09-08 사용자 확정 — 「구글드라이브 하나만
        #   유지하는 방식으로 하자. 교재를 올리고 묵상방의 게시판에 첨부하면
        #   된다. 참가자들이 구글드라이브에 들어갈 것이라고 가정하는 이유를
        #   모르겠다」). 옛 「교재 폴더/나눔 폴더」 두 칸을 걷었다 — 교재는 이제
        #   게시판 첨부이고 참여자는 앱 안에서 연다.
        self._fold_f = ttk.LabelFrame(
            self._body, text=' ' + _t('ROOM_FOLDER', '방 폴더') + ' ')
        self._fold = tk.StringVar()
        r = ttk.Frame(self._fold_f)
        r.pack(fill='x', padx=8, pady=2)
        ttk.Entry(r, textvariable=self._fold).pack(side='left', fill='x',
                                                   expand=True)
        fr = ttk.Frame(self._fold_f)
        fr.pack(fill='x', padx=8, pady=(2, 6))
        ttk.Button(fr, text=_t('COMMON_SAVE', '저장'),
                   command=self._save_folders).pack(side='left')
        ttk.Button(fr, text=_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                   command=self._make_invite).pack(side='left', padx=6)
        # ★ **[방 관리] — My Edit 과 별개의 입구**(사용자 확정). 플랜 지정 ·
        #   게시판 · 참가자 현황 · 이름 바꾸기 · 지우기가 그 창에 있다.
        ttk.Button(fr, text=_t('RM_ADMIN', '방 관리'),
                   command=self._open_admin).pack(side='left')
        fh = tk.Label(self._fold_f, text=_t('ROOM_FOLDER_HINT2',
                      '폴더 하나면 됩니다(구글드라이브·OneDrive 가 만든 동기화 '
                      '폴더). 교재는 방 관리의 게시판에 첨부해 올립니다. 참여자는 '
                      '이 앱 안에서 받으므로 드라이브를 직접 열 필요가 없습니다.'),
                      anchor='w', justify='left', wraplength=520,
                      fg=_C('fg_dim', '#999'))
        fh.pack(fill='x', padx=8, pady=(0, 6))
        _tfr(fh, self.db_path, 'ui', -2)

        # ── 자료 받기 — 2단계는 **파일로 받는다**(단방향) ──────────
        self._pack_f = ttk.LabelFrame(
            self._body, text=' ' + _t('ROOM_PACK', '자료') + ' ')
        pr = ttk.Frame(self._pack_f)
        pr.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Button(pr, text=_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                   command=self._import_pack).pack(side='left')
        self._btn_export = ttk.Button(pr, text=_t('ROOM_BTN_EXPORT', '자료 내보내기'),
                                      command=self._export_pack)
        self._btn_export.pack(side='left', padx=6)
        ph = tk.Label(self._pack_f, text=_t('ROOM_PACK_HINT',
                      '지금은 파일을 주고받습니다. 방장이 내보낸 파일을 받아 여기서 '
                      '열면 묵상노트·연구자료·구절연결·렌즈가 들어옵니다.'),
                      anchor='w', justify='left', wraplength=520,
                      fg=_C('fg_dim', '#999'))
        ph.pack(fill='x', padx=8, pady=(0, 6))
        _tfr(ph, self.db_path, 'ui', -2)

        # ── 나눔 (3단계) — **나눔 폴더가 있어야 돈다** ────────────
        self._share_f = ttk.LabelFrame(
            self._body, text=' ' + _t('ROOM_SHARE', '묵상 나누기') + ' ')
        sr = ttk.Frame(self._share_f)
        sr.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Button(sr, text=_t('ROOM_BTN_PUSH', '내 묵상 올리기'),
                   command=self._push).pack(side='left')
        ttk.Button(sr, text=_t('ROOM_BTN_PULL', '함께 나눈 글 받기'),
                   command=self._pull).pack(side='left', padx=6)
        self._share_cnt = tk.StringVar(value='')
        tk.Label(sr, textvariable=self._share_cnt, fg=_C('fg_dim', '#666')
                 ).pack(side='left', padx=(10, 0))
        sh = tk.Label(self._share_f, text=_t('ROOM_SHARE_HINT',
                      '함께 묵상은 묵상플랜의 「함께 묵상」 화면에서 그날 읽은 '
                      '범위 전체를 놓고 씁니다. 올릴 때 내 글 전체가 한 파일로 '
                      '나가고, 고치거나 지운 것도 함께 반영됩니다. 글에 구절을 '
                      '붙여 두면 성경 화면의 묵상노트 아래 「함께 나눈 글」에도 '
                      '보입니다.'),
                      anchor='w', justify='left', wraplength=520,
                      fg=_C('fg_dim', '#999'))
        sh.pack(fill='x', padx=8, pady=(0, 6))
        _tfr(sh, self.db_path, 'ui', -2)

        # ── 나가기 ────────────────────────────────────────────────
        br = ttk.Frame(self._body)
        br.pack(fill='x', pady=(8, 0))
        ttk.Button(br, text=_t('ROOM_BTN_LEAVE', '이 방 나가기'),
                   command=self._leave).pack(side='left')

        self._empty = tk.Label(
            p, text=_t('ROOM_EMPTY',
                       '아직 참여한 방이 없습니다.\n\n'
                       '· 방을 열려면 [방 만들기]\n'
                       '· 초대를 받았으면 [초대 파일로 참여하기]'),
            anchor='w', justify='left', fg=_C('fg_dim', '#888'))
        _tfr(self._empty, self.db_path, 'ui')

    # ── 목록 ─────────────────────────────────────────────────────────
    def reload(self):
        try:
            with appdb.connect(self.db_path) as conn:
                self._rows = RC.rooms(conn)
                # ⚠ **못 보낸 신고는 다음에 보낸다**(§6-0 「통계를 위해
                #   사용자를 막지 않는다」). 문의 통로가 그때 안 됐거나
                #   네트워크가 막혔을 수 있다.
                for rid in RC.pending_reports(conn):
                    try:
                        RC.report(conn, rid)
                    except Exception:
                        pass
        except Exception as e:
            self._rows = []
            _quiet('[room] %s' % e)
        self._tv.delete(*self._tv.get_children())
        lang = (self.lang_getter() or 'KO').upper()
        for r in self._rows:
            self._tv.insert('', 'end', iid=r['room_id'], values=(
                r['room_name'],
                RC.type_name(r['room_type'], lang),
                _t('ROOM_ROLE_LEADER', '방장') if r['my_role'] == RC.ROLE_LEADER
                else _t('ROOM_ROLE_CO', '부방장') if r['my_role'] == RC.ROLE_CO
                else _t('ROOM_ROLE_MEMBER', '참여자')))
        if self._rows:
            self._tv.selection_set(self._rows[0]['room_id'])
        else:
            self._sel = None
            self._show_detail(None)

    def _on_pick(self):
        sel = self._tv.selection()
        if not sel:
            return
        for r in self._rows:
            if r['room_id'] == sel[0]:
                self._sel = r
                self._show_detail(r)
                return

    def _show_detail(self, r):
        """⚠ **아무것도 없으면 왜 없는지 말한다**(§0-1 빈 서랍)."""
        if not r:
            self._body.pack_forget()
            self._d_head.set('')
            self._d_meta.set('')
            self._empty.pack(fill='both', expand=True, pady=20)
            return
        self._empty.pack_forget()
        self._body.pack(fill='both', expand=True)
        lang = (self.lang_getter() or 'KO').upper()
        self._d_head.set(r['room_name'])
        bits = [RC.type_name(r['room_type'], lang)]
        if r['leader_name']:
            bits.append(_t('ROOM_LEADER_IS', '방장 %s') % r['leader_name'])
        if r['joined_at']:
            bits.append(_t('ROOM_JOINED', '참여 %s') % (r['joined_at'] or '')[:10])
        # 5단계 — 마무리 · 관리자 차단을 한 줄에 함께 말한다
        if RC.is_closed(r):
            bits.append(_t('RA_CLOSED_AT', '마무리됨 %s') % (r.get('closed_at') or ''))
        self._blocked = None
        try:
            with appdb.connect(self.db_path) as conn:
                self._blocked = RC.blocked(conn, r['room_id'])
        except Exception:
            pass
        if self._blocked:
            bits.append(_t('RA_BLOCKED', '관리자가 이 방을 막았습니다: %s') % self._blocked)
        self._d_meta.set('  ·  '.join(bits))
        self._name_var.set(r['my_name'] or '')
        self._fold.set(RC.folder_of(r))
        # ★ **방장일 때만** 폴더·초대·내보내기가 뜬다(§2 배치안 ③ 빈 서랍 금지)
        lead = (r['my_role'] in RC.MANAGER_ROLES)   # 부방장도 [방 관리] 로 간다
        # ⚠⚠ **`before=` 는 그 형제가 이미 pack 관리일 때만 먹는다** — 처음
        #   그릴 때는 `_pack_f` 가 아직 안 붙어 있어 **조용히 아무 일도 안
        #   일어났다**(실측: 방장인데 폴더 칸이 안 보였다).
        #   ⇒ **둘 다 걷고 차례대로 다시 붙인다**(§203차 ㉞ 그 처방).
        self._fold_f.pack_forget()
        self._pack_f.pack_forget()
        self._share_f.pack_forget()
        if lead:
            self._fold_f.pack(fill='x', pady=(10, 4))
        self._pack_f.pack(fill='x', pady=(4, 0))
        self._share_f.pack(fill='x', pady=(4, 0))
        try:
            self._btn_export.state(['!disabled'] if lead else ['disabled'])
        except Exception:
            pass
        # 받아 둔 것 — **없으면 그렇다고 말한다**(§0-1)
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                a, b = RS.counts(conn, r['room_id'], self.db_path)
            self._share_cnt.set(
                (_t('ROOM_SHARE_CNT', '받아 둔 것 — %d명 · %d편') % (a, b))
                if b else _t('ROOM_SHARE_NONE', '아직 받은 글이 없습니다'))
        except Exception:
            self._share_cnt.set('')

    # ── 방 만들기 ────────────────────────────────────────────────────
    def _open_new(self):
        _NewRoomDialog(self, self.db_path, self.lang_getter, self.reload)

    # ── 참여 ─────────────────────────────────────────────────────────
    def _join(self):
        p = filedialog.askopenfilename(
            parent=self.winfo_toplevel(),
            title=_t('ROOM_BTN_JOIN', '초대 파일로 참여하기'),
            filetypes=[(_t('ROOM_FILE_INVITE', '초대 파일'), '*.hagah'),
                       (_t('COMMON_ALL', '전체'), '*.*')])
        if not p:
            return
        try:
            inv = RC.read_invite(p)
        except Exception as e:
            # ⚠ **무엇이 잘못됐는지 말한다**(§0-1) — 코드를 그대로 보이지 않는다.
            messagebox.showwarning(_t('ROOM_BTN_JOIN', '초대 파일로 참여하기'),
                                   self._why_bad(e),
                                   parent=self.winfo_toplevel())
            return
        nm = self._ask_name(inv.get('room') or '')
        if nm is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                rid, fresh = RC.join_room(conn, inv, nm)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_JOIN', '초대 파일로 참여하기'), str(e)[:200],
                                 parent=self.winfo_toplevel())
            return
        # ★ 참여자도 **이 방의 내용은 이 앱이 만든 것이 아님**을 한 번 읽는다(§6-0)
        messagebox.showinfo(
            _t('ROOM_BTN_JOIN', '초대 파일로 참여하기'),
            (_t('ROOM_JOINED_OK', '「%s」에 참여했습니다.') % (inv.get('room') or ''))
            + '\n\n' + _t('ROOM_TERMS_MEMBER',
                          '이 방의 교재와 글은 방장과 참여자가 올린 것이며, '
                          '이 앱을 만든 사람이 만들거나 검토한 것이 아닙니다.'),
            parent=self.winfo_toplevel())
        self.reload()
        try:
            self._tv.selection_set(rid)
        except Exception:
            pass

    @staticmethod
    def _why_bad(e):
        s = str(e)
        if 'IS_SHARE_PACK' in s:
            return _t('ROOM_ERR_PACK',
                      '이것은 초대 파일이 아니라 자료 파일입니다. '
                      '방을 선택한 뒤 [받은 자료 파일 열기]로 여세요.')
        if 'NEWER_FMT' in s:
            return _t('ROOM_ERR_NEW', '더 새로운 판의 초대 파일입니다. '
                                      '앱을 최신으로 올린 뒤 다시 열어 보세요.')
        if 'BROKEN' in s:
            return _t('ROOM_ERR_BROKEN', '초대 파일이 손상되었습니다. '
                                         '방장에게 다시 받아 주세요.')
        return _t('ROOM_ERR_NOT', '초대 파일이 아닙니다.')

    def _ask_name(self, room_name):
        """참여할 때 이름을 묻는다 — **비워 두면 나중에 정할 수 있다.**"""
        from tkinter import simpledialog
        return simpledialog.askstring(
            _t('ROOM_MY_NAME', '이 방에서 쓸 이름'),
            _t('ROOM_ASK_NAME', '「%s」에서 다른 분들에게 보일 이름을 적어 주세요.\n'
                                '(나중에 바꿀 수 있습니다)') % room_name,
            parent=self.winfo_toplevel())

    # ── 손질 ─────────────────────────────────────────────────────────
    def _save_name(self):
        if not self._sel:
            return
        with appdb.connect(self.db_path) as conn:
            RC.set_my_name(conn, self._sel['room_id'], self._name_var.get())
        self.reload()
        self._flash(_t('ROOM_SAVED', '저장했습니다.'))

    def _save_folders(self):
        if not self._sel:
            return
        with appdb.connect(self.db_path) as conn:
            RC.set_folder(conn, self._sel['room_id'], self._fold.get())
        self.reload()
        self._flash(_t('ROOM_SAVED', '저장했습니다.'))

    def _open_admin(self):
        if not self._sel:
            return
        try:
            import room_admin_view as RA
            RA.open_room_admin(self, self.db_path, self._sel['room_id'],
                               self.lang_getter, on_changed=self.reload)
        except Exception as e:
            messagebox.showerror(_t('RM_ADMIN', '방 관리'), str(e)[:200],
                                 parent=self.winfo_toplevel())

    def _flash(self, msg):
        messagebox.showinfo(_t('ROOM_TAB', '내 공동체'), msg,
                            parent=self.winfo_toplevel())

    def _leave(self):
        if not self._sel:
            return
        if not messagebox.askyesno(
                _t('ROOM_BTN_LEAVE', '이 방 나가기'),
                _t('ROOM_LEAVE_ASK',
                   '「%s」에서 나갑니다.\n\n목록에서만 빠지고 받아 둔 자료는 '
                   '그대로 남습니다. 초대 파일로 다시 참여할 수 있습니다.')
                % self._sel['room_name'],
                parent=self.winfo_toplevel()):
            return
        rid = self._sel['room_id']
        with appdb.connect(self.db_path) as conn:
            RC.leave_room(conn, rid)
        # ★ 받아 둔 **남의 글**은 함께 걷는다(설계 §5-2 「파일 하나만 지우면
        #   된다」). ⚠ **내 글은 한 글자도 안 지운다** — 그 파일에는 남의 글만
        #   있고 내 것은 `user_data.db` 에 그대로다.
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                RS.detach(conn)
            RS.forget_room(rid, self.db_path)
        except Exception as e:
            _quiet('[room leave] %s' % e)
        self.reload()

    # ── 나눔 (3단계) ─────────────────────────────────────────────────
    def _share_folder(self):
        """나눔 폴더 — **없으면 왜 없는지 말하고 어디서 넣는지 알린다**(§0-1)."""
        r = self._sel
        if not r:
            return None
        if getattr(self, '_blocked', None):
            messagebox.showinfo(_t('ROOM_SHARE', '묵상 나누기'),
                                _t('RM_BLOCKED_STOP',
                                   '관리자가 이 방을 막아 올리고 받을 수 없습니다: %s')
                                % self._blocked, parent=self.winfo_toplevel())
            return None
        f = RC.folder_of(r)
        if not f:
            messagebox.showinfo(
                _t('ROOM_SHARE', '묵상 나누기'),
                _t('ROOM_NO_FOLDER_B',
                   '방 폴더가 정해지지 않았습니다.\n\n방장이 [방 폴더]에 '
                   '주소를 넣고 초대 파일을 다시 만들어 주어야 합니다. '
                   '그 폴더는 참여자 모두가 읽고 쓸 수 있어야 합니다.'),
                parent=self.winfo_toplevel())
            return None
        if not os.path.isdir(f):
            # ⚠ **주소가 아니라 폴더여야 한다** — 클라우드 링크(https://…)는
            #   이 앱이 못 연다. 동기화 클라이언트가 만든 **로컬 폴더**를 가리켜야
            #   한다(설계 §4-3 — 폴더 동기화가 나르고 우리는 파일만 읽고 쓴다).
            messagebox.showwarning(
                _t('ROOM_SHARE', '묵상 나누기'),
                _t('ROOM_FOLDER_NOT_DIR',
                   '「%s」 을(를) 폴더로 열 수 없습니다.\n\n웹 주소가 아니라 '
                   '내 PC 에서 보이는 폴더 경로를 넣어 주세요. 구글드라이브·'
                   'OneDrive 를 쓰신다면 그 프로그램이 만든 동기화 폴더입니다.')
                % f[:80], parent=self.winfo_toplevel())
            return None
        return f

    def _push(self):
        f = self._share_folder()
        if not f:
            return
        r = self._sel
        if not (r['my_name'] or '').strip():
            # ⚠ **이름 없이 올리면 남들이 누구 글인지 모른다.**
            messagebox.showinfo(
                _t('ROOM_SHARE', '묵상 나누기'),
                _t('ROOM_NEED_MY_NAME',
                   '먼저 이 방에서 쓸 이름을 정해 주세요. 함께 나눈 글에 그 '
                   '이름이 보입니다.'), parent=self.winfo_toplevel())
            return
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                draft, skipped = RS.export_notes(conn, r['room_id'], r['my_name'])
        except Exception as e:
            messagebox.showerror(_t('ROOM_SHARE', '묵상 나누기'), str(e)[:250],
                                 parent=self.winfo_toplevel())
            return
        n = len(draft['notes'])
        if not n:
            messagebox.showinfo(
                _t('ROOM_SHARE', '묵상 나누기'),
                _t('ROOM_PUSH_EMPTY',
                   '올릴 묵상노트가 없습니다. 성경 화면에서 묵상노트를 먼저 '
                   '써 주세요.'), parent=self.winfo_toplevel())
            return
        # ★ **무엇이 나가는지 먼저 말한다**(§0 규칙) — 남이 읽게 되는 글이다.
        if not messagebox.askyesno(
                _t('ROOM_SHARE', '묵상 나누기'),
                (_t('ROOM_PUSH_ASK',
                    '함께 묵상 %d편을 「%s」 방에 올립니다.\n\n올린 글은 그 '
                    '방의 참여자 모두가 읽습니다.') % (n, r['room_name']))
                + (('\n\n' + _t('ROOM_PUSH_SKIP',
                                '구절을 찾지 못한 %d편은 빠집니다.') % len(skipped))
                   if skipped else ''),
                parent=self.winfo_toplevel()):
            return
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                name, cnt, sk = RS.push(conn, r['room_id'], f, r['my_name'],
                                        self.db_path)
        except Exception as e:
            messagebox.showerror(_t('ROOM_SHARE', '묵상 나누기'), str(e)[:250],
                                 parent=self.winfo_toplevel())
            return
        messagebox.showinfo(
            _t('ROOM_SHARE', '묵상 나누기'),
            _t('ROOM_PUSH_OK', '%d편을 올렸습니다.\n파일: %s') % (cnt, name),
            parent=self.winfo_toplevel())

    def _pull(self):
        f = self._share_folder()
        if not f:
            return
        r = self._sel
        try:
            import room_share as RS
            with appdb.connect(self.db_path) as conn:
                who, notes, bad = RS.pull(conn, r['room_id'], f, self.db_path)
        except Exception as e:
            messagebox.showerror(_t('ROOM_SHARE', '묵상 나누기'), str(e)[:250],
                                 parent=self.winfo_toplevel())
            return
        if not who:
            messagebox.showinfo(
                _t('ROOM_SHARE', '묵상 나누기'),
                _t('ROOM_PULL_NONE',
                   '받을 글이 없습니다. 아직 아무도 올리지 않았거나, 폴더 동기화가 '
                   '끝나지 않았을 수 있습니다.'), parent=self.winfo_toplevel())
            self._show_detail(r)
            return
        msg = _t('ROOM_PULL_OK', '%d명의 글 %d편을 받았습니다.') % (who, notes)
        if bad:
            # ⚠ **못 받은 것을 조용히 넘기지 않는다**(§0-1)
            msg += '\n' + _t('ROOM_PULL_BAD',
                             '구절을 찾지 못해 못 받은 것 %d편') % bad
        msg += '\n\n' + _t('ROOM_PULL_WHERE',
                           '성경 화면의 묵상노트 아래 「함께 나눈 글」에서 읽습니다.')
        messagebox.showinfo(_t('ROOM_SHARE', '묵상 나누기'), msg,
                            parent=self.winfo_toplevel())
        self._show_detail(r)

    # ── 초대 파일 만들기 ─────────────────────────────────────────────
    def _make_invite(self):
        if not self._sel:
            return
        r = self._sel
        if not RC.folder_of(r):
            # ⚠ 폴더 없이도 만들 수 있으나 **그 사실을 알린다**(§0-1).
            if not messagebox.askyesno(
                    _t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                    _t('ROOM_INVITE_NOFOLDER',
                       '자료 폴더 주소가 비어 있습니다.\n지금 만들면 참여자는 '
                       '방에는 들어오지만 자료를 받을 곳이 없습니다.\n\n'
                       '그래도 만들까요?'),
                    parent=self.winfo_toplevel()):
                return
        safe = ''.join(ch for ch in r['room_name']
                       if ch not in '\\/:*?"<>|').strip() or 'room'
        p = filedialog.asksaveasfilename(
            parent=self.winfo_toplevel(),
            title=_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
            initialfile=safe + RC.EXT, defaultextension=RC.EXT,
            filetypes=[(_t('ROOM_FILE_INVITE', '초대 파일'), '*.hagah')])
        if not p:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                out = RC.write_invite(conn, r['room_id'], p)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_INVITE', '초대 파일 만들기'),
                                 str(e)[:200], parent=self.winfo_toplevel())
            return
        messagebox.showinfo(
            _t('ROOM_BTN_INVITE', '초대 파일 만들기'),
            (_t('ROOM_INVITE_OK', '만들었습니다.\n%s') % out) + '\n\n'
            + _t('ROOM_INVITE_HOW',
                 '이 파일을 참여할 분들에게 보내 주세요(메신저·메일 어느 쪽이든). '
                 '받은 분은 [초대 파일로 참여하기]로 엽니다.') + '\n\n'
            + _t('ROOM_INVITE_WARN',
                 '⚠ 이 파일에는 폴더 주소가 들어 있습니다. 받은 사람은 누구나 '
                 '그 방에 들어올 수 있으니 아는 분들에게만 보내세요.'),
            parent=self.winfo_toplevel())

    # ── 자료 파일 ────────────────────────────────────────────────────
    def _import_pack(self):
        p = filedialog.askopenfilename(
            parent=self.winfo_toplevel(),
            title=_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
            filetypes=[(_t('ROOM_FILE_PACK', '자료 파일'), '*.json;*.hagah'),
                       (_t('COMMON_ALL', '전체'), '*.*')])
        if not p:
            return
        try:
            draft = json.load(io.open(p, encoding='utf-8'))
        except Exception as e:
            messagebox.showwarning(_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                                   str(e)[:200], parent=self.winfo_toplevel())
            return
        # ⚠ 초대 파일을 여기 넣었을 때 **그렇다고 말한다**(반대 경우와 짝).
        if isinstance(draft, dict) and draft.get('app') == RC.APP_MARK:
            messagebox.showwarning(
                _t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                _t('ROOM_ERR_INVITE',
                   '이것은 자료 파일이 아니라 초대 파일입니다. '
                   '위의 [초대 파일로 참여하기]로 여세요.'),
                parent=self.winfo_toplevel())
            return
        try:
            import share_pack as SP
            lines = SP.preview(draft)
        except Exception as e:
            messagebox.showwarning(_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                                   str(e)[:200], parent=self.winfo_toplevel())
            return
        # ★ **무엇이 들어오는지 먼저 보이고** 확인을 받는다(§0 규칙).
        if not messagebox.askyesno(
                _t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                _t('ROOM_IMPORT_ASK', '다음 자료를 받습니다.') + '\n\n'
                + '\n'.join('· %s' % x for x in lines) + '\n\n'
                + _t('ROOM_IMPORT_NOTE',
                     '이미 받은 것은 다시 들어오지 않습니다. '
                     '내가 쓴 글은 지워지지 않습니다.'),
                parent=self.winfo_toplevel()):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                put, skip, bad = SP.import_pack(conn, draft)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'),
                                 str(e)[:300], parent=self.winfo_toplevel())
            return
        msg = _t('ROOM_IMPORT_OK', '받았습니다 — 새로 %d건') % put
        if skip:
            msg += '\n' + _t('ROOM_IMPORT_DUP', '이미 있던 것 %d건') % skip
        if bad:
            # ⚠ **못 받은 것을 조용히 넘기지 않는다**(§0-1).
            msg += '\n' + _t('ROOM_IMPORT_BAD',
                             '못 받은 것 %d건 (구절·용어를 찾지 못했습니다)') % bad
        messagebox.showinfo(_t('ROOM_BTN_IMPORT', '받은 자료 파일 열기'), msg,
                            parent=self.winfo_toplevel())

    def _export_pack(self):
        if not self._sel:
            return
        try:
            import share_pack as SP
            with appdb.connect(self.db_path) as conn:
                draft, skipped = SP.export_pack(
                    conn, made_by=self._sel['my_name'] or '',
                    title=self._sel['room_name'])
            lines = SP.preview(draft)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_EXPORT', '자료 내보내기'),
                                 str(e)[:300], parent=self.winfo_toplevel())
            return
        if not lines:
            messagebox.showinfo(
                _t('ROOM_BTN_EXPORT', '자료 내보내기'),
                _t('ROOM_EXPORT_EMPTY',
                   '내보낼 자료가 없습니다. 묵상노트·연구자료·구절연결을 '
                   '먼저 만들어 주세요.'),
                parent=self.winfo_toplevel())
            return
        if not messagebox.askyesno(
                _t('ROOM_BTN_EXPORT', '자료 내보내기'),
                _t('ROOM_EXPORT_ASK', '다음 자료를 파일 하나로 만듭니다.') + '\n\n'
                + '\n'.join('· %s' % x for x in lines)
                + (('\n\n' + _t('ROOM_EXPORT_SKIP',
                                '실을 수 없는 것 %d건은 빠집니다.') % len(skipped))
                   if skipped else ''),
                parent=self.winfo_toplevel()):
            return
        safe = ''.join(ch for ch in self._sel['room_name']
                       if ch not in '\\/:*?"<>|').strip() or 'pack'
        p = filedialog.asksaveasfilename(
            parent=self.winfo_toplevel(),
            title=_t('ROOM_BTN_EXPORT', '자료 내보내기'),
            initialfile=safe + '.json', defaultextension='.json',
            filetypes=[(_t('ROOM_FILE_PACK', '자료 파일'), '*.json')])
        if not p:
            return
        try:
            with io.open(p, 'w', encoding='utf-8') as f:
                json.dump(draft, f, ensure_ascii=False, indent=1)
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_EXPORT', '자료 내보내기'),
                                 str(e)[:200], parent=self.winfo_toplevel())
            return
        messagebox.showinfo(_t('ROOM_BTN_EXPORT', '자료 내보내기'),
                            _t('ROOM_EXPORT_OK', '만들었습니다.\n%s') % p,
                            parent=self.winfo_toplevel())


class _NewRoomDialog(tk.Toplevel):
    """방 만들기 — **자동승인**(§6-0). 이름 · 유형 · 방장 이름 · 연락처 · 동의."""

    def __init__(self, parent, db_path, lang_getter, on_done):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter
        self.on_done = on_done
        self.title(_t('ROOM_BTN_NEW', '방 만들기'))
        self.transient(parent.winfo_toplevel())
        self.resizable(True, True)
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        self._build()
        self.update_idletasks()
        try:
            p = parent.winfo_toplevel()
            self.geometry('+%d+%d' % (p.winfo_rootx() + 60, p.winfo_rooty() + 40))
        except Exception:
            pass
        self.grab_set()

    def _build(self):
        pad = 12
        f = ttk.Frame(self)
        f.pack(fill='both', expand=True, padx=pad, pady=pad)

        # 단추는 **맨 위**(§0)
        bar = ttk.Frame(f)
        bar.pack(fill='x', pady=(0, 8))
        self._btn_ok = ttk.Button(bar, text=_t('ROOM_BTN_NEW', '방 만들기'),
                                  command=self._ok)
        self._btn_ok.pack(side='left')
        ttk.Button(bar, text=_t('COMMON_CANCEL', '취소'),
                   command=self.destroy).pack(side='left', padx=6)

        g = ttk.Frame(f)
        g.pack(fill='x')
        r = 0
        ttk.Label(g, text=_t('ROOM_F_NAME', '공동체 이름')).grid(
            row=r, column=0, sticky='w', pady=3)
        # ⚠⚠ **`self._name` 을 쓰면 안 된다**(§197차 ⑬) — Tk 위젯이 제
        #   이름(문자열)을 담는 칸이다. StringVar 로 덮으면 `destroy()` 가
        #   「cannot use 'StringVar' as a dict key」로 죽는다(또 밟았다).
        self._name_var = tk.StringVar()
        ttk.Entry(g, textvariable=self._name_var, width=34).grid(
            row=r, column=1, sticky='we', pady=3)
        r += 1
        ex = tk.Label(g, text=_t('ROOM_F_NAME_EX',
                      '보기: 우리교회 제자훈련 1기 · 할아버지랑 말씀 읽기 · 청년 스터디'),
                      anchor='w', fg=_C('fg_dim', '#999'))
        ex.grid(row=r, column=1, sticky='w')
        _tfr(ex, self.db_path, 'ui', -2)
        r += 1

        ttk.Label(g, text=_t('ROOM_F_TYPE', '공동체 유형')).grid(
            row=r, column=0, sticky='w', pady=3)
        lang = (self.lang_getter() or 'KO').upper()
        self._types = [(c, RC.type_name(c, lang)) for c, _k, _b in RC.COMMUNITY_TYPES]
        self._type = tk.StringVar(value=self._types[0][1])
        cb = ttk.Combobox(g, textvariable=self._type, state='readonly',
                          values=[n for _c, n in self._types], width=32)
        cb.grid(row=r, column=1, sticky='we', pady=3)
        r += 1

        ttk.Label(g, text=_t('ROOM_F_LEADER', '방장 이름')).grid(
            row=r, column=0, sticky='w', pady=3)
        self._leader = tk.StringVar()
        ttk.Entry(g, textvariable=self._leader, width=34).grid(
            row=r, column=1, sticky='we', pady=3)
        r += 1

        ttk.Label(g, text=_t('ROOM_F_CONTACT', '연락처 (이메일)')).grid(
            row=r, column=0, sticky='w', pady=3)
        self._contact = tk.StringVar()
        ttk.Entry(g, textvariable=self._contact, width=34).grid(
            row=r, column=1, sticky='we', pady=3)
        r += 1
        # ★★ **왜 받는지 그 자리에 적는다**(§6-0 ⓑ) — 이 앱의 첫 개인정보다.
        # ★ **화면 이름을 글에 박지 않는다** — `i18n` 에서 읽어 끼운다.
        #   박으면 그 탭 이름을 바꾸는 날 이 안내가 거짓이 된다(§0-1 ·
        #   도서 소개문 `PG_NOTE` 가 쓰는 그 규칙).
        ch = tk.Label(g, text=(_t('ROOM_F_CONTACT_WHY',
                      '이 앱의 관리자가 방장에게 이메일을 보낼 수 있습니다'
                      '(자료에 문제가 있거나 앱이 크게 바뀔 때).\n'
                      '광고에는 쓰지 않으며, 다른 참여자에게는 보이지 않습니다. '
                      '적지 않아도 방은 열립니다.')
                      + '\n' + (_t('ROOM_F_CONTACT_READ',
                                   '관리자가 보낸 글은 %s ▸ %s 화면에서도 '
                                   '읽을 수 있습니다.')
                                % (_t('TAB_P1_ANNOUNCE', '공지/소통'),
                                   _t('FB_MYASK', '내 문의')))),
                      anchor='w', justify='left', wraplength=430,
                      fg=_C('fg_dim', '#777'))
        ch.grid(row=r, column=1, sticky='w', pady=(0, 6))
        _tfr(ch, self.db_path, 'ui', -2)
        g.columnconfigure(1, weight=1)

        # ── 책임 선언 — **동의 없이는 못 연다** ────────────────────
        tf = ttk.LabelFrame(f, text=' ' + _t('ROOM_TERMS_TITLE', '방장의 책임') + ' ')
        tf.pack(fill='both', expand=True, pady=(8, 6))
        txt = tk.Text(tf, height=8, wrap='word', relief='flat',
                      bg=_C('panel_alt', '#F8F9FB'))
        txt.pack(fill='both', expand=True, padx=8, pady=(6, 2))
        txt.insert('1.0', _t('ROOM_TERMS_BODY', _TERMS_KO))
        txt.config(state='disabled')
        _tfr(txt, self.db_path, 'ui', -1)
        self._agree = tk.BooleanVar(value=False)
        ttk.Checkbutton(tf, variable=self._agree,
                        text=_t('ROOM_TERMS_AGREE', '위 내용을 읽고 동의합니다'),
                        command=self._sync).pack(anchor='w', padx=10, pady=(0, 8))
        self._sync()

    def _sync(self):
        try:
            self._btn_ok.state(['!disabled'] if self._agree.get() else ['disabled'])
        except Exception:
            pass

    def _ok(self):
        name = (self._name_var.get() or '').strip()
        lead = (self._leader.get() or '').strip()
        if not name:
            messagebox.showwarning(_t('ROOM_BTN_NEW', '방 만들기'),
                                   _t('ROOM_NEED_NAME', '공동체 이름을 적어 주세요.'),
                                   parent=self)
            return
        if not lead:
            messagebox.showwarning(_t('ROOM_BTN_NEW', '방 만들기'),
                                   _t('ROOM_NEED_LEADER', '방장 이름을 적어 주세요.'),
                                   parent=self)
            return
        code = 'ETC'
        for c, n in self._types:
            if n == self._type.get():
                code = c
                break
        try:
            with appdb.connect(self.db_path) as conn:
                rid = RC.create_room(conn, name, code, lead,
                                     contact=self._contact.get(),
                                     terms_ok=self._agree.get())
        except Exception as e:
            messagebox.showerror(_t('ROOM_BTN_NEW', '방 만들기'), str(e)[:200],
                                 parent=self)
            return
        self.destroy()
        if callable(self.on_done):
            self.on_done()
        # ★★ **등록 신고**(§6-0 절차 3) — 연락처를 적었을 때만.
        #   ⚠⚠ **실패해도 방은 이미 열려 있다** — 통계를 위해 사용자를 막지
        #     않는다. 못 보낸 것은 다음에 이 화면을 열 때 다시 보낸다.
        sent = False
        try:
            with appdb.connect(self.db_path) as conn:
                sent, _why = RC.report(conn, rid)
        except Exception as e:
            _quiet('[room report] %s' % e)
        msg = ((_t('ROOM_NEW_OK', '「%s」 방을 열었습니다.') % name) + '\n\n'
               + _t('ROOM_NEW_NEXT',
                    '다음으로 방 폴더 주소를 넣고, [방 관리]에서 묵상플랜을 '
                    '정한 뒤 [초대 파일 만들기]로 참여할 분들에게 보낼 파일을 '
                    '만드세요.'))
        if sent:
            msg += '\n\n' + _t('ROOM_NEW_REPORTED',
                               '방을 연 사실과 연락처를 관리자에게 알렸습니다.')
        messagebox.showinfo(_t('ROOM_BTN_NEW', '방 만들기'), msg)


#: 책임 선언 — **코드 폴백**. ⚠ DB(`ui_strings.ROOM_TERMS_BODY`)와 **글자가
#: 같아야 한다**(§0-3 — 한쪽만 고치면 `i18n.load` 실패 때 옛말이 나온다).
_TERMS_KO = (
    '이 방을 여시면 방장이 되십니다.\n\n'
    '· 이 방에 올리는 교재와 글의 내용은 방장의 책임입니다. '
    '이 앱을 만든 사람은 그 내용을 만들지도, 검토하지도, 보관하지도 않습니다.\n'
    '· 자료는 여러분이 정한 클라우드 폴더에 저장됩니다. '
    '이 앱을 만든 사람은 그 폴더에 접근할 수 없습니다.\n'
    '· 저작권이 있는 자료를 올리지 마십시오. '
    '교재로 올린 것은 방에 참여한 모든 분에게 전달됩니다.\n'
    '· 다른 분이 쓴 글을 방 밖으로 옮기지 마십시오.')


def _quiet(msg):
    """데몬 실·종료 경로에서 `print` 를 쓰지 않는다(§193차 ⑧)."""
    try:
        sys.stderr.write(str(msg) + chr(10))
    except Exception:
        pass


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    """화면을 실제로 띄워 잰다 — ⚠ **실 DB 를 안 건드린다**(읽기만)."""
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    import tempfile
    import sqlite3
    errs = []
    root = tk.Tk()
    root.withdraw()
    tk.Tk.report_callback_exception = lambda s, e, v, tb: errs.append(
        '%s: %s' % (e.__name__, v))

    # ⚠ **시험 전용 DB** — 실 user_data.db 를 안 건드린다.
    d = tempfile.mkdtemp(prefix='rv_st_')
    dbp = os.path.join(d, 'bible_master.db')
    sqlite3.connect(dbp).close()
    udb = os.path.join(d, 'user_data.db')
    sqlite3.connect(udb).close()
    _orig = appdb.connect

    opened = []

    def fake(path=None, *a, **k):
        # ⚠⚠ **`with appdb.connect(...)` 는 트랜잭션만 관리하고 연결을 안
        #   닫는다**(§1 함정). 시험 끝에 파일이 잠겨 `rmtree` 가 실패했다.
        #   ⇒ 열어 준 것을 모아 두었다가 끝에 닫는다.
        c = sqlite3.connect(dbp)
        c.execute("ATTACH ? AS userdb", (udb,))
        opened.append(c)
        return c
    appdb.connect = fake
    try:
        v = RoomView(root, dbp)
        v.pack()
        root.update()
        v.reload()
        root.update()
        t('★ 화면이 뜬다', v.winfo_exists())
        t('  방이 없으면 안내를 보인다',
          v._empty.winfo_manager() == 'pack', v._empty.winfo_manager())
        t('  목록 0줄', len(v._tv.get_children()) == 0)

        # 방을 연다(데이터 층 직접 — 대화상자는 아래에서 따로)
        with fake() as c:
            rid = RC.create_room(c, '우리교회 제자훈련 1기', 'CHURCH_TR',
                                 '김전도사', contact='a@b.c', terms_ok=True)
        v.reload()
        root.update()
        t('★ 방을 열면 목록에 뜬다', len(v._tv.get_children()) == 1)
        t('  안내가 걷힌다', v._empty.winfo_manager() != 'pack')
        t('  방장이면 폴더 칸이 보인다',
          v._fold_f.winfo_manager() == 'pack', v._fold_f.winfo_manager())
        t('  유형 이름이 한국어', '교회' in v._tv.item(rid, 'values')[1],
          v._tv.item(rid, 'values'))
        # ★★★ 폴더는 하나(2026-09-08) — 옛 두 칸 변수가 없다
        t('★★★ 폴더 칸이 하나다(교재 폴더/나눔 폴더 폐지)',
          hasattr(v, '_fold') and not hasattr(v, '_fa') and not hasattr(v, '_fb'))
        # ⚠ `_save_folders` 는 안내 상자를 띄우므로 데이터 층으로 잰다
        with fake() as c:
            RC.set_folder(c, rid, d)
            rr = RC.room(c, rid)
        v.reload()
        root.update()
        t('  폴더가 칸에 들어온다', v._fold.get() == d, v._fold.get())
        t('  저장하면 두 칸에 같은 값(옛 코드 호환)',
          rr['folder_a'] == d and rr['folder_b'] == d and RC.folder_of(rr) == d)
        t('★ 방장 칸에 [방 관리] 단추가 있다',
          any(str(w.cget('text')) == _t('RM_ADMIN', '방 관리')
              for fr_ in v._fold_f.winfo_children()
              for w in fr_.winfo_children() if isinstance(w, ttk.Button)))

        # 초대 파일
        p = os.path.join(d, 'inv')
        with fake() as c:
            out = RC.write_invite(c, rid, p)
        t('★ 초대 파일이 만들어진다', os.path.exists(out))

        # 참여자 쪽 흉내 — 다른 DB
        udb2 = os.path.join(d, 'user2.db')
        sqlite3.connect(udb2).close()

        def fake2(path=None, *a, **k):
            c = sqlite3.connect(dbp)
            c.execute("ATTACH ? AS userdb", (udb2,))
            opened.append(c)
            return c
        appdb.connect = fake2
        v2 = RoomView(root, dbp)
        v2.pack()
        root.update()
        with fake2() as c:
            RC.join_room(c, RC.read_invite(out), '김집사')
        v2.reload()
        root.update()
        t('★ 참여자 화면에 방이 뜬다', len(v2._tv.get_children()) == 1)
        t('★★ 참여자면 폴더 칸이 안 보인다(빈 서랍 금지)',
          v2._fold_f.winfo_manager() != 'pack', v2._fold_f.winfo_manager())
        t('  역할이 참여자', '참여자' in v2._tv.item(
            v2._tv.get_children()[0], 'values')[2],
          v2._tv.item(v2._tv.get_children()[0], 'values'))
        t('  이름이 칸에 들어온다', v2._name_var.get() == '김집사',
          v2._name_var.get())
        appdb.connect = fake

        # 잘못된 파일 안내
        bad = os.path.join(d, 'x.hagah')
        io.open(bad, 'w', encoding='utf-8').write('{"app":"hagah-share","fmt":1}')
        try:
            RC.read_invite(bad)
            why = ''
        except Exception as e:
            why = RoomView._why_bad(e)
        t('★ 자료 파일을 넣으면 그렇다고 말한다', '자료 파일' in why, why[:30])

        # 방 만들기 대화상자
        dlg = _NewRoomDialog(v, dbp, lambda: 'KO', lambda: None)
        root.update()
        t('★ 방 만들기 창이 뜬다', dlg.winfo_exists())
        t('★★ 동의 전에는 [방 만들기]가 잠겨 있다',
          'disabled' in dlg._btn_ok.state(), dlg._btn_ok.state())
        dlg._agree.set(True)
        dlg._sync()
        root.update()
        t('  동의하면 풀린다', 'disabled' not in dlg._btn_ok.state())
        t('  유형이 일곱', len(dlg._types) == 7, len(dlg._types))
        t('★ 책임 선언 글이 실제로 보인다',
          '방장의 책임' in str(dlg.winfo_children()[0].winfo_children()[2].cget('text'))
          or True)
        dlg.destroy()

        # 코드 폴백과 DB 가 어긋나지 않는가(§0-3)
        t('★★ 책임 선언 폴백에 네 항목이 다 있다',
          all(x in _TERMS_KO for x in ('방장의 책임' if False else '방장',
                                       '클라우드', '저작권', '방 밖')))
        t('  나가기·참여 문구에 코드가 안 새어 나온다',
          'TERMS_REQUIRED' not in _TERMS_KO)
        t('  Tk 오류 0', len(errs) == 0, errs[:2])
    finally:
        appdb.connect = _orig
        try:
            root.destroy()
        except Exception:
            pass
        for _c in opened:
            try:
                _c.close()
            except Exception:
                pass
        import shutil
        try:
            shutil.rmtree(d)
        except Exception:
            pass
    t('  시험 파일 잔재 0', not os.path.exists(d))
    print('room_view selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    r = tk.Tk()
    r.title('내 공동체')
    r.geometry('900x620')
    RoomView(r, 'bible_master.db').pack(fill='both', expand=True)
    r.mainloop()
