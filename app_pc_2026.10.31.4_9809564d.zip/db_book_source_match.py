# -*- coding: utf-8 -*-
"""
db_book_source_match.py — **DB 의 원문이 진짜 그 책인가** (2026-08-22 신설·영구)
================================================================================
`python db_book_source_match.py --selftest`        — 의무
`python db_book_source_match.py --fetch [CODE…]`   — **지금 새로** 내려받는다
`python db_book_source_match.py --match [CODE…]`   — 대조하고 판정
`python db_book_source_match.py --report`          — 표로 정리

━━ 왜 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★★★ 바운즈 『기도의 능력』 20장 중 **한 장도 저자의 글이 아니었다**
  (2026-08-22). 원인 = `참고코드/db_book_bounds.py` 가 **원문을 받지 않고
  본문을 스크립트 안에 글자로 적어** 넣었다. 그리고 「— E.M. Bounds,
  Power Through Prayer (1907)」라는 출처를 붙였다.
  사용자 지적: *"도대체 아무것도 신뢰할 수 없다 · 네 기록을 의지하지 마라 ·
  다운로드 자료가 구텐베르크 또는 ccel 자료와 일치하는지 비교하라"*.

⚠ 기존 `db_book_provenance.py` 는 스스로 **「판본 확인과 표본 대조는 기계가
  못 한다」**고 적어 두었다. **그것이 이 사고를 통과시킨 구멍이다.**
  받아서 대조하면 기계가 할 수 있다. 이 도구가 그 일을 한다.

━━ 무엇을 기준으로 판정하는가 (중요) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
**내 기록(CLAUDE.md·스크립트 주석·`_raw/` 에 이미 있는 파일)을 기준으로 삼지
않는다.** 세 겹으로 확인한다.

  ① **지금 새로 받는다.** 디스크에 있던 파일은 안 쓴다 — 그것도 지어낸
     것일 수 있다. 받을 때마다 `_verify_raw/` 에 새로 쓴다.
  ② **파일이 스스로 밝히는 제목·저자**가 DB 기록과 맞는가. CCEL 은 머리에
     `Title:` / `Creator(s):`, 구텐베르크는 `Title:` / `Author:` 를 적는다.
     ⇒ **내가 정한 짝이 아니라 파일이 스스로 말하는 것**으로 확인한다.
     안 맞으면 그 후보는 버린다(엉뚱한 책과 대조하면 무의미하다).
  ③ **문장 포함 검사.** DB 의 `ORIGINAL` 문장이 그 원문 안에 실제로 있는가
     (`db_book_verify` 와 같은 방법 — 정규화 후 창 대조).

가능하면 **CCEL 과 구텐베르크 둘 다** 받아 서로 대조한다. 둘이 서로 일치하면
소스 자체를 믿을 수 있고, 어긋나면 **사람이 봐야 한다.**

⚠ **`MODERN_EN`·`TRANSLATED`·`SUMMARY` 는 이 검사 대상이 아니다.** 그것은
  모델이 다듬어 쓰는 것이 정상이고 출처 줄에 그렇게 밝힌다(§17-4b).
  **`ORIGINAL` 만** 원문에서 와야 한다.
"""
import io
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import db_book_verify as V

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_verify_raw')
CAT = os.path.join(HERE, '_verify_raw', 'sources.json')

GENUINE, PARTIAL = 0.85, 0.15


def _cands(url, code):
    """DB 의 `source_url` 에서 **글 파일 주소 후보**를 만든다.

    ⚠ 그 URL 도 내 기록이라 믿지 않는다 — 받아서 ②로 확인한다."""
    out = []
    u = (url or '').strip()
    m = re.search(r'gutenberg\.org/ebooks/(\d+)', u)
    if m:
        n = m.group(1)
        out += ['https://www.gutenberg.org/cache/epub/%s/pg%s.txt' % (n, n),
                'https://www.gutenberg.org/files/%s/%s-0.txt' % (n, n),
                'https://www.gutenberg.org/files/%s/%s.txt' % (n, n)]
    m = re.search(r'ccel\.org/ccel/([^/\s]+)/([^/\s.]+)', u)
    if m:
        a, w = m.group(1), m.group(2)
        out += ['https://ccel.org/ccel/%s/%s/cache/%s.txt' % (a, w, w),
                'https://ccel.org/ccel/%s/cache/%s.txt' % (a, w)]
    return out


# ── ★★★ 받기 **전에** 링크를 보인다 — 사용자 지침 (2026-08-22) ───────────────
# 사용자: *"다운로드 하기 전에 먼저 나에게 링크를 표시하라"* · *"반드시 사전에
# 링크 보여주는 것을 지침으로 정하라"*.
# ⚠ 이 지침이 **지침으로만 있던 동안 두 번 빠졌다**(바운즈 · 로렌스). 그래서
#   문서가 아니라 **코드가 막는다** — 확인 없이 받으면 예외가 난다.
_ACK_FLAG = '--links-confirmed'


def show_links(code, cands, note=''):
    """후보 주소를 사람이 열어 볼 수 있게 늘어놓는다. **받기 전에 부른다.**"""
    print('%s — 받으려는 곳 (열어서 확인하십시오)' % code)
    for i, c in enumerate(cands, 1):
        if isinstance(c, (tuple, list)):
            name, url = c[0], c[-1]
        else:
            name, url = '', c
        print('   %d) %-28.28s %s' % (i, name, url))
    if note:
        print('   %s' % note)
    print('   확인하실 것 — 판권장(출판사·연도) · 제목·저자 · **저작권 표시**')
    print('   ⚠ 구텐베르크 파일은 머리에 `COPYRIGHTED` 가 있는지 본다 —'
          ' 있으면 퍼블릭 도메인이 아니다.')
    print('   확인하셨으면 같은 명령에 %s 를 붙여 다시 부르십시오.' % _ACK_FLAG)


def require_ack(code, cands, argv=None, note=''):
    """확인을 받지 않았으면 **받지 않는다.**"""
    argv = sys.argv[1:] if argv is None else argv
    if _ACK_FLAG in argv:
        return True
    show_links(code, cands, note)
    raise SystemExit(
        '[%s] 링크 확인 전이다 — 내려받지 않는다.\n'
        '        (사용자 지침 2026-08-22: 받기 전에 반드시 링크를 보인다)' % code)


# ── 출처를 **DB 에** 남긴다 (2026-08-22 사용자 지시) ──────────────────────────
# 사용자: *"db의 어디에든지 관리자가 볼 수 있도록 url을 추가하자. 네가 나중에
# 확인할 수 있도록 하자. **파일로 저장하는 것은 불완전하다**"*.
# ⚠ `sys_book_asset.source_url` 은 **칸이 하나**라 한 곳밖에 못 담는다. 그런데
#   실제로는 여러 곳이다 — 천로역정 1부는 #131, 2부는 #6048 이고, 대조에 쓴
#   곳과 **버린 후보**(왜 버렸는지)도 남겨야 다음 사람이 같은 삽질을 안 한다.
SRC_TABLE = 'sys_book_source'
ROLES = ('PRIMARY', 'CROSS', 'REJECTED')   # 본문을 받은 곳 / 대조용 / 버린 것


def init_source_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            src_id        INTEGER PRIMARY KEY AUTOINCREMENT,
            book_code     TEXT NOT NULL,
            role          TEXT NOT NULL,
            name          TEXT,
            url           TEXT,
            note          TEXT,
            match_pct     INTEGER,
            checked_at    TEXT,
            record_status TEXT DEFAULT 'LIVE')""" % SRC_TABLE)
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_%s_uni "
                 " ON %s(book_code, url)" % (SRC_TABLE, SRC_TABLE))


def record_source(conn, book_code, role, name, url, note='', match_pct=None,
                  when=None):
    """한 줄을 남긴다 — 멱등(같은 책·같은 주소면 덮어쓴다)."""
    if role not in ROLES:
        raise ValueError('role 은 %s 중 하나' % (ROLES,))
    init_source_table(conn)
    hit = conn.execute("SELECT src_id FROM %s WHERE book_code=? AND url=?"
                       % SRC_TABLE, (book_code, url)).fetchone()
    if hit:
        conn.execute("UPDATE %s SET role=?, name=?, note=?, match_pct=?,"
                     " checked_at=?, record_status='LIVE' WHERE src_id=?"
                     % SRC_TABLE,
                     (role, name, note, match_pct, when, hit[0]))
    else:
        conn.execute("INSERT INTO %s(book_code,role,name,url,note,match_pct,"
                     "checked_at,record_status) VALUES(?,?,?,?,?,?,?,'LIVE')"
                     % SRC_TABLE,
                     (book_code, role, name, url, note, match_pct, when))


def list_sources(conn, code=None):
    init_source_table(conn)
    sql = ("SELECT book_code, role, name, url, note, match_pct, checked_at "
           "  FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'" % SRC_TABLE)
    args = ()
    if code:
        sql += " AND book_code=?"
        args = (code,)
    return conn.execute(sql + " ORDER BY book_code, role DESC, src_id",
                        args).fetchall()


def _ack_selftest():
    """링크 지침이 실제로 막는가 — **양방향**으로 잰다."""
    fails = []
    cands = [('어느 곳', 'https://example.org/a.txt')]
    try:
        require_ack('X', cands, argv=[])
        fails.append('확인 없이 통과했다')
    except SystemExit:
        pass
    try:
        ok = require_ack('X', cands, argv=[_ACK_FLAG])
        if not ok:
            fails.append('확인했는데 안 통과한다')
    except SystemExit:
        fails.append('확인했는데 막힌다')
    return fails


def fetch_one(code, urls):
    """후보를 차례로 받아 **쓸 만한 것**을 남긴다. 돌려주는 것은 경로 목록."""
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    got = []
    for i, u in enumerate(urls):
        p = os.path.join(RAW, '%s_%d.txt' % (code, i))
        subprocess.run(['curl', '-sL', '--max-time', '90', '-o', p, u],
                       capture_output=True)
        if not os.path.exists(p):
            continue
        sz = os.path.getsize(p)
        head = io.open(p, encoding='utf-8', errors='replace').read(400)
        if sz < 20000 or '<html' in head.lower() or '503' in head[:80]:
            os.remove(p)
            print('    x %-70s (%d bytes)' % (u[:68], sz))
            continue
        print('    O %-70s (%s bytes)' % (u[:68], format(sz, ',')))
        got.append((u, p))
    return got


def declared(path):
    """**파일이 스스로 밝히는** 제목·저자. 내 기록이 아니다."""
    s = io.open(path, encoding='utf-8', errors='replace').read(6000)
    t = a = ''
    for pat in (r'^\s*Title:\s*(.+)$', r'^\s*TITLE:\s*(.+)$'):
        m = re.search(pat, s, re.M)
        if m:
            t = m.group(1).strip()
            break
    for pat in (r'^\s*Creator\(s\):\s*(.+)$', r'^\s*Author:\s*(.+)$',
                r'^\s*AUTHOR:\s*(.+)$'):
        m = re.search(pat, s, re.M)
        if m:
            a = m.group(1).strip()
            break
    return t, a


def _words(t):
    return set(re.findall(r'[a-z]{3,}', (t or '').lower()))


def meta_ok(db_title, db_author, src_title, src_author):
    """①과 ②가 맞는가 — 낱말 겹침으로 본다(표기가 조금씩 다르다)."""
    if not src_title:
        return False, '원문이 제목을 안 밝힌다'
    dt, st = _words(db_title), _words(src_title)
    stop = {'the', 'of', 'and', 'a', 'an', 'to', 'in', 'on'}
    dt, st = dt - stop, st - stop
    if not dt or not st:
        return False, '제목을 견줄 수 없다'
    ov = len(dt & st) / min(len(dt), len(st))
    if ov < 0.5:
        return False, '제목이 다르다: %r vs %r' % (db_title, src_title)
    da, sa = _words(db_author), _words(src_author)
    if da and sa and not (da & sa):
        return False, '저자가 다르다: %r vs %r' % (db_author, src_author)
    return True, ''


def match_book(conn, code, path):
    """③ 문장 포함 검사."""
    src = io.open(path, encoding='utf-8', errors='replace').read()
    rows, _ = V.scan(conn, code, src, variant='ORIGINAL')
    n = sum(r['n'] for r in rows)
    h = sum(r['hit'] for r in rows)
    return n, h, (h / n if n else 0.0), rows


# ── ★★★ 두 곳 일치 규칙 — **적재의 문지기** ────────────────────────────────
# 사용자 지시(2026-08-22): *"권위있는 사이트 2곳 이상 일치하는 것만 다운로드
# 하라"*. 이유는 실제로 겪었다 — 적어 둔 구텐베르크 번호 16905 가 『The Great
# Red Frog』였다. **한 곳만 보면 엉뚱한 책을 원문으로 삼는다.**
CROSS_MIN = 0.80        # 두 원문이 이만큼은 서로 같아야 한다
SAMPLE = 200            # 대조할 문장 수


def crosscheck(text_a, text_b, sample=SAMPLE):
    """두 원문이 **서로** 같은 글인가 → (a→b 비율, b→a 비율, 문장 수).

    ⚠ 한 방향만 보면 안 된다 — 발췌본은 전체본 안에 다 들어 있어 100% 가
      나오지만 그 반대는 낮다. **양방향**을 본다."""
    NA, NB = V.norm(text_a), V.norm(text_b)
    sa = [s for s in V.sentences(text_a) if len(s) > 60][:sample]
    sb = [s for s in V.sentences(text_b) if len(s) > 60][:sample]
    ab = sum(1 for s in sa if V.found_in(s, NB)) / max(1, len(sa))
    ba = sum(1 for s in sb if V.found_in(s, NA)) / max(1, len(sb))
    return ab, ba, (len(sa), len(sb))


def gate(book_code, files, verbose=True):
    """**두 곳 이상이 서로 일치해야 통과.** 아니면 예외를 던진다.

    `files` = [(이름, 경로)] — 각각 다른 기관에서 받은 원문.
    ⚠ 이 문을 우회하는 적재 도구를 만들지 말 것. 지어낸 본문이 들어간 사고
      (바운즈 2026-08-22)의 재발을 막는 유일한 장치다.
    """
    if len(files) < 2:
        raise SystemExit(
            '[%s] 원문이 %d곳뿐이다 — **권위 있는 두 곳 이상**에서 받아야 한다.\n'
            '        (사용자 규칙 2026-08-22. 한 곳만 보면 엉뚱한 책을 원문으로 삼는다)'
            % (book_code, len(files)))
    texts = []
    for name, p in files:
        t = io.open(p, encoding='utf-8', errors='replace').read()
        if len(t) < 20000:
            raise SystemExit('[%s] %s 가 너무 작다 (%d자) — 받다 만 것이다'
                             % (book_code, name, len(t)))
        texts.append((name, t))
    worst = 1.0
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            (na, ta), (nb, tb) = texts[i], texts[j]
            ab, ba, cnt = crosscheck(ta, tb)
            worst = min(worst, ab, ba)
            if verbose:
                print('  %s ↔ %s : %.0f%% / %.0f%%  (문장 %d·%d)'
                      % (na, nb, ab * 100, ba * 100, cnt[0], cnt[1]))
            if min(ab, ba) < CROSS_MIN:
                raise SystemExit(
                    '[%s] 두 원문이 서로 다르다 (%s ↔ %s : %.0f%% / %.0f%%).\n'
                    '        **사람이 봐야 한다** — 판본이 다르거나 한쪽이 엉뚱한 책이다.'
                    % (book_code, na, nb, ab * 100, ba * 100))
    if verbose:
        print('  ⇒ 두 곳 일치 확인 (가장 낮은 쪽 %.0f%% ≥ %.0f%%)'
              % (worst * 100, CROSS_MIN * 100))
    return worst


def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        if not cond:
            ok = False

    # ① 후보 주소 만들기
    c = _cands('https://www.gutenberg.org/ebooks/16905', 'X')
    chk('구텐베르크 후보', any('pg16905.txt' in x for x in c), c[:1])
    c = _cands('https://ccel.org/ccel/murray/abide', 'X')
    chk('CCEL 후보', any('abide/cache/abide.txt' in x for x in c), c[:1])

    # ①-2 링크 지침 — 확인 전에는 받지 못해야 한다
    for m in _ack_selftest():
        chk('링크 지침: ' + m, False)
    chk('링크 지침이 막고 열어 준다', not _ack_selftest())

    # ② 제목·저자 대조 — **엉뚱한 책을 걸러야 한다**
    good, _ = meta_ok('Power Through Prayer', 'E.M. Bounds',
                      'Power Through Prayer', 'Bounds, Edward M. (1835-1913)')
    chk('같은 책은 통과', good)
    bad, why = meta_ok('Power Through Prayer', 'E.M. Bounds',
                       'The Pilgrim\'s Progress', 'Bunyan, John')
    chk('다른 책은 막는다', not bad, why)
    bad2, why2 = meta_ok('Abide in Christ', 'Andrew Murray',
                         'Abide in Christ', 'Spurgeon, Charles')
    chk('저자가 다르면 막는다', not bad2, why2)
    bad3, _ = meta_ok('X', 'Y', '', '')
    chk('제목을 안 밝히면 막는다', not bad3)

    # ③ 표기 차이는 통과해야 한다(헛 실패 방지)
    g, _ = meta_ok("The Christian's Secret of a Happy Life", 'Hannah Whitall Smith',
                   "The Christian's Secret of a Happy Life",
                   'Smith, Hannah Whitall (1832-1911)')
    chk('표기가 달라도 통과', g)

    # ④ ★ 두 곳 일치 문지기 — **막아야 할 것을 막는가**
    import tempfile
    def tmp(txt):
        f = tempfile.NamedTemporaryFile('w', suffix='.txt', delete=False,
                                        encoding='utf-8')
        f.write(txt); f.close()
        return f.name
    # ⚠ 문지기가 「20,000자 미만 = 받다 만 것」으로 막으므로 표본도 그만큼 크게
    base = ' '.join('This is sentence number %d about prayer and the church '
                    'and the men whom God is looking for today.' % i
                    for i in range(240))
    other = ' '.join('A frog of great size and red colour sat upon the stone '
                     'beside the river in the land of number %d.' % i
                     for i in range(240))
    pa, pb, pc = tmp(base), tmp(base + ' extra tail. '), tmp(other)
    try:
        chk('한 곳뿐이면 막는다',
            _raises(lambda: gate('X', [('A', pa)], verbose=False)))
        chk('같은 글 두 곳은 통과',
            gate('X', [('A', pa), ('B', pb)], verbose=False) >= CROSS_MIN)
        chk('다른 책이면 막는다',
            _raises(lambda: gate('X', [('A', pa), ('C', pc)], verbose=False)))
        small = tmp('짧다')
        chk('받다 만 파일은 막는다',
            _raises(lambda: gate('X', [('A', pa), ('S', small)], verbose=False)))
        os.remove(small)
    finally:
        for p in (pa, pb, pc):
            try:
                os.remove(p)
            except Exception:
                pass
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _raises(fn):
    try:
        fn()
        return False
    except SystemExit:
        return True


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    only = [a for a in args if re.match(r'^[A-Z][A-Z0-9_]{3,}$', a)]
    conn = appdb.connect()
    books = conn.execute(
        "SELECT book_code, title, author, COALESCE(source_url,'') "
        "  FROM sys_book_asset ORDER BY book_id").fetchall()
    if only:
        books = [b for b in books if b[0] in only]

    cat = {}
    if os.path.exists(CAT):
        cat = json.load(io.open(CAT, encoding='utf-8'))

    if '--fetch' in args:
        for code, title, author, url in books:
            print('%s — %s' % (code, title))
            urls = _cands(url, code) + cat.get(code, {}).get('extra', [])
            if not urls:
                print('    (후보 주소 없음 — 사람이 찾아야 한다)')
                continue
            got = fetch_one(code, urls)
            ent = cat.setdefault(code, {})
            ent['files'] = []
            for u, p in got:
                t, a = declared(p)
                good, why = meta_ok(title, author, t, a)
                print('      스스로 밝힘 — 제목 %r · 저자 %r  %s'
                      % (t[:44], a[:30], 'OK' if good else '✗ ' + why))
                ent['files'].append({'url': u, 'path': os.path.basename(p),
                                     'title': t, 'author': a, 'meta_ok': good})
        if not os.path.isdir(RAW):
            os.makedirs(RAW)
        json.dump(cat, io.open(CAT, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=1)
        print('\n목록을 %s 에 적었다' % CAT)
        return

    if '--match' in args or '--report' in args:
        print('%-20s %-34s %6s %6s %6s  %s'
              % ('코드', '원문(스스로 밝힌 제목)', '문장', '일치', '비율', '판정'))
        for code, title, author, url in books:
            ent = cat.get(code) or {}
            files = [f for f in ent.get('files', []) if f.get('meta_ok')]
            if not files:
                print('%-20s %-34s %6s %6s %6s  %s'
                      % (code, '(맞는 원문을 못 받았다)', '-', '-', '-', '판정불가'))
                continue
            best = None
            for f in files:
                p = os.path.join(RAW, f['path'])
                if not os.path.exists(p):
                    continue
                n, h, r, _rows = match_book(conn, code, p)
                if best is None or r > best[2]:
                    best = (n, h, r, f)
            if best is None:
                print('%-20s %-34s %6s %6s %6s  %s'
                      % (code, '(파일 없음)', '-', '-', '-', '판정불가'))
                continue
            n, h, r, f = best
            v = ('진본' if r >= GENUINE else
                 ('위작' if r < PARTIAL else '일부'))
            print('%-20s %-34s %6d %6d %5.0f%%  %s'
                  % (code, f['title'][:32], n, h, r * 100, v))
        conn.close()
        return
    print(__doc__)


if __name__ == '__main__':
    main()
