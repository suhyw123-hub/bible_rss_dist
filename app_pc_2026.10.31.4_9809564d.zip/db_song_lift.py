# -*- coding: utf-8 -*-
"""찬양 구절연결을 **곡 층으로 올린다** — 1.txt 17번 「뿌리 고치기」.

★★★ **까닭 = 같은 곡인데 판마다 다르다.**
  실측(2026-09-25) — 구절연결이 하나라도 있는 곡 **40개 가운데 33개**가
  **판(영상)마다 붙은 구절이 달랐다**:

      神掌權  男聲D調 1절 · 女聲降B調 0절 · 教會聖詩 5절 · 歌詞MV 1절

  사용자가 짚은 그대로다 — 「거룩 영원히」가 마커스워십 판 0 · POD 판 7 ·
  스캇브래너 판 7. **곡은 하나인데 어느 판을 눌렀느냐가 답을 바꾼다.**

★★★ **뿌리 = 연결이 「곡」이 아니라 「영상」에 붙어 있다.**
  「이 노래가 이 구절을 노래한다」는 **곡의 성질**이지 그 업로드 하나의
  성질이 아니다. 그런데 연결기(제목·간접)는 영상마다 도므로 **판이 늘수록
  답이 갈린다.** 사람이 한 판에 손으로 이어도 다른 판은 모른다.

⇒ **곡 층(`SONG_VERS`)이 정본이다.** 이 도구가 **한 문**으로 그 층을 짓는다:
  그 곡에 딸린 모든 영상의 구절연결을 **합쳐** 곡에 적는다.

★★★ **읽는 쪽은 이미 곡 층을 본다** — `db_song.songs_of_verse` 가
  `SONG_VERS` 만 읽는다(P2 「찬양」 갈래). 지금까지 그 표에 **9줄**뿐이라
  그 화면이 사실상 비어 있었다. **문은 이미 있었고 재료가 없었다.**

⚠⚠ **영상 층(`MEDI_VERS`)은 안 건드린다.** 까닭 둘 —
  ⓐ 자동승인(`db_media_autoapprove` T2R·`run_term`)이 **영상의 구절연결**을
    보고 승인한다. 걷으면 앞으로 그 곡의 새 영상이 승인 문을 못 넘는다.
  ⓑ 「영상」 갈래는 영상 축이 맞다. **축이 다른 두 화면**이다.
  ⇒ 곡 층은 **영상 층에서 뽑아 낸 것**이고 고치는 문은 여기 하나다.
     두 벌로 손으로 적으면 반드시 갈린다.

⚠ **사람이 적은 곡 연결은 안 건드린다** — 이 도구가 지운 자리는
  `source LIKE 'LIFT:%'` 뿐이다(사람 줄 3 · 옛 승격 줄 6 은 그대로 둔다).

⚠⚠⚠ **닿는 범위가 좁다 — 숨기지 않고 적는다.** 실측 찬양 영상 3,578편
  가운데 **곡에 매인 것이 737편(21%)**이고, 구절연결까지 가진 것은
  **288건**뿐이다. 곧 이 도구는 **지금 40곡 96줄**을 만든다. 나머지는
  **곡 매칭이 없어서** 올릴 자리가 없는 것이지 규칙이 좁아서가 아니다.
  ⇒ **곡 매칭을 늘리는 것이 이 다음 일**이다(찬양 수집기 ③ 곡 잇기).

쓰는 법 — `--check`(안 건드린다) · `--apply` · `--undo` · `--selftest`.
"""
import sys

import appdb

DB = 'bible_master.db'

LINK_MEDI = 'MEDI_REND'      # 영상 → 판
LINK_VERS = 'SONG_VERS'      # 곡 → 구절
LINK_MV = 'MEDI_VERS'        # 영상 → 구절
T_REND = 'sys_song_rendition'

#: 이 도구가 만든 줄임을 말하는 표식 — `undo` 가 이것만 걷는다.
SRC_PREFIX = 'LIFT'

#: **근거의 무게** — 한 구절에 여러 영상이 저마다 다른 근거를 댈 때
#: 곡 줄에 어느 근거를 적을지 정한다(화면의 「추천근거」가 이것을 읽는다).
#: ⚠ 제목 근거가 가장 세다 — 실측 살아남은 비율 99%(설명문 0.3%).
_RANK = ('TITLE:', 'SONG:', 'SEED', 'DESC:', 'INDIRECT:')


def _rank(src):
    """근거 글자의 무게(작을수록 세다)."""
    s = (src or '').strip()
    for i, p in enumerate(_RANK):
        if s.startswith(p) or s == p:
            return i
    return len(_RANK) + (0 if s else 1)


def song_videos(conn):
    """{song_id: {media_id, …}} — 곡에 매인 **살아 있는** 영상."""
    out = {}
    for sid, mid in conn.execute(
            "SELECT r.song_id, l.clicked_id FROM sys_link_asset l"
            "  JOIN %s r ON r.rend_id=l.target_id"
            "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
            " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
            "   AND COALESCE(r.record_status,'LIVE')='LIVE'"
            "   AND m.record_status='LIVE'" % T_REND,
            (LINK_MEDI,)).fetchall():
        out.setdefault(sid, set()).add(mid)
    return out


def plan(conn):
    """곡 층에 **있어야 할** 줄 → {song_id: {(시작, 끝): 근거}}.

    ⚠ **사람이 뗀 영상 연결은 안 올린다** — `record_status` 가 LIVE 인 것만.
    """
    s2m = song_videos(conn)
    if not s2m:
        return {}
    mids = set()
    for v in s2m.values():
        mids |= v
    m2v = {}
    # ⚠ 영상이 수천이라 한 조회로 받는다(영상마다 물으면 그만큼 조회가 는다).
    for mid, tgt, end, src in conn.execute(
            "SELECT clicked_id, target_id, COALESCE(end_id, target_id),"
            "       COALESCE(source,'') FROM sys_link_asset"
            " WHERE link_type=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (LINK_MV,)).fetchall():
        if mid in mids:
            m2v.setdefault(mid, []).append((tgt, end, src))
    want = {}
    for sid, ms in s2m.items():
        acc = {}
        for mid in ms:
            for tgt, end, src in m2v.get(mid, ()):
                key = (tgt, end)
                if key not in acc or _rank(src) < _rank(acc[key]):
                    acc[key] = src
        if acc:
            want[sid] = acc
    return want


def _have(conn):
    """{(song_id, 시작, 끝): (번호, 내가 만든 것인가)} — 지금 곡 층."""
    out = {}
    for lid, sid, tgt, end, src in conn.execute(
            "SELECT sys_link_id, clicked_id, target_id,"
            "       COALESCE(end_id, target_id), COALESCE(source,'')"
            "  FROM sys_link_asset WHERE link_type=?",
            (LINK_VERS,)).fetchall():  # status-ok: 가림도 있는 줄이다
        out[(sid, tgt, end)] = (lid, src.startswith(SRC_PREFIX + ':'))
    return out


def sync(conn, dry=False):
    """곡 층을 영상 층에서 다시 짓는다 → {'add','keep','drop','songs'}.

    ⚠ **멱등** — 두 번 돌려도 행수가 그대로다(selftest 가 잰다).
    ⚠ **내가 만든 줄만 걷는다** — 사람 줄·옛 승격 줄은 그대로 둔다.
    """
    want, have = plan(conn), _have(conn)
    out = {'add': 0, 'keep': 0, 'drop': 0, 'songs': len(want)}
    for sid, acc in want.items():
        for (tgt, end), src in acc.items():
            k = (sid, tgt, end)
            if k in have:
                out['keep'] += 1
                continue
            out['add'] += 1
            if not dry:
                conn.execute(
                    "INSERT INTO sys_link_asset(link_type, clicked_id,"
                    " target_id, end_id, record_status, confidence, source)"
                    " VALUES(?,?,?,?,'LIVE','RULE',?)",
                    (LINK_VERS, sid, tgt, None if end == tgt else end,
                     '%s:%s' % (SRC_PREFIX, src or '-')))
    for (sid, tgt, end), (lid, mine) in have.items():
        if not mine:
            continue
        if (tgt, end) in want.get(sid, {}):
            continue
        out['drop'] += 1
        if not dry:
            conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?",
                         (lid,))
    if not dry:
        conn.commit()
    return out


def undo(conn):
    """이 도구가 만든 줄만 걷는다 → 지운 수."""
    cur = conn.execute(
        "DELETE FROM sys_link_asset WHERE link_type=? AND source LIKE ?",
        (LINK_VERS, SRC_PREFIX + ':%'))
    conn.commit()
    return cur.rowcount


def diverged(conn):
    """**판마다 답이 다른 곡** [(song_id, 영상 수, 서로 다른 조합 수)].

    ★ 이 도구가 고치려는 것이 이 수다 — `sync` 뒤에는 곡 층이 하나라
      화면에서 그 갈림이 사라진다(영상 층 수치는 그대로다).
    """
    s2m = song_videos(conn)
    m2v = {}
    for mid, tgt, end in conn.execute(
            "SELECT clicked_id, target_id, COALESCE(end_id, target_id)"
            "  FROM sys_link_asset WHERE link_type=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'",
            (LINK_MV,)).fetchall():
        m2v.setdefault(mid, set()).add((tgt, end))
    out = []
    for sid, ms in s2m.items():
        if len(ms) < 2 or not any(m2v.get(m) for m in ms):
            continue
        sets = {frozenset(m2v.get(m, ())) for m in ms}
        if len(sets) > 1:
            out.append((sid, len(ms), len(sets)))
    return sorted(out, key=lambda x: -x[1])


# ── 자가 검증 ────────────────────────────────────────────────────────
def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,
        link_type TEXT, clicked_id INT, target_id INT, end_id INT,
        record_status TEXT DEFAULT 'LIVE', confidence TEXT, note TEXT,
        source TEXT, rel_code TEXT);
      CREATE TABLE sys_song_rendition(rend_id INTEGER PRIMARY KEY,
        song_id INT, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,
        media_type TEXT, record_status TEXT DEFAULT 'LIVE');
    """)
    return c


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  OK   %s' % name)
        else:
            print('  FAIL %s %s' % (name, extra))

    t('근거 무게 — 제목이 간접보다 세다',
      _rank('TITLE:Jesus') < _rank('INDIRECT:319'))
    t('근거 무게 — 모르는 꼴도 자리가 있다', _rank('WEIRD:x') < 99)

    c = _mem()
    # 곡 1 = 판 10·11 / 영상 100(판10) · 101(판10) · 102(판11)
    for rid in (10, 11):
        c.execute("INSERT INTO sys_song_rendition(rend_id,song_id) VALUES(?,1)",
                  (rid,))
    c.execute("INSERT INTO sys_song_rendition(rend_id,song_id) VALUES(20,2)")
    for mid in (100, 101, 102, 200):
        c.execute("INSERT INTO sys_media_asset(media_id,media_type)"
                  " VALUES(?,'WORSHIP')", (mid,))
    for mid, rid in ((100, 10), (101, 10), (102, 11), (200, 20)):
        c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id)"
                  " VALUES('MEDI_REND',?,?)", (mid, rid))
    # 판마다 다르게 붙여 둔다 — 이것이 고치려는 상태다
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,source)"
              " VALUES('MEDI_VERS',100,500,'INDIRECT:9')")
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,source)"
              " VALUES('MEDI_VERS',102,501,'TITLE:Jesus')")
    # 같은 절을 다른 근거로 — 센 쪽이 남아야 한다
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,source)"
              " VALUES('MEDI_VERS',101,501,'DESC:가사')")
    # 사람이 뗀 것은 안 올라간다
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,"
              " record_status,confidence,source)"
              " VALUES('MEDI_VERS',100,900,'HIDE','MANUAL','TITLE:x')")

    t('★ 판마다 다른 곡을 찾는다', [x[0] for x in diverged(c)] == [1],
      diverged(c))

    r = sync(c)
    got = {(a, b) for a, b in c.execute(
        "SELECT target_id, source FROM sys_link_asset"
        " WHERE link_type='SONG_VERS' AND clicked_id=1")}
    t('★ 곡 층으로 합쳐진다(500·501)', {g[0] for g in got} == {500, 501}, got)
    t('★ 같은 절은 **센 근거**가 남는다(제목 > 설명문)',
      dict(got).get(501) == 'LIFT:TITLE:Jesus', got)
    t('★ 사람이 뗀 것은 안 올라간다', 900 not in {g[0] for g in got})
    t('영상이 없는 곡(2)은 줄이 안 생긴다',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                "'SONG_VERS' AND clicked_id=2").fetchone()[0] == 0)
    n1 = c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                   "'SONG_VERS'").fetchone()[0]
    r2 = sync(c)
    n2 = c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                   "'SONG_VERS'").fetchone()[0]
    t('★ 멱등 — 두 번 돌려도 행수가 그대로', n1 == n2 and r2['add'] == 0,
      (n1, n2, r2))

    # 사람이 적은 곡 줄은 안 건드린다
    c.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id,"
              " confidence) VALUES('SONG_VERS',1,777,'MANUAL')")
    sync(c)
    t('★ 사람이 적은 곡 줄은 **안 지운다**',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                "'SONG_VERS' AND target_id=777").fetchone()[0] == 1)

    # 영상 연결이 사라지면 곡 줄도 걷힌다
    c.execute("UPDATE sys_link_asset SET record_status='HIDE'"
              " WHERE link_type='MEDI_VERS' AND target_id=500")
    r3 = sync(c)
    t('★ 영상 연결이 사라지면 곡 줄도 걷힌다(500)',
      r3['drop'] == 1 and c.execute(
          "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='SONG_VERS'"
          " AND target_id=500").fetchone()[0] == 0, r3)

    n = undo(c)
    t('undo — 내가 만든 것만 걷는다(사람 줄 777 은 남는다)',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                "'SONG_VERS'").fetchone()[0] == 1, n)
    t('★ undo 뒤 다시 돌리면 되살아난다', sync(c)['add'] >= 1)
    c.close()

    print('db_song_lift selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if '--undo' in a:
            print('걷은 곡 연결 %d줄' % undo(conn))
            return
        dry = '--apply' not in a
        dv = diverged(conn)
        print('판마다 답이 다른 곡  %d개' % len(dv))
        r = sync(conn, dry=dry)
        print('곡 %d개 · 새로 %d · 그대로 %d · 걷음 %d%s'
              % (r['songs'], r['add'], r['keep'], r['drop'],
                 '   (미리보기 — `--apply` 를 주면 적용한다)' if dry else ''))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
