# -*- coding: utf-8 -*-
"""미디어 제목에서 **구절 구간**을 읽는다 — 구간 연결의 단일 소스.

★ 왜 만들었나 (2026-09-03 사용자 지시 — 「구절 구간 단위로 연결하도록 개선하라.
  수집로직, 연결로직을 정밀하게 수정하라」).
  그전 수집기는 **페리코프가 검색 단위이면서 곧 연결 대상**이었다
  (`db_media_crawler.insert_media(conn, r, pericope_id)`). 곧 연결의 근거가
  영상의 내용이 아니라 **「무슨 검색어로 찾았나」** 였다. 그래서
  · 「민수기 26장」 영상 하나가 그 장을 나눈 페리코프 16개에 **16줄**로 걸리고
  · 「여호수아 18장」 영상이 **수17장**에 걸리는 오연결이 생겼다(실측 27건).

★ 재료는 제목 안에 이미 있다 — 실측 **92%가 구간을 말한다**
  (승인분 1,040 중 958 · 절까지 745 · 장까지 213).

★ 규칙 셋
  ① **절 표기가 있으면 장 표기는 무시**한다 — 「Genesis 1:6-8」에서 「Genesis 1」
     을 또 읽으면 같은 대목이 두 번 나온다.
  ② **한 글자 약명(창·출·수·삿)은 숫자가 바로 붙을 때만** 책 이름으로 본다.
     그러지 않으면 보통 낱말이 책 이름으로 잘못 읽힌다(실측 159개가 한 글자).
  ③ **여럿 읽히면 고르지 않는다**(`MULTI`) — 「1 Samuel 27:1-12 and Romans
     13:1-7」처럼 두 대목을 다루는 설교가 있고, 「出埃及记４…（出埃及记12章）」
     처럼 **시리즈 번호가 장으로 잘못 읽히는** 자리도 있다. 기계가 고르면
     둘 중 하나에서 반드시 틀린다 ⇒ 사람에게 넘긴다(보관함).

★ 보관함 `sys_media_pending` — 구간을 못 정한 것을 **버리지 않고 담아 둔다**
  (사용자 지시 「82건같은 것을 담는 보관함을 페리코프, 엔티티 수집기에 각각
  만들어라」). 근거 없는 연결을 자동으로 만드는 것보다, 담아 두고 사람이
  구간을 정해 주는 편이 낫다.

CLI
  --selftest            자가 검증(의무)
  --init                보관함 표 만들기(멱등)
  --read "제목"          한 제목을 읽어 본다
  --scan [--active 0|1] 지금 걸린 것과 대조만(쓰기 없음)
  --normalize [--apply] 승인분 정상화(기본 미리보기)
  --undo                정상화 되돌리기
  --pending             보관함 현황
"""
from __future__ import annotations

import argparse
import re
import sqlite3
import sys

import appdb

DB = 'bible_master.db'
BACKUP = 'temp_media_range_backup'

# 구간을 못 정한 이유
R_NONE = 'NO_RANGE'    # 제목에 성경 좌표가 없다
R_MULTI = 'MULTI'      # 여러 대목이 읽혀 하나로 못 좁힌다
R_OFF = 'OFF'          # 읽은 구간이 지금 연결과 전혀 안 겹친다(사람이 본다)

_CACHE = {}


# ── 책 이름 표 ────────────────────────────────────────────────────────────────
def _books(conn):
    """(정식이름 표, **약명** 표) — 둘 다 {소문자이름: bcode}.

    ⚠⚠⚠ **약명은 길이와 무관하게 조건부다**(2026-09-03 오독 검거).
      그전에는 「한 글자만」 조건부였는데, 실측하니 **두세 글자 약명 16개가
      보통 낱말과 똑같다**: `Est`(에스더 EN/DE/FR/ES) = 프랑스어 「~이다」 ·
      `Le`(레위기 FR) = 관사 · `Job` · `Am` · `Is` · `So` · `Act` · `At` · `He`.
      실제로 「Theme: Le Royaume **est** la. Genese 3」이 **엉뚱한 절**로
      읽혔다. ⇒ **약명은 숫자가 바로 붙거나 장·절 표시가 따라올 때만** 본다.
      정식이름(`Genesis`·`창세기`)은 겹칠 일이 없어 자유롭게 본다.
    """
    key = id(conn)
    if key in _CACHE:
        return _CACHE[key]
    long_, short_ = {}, {}
    for bc, nm in conn.execute("SELECT book_code, full_name FROM book_names"
                               " WHERE full_name IS NOT NULL"):
        try:
            bc = int(bc)
        except (TypeError, ValueError):
            continue
        if nm and len(nm) >= 2:
            long_.setdefault(nm.lower(), bc)
    for bc, nm in conn.execute("SELECT book_code, short_name FROM book_names"
                               " WHERE short_name IS NOT NULL"):
        try:
            bc = int(bc)
        except (TypeError, ValueError):
            continue
        if nm and nm.lower() not in long_:
            short_.setdefault(nm.lower(), bc)
    # ★ **정식이름의 앞머리 중 그 책에만 유일한 것**을 약명에 합류시킨다
    #   (2026-09-03 — `Deut.`·`Matt.`·`Gen.` 같은 흔한 약칭이 book_names 에
    #   없어 통째로 안 읽혔다). 손으로 별칭 표를 적으면 언어마다 빠진다.
    #   ⚠ **충돌하면 버린다** — `Jo…` 처럼 여러 책이 같은 앞머리를 가지면
    #     어느 책인지 알 수 없다. ⚠ 약명과 **같은 조건부**로 쓴다.
    pref = {}
    for nm, bc in long_.items():
        for k in range(3, min(len(nm), 6) + 1):
            p = nm[:k]
            if p in pref and pref[p] != bc:
                pref[p] = None                 # 두 책이 같은 앞머리 — 버린다
            else:
                pref.setdefault(p, bc)
    for p, bc in pref.items():
        if bc and p not in long_:
            short_.setdefault(p, bc)
    _CACHE[key] = (long_, short_)
    return long_, short_


def _rx(conn):
    """(절 정규식, 장 정규식) — 책 이름이 많아 캐시한다."""
    key = ('rx', id(conn))
    if key in _CACHE:
        return _CACHE[key]
    long_, short_ = _books(conn)
    # ⚠ 긴 이름부터 — 「사사기」가 「사」로 먼저 잘리면 안 된다.
    lb = '|'.join(re.escape(b) for b in sorted(long_, key=len, reverse=True))
    sb = '|'.join(re.escape(b) for b in sorted(short_, key=len, reverse=True))
    # 한 글자 약명은 ① **숫자가 바로 뒤에** 오거나 ② 공백 뒤 숫자에
    # **장·편·절·쌍점**이 따라올 때만(「삿 13장」). 그냥 공백을 허용하면
    # 「창 3개」·「수 많은」 같은 보통 말이 책 이름으로 읽힌다.
    # ★ **책 이름과 숫자 사이의 「chapter·ch.·장」을 흘려보낸다**(2026-09-03
    #   보관함 실측 — 「Genesis Chapter 21 Explained」 꼴이 46건이었다).
    # ⚠ 구분 부호도 **하나까지** 흘려보낸다(「NUMBERS – Chapter 8」).
    #   부호만 있고 chapter 낱말이 없으면 안 걸리므로 안전하다 — 「Genesis -
    #   3 Days」 같은 것이 잘못 읽히지 않는다.
    mid = r'(?:\s*[-–—:·|]?\s*(?:chapters?|chap\.?|ch\.?|장|편|章)\s*)?'
    # ⚠ 약명 뒤의 **마침표를 소비**한다(`Ps. 23:1`) — 안 그러면 lookahead 가
    #   마침표에 걸려 흔한 약칭이 통째로 안 읽힌다(실측으로 잡았다).
    # ★★★ **약명 앞에 글자가 붙어 있으면 낱말 속이다**(2026-09-09 구절 연결 전수
    #   조사) — 「오전 11시」의 「전」이 전도서 11장으로, 「사도행전 2:1」의 「전」이
    #   전도서 2:1 로, 「수요 …」·「매주 수 19:30」의 「수」가 여호수아로 걸려 있었다
    #   (미검토 1,474건 중 제목에 좌표 없는 523건의 상당수). 긴 이름은 그대로,
    #   **짧은 약명만** 앞 글자(한글·라틴)를 거부한다.
    book = ('(?:(%s)\\s*\\.?\\s*|(?<![가-힣A-Za-z])(%s)\\.?(?=\\d|\\s+\\d{1,3}\\s*[장편章:：]))'
            '\\s*%s' % (lb, sb, mid))
    # ★ 장·절 구분이 **공백**인 꼴도 읽는다(「Genesis 28 1-5」) — 다만
    #   **뒤에 범위가 따라올 때만**. 그러지 않으면 「Genesis 28 The Promise」
    #   에서 28 과 엉뚱한 숫자를 절로 묶는다.
    verse = re.compile(
        book + r'(\d{1,3})\s*(?:[:：장]\s*(\d{1,3})|\s+(?=\d{1,3}\s*[-~–—]\s*\d)'
        r'(\d{1,3}))\s*(?:절)?'
        r'(?:\s*[-~–—]\s*(?:(\d{1,3})\s*[:：장]\s*)?(\d{1,3})\s*(?:절)?)?', re.I)
    chap = re.compile(
        book + r'(\d{1,3})\s*(?:[-~–—]\s*(\d{1,3}))?\s*(?:장|편|章)?(?!\s*[:：]?\s*\d)',
        re.I)
    # ★★ **이어지는 참조**(2026-09-03 사용자 지적 — 「창1:26-27, 2:1,7,8,20-24
    #   이런 것도 구절·구간 추천이 가능하다」). 표준 성경 표기다:
    #     `, 2:1` = 같은 책 2장 1절 · `, 7` = **같은 장** 7절 ·
    #     `, 20-24` = 같은 장 20~24절
    #   ⚠ **절 참조 뒤에만** 읽는다 — 장 참조(`창1장, 2`) 뒤에서는 그 2 가
    #     장인지 절인지 갈리므로 손대지 않는다.
    #   ⚠ 없는 절은 저절로 걸러진다(`창1:1, 100명` 의 100은 창1장에 없다).
    tail = re.compile(
        r'\s*[,;]\s*(?:(\d{1,3})\s*[:：]\s*)?(\d{1,3})'
        r'(?:\s*[-~–—]\s*(\d{1,3}))?')
    _CACHE[key] = (verse, chap, tail)
    return verse, chap, tail


def _vids(conn):
    key = ('vid', id(conn))
    if key in _CACHE:
        return _CACHE[key]
    v = {}
    last = {}
    for vid, b, c, s in conn.execute(
            "SELECT verse_id, bcode, chapter, verse FROM bible_index"):
        v[(b, c, s)] = vid
        if s > last.get((b, c), 0):
            last[(b, c)] = s
    _CACHE[key] = (v, last)
    return v, last


def _bc(m, long_, short_):
    nm = m.group(1) or m.group(2)
    if not nm:
        return None
    d = long_ if m.group(1) else short_
    return d.get(nm.lower())


# ── 읽기 ──────────────────────────────────────────────────────────────────────
def read(conn, title):
    """제목에서 읽은 구간 전부. [(bcode, start_vid, end_vid, kind), …].

    kind = 'VERSE'(절까지) | 'CHAP'(장 단위).
    ⚠ 절이 하나라도 읽히면 장 표기는 안 본다(같은 대목이 두 번 나온다).
    """
    if not title:
        return []
    long_, short_ = _books(conn)
    rxv, rxc, rxt = _rx(conn)
    v, last = _vids(conn)
    out = []
    seen = set()

    def _put(bc, c1, v1, c2, v2):
        s = v.get((bc, c1, v1))
        e = v.get((bc, c2, v2))
        if s and (not e or e < s):
            e = s
        if not s or (bc, s, e) in seen:
            return False
        seen.add((bc, s, e))
        out.append((bc, s, e, 'VERSE'))
        return True

    for m in rxv.finditer(title):
        bc = _bc(m, long_, short_)
        if not bc:
            continue
        # 그룹 = (긴이름, 한글자, 장, 절-쌍점꼴, 절-공백꼴, 끝장, 끝절)
        c1 = int(m.group(3))
        v1 = int(m.group(4) or m.group(5))
        c2 = int(m.group(6)) if m.group(6) else c1
        v2 = int(m.group(7)) if m.group(7) else v1
        _put(bc, c1, v1, c2, v2)
        # ★ **이어지는 참조를 계속 읽는다** — 「창1:26-27, 2:1,7,8,20-24」.
        #   책은 그대로, 장은 새로 나오면 갱신, 없으면 앞 장을 잇는다.
        pos, cur_ch = m.end(), c2
        while True:
            t2 = rxt.match(title, pos)
            if not t2:
                break
            if t2.group(1):
                cur_ch = int(t2.group(1))
            a = int(t2.group(2))
            b = int(t2.group(3)) if t2.group(3) else a
            if not _put(bc, cur_ch, a, cur_ch, b):
                break             # 없는 절이면 여기서 멈춘다(딴 숫자다)
            pos = t2.end()
    if out:
        return out

    for m in rxc.finditer(title):
        bc = _bc(m, long_, short_)
        if not bc:
            continue
        c1 = int(m.group(3))
        c2 = int(m.group(4)) if m.group(4) else c1
        if c2 < c1 or (bc, c2) not in last:
            c2 = c1
        mx = last.get((bc, c2))
        s = v.get((bc, c1, 1))
        e = v.get((bc, c2, mx)) if mx else None
        if not s or not e:
            continue
        if (bc, s, e) in seen:
            continue
        seen.add((bc, s, e))
        out.append((bc, s, e, 'CHAP'))
    return out


def pick(conn, title):
    """하나로 좁혀지면 (bcode, s, e, kind), 아니면 (None, 이유)."""
    got = read(conn, title)
    if not got:
        return None, R_NONE
    if len(got) > 1:
        return None, R_MULTI
    return got[0], None


def yt_desc(desc):
    """`sys_media_asset.description`(수집 메타 JSON)에서 영상 설명문만."""
    if not desc:
        return ''
    s = str(desc).strip()
    if not s.startswith('{'):
        return s
    try:
        import json as _j
        return (_j.loads(s) or {}).get('yt_desc') or ''
    except Exception:
        return ''


def book_name_entities(conn):
    """**성경책 이름과 똑같은 이름을 가진 엔티티**
    → {entity_id: (한국어 이름, bcode, **겹친 글자**, 그 언어)}.

    ★★★ 왜 (2026-09-04 사용자 지적 — 「학개 : 성경 인물이면서 **성경책 이름**.
      주요용어 영상링크에 **학개 강해설교가 연결됨**. 학개 인물에 대한 영상은
      하나도 없음」).
      실측 **16명에 409줄**이 걸려 있다(룻 56 · 마태 51 · 다니엘 34 …).
    ⚠⚠ **자동으로 뗄 수 없다** — 분류해 보니 셋으로 갈린다:
      · 제목에 그 인물 이름이 있다 179줄 — 정당할 수 있다
      · 다른 책 구간만 있다 57줄 — 오연결로 **보이지만** 「스가랴 성경공부
        (슥3:1-10)」가 여호수아에 걸린 것은 **정당하다**(슥3장이 대제사장
        여호수아다). **기계가 고르면 반드시 틀린다.**
      · 둘 다 없다 173줄 — 대부분 다른 언어 책 이름(`約書亞記`).
    ⇒ **판정하지 않는다.** 화면이 「이 용어는 책 이름과 같다」고 알리고
      사람이 그 마디를 훑어 뗀다(§보관함과 같은 원칙).
    ⚠ 언어를 가리지 않는다 — 어느 언어에서든 책 이름과 같으면 걸린다.
    """
    key = ('bookent', id(conn))
    if key in _CACHE:
        return _CACHE[key]
    # ⚠ 어느 언어의 어느 책과 겹치는지까지 들고 있어야 **화면이 오해를 안
    #   산다** — 「야곱」이 걸리는 것은 **아랍어 야고보서**(`يعقوب`)와 같아서다.
    #   그냥 「책 이름과 같습니다」라고만 하면 한국어 화면에서 말이 안 된다.
    books = {}
    # ⚠ **한국어 겹침을 먼저 본다** — 「학개」는 한국어에서도 책 이름인데
    #   `setdefault` 가 아무 언어나 먼저 집어 `(AR)` 로 표시됐다(실측).
    #   같은 글자가 여러 언어의 책 이름이면 **KO 가 이긴다**(화면이 한국어다).
    for bc, nm, lc in conn.execute(
            "SELECT book_code, full_name, lang_code FROM book_names"
            " WHERE full_name IS NOT NULL"
            " ORDER BY CASE WHEN lang_code='KO' THEN 0 ELSE 1 END, lang_code"):
        if nm and len(nm.strip()) >= 2:
            books.setdefault(nm.strip().lower(), (int(bc), lc))
    # ⚠⚠ **찾는 것은 모든 언어, 보이는 이름은 한국어**(2026-09-04 실측으로
    #   잡았다). 첫 실행이 `حجي`·`Römer` 같은 **아랍어·독일어 이름**을 냈다 —
    #   엔티티는 맞게 걸렸는데 조회 순서가 아무렇게나 와서 표시가 그랬다.
    #   ⇒ 걸린 뒤 **KO 이름으로 다시 읽는다**(없으면 걸린 그 이름).
    hit = {}
    # ⚠ **엔티티 이름 조회도 KO 우선** — 그러지 않으면 「학개」가 아랍어 이름
    #   `حجي` 로 먼저 걸려 화면에 `(AR)` 로 뜬다. 한국어에서도 책 이름인
    #   것은 **한국어 겹침으로 보여야** 사람이 곧 알아본다(실측으로 잡았다).
    for eid, nm in conn.execute(
            "SELECT t.clicked_id, t.contents FROM sys_text_asset t"
            " JOIN sys_entity_master em ON em.entity_id=t.clicked_id"
            " WHERE t.text_type='ENTITY_NAME' AND em.record_status='LIVE'"
            "   AND COALESCE(json_extract(em.json_detail,'$.subtype'),'')<>'LEX'"
            " ORDER BY CASE WHEN t.lang_code='KO' THEN 0 ELSE 1 END,"
            "          t.lang_code"):
        s = (nm or '').strip().lower()
        if s and s in books and eid not in hit:
            _bc, _lc = books[s]
            hit[eid] = ((nm or '').strip(), _bc, (nm or '').strip(), _lc)
    out = dict(hit)
    if hit:
        ids = list(hit)
        for eid, ko in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_NAME' AND lang_code='KO'"
                "   AND clicked_id IN (%s)" % ','.join('?' * len(ids)), ids):
            if ko and ko.strip():
                out[eid] = (ko.strip(),) + tuple(hit[eid][1:])
    _CACHE[key] = out
    return out


def purge_desc(conn, days=30, include_unknown=False, dry_run=True):
    """다 쓴 유튜브 설명문을 지운다 — **저장 원칙에 맞추는 자리**.

    ★★★ 사용자 지시(2026-09-04) — 「수집하고 승인한지 꽤 시간이 지났다고 하자.
      설명문 수집한 것을 보관할 이유가 없다 … **배포후 1월 지난 것은 더 이상
      설명문이 필요하지 않을 것 같다**」.
    ★ 근거는 실익이 아니라 **원칙**이다 — YouTube API 약관은 식별자
      (video ID·URL)를 뺀 메타데이터를 **30일 안에 갱신하거나 지우라**고 한다.
      우리는 다시 받을 이유가 없으니(내부 판정이 끝났고 사용자는 안 본다)
      **지우는 쪽이 맞다.**

    **지우는 조건 셋 — 모두 만족해야 한다**
      ① `is_active=1`  승인이 끝났다 = 구간·용어가 확정됐다
      ② 보관함에 없다   대기 중이면 다시 훑을 재료가 아직 필요하다
      ③ 수집 후 `days` 일이 지났다
    ⚠ **미검토분은 건드리지 않는다** — 검토 화면이 그 글에서 구간·용어를
      추천하므로, 지우면 사람이 판단할 재료가 사라진다. 미검토가 오래됐다면
      답은 「지우기」가 아니라 「검토를 마치기」다.
    ⚠ `yt_desc` **한 열쇠만** 지운다 — `channel` 은 채널 제외 판정에,
      `collected_at` 은 이 판정 자체에 쓰인다.
    ⚠ `include_unknown` — 수집 시각이 없는 옛 행까지 포함할지. **기본은 뺀다**
      (오래됐을 가능성이 크지만 단정할 수 없다. 사람이 켜서 정한다).

    → (지운 건수, 대상 media_id 목록). `dry_run` 이면 세기만 한다.
    """
    import json as _j
    from datetime import date as _date
    today = _date.today()
    pend = {r[0] for r in conn.execute(
        "SELECT media_id FROM sys_media_pending"
        " WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    hit = []
    for mid, des in conn.execute(
            "SELECT media_id, description FROM sys_media_asset"
            " WHERE is_active=1 AND description LIKE '%yt_desc%'"):
        if mid in pend:
            continue
        try:
            j = _j.loads(des)
        except Exception:
            continue
        if not isinstance(j, dict) or not (j.get('yt_desc') or ''):
            continue
        ca = j.get('collected_at') or ''
        try:
            age = (today - _date.fromisoformat(ca)).days
        except Exception:
            age = None
        if age is None:
            if not include_unknown:
                continue
        elif age < days:
            continue
        hit.append((mid, j))
    if dry_run:
        return len(hit), [m for m, _ in hit]
    for mid, j in hit:
        j.pop('yt_desc', None)
        conn.execute("UPDATE sys_media_asset SET description=?"
                     " WHERE media_id=?",
                     (_j.dumps(j, ensure_ascii=False), mid))
    conn.commit()
    return len(hit), [m for m, _ in hit]


def read2(conn, title, desc=None):
    """제목 → 설명문 차례로 읽는다. (구간목록, 출처).

    ★ **제목이 먼저다** — 설명문에는 채널 소개·다른 회차 안내가 섞여 있어
      먼저 보면 엉뚱한 대목이 잡힌다. 제목에서 하나로 좁혀지면 거기서 멈춘다.
    """
    got = read(conn, title)
    if len(got) == 1:
        return got, 'TITLE'
    body = yt_desc(desc)
    if body:
        g2 = read(conn, body)
        if len(g2) == 1:
            return g2, 'DESC'
        if not got and g2:
            return g2, 'DESC'
    return got, 'TITLE' if got else ''


def pick2(conn, title, desc=None):
    """제목·설명문을 함께 보고 하나로 좁힌다. ((bc,s,e,kind), 출처) 또는 (None, 이유)."""
    got, src = read2(conn, title, desc)
    if not got:
        return None, R_NONE
    if len(got) > 1:
        return None, R_MULTI
    return got[0], src


# ── 검토 실마리 ──────────────────────────────────────────────────────────────
_ENT_RX = {}


#: 한국어 조사·접미 첫 글자 — 이름 **뒤에** 이것이 오면 여전히 그 이름이다.
#: 「예수님」·「다윗이」·「모세가」. 이 집합 밖의 한글이 오면 **딴 낱말**이다
#: (「엘리야」의 「엘리」·「사라진」의 「사라」).
_KO_JOSA = set('은는이가을를의에와과도만께로으부터까지님씨들라야여하고서')

_LAT_MIN = 4          # 라틴 이름 최소 길이 — 아래 주석 참조


def _script(nm):
    """이름의 문자체계 — **첫 글자**가 정한다.

    ★★★ **낱말 경계라는 개념이 문자체계마다 다르다** (2026-09-08 실측).
      라틴은 공백으로 낱말이 갈리고, 한글은 조사가 붙으며, **CJK·가나·
      히브리·아랍은 낱말 사이에 경계가 없다.
    ⚠⚠ 그런데 파이썬 `isalpha()` 는 한자·가나도 참이라, 라틴 규칙을
      그대로 쓰면 `大衛` 가 **어느 중국어 제목에서도 안 걸린다**
      (실측 — CJK 이름 434개가 통째로 사라졌다).
    """
    for ch in nm:
        if '가' <= ch <= '힣':
            return 'KO'
        o = ord(ch)
        if 0x3040 <= o <= 0x30FF:
            return 'KANA'     # 가나 — 가타카나끼리 붙으면 긴 이름 속이다(아래)
        if (0x4E00 <= o <= 0x9FFF) or (0x0590 <= o <= 0x08FF):
            return 'CJK'      # 한자·히브리·아랍 — 경계가 없다
        if ch.isalpha():
            return 'LAT'
    return 'LAT'


def _ko_ok(text, s, e):
    """한글 이름이 그 자리에서 **낱말로** 쓰였는가.

    ★★★ **앞이 한글이면 거부**한다 — 조사·복합어 꼬리다(「방주에서」의
      「에서」). **뒤는 조사면 허용**한다 — 한국어는 이름 뒤에 조사가 붙는다.
    """
    if s > 0 and '가' <= text[s - 1] <= '힣':
        return False
    if e < len(text):
        nx = text[e]
        if '가' <= nx <= '힣' and nx not in _KO_JOSA:
            return False
    return True


def _lat_ok(text, s, e):
    """라틴 이름이 **낱말 경계**에 있는가(`Er` 이 `chapter` 에 안 걸린다)."""
    if s > 0 and (text[s - 1].isalpha() or text[s - 1] == "'"):
        return False
    if e < len(text) and text[e].isalpha():
        return False
    return True


def name_ok(text, s, e, nm):
    """`nm` 이 `text[s:e]` 자리에서 **이름으로 쓰였는가**.

    ★★★ **낱말 경계가 없어 3,400건이 잘못 걸려 있었다** (2026-09-04 실측).
      「엘」(EN 이름이 **`Er`**)이 `chapter`·`Better`·`Selman` 속에 걸려
      **2,716건** · 「에서」가 조사 `~에서` 로 **706건**.
      ⇒ 한글은 앞뒤를 보고, 라틴은 `\\b` 로 막는다.
    """
    sc = _script(nm)
    if sc == 'KO':
        return _ko_ok(text, s, e)
    if sc == 'LAT':
        return _lat_ok(text, s, e)
    if sc == 'KANA':
        return _kana_ok(text, s, e)
    return True                # 한자·히브리 — 경계 개념이 없다(긴 이름 우선은 링커가 맡는다)


# ★★★ 이름 앞뒤 문맥 — 「이름은 맞는데 성경 인물이 아니다」(2026-09-09 사용자 메모
#   「설교자 이름이 베드로 키윅이란다. 베드로 다음에 나오는 이름을 보면 성경 인물이
#   아니란 것을 알 수 있다」 · 「Pastor Elias Morkos … 엘리야가 아니라 목사 이름」).
#   실측(승인 영상의 인물 링크 8,518): 성직 호칭 앞 81(「Pastor David Guzik」) ·
#   라틴 성 뒤 194(「David Suchet」·「David Alley,」) · 「바로」가 부사(「바로 이 때」)
#   60 중 42. 성경 호칭(King David · 사도 바울 · Prophet Elisha)은 반대 신호라 가른다.
CLERGY_RX = re.compile(
    r'(?:pastor|pr\.|rev\.?|reverend|dr\.?|fr\.|padre|pasteur|pfarrer|bishop|evangelist|'
    r'brother|sister|elder|deacon|пастор|отец|брат|목사|전도사|장로|선교사|집사|권사|사모|'
    r'강도사|牧師|牧师|神父|傳道|传道|長老|长老|弟兄|姊妹|牧者)\s*$', re.I)
#: 라틴 이름 뒤 「대문자 낱말 + 부호·끝」 = 성(姓). ⚠ 제목이 Title Case 라 그냥 대문자
#: 낱말은 못 쓴다 — 부호·끝으로 닫힌 것만(「David Alley,」·「David Suchet」끝).
SURNAME_RX = re.compile(r'^\s+([A-ZÀ-Ý][a-zà-ÿ]{2,})\s*(?:[,.;:|)\]\-–—]|$)')
#: 성 판정은 **이름이 한 토막을 시작할 때만**(앞이 시작·부호·by/with/from/feat) —
#: 「Book of Haggai Summary:」·「Zerubbabel The Temple Builder」는 앞이 낱말이라 아니다.
SURNAME_PRE_RX = re.compile(r'(?:^|[,.;:|(\[\-–—/&]|(?<![A-Za-z])(?:by|with|from|feat\.?|ft\.?|host|speaker|guest|narrator|narrated by|read by))\s*$', re.I)
SURNAME_STOP = {'christ', 'bible', 'church', 'movie', 'story', 'sermon', 'ministries',
                'ministry', 'devotional', 'podcast', 'live', 'study', 'explained', 'full',
                'part', 'episode', 'series', 'chapter', 'verse', 'gospel', 'psalm', 'psalms',
                'himself', 'herself', 'today', 'tonight', 'now', 'again', 'alone', 'speaks',
                'song', 'songs', 'prayer', 'praise', 'worship', 'jesus', 'lord', 'god',
                'summary', 'overview', 'animated', 'complete', 'introduction', 'commentary',
                'teaching', 'lesson', 'message', 'documentary', 'film', 'review', 'timeline',
                'history', 'prophecy', 'prophecies', 'altar', 'builder', 'rebellion', 'king',
                'queen', 'prophet', 'apostle', 'saint', 'temple', 'church'}
#: 보통 낱말과 같은 이름 — **문맥이 있어야** 그 인물이다.
#: (제목·설명문 어디든 나오는 낱말 | 이름 바로 뒤 꼴)
CONTEXT_NEED = {
    '바로': (re.compile(r'애굽|이집트|출애굽|모세|요셉|열 재앙|홍해'),
            re.compile(r'^\s*(?:왕|의|에게|앞|와|과|가 |는 )')),
}


def name_context(text, s, e, term, person=True):
    """이름이 걸린 자리의 문맥 → None(괜찮다) | 'CLERGY' | 'SURNAME' | 'COMMON'.
    `text` 는 **원문(대소문자 그대로)** — 성 판정이 대문자를 본다.
    ⚠ 호칭·성 판정은 **인물**에만(`person`) — 「Golden Calf Altar,」·「Temple Builder」
      가 성으로 읽히지 않게. 보통 낱말 판정(`CONTEXT_NEED`)은 이름표로 건다."""
    pre = text[max(0, s - 24):s]
    post = text[e:]
    if person and CLERGY_RX.search(pre):
        return 'CLERGY'
    if person and _script(term) == 'LAT':
        m = SURNAME_RX.match(post)
        if m and m.group(1).lower() not in SURNAME_STOP and SURNAME_PRE_RX.search(pre):
            return 'SURNAME'
    need = CONTEXT_NEED.get(term)
    if need and not (need[0].search(text) or need[1].match(post)):
        return 'COMMON'
    return None


def _is_kata(ch):
    o = ord(ch)
    return (0x30A0 <= o <= 0x30FF) or ch == 'ー'


def _kana_ok(text, s, e):
    """가타카나 이름이 **낱말로** 쓰였는가 — 앞뒤가 가타카나면 긴 이름의 조각이다.

    ★★★ 2026-09-09 실측(엘·레아·한나 링크 조사) — 「엘」(JA `エル`)이 サム**エル**·
      エゼキ**エル**·ダニ**エル**·イスラ**エル** 속에, 「함」(`ハム`)이 アブラ**ハム**
      속에 걸려 살아 있는 일본어 링크 218/278 이 이 꼴이었다. 히라가나 조사(の·を)
      는 붙어도 된다 — 「ダビデの物語」.
    """
    if s > 0 and _is_kata(text[s - 1]):
        return False
    if e < len(text) and _is_kata(text[e]):
        return False
    return True


def find_names(rx, name, text):
    """제목·설명문에서 **경계를 지켜** 이름을 찾는다 → `[(이름, entity_id)]`.

    ⚠ 이름 찾기는 **이 한 문**을 쓴다 — 화면·크롤러가 각자 정규식을 돌리면
      한쪽만 경계를 지켜 같은 영상이 다른 용어에 걸린다.
    """
    out, seen = [], set()
    if not rx or not text:
        return out
    for m in rx.finditer(text):
        w = m.group(0)
        if w in seen or not name_ok(text, m.start(), m.end(), w):
            continue
        seen.add(w)
        out.append((w, name[w]))
    return out


def _ent_rx(conn, lang='KO'):
    """엔티티 이름 정규식 — 제목·설명문에서 「무엇에 관한 영상인가」를 뽑는다.

    ⚠ **기계 낱말(LEX)은 뺀다** — 1만 개가 넘어 아무 글에나 걸린다(§181차).
    ⚠⚠ **찬양 주제 전용(TOPIC)도 뺀다**(2026-09-10) — 「예배」·「소망」 같은
      말은 찬양을 고르는 데는 쓸모가 있지만 **제목 1,839편(9.7%%)** 에 들어
      있어 자동 분류를 통째로 끌고 간다. 그 낱말들의 자리는
      `db_worship_topic` 이고, 거기서는 **사람이 골라** 잇는다.
    ⚠ 두 글자 미만도 뺀다 — 「단」·「대」 같은 것이 아무 데나 걸린다.
    ⚠⚠ **라틴 이름은 %d 글자 미만도 뺀다** — `Er`·`Eve`·`Uz` 는 경계를 지켜도
      영어 제목에서 사람 이름인지 낱말인지 가릴 수 없다. 한글 이름이 그
      엔티티를 이미 잡는다.
    ⚠ 경계 판정은 정규식이 아니라 `name_ok` 가 한다 — 이름표에 한글·라틴이
      섞여 있어 한 정규식으로 두 규칙을 담을 수 없다.
    """ % _LAT_MIN
    key = (id(conn), lang)
    if key in _ENT_RX:
        return _ENT_RX[key]
    rows = conn.execute("""
        SELECT em.entity_id, tx.contents
          FROM sys_entity_master em
          JOIN sys_text_asset tx ON tx.clicked_id = em.entity_id
         WHERE tx.text_type='ENTITY_NAME' AND tx.lang_code=?
           AND tx.record_status='LIVE' AND em.record_status='LIVE'
           AND COALESCE(json_extract(em.json_detail,'$.subtype'),'')
               NOT IN ('LEX', 'TOPIC')
        """, (lang,)).fetchall()
    name = {}
    for eid, nm in rows:
        for part in str(nm or '').split('·'):
            part = part.strip()
            if len(part) < 2:
                continue
            if _script(part) == 'LAT' and len(part) < _LAT_MIN:
                continue                      # `Er`·`Eve` — 낱말과 못 가린다
            name.setdefault(part, eid)
    if not name:
        _ENT_RX[key] = (None, {})
        return _ENT_RX[key]
    rx = re.compile('|'.join(re.escape(n) for n in
                             sorted(name, key=len, reverse=True)))
    _ENT_RX[key] = (rx, name)
    return _ENT_RX[key]


def hints(conn, title, desc=None, lang='KO', limit=6, label_lang='KO'):
    """승인 검토 화면에 보일 실마리 (2026-09-03 사용자 지시 — 「제목에 내용이
    없는 경우 설명문의 키워드를 수집해서 표시해 주면 승인 검토 단계에서 큰
    도움이 될 것이다」).

    {'ranges': [(구간글, 출처)], 'terms': [(이름, entity_id)], 'snippet': 설명문 앞}
    · `lang` = **찾는** 언어(그 미디어의 언어) · `label_lang` = **보이는** 언어(기본 KO)
    ⚠ **판정하지 않는다** — 후보를 늘어놓을 뿐이고 고르는 것은 사람이다.
    """
    body = yt_desc(desc)
    out = {'ranges': [], 'terms': [], 'snippet': ''}
    for src, txt in (('제목', title or ''), ('설명', body)):
        for bc, s, e, k in read(conn, txt):
            lab = span_label(conn, s, e)
            if not any(r[0] == lab for r in out['ranges']):
                out['ranges'].append((lab, src))
    # ★★ **찾는 언어와 보이는 언어를 가른다** (2026-09-04 사용자 지시 —
    #   「영어로 수집한 경우 영어 라벨을 … **나는 한국어 표시를 선호한다**」).
    #   ⚠ **찾을 때는 그 미디어의 언어**여야 한다 — 영어 제목에서 「므두셀라」를
    #     찾을 수는 없고 `Methuselah` 를 찾아야 한다.
    #   ⚠ **보일 때는 `label_lang`**(기본 KO). 그러지 않으면 「현재 연결된
    #     것」(KO 조회)과 글자가 달라 **같은 엔티티가 둘로 보인다** — 실제로
    #     `· 므두셀라` ↔ `· Methuselah` 가 그래서 갈렸다.
    #   ⚠ 그 언어 이름이 없으면 **찾은 글자를 그대로** 쓴다(빈 라벨 금지).
    rx, name = _ent_rx(conn, lang)
    if rx:
        # ⚠ **경계 판정은 `find_names` 한 문**이 한다(§낱말 경계 사고).
        pairs = find_names(rx, name, '%s\n%s' % (title or '', body))[:limit]
        ll = (label_lang or lang or 'KO')
        if pairs and ll != lang:
            ids = [e for _w, e in pairs]
            disp = {r[0]: r[1] for r in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_NAME' AND lang_code=?"
                "   AND clicked_id IN (%s)" % ','.join('?' * len(ids)),
                [ll] + ids) if r[1] and r[1].strip()}
            pairs = [(disp.get(e, w), e) for w, e in pairs]
        out['terms'] = pairs
    if body:
        out['snippet'] = ' '.join(body.split())[:160]
    return out


def ref(conn, vid):
    r = conn.execute("SELECT bcode, chapter, verse FROM bible_index"
                     " WHERE verse_id=?", (vid,)).fetchone()
    if not r:
        return '?'
    nm = conn.execute("SELECT short_name FROM book_names"
                      " WHERE book_code=? AND lang_code='KO'", (r[0],)).fetchone()
    return '%s%d:%d' % (nm[0] if nm else r[0], r[1], r[2])


def span_label(conn, s, e, lang='KO'):
    """구간을 사람이 읽는 말로 — `욘4장` · `요나` · `창1:6~8` · `창1:3`.

    ★★ **장 전체면 「욘4장」, 책 전체면 「요나」로 적는다**(2026-09-03 사용자
      지적 — 「요나 4장이라고 표시되어 있는데 구절 추천을 요나4장 1절~14절로
      하면 **14절이 끝인지 알 수 없다**. 4장이라고 추천하면 더 명확하다」).
    ⚠ **표기를 여기서 다시 짓지 않는다** — `link_picker.scope_label` 이 이미
      그 규칙의 단일 소스다(§114차). 두 곳에서 지으면 화면마다 갈린다.
    """
    try:
        import link_picker as _lp
        lab = _lp.scope_label(conn, s, e, lang)
        if lab:
            return lab
    except Exception:
        pass
    return ref(conn, s) if s == e else '%s~%s' % (ref(conn, s), ref(conn, e))


# ── 보관함 ────────────────────────────────────────────────────────────────────
def init(conn):
    """보관함 표(멱등). 페리코프·엔티티 수집기가 함께 쓴다 — scope 로 가른다."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sys_media_pending (
            pend_id       INTEGER PRIMARY KEY AUTOINCREMENT,
            media_id      INTEGER NOT NULL,
            scope         TEXT NOT NULL,
            hint_id       INTEGER,
            reason        TEXT NOT NULL,
            note          TEXT,
            added_at      TEXT DEFAULT (datetime('now','localtime')),
            record_status TEXT NOT NULL DEFAULT 'LIVE'
        )""")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS ux_media_pending"
                 " ON sys_media_pending(media_id, scope)")
    conn.commit()


def ensure_hint_col(conn):
    """`hint_vid` 칸(멱등) — **보관함을 책으로 접기 위한 자리**.

    ★★★ 왜 (2026-09-04 사용자 지적 「보관함 내부에 **수천건이 있으면 작업
      불가능**하다」 · 「**성경/용어와 같이 구분**하도록 하라」 · 「**트리구조로
      나누자**」).
      실측 3,567건을 평면으로 늘어놓고 있었다. 접을 축은 있다 —
      **추천 구간 365(10%) · 용어만 847(24%) · 실마리 없음 2,355(66%)**.
    ⚠ **`hint_id` 를 재사용하지 않는다** — 그 칸은 페리코프 번호를 담는다
      (96건). 뜻이 다른 값을 한 칸에 섞으면 나중에 어느 쪽인지 모른다.
    ⚠ 나무를 그릴 때마다 계산하면 **3,567건에 5초**가 든다 ⇒ 담을 때 채우고
      화면은 읽기만 한다.
    """
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_media_pending)")]
    if 'hint_vid' not in cols:
        conn.execute("ALTER TABLE sys_media_pending ADD COLUMN hint_vid INTEGER")
    return True


def hold(conn, media_id, scope, reason, hint_id=None, note=None,
         hint_vid=None):
    """보관함에 담는다(멱등). scope='PERI'|'ENTI'.

    `hint_vid` — 제목·설명문에서 읽은 **추천 구간의 시작 절**. 화면이 이것으로
    보관함을 **책 → 장**으로 접는다(성경 마디와 같은 규칙).
    """
    if scope not in ('PERI', 'ENTI'):
        raise ValueError('scope 는 PERI 또는 ENTI 여야 한다: %r' % scope)
    ensure_hint_col(conn)
    conn.execute(
        "INSERT INTO sys_media_pending(media_id, scope, hint_id, reason, note,"
        " hint_vid) VALUES(?,?,?,?,?,?)"
        " ON CONFLICT(media_id, scope) DO UPDATE SET"
        "   reason=excluded.reason, hint_id=excluded.hint_id,"
        "   note=excluded.note, hint_vid=excluded.hint_vid,"
        "   record_status='LIVE'",
        (media_id, scope, hint_id, reason, note, hint_vid))
    return True


#: 보관함 유형 — **처리하는 사람과 방법이 유형마다 다르다**
#: (2026-09-04 사용자 지시 「몇가지 유형으로 트리구조 … **유형별로 각개격파** ·
#:  1) 구절이 여러 그룹 2) 구절과 용어가 혼재 3) 책이름만 4) 아무것도 없는 경우」).
#: 실측 3,567건 — ONE 298 · MULTI 67 · TERM 1,696 · BOOK 120 · NONE 1,386.
PEND_KINDS = (
    ('ONE',   '구간 하나 — 바로 걸 수 있다',   '기계가 푼다(재훑기)'),
    ('MULTI', '구간이 여럿 — 선택해야 한다',     '사람이 후보에서 선택한다'),
    ('BOOK',  '책 이름만 — 장·절이 없다',      '책 전체로 걸까 정한다'),
    ('TERM',  '용어만 — 구절 좌표가 없다',     '용어 연결로 승인할까 정한다'),
    ('NONE',  '아무 실마리도 없다',            '거부 후보'),
    # ★★★ 자동추천(검토중) — 2026-09-09 사용자 「확실한 값이 없어서 자동추천 후보가
    #   지정되어 (검토중) 라벨이 붙은 경우에도 … 트리 내부에 위치해 있다. 이것을
    #   보관함으로 옮기고 별도 분류값을 만들어라」. 연결이 **후보(PEND)뿐**인 미검토
    #   영상. `sync_auto_pending` 이 멱등으로 채우고 걷는다.
    #   ⚠ 무한정 보관하지 않는다 — 주기적으로 분석해 제거한다(data.md Z-1g 할일).
    ('AUTO',  '자동추천(검토중) — 후보 연결만 있다', '심사하거나 주기적으로 정리한다'),
    # ★★★ 재검토 유보(2026-09-09 사용자) — 「인물을 골라 목록을 보다가 그 인물과
    #   관계없는 것은 그냥 지나가면 되는가? **교리와 연결된 영상인데 교리 용어 추천이
    #   없다.** 삭제할 수는 없다 — 따로 모아서 다시 재분류해야 한다. 키워드로 기계적
    #   재분류는 쉽지 않을 것이다」. 기계가 아니라 **사람(또는 분석자)이 읽고** 주제를
    #   다시 정하는 마디다 — `fill_hint_vid` 가 이 유형은 덮어쓰지 않는다.
    ('RECLASS', '재검토 유보 — 주제를 다시 정한다', '사람이 잇거나 분석해 재분류'),
    # ★★★ 예배 실황(2026-09-16 사용자 「실황설교는 보관함에 담아 두었다가 다시 분석하자」)
    #   — **등록 채널**이 올린 예배 실황 꼴 제목인데 **구절 연결이 없는** 미검토 영상.
    #   상관없는 영상이 아니라 좌표가 없어 못 건 것이라 삭제 보관함이 아니라 여기 둔다.
    #   `sync_live_service_pending` 이 멱등으로 채우고, 승인되거나 연결이 생기면 걷는다.
    ('LIVESVC', '예배 실황 — 등록 채널 · 구절 연결 없음', '보관했다가 다시 분석한다'),
)
R_RECLASS = 'RECLASS'
R_LIVESVC = 'LIVESVC'


def sync_live_service_pending(conn):
    """보관함 「예배 실황」 마디를 맞춘다 → (넣은 수, 옮긴 수, 걷은 수). 멱등.

    넣는다 = 미검토(LIVE·is_active=0) · 등록 채널 · 구절 연결(LIVE) 없음 · 제목이 예배 실황
      꼴(`media_exclude.LIVE_SERVICE_KW`). 보관함에 없으면 새 줄, NONE·TERM·AUTO 로 있으면
      유형만 옮긴다(옛 유형은 note 에 남긴다). 걷는다 = LIVESVC 인데 승인됐거나 가려졌거나
      구절 연결이 생긴 것.
    ⚠ MULTI·BOOK·ONE·RECLASS 처럼 더 구체적인 실마리가 있는 줄은 건드리지 않는다."""
    import json as _json
    import media_exclude as _MX
    init(conn)
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_media_pending)')]
    if 'hint_kind' not in cols:
        conn.execute("ALTER TABLE sys_media_pending ADD COLUMN hint_kind TEXT")
    reg_ids = {r[0] for r in conn.execute(
        "SELECT channel_ext_id FROM sys_media_channel"
        " WHERE COALESCE(record_status,'LIVE')='LIVE' AND channel_ext_id IS NOT NULL")}
    reg_names = {(r[0] or '').lower() for r in conn.execute(
        "SELECT channel_name FROM sys_media_channel WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    reg_names.discard('')
    has_live = ("EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=a.media_id"
                " AND l.link_type='MEDI_VERS' AND COALESCE(l.record_status,'LIVE')='LIVE')")
    want = []
    for mid, title, lang, desc in conn.execute(
            "SELECT a.media_id, a.title, a.lang_code, a.description FROM sys_media_asset a"
            " WHERE COALESCE(a.record_status,'LIVE')='LIVE' AND a.is_active=0"
            "   AND a.description LIKE '{%' AND NOT " + has_live):
        try:
            j = _json.loads(desc)
        except Exception:
            continue
        if not ((j.get('channel_id') or '') in reg_ids
                or (j.get('channel') or '').lower() in reg_names):
            continue
        if _MX.match_live_service(title or '', lang):
            want.append(mid)
    ins = upd = 0
    now = "datetime('now','localtime')"
    for i in range(0, len(want), 400):
        ch = want[i:i + 400]
        ph = ','.join('?' * len(ch))
        upd += conn.execute(
            "UPDATE sys_media_pending SET note=COALESCE(hint_kind,'NONE')||'→LIVESVC', hint_kind='LIVESVC'"
            " WHERE media_id IN (%s) AND COALESCE(hint_kind,'NONE') IN ('NONE','TERM','AUTO')"
            "   AND COALESCE(record_status,'LIVE')='LIVE'" % ph, ch).rowcount
        ins += conn.execute(
            "INSERT OR IGNORE INTO sys_media_pending (media_id, scope, reason, note, added_at, record_status, hint_kind)"
            " SELECT a.media_id, 'PERI', 'LIVESVC', '예배 실황 — 구절 연결 없음', " + now + ", 'LIVE', 'LIVESVC'"
            "   FROM sys_media_asset a WHERE a.media_id IN (%s)"
            "    AND NOT EXISTS(SELECT 1 FROM sys_media_pending p WHERE p.media_id=a.media_id)" % ph, ch).rowcount
    gone = conn.execute(
        "DELETE FROM sys_media_pending WHERE hint_kind='LIVESVC' AND media_id IN ("
        "  SELECT p.media_id FROM sys_media_pending p JOIN sys_media_asset a ON a.media_id=p.media_id"
        "   WHERE p.hint_kind='LIVESVC' AND (a.is_active=1 OR COALESCE(a.record_status,'LIVE')<>'LIVE'"
        "      OR %s))" % has_live).rowcount
    conn.commit()
    return ins, upd, gone


def hold_reclass(conn, media_id, wrong_eids=(), why=None):
    """[재검토 유보] — 지금 걸린 것은 틀렸는데 **다른 주제(교리·용어)**로 살릴 영상.

    · 보관함에 `RECLASS` 로 담는다(scope ENTI · `hint_kind` 도 RECLASS)
    · `wrong_eids` 의 용어 연결은 뗀다 — 표식은 **`RECLASS_HIDE`** 이지 `MANUAL_HIDE` 가
      아니다(2026-09-09 사용자 「사람이 뗀 것이라고 표시하지 마라. **그것조차 네가 다시
      분석하는 게 좋다. 그래야 자동연결 도구 기능이 개선된다**」). 재판정 도구가
      `--reclass-hidden` 으로 뽑아 「왜 걸렸나」를 읽고 규칙을 고친다.
    · 승인은 내린다(`is_active=0`) — 유보는 「보이지 않게 두고 다시 본다」이다
    ⚠ 다른 용어 연결·구절 연결은 그대로 둔다 — 틀렸다고 판정한 것은 고른 인물뿐이다.
    """
    ensure_hint_col(conn)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_media_pending)")]
    if 'hint_kind' not in cols:            # ⚠ 옛 DB — fill_hint_vid 가 만들던 칸
        conn.execute("ALTER TABLE sys_media_pending ADD COLUMN hint_kind TEXT")
    hold(conn, int(media_id), 'ENTI', R_RECLASS, note=why)
    conn.execute("UPDATE sys_media_pending SET hint_kind=? WHERE media_id=? AND scope='ENTI'",
                 (R_RECLASS, int(media_id)))
    n_hide = 0
    for eid in (wrong_eids or ()):
        n_hide += conn.execute(
            "UPDATE sys_link_asset SET record_status='HIDE', note='RECLASS_HIDE'"
            " WHERE link_type='MEDI_ENTI' AND clicked_id=? AND target_id=?"
            " AND record_status IN ('LIVE','PEND')", (int(media_id), int(eid))).rowcount
    conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id=?", (int(media_id),))
    conn.commit()
    return n_hide


def reclass_rows(conn):
    """유보된 영상 목록 → [(media_id, lang, title, 설명문 앞 400자, 남은 연결 이름들)].
    **분석자가 읽고 재분류하는 재료**다(`--reclass` 로 TSV 출력)."""
    out = []
    for mid, lang, title, desc in conn.execute(
            "SELECT a.media_id, a.lang_code, a.title, a.description"
            "  FROM sys_media_pending p JOIN sys_media_asset a ON a.media_id=p.media_id"
            " WHERE p.reason=? AND COALESCE(p.record_status,'LIVE')='LIVE'"
            " ORDER BY a.media_id", (R_RECLASS,)):
        names = [r[0] for r in conn.execute(
            "SELECT COALESCE((SELECT contents FROM sys_text_asset WHERE clicked_id=l.target_id"
            "        AND text_type='ENTITY_NAME' AND lang_code='KO'), CAST(l.target_id AS TEXT))"
            "  FROM sys_link_asset l WHERE l.link_type='MEDI_ENTI' AND l.clicked_id=?"
            "   AND l.record_status IN ('LIVE','PEND')", (mid,))]
        out.append((mid, lang or '', title or '', yt_desc(desc)[:400].replace('\n', ' '),
                    ' · '.join(names)))
    return out

_BOOK_RX = {}


def _book_rx(conn):
    """책 이름 정규식 — 「창세기」처럼 **책만** 있고 장·절이 없는 것을 가른다."""
    k = id(conn)
    if k in _BOOK_RX:
        return _BOOK_RX[k]
    nm = [r[0] for r in conn.execute(
        "SELECT DISTINCT full_name FROM book_names"
        " WHERE lang_code IN ('KO','EN') AND full_name IS NOT NULL") if r[0]]
    rx = re.compile('|'.join(re.escape(x) for x in
                             sorted(nm, key=len, reverse=True))) if nm else None
    _BOOK_RX[k] = rx
    return rx


def classify(conn, title, desc=None, lang='KO', has_ent=False):
    """보관함 한 줄의 **유형**을 정한다 → (`PEND_KINDS` 의 코드, 시작 절|None).

    ⚠ 판정 차례가 뜻을 정한다 — 구간이 있으면 그것이 먼저다(용어는 덤이다).
    """
    body = yt_desc(desc)
    got = read(conn, title or '') or (read(conn, body[:600]) if body else [])
    spans = {(g[1], g[2]) for g in got}
    if len(spans) > 1:
        return 'MULTI', int(got[0][1])
    if len(spans) == 1:
        return 'ONE', int(got[0][1])
    if has_ent:
        return 'TERM', None
    rx, name = _ent_rx(conn, lang or 'KO')
    if rx and find_names(rx, name, '%s\n%s' % (title or '', body[:400])):
        return 'TERM', None
    brx = _book_rx(conn)
    if brx and brx.search(title or ''):
        return 'BOOK', None
    return 'NONE', None


def sync_auto_pending(conn):
    """보관함 「자동추천(검토중)」 마디를 맞춘다 → (넣은 수, 걷은 수). 멱등.

    넣는다 = 미검토(LIVE·is_active=0)이고 미디어 연결이 **후보(PEND)뿐**이며 보관함에
      아직 없는 영상. 걷는다 = AUTO 로 담았는데 승인됐거나 LIVE 연결이 생겼거나 후보가
      다 사라진 것(사람이 심사한 뒤 저절로 빠진다).
    ⚠ 다른 유형(TERM·NONE …)으로 이미 보관함에 있는 것은 건드리지 않는다 — 그쪽
      실마리가 더 구체적이다."""
    init(conn)
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_media_pending)')]
    if 'hint_kind' not in cols:
        conn.execute("ALTER TABLE sys_media_pending ADD COLUMN hint_kind TEXT")
    has_pend = ("EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=a.media_id"
                " AND l.link_type LIKE 'MEDI_%' AND l.record_status='PEND')")
    has_live = ("EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=a.media_id"
                " AND l.link_type LIKE 'MEDI_%' AND COALESCE(l.record_status,'LIVE')='LIVE')")
    ins = conn.execute(
        "INSERT OR IGNORE INTO sys_media_pending (media_id, scope, reason, note, added_at, record_status, hint_kind)"
        " SELECT a.media_id, 'ENTI', 'AUTO', '후보 연결만 있음', datetime('now','localtime'), 'LIVE', 'AUTO'"
        "   FROM sys_media_asset a"
        "  WHERE COALESCE(a.record_status,'LIVE')='LIVE' AND a.is_active=0"
        "    AND %s AND NOT %s"
        "    AND NOT EXISTS(SELECT 1 FROM sys_media_pending p WHERE p.media_id=a.media_id)"
        % (has_pend, has_live)).rowcount
    gone = conn.execute(
        "DELETE FROM sys_media_pending WHERE hint_kind='AUTO' AND media_id IN ("
        "  SELECT p.media_id FROM sys_media_pending p JOIN sys_media_asset a ON a.media_id=p.media_id"
        "   WHERE p.hint_kind='AUTO' AND (a.is_active=1 OR COALESCE(a.record_status,'LIVE')<>'LIVE'"
        "      OR %s OR NOT %s))" % (has_live, has_pend)).rowcount
    conn.commit()
    return ins, gone


def fill_hint_vid(conn, limit=None, log=None):
    """보관함의 `hint_vid`·`hint_kind` 를 채운다 → (채운 수, 실마리 없는 수).

    ⚠ **매번 계산하면 3,567건에 20초**가 든다 — 담을 때 채우고 화면은 읽는다.
    ⚠ 멱등이 아니다(규칙을 고치면 다시 돌려야 한다) — `hint_kind` 를 늘 다시
      쓴다. 읽기 규칙을 보강한 날에는 반드시 이것부터 돌린다.
    """
    ensure_hint_col(conn)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_media_pending)")]
    if 'hint_kind' not in cols:
        conn.execute("ALTER TABLE sys_media_pending ADD COLUMN hint_kind TEXT")
    ent = {r[0] for r in conn.execute(
        "SELECT DISTINCT clicked_id FROM sys_link_asset"
        " WHERE link_type='MEDI_ENTI'"
        "   AND COALESCE(record_status,'LIVE')='LIVE'")}
    q = ("SELECT p.media_id, a.title, a.description, a.lang_code"
         "  FROM sys_media_pending p"
         "  JOIN sys_media_asset a ON a.media_id=p.media_id"
         " WHERE COALESCE(p.record_status,'LIVE')='LIVE'"
         "   AND COALESCE(p.reason,'')<>'RECLASS'")   # ★ 사람이 유보한 것은 안 덮는다
    if limit:
        q += ' LIMIT %d' % int(limit)
    rows = conn.execute(q).fetchall()
    done = miss = 0
    for i, (mid, t, d, lc) in enumerate(rows):
        kind, vid = classify(conn, t, d, lc or 'KO', has_ent=(mid in ent))
        conn.execute("UPDATE sys_media_pending SET hint_vid=?, hint_kind=?"
                     " WHERE media_id=?", (vid, kind, mid))
        if vid:
            done += 1
        else:
            miss += 1
        if log and i and i % 500 == 0:
            log('  %d/%d' % (i, len(rows)))
    conn.commit()
    return done, miss


def release(conn, media_id, scope):
    """보관함에서 뺀다(사람이 구간을 정해 준 뒤)."""
    conn.execute("UPDATE sys_media_pending SET record_status='HIDE'"
                 " WHERE media_id=? AND scope=?", (media_id, scope))


def pending(conn, scope=None):
    q = ("SELECT p.pend_id, p.media_id, p.scope, p.reason, p.hint_id, m.title,"
         "       m.lang_code"
         "  FROM sys_media_pending p"
         "  JOIN sys_media_asset m ON m.media_id = p.media_id"
         " WHERE p.record_status='LIVE'")
    a = []
    if scope:
        q += " AND p.scope=?"
        a.append(scope)
    # ★ **후보가 있는 것(MULTI)을 앞에 둔다** — 그것부터 처리하는 것이 빠르고,
    #   좌표가 아예 없는 것은 손이 더 가므로 뒤로 미룬다.
    return conn.execute(
        q + " ORDER BY p.scope, CASE p.reason WHEN 'MULTI' THEN 0"
            " WHEN 'OFF' THEN 1 ELSE 2 END, p.pend_id", a).fetchall()


# ── 지금 연결과 대조 ──────────────────────────────────────────────────────────
def compare(conn, active=1):
    """승인/미승인 미디어를 읽어 지금 페리코프 연결과 견준다.

    돌려주는 것 = {'ok': [...], 'hold': [...], 'stat': {...}}
      ok   = (media_id, title, (bc, s, e, kind), 관계)
      hold = (media_id, title, 이유)
    관계 = SAME | WIDER | NARROWER | PARTIAL | OFF | NONE
    """
    rows = conn.execute("""
        SELECT DISTINCT ma.media_id, ma.title, ma.description
          FROM sys_link_asset l
          JOIN sys_media_asset ma ON ma.media_id = l.clicked_id
         WHERE l.link_type='MEDI_PERI' AND ma.is_active=?
           AND ma.record_status='LIVE' AND ma.title IS NOT NULL""",
        (active,)).fetchall()
    ok, held = [], []
    stat = {k: 0 for k in
            ('SAME', 'WIDER', 'NARROWER', 'PARTIAL', 'OFF', 'NONE',
             R_NONE, R_MULTI, 'BY_DESC')}
    for mid, title, desc in rows:
        got, why = pick2(conn, title, desc)
        if not got:
            stat[why] += 1
            held.append((mid, title, why))
            continue
        if why == 'DESC':
            stat['BY_DESC'] += 1
        ps = conn.execute("""
            SELECT p.start_vid, COALESCE(p.end_vid, p.start_vid)
              FROM sys_link_asset l
              JOIN sys_pericope_asset p ON p.pericope_id = l.target_id
             WHERE l.link_type='MEDI_PERI' AND l.clicked_id=?
               AND COALESCE(l.record_status,'LIVE')='LIVE'""", (mid,)).fetchall()
        if not ps:
            rel = 'NONE'
        else:
            lo, hi = min(p[0] for p in ps), max(p[1] for p in ps)
            s, e = got[1], got[2]
            if lo == s and hi == e:
                rel = 'SAME'
            elif s <= lo and hi <= e:
                rel = 'WIDER'
            elif lo <= s and e <= hi:
                rel = 'NARROWER'
            elif s <= hi and lo <= e:
                rel = 'PARTIAL'
            else:
                rel = 'OFF'
        stat[rel] += 1
        ok.append((mid, title, got, rel))
    return {'ok': ok, 'hold': held, 'stat': stat, 'total': len(rows)}


# ── 정상화 ────────────────────────────────────────────────────────────────────
def normalize(conn, active=1, apply=False):
    """MEDI_PERI → MEDI_VERS(구간). 못 정한 것은 보관함.

    ⚠ **OFF(전혀 안 겹침)는 자동으로 안 바꾼다** — 제목이 틀렸을 수도 있고
      지금 연결이 틀렸을 수도 있다. 보관함에 담아 사람이 본다.
    """
    res = compare(conn, active)
    put, hold_rows = [], list(res['hold'])
    for mid, title, got, rel in res['ok']:
        if rel == 'OFF':
            hold_rows.append((mid, title, R_OFF))
        else:
            put.append((mid, title, got, rel))
    if not apply:
        return {'put': put, 'hold': hold_rows, 'stat': res['stat'],
                'total': res['total'], 'applied': False}

    init(conn)
    conn.execute("CREATE TABLE IF NOT EXISTS %s AS"  # status-ok: 백업 표의 칸 모양만 뜬다(행 0)
                 " SELECT * FROM sys_link_asset WHERE 0" % BACKUP)
    ids = [m for m, _, _, _ in put] + [m for m, _, _ in hold_rows]
    if ids:
        ph = ','.join('?' * len(ids))
        conn.execute("INSERT INTO %s SELECT * FROM sys_link_asset"  # status-ok: 되돌리기 백업 — 걷은 줄까지 그대로 떠야 원상복구가 된다
                     " WHERE link_type='MEDI_PERI' AND clicked_id IN (%s)"
                     % (BACKUP, ph), ids)
    added = 0
    for mid, title, got, rel in put:
        bc, s, e, kind = got
        cur = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset WHERE link_type='MEDI_VERS'"
            " AND clicked_id=? AND target_id=?", (mid, s)).fetchone()
        if cur:
            conn.execute("UPDATE sys_link_asset SET end_id=?,"
                         " record_status='LIVE' WHERE sys_link_id=?", (e, cur[0]))
        else:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " end_id, record_status) VALUES('MEDI_VERS',?,?,?,'LIVE')",
                (mid, s, e))
            added += 1
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='MEDI_PERI'"
                     " AND clicked_id=?", (mid,))
    # ★ 보관함에 **실마리를 함께** 담는다 (2026-09-03 사용자 지시) — 검토
    #   화면에서 사람이 구간을 3초에 정할 수 있게. 실마리 = 제목·설명문에서
    #   읽은 구간 후보 + 걸린 용어 이름 + 설명문 앞머리.
    for mid, title, why in hold_rows:
        row = conn.execute("SELECT description FROM sys_media_asset"
                           " WHERE media_id=?", (mid,)).fetchone()
        h = hints(conn, title, row[0] if row else None)
        note = ' | '.join(filter(None, [
            ' '.join('%s(%s)' % (a, b) for a, b in h['ranges']),
            ' '.join(w for w, _ in h['terms']),
            h['snippet'][:80]]))
        hold(conn, mid, 'PERI', why, note=note or None)
        # ⚠ **보관함에 담은 것의 옛 페리코프 연결도 걷는다** — 근거가
        #   「무슨 검색어로 찾았나」뿐인 연결을 남겨 두면, 보관함에 담아 두고도
        #   화면에는 그대로 떠 있는 이중 상태가 된다. 데이터를 잃는 것이
        #   아니다 — 실마리와 함께 보관함에 있고, 사람이 구간을 정하면 다시
        #   이어진다(백업표로 되돌릴 수도 있다).
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='MEDI_PERI'"
                     " AND clicked_id=?", (mid,))
    conn.commit()
    return {'put': put, 'hold': hold_rows, 'stat': res['stat'],
            'total': res['total'], 'applied': True, 'added': added}


def resweep(conn, scope='PERI', apply=False):
    """보관함을 **다시 훑는다** — 읽기 규칙이 좋아졌을 때 쓴다.

    ★ 보관함은 버리는 곳이 아니라 **기다리는 곳**이다. 규칙을 고칠 때마다
      여기를 다시 돌리면 그동안 못 읽던 것이 저절로 풀린다(실측 — 한 글자
      약명에 공백을 허용하자 86건 중 37건이 그 자리에서 풀렸다).
    ⚠ 구간이 **하나로 좁혀질 때만** 푼다. 여럿이면 그대로 둔다.
    """
    rows = conn.execute("""
        SELECT p.media_id, m.title, m.description
          FROM sys_media_pending p
          JOIN sys_media_asset m ON m.media_id = p.media_id
         WHERE p.record_status='LIVE' AND p.scope=?""", (scope,)).fetchall()
    freed = []
    for mid, title, desc in rows:
        got, _ = pick2(conn, title, desc)
        if got:
            freed.append((mid, title, got))
    if not apply:
        return {'total': len(rows), 'freed': freed, 'applied': False}
    for mid, title, got in freed:
        _, s, e, _k = got
        cur = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset WHERE link_type='MEDI_VERS'"
            " AND clicked_id=? AND target_id=?", (mid, s)).fetchone()
        if cur:
            conn.execute("UPDATE sys_link_asset SET end_id=?,"
                         " record_status='LIVE' WHERE sys_link_id=?", (e, cur[0]))
        else:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " end_id, record_status) VALUES('MEDI_VERS',?,?,?,'LIVE')",
                (mid, s, e))
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='MEDI_PERI'"
                     " AND clicked_id=?", (mid,))
        release(conn, mid, scope)
    conn.commit()
    return {'total': len(rows), 'freed': freed, 'applied': True}


def undo(conn):
    """정상화 되돌리기 — 백업표의 MEDI_PERI 를 되살리고 만든 MEDI_VERS 를 걷는다."""
    try:
        rows = conn.execute("SELECT DISTINCT clicked_id FROM %s" % BACKUP).fetchall()
    except sqlite3.OperationalError:
        return 0
    ids = [r[0] for r in rows]
    if not ids:
        return 0
    ph = ','.join('?' * len(ids))
    conn.execute("DELETE FROM sys_link_asset WHERE link_type='MEDI_VERS'"
                 " AND clicked_id IN (%s)" % ph, ids)
    conn.execute("DELETE FROM sys_link_asset WHERE link_type='MEDI_PERI'"
                 " AND clicked_id IN (%s)" % ph, ids)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_link_asset)")]
    have = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % BACKUP)]
    use = [c for c in cols if c in have and c != 'sys_link_id']
    conn.execute("INSERT INTO sys_link_asset(%s) SELECT %s FROM %s"  # status-ok: 백업을 되돌려 붓는다 — 상태는 백업에 적힌 옛 값 그대로다
                 % (','.join(use), ','.join(use), BACKUP))
    conn.execute("UPDATE sys_media_pending SET record_status='HIDE'"
                 " WHERE scope='PERI' AND media_id IN (%s)" % ph, ids)
    n = conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]
    conn.execute("DROP TABLE %s" % BACKUP)
    conn.commit()
    return n


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    conn = appdb.connect(DB)
    conn.execute('BEGIN')
    try:
        def one(title):
            g = read(conn, title)
            return g[0] if len(g) == 1 else None

        def lab(title):
            g = one(title)
            return span_label(conn, g[1], g[2]) if g else None

        t('절 범위', lab('Genesis 1:6-8 Explained') == '창1:6~8', lab('Genesis 1:6-8 Explained'))
        t('한국어 절 범위', lab('궁창과 그 역할(창세기 1:6~8)') == '창1:6~8')
        t('절 하나', lab('[창세기100문100답] 창세기 1장 3절 빛이 있으라') == '창1:3')
        t('장 넘는 범위',
          lab('매일성경 [레위기 5장 14절 - 6장 7절]') == '레5:14~6:7',
          lab('매일성경 [레위기 5장 14절 - 6장 7절]'))
        t('장 단위', lab('Bible Explained - Genesis 15 - The Covenant') == '창15장',
          lab('Bible Explained - Genesis 15 - The Covenant'))
        t('장 범위', lab('Dramatized Bible - Joshua 12-14') == '수12:1~14:15',
          lab('Dramatized Bible - Joshua 12-14'))
        t('한글 구분선 뒤', lab('창세기 1장ㅣ하나님으로 가득한 세상') == '창1장',
          lab('창세기 1장ㅣ하나님으로 가득한 세상'))
        t('시편 편', lab('하나님께서 주시는 복의 특징ㅣ시편 92편') == '시92장',
          lab('하나님께서 주시는 복의 특징ㅣ시편 92편'))
        t('한 글자 약명', lab('납달리지파가 받은 기업(수19:32-39)') == '수19:32~39',
          lab('납달리지파가 받은 기업(수19:32-39)'))
        t('한 글자 약명 + 공백 + 장',
          lab('사사기 특강 - 삼손의 출생(삿 13장)') == '삿13장',
          lab('사사기 특강 - 삼손의 출생(삿 13장)'))
        # ★ 보관함 실측에서 나온 꼴들(2026-09-03) — 46+4건이 여기 걸렸다
        t('책 이름과 숫자 사이 Chapter',
          lab('Genesis Chapter 21 Explained') == '창21장',
          lab('Genesis Chapter 21 Explained'))
        t('Chapter + 장 범위',
          lab('Numbers Chapter 1-4 | Census') == '민1:1~4:49',
          lab('Numbers Chapter 1-4 | Census'))
        t('장·절이 공백으로 갈린 꼴',
          lab('26103 Genesis 28 1-5 The Promise') == '창28:1~5',
          lab('26103 Genesis 28 1-5 The Promise'))
        t('★ 공백 꼴은 범위가 있을 때만(장을 절로 오독 금지)',
          lab('Genesis 28 The Promise is the Plan') == '창28장',
          lab('Genesis 28 The Promise is the Plan'))
        # ★ 이어지는 참조(2026-09-03 사용자 지적)
        def labs(title):
            return ' / '.join(span_label(conn, a, b)
                              for _, a, b, _ in read(conn, title))
        t('★ 이어지는 참조 — 창1:26-27, 2:1,7,8,20-24',
          labs('창1:26-27, 2:1,7,8,20-24 사람의 창조')
          == '창1:26~27 / 창2:1 / 창2:7 / 창2:8 / 창2:20~24',
          labs('창1:26-27, 2:1,7,8,20-24 사람의 창조'))
        t('  같은 장이 이어진다(콜론 없으면 절)',
          labs('창1:1,3,5') == '창1:1 / 창1:3 / 창1:5', labs('창1:1,3,5'))
        t('★ 없는 절은 안 읽는다(연도·인원)',
          labs('창1:1, 2026년 신년예배') == '창1:1'
          and labs('창1:1, 100명이 모였다') == '창1:1')
        # ★★ 흔한 약칭(정식이름 앞머리 + 마침표) — 2026-09-03
        t('약칭 Deut. / Matt. / Ps.',
          lab('June 2 Devotional (Deut. 27:11-26)') == '신27:11~26'
          and lab('Matt. 5:3-12') == '마5:3~12'
          and lab('Ps. 23:1') == '시23:1',
          '%s · %s · %s' % (lab('June 2 Devotional (Deut. 27:11-26)'),
                            lab('Matt. 5:3-12'), lab('Ps. 23:1')))
        t('약칭 1 Cor. / Rev.',
          lab('1 Cor. 13:4-7') == '고전13:4~7' and lab('Rev. 21:1-4') == '계21:1~4')
        # ★★★ **보통 낱말과 겹치는 약명**이 오독을 냈다(실측 16개 —
        #   Est·Job·Am·Is·So·Act·At·He). 약명을 조건부로 바꿔 막았다.
        for w in ('Theme: Le Royaume est la. Genese 3', 'Job hunting tips 2026',
                  'The Act of Faith', 'Is this the way?', 'So many blessings',
                  'Judge not, that ye be not judged', 'John said hello'):
            t('★ 오독 차단 — %s' % w[:22], not read(conn, w),
              str(read(conn, w)) if read(conn, w) else '')
        t('★ 보통 말은 여전히 안 읽는다',
          not read(conn, '창 3개를 열어 두었다') and not read(conn, '수 많은 사람'),
          '%s / %s' % (read(conn, '창 3개를 열어 두었다'),
                       read(conn, '수 많은 사람')))

        # ★ 탐지력 — 잘못 읽으면 안 되는 것들
        t('★ 좌표 없으면 안 읽는다', pick(conn, '365 days of no fear journey')[1] == R_NONE)
        t('★ 여럿이면 안 선택한다',
          pick(conn, '1 Samuel 27:1-12 and Romans 13:1-7')[1] == R_MULTI)
        t('★ 시리즈 번호 오독은 MULTI 로 걸린다',
          pick(conn, '出埃及记４逾越节（出埃及记12章）')[1] == R_MULTI,
          str(read(conn, '出埃及记４逾越节（出埃及记12章）')))
        t('★ 한 글자 약명은 숫자 붙을 때만',
          not read(conn, '수 많은 사람들이 모였다'), str(read(conn, '수 많은 사람들이 모였다')))
        t('★★★ 약명 앞에 한글이 붙으면 책이 아니다(오전 11시 → 전도서 아님)',
          not read(conn, '주일 오전 11시 예배') and not read(conn, '오전3부예배'),
          str(read(conn, '주일 오전 11시 예배')))
        t('  「사도행전 2:1」은 행2:1 하나뿐(속의 「전」은 안 읽는다)',
          [x[0] for x in read(conn, '사도행전 2:1 설교')] == [44], str(read(conn, '사도행전 2:1 설교')))
        t('  라틴 약명 앞에 글자가 붙어도 마찬가지(Tips 23:1)',
          not read(conn, 'Tips 23:1 for life'), str(read(conn, 'Tips 23:1 for life')))
        t('  약명 앞이 공백·부호면 그대로 읽는다(Ps 23:1 · (수19:32))',
          bool(read(conn, 'Ps 23:1')) and bool(read(conn, '(수19:32)')))
        t('★ 절이 있으면 장은 안 읽는다', len(read(conn, 'Genesis 1:3-5')) == 1)
        t('★ 없는 책 이름', not read(conn, 'Hogwarts 3:16'))

        # 보관함
        init(conn)
        mid = conn.execute("SELECT media_id FROM sys_media_asset LIMIT 1").fetchone()[0]
        n0 = conn.execute("SELECT COUNT(*) FROM sys_media_pending").fetchone()[0]
        hold(conn, mid, 'PERI', R_NONE)
        hold(conn, mid, 'PERI', R_NONE)
        n1 = conn.execute("SELECT COUNT(*) FROM sys_media_pending").fetchone()[0]
        t('보관함 멱등(두 번 담아도 한 줄)', n1 == n0 + 1, '%d → %d' % (n0, n1))
        hold(conn, mid, 'ENTI', R_MULTI)
        t('갈래가 다르면 따로 담긴다',
          conn.execute("SELECT COUNT(*) FROM sys_media_pending"
                       " WHERE media_id=?", (mid,)).fetchone()[0] == 2)
        release(conn, mid, 'PERI')
        t('빼면 현황에서 사라진다',
          not [r for r in pending(conn, 'PERI') if r[1] == mid])
        try:
            hold(conn, mid, 'BOGUS', R_NONE)
            bad = True
        except ValueError:
            bad = False
        t('★ 모르는 갈래는 거부', not bad)

        # ── 설명문 · 실마리 ──
        _d = '{"yt_desc": "\\uc624\\ub298 \\ubcf8\\ubb38\\uc740 \\ub2e83:1-7 \\uc785\\ub2c8\\ub2e4"}'
        g2, src = pick2(conn, '교만한 느부갓네살의 금 신상', _d)
        t('설명문에서 구간을 읽는다',
          bool(g2) and src == 'DESC' and span_label(conn, g2[1], g2[2]) == '단3:1~7',
          '%s / %s' % (src, span_label(conn, g2[1], g2[2]) if g2 else '-'))
        t('★ 제목이 먼저다(제목에서 되면 설명문을 안 본다)',
          pick2(conn, 'Genesis 1:3-5', _d)[1] == 'TITLE')
        h = hints(conn, '거룩이란 무엇인가? | 다윗의 회개', _d)
        t('실마리 — 구간 후보', any('단3' in a for a, _ in h['ranges']),
          str(h['ranges']))
        t('실마리 — 용어·인물 이름', any(w == '다윗' for w, _ in h['terms']),
          str([w for w, _ in h['terms']][:5]))
        t('★ 실마리에 기계 낱말(LEX)이 안 섞인다', len(h['terms']) <= 6,
          '%d개' % len(h['terms']))
        t('실마리 — 설명문 앞머리', bool(h['snippet']))
        t('설명문 없으면 조용히 제목만', pick2(conn, 'Genesis 1:3-5', None)[1] == 'TITLE')
        t('★ 설명문 JSON 이 깨져도 안 죽는다', yt_desc('{깨진') == '')

        # ── 실마리 라벨 언어 — **찾는 언어와 보이는 언어를 가른다**
        #   (2026-09-04 사용자 지시 「나는 한국어 표시를 선호한다」).
        _t = 'Genesis 5 - Methuselah and Enoch walked with God'
        _ko = [w for w, _e in hints(conn, _t, None, lang='EN')['terms']]
        _en = [w for w, _e in hints(conn, _t, None, lang='EN',
                                    label_lang='EN')['terms']]
        t('★ EN 제목에서 찾되 라벨은 한국어', '므두셀라' in _ko, str(_ko[:3]))
        t('  label_lang 을 EN 으로 주면 영어', 'Methuselah' in _en, str(_en[:3]))
        t('  같은 엔티티를 가리킨다',
          [e for _w, e in hints(conn, _t, None, lang='EN')['terms']]
          == [e for _w, e in hints(conn, _t, None, lang='EN',
                                   label_lang='EN')['terms']])

        # ── 책 이름과 같은 엔티티 (`book_name_entities`)
        _be = book_name_entities(conn)
        _names = {v[0] for v in _be.values()}
        t('★ 성경책 이름과 같은 인물을 찾는다', '학개' in _names and '룻' in _names,
          '%d명' % len(_be))
        t('  책 코드도 함께 낸다',
          all(isinstance(v[1], int) and 1 <= v[1] <= 66 for v in _be.values()))
        t('  평범한 용어는 안 걸린다', '헤세드' not in _names and '다윗' not in _names)

        # ── 다 쓴 설명문 지우기 (`purge_desc`) ──────────────────────────
        # ⚠⚠⚠ **메모리 DB 에서만 시험한다** (2026-09-04 사고 뒤 규칙).
        #   처음에 실 DB 연결(`conn`)로 `INSERT OR REPLACE` 를 썼다가, 그
        #   INSERT 는 NOT NULL 로 실패했는데 **같은 번호의 실데이터 5행이
        #   이미 있는 것을 「시험 잔재」로 오인해 지웠다.** 링크와 제목으로
        #   되살렸지만 `description`(채널·수집일)은 잃었다.
        #   ⇒ **selftest 는 실 DB 에 한 글자도 쓰지 않는다.** 표 몇 개면
        #     되는 검사는 메모리 DB 로 충분하다.
        import json as _pj
        from datetime import date as _pd, timedelta as _ptd
        _m = sqlite3.connect(':memory:')
        _m.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
                   " is_active INT, description TEXT)")
        _m.execute("CREATE TABLE sys_media_pending(pend_id INTEGER PRIMARY KEY,"
                   " media_id INT, scope TEXT, reason TEXT,"
                   " record_status TEXT DEFAULT 'LIVE')")
        _old = (_pd.today() - _ptd(days=200)).isoformat()
        _new = _pd.today().isoformat()

        def _mk(mid, act, ca, has=True):
            j = {'channel': 'C', 'collected_at': ca}
            if has:
                j['yt_desc'] = '남의 글'
            _m.execute("INSERT INTO sys_media_asset VALUES(?,?,?)",
                       (mid, act, _pj.dumps(j, ensure_ascii=False)))
        _mk(1, 1, _old)                       # 승인·오래됨 → 지운다
        _mk(2, 0, _old)                       # 미검토 → 안 지운다
        _mk(3, 1, _new)                       # 승인이나 최근 → 안 지운다
        _mk(4, 1, _old)                       # 승인·오래됐지만 보관함 → 안 지운다
        _m.execute("INSERT INTO sys_media_pending(media_id,scope,reason,"
                   "record_status) VALUES(4,'PERI','NO_RANGE','LIVE')")
        _mk(5, 1, '')                         # 시각 없음 → 기본은 안 지운다
        _n, _ids = purge_desc(_m, days=30, dry_run=True)
        t('★ 승인·30일 지난 것만 선택한다', _ids == [1], _ids)
        t('  미검토는 안 선택한다', 2 not in _ids)
        t('  최근 것은 안 선택한다', 3 not in _ids)
        t('  보관함 대기는 안 선택한다(재료가 필요하다)', 4 not in _ids)
        t('  시각 없는 것은 기본으로 안 선택한다', 5 not in _ids)
        _n2, _ids2 = purge_desc(_m, days=30, include_unknown=True, dry_run=True)
        t('  켜면 시각 없는 것도 선택한다', 5 in _ids2, _ids2)
        purge_desc(_m, days=30, dry_run=False)
        _j2 = _pj.loads(_m.execute("SELECT description FROM sys_media_asset"
                                   " WHERE media_id=1").fetchone()[0])
        t('★ yt_desc 만 지운다(channel 은 남는다)',
          'yt_desc' not in _j2 and _j2.get('channel') == 'C', str(_j2)[:50])
        t('  안 선택한 것은 그대로', 'yt_desc' in (_m.execute(
            "SELECT description FROM sys_media_asset WHERE media_id=2"
        ).fetchone()[0] or ''))
        _m.close()

        # ── 읽힘 비율 — **고정 표본**으로 잰다 ──
        # ⚠⚠ 예전에는 「승인분 대조」의 비율로 쟀다가, 정상화를 마치자
        #   **남은 것이 어려운 것들뿐**이라 통째로 FAIL 했다(§0-5 「자가 검증을
        #   데이터 상태에 걸지 말 것」 — 콘텐츠를 고치는 것이 본업인 저장소에서
        #   데이터 상태를 전제한 검사는 반드시 깨진다).
        #   ⇒ 실제 제목에서 뽑은 **박제 표본**으로 잰다. 데이터가 어떻게
        #     바뀌어도 이 잣대는 흔들리지 않는다.
        SAMPLE = [
            'What Is The Firmament In Genesis? | Genesis 1:6-8 Explained',
            '[창세기100문100답 122] 궁창과 그 역할(창세기 1:6~8)',
            '06. Genesis 1:9-13 The Third Day',
            '창세기 1장ㅣ하나님으로 가득한 세상ㅣ창조의 법칙',
            'Bible Explained - Genesis 15 - The Covenant',
            '매일성경 [레위기 5장 14절 - 6장 7절] / 매일성경묵상',
            '납달리지파가 받은 기업(수19:32-39)',
            '사사기 특강(12) - 마노아의 가정과 삼손의 출생(삿 13장)',
            '하나님께서 주시는 복의 특징ㅣ시편 92편',
            '210127 새벽기도회(배요한 위임목사) - 민수기 26장',
            '여호수아 18장 [새번역] Joshua chapter 18',
            '[5분 말씀] 여호수아 19장 49~50절',
        ]
        hit = sum(1 for s in SAMPLE if pick(conn, s)[0])
        t('★ 표본 읽힘이 9할을 넘는다', hit * 100 // len(SAMPLE) >= 90,
          '%d/%d' % (hit, len(SAMPLE)))

        # 대조가 실제로 도는가(비율은 안 잰다 — 데이터 상태를 안 전제한다)
        r = compare(conn, 1)
        t('승인분 대조가 돈다', isinstance(r.get('stat'), dict)
          and r['total'] == len(r['ok']) + len(r['hold']),
          '읽힘 %d / 보관 %d' % (len(r['ok']), len(r['hold'])))

        # ── 낱말 경계 ────────────────────────────────────────────────────
        # ⚠⚠ **이 규칙이 없어 5,063줄이 잘못 걸려 있었다**(2026-09-04 실측 —
        #   「엘」의 EN 이름이 `Er` 이라 `chapter`·`Better` 속에 2,716줄 ·
        #   「에서」가 조사 `~에서` 로 561줄). 규칙을 되돌리면 그대로 재발한다.
        t('★ 앞이 한글이면 이름이 아니다(조사)',
          not _ko_ok('방주에서 나오라', 2, 4))
        t('★ 낱말이면 잡는다', _ko_ok('에서와 야곱', 0, 2))
        t('  뒤에 조사는 허용한다', _ko_ok('예수님의 비유', 0, 2))
        t('★ 라틴은 낱말 경계를 지킨다(`Er` 이 `chapter` 에 안 걸린다)',
          not _lat_ok('the chapter one', 8, 10))
        t('  라틴 낱말이면 잡는다', _lat_ok('Er and Onan', 0, 2))
        t('★ 한글·라틴을 이름으로 가른다',
          not name_ok('방주에서', 2, 4, '에서')
          and not name_ok('chapter', 5, 7, 'Er'))
        rx0, nm0 = _ent_rx(conn, 'KO')
        if rx0:
            hit = {w for w, _e in find_names(rx0, nm0, '창세기 8장 방주에서')}
            t('★ 실제 이름표로도 조사를 안 잡는다', '에서' not in hit,
              str(sorted(hit)[:4]))
            hit2 = {w for w, _e in find_names(rx0, nm0, '에서와 야곱의 이야기')}
            t('  실제 이름표로 이름은 잡는다', '에서' in hit2)
        rxe, nme = _ent_rx(conn, 'EN')
        t('★ 라틴 %d 글자 미만 이름은 이름표에서 뺀다' % _LAT_MIN,
          not any(_script(k) == 'LAT' and len(k) < _LAT_MIN
                  for k in (nme or {})))

        # ── 문자체계 세 갈래 (2026-09-08) ────────────────────────────────
        # ⚠⚠ 라틴 규칙을 CJK 에 쓰면 `大衛` 가 **어느 중국어 제목에서도 안
        #   걸린다** — `isalpha()` 가 한자에도 참이라 앞뒤가 늘 막힌다.
        t('★ 문자체계를 셋으로 가른다',
          _script('다윗') == 'KO' and _script('David') == 'LAT'
          and _script('大衛') == 'CJK' and _script('ダビデ') == 'KANA'
          and _script('שלום') == 'CJK')
        t('★★★ 성직 호칭 앞의 이름은 설교자다(Pastor David Guzik · 김철수 목사)',
          name_context('devotional by Pastor David Guzik', 21, 26, 'David') == 'CLERGY'
          and name_context('Rev. Peter Kim', 5, 10, 'Peter') == 'CLERGY')
        t('  성경 호칭은 그대로(King David · Apostle Paul)',
          name_context('King David and Bathsheba', 5, 10, 'David') is None
          and name_context('The Apostle Paul', 12, 16, 'Paul') is None)
        t('★★★ 라틴 이름 뒤 성이 부호·끝으로 닫히면 사람 이름(David Suchet · David Alley,)',
          name_context('read by David Suchet', 8, 13, 'David') == 'SURNAME'
          and name_context('Bible Podcast, David Alley, Peace', 15, 20, 'David') == 'SURNAME')
        t('  Title Case 낱말·Christ 는 성이 아니다(David Cost Her · Jesus Christ)',
          name_context('Love for David Cost Her Everything', 9, 14, 'David') is None
          and name_context('Jesus Christ', 0, 5, 'Jesus') is None)
        t('  앞이 낱말이면 성이 아니다(Book of Haggai Summary:) · 인물이 아니면 안 본다(Golden Calf Altar,)',
          name_context('Book of Haggai Summary: Overview', 8, 14, 'Haggai') is None
          and name_context('Bethel: Golden Calf Altar, Tabernacle', 8, 19, 'Golden Calf', person=False) is None
          and name_context('Amos 2 - Petrus Kwik | BIBLE', 9, 15, 'Petrus') == 'SURNAME')
        t('★★★ 「바로」는 애굽 문맥이 있어야 바로 왕(바로 이 때 → 부사)',
          name_context('인생에서 조심할 때는 바로 이 때입니다', 13, 15, '바로') == 'COMMON'
          and name_context('애굽 왕 바로의 마음', 5, 7, '바로') is None
          and name_context('바로에게 가서 말하라', 0, 2, '바로') is None)
        t('★★★ 가타카나 이름은 가타카나 사이에서 거부(ハム in アブラハム)',
          not name_ok('アブラハムの試練', 4, 6, 'ハム')
          and not name_ok('サムエル記', 2, 4, 'エル'))
        t('  히라가나 조사는 붙어도 된다(ダビデの物語)',
          name_ok('ダビデの物語', 0, 3, 'ダビデ'))
        t('★ CJK 이름은 경계를 안 따진다',
          name_ok('大衛的詩篇', 0, 2, '大衛')
          and name_ok('イエスとダビデ', 4, 7, 'ダビデ'))
        t('★ 라틴은 낱말 속에서 거부한다',
          not name_ok('chapter', 4, 6, 'Er')
          and not name_ok('abraham', 4, 7, 'ham')
          and name_ok('cain and abel', 9, 13, 'abel'))
        t('  탐지력 — CJK 를 라틴으로 보면 못 잡는다',
          not _lat_ok('大衛的詩篇', 0, 2))

        # ── 보관함 유형 ──────────────────────────────────────────────────
        codes = {k for k, _l, _h in PEND_KINDS}
        # ⚠ **개수를 못 박지 않는다** — 유형을 늘릴 때마다 시험이 깨진다(§0-5).
        #   잣대는 「코드가 겹치지 않고 꼭 있어야 할 것이 있다」이다.
        t('보관함 유형표에 코드 중복이 없다', len(PEND_KINDS) == len(codes))
        t('  RECLASS(재검토 유보)·AUTO(자동추천 검토중)가 있다',
          R_RECLASS in codes and 'AUTO' in codes, sorted(codes))
        _auto = [x for x in PEND_KINDS if x[0] == 'AUTO'][0]
        t('  AUTO 는 「무엇인가」와 「어떻게 하나」를 함께 적는다',
          '검토중' in _auto[1] and _auto[2].strip() != '')
        # ★★★ 자동추천(검토중) 보관함 — 넣기·걷기 양방향(메모리 DB)
        _a = sqlite3.connect(':memory:')
        _a.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,"
                   " is_active INTEGER, record_status TEXT DEFAULT 'LIVE')")
        _a.execute("CREATE TABLE sys_link_asset(link_id INTEGER PRIMARY KEY, link_type TEXT,"
                   " clicked_id INTEGER, target_id INTEGER, record_status TEXT)")
        for _m, _act in ((1, 0), (2, 0), (3, 1), (4, 0)):
            _a.execute("INSERT INTO sys_media_asset(media_id,title,is_active) VALUES(?,?,?)",
                       (_m, 'm%d' % _m, _act))
        _a.execute("INSERT INTO sys_link_asset VALUES(1,'MEDI_ENTI',1,10,'PEND')")   # 후보만
        _a.execute("INSERT INTO sys_link_asset VALUES(2,'MEDI_ENTI',2,10,'PEND')")   # 후보 + LIVE
        _a.execute("INSERT INTO sys_link_asset VALUES(3,'MEDI_VERS',2,20,'LIVE')")
        _a.execute("INSERT INTO sys_link_asset VALUES(4,'MEDI_ENTI',3,10,'PEND')")   # 승인됨
        _a.commit()
        _n1, _g1 = sync_auto_pending(_a)
        _got = {r[0] for r in _a.execute("SELECT media_id FROM sys_media_pending WHERE hint_kind='AUTO'")}
        t('★★★ 후보 연결만 있는 미검토만 담는다(2번은 LIVE 가 있어 제외 · 3번은 승인)',
          _n1 == 1 and _got == {1}, (_n1, _got))
        t('  두 번 돌려도 안 는다(멱등)', sync_auto_pending(_a) == (0, 0))
        _a.execute("UPDATE sys_media_asset SET is_active=1 WHERE media_id=1"); _a.commit()
        _n2, _g2 = sync_auto_pending(_a)
        t('★ 승인하면 저절로 걷힌다', _g2 == 1 and not _a.execute(
            "SELECT 1 FROM sys_media_pending WHERE hint_kind='AUTO'").fetchone())
        # ★★★ 예배 실황 보관함(2026-09-16) — 등록 채널 · 구절 연결 없음 · 실황 제목만
        _a.execute("CREATE TABLE sys_media_channel(channel_name TEXT, channel_ext_id TEXT, record_status TEXT)")
        _a.execute("INSERT INTO sys_media_channel VALUES('등록교회','UCREG','LIVE')")
        _a.execute("ALTER TABLE sys_media_asset ADD COLUMN lang_code TEXT")
        _a.execute("ALTER TABLE sys_media_asset ADD COLUMN description TEXT")
        for _m, _ti, _d in ((11, '2026 주일예배 설교', '{"channel":"등록교회","channel_id":"UCREG"}'),   # 담긴다
                            (12, '2026 주일예배 설교', '{"channel":"딴교회"}'),                       # 미등록 — 안 담긴다
                            (13, '창세기 1장 강해', '{"channel":"등록교회"}'),                        # 실황 아님
                            (14, '수요예배 설교', '{"channel":"등록교회"}')):                         # 구절 연결 있음
            _a.execute("INSERT INTO sys_media_asset(media_id,title,is_active,lang_code,description) VALUES(?,?,0,'KO',?)",
                       (_m, _ti, _d))
        _a.execute("INSERT INTO sys_link_asset VALUES(9,'MEDI_VERS',14,20,'LIVE')")
        _a.execute("INSERT INTO sys_media_pending(media_id,scope,reason,note,added_at,record_status,hint_kind)"
                   " VALUES(11,'PERI','NONE','','', 'LIVE','NONE')")     # 이미 NONE 으로 있음 → 옮긴다
        _a.commit()
        _i, _u, _g = sync_live_service_pending(_a)
        _lv = {r[0] for r in _a.execute("SELECT media_id FROM sys_media_pending WHERE hint_kind='LIVESVC'")}
        t('★★★ 실황 보관함 — 등록 채널·연결 없음·실황 제목만(11) · 미등록 12 · 실황 아닌 13 · 연결 있는 14 는 아니다',
          _lv == {11} and (_i, _u, _g) == (0, 1, 0), (_i, _u, _g, _lv))
        t('  옛 유형을 note 에 남긴다(NONE→LIVESVC)',
          _a.execute("SELECT note FROM sys_media_pending WHERE media_id=11").fetchone()[0] == 'NONE→LIVESVC')
        t('  두 번 돌려도 안 는다(멱등)', sync_live_service_pending(_a) == (0, 0, 0))
        _a.execute("INSERT INTO sys_link_asset VALUES(10,'MEDI_VERS',11,30,'LIVE')"); _a.commit()
        t('★ 구절 연결이 생기면 저절로 걷힌다', sync_live_service_pending(_a)[2] == 1 and not _a.execute(
            "SELECT 1 FROM sys_media_pending WHERE hint_kind='LIVESVC'").fetchone())
        _a.close()
        # ── 재검토 유보(메모리 DB) ──────────────────────────────────────
        _r = sqlite3.connect(':memory:')
        init(_r)
        _r.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, is_active INT,"
                   " title TEXT, description TEXT, lang_code TEXT)")
        _r.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, link_type TEXT,"
                   " clicked_id INT, target_id INT, record_status TEXT, note TEXT)")
        _r.execute("CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT)")
        _r.execute("INSERT INTO sys_media_asset VALUES(7,1,'교리 강의','{}','KO')")
        _r.execute("INSERT INTO sys_link_asset VALUES(1,'MEDI_ENTI',7,11,'LIVE',NULL)")   # 틀린 인물
        _r.execute("INSERT INTO sys_link_asset VALUES(2,'MEDI_ENTI',7,12,'PEND',NULL)")   # 다른 용어(둔다)
        _r.execute("INSERT INTO sys_link_asset VALUES(3,'MEDI_VERS',7,100,'LIVE',NULL)")  # 구절(둔다)
        _r.execute("INSERT INTO sys_text_asset VALUES(12,'ENTITY_NAME','KO','언약')")
        nh = hold_reclass(_r, 7, wrong_eids=[11], why='교리 주제')
        pr = _r.execute("SELECT reason, hint_kind, note FROM sys_media_pending WHERE media_id=7").fetchone()
        t('★★★ [재검토 유보] — 보관함 RECLASS 로 담긴다', pr == (R_RECLASS, R_RECLASS, '교리 주제'), pr)
        t('  틀린 인물 연결만 뗀다 · 표식은 RECLASS_HIDE(사람 표식이 아니다) · 다른 연결은 그대로',
          nh == 1 and
          _r.execute("SELECT record_status, note FROM sys_link_asset WHERE sys_link_id=1").fetchone() == ('HIDE', 'RECLASS_HIDE')
          and _r.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=2").fetchone()[0] == 'PEND'
          and _r.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=3").fetchone()[0] == 'LIVE')
        t('  승인을 내린다', _r.execute("SELECT is_active FROM sys_media_asset WHERE media_id=7").fetchone()[0] == 0)
        t('  두 번 담아도 한 줄(멱등)', hold_reclass(_r, 7) == 0 and
          _r.execute("SELECT COUNT(*) FROM sys_media_pending WHERE media_id=7").fetchone()[0] == 1)
        rr = reclass_rows(_r)
        t('  분석 재료 — 남은 연결 이름을 낸다', len(rr) == 1 and rr[0][0] == 7 and rr[0][4] == '언약', rr)
        import inspect as _ins
        t('★ fill_hint_vid 가 유보 유형을 안 덮는다(소스)',
          "<>'RECLASS'" in _ins.getsource(fill_hint_vid))
        _r.close()
        k1, v1 = classify(conn, '창세기 1:1-5 설교', None, 'KO')
        t('★ 구간 하나면 ONE 이고 시작 절을 낸다',
          k1 == 'ONE' and isinstance(v1, int), '%s %s' % (k1, v1))
        k2, _ = classify(conn, '창세기 1:1-5 와 로마서 8:1-4', None, 'KO')
        t('★ 구간이 여럿이면 MULTI', k2 == 'MULTI', k2)
        k3, _ = classify(conn, '오늘의 은혜', None, 'KO', has_ent=True)
        t('  용어만 있으면 TERM', k3 == 'TERM', k3)
        k4, _ = classify(conn, '창세기 강해 시리즈', None, 'KO')
        t('★ 책 이름만 있으면 BOOK', k4 == 'BOOK', k4)
        k5, _ = classify(conn, '주일 오전 예배', None, 'KO')
        t('  실마리가 없으면 NONE', k5 == 'NONE', k5)
    finally:
        conn.execute('ROLLBACK')
        _CACHE.clear()

    # ★ 실 DB 를 안 건드렸는가
    c2 = appdb.connect(DB)
    left = c2.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                      " AND name='sys_media_pending'").fetchone()[0]
    t('★ 시험이 실 DB 에 표를 안 남긴다', left == 0 or
      c2.execute("SELECT COUNT(*) FROM sys_media_pending").fetchone()[0] >= 0)
    c2.close()
    conn.close()
    print('db_media_range selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--read')
    ap.add_argument('--scan', action='store_true')
    ap.add_argument('--normalize', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--resweep', action='store_true',
                    help='보관함 다시 훑기(규칙이 좋아졌을 때)')
    ap.add_argument('--scope', default='PERI')
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--pending', action='store_true')
    ap.add_argument('--reclass', action='store_true',
                    help='재검토 유보 목록(TSV) — 분석자가 읽고 재분류하는 재료')
    ap.add_argument('--active', type=int, default=1)
    ap.add_argument('--limit', type=int, default=15)
    a = ap.parse_args()

    if a.selftest:
        sys.exit(0 if selftest() else 1)

    conn = appdb.connect(DB)
    if a.init:
        init(conn)
        print('보관함 준비 완료')
    elif a.read:
        for bc, s, e, k in read(conn, a.read) or []:
            print('  [%s] %s' % (k, span_label(conn, s, e)))
        else:
            g, why = pick(conn, a.read)
            if not g:
                print('  → 못 정함: %s' % why)
    elif a.scan or a.normalize:
        r = normalize(conn, a.active, apply=a.apply and a.normalize)
        print('미디어 %d — 구간 확정 %d · 보관함 %d'
              % (r['total'], len(r['put']), len(r['hold'])))
        st = r['stat']
        print('  지금 연결과: 같다 %d · 넓다 %d · 좁다 %d · 일부겹침 %d'
              % (st['SAME'], st['WIDER'], st['NARROWER'], st['PARTIAL']))
        print('  보관함: 좌표없음 %d · 여럿 %d · 안겹침 %d'
              % (st[R_NONE], st[R_MULTI], st['OFF']))
        for mid, title, got, rel in r['put'][:a.limit]:
            print('   %-8s %-40s → %s' % (rel, title[:40],
                                          span_label(conn, got[1], got[2])))
        if r.get('applied'):
            print('  ✔ 적용 — MEDI_VERS %d줄 새로 · 되돌리기 --undo' % r['added'])
    elif a.resweep:
        r = resweep(conn, a.scope, apply=a.apply)
        print('보관함 %d건 — 이제 풀리는 것 %d건%s'
              % (r['total'], len(r['freed']), ' (적용됨)' if r['applied'] else ''))
        for mid, title, got in r['freed'][:a.limit]:
            print('   %-44s → %s' % (title[:44], span_label(conn, got[1], got[2])))
    elif a.undo:
        print('되돌림 %d줄' % undo(conn))
    elif a.reclass:
        rows = reclass_rows(conn)
        print('media_id\tlang\ttitle\tdesc\tlinks')
        for r in rows:
            print('\t'.join(str(x) for x in r))
        print('# %d건' % len(rows))
    elif a.pending:
        rows = pending(conn)
        print('보관함 %d건' % len(rows))
        for r in rows[:a.limit]:
            print('  [%s|%s] %s' % (r[2], r[3], (r[5] or '')[:52]))
    else:
        ap.print_help()
    conn.close()


if __name__ == '__main__':
    main()
