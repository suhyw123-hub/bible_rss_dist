# -*- coding: utf-8 -*-
"""연구자료 작성툴 (2026-08-20 신설·영구 — 0.txt 3·4번 확정 설계).

흐름 = 재료 담기(현재 캔버스·저장맵·구절/구간·페리코프)
     → 후보 트리(1차 연결 자동, 2차는 펼칠 때만 — 깊이 2 제한·중복 접기·교집합 ★)
     → 원문 보기 + **[선택 담기]**(발췌가 출처를 자동으로 물고 온다 —
       클립보드 붙여넣기는 출처를 잃으므로 쓰지 않는다)
     → 블록 초안(발췌/내 글, 순서·삭제·문구 손질 — 각 블록이 개체)
     → [저장] = 평문 통합(출처 줄) + user_ref_asset/user_ref_text/링크 확정.

★ 설계 원칙(사용자 확정): 병렬 재료끼리 연결을 새로 만들지 않는다 — 관계는
  교집합 ★ 표시와 저장된 글(링크의 결절)이 말한다. 값 스냅샷은 발췌를
  채택하는 순간(=연구자료가 되는 순간)에만 굳는다.
★ 링크는 KINDS(VERSE·ENTITY·BOOK_UNIT) 안에서만 — 설명문·내부자료 발췌는
  출처 줄로 남는다(REF_UNIT 링크는 후속 확장).
초안은 user_config['COMPOSE_DRAFT'] 에 보관 — 중단했다 재개할 수 있다.
"""
import json
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import i18n
import map_source


def _C(role, fb):
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb


def _tf(w, db, zone='prose'):
    try:
        import theme_font
        theme_font.register(w, db, zone)
    except Exception:
        pass


MAX_DEPTH = 2          # cascade 깊이 — 무한 표시는 화면이 아니라 늪이다
CHILD_LIMIT = 20       # 자산 종류별 상한(초과분은 「… 외 N」 줄로 알린다)
BIG_CHARS = 20000      # 여러 항목을 한꺼번에 담을 때 — 이보다 크면 한 번 묻는다
# (구) DRAFT_CHARS 400 — 「초안 생성」이 자르던 길이. 2026-08-20 폐기:
#      사용자가 원한 것은 자동 요약이 아니라 **전문을 담아 놓고 줄이기**였다.
DRAFT_KEY = 'COMPOSE_DRAFT'

# 발췌 출처 줄 접두 — 저장 본문에 문장으로 남는다
_REF_TYPES = ('STUDY', 'SERMON', 'REFERENCE')   # ★ 2026-10-16 내용 셋(docs/1.txt 2-2 · ref_kinds)


def _rt_label(k):
    import ref_kinds
    return ref_kinds.kind_label(k)


def _rt_code(label):
    import ref_kinds
    return next((k for k in ref_kinds.KINDS if ref_kinds.kind_label(k) == label), ref_kinds.normalize(label)[0])


class ComposeView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None, ver_getter=None,
                 on_saved=None):
        super().__init__(parent)
        self.db = db_path
        self.lang_getter = lang_getter
        self.ver_getter = ver_getter
        self.on_saved = on_saved
        self._items = {}      # iid → {'kind','id','end','label','checked','depth','loaded'}
        self._seen = {}       # (kind,id,end) → (root_iid, iid)  — 다리 ★ 판정
        self._grp_seq = 0     # 담기 묶음 번호 — 한 번의 담기가 한 묶음
        self._mat_order = []  # 재료(depth 0) iid 순서 — 방계 접기 복원용
        self._blocks = []     # [{'kind':'EXCERPT'|'MINE', 'text', 'src':{...}|None}]
        self._blk_widgets = []
        self._cur_iid = None
        self._view_lang_touched = False   # 단락 콤보를 사용자가 직접 골랐나
        self._check_w = 18        # 줄 앞 체크 글리프 폭(px) — _build 에서 실측
        self._textx_cache = {}    # 깊이 → 글자 시작 x(체크 영역 판정용)
        self._build()
        self._measure_check_w()
        # 단락(보기) 콤보의 **초기값은 문서 언어를 따른다** (2026-08-20 사용자).
        #   ⚠ 두 콤보가 다 만들어진 뒤라야 한다 — _build 안에서 부르면 순서에
        #     걸린다(문서 콤보가 상단으로 올라가며 실제로 걸렸다).
        self._sync_view_lang_to_doc(initial=True)
        self._load_draft()

    def _measure_check_w(self):
        """트리 글꼴로 '☐ ' 폭을 재 둔다 — 클릭이 체크인지 글자인지 가른다."""
        try:
            import tkinter.font as tkfont
            style = ttk.Style()
            fnt = style.lookup('Compose.Treeview', 'font') or 'TkDefaultFont'
            self._check_w = tkfont.nametofont(fnt).measure('☐ ') + 2
        except Exception:
            pass

    def _doc_lang(self):
        """**문서 언어** — 저장되는 연구자료 자체의 언어코드.

        보기 언어(`_lang`)와 엄격히 분리한다 — 항목을 무슨 언어로 들여다봤는지가
        글의 언어를 바꾸면 안 된다(2026-08-20 사용자 지적)."""
        c = getattr(self, '_doc_lang_combo', None)
        if c is not None:
            try:
                got = c.lang()
                if got:
                    return str(got).upper()
            except Exception:
                pass
        return ((self.lang_getter() if callable(self.lang_getter) else 'KO')
                or 'KO').upper()

    def _lang(self):
        """**보기 언어** — 원문 칸에 그 항목을 무슨 언어로 보일까(저장과 무관)."""
        lc = getattr(self, '_lang_combo', None)
        if lc is not None:
            try:
                got = lc.lang()
                if got:
                    return str(got).upper()
            except Exception:
                pass
        return ((self.lang_getter() if callable(self.lang_getter) else 'KO')
                or 'KO').upper()

    def _ui_lang(self):
        """**앱 화면 언어** — 선택하는 목록·라벨·약명이 따르는 것.

        ★★ **언어가 셋이라 헷갈린다. 한 줄로 못 박는다** (2026-08-23 사용자 신고
        「왼쪽 패널에 나타나는 구절약명이 한글/영어 뒤섞여 있다」):

            본문(성경 구절·도서 원문)만 **역본·보기 언어**를 따른다.
            약명·제목·라벨·목록은 예외 없이 **앱 화면 언어**를 따른다.
            글 안에 적히는 것(인용 서식·출처 줄)만 **문서 언어**를 따른다.

        ⚠ 뒤섞인 원인은 `_verse_label` 의 **기본값이 `_lang()`(보기 언어)** 이던
          것이다. 본문을 한 번 영어로 들여다보면 그 뒤에 그려진 줄만 영어가 되고
          이미 그려진 줄은 한국어로 남는다. 그래서 **기본값을 이쪽으로 뒤집었다**
          — 보기 언어가 필요한 자리(`_full_text`)는 `_lang()` 을 직접 부른다.
        ⚠ 같은 실수가 세 번째다(§39 문서/보기 언어 분리 · §41 「여기는 문서를
          고르는 목록이지 본문이 아니다」). 규칙을 문서에만 두면 또 샌다.
        """
        return ((self.lang_getter() if callable(self.lang_getter) else 'KO')
                or 'KO').upper()

    # ── UI ───────────────────────────────────────────────────────────────
    def _build(self):
        pnl = _C('panel', '#FFFFFF')
        self.configure()
        bar = tk.Frame(self, bg=_C('panel_alt', '#F4F6F7'))
        bar.pack(fill='x')
        def _b(text, cmd):
            return tk.Button(bar, text=text, font=('', 9), bd=1, relief='groove',
                             bg=_C('panel', '#EFF3F6'), fg=_C('fg', '#2C3E50'),
                             cursor='hand2', padx=6, command=cmd)
        _b(i18n.t('RC_SRC_CANVAS', '⇩ 캔버스에서 담기'), self._add_from_canvas
           ).pack(side='left', padx=(6, 2), pady=3)
        self._map_combo = ttk.Combobox(bar, width=24, state='readonly')
        self._map_combo.pack(side='left', padx=2)
        self._map_combo.bind('<<ComboboxSelected>>', self._add_from_map)
        self._map_combo.bind('<Button-1>', lambda e: self._fill_map_combo(), add='+')
        self._fill_map_combo()
        _b(i18n.t('RC_SRC_RANGE', '+ 구절/구간'), self._pick_range
           ).pack(side='left', padx=2, pady=3)
        _b(i18n.t('RC_SRC_PERI', '+ 페리코프'), self._pick_pericope
           ).pack(side='left', padx=2, pady=3)
        # ── 범위: 직계(실제 지나온 경로) / +방계(펼쳐만 둔 이웃) ─────────
        #    (2026-08-20 사용자 지시 — 옛 리포트의 DIRECT/COLLATERAL 을 계승.
        #     ★ 담기는 **둘 다** 하고 **보이기만** 거른다 — 값을 바꿔도 체크·
        #       발췌를 잃지 않고 즉시 되돌아온다.)
        self._scope = tk.StringVar(value=self._load_cfg('COMPOSE_SCOPE', 'ALL'))
        sf = tk.Frame(bar, bg=_C('panel_alt', '#F4F6F7'))
        sf.pack(side='left', padx=(12, 4))
        for txt, val in ((i18n.t('RC_SCOPE_DIRECT', '직계만'), 'DIRECT'),
                         (i18n.t('RC_SCOPE_ALL', '＋방계'), 'ALL')):
            tk.Radiobutton(sf, text=txt, value=val, variable=self._scope,
                           bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                           selectcolor=_C('panel', '#FFFFFF'),
                           command=self._apply_scope).pack(side='left')
        _b(i18n.t('RC_CLEAR', '✕ 비우기'), self._clear_materials
           ).pack(side='left', padx=(10, 2), pady=3)
        # ── 문서 단위 도구 — 비우기에서 한 뼘 떼어 놓는다(2026-08-20 사용자 배치):
        #      ⟨간격⟩ [문서 언어 ▾] [불러오기] [새 글]
        #    ★ **문서 언어는 상단에** — 초안 머리줄에 있으면 「이 단락의 언어」로
        #      읽힌다. 여기 있어야 화면 전체(=이 문서)에 걸린 값으로 보인다.
        tk.Frame(bar, bg=_C('panel_alt', '#F4F6F7'), width=28
                 ).pack(side='left', fill='y')
        tk.Label(bar, text=i18n.t('RC_DOC_LANG', '문서 언어'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50')
                 ).pack(side='left', padx=(0, 2))
        import lang_combo as _lcmb
        self._doc_lang_combo = _lcmb.LangCombo(
            bar, self.db, side='left', width=12, gap=0,
            key='LANGSEL_COMPOSE_DOC', on_change=lambda *_a: self._on_doc_lang(),
            default_lang=((self.lang_getter() if callable(self.lang_getter)
                           else 'KO') or 'KO'))
        self._doc_lang_combo.set_items(_lcmb.lang_items())
        self._load_btn = _b(i18n.t('RC_LOAD', '불러오기 ▾'), self._open_load_popup)
        self._load_btn.pack(side='left', padx=(8, 2), pady=3)
        self._load_pop = None
        _b(i18n.t('RC_NEW', '새 글'), self._new_doc
           ).pack(side='left', padx=2, pady=3)

        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4,
                            bg=_C('border', '#D5D8DC'))
        pw.pack(fill='both', expand=True)

        # 좌 — 위: 재료·연결 후보 / 아래: 담을 목록 (2026-08-20 사용자 배치)
        lpw = tk.PanedWindow(pw, orient='vertical', sashwidth=4,
                             bg=_C('border', '#D5D8DC'))
        pw.add(lpw, width=360)

        lf = tk.Frame(lpw, bg=pnl)
        tb = tk.Frame(lf, bg=_C('panel_alt', '#F4F6F7')); tb.pack(fill='x')
        tk.Label(tb, text=i18n.t('RC_P_TREE', '재료·연결 후보'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                 font=('', 9, 'bold')).pack(side='left', padx=6)
        # ★ [체크 전환] 단추 폐지 (2026-08-20 사용자 — 「위에 있어 왔다갔다
        #   불편하다. 목록의 체크상자를 직접 누르게 하라」). 이제 줄 앞
        #   ☐/☑ 글리프를 클릭하면 그 자리에서 토글된다(_on_lclick).
        tk.Button(tb, text=i18n.t('RC_DROP_MATERIAL', '✕ 재료 제거'),
                  font=('', 9), bd=1, relief='groove', padx=5,
                  bg=_C('panel', '#EFF3F6'), fg=_C('danger', '#C0392B'),
                  cursor='hand2', command=self._drop_material
                  ).pack(side='right', padx=2, pady=2)
        self._tv = ttk.Treeview(lf, show='tree', selectmode='browse')
        try:
            import theme_font
            theme_font.list_style('Compose.Treeview', self.db)
            self._tv.configure(style='Compose.Treeview')
        except Exception:
            pass
        vsb = ttk.Scrollbar(lf, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', self._on_select)
        self._tv.bind('<<TreeviewOpen>>', self._on_open)
        self._tv.bind('<space>', lambda e: (self._toggle_check(), 'break')[1])
        self._tv.bind('<Button-1>', self._on_lclick, add='+')
        self._tv.bind('<Button-3>', self._on_rclick)
        # 방계는 흐린 글씨로 — ○/● 글리프를 없앤 자리(기호를 줄인다)
        self._tv.tag_configure('side', foreground=_C('fg_dim', '#8A8F94'))
        lpw.add(lf, height=380)

        # ── 담을 목록 — 체크한 것만 모아 눈으로 확인 (2026-08-20 사용자 지시
        #    「왼쪽 트리가 복잡해 무엇을 체크했는지 알기 어렵다」)
        cf = tk.Frame(lpw, bg=pnl)
        ch = tk.Frame(cf, bg=_C('panel_alt', '#F4F6F7')); ch.pack(fill='x')
        self._cart_lbl = tk.Label(ch, text=i18n.t('RC_P_CART', '담을 목록'),
                                  bg=_C('panel_alt', '#F4F6F7'),
                                  fg=_C('fg', '#2C3E50'), font=('', 9, 'bold'))
        self._cart_lbl.pack(side='left', padx=6)
        tk.Button(ch, text=i18n.t('RC_CART_DROP', '✕ 제외'), font=('', 9),
                  bd=1, relief='groove', padx=5,
                  bg=_C('panel', '#EFF3F6'), fg=_C('danger', '#C0392B'),
                  cursor='hand2', command=self._cart_remove
                  ).pack(side='right', padx=2, pady=2)
        tk.Button(ch, text=i18n.t('RC_CART_TAKE', '⇊ 모두 담기'), font=('', 9),
                  bd=1, relief='groove', padx=5,
                  bg=_C('panel', '#EFF3F6'), fg=_C('accent', '#1A5276'),
                  cursor='hand2', command=self._take_all_checked
                  ).pack(side='right', padx=2, pady=2)
        self._cart = ttk.Treeview(cf, show='tree', selectmode='browse',
                                  style='Compose.Treeview')
        cvsb = ttk.Scrollbar(cf, orient='vertical', command=self._cart.yview)
        self._cart.configure(yscrollcommand=cvsb.set)
        cvsb.pack(side='right', fill='y')
        self._cart.pack(fill='both', expand=True)
        self._cart.bind('<<TreeviewSelect>>', self._on_cart_select)
        lpw.add(cf, height=200)

        # 우 — 위: 원문 보기 / 아래: 연구자료 초안
        rp = tk.PanedWindow(pw, orient='vertical', sashwidth=4,
                            bg=_C('border', '#D5D8DC'))
        pw.add(rp)

        srcf = tk.Frame(rp, bg=pnl)
        sh = tk.Frame(srcf, bg=_C('panel_alt', '#F4F6F7')); sh.pack(fill='x')
        tk.Label(sh, text=i18n.t('RC_P_SRC', '원문 보기'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                 font=('', 9, 'bold')).pack(side='left', padx=(6, 10))
        self._src_lbl = tk.Label(sh, text=i18n.t('RC_SRC_HINT',
                                 '왼쪽에서 항목을 선택하면 전문이 여기 보입니다.'),
                                 bg=_C('panel_alt', '#F4F6F7'),
                                 fg=_C('fg_dim', '#888'), anchor='w')
        self._src_lbl.pack(side='left', padx=6, pady=2, fill='x', expand=True)
        # ── 머리줄 배치 (2026-08-20 사용자 지정 순서):
        #      … [버전/언어 콤보][서식]   ⟨간격⟩   [⇊ 전문 담기][✚ 선택 담기]
        #    ⚠ **side='right' 는 먼저 pack 한 것이 오른쪽**이다 — 그래서 오른쪽
        #      끝부터 거꾸로 붙인다(처음에 순서대로 적었다가 뒤집혀 나왔다).
        #    ⚠ 콤보는 **여기서 pack 하지 않는다** — 항목 종류에 따라 골라 띄우고
        #      (구절=버전 / 그 외=언어) 순서를 지키려면 마지막에 붙어야 한다.
        tk.Button(sh, text=i18n.t('RC_TAKE_SEL', '✚ 선택 담기'),
                  font=('', 9, 'bold'), bd=0, padx=8, pady=2,
                  bg=_C('success', '#1E8449'), fg=_C('fg_on_dark', 'white'),
                  cursor='hand2', command=self._take_selection
                  ).pack(side='right', padx=(2, 6), pady=2)
        # ★ 담기 단추 셋의 뜻 (2026-08-20 사용자 지적 「초안 생성이 무엇인지
        #   모르겠다 / 전체 담기의 의미가 내 생각과 다르다」):
        #     [✚ 선택 담기] = 위 원문에서 **드래그한 부분**
        #     [⇊ 전문 담기] = 위에 보이는 **그 항목 전체**  ← 사용자 의도
        #     [⇊ 모두 담기](담을 목록 패널) = 체크한 **여러 항목 전문**
        tk.Button(sh, text=i18n.t('RC_TAKE_FULL', '⇊ 전문 담기'),
                  font=('', 9), bd=1, relief='groove', padx=8,
                  bg=_C('panel', '#EFF3F6'), fg=_C('fg', '#2C3E50'),
                  cursor='hand2', command=self._take_full
                  ).pack(side='right', padx=(0, 2), pady=2)
        # 보기 도구(콤보·서식)와 담기 단추 사이 간격 — 성격이 다른 무리다
        tk.Frame(sh, bg=_C('panel_alt', '#F4F6F7'), width=24
                 ).pack(side='right', fill='y')
        tk.Button(sh, text=i18n.t('RC_QFMT', '서식'), font=('', 9),
                  bd=1, relief='groove', padx=6,
                  bg=_C('panel', '#EFF3F6'), fg=_C('fg', '#2C3E50'),
                  cursor='hand2', command=self._open_quote_format
                  ).pack(side='right', padx=(0, 2), pady=2)
        # ── 항목별 언어/버전 (상단 bar 에서 내려온 자리). 구절이면 **성경 버전**,
        #    아니면 **언어**. 둘 다 직전값을 기억한다.
        import lang_combo
        self._lang_combo = lang_combo.LangCombo(
            sh, self.db, on_change=lambda *_a: self._on_lang_change(),
            side='right', width=12, gap=0, key='LANGSEL_COMPOSE',
            default_lang=((self.lang_getter() if callable(self.lang_getter)
                           else 'KO') or 'KO'))
        self._lang_combo.set_items(lang_combo.lang_items())
        self._lang_combo.combo.pack_forget()      # 자리는 _show_source 가 정한다
        self._ver_cb = ttk.Combobox(sh, width=10, state='readonly')
        self._ver_cb.bind('<<ComboboxSelected>>', self._on_ver_change)
        self._fill_ver_combo()
        self._src_txt = tk.Text(srcf, wrap='word', height=8, bd=0,
                                bg=pnl, fg=_C('fg', '#2C3E50'), padx=8, pady=6)
        _tf(self._src_txt, self.db, 'prose')
        self._src_txt.pack(fill='both', expand=True)
        try:
            import reading_pane
            reading_pane.enable_copy(self._src_txt)
        except Exception:
            self._src_txt.config(state='disabled')
        rp.add(srcf, height=240)

        drf = tk.Frame(rp, bg=pnl)
        dh = tk.Frame(drf, bg=_C('panel_alt', '#F4F6F7')); dh.pack(fill='x')
        tk.Label(dh, text=i18n.t('RC_P_DRAFT', '연구/설교노트 초안'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                 font=('', 9, 'bold')).pack(side='left', padx=(6, 10))
        tk.Label(dh, text=i18n.t('RC_TITLE', '제목'), bg=_C('panel_alt', '#F4F6F7'),
                 fg=_C('fg', '#2C3E50')).pack(side='left', padx=(0, 2))
        self._title_ent = tk.Entry(dh, width=30)
        self._title_ent.pack(side='left', padx=2, pady=3)
        self._type_cb = ttk.Combobox(dh, width=12, state='readonly',
                                     values=[_rt_label(k) for k in _REF_TYPES])
        self._type_cb.set(_rt_label('STUDY'))
        self._type_cb.pack(side='left', padx=4)
        # (문서 언어 콤보는 **상단 bar** 로 올라갔다 — 2026-08-20 사용자 지시.
        #  여기 초안 머리줄에 두면 「이 단락의 언어」로 읽힌다.)
        self._save_btn = tk.Button(dh, text=i18n.t('RC_SAVE', '저장'),
                                   font=('', 9, 'bold'), bd=0, padx=10, pady=2,
                                   bg=_C('success', '#1E8449'),
                                   fg=_C('fg_on_dark', 'white'),
                                   cursor='hand2', command=self._save)
        self._save_btn.pack(side='right', padx=6, pady=3)
        # ([불러오기]·[새 글]도 상단 bar 로 — 문서 단위 도구를 한자리에 모았다)
        tk.Button(dh, text=i18n.t('RC_ADD_MINE', '+ 내 글'), font=('', 9),
                  bd=1, relief='groove', padx=6,
                  bg=_C('panel', '#EFF3F6'), fg=_C('fg', '#2C3E50'),
                  cursor='hand2', command=lambda: self._add_block('MINE', '', None)
                  ).pack(side='right', padx=2, pady=3)
        # (구) [☑ 체크한 것 담기] 는 **담을 목록 패널의 [⇊ 모두 담기]** 로
        #      이사했다 (2026-08-20 — 체크한 것을 눈으로 확인한 자리에서 담는다)

        cvs = tk.Canvas(drf, bg=pnl, highlightthickness=0, bd=0)
        dsb = ttk.Scrollbar(drf, orient='vertical', command=cvs.yview)
        cvs.configure(yscrollcommand=dsb.set)
        dsb.pack(side='right', fill='y')
        cvs.pack(side='left', fill='both', expand=True)
        self._blk_f = tk.Frame(cvs, bg=pnl)
        _win = cvs.create_window((0, 0), window=self._blk_f, anchor='nw')
        cvs.bind('<Configure>', lambda e: cvs.itemconfigure(_win, width=e.width))
        self._blk_f.bind('<Configure>',
                         lambda e: cvs.configure(scrollregion=cvs.bbox('all')))
        self._blk_cvs = cvs
        # ★ 마우스 휠 (2026-08-20 사용자 — 「스크롤바는 있는데 휠이 안 된다」).
        #   ⚠ 자식 위젯은 부모 바인딩을 물려받지 않는다 — 블록을 그릴 때마다
        #     새 위젯에 다시 걸어야 한다(_bind_wheel).
        self._bind_wheel(cvs)
        self._bind_wheel(self._blk_f)
        rp.add(drf)

    # ── 재료 입구 4종 ────────────────────────────────────────────────────
    def add_parsed(self, parsed, tag=''):
        """map_source 표준 dict(맵/현재 캔버스) → 구절 재료들로 (**한 묶음**).

        직계(여정)·방계(펼쳐만 둔 노드)를 함께 담고 표식으로 가른다 —
        범위 라디오는 보이기만 거른다."""
        if not parsed:
            return 0
        self._grp_seq += 1
        grp, n = self._grp_seq, 0
        direct = set(parsed.get('direct') or [])
        for vid in parsed.get('verses', []):
            if self._add_material('VERSE', vid, None, grp=grp,
                                  direct=(vid in direct)):
                n += 1
        self._apply_scope()
        return n

    def _load_cfg(self, key, dflt):
        try:
            with appdb.connect(self.db) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (key,)).fetchone()
            return (r[0] if r and r[0] else dflt)
        except Exception:
            return dflt

    def _save_cfg(self, key, val):
        try:
            with appdb.connect(self.db) as c:
                cur = c.execute("UPDATE user_config SET config_val=? WHERE config_key=?",
                                (val, key))
                if cur.rowcount == 0:
                    c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)",
                              (key, val))
                c.commit()
        except Exception:
            pass

    def _apply_scope(self):
        """범위 값대로 방계 재료를 감췄다 폈다 한다 (detach/reattach — 비파괴)."""
        want_all = (self._scope.get() != 'DIRECT')
        self._save_cfg('COMPOSE_SCOPE', self._scope.get())
        for pos, iid in enumerate(list(self._mat_order)):
            m = self._items.get(iid)
            if not m:
                continue
            show = want_all or m.get('direct', True)
            try:
                if show:
                    self._tv.reattach(iid, '', pos)
                else:
                    self._tv.detach(iid)
            except Exception:
                pass

    def _add_from_canvas(self, quiet=False):
        """지금 P4 캔버스에 펼쳐진 것을 **그 순간 퍼 담는다**(살아 있는 연결 아님).

        ⚠ 같은 재료는 다시 담기지 않는데 조용해서 「눌러도 변화가 없다」로
          보였다(2026-08-20 사용자) — 담은 수·건너뛴 수를 알린다."""
        try:
            app = self.winfo_toplevel()
            parsed = app._canvas_material()
        except Exception as e:
            print(f'[compose canvas] {e}')
            parsed = None
        if not parsed or not parsed.get('verses'):
            if not quiet:
                messagebox.showinfo(i18n.t('RC_TOOL', '작성도구'),
                                    i18n.t('RC_NO_CANVAS', '캔버스에 펼쳐진 구절이 없습니다.'),
                                    parent=self)
            return
        total = len(parsed.get('verses') or [])
        n = self.add_parsed(parsed)
        if not quiet:
            messagebox.showinfo(
                i18n.t('RC_TOOL', '작성도구'),
                i18n.t('RC_ADDED', '{n}개를 담았습니다. (이미 있던 {s}개는 건너뜀)'
                       ).format(n=n, s=max(0, total - n)), parent=self)

    def _fill_map_combo(self):
        try:
            rows = map_source.list_maps(self.db, include_auto=False)[:30]
            self._map_combo['values'] = [
                f"{r['root_id']} | {r['map_name']}" for r in rows]
            if not self._map_combo.get():
                self._map_combo.set(i18n.t('RC_SRC_MAP', '저장맵 ▾'))
        except Exception as e:
            print(f'[compose maps] {e}')

    def _add_from_map(self, _e=None):
        sel = self._map_combo.get()
        if ' | ' not in sel:
            return
        rid, name = sel.split(' | ', 1)
        m = map_source.load_map(self.db, int(rid), name)
        self.add_parsed(m)
        self._map_combo.set(i18n.t('RC_SRC_MAP', '저장맵 ▾'))

    def _pick_range(self):
        self._range_dialog(peri=False)

    def _pick_pericope(self):
        self._range_dialog(peri=True)

    def _range_dialog(self, peri=False):
        """책/장(/절+끝절 | 페리코프) 콤보 팝업 — My Lens 구간 선택 문법."""
        pop = tk.Toplevel(self)
        pop.title(i18n.t('RC_SRC_PERI', '+ 페리코프') if peri
                  else i18n.t('RC_SRC_RANGE', '+ 구절/구간'))
        pop.transient(self.winfo_toplevel())
        pnl = _C('panel', '#FFFFFF')
        pop.configure(bg=pnl)
        f = tk.Frame(pop, bg=pnl, padx=10, pady=10)
        f.pack(fill='both', expand=True)
        # ★ 책을 고르는 콤보는 **정식명**이다 (2026-08-20 사용자 지적 —
        #   약명은 구절 참조 표기(창 1:1)·좁은 라벨의 것이고, 앱의 다른 책
        #   선택 콤보(P1·관리자 구절연결관리)는 전부 full_name 이다).
        # ⚠ 책을 **고르는** 콤보라 앱 화면 언어다(보기 언어 아님 — §`_ui_lang`).
        lang = self._ui_lang()
        with appdb.connect(self.db) as c:
            books = c.execute(
                "SELECT book_code, full_name FROM book_names WHERE lang_code=? "
                "ORDER BY book_code", (lang,)).fetchall()
            if not books:
                books = c.execute(
                    "SELECT book_code, full_name FROM book_names "
                    "WHERE lang_code IN ('EN','KO') GROUP BY book_code "
                    "ORDER BY book_code").fetchall()
        bmap = {r[1]: r[0] for r in books}
        cb_b = ttk.Combobox(f, width=12, state='readonly', values=list(bmap.keys()))
        cb_c = ttk.Combobox(f, width=5, state='readonly')
        cb_b.grid(row=0, column=0, padx=2); cb_c.grid(row=0, column=1, padx=2)
        if peri:
            lb = tk.Listbox(f, width=44, height=12)
            lb.grid(row=1, column=0, columnspan=4, pady=6)
            peri_rows = []

            def on_chap(_e=None):
                lb.delete(0, 'end'); peri_rows.clear()
                bc, ch = bmap.get(cb_b.get()), cb_c.get()
                if not bc or not ch:
                    return
                with appdb.connect(self.db) as c:
                    rows = c.execute("""
                        SELECT p.pericope_id, p.start_vid, p.end_vid,
                               COALESCE(t.contents, t.title, p.peri_code)
                        FROM sys_pericope_asset p
                        LEFT JOIN sys_text_asset t ON t.text_type='PERI_TITLE'
                             AND t.clicked_id=p.pericope_id
                             AND UPPER(t.lang_code)=?
                             AND COALESCE(t.record_status,'LIVE')='LIVE'
                        WHERE p.peri_type='BODY'
                          AND COALESCE(p.record_status,'LIVE')='LIVE'
                          AND p.start_vid IN (SELECT verse_id FROM bible_index
                                              WHERE bcode=? AND chapter=?)
                        ORDER BY p.start_vid""", (lang, bc, int(ch))).fetchall()
                for pid, sv, ev, title in rows:
                    peri_rows.append((sv, ev, pid, title))
                    lb.insert('end', f"{self._verse_label(sv, ev)}  {title or ''}")

            def ok():
                sel = lb.curselection()
                if not sel:
                    return
                sv, ev, pid, title = peri_rows[sel[0]]
                # ★ 단락 제목을 라벨로 살린다 — 구간으로만 담으면 「막 6:30-44」
                #   가 되어 무슨 단락이었는지 사라진다(2026-08-20 난이도 분석).
                lab = self._verse_label(sv, ev)
                if title:
                    lab += ' · ' + str(title)[:24]
                self._add_material('VERSE', sv, ev if ev and ev != sv else None,
                                   label=lab, peri_id=pid)
                pop.destroy()
        else:
            cb_v = ttk.Combobox(f, width=5, state='readonly')
            cb_e = ttk.Combobox(f, width=5, state='readonly')
            cb_v.grid(row=0, column=2, padx=2); cb_e.grid(row=0, column=3, padx=2)
            tk.Label(f, text=i18n.t('RC_RANGE_END', '~ 끝 절(선택)'), bg=pnl,
                     fg=_C('fg_dim', '#888')).grid(row=1, column=2, columnspan=2)
            vmap = {}

            def on_chap(_e=None):
                bc, ch = bmap.get(cb_b.get()), cb_c.get()
                if not bc or not ch:
                    return
                with appdb.connect(self.db) as c:
                    rows = c.execute("SELECT verse, verse_id FROM bible_index "
                                     "WHERE bcode=? AND chapter=? ORDER BY verse",
                                     (bc, int(ch))).fetchall()
                vmap.clear(); vmap.update({str(v): vid for v, vid in rows})
                cb_v['values'] = list(vmap.keys()); cb_v.set('')
                cb_e['values'] = [''] + list(vmap.keys()); cb_e.set('')

            def ok():
                sv = vmap.get(cb_v.get())
                if not sv:
                    return
                ev = vmap.get(cb_e.get())
                if ev and ev <= sv:
                    ev = None
                self._add_material('VERSE', sv, ev)
                pop.destroy()

        def on_book(_e=None):
            bc = bmap.get(cb_b.get())
            with appdb.connect(self.db) as c:
                chaps = c.execute("SELECT DISTINCT chapter FROM bible_index "
                                  "WHERE bcode=? ORDER BY chapter", (bc,)).fetchall()
            cb_c['values'] = [r[0] for r in chaps]; cb_c.set('')
        cb_b.bind('<<ComboboxSelected>>', on_book)
        cb_c.bind('<<ComboboxSelected>>', on_chap)
        tk.Button(f, text=i18n.t('COMMON_ADD', '추가'), command=ok,
                  bg=_C('success', '#1E8449'), fg=_C('fg_on_dark', 'white'),
                  bd=0, padx=12, pady=3
                  ).grid(row=2, column=0, columnspan=4, pady=(8, 0))

    # ── 후보 트리 ────────────────────────────────────────────────────────
    def _root_of(self, iid):
        """그 줄이 어느 재료(depth 0) 밑에 있는가."""
        cur = iid
        while cur:
            if self._items.get(cur, {}).get('depth') == 0:
                return cur
            cur = self._tv.parent(cur)
        return None

    def _grp_of(self, iid):
        """그 줄이 속한 **재료 묶음** — 한 번의 담기(맵·캔버스·구간)가 한 묶음."""
        r = self._root_of(iid)
        return self._items.get(r, {}).get('grp') if r else None

    def _mk(self, parent, kind, tid, end, label, depth):
        """★ = **서로 다른 재료를 잇는 다리** (2026-08-20 좁힘).

        ⚠ 「이미 나온 것 전부」로 재면 별이 잡음이 된다 — 한 캔버스에서 온
          재료들은 애초에 서로 연결돼 있어 실측 53줄이 별을 달았다. 그래서
          ① 재료(depth 0) 자신은 별을 달지 않고 ② **다른 재료 밑에서** 또
          나올 때만 양쪽에 단다.
        """
        key = (kind, int(tid), int(end) if end else None)
        iid = self._tv.insert(parent, 'end', text='☐ ' + label)
        self._items[iid] = {'kind': kind, 'id': int(tid),
                            'end': (int(end) if end else None),
                            'label': label, 'checked': False,
                            'depth': depth, 'loaded': False}
        if depth > 0:
            # ★ 판정 단위는 재료가 아니라 **묶음(grp)** 이다 — 한 맵/캔버스에서
            #   함께 들어온 재료들은 애초에 한 경로라 교집합이 당연하다(실측 47줄).
            #   서로 다른 입구로 담은 재료 사이의 겹침만 다리로 본다.
            my_grp = self._grp_of(iid)
            prev = self._seen.get(key)
            if prev is None or prev[0] is None:
                self._seen[key] = (my_grp, iid)
            elif prev[0] != my_grp:
                self._star(iid)
                self._star(prev[1])          # 먼저 있던 쪽에도
        elif key not in self._seen:
            self._seen[key] = (None, iid)    # 재료 자신 — 다리 판정에서 뺀다
        if kind == 'VERSE' and depth < MAX_DEPTH:
            self._tv.insert(iid, 'end', text='…')     # 지연 펼침 자리
        return iid

    def _star(self, iid):
        if iid not in self._items:
            return
        t = self._tv.item(iid, 'text')
        if not t.endswith(' ★'):
            self._tv.item(iid, text=t + ' ★')

    def _add_material(self, kind, tid, end, label=None, grp=None, direct=True,
                      peri_id=None):
        key = (kind, int(tid), int(end) if end else None)
        for iid, m in self._items.items():
            if m['depth'] == 0 and (m['kind'], m['id'], m['end']) == key:
                return False                            # 같은 재료 중복 금지
        label = label or self._verse_label(tid, end)
        # ⚠ ●/○ 글리프는 2026-08-20 폐지 — 체크 ☐·펼침 세모와 겹쳐 「기호가
        #   복잡하다」(사용자). 방계는 **흐린 글씨**(tag 'side')로만 가른다.
        if grp is None:                                 # 낱개로 담은 것 = 제 묶음
            self._grp_seq += 1
            grp = self._grp_seq
        iid = self._mk('', kind, tid, end, label, 0)
        self._items[iid]['grp'] = grp
        self._items[iid]['direct'] = bool(direct)
        self._items[iid]['peri_id'] = peri_id     # 페리코프로 담았으면 그 id
        if not direct:
            self._tv.item(iid, tags=('side',))
        self._mat_order.append(iid)
        # 이 재료가 **이미 남의 자식으로** 그려져 있으면 그쪽을 거둔다
        # (재료가 대표 — 중복 원칙 ②. 늦게 담은 경우가 여기 걸린다)
        self._purge_dup_children(kind, int(tid), iid)
        self._load_children(iid)
        self._tv.item(iid, open=True)
        return True

    def _purge_dup_children(self, kind, tid, keep_iid):
        for i in [x for x in list(self._items) if x != keep_iid]:
            m = self._items.get(i)
            if not m or m['depth'] == 0:
                continue
            if (m['kind'], m['id']) != (kind, tid):
                continue
            try:
                for ch in self._tv.get_children(i):
                    self._items.pop(ch, None)
                self._items.pop(i, None)
                self._tv.delete(i)
            except Exception:
                pass

    def _on_open(self, _e=None):
        iid = self._tv.focus()
        m = self._items.get(iid)
        if m and not m['loaded'] and m['kind'] == 'VERSE' and m['depth'] < MAX_DEPTH:
            self._load_children(iid)

    def _load_children(self, iid):
        m = self._items.get(iid)
        if not m or m['loaded']:
            return
        m['loaded'] = True
        for ch in self._tv.get_children(iid):        # '…' 자리 제거
            if ch not in self._items:
                self._tv.delete(ch)
        depth = m['depth'] + 1
        vid, end = m['id'], m['end']
        try:
            with appdb.connect(self.db) as c:
                self._fetch_children(c, iid, vid, end, depth)
        except Exception as e:
            print(f'[compose children] {e}')

    def _skip_keys(self, iid):
        """이 줄 밑에 **자식으로 만들지 않을** 것들 (2026-08-20 중복 원칙).

        ① 조상 — A→B→A 왕복 금지(캔버스가 쓰는 규칙과 같다)
        ② 이미 담긴 재료 — 한 쌍이 트리에 두 번 나오지 않게. 재료 쪽이 대표다
           (사용자 「양방향 연결이 중복 표시된다. 하나만 표시해야 한다」).
        """
        skip = set()
        cur = iid
        while cur:
            m = self._items.get(cur)
            if m:
                skip.add((m['kind'], m['id']))
            cur = self._tv.parent(cur)
        for r in self._mat_order:
            m = self._items.get(r)
            if m:
                skip.add((m['kind'], m['id']))
        return skip

    def _fetch_children(self, c, iid, vid, end, depth):
        # ⚠ 후보 트리는 **고르는 목록**이라 이름·약명이 앱 화면 언어를 따른다
        #   (이 `lang` 은 용어 이름 `ENTITY_NAME` 조회에 쓰인다 — §`_ui_lang`).
        lang, lo, hi = self._ui_lang(), vid, (end or vid)
        skip = self._skip_keys(iid)
        # ① 연결 구절 (양방향 dedup — 다중 rel 은 첫 라벨만)
        rows = c.execute("""
            SELECT CASE WHEN clicked_id BETWEEN ? AND ? THEN target_id ELSE clicked_id END t
            FROM sys_link_asset WHERE link_type='VERS_VERS'
              AND COALESCE(record_status,'LIVE')='LIVE'
              AND (clicked_id BETWEEN ? AND ? OR target_id BETWEEN ? AND ?)
            """, (lo, hi, lo, hi, lo, hi)).fetchall()
        seen = []
        for (t,) in rows:
            if t in seen or lo <= t <= hi or ('VERSE', t) in skip:
                continue
            seen.append(t)
        for t in seen[:CHILD_LIMIT]:
            self._mk(iid, 'VERSE', t, None, self._verse_label(t, None), depth)
        if len(seen) > CHILD_LIMIT:
            self._tv.insert(iid, 'end', text=i18n.t(
                'RC_MORE', '… 외 {n}건').format(n=len(seen) - CHILD_LIMIT))
        # ② 구절 설명문 (있을 때만 한 줄)
        r = c.execute("""
            SELECT 1 FROM sys_text_asset WHERE text_type='VERS_DESC'
              AND clicked_id BETWEEN ? AND ?
              AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1""",
                      (lo, hi)).fetchone()
        if r:
            self._mk(iid, 'DESC', vid, end,
                     i18n.t('RC_K_DESC', '구절 설명문') + ' · '
                     + self._verse_label(vid, end), depth)
        # ③ 내부자료 글
        for uid, label in c.execute("""
            SELECT DISTINCT u.ref_unit_id,
                   COALESCE(s.title_ko, s.title) || ' · ' || u.unit_label
            -- ★ 2026-08-24 통합 표(`REFU_VERS`)
            FROM sys_link_asset l
            JOIN sys_ref_unit u ON u.ref_unit_id=l.clicked_id
                 AND COALESCE(u.record_status,'LIVE')='LIVE'
            JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id
            WHERE l.link_type='REFU_VERS'
              AND """ + _vr.overlaps_sql('l', 'target_id', 'end_id') + """
              AND COALESCE(l.record_status,'LIVE')='LIVE'
            LIMIT ?""", _vr.overlaps_args(lo, hi) + [CHILD_LIMIT]).fetchall():
            self._mk(iid, 'REF', uid, None, label, depth)
        # ④ 도서·설교 유닛
        for uid, label in c.execute("""
            SELECT u.unit_id, b.title || ' · ' || u.unit_label
            FROM sys_book_unit u JOIN sys_book_asset b ON b.book_id=u.book_id
            WHERE """ + _vr.overlaps_sql('u', 'start_vid', 'end_vid') + """
              AND COALESCE(u.record_status,'LIVE')='LIVE'
            LIMIT ?""", _vr.overlaps_args(lo, hi) + [CHILD_LIMIT]).fetchall():
            self._mk(iid, 'BOOK', uid, None, label, depth)
        # ⑤ 용어(엔티티) — 대표(is_key) 우선 소수만
        for eid, name in c.execute("""
            -- ★ 2026-08-24 통합 표(`ENTI_VERS`)
            SELECT ev.clicked_id, t.contents FROM sys_link_asset ev
            JOIN sys_text_asset t ON t.text_type='ENTITY_NAME'
                 AND t.clicked_id=ev.clicked_id
                 AND UPPER(t.lang_code)=?
                 AND COALESCE(t.record_status,'LIVE')='LIVE'
            WHERE ev.link_type='ENTI_VERS'
              AND ev.target_id BETWEEN ? AND ?
              AND COALESCE(ev.record_status,'LIVE')='LIVE'
            GROUP BY ev.clicked_id
            ORDER BY MAX(ev.is_key) DESC LIMIT 8""",
                                   (lang, lo, hi)).fetchall():
            self._mk(iid, 'ENTITY', eid, None,
                     i18n.t('RC_K_ENTITY', '용어') + ' · ' + str(name), depth)

    # ── 체크·제거 ────────────────────────────────────────────────────────
    def _on_lclick(self, e):
        """줄 앞 ☐/☑ 를 누르면 그 자리에서 체크 (2026-08-20 사용자 지시).

        ⚠ 글자 영역 클릭은 그대로 선택(원문 보기)이라야 한다 — 체크 글리프
          폭 안에서만 가로챈다. 폭은 트리 글꼴로 실측한다."""
        iid = self._tv.identify_row(e.y)
        if not iid or iid not in self._items:
            return None
        el = str(self._tv.identify_element(e.x, e.y))
        if 'indicator' in el:
            return None                       # 펼침 세모는 Tk 에 맡긴다
        x0 = self._text_x(iid, e.y)
        if x0 is None:
            return None
        if x0 <= e.x <= x0 + self._check_w:   # 글리프 폭 안 = 체크
            self._tv.selection_set(iid)
            self._toggle_check()
            return 'break'
        return None

    def _text_x(self, iid, y):
        """그 줄의 **글자 시작 x** — 들여쓰기·펼침 세모 폭만큼 오른쪽이다.

        ⚠ bbox[0] 은 줄 왼쪽 끝(세모 포함)이라 체크 판정에 쓰면 안 된다
          (2026-08-20 실측 실패). 깊이마다 한 번 훑어 캐시한다."""
        depth = 0
        cur = self._tv.parent(iid)
        while cur:
            depth += 1
            cur = self._tv.parent(cur)
        if depth in self._textx_cache:
            return self._textx_cache[depth]
        bb = self._tv.bbox(iid)
        if not bb:
            return None
        for x in range(bb[0], bb[0] + 220, 2):
            if 'text' in str(self._tv.identify_element(x, y)):
                self._textx_cache[depth] = x
                return x
        return None

    def _on_rclick(self, e):
        iid = self._tv.identify_row(e.y)
        if iid:
            self._tv.selection_set(iid)
            self._toggle_check()

    def _on_lang_change(self):
        """단락(보기) 언어가 바뀌면 원문 칸만 다시 읽는다 — 문서 언어는 불변."""
        self._view_lang_touched = True     # 사용자가 손댔다 → 문서 언어를 안 따른다
        if self._cur_iid:
            self._on_select()

    def _on_doc_lang(self):
        """문서 언어 변경 — 단락 콤보가 아직 손을 안 탔으면 함께 옮긴다."""
        self._sync_view_lang_to_doc()

    def _sync_view_lang_to_doc(self, initial=False):
        """단락(보기) 콤보를 문서 언어에 맞춘다.

        ★ 「초기값은 메인 언어콤보를 따른다」(사용자) — 처음 열 때, 그리고
          사용자가 단락 콤보를 직접 만지기 전까지는 문서 언어를 따라간다.
          한 번 직접 고르면 그 뒤로는 그 선택이 남는다(화면별 기억)."""
        if getattr(self, '_view_lang_touched', False):
            return
        vc = getattr(self, '_lang_combo', None)
        if vc is None:
            return
        if initial and self._load_cfg('LANGSEL_COMPOSE', ''):
            return                      # 지난번에 고른 값이 있으면 그것을 살린다
        try:
            import lang_combo as _lc
            vc.set_items(_lc.lang_items(), select=(None, self._doc_lang()))
        except Exception:
            pass
        if self._cur_iid:
            self._on_select()

    # ── 담을 목록(체크한 것) ─────────────────────────────────────────────
    def _sync_cart(self):
        """체크한 항목만 아래 왼쪽 패널에 모은다 (트리가 복잡해도 한눈에)."""
        cart = getattr(self, '_cart', None)
        if cart is None:
            return
        for i in cart.get_children(''):
            cart.delete(i)
        order = {iid: n for n, iid in enumerate(self._visible_iids())}
        rows, seen = [], set()
        for i, m in sorted(self._items.items(),
                           key=lambda kv: order.get(kv[0], 10 ** 6)):
            if not m.get('checked'):
                continue
            key = (m['kind'], m['id'], m['end'])
            if key in seen:            # 같은 자산은 한 줄만 (자리마다 세지 않는다)
                continue
            seen.add(key)
            rows.append((i, m))
        self._cart_map = {}
        for iid, m in rows:
            cid = cart.insert('', 'end', text=m['label'])
            self._cart_map[cid] = iid
        try:
            self._cart_lbl.config(
                text=i18n.t('RC_P_CART', '담을 목록') + f' ({len(rows)})')
        except Exception:
            pass

    def _on_cart_select(self, _e=None):
        """담을 목록에서 선택하면 원문 칸도 그 항목으로 (확인하며 지우기 좋게)."""
        sel = self._cart.selection()
        if not sel:
            return
        iid = (getattr(self, '_cart_map', {}) or {}).get(sel[0])
        if iid and iid in self._items:
            self._cur_iid = iid
            self._show_source(self._items[iid])

    def _cart_remove(self):
        """담을 목록에서 빼기 = 그 항목 체크 해제."""
        sel = self._cart.selection()
        if not sel:
            return
        iid = (getattr(self, '_cart_map', {}) or {}).get(sel[0])
        m = self._items.get(iid or '')
        if not m:
            return
        self._set_checked((m['kind'], m['id'], m['end']), False)
        self._sync_cart()

    def _clear_materials(self):
        """재료·후보를 모두 비운다 (초안 블록은 그대로 — 2026-08-20 사용자 지시).

        경로맵과 무관하게 페리코프만으로 새로 쓰려는 흐름을 막지 않기 위해."""
        if self._items and not messagebox.askyesno(
                i18n.t('RC_TOOL', '작성도구'),
                i18n.t('RC_CLEAR_ASK', '왼쪽 재료·후보를 모두 비울까요?\n'
                       '(아래 초안 블록은 그대로 둡니다)'), parent=self):
            return
        for i in self._tv.get_children(''):
            self._tv.delete(i)
        self._items.clear()
        self._seen.clear()
        self._mat_order.clear()
        self._textx_cache.clear()
        self._cur_iid = None
        self._src_lbl.config(text=i18n.t('RC_SRC_HINT',
                                         '왼쪽에서 항목을 선택하면 전문이 여기 보입니다.'))
        self._src_txt.config(state='normal')
        self._src_txt.delete('1.0', 'end')
        self._sync_cart()

    # ── 성경 버전 콤보 (구절 항목일 때만 보인다) ─────────────────────────
    def _fill_ver_combo(self):
        try:
            with appdb.connect(self.db) as c:
                # ★ **읽기 목록**을 쓴다 (2026-08-23) — 여기서 고르는 것은
                #   「인용할 본문을 어느 역본으로 볼까」라 **읽기** 쪽이다.
                #   비교 목록(`PREFERRED_VERSIONS`)에는 콥틱 신약·히브리 원문이
                #   들어 있어 인용문 후보로는 맞지 않는다.
                #   ⚠ 옛 설정(읽기 목록이 아직 없는 사용자)은 비교 목록으로 폴백.
                r = c.execute("SELECT config_val FROM user_config "
                              "WHERE config_key='READING_VERSIONS'").fetchone()
                if not (r and r[0]):
                    r = c.execute("SELECT config_val FROM user_config "
                                  "WHERE config_key='PREFERRED_VERSIONS'").fetchone()
                codes = []
                if r and r[0]:
                    codes = [x for x in json.loads(r[0])]
                if not codes:
                    codes = [x[0] for x in c.execute(
                        "SELECT version_code FROM bible_version ORDER BY version_code")]
            self._ver_cb['values'] = codes
            saved = self._load_cfg('COMPOSE_VER', '')
            cur = (saved if saved in codes else
                   ((self.ver_getter() if callable(self.ver_getter) else None)
                    or (codes[0] if codes else 'KRV')))
            self._ver_cb.set(cur)
        except Exception as e:
            print(f'[compose ver] {e}')

    def _on_ver_change(self, _e=None):
        self._save_cfg('COMPOSE_VER', self._ver_cb.get())
        if self._cur_iid:
            self._on_select()

    def _ver(self):
        try:
            v = self._ver_cb.get()
            if v:
                return v
        except Exception:
            pass
        return (self.ver_getter() if callable(self.ver_getter) else 'KRV') or 'KRV'

    def _toggle_check(self):
        sel = self._tv.selection()
        if not sel:
            return
        iid = sel[0]
        m = self._items.get(iid)
        if not m:
            return
        # ★ 체크는 **자산 단위**다 (2026-08-20 실측으로 잡음) — 같은 구절이
        #   트리 여러 자리에 나올 수 있는데 자리마다 따로 세면 담을 목록에
        #   같은 것이 여러 번 오르고, 저장·복원에서 개수가 3→6 으로 불어난다.
        want = not m['checked']
        self._set_checked((m['kind'], m['id'], m['end']), want)
        self._sync_cart()

    def _set_checked(self, key, on):
        """그 자산의 **모든 줄**을 함께 체크/해제."""
        for iid, mm in self._items.items():
            if (mm['kind'], mm['id'], mm['end']) != key:
                continue
            mm['checked'] = on
            t = self._tv.item(iid, 'text')
            self._tv.item(iid, text=('☑' if on else '☐') + t[1:])

    def _drop_material(self):
        sel = self._tv.selection()
        if not sel:
            return
        iid = sel[0]
        m = self._items.get(iid)
        if not m or m['depth'] != 0:
            return
        def _forget(i):
            for ch in self._tv.get_children(i):
                _forget(ch)
            if i in self._mat_order:
                self._mat_order.remove(i)
            mm = self._items.pop(i, None)
            if mm:
                key = (mm['kind'], mm['id'], mm['end'])
                got = self._seen.get(key)
                if got and got[1] == i:      # (root_iid, iid) — 그 줄이 대표였을 때만
                    self._seen.pop(key, None)
        _forget(iid)
        self._tv.delete(iid)

    # ── 원문 보기 + 발췌 ─────────────────────────────────────────────────
    def _on_select(self, _e=None):
        sel = self._tv.selection()
        if not sel:
            return
        iid = sel[0]
        m = self._items.get(iid)
        if not m:
            return
        self._cur_iid = iid
        self._show_source(m)

    def _show_source(self, m):
        """원문 칸 채우기 + 그 항목에 맞는 콤보 띄우기(구절=버전 / 그 외=언어)."""
        body = self._full_text(m) or ''
        self._src_lbl.config(text=m['label'])
        is_verse = (m['kind'] == 'VERSE')
        try:
            # 콤보는 머리줄 **가장 왼쪽 도구** 자리 — 서식 단추의 왼쪽에 온다
            if is_verse:
                self._lang_combo.combo.pack_forget()
                if not self._ver_cb.winfo_manager():
                    self._ver_cb.pack(side='right', padx=(6, 2), pady=2)
            else:
                self._ver_cb.pack_forget()
                if not self._lang_combo.combo.winfo_manager():
                    self._lang_combo.combo.pack(side='right', padx=(6, 2), pady=2)
        except Exception:
            pass
        self._src_txt.config(state='normal')
        self._src_txt.delete('1.0', 'end')
        self._src_txt.insert('1.0', body)
        try:
            import reading_pane
            reading_pane.enable_copy(self._src_txt)
        except Exception:
            self._src_txt.config(state='disabled')

    def _take_selection(self):
        m = self._items.get(self._cur_iid or '')
        if not m:
            return
        try:
            rng = self._src_txt.tag_ranges('sel')
            text = (self._src_txt.get(rng[0], rng[1]) if rng else '').strip()
        except Exception:
            text = ''
        if not text:
            messagebox.showinfo(i18n.t('RC_TOOL', '작성툴'),
                                i18n.t('RC_SELECT_FIRST',
                                       '원문에서 담을 부분을 먼저 드래그하세요.'),
                                parent=self)
            return
        self._add_block('EXCERPT', text, dict(m))

    def _take_all_checked(self):
        """체크한 항목을 **전문 그대로** 블록으로 (2026-08-20 사용자 지시).

        먼저 통째로 담아 두고 읽으면서 줄이는 방식 — 그래서 자르지 않는다.
        다만 분량이 크면 한 번 알린다(사용자가 「불필요하게 늘어난다」고 한
        바로 그 상황이라, 모르고 담는 일은 없어야 한다)."""
        order = {iid: n for n, iid in enumerate(self._visible_iids())}
        picked, pseen = [], set()
        for i, m in sorted(self._items.items(),
                           key=lambda kv: order.get(kv[0], 10 ** 6)):
            if not m.get('checked'):
                continue
            key = (m['kind'], m['id'], m['end'])
            if key in pseen:            # 같은 자산을 두 번 담지 않는다
                continue
            pseen.add(key)
            picked.append((i, m))
        if not picked:
            messagebox.showinfo(i18n.t('RC_TOOL', '작성도구'),
                                i18n.t('RC_NO_CHECK', '체크한 항목이 없습니다.'),
                                parent=self)
            return
        bodies = []
        for iid, m in picked:
            body = (self._full_text(m) or '').strip()
            if body:
                bodies.append((m, body))
        total = sum(len(b) for _m, b in bodies)
        if total > BIG_CHARS and not messagebox.askyesno(
                i18n.t('RC_TOOL', '작성툴'),
                i18n.t('RC_BIG_ASK', '{n}개 · 약 {c}자를 통째로 담습니다.\n'
                       '계속할까요?').format(n=len(bodies), c=total),
                parent=self):
            return
        for m, body in bodies:
            self._blocks.append({'kind': 'EXCERPT', 'text': body,
                                 'src': {'kind': m['kind'], 'id': m['id'],
                                         'end': m['end'], 'label': m['label']}})
        self._render_blocks()
        self._save_draft()
        messagebox.showinfo(i18n.t('RC_TOOL', '작성툴'),
                            i18n.t('RC_DRAFT_MADE', '{n}개 블록을 초안에 넣었습니다.'
                                   ).format(n=len(bodies)), parent=self)

    # ── 블록 초안 ────────────────────────────────────────────────────────
    def _add_block(self, kind, text, src):
        self._blocks.append({'kind': kind, 'text': text,
                             'src': ({'kind': src['kind'], 'id': src['id'],
                                      'end': src['end'], 'label': src['label']}
                                     if src else None)})
        self._render_blocks()
        self._save_draft()

    def _take_full(self):
        """지금 원문 칸에 보이는 **그 항목 전체**를 담는다 (2026-08-20 사용자 정정).

        [✚ 선택 담기]의 짝 — 드래그한 일부가 아니라 전문. 예전 [전체 담기]가
        「체크한 여러 항목」이었던 것을 바로잡았다(그 일은 [☑ 체크한 것 담기])."""
        m = self._items.get(self._cur_iid or '')
        if not m:
            messagebox.showinfo(i18n.t('RC_TOOL', '작성툴'),
                                i18n.t('RC_PICK_ITEM', '왼쪽에서 항목을 먼저 선택하세요.'),
                                parent=self)
            return
        body = (self._src_txt.get('1.0', 'end-1c') or '').strip()
        if not body:
            return
        self._add_block('EXCERPT', body, dict(m))

    def _visible_iids(self):
        out = []
        def walk(parent):
            for i in self._tv.get_children(parent):
                out.append(i)
                walk(i)
        walk('')
        return out

    def _sync_blocks(self):
        for i, w in enumerate(self._blk_widgets):
            try:
                self._blocks[i]['text'] = w.get('1.0', 'end-1c')
            except Exception:
                pass

    def _bind_wheel(self, w):
        """이 위젯 위에서도 블록 목록이 휠로 굴러가게 한다."""
        def _go(e):
            try:
                self._blk_cvs.yview_scroll(-1 if e.delta > 0 else 1, 'units')
            except Exception:
                pass
            return 'break'
        w.bind('<MouseWheel>', _go)

    def _render_blocks(self):
        pnl = _C('panel', '#FFFFFF')
        for w in self._blk_f.winfo_children():
            w.destroy()
        self._blk_widgets = []
        for i, blk in enumerate(self._blocks):
            row = tk.Frame(self._blk_f, bg=pnl)
            row.pack(fill='x', padx=6, pady=(6, 0))
            hd = tk.Frame(row, bg=pnl); hd.pack(fill='x')
            cap = (blk['src']['label'] if blk['src']
                   else i18n.t('RC_B_MINE', '내 글'))
            tk.Label(hd, text=('❝ ' if blk['kind'] == 'EXCERPT' else '') + cap,
                     bg=pnl, fg=(_C('accent', '#1A5276') if blk['kind'] == 'EXCERPT'
                                 else _C('fg_dim', '#888')),
                     anchor='w', font=('', 9, 'bold')).pack(side='left')
            for txt, cmd in (('✕', lambda i=i: self._del_block(i)),
                             ('▼', lambda i=i: self._move_block(i, 1)),
                             ('▲', lambda i=i: self._move_block(i, -1))):
                tk.Button(hd, text=txt, font=('', 8), bd=0, padx=3,
                          bg=pnl, fg=_C('fg_dim', '#888'), cursor='hand2',
                          command=cmd).pack(side='right')
            t = tk.Text(row, wrap='word', bd=1, relief='solid',
                        height=min(8, max(2, blk['text'].count('\n') + 2)),
                        bg=(_C('accent_bg', '#F4F9FD') if blk['kind'] == 'EXCERPT'
                            else pnl),
                        fg=_C('fg', '#2C3E50'), padx=6, pady=4)
            _tf(t, self.db, 'prose')
            t.insert('1.0', blk['text'])
            t.pack(fill='x')
            # 블록 Text 안에서도 휠 — 자기 내용이 넘치지 않으면 목록을 굴린다
            self._bind_wheel(row)
            self._bind_wheel(hd)
            def _wheel_in_text(e, w=t):
                try:
                    first, last = w.yview()
                    if first <= 0.0 and last >= 1.0:      # 안쪽에 굴릴 것이 없다
                        self._blk_cvs.yview_scroll(-1 if e.delta > 0 else 1, 'units')
                        return 'break'
                except Exception:
                    pass
                return None
            t.bind('<MouseWheel>', _wheel_in_text)
            self._blk_widgets.append(t)

    def _del_block(self, i):
        self._sync_blocks()
        del self._blocks[i]
        self._render_blocks()
        self._save_draft()

    def _move_block(self, i, d):
        j = i + d
        if not (0 <= j < len(self._blocks)):
            return
        self._sync_blocks()
        self._blocks[i], self._blocks[j] = self._blocks[j], self._blocks[i]
        self._render_blocks()
        self._save_draft()

    # ── 초안 보관 ────────────────────────────────────────────────────────
    def _save_draft(self):
        self._sync_blocks()
        data = {'title': self._title_ent.get().strip(),
                'rtype': _rt_code(self._type_cb.get()), 'blocks': self._blocks,
                'edit_ref_id': getattr(self, '_edit_ref_id', None),
                'tree': self._collect_tree()}   # 저장 전에 껐다 켜도 작업대가 산다
        try:
            with appdb.connect(self.db) as c:
                cur = c.execute("UPDATE user_config SET config_val=? WHERE config_key=?",
                                (json.dumps(data, ensure_ascii=False), DRAFT_KEY))
                if cur.rowcount == 0:
                    c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)",
                              (DRAFT_KEY, json.dumps(data, ensure_ascii=False)))
                c.commit()
        except Exception as e:
            print(f'[compose draft] {e}')

    def _load_draft(self):
        try:
            with appdb.connect(self.db) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (DRAFT_KEY,)).fetchone()
            if not r or not r[0]:
                return
            data = json.loads(r[0])
            self._blocks = list(data.get('blocks') or [])
            if data.get('title'):
                self._title_ent.insert(0, data['title'])
            if data.get('rtype'):
                self._type_cb.set(_rt_label(data['rtype']))
            if data.get('edit_ref_id'):
                self._edit_ref_id = data['edit_ref_id']
                self._sync_edit_ui()
            if self._blocks:
                self._render_blocks()
            if (data.get('tree') or {}).get('materials'):
                # 앱을 켜면서 조용히 되살린다 — 시작하자마자 알림창은 방해다
                self._restore_tree(data['tree'], quiet=True)
        except Exception as e:
            print(f'[compose draft load] {e}')

    def _clear_draft(self):
        self._blocks = []
        self._render_blocks()
        self._title_ent.delete(0, 'end')
        try:
            with appdb.connect(self.db) as c:
                c.execute("DELETE FROM user_config WHERE config_key=?", (DRAFT_KEY,))
                c.commit()
        except Exception:
            pass

    # ── 저장한 초안 다시 열기 ────────────────────────────────────────────
    def _fill_load_combo(self):
        """목록만 새로 읽어 둔다 — 표시는 팝업이 한다."""
        import db_user_ref_schema as U
        try:
            with appdb.connect(self.db) as c:
                U.init(c)
                rows = U.compose_list(c)
        except Exception as e:
            print(f'[compose list] {e}')
            rows = []
        self._load_rows = rows
        return rows

    def _open_load_popup(self):
        """Recent 팝업과 같은 문법 — 문서 이름 + 대표 구절 약명을 나란히
        (2026-08-20 사용자 지시. 제목만으로는 무슨 글인지 떠오르지 않는다)."""
        if getattr(self, '_load_pop', None) is not None:
            self._close_load_popup()
            return
        rows = self._fill_load_combo()
        if not rows:
            messagebox.showinfo(i18n.t('RC_TOOL', '작성도구'),
                                i18n.t('RC_NO_SAVED', '작성도구로 저장한 글이 없습니다.'),
                                parent=self)
            return
        btn = self._load_btn
        pop = tk.Toplevel(self)
        pop.overrideredirect(True)
        pop.attributes('-topmost', True)
        _bg = _C('panel', 'white')
        _hov = _C('accent_bg', '#EAF2F8')
        pop.configure(bg=_C('border', '#7F8C8D'))
        self._load_pop = pop
        inner = tk.Frame(pop, bg=_bg)
        inner.pack(padx=1, pady=1, fill='both', expand=True)
        # ⚠ 약명은 **앱 화면 언어**로 — 여기는 문서를 고르는 목록이지 본문이
        #   아니다(단락 보기 언어를 따르면 EN 으로 「Gen 1:1」이 나온다. 실측)
        _ui = self._ui_lang()
        for ref_id, title, upd, vid in rows[:20]:
            ref = self._verse_label(vid, None, lang=_ui) if vid else ''
            row = tk.Frame(inner, bg=_bg, cursor='hand2')
            row.pack(fill='x')
            l1 = tk.Label(row, text=(title or '')[:34], bg=_bg,
                          fg=_C('fg', '#2C3E50'), anchor='w')
            l1.pack(side='left', padx=(6, 4), pady=1, fill='x', expand=True)
            l2 = tk.Label(row, text=ref, bg=_bg, width=10, anchor='e',
                          fg=_C('accent', '#1A5276'), font=('', 9, 'bold'))
            l2.pack(side='right', padx=(0, 6))
            l3 = tk.Label(row, text=(upd or '')[:10], bg=_bg,
                          fg=_C('fg_dim', '#888'), anchor='e')
            l3.pack(side='right', padx=(0, 8))
            for w in (row, l1, l2, l3):
                w.bind('<Button-1>', lambda _e, r=ref_id, t=title: self._load_saved(r, t))
                w.bind('<Enter>', lambda _e, ws=(row, l1, l2, l3):
                       [x.config(bg=_hov) for x in ws])
                w.bind('<Leave>', lambda _e, ws=(row, l1, l2, l3):
                       [x.config(bg=_bg) for x in ws])
        pop.update_idletasks()
        x = btn.winfo_rootx()
        y = btn.winfo_rooty() + btn.winfo_height() + 2
        w = max(inner.winfo_reqwidth(), 360)
        h = inner.winfo_reqheight() + 2
        x = min(x, self.winfo_screenwidth() - w - 10)
        pop.geometry(f'{w}x{h}+{x}+{y}')
        pop.bind('<FocusOut>', lambda e: self._close_load_popup())
        pop.bind('<Escape>', lambda e: self._close_load_popup())
        pop.focus_force()

    def _close_load_popup(self):
        pop = getattr(self, '_load_pop', None)
        self._load_pop = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass

    def _load_saved(self, ref_id, title=''):
        self._close_load_popup()
        if self._blocks and not messagebox.askyesno(
                i18n.t('RC_TOOL', '작성도구'),
                i18n.t('RC_LOAD_ASK', '지금 초안을 두고 「{t}」 을(를) 열까요?'
                       ).format(t=title), parent=self):
            return
        import db_user_ref_schema as U
        with appdb.connect(self.db) as c:
            got = U.load_compose(c, ref_id)
            row = c.execute("SELECT title, ref_type FROM user_ref_asset WHERE ref_id=?",
                            (ref_id,)).fetchone()
        if not got:
            messagebox.showinfo(i18n.t('RC_TOOL', '작성도구'),
                                i18n.t('RC_NO_STRUCT', '이 글에는 저장된 블록 구조가 없습니다.'),
                                parent=self)
            return
        self._edit_ref_id = ref_id
        self._blocks = list(got.get('blocks') or [])
        self._render_blocks()
        # 작업대(재료·후보)까지 — 없으면(옛 글) 초안만 열린다
        self._restore_tree(got.get('tree'))
        self._title_ent.delete(0, 'end')
        self._title_ent.insert(0, (row[0] if row else title) or '')
        if row and row[1]:
            self._type_cb.set(_rt_label(row[1]))
        try:
            import lang_combo as _lc
            self._doc_lang_combo.set_items(_lc.lang_items(),
                                           select=(None, got.get('doc_lang') or 'KO'))
        except Exception:
            pass
        self._sync_edit_ui()
        self._save_draft()

    # ── 작업대(재료·체크·펼침·범위) 저장·복원 ───────────────────────────
    def _collect_tree(self):
        """지금 작업대 상태를 담는다 — **후보(자식)는 담지 않는다**(재계산)."""
        mats = []
        for iid in self._mat_order:
            m = self._items.get(iid)
            if not m:
                continue
            mats.append({'kind': m['kind'], 'id': m['id'], 'end': m['end'],
                         'grp': m.get('grp'), 'direct': bool(m.get('direct', True)),
                         'label': m['label'], 'peri_id': m.get('peri_id')})
        checks, opened, cseen = [], [], set()
        for iid, m in self._items.items():
            if m.get('checked'):
                key = (m['kind'], m['id'], m['end'])
                if key not in cseen:      # 자산 단위 — 자리 수만큼 부풀지 않게
                    cseen.add(key)
                    checks.append([m['kind'], m['id'], m['end']])
            if m['depth'] > 0 and m.get('loaded'):
                opened.append([m['kind'], m['id']])
        return {'materials': mats, 'checks': checks, 'opened': opened,
                'scope': self._scope.get()}

    def _restore_tree(self, tree, quiet=False):
        """저장된 작업대를 되살린다 — 재료를 다시 담고 후보는 새로 계산한다.

        ⚠ 그 사이 구절연결이 바뀌었으면 후보가 달라진다(그게 맞다 — 낡은
          사본을 남기지 않는 원칙). 다만 **복원 못 한 체크는 조용히 빠지지
          않게** 세어서 알린다."""
        if not tree:
            return
        for i in self._tv.get_children(''):
            self._tv.delete(i)
        self._items.clear(); self._seen.clear()
        self._mat_order.clear(); self._textx_cache.clear()
        self._cur_iid = None
        for m in (tree.get('materials') or []):
            try:
                # ★★ **저장된 약명을 그대로 믿지 않는다 — 그릴 때마다 다시 짓는다**
                #   (2026-08-23. §54 핀 칩에서 세운 원칙과 같다.)
                #   초안에는 담을 때의 글자가 그대로 들어 있어, 앱 화면 언어를
                #   바꾸면 **복원된 재료만 옛 언어로 남는다** — 사용자가 신고한
                #   「한글/영어 뒤섞임」의 진짜 정체가 이것이었다(실측: 앱을 EN 으로
                #   두어도 복원분은 「창 1:1」, 새로 담은 것만 「Jhn 8:12」).
                #   ⚠ **페리코프 꼬리(` · 단락 제목`)는 살린다** — 구간으로만
                #     담으면 무슨 단락이었는지 사라진다(2026-08-20 결정).
                lab = m.get('label')
                if m.get('kind', 'VERSE') == 'VERSE':
                    tail = ''
                    if m.get('peri_id') and lab and ' · ' in lab:
                        tail = ' · ' + lab.split(' · ', 1)[1]
                    lab = self._verse_label(m['id'], m.get('end')) + tail
                self._add_material(m.get('kind', 'VERSE'), m['id'], m.get('end'),
                                   label=lab, grp=m.get('grp'),
                                   direct=m.get('direct', True),
                                   peri_id=m.get('peri_id'))
            except Exception as e:
                print(f'[restore material] {e}')
        # 펼쳐 두었던 자리 — 자식이 있어야 그 다음 깊이가 열린다
        for kind, tid in (tree.get('opened') or []):
            for iid, mm in list(self._items.items()):
                if mm['depth'] > 0 and (mm['kind'], mm['id']) == (kind, tid):
                    self._load_children(iid)
                    self._tv.item(iid, open=True)
                    break
        # 체크 복원 — 키가 맞는 줄에 다시 표시
        want = {(k, i, e) for k, i, e in (tree.get('checks') or [])}
        got = set()
        for iid, mm in self._items.items():
            key = (mm['kind'], mm['id'], mm['end'])
            if key in want and not mm.get('checked'):
                mm['checked'] = True
                t = self._tv.item(iid, 'text')
                self._tv.item(iid, text='☑' + t[1:])
                got.add(key)
        try:
            self._scope.set(tree.get('scope') or 'ALL')
        except Exception:
            pass
        self._apply_scope()
        self._sync_cart()
        miss = len(want) - len(got)
        if miss > 0 and not quiet:
            messagebox.showinfo(
                i18n.t('RC_TOOL', '작성도구'),
                i18n.t('RC_CHECK_MISS',
                       '체크 {n}건은 지금 후보에 없어 복원하지 못했습니다.\n'
                       '(그 사이 구절연결이 바뀌었을 수 있습니다)').format(n=miss),
                parent=self)

    def _new_doc(self):
        """편집 중이던 글에서 손을 떼고 새 글로 (블록·제목 비움)."""
        if self._blocks and not messagebox.askyesno(
                i18n.t('RC_TOOL', '작성도구'),
                i18n.t('RC_NEW_ASK', '지금 초안을 비우고 새로 쓸까요?'), parent=self):
            return
        self._edit_ref_id = None
        self._clear_draft()
        self._sync_edit_ui()

    def _sync_edit_ui(self):
        """편집 중이면 [저장]을 [수정 저장]으로 — 새 글이 또 생기지 않는다."""
        try:
            editing = bool(getattr(self, '_edit_ref_id', None))
            self._save_btn.config(
                text=(i18n.t('RC_SAVE_EDIT', '수정 저장') if editing
                      else i18n.t('RC_SAVE', '저장')))
        except Exception:
            pass

    # ── 저장 = 평문 통합 + 링크 확정 ─────────────────────────────────────
    # ── 인용 서식 (구절 전용) ────────────────────────────────────────────
    #   사용자 지시(2026-08-20): 「"태초에 …" (KRX 창1:1)」 처럼 쓰고 싶다.
    #   따옴표·괄호·책이름·역본 표기를 고를 수 있게 — 구절이 아닌 자산은
    #   출처 한 줄(— 라벨)이면 충분하다(사용자 확인).
    QFMT_DEFAULT = {'quote': '“ ”', 'paren': '( )', 'book': 'short',
                    'ver': 'short', 'pos': 'after', 'num': 'auto'}
    QUOTES = {'“ ”': ('“', '”'), '" "': ('"', '"'), "' '": ("'", "'"),
              '「 」': ('「', '」'), '없음': ('', '')}
    PARENS = {'( )': ('(', ')'), '[ ]': ('[', ']'), '- -': ('— ', ''),
              '없음': ('', '')}

    def _qfmt(self):
        try:
            got = json.loads(self._load_cfg('COMPOSE_QFMT', '') or '{}')
        except Exception:
            got = {}
        out = dict(self.QFMT_DEFAULT)
        out.update({k: v for k, v in got.items() if k in out})
        return out

    @staticmethod
    def _strip_verse_nums(text):
        """줄 앞 절 번호를 뗀다 — 인용문 안에 번호가 남으면 어색하다."""
        import re
        out = [re.sub(r'^\s*\d+\s+', '', ln) for ln in (text or '').split('\n')]
        return '\n'.join(out).strip()

    def _quote_verse(self, text, vid, end):
        """구절 발췌 한 덩이를 사용자 서식으로."""
        f = self._qfmt()
        # 절 번호 — auto: 단일 절이면 떼고(출처에 이미 있다) 구간이면 남긴다
        mode = f.get('num', 'auto')
        if mode == 'strip' or (mode == 'auto' and not (end and end != vid)):
            text = self._strip_verse_nums(text)
        q1, q2 = self.QUOTES.get(f['quote'], ('', ''))
        p1, p2 = self.PARENS.get(f['paren'], ('', ''))
        # 글 안에 적히는 표기는 **문서 언어**를 따른다(보기 언어가 아니라)
        ref = self._verse_label(vid, end, full=(f['book'] == 'full'),
                                lang=self._doc_lang())
        ver = ''
        if f['ver'] == 'short':
            ver = self._ver()
        elif f['ver'] == 'full':
            ver = self._ver_display_name(self._ver())
        cite = (ver + ' ' + ref).strip()
        cite = f'{p1}{cite}{p2}'
        body = f'{q1}{text}{q2}'
        return (cite + ' ' + body) if f['pos'] == 'before' else (body + ' ' + cite)

    def _ver_display_name(self, code):
        try:
            with appdb.connect(self.db) as c:
                r = c.execute("SELECT COALESCE(display_name, version_name, version_code) "
                              "FROM bible_version WHERE version_code=?", (code,)).fetchone()
            return r[0] if r else code
        except Exception:
            return code

    def _open_quote_format(self):
        """서식 선택하기 팝업 — 미리보기 한 줄과 함께."""
        f = self._qfmt()
        pop = tk.Toplevel(self)
        pop.title(i18n.t('RC_QFMT_TITLE', '구절 인용 서식'))
        pop.transient(self.winfo_toplevel())
        pnl = _C('panel', '#FFFFFF')
        pop.configure(bg=pnl)
        body = tk.Frame(pop, bg=pnl, padx=12, pady=10); body.pack(fill='both', expand=True)
        vars_ = {}
        rows = [('quote', i18n.t('RC_QF_QUOTE', '따옴표'), list(self.QUOTES)),
                ('paren', i18n.t('RC_QF_PAREN', '괄호'), list(self.PARENS)),
                ('book', i18n.t('RC_QF_BOOK', '책 이름'), ['short', 'full']),
                ('ver', i18n.t('RC_QF_VER', '역본 표기'), ['short', 'full', 'none']),
                ('pos', i18n.t('RC_QF_POS', '출처 위치'), ['after', 'before']),
                ('num', i18n.t('RC_QF_NUM', '절 번호'), ['auto', 'keep', 'strip'])]
        prev = tk.Label(body, text='', bg=_C('accent_bg', '#EAF2F8'),
                        fg=_C('fg', '#2C3E50'), anchor='w', justify='left',
                        wraplength=420, padx=8, pady=6)

        def _refresh(*_a):
            f2 = {k: v.get() for k, v in vars_.items()}
            self._save_cfg('COMPOSE_QFMT', json.dumps(f2, ensure_ascii=False))
            prev.config(text=self._quote_verse('태초에 하나님이 천지를 창조하시니라',
                                               1, None))
        for n, (key, label_, vals) in enumerate(rows):
            tk.Label(body, text=label_, bg=pnl, fg=_C('fg', '#2C3E50')
                     ).grid(row=n, column=0, sticky='w', pady=2)
            v = tk.StringVar(value=f[key])
            vars_[key] = v
            cb = ttk.Combobox(body, width=12, state='readonly', values=vals,
                              textvariable=v)
            cb.grid(row=n, column=1, sticky='w', padx=8, pady=2)
            cb.bind('<<ComboboxSelected>>', _refresh)
        prev.grid(row=len(rows), column=0, columnspan=2, sticky='we', pady=(10, 4))
        tk.Button(body, text=i18n.t('COMMON_CLOSE', '닫기'), command=pop.destroy,
                  bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                  bd=1, relief='groove', padx=10
                  ).grid(row=len(rows) + 1, column=0, columnspan=2, pady=(4, 0))
        _refresh()

    def _source_line(self, src):
        # ⚠ **부르는 곳이 0이다**(2026-08-23 실측) — 저장 본문에 들어가는 것은
        #   아래 `_source_line_doc`(문서 언어)이다. 되살릴 일이 있으면 그쪽과
        #   언어 규칙을 맞출 것.
        k = src['kind']
        if k == 'VERSE':
            return '— ' + self._verse_label(src['id'], src['end']) \
                   + f" ({self._ver()})"
        return '— ' + src['label']

    def _source_line_doc(self, src):
        """저장 본문에 남기는 출처 줄 — 구절 표기는 문서 언어로."""
        if src['kind'] == 'VERSE':
            return '— ' + self._verse_label(src['id'], src['end'],
                                            lang=self._doc_lang()) \
                   + f" ({self._ver()})"
        return '— ' + src['label']

    def _save(self):
        self._sync_blocks()
        title = self._title_ent.get().strip()
        blocks = [b for b in self._blocks if (b['text'] or '').strip()]
        if not title:
            messagebox.showwarning(i18n.t('RC_TOOL', '작성툴'),
                                   i18n.t('RC_NEED_TITLE', '제목을 입력하세요.'),
                                   parent=self)
            return
        if not blocks:
            messagebox.showwarning(i18n.t('RC_TOOL', '작성툴'),
                                   i18n.t('RC_NEED_BLOCK',
                                          '담은 발췌나 내 글이 없습니다.'),
                                   parent=self)
            return
        parts = []
        for b in blocks:
            t = b['text'].strip()
            if b['kind'] == 'EXCERPT' and b['src']:
                if b['src']['kind'] == 'VERSE':
                    # 구절은 사용자 인용 서식 한 줄로 («…» (KRV 창 1:1))
                    t = self._quote_verse(t, b['src']['id'], b['src']['end'])
                else:
                    t += '\n' + self._source_line_doc(b['src'])
            parts.append(t)
        body = '\n\n'.join(parts)

        # 링크 = 재료 구절 + 체크된 자산 + 발췌 출처 (KINDS 안에서만, dedup)
        links, ldup = [], set()
        def _push(kind, tid, end):
            kk = {'VERSE': 'VERSE', 'ENTITY': 'ENTITY',
                  'BOOK': 'BOOK_UNIT'}.get(kind)
            if not kk:
                return
            key = (kk, tid, end)
            if key in ldup:
                return
            ldup.add(key)
            links.append((kk, tid, end))
        for m in self._items.values():
            if m['depth'] == 0 or m['checked']:
                _push(m['kind'], m['id'], m['end'])
        for b in blocks:
            if b['src']:
                _push(b['src']['kind'], b['src']['id'], b['src']['end'])

        lang = self._doc_lang()          # ★ 문서 언어(보기 언어 아님)
        rtype = _rt_code(self._type_cb.get()) or 'STUDY'
        import db_user_ref_schema as U
        first_v = next((t for k, t, _e in links if k == 'VERSE'), None)
        editing = getattr(self, '_edit_ref_id', None)
        try:
            with appdb.connect(self.db) as conn:
                U.init(conn)
                if editing:
                    conn.execute(
                        "UPDATE user_ref_asset SET verse_id=?, ref_type=?, title=?,"
                        " summary=?, lang_code=? WHERE ref_id=?",
                        (first_v, rtype, title, body, lang, editing))
                    ref_id = editing
                else:
                    cur = conn.execute(
                        "INSERT INTO user_ref_asset (verse_id, ref_type, title, author, "
                        "  source_name, url, summary, file_path, lang_code, record_status) "
                        "VALUES (?,?,?,?,?,?,?,?,?,'LIVE')",
                        (first_v, rtype, title, '', '', '', body, '', lang))
                    ref_id = cur.lastrowid
                conn.commit()
                U.set_text(conn, ref_id, lang, title, body)
                U.set_links(conn, ref_id, links)
                # 블록 + 작업대(재료·체크·펼침·범위)도 함께 — 그대로 되살린다
                U.save_compose(conn, ref_id, lang, self._blocks,
                               tree=self._collect_tree())
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e), parent=self)
            return
        self._edit_ref_id = ref_id          # 이어서 고치면 같은 글에 쓴다
        self._sync_edit_ui()
        self._fill_load_combo()
        self._save_draft()
        messagebox.showinfo(i18n.t('RC_TOOL', '작성도구'),
                            i18n.t('RC_SAVED', "'{t}' 을(를) 연구/설교노트에 저장했습니다."
                                   ).format(t=title), parent=self)
        # ★ **저장되자마자 태그 입력** (2026-08-21 사용자 지시) — [입력 안 함]
        #   이면 그대로 끝난다. 검색하기 폼과 **같은 부품**을 쓴다.
        try:
            import tag_picker
            tag_picker.after_save(self, self.db, 'USER_REF', ref_id, self._doc_lang())
        except Exception as e:
            print(f'[compose tag] {e}')
        if callable(self.on_saved):
            self.on_saved(ref_id, lang)

    # ── 조회 헬퍼 ────────────────────────────────────────────────────────
    def _verse_label(self, vid, end=None, full=False, lang=None):
        """구절 약명. **기본은 앱 화면 언어**(§`_ui_lang`) — 글 안에 적히는
        자리만 `lang=self._doc_lang()` 을 명시해서 넘긴다."""
        try:
            with appdb.connect(self.db) as c:
                lang = (lang or self._ui_lang())
                col = 'full_name' if full else 'short_name'
                def one(v):
                    return c.execute("""
                        SELECT bn.%s, bi.chapter, bi.verse""" % col + """
                        FROM bible_index bi JOIN book_names bn
                             ON bn.book_code=bi.bcode
                             AND bn.lang_code IN (?, 'EN', 'KO')
                        WHERE bi.verse_id=?
                        ORDER BY CASE bn.lang_code WHEN ? THEN 0
                                 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1""",
                                     (lang, v, lang)).fetchone()
                a = one(vid)
                if not a:
                    return str(vid)
                lab = f'{a[0]} {a[1]}:{a[2]}'
                if end and end != vid:
                    b = one(end)
                    if b:
                        lab += (f'-{b[2]}' if (b[0], b[1]) == (a[0], a[1])
                                else f'-{b[1]}:{b[2]}')
                return lab
        except Exception:
            return str(vid)

    def _full_text(self, m):
        k, tid, end, lang = m['kind'], m['id'], m['end'], self._lang()
        try:
            with appdb.connect(self.db) as c:
                if k == 'VERSE':
                    rows = c.execute("""
                        SELECT bi.verse, bc.verse_text FROM bible_index bi
                        JOIN bible_content bc ON bc.verse_id=bi.verse_id
                             AND bc.version_code=?
                        WHERE """ + _vr.between_sql('bi.verse_id') + """
                        ORDER BY bi.sort_order""",
                                     [self._ver()]
                                     + _vr.between_args(tid, end or tid)).fetchall()
                    return '\n'.join(f'{v} {t}' for v, t in rows)
                if k == 'DESC':
                    # ⚠ **절마다 한 언어만** (2026-08-20 사용자 「언어 콤보가
                    #   없으니 언어별로 다 표시하는가?」 — 실제로 그랬다.
                    #   내용이 다르면 dedup 이 못 걸러 KO·EN 이 나란히 나왔다).
                    rows = c.execute("""
                        SELECT clicked_id, contents FROM sys_text_asset
                        WHERE text_type='VERS_DESC' AND clicked_id BETWEEN ? AND ?
                          AND COALESCE(record_status,'LIVE')='LIVE'
                          AND COALESCE(text_variant,'LAY') != 'EXPERT'
                          AND UPPER(lang_code) IN (?, 'EN', 'KO')
                        ORDER BY clicked_id,
                                 CASE UPPER(lang_code) WHEN ? THEN 0
                                 WHEN 'EN' THEN 1 ELSE 2 END""",
                                     (tid, end or tid, lang, lang)).fetchall()
                    picked, out = set(), []
                    for cid, t in rows:
                        if cid in picked or not t:
                            continue
                        picked.add(cid)
                        out.append(t)
                    return '\n\n'.join(out)
                if k == 'REF':
                    r = c.execute("""
                        SELECT body_text FROM sys_ref_text
                        WHERE ref_unit_id=? AND COALESCE(record_status,'LIVE')='LIVE'
                          AND UPPER(lang_code) IN (?, 'EN', 'KO')
                        ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0
                                 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1""",
                                  (tid, lang, lang)).fetchone()
                    if r and r[0]:
                        return r[0]
                    r = c.execute("SELECT COALESCE(unit_answer, unit_question, '') "
                                  "FROM sys_ref_unit WHERE ref_unit_id=?",
                                  (tid,)).fetchone()
                    return r[0] if r else ''
                if k == 'BOOK':
                    r = c.execute("""
                        SELECT body_text FROM sys_book_unit_text
                        WHERE unit_id=? AND COALESCE(record_status,'LIVE')='LIVE'
                        ORDER BY CASE WHEN UPPER(lang_code)=? AND text_variant='TRANSLATED' THEN 0
                                 WHEN text_variant='ORIGINAL' THEN 1 ELSE 2 END
                        LIMIT 1""", (tid, lang)).fetchone()
                    return r[0] if r else ''
                if k == 'ENTITY':
                    r = c.execute("""
                        SELECT contents FROM sys_text_asset
                        WHERE text_type='ENTITY_DESC' AND clicked_id=?
                          AND COALESCE(record_status,'LIVE')='LIVE'
                          AND UPPER(lang_code) IN (?, 'EN', 'KO')
                        ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0
                                 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1""",
                                  (tid, lang, lang)).fetchone()
                    return r[0] if r else ''
        except Exception as e:
            print(f'[compose text] {e}')
        return ''
