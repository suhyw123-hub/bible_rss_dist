# -*- coding: utf-8 -*-
"""배포 자산 **전수 분류** — 「팩 목록에 빠진 자산이 없다」를 코드가 보장한다.

★★★ 왜 (2026-09-04 사용자 지시 — 「**팩 목록에 빠진 자산이 없도록 처음부터
  철저하게 설계**하라」 · 「배포수단이 없는 갈래를 **상정하지 마라. 모든 자산은
  결국 배포해야 한다**」).
  ⚠⚠ 문서에만 「무엇을 배포한다」를 적어 두면 **표가 늘어날 때 조용히 빠진다.**
    그래서 **표 하나하나를 여기에 적고**, 적히지 않은 표가 있으면 selftest 가
    실패한다. 표를 만든 사람이 「이건 배포 대상인가」를 그 자리에서 답하게 된다.

**팩 층 셋** (2026-09-04 사용자 확정 — 방법 2)
  · **CORE** — 앱과 함께 가는 것. **모든 연결관계 + 모든 자산 껍데기 + 좌표**.
    실측 연결 67,255행 = 3.6MB · 껍데기 0.47MB · 미디어 본체 1.2MB ⇒ 약 5MB.
    ★ 쪼개지 않는 이유가 크기다 — 본문(성경 51MB · 도서 147MB)에 견주면
      **연결 전체가 도서 한 권의 3%**도 안 된다. 쪼개면 아끼는 것 없이
      「연결이 없는 것인지 안 받은 것인지」를 앱이 구분 못 하게 된다.
  · **PACK** — 사용자가 골라 받는 본문. **사용자가 하나로 고르는 것이 팩 하나**
    (역본 하나 · 책 하나×언어×변형 · 주석서 하나×언어 · 성경책 하나의 설명문).
  · **LOCAL** — 관리자 것. 배포하지 않는다(감사 로그·수집 대기·백업·마이그레이션).

⚠ **`REVIEW` 는 「분류했으나 결정이 남은 것」** — 미분류가 아니다. 화면이 그것을
  따로 보여 사람이 정하게 한다. 미분류(표에 없음)는 **selftest 가 막는다**.

`--selftest`(의무) · `--audit`(분류 현황) · `--missing`(표에 없는 표).
"""
import argparse
import io
import os
import sys

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

CORE, PACK, LOCAL, REVIEW = 'CORE', 'PACK', 'LOCAL', 'REVIEW'

#: 본문팩 갈래 — **사용자 다운로드 화면의 갈래와 같은 이름**이어야 한다.
#: ⚠ 여기 이름을 바꾸면 사용자 화면(`feedback_view._DL_KINDS`)도 함께 바꾼다.
PACK_KINDS = (
    # ★★★ **영상 연결 — 독립 팩**(2026-09-29 293차 · 사용자 확정 「독립된
    #   자산팩으로 취급 … 배포관리 탭에서 통합관리」). 승인된 영상 주소
    #   (`sys_media_asset`)와 그 연결(`MEDI_*`)을 **매일 델타**로 나른다.
    #   ⚠ 만드는 문은 `db_linkpack_build`(시퀀스·묘비·트레이 자동 수신) —
    #     본문팩(`db_pack_body`)과 문법이 다르다. 실측 30일 변경이 주소
    #     149,461 · 연결 739,243 건이라 통째로 갈아 끼우는 본문팩 문법으로는
    #     사용자가 날마다 3MB 를 받는다.
    #   ⚠ 팩 하나뿐이다(열쇠 `LINK·MEDIA·-·-`) — 언어로 안 가른다(영상은
    #     올린 사람의 언어이지 번역이 아니다).
    ('LINK',   '영상 연결',  '승인된 영상 주소와 그 연결 — 매일 · 델타 · 자동 수신'),
    ('BIBLE',  '성경 버전',  '역본 하나'),
    ('COMM',   '주석',      '주석서 하나 × 언어'),
    ('BOOK',   '도서',      '책 하나 × 언어 × 변형'),
    ('SERMON', '설교집',    '설교집 하나 × 언어 × 변형'),
    ('DICT',   '사전',      '사전·자료집 하나 × 언어'),
    ('DESC',   '설명문',    '성경책 묶음 하나 × 언어(오경·복음서 …)'),
    ('LEX',    '원어 사전',  'BDB · A-S · Thayer · 스트롱'),
    # ★★ **시작 이미지 — 스타일 하나가 팩 하나**(2026-09-05 사용자 지시
    #   「선호하는 사용자를 위해서 별도 팩 · 스타일에 따라 유형 분류」).
    #   ⚠ 지금 실데이터가 1행(스타일 없음)이라 **팩이 0개**다 — 스타일을
    #     붙인 사진이 들어오면 저절로 팩이 생긴다(빈 팩은 안 만든다).
    ('IMAGE',  '시작 이미지', '팩 하나(기본·산들·물·하늘·농사·성지·예배)'),
)

#: ★★★ **표 하나하나의 배포 판정.** `(층, 갈래|None, 한 줄 설명)`.
#: 새 표를 만들면 **여기 한 줄** — 안 적으면 selftest 가 실패한다.
TABLES = {
    # ── 성경 본문·좌표 ────────────────────────────────────────────────
    'bible_index':          (CORE, None, '구절 좌표 31,104 — 모든 연결의 뼈대'),
    'book_names':           (CORE, None, '책 이름 다국어'),
    'bible_version':        (CORE, None, '역본 목록(이름만 · 본문은 따로 받는다)'),
    'bible_version_text':   (CORE, None, '역본 이름·설명'),
    'bible_content':        (PACK, 'BIBLE', '역본 본문 — 역본 하나가 팩 하나'),
    'versification_map':    (CORE, None, 'LXX↔MT 매핑(지금 0행)'),
    'sys_heb_verse_ref':    (CORE, None, '히브리 절 번호 병기 1,963절 — 번호가 다른 자리만'),
    'lxx_orphan_content':   (PACK, 'BIBLE', 'LXX 전용 구절(지금 0행)'),

    # ── 연결 — **전부 코어**(방법 2의 핵심) ───────────────────────────
    # ⚠ 영상 연결(`MEDI_*`)만은 **영상 연결 팩**이 나른다(2026-09-29) —
    #   코어 조건(`RULE_ONLY`)이 그것을 뺀다. 표는 그대로 코어다.
    'sys_link_asset':       (CORE, None, '모든 연결관계(영상 연결은 영상 연결 팩이 나른다)'),
    'sys_unit_asset':       (CORE, None, '렌즈묵상 뼈대(묶음·마디)'),
    'sys_entity_verse':     (CORE, None, '주요용어↔구절'),
    'sys_entity_pericope':  (CORE, None, '주요용어↔단락'),
    'sys_ref_verse_link':   (CORE, None, '사전·문답 글↔구절'),
    'sys_ref_entity_link':  (CORE, None, '사전·문답 글↔주요용어'),
    'sys_ref_asset_link':   (CORE, None, '사전·문답↔자산'),
    'sys_ref_book_link':    (CORE, None, '사전·문답↔도서'),
    'sys_book_unit_verse':  (CORE, None, '도서 편↔구절'),
    'sys_book_unit_entity': (CORE, None, '도서 편↔주요용어'),
    'sys_book_unit_tag':    (CORE, None, '도서 편↔태그'),
    'sys_book_asset_tag':   (CORE, None, '도서↔태그'),
    'sys_book_tag_link':    (CORE, None, '도서 태그(지금 0행)'),
    'sys_tag_link':         (CORE, None, '태그 연결'),
    'sys_unit_tag_link':    (CORE, None, '단위↔태그(지금 0행)'),
    'sys_media_link':       (CORE, None, '영상 연결(옛 표 · 화면이 읽는다)'),
    'sys_person_relation':  (CORE, None, '인물 관계'),
    'sys_idol_person_relation': (CORE, None, '우상↔인물'),
    'sys_genealogy_relation':   (CORE, None, '가계도 관계'),
    'sys_chain_route':      (CORE, None, '구속사 흐름 경로'),
    'sys_place_route':      (CORE, None, '여정 경로'),
    'sys_place_route_stop': (CORE, None, '여정 정류장'),
    'sys_place_route_theme':(CORE, None, '여정 주제'),
    'sys_place_road':       (CORE, None, '성지순례 도로(거리·시간·선 · db_place_road)'),
    'sys_plan_route':       (CORE, None, '묵상 경로'),

    # ── 자산 껍데기 — 안 받은 것도 이름은 보인다 ──────────────────────
    'sys_entity_master':    (CORE, None, '주요용어·인물·장소 목록'),
    'sys_person':           (CORE, None, '인물 속성'),
    'sys_book_asset':       (CORE, None, '도서 목록(제목·저자·소개)'),
    'sys_book_asset_text':  (CORE, None, '도서 이름·소개 다국어'),
    'sys_book_unit':        (CORE, None, '도서 편 목록(제목·차례) — 본문은 따로 받는다'),
    'sys_book_source':      (CORE, None, '도서 출처·판본'),
    'sys_commentary_source':(CORE, None, '주석 목록(주석서 이름·저자)'),
    'sys_commentary_entry': (CORE, None, '주석 항목 좌표 — 본문은 따로 받는다'),
    'sys_ref_source':       (CORE, None, '사전·문답 목록(자료 이름)'),
    'sys_ref_asset':        (CORE, None, '사전·문답 자산'),
    'sys_ref_unit':         (CORE, None, '사전·문답 글 목록 — 본문은 따로 받는다'),
    'sys_pericope_asset':   (CORE, None, '단락 좌표·제목'),
    'sys_bible_plan':       (CORE, None, '묵상플랜 정의'),
    'sys_plan_schedule':    (CORE, None, '플랜 일별 스케줄'),
    'sys_plan_category':    (CORE, None, '플랜 분류'),
    'sys_category':         (CORE, None, '분류'),
    'sys_chain_master':     (CORE, None, '구속사 흐름'),
    'sys_chain_catalog':    (CORE, None, '흐름 카탈로그'),
    'sys_genealogy_person': (CORE, None, '가계도 인물'),
    'sys_genealogy_card':   (CORE, None, '가계도 카드'),
    'sys_genealogy_layout': (CORE, None, '가계도 좌표'),
    # ★★★ **코어가 아니다**(2026-09-29 293차) — 영상 연결 팩(`LINK`)이
    #   델타로 나른다. 코어에 두면 코어의 절반이 영상이고 매일 늘어 코어를
    #   날마다 다시 만들게 된다(실측 활성 53,537편 · gzip 2.5MB).
    'sys_media_asset':      (PACK, 'LINK', '영상 주소 — 영상 연결 팩이 델타로 나른다'),
    'sys_tag_asset':        (CORE, None, '태그(지금 0행)'),
    'sys_verse_highlight':  (CORE, None, '오늘의 구절'),
    'sys_verse_view':       (CORE, None, '절별 관점'),
    'sys_view_tradition':   (CORE, None, '관점 전통'),
    'sys_entity_compare':   (CORE, None, '가까운 낱말(옛 표 · 되돌릴 자리)'),
    'sys_entity_branch':    (CORE, None, '주요용어 갈래(원천·십자가·확산)'),
    'sys_entity_lemma':     (CORE, None, '주요용어의 히브리·헬라 원어 낱말'),
    # ★ 낱말↔절(2026-09-12) — 절마다 Strong 번호 한 줄. **본문 글자는 없다.**
    #   ⚠ 번호 층이 CC BY 4.0(OSHB)이라 `license_info` 에 표기가 있어야 한다.
    'sys_verse_lemma':      (PACK, 'LEX', '절↔원어 낱말 30,954절'),
    # ⚠ **LOCAL — 배포하지 않는다**(2026-09-22 · db_strong_align).
    #   역본차이 판정의 **재료**다. 사용자 화면에 역본별 스트롱을
    #   보이는 것은 별개 결정이고, 지금 보내면 코어팩이 그만큼 부푼다.
    # ⚠ 갈래를 **None 으로** 둔다(2026-09-23) — LOCAL 은 배포하지 않으므로
    #   팩 갈래가 뜻이 없다. 'LEX' 가 붙어 있어 「PACK 아닌데 갈래가 붙은
    #   표 0」 검사가 오래 빨갰다. **배포하기로 하면 그때 PACK 으로 올리고
    #   갈래를 다시 적는다.**
    'sys_verse_strong':     (LOCAL, None, '역본별 스트롱 태그 본문 — 역본차이 판정 재료'),
    # ★ **판정 결과는 배포한다** — 사용자 화면이 「이 역본에서는
    #   내용이 다릅니다」를 알려야 한다(1.txt 6-2). 184행이라 작다.
    # ⚠ 갈래를 **None 으로**(2026-09-23) — CORE 는 통째로 나가므로 팩
    #   갈래가 뜻이 없다. 'LEX' 가 붙어 있어 검사가 오래 빨갰다.
    'sys_align_span':       (CORE, None, '역본 사이 구절 차이 구간'),
    'figure_pool':          (CORE, None, '인물 묵상 풀'),
    'unit_pool':            (CORE, None, '인물 묵상 단위'),
    'miracle_pool':         (CORE, None, '기적 목록'),
    'miracle_unit_pool':    (CORE, None, '기적 단위'),

    # ── 본문 — 골라 받는다 ────────────────────────────────────────────
    'sys_text_asset':       (PACK, 'DESC',
                         '설명문 — (성경책 묶음 × 언어)가 팩 하나'),
    'sys_book_unit_text':   (PACK, 'BOOK', '★ 도서·설교 본문 — (책×언어×변형)'),
    # ⚠ **맛보기 조각 번역은 안 싣는다** — 사용자 앱은 코어팩이 실어 나른
    #   `sys_book_unit_text` 행으로 읽는다(`db_pack_taste.taste_tables`).
    #   여기까지 실으면 같은 글이 두 벌이 된다.
    'sys_book_taste':       (LOCAL, None, '도서 맛보기 조각의 번역 — 관리자 원본'),
    'sys_commentary_text':  (PACK, 'COMM', '★ 주석 본문 — (주석서 × 언어)'),
    'sys_ref_text':         (PACK, 'DICT', '★ 자료집 본문 — (자료집 × 언어)'),
    # ★ 317차-18 — 연구/설교노트의 표(ref_doc · 본문엔 자리표 [[T1]]만) — 작아서 코어로 싣는다.
    #   ⚠ 표가 많아져 무거워지면 sys_ref_text 와 같은 팩(DICT)으로 옮긴다(data.md Z-2v ⑧).
    'sys_ref_table':        (CORE, None, '연구/설교노트의 표 구조(행·열·머리 줄)'),
    'sys_ref_table_text':   (CORE, None, '연구/설교노트의 표 칸 글(언어마다 한 줄)'),
    'sys_lemma_master':     (PACK, 'LEX', '스트롱 낱말 마스터 14,298'),
    'sys_bdb_entry':        (PACK, 'LEX', 'BDB 히브리 사전 10,021'),
    'sys_bdb_map':          (PACK, 'LEX', 'BDB 다리'),
    'sys_absmith_entry':    (PACK, 'LEX', 'Abbott-Smith 헬라 사전 5,895'),
    'sys_absmith_map':      (PACK, 'LEX', 'A-S 다리'),
    'sys_thayer_entry':     (PACK, 'LEX', 'Thayer 헬라 사전 5,521'),

    # ── 화면 문자열·설정 — 앱과 함께 ──────────────────────────────────
    'ui_strings':           (CORE, None, '화면 문자열 다국어'),
    'sys_language':         (CORE, None, '언어 목록'),
    'sys_sign_language':    (CORE, None, '수화 언어 코드표(ISO 639-3 · 2026-09-08)'),
    'sys_config':           (CORE, None, '시스템 설정 기본값'),
    'sys_menu_config':      (CORE, None, '메뉴 구성'),
    'sys_manual_asset_v2':  (CORE, None, '화면 도움말'),
    'sys_manual_screen':    (CORE, None, '도움말 화면 목록'),
    'sys_splash_image':     (CORE, None, '시작 화면'),
    'sys_photo_original':   (LOCAL, None, '사진 원본 — 관리자 PC 에만(시작화면·카드는 여기서 만든다)'),
    'sys_photo_pack':       (LOCAL, None, '사진팩 번호·이름·추가/교체 방식 — 관리자'),
    # ★ 2026-10-23 유적 사진·링크(db_site_photo) — 사진은 블롭이라 관리자 PC 에만(폰은 사진 팩으로 받는다) · 링크는 작아 코어에
    'sys_site_photo':       (LOCAL, None, '유적 사진 — 관리자(폰은 사진 팩 MPHOTO)'),
    'sys_photo_link':       (CORE, None, '사진 링크(바깥 사이트)'),
    'sys_pilgrim_site':     (CORE, None, '순례 장소(위키데이터 · 승인한 것만)'),
    'sys_pilgrim_base':     (CORE, None, '성지순례 거점(숙박 도시 · 2026-10-29)'),
    'sys_pilgrim_base_road': (CORE, None, '거점 → 둘레 장소 차 시간·거리(이 PC 도로 엔진 · 2026-10-29)'),
    'sys_pilgrim_near':     (CORE, None, '성지순례 장소 ↔ 장소 실제 도로 거리(둘레 넓히기 · db_pilgrim_near · 2026-10-29)'),
    'sys_pilgrim_walk_zone':   (CORE, None, '성지순례 도보 구역(걸어서 둘러보는 단위 · db_pilgrim_walk · 2026-10-30)'),
    'sys_pilgrim_walk_course': (CORE, None, '성지순례 추천 걷기 코스(구역마다 · 기본으로 체크된 차례 · 2026-10-30)'),
    'sys_pilgrim_line':        (CORE, None, '성지순례 도로 선 모양(거점·10km 둘레 단계 · db_pilgrim_line · 2026-10-30)'),
    'sys_pilgrim_walk_path':   (CORE, None, '성지순례 걷는 길(도보 구역 안 장소 두 곳 · 거리·시간·선·흙길 비율 · 2026-10-30)'),
    'sys_pilgrim_leg':      (CORE, None, '성지순례 구간(12 + 확장 · 날마다 거점 + 들를 곳 · db_pilgrim_leg · 2026-10-29)'),
    'sys_era_code':         (CORE, None, '시대 코드'),
    'sys_era_span':         (CORE, None, '시대 구간'),
    'sys_timeline_event':   (CORE, None, '연대표 사건'),      # 2026-10-22 둘러보기 ▸ 성경 연대표
    'sys_timeline_date':    (CORE, None, '연대표 연대(학설마다 한 줄)'),
    'sys_region_code':      (CORE, None, '지역 코드'),
    'sys_rel_catalog':      (CORE, None, '관계 어휘'),
    'sys_rel_scope':        (CORE, None, '관계 범위'),
    'sys_tag_source_map':   (CORE, None, '태그 출처 매핑'),
    'sys_ref_site':         (CORE, None, '외부 사이트 주소 틀 14개'),
    # ★★★ **규칙으로 만들 수 있는 것은 보내지 않는다** (2026-09-04 전수 분류가
    #   잡았다). 이 표는 사이트 14개 × 구절 31,104 의 **완성 URL 을 미리 만들어
    #   둔 것**이라 **22.7MB — 코어의 61%** 였다. 그런데 `sys_ref_site.
    #   url_template` 의 자리표를 채우면 그대로 나온다.
    #   실측 — 규칙 밖(EXCLUDED·MANUAL·죽은 링크) **8,219행 = 2.2%** 뿐이다.
    #   ⇒ **틀 14개 + 예외 8,219행**만 보낸다. 22.7MB → 0.3MB.
    #   ⚠ 앱이 그 자리에서 URL 을 만든다 — `overlay_read.strong_url` 이 이미
    #     같은 문법을 쓴다(자리표 치환).
    'sys_ref_verse_map':    (CORE, None, '구절↔외부 사이트 주소 — 규칙 밖 예외만'),
    'sys_ref_entity_url':   (CORE, None, '주요용어↔외부 사이트 주소'),
    'sys_ref_site_bookmap': (CORE, None, '사이트별 책 이름 매핑'),
    'sys_announcement':     (CORE, None, '공지(별도 동기화도 있다)'),
    'sys_ai_model':         (CORE, None, 'AI 모델 목록(별도 동기화도 있다 — 모델 이름이 물리면 404)'),
    'sys_ai_guard':         (CORE, None, 'AI 도우미 필수 지침(별도 동기화도 있다 — 사용자는 못 고친다)'),
    'sys_faq':              (CORE, None, 'FAQ'),
    'sys_faq_text':         (CORE, None, 'FAQ 본문'),
    'sys_diagnosis_track':  (CORE, None, '자가진단 축(옛 것 · 읽지 않는다)'),
    'sys_diagnosis_phase':  (CORE, None, '자가진단 국면(옛 것)'),
    'sys_diagnosis_unit':   (CORE, None, '자가진단 원본(옛 것 · 읽지 않는다)'),

    # ── 관리자 전용 — 배포하지 않는다 ─────────────────────────────────
    # ── AI 작성·번역 작업대 (277차) — 전부 **관리자 전용** ──────────
    # ⚠⚠ `sys_ai_item.out_text` 에는 **승인 전 초안**이 들어 있다. 배포하면
    #   사람이 아직 안 본 글이 사용자에게 간다. 적재된 것만 `sys_text_asset`
    #   으로 옮겨 가고 그것이 DESC 팩으로 나간다.
    'sys_ai_job':           (LOCAL, None, 'AI 작업 — 관리자 작업대'),
    'sys_ai_item':          (LOCAL, None, 'AI 건별 — **승인 전 초안**(배포 금지)'),
    'sys_ai_profile':       (LOCAL, None, 'AI 프롬프트 프로필'),
    # 2026-09-25 — 프롬프트 층(전체/자산유형/언어/개별). 관리자 전용.
    'sys_ai_prompt':        (LOCAL, None, 'AI 프롬프트 층'),
    'sys_ai_gate_cfg':      (LOCAL, None, 'AI 게이트 세기(관리자 설정)'),
    'sys_ai_profile_hist':  (LOCAL, None, 'AI 프롬프트 이력'),
    'sys_ai_usage':         (LOCAL, None, 'AI 사용량 집계'),
    'sys_comm_ocr_log':     (LOCAL, None, '주석 원문 OCR 고침 기록(되돌림용) — 관리자 작업대'),
    'sys_ai_batch':         (LOCAL, None, 'AI Batch 작업(구글 대기열) — 관리자 작업대'),
    'sys_ai_srccheck':      (LOCAL, None, 'AI 원문 의심 — 점검한 자리(한 원문에 한 번)'),
    'sys_audit_log':        (LOCAL, None, '감사 로그 — 되돌리기용(배포 금지)'),
    'sys_audit_switch':     (LOCAL, None, '감사 스위치'),
    'sys_log_asset':        (LOCAL, None, '옛 로그'),
    'sys_linkmig_log':      (LOCAL, None, '연결 이관 로그'),
    'sys_linkmig_desc':     (LOCAL, None, '연결 이관 설명'),
    'sys_linkwatch':        (LOCAL, None, '연결 감시'),
    'sys_media_pending':    (LOCAL, None, '보관함 — 관리자 대기줄'),
    'sys_media_attempt':    (LOCAL, None, '수집 시도 로그'),
    'sys_media_skip':       (LOCAL, None, '걸러짐 보관함 — 담지 않기로 한 것(배포 안 함)'),
    'sys_media_channel':    (LOCAL, None, '수집 채널'),
    'sys_media_blacklist':  (LOCAL, None, '수집 제외'),
    'sys_media_excluded_channel': (LOCAL, None, '제외 채널'),
    'sys_media_rejected_channel': (LOCAL, None, '거부 채널'),
    'sys_mine_keyword':     (LOCAL, None, '채널 발굴 — 씨앗 낱말·채굴 이력'),
    'sys_mine_channel':     (LOCAL, None, '채널 발굴 — 발굴 결과'),
    'sys_media_excl_reason':(LOCAL, None, '제외 사유'),
    'sys_media_correction': (LOCAL, None, '수집 교정'),
    # ★ 찬양 사역자(2026-09-09) — 지금은 **관리자가 프로 사역자 영상을 고르는**
    #   재료라 LOCAL 이다. 사용자 화면에 이름이 나가는 날 CORE 로 올린다.
    #   ⚠ 그때 이름(`sys_text_asset('ARTIST_NAME')`)의 배포 길을 **함께** 정해야
    #     한다 — 그 표는 PACK/DESC 이고 DESC 팩은 `VERS_*` 만 싣는다(실측).
    'sys_worship_artist':   (LOCAL, None, '찬양 사역자'),
    'sys_song_album':       (LOCAL, None, '찬양 앨범 — 원곡 증거(배포 안 함)'),
    'sys_album_track':      (LOCAL, None, '앨범 수록곡 — 곡 번호는 비어 있어도 된다'),
    # ★ 곡·판 두 층(2026-09-09) — 사역자와 같은 배다. 화면이 서면 CORE 로.
    'sys_song':             (LOCAL, None, '찬양 곡'),
    'sys_song_rendition':   (LOCAL, None, '찬양 판(번안·커버)'),
    'sys_media_link_backup':(LOCAL, None, '옛 연결 백업'),
    # ★ 링크 점검 장부(2026-09-08) — `sys_media_asset` 에 칸을 더하지 않고
    #   따로 둔 까닭: 그 표는 코어팩·감사 대상이라 매일 수천 행의 점검 시각을
    #   거기 쓰면 감사 로그와 코어 델타가 함께 부푼다. 운영 장부라 배포 안 함.
    'sys_media_check':      (LOCAL, None, '링크 점검 장부 — 휴면·제거(배포 안 함)'),
    # ⚠ 조회수·구독자는 **수시로 바뀐다** — 배포하면 델타가 매일 그만큼
    #   커지고, 사용자가 보는 값은 늘 낡은 값이 된다(2026-09-10 사용자
    #   「조회수는 사용자에게 표시할 것은 아니다」).
    'sys_channel_stat':     (LOCAL, None, '채널 규모 장부 — 구독자·영상 수(배포 안 함)'),
    # ⚠ 사람이 지운 추천 — 관리자의 판단 기록이라 사용자에게 갈 것이 아니다.
    'sys_song_match_reject': (LOCAL, None, '지운 곡·사역자 추천(배포 안 함)'),
    'sys_pack_history':     (LOCAL, None, '배포 이력 — manifest 로 나간다'),
    'sys_pack_board':       (LOCAL, None, '배포 안내문 언어별 — manifest 로 나간다'),
    # ⚠ **이 줄이 없어 selftest 가 실패했다**(2026-09-04) — 표를 만들고 분류를
    #   안 적으면 그 자리에서 걸린다. 장치가 실제로 값을 한 첫 사례다.
    'sys_pack_item':        (LOCAL, None, '자산별 판 — manifest 로 나간다'),
    # ⚠ **미리 적어 둔다** — 사용자가 첫 팩을 적재하면 이 표가 생긴다. 그때
    #   분류가 없으면 selftest 가 실패한다(장치가 옳게 도는 것이지만, 예상되는
    #   표는 미리 적는 것이 맞다).
    # ── 릴리스 패킹(2026-09-05) — **관리자 것이라 배포하지 않는다** ──
    # ── 시작화면 장면(2026-09-05) ────────────────────────────────────
    #   ⚠ **매핑은 코어**다 — 사용자 앱이 「이 구절에 어떤 장면인가」를 읽는다.
    #   ⚠ 팩↔장면 표도 코어 — 받는 쪽이 팩 이름을 풀어야 한다.
    'sys_scene_map':        (CORE, None, '구절·단락·장 ↔ 시작화면 장면'),
    'sys_scene_pack':       (CORE, None, '장면이 어느 사진 팩에 속하나'),
    'sys_pack_plan':        (LOCAL, None, '스몰팩마다 배포 주기 — 릴리스 결합'),
    # ★ 환경설정 양식(A 타입·B 타입 …) — 코어에 실려 사용자 다운로드 화면에 뜬다(293차)
    'sys_pref_preset':      (CORE, None, '환경설정 양식 — 관리자가 담은 설정 한 벌(테마·탭 짜임·캔버스)'),
    # ★ 말씀카드 세부마다 추천 구절(2026-10-21 · db_card_verse)
    'sys_card_verse':       (CORE, None, '말씀카드 추천 구절 — 세부(생일·결혼 …)마다'),
    'sys_app_info':         (CORE, None, '앱 소개 글(소개·만든 사람·개인정보·약관·신고·후원 · app_info)'),
    'sys_card_verse_text':  (CORE, None, '말씀카드 추천 구절의 한 줄 설명(언어마다)'),
    'sys_verse_topic':      (CORE, None, '때에 맞는 말씀 — 주제 목록(큰 갈래 · 이름 언어마다 · 2026-10-29)'),
    'sys_auto_deploy_log':  (LOCAL, None, '자동 배포 실행 기록 — 관리자 PC 만(293차)'),
    'sys_ext_link_check':   (LOCAL, None, '외부 링크 사전 점검 기록 — 관리자 PC 만(db_ext_link_check · 2026-10-25)'),
    'sys_shop_mall':        (LOCAL, None, '추천몰 쇼핑몰 — 날마다 shop.json 으로 나간다(db_shop)'),
    'sys_shop_category':    (LOCAL, None, '추천몰 카테고리 — shop.json 으로 나간다'),
    'sys_shop_item':        (LOCAL, None, '추천몰 상품 — shop.json 으로 나간다'),
    'sys_shop_meta':        (LOCAL, None, '추천몰 판 번호'),
    'sys_ui_string_note':   (LOCAL, None, 'UI 문자열 비고 — 관리자 메모(1.txt 60-2 · 관리자 PC 만)'),
    'sys_pack_core_pick':   (LOCAL, None, '코어팩에서 뺄 표 — 관리자 선택'),
    'sys_pack_core_extra':  (LOCAL, None, '코어팩에 함께 실을 맛보기 자산 — 관리자 선택'),
    'sys_pack_size':        (LOCAL, None, '스몰팩 크기 캐시(잰 날 포함)'),
    # 「성질상 고립」 도장 — 관리자 판정 기록. 배포하지 않는다(사용자 화면과
    # 무관하고, 사용자 DB 에 있어도 하는 일이 없다). 2026-09-06 · 0.txt 6-3
    'sys_iso_exempt':       (LOCAL, None, '고립이어도 정상이라고 찍은 도장'),
    'sys_pack_applied':     (LOCAL, None, '받는 쪽 적재 기록 — 배포 안 함'),
    'sys_rss_feed':         (LOCAL, None, 'RSS 수집 설정'),
    'sys_rss_collect_log':  (LOCAL, None, 'RSS 회차 수집 기록 — 관리자 PC 만(2026-10-24)'),
    'sys_table_doc':        (LOCAL, None, '표 설명(관리자 문서)'),
    'sys_schema_guide':     (LOCAL, None, '스키마 안내(관리자 문서)'),
    'sys_diag_logs':        (LOCAL, None, '진단 로그'),
    'sys_manual_asset':     (LOCAL, None, '옛 도움말(v2 로 대체)'),
    'sys_genealogy_layout_backup': (LOCAL, None, '가계도 좌표 백업'),
    'sys_genealogy_person_work':   (LOCAL, None, '가계도 작업본'),
    'old_layout_backup':    (LOCAL, None, '옛 배치 백업'),
    'sys_pericope_asset_bak_20260429_222637': (LOCAL, None, '단락 백업'),
}


#: ★★ **규칙으로 만들 수 있어 예외만 보내는 표** — `(표, 조건, 왜)`.
#: 전수 분류가 잡아낸 부류다(코어 37MB 중 22.7MB 가 여기 있었다).
#: ⚠ 새로 넣을 때는 **앱이 그 규칙을 실제로 갖고 있는지** 먼저 확인한다 —
#:   안 보내 놓고 못 만들면 화면이 통째로 빈다.
#: ★★★ **승인분만 나간다**(2026-09-04 실측으로 잡았다) — ⚠⚠ 코어팩이
#:   **미승인 미디어 10,863건**을 사용자에게 보내고 있었다. 옛 링크 팩은
#:   `is_active=1` 로 걸러 4,300건만 보낸다(`db_linkpack_build` 가 「검토 안
#:   끝난 URL 이 나가면 죽은 링크가 사용자에게 간다」고 못 박은 그 규칙).
#:   **코어팩이 그 문을 우회하고 있었다.**
#: ⚠ 미디어 연결도 함께 건다 — 미디어를 걸러도 그 연결이 남으면 사용자
#:   화면에 「대상이 없는 연결」이 뜬다(무결성 검사가 잡는 그 꼴).
#: ⚠ 미디어가 아닌 연결(용어·구절·자료)은 **그대로** 나간다 — 승인 개념이 없다.
_MEDIA_LIVE = ("SELECT 1 FROM sys_media_asset m WHERE m.media_id=%s"
               "   AND m.is_active=1"
               "   AND COALESCE(m.record_status,'LIVE')='LIVE'")

# ══════════════════════════════════════════════════════════════════
#  담되 **비우는 칸** — 있어야 하지만 내용을 보내면 안 되는 것
# ══════════════════════════════════════════════════════════════════
#
# ⚠⚠⚠ **유튜브 설명문은 올린 사람의 글이다**(2026-09-17 사용자 확정 —
#   「수집한 설명문 자료는 관리자 전용으로 이용한다. 수집해서 우리 앱에서
#   표시하는 것은 저작권 문제가 있을 것이다」). 우리가 담아 둔 것은 **판정
#   재료**(거르기·용어 연결)이지 내보낼 글이 아니다.
#   ⇒ 실측 — 이 한 칸이 코어팩 48.0MB 중 **28.8MB(60%)** 였다.
#     비우면 원본 19.2MB · gzip 10.4 → **2.1MB**(CDN 한도 20MB 안).
#
# ⚠ **칸을 빼지 않고 빈 문자열로 담는다** — 받는 쪽이 칸을 기대한다.
#   통째로 빼면 옛 앱이 깨지고, 받는 쪽이 합쳐 넣기라 **이미 내려간
#   설명문도 ''로 덮여 저절로 지워진다**(옛 링크팩과 같은 문법).

DROP_COLS = {
    # 유튜브 설명문 — 올린 사람의 글(28.8MB)
    'sys_media_asset': ('description',),
    # ★★★ RSS 로 수집한 **외부 기사 본문**(2.46MB · 811편). 남의 글이고
    #   **심사용**이다(2026-09-23 사용자 「기사본문 등은 모두 심사용이다.
    #   배포 팩에서는 절대로 포함하면 안된다」).
    #   ⚠ 실측 — 사용자 화면은 `title`·`source_name`·`url`·`summary`(앞 80자)
    #     만 읽는다. **본문을 읽는 자리가 한 곳도 없다.**
    #   ⚠ `summary` 는 **남긴다** — 목록에 실제로 뜬다.
    'sys_ref_asset': ('body',),
}

RULE_ONLY = {
    'sys_pilgrim_site': (
        # ★ 2026-10-28 위키데이터 후보(PEND)·숨김(HIDE)은 관리자 검수용 — 승인한 것만
        "status='LIVE'", '★ 순례 장소 — 승인(LIVE)한 것만'),
    # ⚠ `sys_media_asset` 은 여기 없다(2026-09-29) — 코어가 아니라 영상 연결
    #   팩이다. 승인분만 나가는 규칙은 `db_linkpack_build.snapshot` 이 갖는다.
    'sys_link_asset': (
        # ★ 용어 연결 후보(`record_status='PEND'` · db_term_link_audit)는 사람이
        #   확인하기 전이라 **안 싣는다** — 사용자 화면은 LIVE 만 읽지만 팩에
        #   실리면 용량만 먹고 「받았는데 안 보이는」 행이 된다.
        # ★★★ **영상 연결(`MEDI_*`)은 통째로 뺀다**(2026-09-29 293차) — 그것은
        #   영상 연결 팩이 델타로 나른다. 코어에도 실으면 두 경로가 같은 행을
        #   나르고, 받는 쪽 `_wipe_scope` 가 이 조건으로 지우므로 **사용자
        #   PC 의 영상 연결을 코어가 걷어 가는 사고**도 이 한 줄이 막는다.
        "link_type NOT LIKE 'MEDI%%'"
        " AND COALESCE(record_status,'LIVE')<>'PEND'",
        '★ 영상 연결은 영상 연결 팩이 · 용어 후보(PEND)는 뺀다'),
    'sys_media_link': (
        # ⚠⚠ **상관 서브쿼리 함정** — 이 표의 칸 이름도 `media_id` 라
        #   `m.media_id=media_id` 는 `m.media_id=m.media_id`(늘 참)로 읽힌다.
        #   실측 16,264/16,264 로 조건이 안 먹었다. **표 이름으로 한정한다.**
        "EXISTS(" + (_MEDIA_LIVE % 'sys_media_link.media_id') + ")",
        '★ 옛 미디어 연결 표도 같은 규칙'),
    'sys_splash_image': (
        # ★★★ **기본 사진만 코어에**(2026-09-05 · 시작 이미지 별도 팩).
        #   장면이 붙은 사진은 `IMAGE` 팩으로 골라 받는다.
        #   ⚠⚠ 전부 팩으로 빼면 **팩을 안 받은 사용자에게 시작 화면 사진이
        #     하나도 없다** — 기본 하나는 반드시 코어에 남는다.
        # ★★★ 2026-10-11 번호 사진팩 — 코어 = **기본 사진(사진팩에 안 든 것)**만.
        #   그전 규칙(장면 없는 사진만)은 지금 사진 둘이 모두 장면이 붙어 코어에 사진이 0장이었다.
        "COALESCE(basic,0)=1 AND photo_pack IS NULL",
        '★ 기본 사진만 — 나머지는 번호 사진팩(IMAGE · 열쇠 = 팩 번호)으로 나간다'),
    'sys_ref_verse_map': (
        "COALESCE(map_status,'AUTO')<>'AUTO' OR COALESCE(is_alive,1)=0",
        'URL 은 sys_ref_site.url_template 으로 만든다 — 예외만 보낸다'),
}


#: ★★★ **코어에서 뺄 수 있는 표** — `{표: 빼면 무엇을 잃나}`.
#: (2026-09-24 1.txt 12-2 — 관리자가 코어팩 내용을 고른다)
#:
#: ⚠⚠⚠ **여기 없는 표는 못 뺀다.** `bible_index`·`sys_link_asset`·`ui_strings`
#:   가 빠지면 앱이 아예 서지 않는다. 「빼도 되는가」는 사람이 판단할 일이라
#:   허용 목록으로 둔다(금지 목록으로 두면 새 표가 **조용히 뺄 수 있는 것**이
#:   된다 — 그 방향의 실수가 훨씬 비싸다).
#: ⚠ 잣대 = **그 화면만 비고 나머지가 그대로 도는가.** 「크니까 뺀다」가
#:   아니다 — 연결(`sys_link_asset`)은 4.7MB 지만 뼈대라 못 뺀다.
#: ⚠ 뺀 것은 팩에 `excluded` 로 적혀 나간다(`db_pack_core.build`) — 받는 쪽이
#:   「원래 없는 것」과 「이번에 안 보낸 것」을 가른다(§0-1).
# ★★★ **코어는 전부 필수다 — 뺄 수 있는 것이 없다**(2026-09-25 사용자 확정
#   「내가 보기에는 **모두 필수로 지정**해야 할 것 같다. 내가 말했던 선택이란
#    것은 **맛보기를 의미**한 것이다」 · 「선택 2개 구분하지 않는 것이 좋다.
#    **심플한 것이 좋다**」).
#
# ⚠⚠⚠ **왜 걷었나 — 실측이 셋 다 사용자 쪽이었다:**
#   ⓐ **크기가 까닭이 못 된다** — 화면이 보이던 「18.6 MB」는 압축 전 글자
#     수이고 실제 팩은 **6.36 MB**(CDN 한 파일 한도 20 MB).
#   ⓑ **뺄 수 있던 34개 중 둘이 91%** — 영상 5.55 · 주석 좌표 1.71 MB.
#     **나머지 32개를 다 합쳐도 0.74 MB**(가계도 카드 0.11 · 도움말 0.04).
#   ⓒ ★★★ **「뺄 수 있다」가 곧 「§0-1 위반을 허가한다」는 뜻이었다** —
#     아래 표에 **이미 이렇게 적혀 있었다**: `sys_manual_asset_v2` 「화면
#     도움말 — **ⓘ 를 눌러도 글이 없다**」. 사용자가 겪은 그 문제를 설계가
#     **미리 적어 두고도** 뺄 수 있게 두었다. 눌러도 아무 일이 없는 단추를
#     만드는 스위치를 관리자에게 준 셈이다.
#   ⓓ 그 둘마저 못 뺀다 — 영상을 빼면 영상 화면이 **통째로** 빈다(61,426편),
#     주석 좌표를 빼면 **본문 팩을 받아도 한 줄도 안 뜬다**(좌표만 코어에
#     있고 본문은 팩이다).
#
# ★★ **표는 남긴다 — 이제 「무엇을 잃는가」 설명으로 쓴다.** 목록 화면이
#   이 글을 보여 사람이 무엇인지 알게 한다(사용자 「그 내용이 도대체 무엇인지
#   알 수 있어야 선택할지 결정한다」). 되돌릴 자리이기도 하다.
CORE_OPTIONAL = {}

# 「없으면 무엇이 안 보이나」 — **목록 설명의 단일 소스**
CORE_WHY = {
    # ── 영상 ──────────────────────────────────────────────────────
    # ⚠ `sys_media_asset` 은 이제 코어가 아니다(2026-09-29 · 영상 연결 팩).
    'sys_media_link':         '옛 미디어 연결 — 옛 경로의 영상만 안 보인다',
    'sys_pref_preset':        '환경설정 양식 — 다운로드 화면의 「환경설정 양식」 줄이 빈다',
    'sys_card_verse':         '말씀카드 추천 구절 — 세부를 골라도 구절이 안 나온다(AI 도우미만)',
    'sys_app_info':           '앱 소개 글 — 서버에서 받기 전까지 앱 소개 화면이 빈다',
    'sys_card_verse_text':    '말씀카드 추천 구절 설명 — 구절만 보이고 왜 맞는지가 빈다',
    'sys_verse_topic':        '때에 맞는 말씀 주제 목록 — 그 화면이 빈다',
    # ── 주석 좌표 ─────────────────────────────────────────────────
    'sys_commentary_entry':   '주석 좌표 — 주석 탭이 빈다(본문은 어차피 PACK)',
    'sys_commentary_source':  '주석 소스 껍데기 — 받을 주석 목록이 안 보인다',
    # ── 가계도 ────────────────────────────────────────────────────
    'sys_genealogy_card':     '가계도 카드 — 메시아·제자 가계도 설명이 빈다',
    'sys_genealogy_person':   '가계도 인물',
    'sys_genealogy_relation': '가계도 관계',
    'sys_genealogy_layout':   '가계도 좌표',
    # ── 여정(믿음의 발자취) ───────────────────────────────────────
    'sys_place_route':        '여정 경로 — 믿음의 발자취가 빈다',
    'sys_place_route_stop':   '여정 정류장',
    'sys_place_route_theme':  '여정 주제',
    'sys_place_road':         '성지순례 도로 — 없으면 순례 코스가 직선 어림으로 물러선다',
    # ── 골라담기 재료 ─────────────────────────────────────────────
    'miracle_pool':           '기적 목록 — 골라담기 기적 플랜을 못 만든다',
    'miracle_unit_pool':      '기적 단위',
    'unit_pool':              '인물 묵상 단위 — 인물 플랜 만들기가 빈다',
    'figure_pool':            '인물 묵상 풀',
    # ── 시작 화면 ─────────────────────────────────────────────────
    'sys_splash_image':       '시작 화면 사진 — 기본 화면으로 뜬다',
    'sys_scene_map':          '구절↔장면 — 구절에 맞는 사진이 안 뜬다',
    'sys_scene_pack':         '장면↔사진 팩',
    'sys_photo_link':         '유적 사진 링크 — 폰 둘러보기 ▸ 성경 유적 사진의 링크 갈래가 빈다',
    'sys_pilgrim_site':       '순례 장소 — 폰 성지순례 지도에 교회·유적 같은 찾아갈 자리가 안 뜬다',
    'sys_pilgrim_base':       '성지순례 거점 — 「거점 둘레」가 빈다',
    'sys_pilgrim_base_road':  '거점 둘레 차 시간 — 거점을 골라도 둘레가 안 나온다',
    'sys_pilgrim_near':       '장소끼리 도로 거리 — 「둘레 넓히기」가 빈다',
    'sys_pilgrim_walk_zone':  '도보 구역 — 「걸어서」 갈래가 빈다',
    'sys_pilgrim_walk_course': '추천 걷기 코스 — 구역을 골라도 기본 코스가 없다',
    'sys_pilgrim_line':        '도로 선 — 거점·10km 둘레 지도가 고른 곳을 점선 직선으로만 잇는다',
    'sys_pilgrim_walk_path':   '걷는 길 — 지도가 장소 사이를 점선 직선으로만 잇는다',
    'sys_pilgrim_leg':        '성지순례 구간 — 「구간」 갈래가 빈다',
    # ── 도움말·안내 ───────────────────────────────────────────────
    'sys_manual_asset_v2':    '화면 도움말 — ⓘ 를 눌러도 글이 없다',
    'sys_manual_screen':      '도움말 화면 목록',
    'sys_faq':                'FAQ 목록 — 지원 화면의 FAQ 가 빈다',
    'sys_faq_text':           'FAQ 본문',
    'sys_announcement':       '공지 — 별도 동기화로도 들어온다',
    'sys_ai_model':           'AI 모델 목록 — 코드 씨앗으로 돌아간다(물린 이름이면 404)',
    'sys_ai_guard':           'AI 도우미 필수 지침 — 코드 씨앗으로 돌아간다',
    # ── 연구 보조(있으면 좋은 것) ─────────────────────────────────
    'sys_heb_verse_ref':      '히브리 절 번호 병기 — 번호가 다른 자리 표기만 빈다',
    'sys_align_span':         '역본차이 구간 — 그 경고 표시만 빈다',
    'sys_entity_compare':     '가까운 낱말 — 그 칸만 빈다',
    'sys_verse_view':         '절별 관점 — 전문 설명의 관점 줄만 빈다',
    'sys_view_tradition':     '관점 전통',
    'sys_ref_entity_url':     '용어↔외부 사이트 URL — 사전 사이트 단추만 빈다',
    'sys_sign_language':      '수화 언어 코드표 — 수화 갈래 이름만 빈다',
    # ── 이미 읽지 않는 옛 것 ──────────────────────────────────────
    'sys_diagnosis_unit':     '자가진단 원본(옛 것) — 읽는 코드가 0곳이다',
    'sys_diagnosis_track':    '자가진단 축(옛 것)',
    'sys_diagnosis_phase':    '자가진단 국면(옛 것)',
    'versification_map':      'LXX↔MT 매핑 — 지금 0행이다',
    # ── 뼈대 — 없으면 앱이 서지 않는다 (2026-09-25 신설) ──────────
    'bible_index':            '구절 좌표 — 성경을 한 절도 못 연다',
    'bible_version':          '역본 목록 — 선택할 역본이 없다',
    'bible_version_text':     '역본 이름·설명 — 선택하는 자리에 코드만 뜬다',
    'book_names':             '책 이름 다국어 — 66권이 영어로만 뜬다',
    'ui_strings':             '화면 글자 — 단추·탭 이름이 통째로 영어로 떨어진다',
    'sys_config':             '시스템 기본값 — 처음 켤 때 설정이 빈다',
    'sys_language':           '언어 목록 — 표시 언어를 선택할 수 없다',
    'sys_menu_config':        '메뉴 구성 — 화면 차례가 기본값으로 떨어진다',
    'sys_category':           '분류 — 목록 묶음 이름이 빈다',
    # ── 연결 ──────────────────────────────────────────────────────
    'sys_link_asset':         '모든 연결 — 구절·용어·영상 연결이 통째로 빈다',
    'sys_pericope_asset':     '단락 좌표·제목 — 단락설명과 단락 이름이 빈다',
    # ── 묵상플랜 ──────────────────────────────────────────────────
    'sys_bible_plan':         '묵상플랜 정의 — 플랜 목록이 통째로 빈다',
    'sys_plan_schedule':      '플랜 하루치 — 플랜을 열어도 읽을 곳이 없다',
    'sys_plan_category':      '플랜 분류 — 묵상플랜 트리가 빈다',
    'sys_plan_route':         '묵상 경로 — 「다음 걸음」이 안 뜬다',
    'sys_unit_asset':         '렌즈묵상 뼈대 — 렌즈와 마디가 통째로 빈다',
    # ── 주요용어·인물 ─────────────────────────────────────────────
    'sys_entity_master':      '주요용어·인물·장소 목록 — 그 화면이 통째로 빈다',
    'sys_entity_lemma':       '용어의 원어 낱말 — 낱말 구절과 원어 표기가 빈다',
    'sys_entity_verse':       '용어↔구절 — 용례구절 탭이 빈다',
    'sys_entity_pericope':    '용어↔단락 — 단락에서 인물·용어 칩이 안 뜬다',
    'sys_entity_branch':      '용어 갈래 — 원천·십자가·확산 묶음이 빈다',
    'sys_person':             '인물 속성 — 지파·시대 거르개가 빈다',
    'sys_person_relation':    '인물 관계 — 가계도와 관계 목록이 빈다',
    'sys_idol_person_relation': '우상↔인물 — 우상 화면의 인물 줄이 빈다',
    'sys_rel_catalog':        '관계 어휘 — 관계 이름이 코드로 뜬다',
    'sys_rel_scope':          '관계 범위 어휘 — 같은 자리',
    # ── 구속사 흐름 ───────────────────────────────────────────────
    'sys_chain_master':       '구속사 흐름 — 말씀흐름 탭이 빈다',
    'sys_chain_catalog':      '흐름 이름·설명 — 흐름이 코드로 뜬다',
    'sys_chain_route':        '흐름 경로 — 흐름의 「다음 걸음」이 빈다',
    # ── 도서·설교 ─────────────────────────────────────────────────
    'sys_book_asset':         '도서 목록 — 서재가 통째로 빈다',
    'sys_book_asset_text':    '도서 이름·소개 — 서재에 이름이 안 뜬다',
    'sys_book_unit':          '도서 편 목록 — 책을 열어도 차례가 없다',
    'sys_book_source':        '도서 출처·판본 — 저작권 고지가 빈다',
    'sys_book_unit_verse':    '도서 편↔구절 — 구절에서 그 편이 안 뜬다',
    'sys_book_unit_entity':   '도서 편↔용어 — 용어에서 도서가 안 뜬다',
    'sys_book_unit_tag':      '도서 편↔태그 — 태그로 찾기에서 빠진다',
    'sys_book_asset_tag':     '도서↔태그 — 같은 자리',
    # ── 사전·문답 ─────────────────────────────────────────────────
    'sys_ref_source':         '사전·문답 자료 이름 — 어느 사전인지 모른다',
    'sys_ref_asset':          '사전·문답 자산 — 자료집 목록이 빈다',
    'sys_ref_unit':           '사전·문답 표제어 — 목록이 비어 본문을 못 받는다',
    'sys_ref_table':          '연구/설교노트의 표 — 본문의 표 자리가 빈다',
    'sys_ref_table_text':     '연구/설교노트의 표 칸 글 — 표가 빈 칸으로 보인다',
    'sys_ref_verse_link':     '사전·문답↔구절 — 구절에서 자료집이 안 뜬다',
    'sys_ref_entity_link':    '사전·문답↔용어 — 용어 화면의 사전 탭이 빈다',
    'sys_ref_asset_link':     '사전·문답↔자산 — 자료끼리 오가는 길이 빈다',
    # ── 외부 사이트 ───────────────────────────────────────────────
    'sys_ref_site':           '외부 사이트 주소 틀 — 사전·주석 단추가 빈다',
    'sys_ref_site_bookmap':   '사이트별 책 이름 — 외부 주소가 어긋난다',
    'sys_ref_verse_map':      '구절↔외부 주소 예외 — 규칙 밖 절만 어긋난다',
    # ── 그 밖 ─────────────────────────────────────────────────────
    'sys_verse_highlight':    '오늘의 구절 — 맨 위 띠가 빈다',
    'sys_era_span':           '시대 구간 — 연표 띠가 빈다',
    'sys_timeline_event':     '연대표 사건 — 둘러보기 ▸ 성경 연대표가 빈다',
    'sys_timeline_date':      '연대표 연대 — 사건에 연도가 안 붙는다',
    'sys_era_code':           '시대 코드 — 시대 이름이 코드로 뜬다',
    'sys_region_code':        '지역 코드 — 지역 이름이 코드로 뜬다',
    'sys_tag_link':           '태그 연결 — 태그로 찾기가 빈다',
    # ⚠ **지금 0행인 표는 그렇다고 적는다** — 지어내지 않는다(§0-1).
    'sys_tag_asset':          '태그(지금 0행 — 주요용어로 합쳤다)',
    'sys_tag_source_map':     '태그 출처 매핑(지금 0행)',
    'sys_unit_tag_link':      '단위↔태그(지금 0행)',
    'sys_book_tag_link':      '도서 태그(지금 0행)',
    'sys_ref_book_link':      '사전·문답↔도서(지금 0행)',
}


#: `core_bytes` 를 **잠깐 기억한다**. ⚠⚠ 90개 표를 다 훑어 실측 0.3~1.3초인데
#: 화면 한 번에 여덟 번까지 불렸다(286차). 표 행수는 관리자가 화면을 보는 동안
#: 거의 안 바뀌므로 짧게 기억하고 **판을 만들 때는 반드시 다시 센다.**
_CB_MEMO = {'at': 0.0, 'val': None}
CB_TTL = 60.0


def core_bytes_clear():
    """기억을 버린다 — **팩을 만들기 전·자료를 고친 뒤**에 부른다."""
    _CB_MEMO['at'] = 0.0
    _CB_MEMO['val'] = None


def core_bytes(conn, fresh=False):
    """코어팩에 실제로 실릴 크기 → `(합계, [(표, 바이트)])`.

    ⚠ `RULE_ONLY` 표는 **예외 행만** 센다 — 그러지 않으면 22.7MB 를 보낸다고
      착각한다.
    ⚠ 기본은 **60초 기억**이다(`fresh=True` 면 다시 센다). 세는 쪽과 담는
      쪽이 갈리면 안 되므로 `db_pack_core.build` 가 만들기 직전에 버린다.
    """
    import time as _tm
    if not fresh and _CB_MEMO['val'] is not None \
            and (_tm.time() - _CB_MEMO['at']) < CB_TTL:
        return _CB_MEMO['val']
    out, tot = [], 0
    for t, (layer, _k, _d) in TABLES.items():
        if layer != CORE:
            continue
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % t)]
            if not cols:
                continue
            # ⚠⚠ **비우는 칸은 세지 않는다**(`DROP_COLS`) — 안 그러면 화면이
            #   「48MB」라 하고 실제로는 19MB 가 나간다. **세는 쪽과 담는
            #   쪽이 갈리면 어느 것도 못 믿는다.**
            _drop = set(DROP_COLS.get(t, ()))
            expr = '+'.join("LENGTH(COALESCE(CAST(%s AS TEXT),''))" % x
                            for x in cols if x not in _drop) or '0'
            q = "SELECT COALESCE(SUM(%s),0) FROM %s" % (expr, t)
            if t in RULE_ONLY:
                q += ' WHERE ' + RULE_ONLY[t][0]
            b = conn.execute(q).fetchone()[0]
        except Exception:
            b = 0
        tot += b
        out.append((t, b))
    res = (tot, sorted(out, key=lambda x: -x[1]))
    _CB_MEMO['at'] = _tm.time()
    _CB_MEMO['val'] = res
    return res


def all_tables(conn):
    """지금 DB 의 표 이름(임시·sqlite 내부 제외)."""
    return [t for (t,) in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
        "   AND name NOT LIKE 'sqlite_%' ORDER BY name")
        if not t.startswith('temp_')]


def core_lang_gaps(conn, want=None):
    """코어팩 안 **다국어 자료**가 몇 언어를 채웠나 → `[(표, 설명, 있는 언어)]`.

    ★★★ 왜 (2026-09-24 사용자 물음 — 「코어팩 내부에 다국어 모드가 반영된
      텍스트 자산이 있는가? **화면도움말, 도서이름소개 등** 모든 언어로
      표시할 수 있도록 … 되어있는가? **점검결과를 설명하라**」).
      ⚠ 구조는 이미 다국어다(`lang_code` 행) — 모자란 것은 **내용**이다.
        그런데 그것을 세는 자리가 없어 **배포하고 나서야** 안다.
    ⚠ **원어 표는 세지 않는다** — 히브리·헬라 낱말에는 번역이라는 것이 없다.
    ⚠ 판정은 `lang_config.ui_langs()` 기준이다(언어를 늘리면 따라온다).
    """
    if want is None:
        try:
            import lang_config as LC
            want = set(x.upper() for x in LC.ui_langs())
        except Exception:                                    # noqa: BLE001
            want = set()
    out = []
    for t, (layer, _k, desc) in TABLES.items():
        if layer != CORE or t in LANG_SKIP:
            continue
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % t)]
            if 'lang_code' not in cols:
                continue
            got = {str(r[0] or '').upper()
                   for r in conn.execute(
                       "SELECT DISTINCT lang_code FROM %s" % t) if r[0]}
        except Exception:                                    # noqa: BLE001
            continue
        out.append((t, desc, got & want if want else got))
    out.sort(key=lambda x: len(x[2]))
    return out


#: 다국어 셈에서 **뺀다** — 번역이라는 것이 없는 자료.
LANG_SKIP = {
    'sys_entity_lemma',     # 히브리·헬라 원어 낱말
    'sys_language',         # 언어 목록 자체
    'sys_sign_language',    # 수화 언어 코드표
    'sys_media_asset',      # 영상 — 올린 사람의 언어이지 번역이 아니다
}


def missing(conn):
    """**분류표에 없는 표** → 목록. 이것이 0 이어야 「빠진 자산이 없다」."""
    return [t for t in all_tables(conn) if t not in TABLES]


def stale(conn):
    """분류표에는 있는데 **DB 에 없는** 표(이름이 바뀌었거나 지워졌다)."""
    have = set(all_tables(conn))
    return [t for t in TABLES if t not in have]


def audit(conn):
    """층별 표 수·행수 → `{층: [(표, 갈래, 행수, 설명)]}`."""
    out = {CORE: [], PACK: [], LOCAL: [], REVIEW: []}
    for t in all_tables(conn):
        layer, kind, desc = TABLES.get(t, (REVIEW, None, '**분류 안 됨**'))
        try:
            n = conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
        except Exception:
            n = -1
        out.setdefault(layer, []).append((t, kind, n, desc))
    return out


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    c = appdb.connect(DB)
    try:
        miss = missing(c)
        # ★★★ **이 한 줄이 「빠진 자산이 없다」를 지킨다** — 표를 만들고 분류를
        #   안 적으면 여기서 걸린다.
        t('★★★ **분류 안 된 표가 없다**', not miss,
          ('빠진 표: %s' % miss[:6]) if miss else '')
        st = stale(c)
        t('  분류표에 유령 표가 없다', not st, str(st[:6]) if st else '')
        t('층 이름이 넷이다', {CORE, PACK, LOCAL, REVIEW} == {'CORE', 'PACK',
                                                          'LOCAL', 'REVIEW'})
        kinds = {k for k, _l, _d in PACK_KINDS}
        used = {v[1] for v in TABLES.values() if v[0] == PACK}
        t('★ 본문팩 갈래가 모두 정의돼 있다', used <= kinds,
          str(sorted(used - kinds)))
        t('  PACK 인데 갈래가 없는 표 0',
          not [k for k, v in TABLES.items() if v[0] == PACK and not v[1]])
        t('  PACK 아닌데 갈래가 붙은 표 0',
          not [k for k, v in TABLES.items() if v[0] != PACK and v[1]])
        a = audit(c)
        t('★ 연결 표가 전부 코어다',
          all(TABLES.get(x, (None,))[0] == CORE for x in
              ('sys_link_asset', 'sys_entity_verse', 'sys_ref_verse_link',
               'sys_book_unit_verse')))
        # ★★★ 2026-09-29 293차 — 영상 주소는 **영상 연결 팩**(LINK)이 나른다.
        #   옛 검사(「미디어 본체가 코어다」)를 뒤집어 못 박는다.
        t('★★★ 영상 주소는 코어가 아니다 — 영상 연결 팩(LINK)',
          TABLES['sys_media_asset'][:2] == (PACK, 'LINK'))
        t('★ 영상 연결 갈래가 카탈로그에 있다',
          'LINK' in {k for k, _l, _d in PACK_KINDS})
        t('★ 감사 로그는 배포하지 않는다',
          TABLES['sys_audit_log'][0] == LOCAL)
        t('★ 본문은 코어가 아니다',
          all(TABLES[x][0] == PACK for x in
              ('bible_content', 'sys_book_unit_text', 'sys_commentary_text',
               'sys_text_asset')))
        t('  설명이 빈 표 0',
          not [k for k, v in TABLES.items() if not (v[2] or '').strip()])
        t('  층별 표가 다 잡힌다',
          sum(len(v) for v in a.values()) == len(all_tables(c)),
          '%d / %d' % (sum(len(v) for v in a.values()), len(all_tables(c))))
        # ★★ 규칙으로 만들 수 있는 것을 통째로 보내지 않는가
        t('★ 규칙 전용 표가 코어에 있다(예외만 보낸다)',
          all(TABLES.get(k, (None,))[0] == CORE for k in RULE_ONLY))
        tot, rows = core_bytes(c)
        big = [r for r in rows if r[1] > tot * 0.4] if tot else []
        # ⚠ **한 표가 코어의 40%를 넘으면 설계를 다시 본다** — 실측으로
        #   `sys_ref_verse_map` 이 61% 였고 규칙으로 대체됐다.
        t('★★ 코어를 한 표가 40%% 넘게 차지하지 않는다', not big,
          str([(x[0], '%.0f%%' % (x[1] * 100 / tot)) for x in big]))
        t('  코어가 20MB 를 넘지 않는다', tot < 20 * 1048576,
          '%.1f MB' % (tot / 1048576))
    finally:
        c.close()
    # ── ★★★ **미승인 미디어가 코어에 새지 않는다**(2026-09-04 실측으로
    #   잡았다 — 10,863건이 나가고 있었다) ────────────────────────────
    c3 = appdb.connect(DB)
    try:
        import db_pack_core as _PK
        ct = {t: cd for t, cd in _PK.core_tables()}
        # ⚠ `sys_media_asset` 은 코어가 아니라 여기서 안 센다(2026-09-29).
        for tbl, idcol in (('sys_media_link', 'media_id'),
                           ('sys_link_asset', 'clicked_id')):
            cond = ct.get(tbl)
            t('★★★ **%s 에 승인 조건이 걸려 있다**' % tbl, bool(cond),
              str(cond)[:40])
            if not cond:
                continue
            if tbl == 'sys_link_asset':
                q = ("SELECT COUNT(*) FROM %s x WHERE (%s)"
                     "  AND x.link_type LIKE 'MEDI%%'"
                     "  AND NOT EXISTS(SELECT 1 FROM sys_media_asset m"
                     "    WHERE m.media_id=x.clicked_id AND m.is_active=1)"
                     % (tbl, cond.replace('clicked_id', 'x.clicked_id')
                        .replace('link_type', 'x.link_type')))
            else:
                q = ("SELECT COUNT(*) FROM %s x WHERE (%s)"
                     "  AND NOT EXISTS(SELECT 1 FROM sys_media_asset m"
                     "    WHERE m.media_id=x.%s AND m.is_active=1)"
                     % (tbl, cond.replace(tbl + '.', 'x.')
                        .replace('is_active=1 AND', 'x.is_active=1 AND')
                        .replace("COALESCE(record_status",
                                 "COALESCE(x.record_status"), idcol))
            try:
                n = c3.execute(q).fetchone()[0]
            except Exception as e:                            # noqa: BLE001
                n = -1
                t('  (%s 검사 질의)' % tbl, False, str(e)[:60])
            t('★★ **%s — 미승인이 0건**' % tbl, n == 0, '%s건' % n)
        # ★★★ **영상 연결(MEDI_*)은 코어 조건에 한 건도 안 걸린다**(2026-09-29)
        #   — 그것은 영상 연결 팩의 몫이다. 양방향: 조건을 옛것으로 되돌리면
        #   여기서 그 자리에서 잡힌다.
        _lc = ct.get('sys_link_asset') or '0'
        _nm = c3.execute("SELECT COUNT(*) FROM sys_link_asset WHERE (%s)"
                         " AND link_type LIKE 'MEDI%%'" % _lc).fetchone()[0]
        t('★★★ **코어 조건에 영상 연결이 0건**(영상 연결 팩의 몫)',
          _nm == 0, '%s건' % _nm)
        _ok_all = c3.execute("SELECT COUNT(*) FROM sys_link_asset WHERE (%s)"
                             % _lc).fetchone()[0]
        t('  그 밖 연결은 그대로 코어에 있다', _ok_all > 50000, '%s건' % _ok_all)
    finally:
        c3.close()

    # ── 다국어 셈 (286차 · 1.txt 12-3) ─────────────────────────────
    import sqlite3 as _sq
    mc = _sq.connect(':memory:')
    mc.executescript(
        "CREATE TABLE ui_strings(k TEXT, lang_code TEXT);"
        "CREATE TABLE sys_faq_text(a TEXT, lang_code TEXT);"
        "CREATE TABLE sys_entity_lemma(a TEXT, lang_code TEXT);"
        "CREATE TABLE bible_index(verse_id INTEGER);")
    for lg in ('KO', 'EN', 'JA'):
        mc.execute("INSERT INTO ui_strings VALUES('x',?)", (lg,))
    mc.execute("INSERT INTO sys_faq_text VALUES('x','KO')")
    mc.execute("INSERT INTO sys_entity_lemma VALUES('x','HE')")
    mc.commit()
    g = {x[0]: x[2] for x in core_lang_gaps(mc, want={'KO', 'EN', 'JA'})}
    t('★★ 다국어 자료의 **채운 언어**를 센다',
      g.get('ui_strings') == {'KO', 'EN', 'JA'}
      and g.get('sys_faq_text') == {'KO'}, str(sorted(g)))
    t('  ★ 원어 표는 안 센다(번역이라는 것이 없다)',
      'sys_entity_lemma' not in g)
    t('  ★ 언어 칸이 없는 표는 안 센다', 'bible_index' not in g)
    t('  모자란 것이 앞에 온다',
      [x[0] for x in core_lang_gaps(mc, want={'KO', 'EN', 'JA'})][0]
      == 'sys_faq_text')
    mc.close()

    # ── 크기 기억 (286차 · 화면이 여덟 번 세던 자리) ─────────────────
    import time as _t3
    c3 = appdb.connect(DB)
    try:
        core_bytes_clear()
        _s0 = _t3.time()
        a1 = core_bytes(c3)
        d1 = _t3.time() - _s0
        _s0 = _t3.time()
        a2 = core_bytes(c3)
        d2 = _t3.time() - _s0
        t('★★★ 크기를 **기억한다**(두 번째가 훨씬 빠르다)',
          a1 == a2 and d2 < max(d1 * 0.5, 0.02),
          '%.2f초 → %.3f초' % (d1, d2))
        t('  ★ `fresh=True` 면 다시 센다', core_bytes(c3, fresh=True) == a1)
        core_bytes_clear()
        t('  기억을 버릴 수 있다', _CB_MEMO['val'] is None)
    finally:
        c3.close()

    print('db_pack_catalog selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--audit', action='store_true')
    ap.add_argument('--missing', action='store_true')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.missing:
            m = missing(c)
            print('분류 안 된 표 %d개' % len(m))
            for t in m:
                print('   %s' % t)
        if a.audit:
            res = audit(c)
            for layer in (CORE, PACK, LOCAL, REVIEW):
                rows = res.get(layer) or []
                tot = sum(r[2] for r in rows if r[2] > 0)
                print('%s — 표 %d개 · %s행' % (layer, len(rows), f'{tot:,}'))
                for t_, kind, n, d in sorted(rows, key=lambda x: -x[2])[:8]:
                    print('   %-30s %-7s %9s  %s'
                          % (t_, kind or '', f'{n:,}' if n >= 0 else '?', d))
                print()
    finally:
        c.close()


if __name__ == '__main__':
    main()
