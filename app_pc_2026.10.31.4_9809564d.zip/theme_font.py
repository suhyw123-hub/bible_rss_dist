# -*- coding: utf-8 -*-
"""폰트·테마 단일 소스 (2026-08-13 신설 — `font.md` 종합계획 1단계).

무엇을 하나
    앱의 모든 글자가 이 모듈 하나를 거친다. 화면은 `apply(widget, db, scope)` 만 부르고
    **글꼴 이름을 직접 적지 않는다.**

왜 필요했나 — 실측 셋 (`font.md` §0)
    ① **`'Malgun Gothic'` 이라는 이름을 Tk 가 못 찾는다.** 코드 442곳이 그 이름을 쓰는데
       `tkfont.families()` 에는 한글명 `'맑은 고딕'` 만 있다. 한국어 Windows 에서는
       기본 폰트가 어차피 맑은 고딕이라 **차이가 안 보일 뿐**, 다른 로케일에서는
       442곳이 전부 그 OS 기본 폰트로 떨어진다.
    ② **한글과 히브리·아랍을 함께 가진 폰트가 0개다.** 「하나로 통일」은 물리적으로 불가능하다.
    ③ **글리프 판정에 `tkfont.measure()` 를 쓸 수 없다** — 글자가 없어도 대체 폭을 돌려주어
       모든 폰트가 모든 문자를 지원하는 것처럼 나온다(실제로 그렇게 나왔다). `cmap` 을 읽는다.

구조 — 「비어 있으면 위를 따른다」
    base 한 벌 위에 구역이 얹힌다. 구역이 비어 있으면 base 를 그대로 쓰고,
    값이 있으면 **그 항목만** 덮는다. 우선순위가 하나뿐이라 충돌이 없다.

    ⚠ **`clear(scope)` 가 반드시 있어야 한다.** 값이 한 번 들어가면 base 를 바꿔도
      따라오지 않으므로, 되돌릴 길이 없으면 「일단 통일하고 나중에 개별 수정」이 깨진다.
"""

import json
import os
import struct
import sqlite3

CONFIG_KEY = 'THEME'
CACHE_FILE = 'font_cache.json'      # cmap 스캔 결과 (앱 폴더)

# ── 구역 (font.md §7 — 6구역 + 원어) ─────────────────────────────────────────
# ── 역할 5가지 (2026-08-13 사용자 확정 · font.md §22) ────────────────────────
# ★ 예전 7구역은 **장소**(어느 화면) 기준이라 성경 구절을 못 묶었다 — 구절이 나오는
#   화면이 아홉인데 `bible` 은 P1 하나만 덮었다. 그래서 **역할**(무엇인가)로 바꿨다.
#
# ⚠ **두 줄이 규칙의 핵심이다. 흐려지면 이 작업의 뜻이 사라진다.**
#   ① **성경 구절은 어디에 있든 `bible`** — 목록 안이든 카드 안이든.
#      그래서 **성경 구절 목록(트리뷰·리스트)은 `list` 가 아니라 `bible`** 이다.
#   ② **묵상노트는 `prose`** — 사용자가 길게 쓰는 글이라 읽는 조건이 설명문과 같다.
SCOPES = {
    'bible': '성경',      # 구절 그 자체 — P1·페리코프·렌즈카드·묵상플랜·연쇄·
                          #   여정·역본비교·음성성경·가계도 정보칸 **전부**
    'prose': '문장',      # 길게 읽는 글 — 설명문·주석·도서/설교·내부자료·묵상노트
    'list':  '목록',      # 표·트리 한 줄 (성경 구절 목록은 뺀다 — 그건 bible)
    'meta':  '딸림글',    # 절 번호·출처·개수·날짜·메타
    'ui':    '조작',      # 탭 머리글·버튼·라벨·콤보
}

# 옛 이름 → 새 역할. **저장된 값과 화면 코드가 그대로 살아 있게** 한다.
# ⚠ 지우지 말 것 — `desc`/`ref`/`book` 으로 등록하는 화면이 아직 여럿이다.
LEGACY_SCOPE = {'desc': 'prose', 'ref': 'prose', 'book': 'prose',
                'canvas': 'meta'}

MODE_ALL, MODE_EACH = 'ALL', 'EACH'   # 전체 적용 / 선택 적용 (배타)

# ★ **읽기 서식 둘을 더한다** (2026-08-14 사용자 지시 「도서읽기 스타일을 구현하기
#   위해서 독특하게 필요한 폰트나 서식을 추가로 만들어야 한다면 적극 시도하라」).
#   책 조판이 하는 두 가지인데 지금껏 없었다:
#     `first_indent` — 문단 **첫 줄**만 들여쓴다. 문단이 어디서 시작하는지 보인다.
#     `read_width`   — **읽는 폭**(글자 수). 창을 넓혀도 한 줄이 그 이상 길어지지 않는다.
#                      0 이면 제한 없음(지금까지의 동작).
#   ⚠ 읽는 화면에만 뜻이 있다 — 목록·버튼에는 넣지 않는다(`READING` 역할만).
# ★ **글자색도 여기서 정한다** (2026-08-14 사용자 지시 「통합 폰트에 글자색상을 추가」).
#   빈 문자열이면 **테마가 정한 색**을 쓴다 — 색을 안 고른 것이 기본이다.
#   ⚠ 바탕색은 넣지 않는다. 그건 테마(`ui_theme`)의 몫이고, 두 곳에서 정하면
#     「글자는 폰트 화면에서, 바탕은 테마에서」가 되어 대비가 깨질 수 있다.
BASE_DEFAULTS = {'family': '', 'size': 10,
                 'line_gap': 2, 'para_gap': 4, 'margin': 10,
                 'first_indent': 0, 'read_width': 0, 'color': ''}
LIMITS = {'size': (7, 30), 'line_gap': (0, 14),
          'para_gap': (0, 20), 'margin': (0, 60),
          'first_indent': (0, 40), 'read_width': (0, 120)}

# ── 문자체계 (§9) ────────────────────────────────────────────────────────────
# 대표 코드포인트 하나로 판정한다. 히브리는 **모음기호까지** 있어야 본문을 읽을 수 있다.
SCRIPTS = {
    'ko':  ('한글',   (0xAC00,)),
    'el':  ('헬라어', (0x03B1,)),
    'he':  ('히브리', (0x05D0, 0x05B0)),      # 자음 + 니쿠드
    'ar':  ('아랍어', (0x0627,)),
    'cop': ('콥트어', (0x2C81,)),
    'cjk': ('한자·가나', (0x4E00, 0x3042)),
    'ru':  ('키릴',   (0x0430,)),
}

# 후보 사슬.
# ⚠ **앞자리는 우리가 번들한 것**(`fonts/`, SIL OFL — 어느 PC 에나 있다),
#   **마지막은 Windows 기본 폰트**(있으면 쓰고 배포는 안 한다).
#   Cardo·Ezra SIL 같은 연구용 폰트는 이 PC 에만 있어 중간에만 둔다.
PREFERRED = {
    'ko':  ['맑은 고딕', 'Malgun Gothic', '바탕', 'Batang', '굴림', 'Gulim'],
    'el':  ['Palatino Linotype', 'Georgia', 'Times New Roman', 'Arial'],
    'he':  ['Noto Sans Hebrew', 'Ezra SIL', 'Cardo', 'SBL Hebrew',
            'Times New Roman', 'Arial'],
    'ar':  ['Noto Sans Arabic', 'Tahoma', 'Segoe UI', 'Arial'],
    # ⚠ 콥트는 Windows 쪽에 `Segoe UI Historic` 하나뿐인데 **재배포가 안 된다.**
    #   번들한 Noto 를 앞에 세워야 다른 PC 에서도 깨지지 않는다.
    'cop': ['Noto Sans Coptic', 'Segoe UI Historic', 'Segoe UI Symbol'],
    'cjk': ['맑은 고딕', '바탕', 'Yu Gothic', 'SimSun'],
    'ru':  ['Segoe UI', 'Arial', 'Times New Roman'],
}

# 번들 폴더(앱과 함께 배포 · SIL OFL 만) / 사용자 폴더(각자 넣는 곳)
BUNDLE_DIR = 'fonts'
USER_DIR = 'fonts_user'

_families_cache = None
_cmap_cache = None


# ── 폰트 파일 불러오기 — **설치하지 않고 쓴다** ──────────────────────────────
_loaded = []


def load_font_files(app_dir=None):
    """`fonts/` 와 `fonts_user/` 의 폰트를 이 프로세스에만 등록한다.

    ★ **설치가 필요 없다** (2026-08-13 실측). `AddFontResourceExW(path, FR_PRIVATE, 0)`
      로 등록하면 Tk 의 폰트 목록에 나타나고 그대로 렌더된다.
      표본 `Accordance.ttf`(Tk 가 모르던 파일) → 등록 후 인식·렌더 확인.

    ⚠ **`tk.Tk()` 를 만들기 전에 불러야 한다.** Tk 는 시작할 때 폰트 목록을 잡는다.
    ⚠ `FR_PRIVATE` 라 **시스템에 설치되지 않는다** — 앱을 닫으면 흔적이 남지 않고,
      관리자 권한도 필요 없다.

    무엇을 넣나
      `fonts/`      우리가 배포하는 것. **SIL OFL 만.** 지금은 원어 3종(308KB).
                    ⚠ Arial·Segoe UI·맑은 고딕 같은 **Windows 번들 폰트는 넣을 수 없다**(재배포 금지).
      `fonts_user/` 사용자가 직접 넣는 곳. 넣기만 하면 콤보에 나타난다.
    """
    import glob
    if os.name != 'nt':
        return 0
    app_dir = app_dir or os.path.dirname(os.path.abspath(__file__))
    n = 0
    for sub in (BUNDLE_DIR, USER_DIR):
        d = os.path.join(app_dir, sub)
        if not os.path.isdir(d):
            continue
        for p in sorted(glob.glob(os.path.join(d, '*.tt*')) +
                        glob.glob(os.path.join(d, '*.otf'))):
            try:
                import ctypes
                if ctypes.windll.gdi32.AddFontResourceExW(
                        ctypes.c_wchar_p(os.path.abspath(p)), 0x10, 0):
                    _loaded.append(p)
                    n += 1
            except Exception:
                pass
    if n:
        global _families_cache, _cmap_cache
        _families_cache = None      # 목록이 늘었으니 다시 읽는다
        _cmap_cache = None
    return n


def loaded_files():
    """등록에 성공한 파일들 (설정 화면의 안내용)."""
    return list(_loaded)


# ── 설치 폰트 이름 해결 (실측 ①) ─────────────────────────────────────────────
def families():
    """Tk 가 아는 폰트 이름들. `@` 로 시작하는 세로쓰기 변형은 뺀다."""
    global _families_cache
    if _families_cache is None:
        try:
            import tkinter.font as tkfont
            _families_cache = {f for f in tkfont.families() if not f.startswith('@')}
        except Exception:
            _families_cache = set()
    return _families_cache


# 한글 Windows 는 폰트 패밀리명을 현지화한다. 영문명으로 지정하면 **조용히 실패**한다.
_ALIAS = {
    'Malgun Gothic': '맑은 고딕', '맑은 고딕': 'Malgun Gothic',
    'Batang': '바탕', '바탕': 'Batang',
    'Gulim': '굴림', '굴림': 'Gulim',
    'Dotum': '돋움', '돋움': 'Dotum',
    'Gungsuh': '궁서', '궁서': 'Gungsuh',
}


def resolve_family(name, script='ko'):
    """실제로 쓸 수 있는 폰트 이름으로 바꾼다.

    ⚠ 이 함수가 없으면 `'Malgun Gothic'` 이 다른 로케일에서 통째로 무시된다.
    """
    fams = families()
    # ⚠ **「확인할 수 없다」와 「설치돼 있지 않다」는 다르다** (2026-08-14).
    #   Tk 가 없거나 목록을 못 읽으면 `families()` 가 빈 집합을 준다. 그때 없는
    #   것으로 단정하면 사용자가 고른 글꼴이 **조용히 버려진다.**
    if not fams:
        return name or ''
    if name and name in fams:
        return name
    alt = _ALIAS.get(name)
    if alt and alt in fams:
        return alt
    for cand in PREFERRED.get(script, []):
        if cand in fams:
            return cand
        a = _ALIAS.get(cand)
        if a and a in fams:
            return a
    return ''            # 빈 문자열 = Tk 기본 글꼴에 맡긴다


# ── cmap 판독 (실측 ③) ───────────────────────────────────────────────────────
def _cmap_ranges(path):
    """폰트 파일이 담고 있는 코드포인트 구간. 실패하면 None."""
    try:
        d = open(path, 'rb').read()
    except Exception:
        return None
    offs = [0]
    if d[:4] == b'ttcf':
        try:
            n = struct.unpack('>I', d[8:12])[0]
            offs = [struct.unpack('>I', d[12 + i * 4:16 + i * 4])[0] for i in range(min(n, 1))]
        except Exception:
            return None
    got = set()
    for off in offs:
        try:
            num = struct.unpack('>H', d[off + 4:off + 6])[0]
            co = None
            for i in range(num):
                rec = off + 12 + i * 16
                if d[rec:rec + 4] == b'cmap':
                    co = struct.unpack('>I', d[rec + 8:rec + 12])[0]
            if co is None:
                continue
            n2 = struct.unpack('>H', d[co + 2:co + 4])[0]
            best = None
            for i in range(n2):
                pid, eid, o = struct.unpack('>HHI', d[co + 4 + i * 8:co + 12 + i * 8])
                if (pid, eid) in ((3, 1), (3, 10), (0, 3), (0, 4)):
                    best = co + o
            if best is None:
                continue
            fmt = struct.unpack('>H', d[best:best + 2])[0]
            if fmt == 4:
                sx = struct.unpack('>H', d[best + 6:best + 8])[0]
                seg = sx // 2
                ends = [struct.unpack('>H', d[best + 14 + i * 2:best + 16 + i * 2])[0]
                        for i in range(seg)]
                sp = best + 16 + sx
                starts = [struct.unpack('>H', d[sp + i * 2:sp + i * 2 + 2])[0]
                          for i in range(seg)]
                got |= {(s, e) for s, e in zip(starts, ends) if s != 0xFFFF}
            elif fmt == 12:
                ng = struct.unpack('>I', d[best + 12:best + 16])[0]
                for i in range(min(ng, 8000)):
                    s, e, _ = struct.unpack('>III', d[best + 16 + i * 12:best + 28 + i * 12])
                    got.add((s, e))
        except Exception:
            pass
    return got or None


def _family_names(path):
    """폰트 파일이 스스로 밝히는 **패밀리 이름들** (`name` 테이블 nameID=1).

    ⚠ 파일명으로 추측하면 안 된다 — `Cardo104s.ttf` 의 패밀리명은 `Cardo` 다.
      첫 구현이 파일명 대조라 히브리 폰트를 37개 중 4개만 찾아냈다(2026-08-13 실측).
    ⚠ 한글 Windows 는 **현지화된 이름도 함께** 담고 있다(`맑은 고딕` ↔ `Malgun Gothic`).
      둘 다 거둔다.
    """
    try:
        d = open(path, 'rb').read()
    except Exception:
        return []
    offs = [0]
    if d[:4] == b'ttcf':
        try:
            n = struct.unpack('>I', d[8:12])[0]
            offs = [struct.unpack('>I', d[12 + i * 4:16 + i * 4])[0] for i in range(min(n, 4))]
        except Exception:
            return []
    out = []
    for off in offs:
        try:
            num = struct.unpack('>H', d[off + 4:off + 6])[0]
            no = None
            for i in range(num):
                rec = off + 12 + i * 16
                if d[rec:rec + 4] == b'name':
                    no = struct.unpack('>I', d[rec + 8:rec + 12])[0]
            if no is None:
                continue
            cnt, so = struct.unpack('>HH', d[no + 2:no + 6])
            base = no + so
            for i in range(cnt):
                p = no + 6 + i * 12
                pid, eid, lid, nid, ln, o = struct.unpack('>HHHHHH', d[p:p + 12])
                if nid != 1:                 # 1 = Font Family
                    continue
                raw = d[base + o:base + o + ln]
                try:
                    s = raw.decode('utf-16-be') if pid == 3 else raw.decode('latin-1')
                except Exception:
                    continue
                s = s.strip('\x00').strip()
                if s:
                    out.append(s)
        except Exception:
            pass
    return out


def _font_dir():
    return os.path.join(os.environ.get('WINDIR', r'C:\Windows'), 'Fonts')


def _scan(app_dir):
    """설치 폰트를 문자체계별로 가른다. **결과를 파일에 캐시한다.**

    ⚠ 164개 파일을 여는 작업이라 **시작 경로에서 부르면 안 된다**(§29 시작 성능).
      폰트 콤보를 처음 열 때만 부른다.
    """
    import glob
    cache = os.path.join(app_dir, CACHE_FILE)
    # ⚠ **시스템 폴더만 훑으면 번들·사용자 폰트가 목록에 안 뜬다.**
    #   첫 구현이 그래서 `Noto Sans Coptic` 을 번들해 두고도 콤보에 못 올렸다
    #   (2026-08-13 — 컨트롤 타워 검사에서 잡았다). 세 폴더를 함께 본다.
    dirs = [_font_dir(),
            os.path.join(app_dir, BUNDLE_DIR),
            os.path.join(app_dir, USER_DIR)]
    files = []
    for d in dirs:
        if os.path.isdir(d):
            files += glob.glob(os.path.join(d, '*.tt*')) + glob.glob(os.path.join(d, '*.otf'))
    files = sorted(files)
    sig = str(len(files))
    if os.path.exists(cache):
        try:
            d = json.load(open(cache, encoding='utf-8'))
            if d.get('sig') == sig:
                return d['map']
        except Exception:
            pass
    fams = families()
    out = {k: [] for k in SCRIPTS}
    for p in files:
        rn = _cmap_ranges(p)
        if not rn:
            continue
        # 파일이 스스로 밝힌 패밀리명 가운데 **Tk 가 아는 것**을 고른다.
        # ⚠ Tk 목록에 없는 이름을 넣으면 콤보에서 골라도 적용되지 않는다(실측 ①).
        name = next((n for n in _family_names(p) if n in fams), None)
        if not name:
            continue
        for key, (_, cps) in SCRIPTS.items():
            if all(any(s <= cp <= e for s, e in rn) for cp in cps):
                out[key].append(name)
    for k in out:
        out[k] = sorted(set(out[k]))
    try:
        json.dump({'sig': sig, 'map': out}, open(cache, 'w', encoding='utf-8'),
                  ensure_ascii=False)
    except Exception:
        pass
    return out


def fonts_for(script, app_dir=None):
    """그 문자를 **실제로 가진** 폰트 이름들 (콤보에 올릴 목록).

    ⚠ 목록이 비면 후보 사슬로 대신한다 — 스캔이 실패해도 화면이 비지 않게.
    """
    global _cmap_cache
    app_dir = app_dir or os.path.dirname(os.path.abspath(__file__))
    if _cmap_cache is None:
        try:
            _cmap_cache = _scan(app_dir)
        except Exception:
            _cmap_cache = {}
    got = _cmap_cache.get(script) or []
    if got:
        return got
    fams = families()
    return [c for c in PREFERRED.get(script, []) if c in fams]


# ── 저장 ─────────────────────────────────────────────────────────────────────
def _clamp(key, v, dflt):
    try:
        v = int(v)
    except Exception:
        return dflt
    lo, hi = LIMITS.get(key, (v, v))
    return max(lo, min(hi, v))


def _connect(db_path):
    """⚠ **`sqlite3.connect` 를 직접 쓰면 안 된다** (CLAUDE.md §1).

    `user_config` 는 `user_data.db` 에 있고 앱이 넘기는 `db_path` 는 `bible_master.db` 다.
    직접 열면 그 표가 없어 **조용히 실패한다** — 2026-08-13 에 실제로 그랬다.
    설정 창의 [＋]를 눌러도 숫자조차 안 바뀌었고 오류도 안 났다.
    `appdb.connect` 가 `user_data.db` 를 ATTACH 해 주므로 그것을 쓴다.

    ⚠ 검사용 임시 DB 는 ATTACH 대상이 아니므로 실패하면 직접 연결로 물러선다.
    """
    try:
        import appdb
        c = appdb.connect(db_path)
        c.execute("SELECT 1 FROM user_config LIMIT 1")
        return c
    except Exception:
        pass
    return sqlite3.connect(db_path)


#: 읽은 설정 글을 **1초만** 기억한다(2026-10-09 사용자 「앱이 표시될 때까지 지연」 —
#:   실측 시작 한 번에 이 파일이 DB 를 **25번** 열었다(0.1초)). 쓰는 자리(`_write` ·
#:   `db_pref_preset.apply`)는 `forget()` 으로 지운다 — 바꾼 설정이 늦게 보이지 않게.
_RAW = {}
RAW_TTL = 1.0


def forget():
    _RAW.clear()


def _read_raw(db_path):
    import time as _time
    k = str(db_path)
    hit = _RAW.get(k)
    if hit and _time.monotonic() - hit[0] < RAW_TTL:
        return hit[1]
    raw = None
    conn = None
    try:
        conn = _connect(db_path)
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?",
                         (CONFIG_KEY,)).fetchone()
        raw = r[0] if r and r[0] else None
    except Exception:
        raw = None
    finally:
        if conn is not None:
            conn.close()
    _RAW[k] = (_time.monotonic(), raw)
    return raw


def load(db_path):
    """저장된 것 전부. 없으면 기본 한 벌만 든 dict."""
    # ⚠ `with sqlite3.connect(...)` 는 **트랜잭션만** 관리하고 연결을 닫지 않는다.
    #   그대로 두면 연결이 쌓이고 파일 잠금이 풀리지 않는다(selftest 가 잡아냈다).
    d = {}
    try:
        raw = _read_raw(db_path)
        if raw:
            d = json.loads(raw)            # 늘 새 dict — 기억한 글을 부르는 쪽이 못 바꾼다
    except Exception:
        d = {}
    f = d.get('font') or {}
    base = dict(BASE_DEFAULTS)
    base.update({k: v for k, v in (f.get('base') or {}).items() if v not in (None, '')})
    base.setdefault('color', '')
    for k in ('size', 'line_gap', 'para_gap', 'margin',
              'first_indent', 'read_width'):
        base[k] = _clamp(k, base.get(k), BASE_DEFAULTS[k])
    # ⚠ **여기서 다시 조립하므로 새 열쇠를 빠뜨리면 조용히 사라진다.**
    #   `mode` 를 안 넣었다가 「저장은 되는데 다시 읽으면 없다」를 실제로 겪었다
    #   (2026-08-13). 열쇠를 더할 때는 **반드시 이 줄에도 더한다.**
    return {'font': {'base': base,
                     **{s: dict(f.get(s) or {}) for s in SCOPES},
                     'mode': (f.get('mode') if f.get('mode') in (MODE_ALL, MODE_EACH)
                              else MODE_ALL),
                     'script': dict(f.get('script') or {})},
            'dark': bool(d.get('dark', False))}


def _write(db_path, data):
    forget()
    conn = None
    try:
        conn = _connect(db_path)
        conn.execute("INSERT INTO user_config (config_key, config_val) VALUES (?, ?) "
                     "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                     (CONFIG_KEY, json.dumps(data, ensure_ascii=False)))
        conn.commit()
        forget()
        return True
    except Exception as e:
        # ⚠ 여기서 삼키면 **화면이 안 바뀌는데 이유를 알 수 없다**(실제로 겪었다).
        import sys
        print('theme_font: 저장 실패 —', e, file=sys.stderr)
        return False
    finally:
        if conn is not None:
            conn.close()


def save(db_path, scope='base', **kw):
    """그 구역의 항목만 **덮어쓴다**. 통째로 갈아 끼우지 않는다.

    ⚠ 값에 `None` 을 주면 **그 항목만 지운다**(= 기본을 따르게 한다).
    """
    d = load(db_path)
    tgt = d['font'].setdefault(_scope(scope), {})
    for k, v in kw.items():
        if v is None:
            tgt.pop(k, None)
        else:
            tgt[k] = _clamp(k, v, BASE_DEFAULTS.get(k, v)) if k in LIMITS else v
    return _write(db_path, d)


def clear(db_path, scope):
    """그 구역을 통째로 비운다 = **기본으로 되돌리기**."""
    if scope == 'base':
        return False                      # base 는 비울 수 없다
    d = load(db_path)
    d['font'][_scope(scope)] = {}
    return _write(db_path, d)


def is_default(db_path, scope):
    """그 구역이 기본을 따르고 있는가 (화면에 「(기본을 따름)」 표시용)."""
    return not (load(db_path)['font'].get(scope) or {})


# ── 읽기 ─────────────────────────────────────────────────────────────────────
def get_mode(db_path):
    """지금 **전체 적용**인가 **선택 적용**인가. 기본은 전체 적용.

    ★ 두 영역은 **배타적**이다 (2026-08-13 사용자 설계).
      · 전체 적용 — 한 벌이 화면 전체를 지배한다. 역할 값은 **무시**된다.
      · 선택 적용 — 역할마다 제 값이 쓰인다.
    ⚠ 모드를 바꿀 때 **역할 값을 지우지 않는다.** 지우면 전체 적용으로 갔다가
      돌아올 때 공들여 맞춘 값이 사라진다. 무시할 뿐 그대로 둔다.
    """
    m = load(db_path)['font'].get('mode')
    return m if m in (MODE_ALL, MODE_EACH) else MODE_ALL


def sync_roles(db_path):
    """모든 역할 값을 **전체 적용 값과 똑같이** 맞춘다.

    ★ 사용자 설계 — 「전체 적용에서 폰트를 수정하면 선택 적용 화면에서
      **모든 값이 자동으로 동일하게 따라서 반영된다**」.
    ⚠ 표시만 같게 하는 것으로는 부족하다. 값이 실제로 같아져야 그다음
      선택 적용에서 **거기서부터** 손댈 수 있다(안 그러면 옛 값에서 튄다).
    """
    d = load(db_path)
    base = d['font']['base']
    keep = ('family', 'size', 'line_gap', 'para_gap', 'margin',
            'first_indent', 'read_width', 'color')
    for sc in SCOPES:
        d['font'][sc] = {k: base[k] for k in keep if base.get(k) not in (None, '')}
    return _write(db_path, d)


def set_mode(db_path, mode):
    d = load(db_path)
    d['font']['mode'] = MODE_ALL if mode not in (MODE_ALL, MODE_EACH) else mode
    return _write(db_path, d)


def _scope(scope):
    """옛 구역 이름을 새 역할로 옮긴다. **들어오는 문 하나에서만** 한다.

    ⚠ 화면 코드가 아직 `'desc'`·`'ref'`·`'book'` 으로 부른다. 그 쪽을 다 고치는 것보다
      여기서 받아 주는 편이 안전하다 — 놓치면 조용히 `base` 로 떨어져 버린다.
    """
    return LEGACY_SCOPE.get(scope, scope)


def resolve(db_path, scope='base', script='ko'):
    """base 위에 구역을 덮은 **최종값**. 글꼴은 설치 확인까지 마친 이름으로 돌려준다."""
    scope = _scope(scope)
    d = load(db_path)['font']
    out = dict(d['base'])
    # ★ **전체 적용이면 역할 값을 보지 않는다** — 두 영역이 배타적이다.
    if scope != 'base' and (d.get('mode') or MODE_ALL) == MODE_EACH:
        out.update({k: v for k, v in (d.get(scope) or {}).items()
                    if v not in (None, '')})
    if script != 'ko':
        s = (d.get('script') or {}).get(script)
        if s:
            out['family'] = s
    out['family'] = resolve_family(out.get('family'), script)
    return out


# ── UI 크롬 · 목록/표 (font.md 5단계) ────────────────────────────────────────
# Tk 가 이름으로 들고 있는 글꼴들. **폰트를 명시하지 않은 위젯이 전부 이것을 쓴다.**
# 하나만 고치면 화면 전체가 따라오므로, 하드코딩 449곳을 손대기 전에 여기부터 잇는다.
_NAMED = ('TkDefaultFont', 'TkTextFont', 'TkMenuFont', 'TkHeadingFont',
          'TkCaptionFont', 'TkSmallCaptionFont', 'TkIconFont', 'TkTooltipFont')
_named_orig = {}


def apply_ui(db_path, root=None):
    """이름 붙은 글꼴을 「화면 글자」 구역에, `ttk.Style` 을 「목록·표」 구역에 맞춘다.

    ★ 이것이 **비용 대비 효과가 가장 크다** — `font=` 를 명시하지 않은 위젯은
      전부 `TkDefaultFont` 를 쓰므로 한 곳만 고치면 즉시 따라온다.

    ⚠ **`TkFixedFont` 는 글꼴을 바꾸지 않는다** — 고정폭이 깨지면 표가 어긋난다.
    ⚠ **`Treeview` 는 행 높이가 글꼴을 따라가지 않는다.** 글자만 키우면 잘린다.
      `rowheight` 를 함께 올려야 한다.
    ⚠ 첫 호출 때 원래 값을 갈무리해 둔다 — 되돌릴 길이 없으면 실험을 못 한다.
    """
    try:
        import tkinter.font as tkfont
        from tkinter import ttk
    except Exception:
        return False
    ui = resolve(db_path, 'ui')
    lst = resolve(db_path, 'list')
    own_ui = load(db_path)['font'].get('ui') or {}
    own_lst = load(db_path)['font'].get('list') or {}
    try:
        for nm in _NAMED:
            try:
                f = tkfont.nametofont(nm)
            except Exception:
                continue
            if nm not in _named_orig:
                _named_orig[nm] = dict(family=f.cget('family'), size=f.cget('size'))
            o = _named_orig[nm]
            # 지정한 것만 덮는다. 비어 있으면 **원래 값으로 되돌린다.**
            fam = own_ui.get('family') or (ui['family'] if own_ui.get('family') else o['family'])
            size = int(own_ui['size']) if 'size' in own_ui else int(o['size'])
            f.configure(family=fam or o['family'], size=size)

        st = ttk.Style(root) if root is not None else ttk.Style()
        fam = own_lst.get('family') or lst.get('family') or ''
        size = int(own_lst.get('size', lst.get('size', 10)))
        st.configure('Treeview', font=(fam, size), rowheight=max(16, int(size * 2.0)))
        st.configure('Treeview.Heading', font=(fam, size))
        return True
    except Exception as e:
        import sys
        print('theme_font.apply_ui:', e, file=sys.stderr)
        return False


_registry = []          # [(weakref(widget), scope, script, size_delta)]


def register(widget, db_path, scope='base', script='ko', size_delta=0):
    """적용하고 **기억한다.** 설정이 바뀌면 `reapply_all()` 이 다시 입힌다.

    ★ 왜 필요한가 (2026-08-13 — 사용자가 「작동하지 않는다」고 두 번 지적).
      화면마다 만들 때 `apply()` 를 한 번 부르면 **그때만** 적용된다. 설정 창에서
      값을 바꿔도 그 위젯은 그대로다 — 앱을 다시 켜야 반영된다.
      호출부마다 「설정이 바뀌면 나를 다시 불러 달라」를 따로 배선하면 **빠뜨린 곳이
      조용히 안 따라온다**(실제로 주석·묵상노트·도서 본문이 그랬다).
    ⇒ 등록해 두고 한 번에 다시 입힌다. **화면은 `register` 만 부르면 된다.**

    ⚠ 약한 참조라 위젯이 사라지면 목록에서 저절로 빠진다(창을 여닫아도 새지 않는다).
    """
    import weakref
    # ⚠ **호출부가 `except: pass` 로 감싸는 일이 잦다.** 속성 이름을 잘못 짚어도
    #   조용히 지나가 「그 화면만 안 따라온다」가 된다(2026-08-13 주석 패널이 그랬다).
    #   여기서 db_path 가 이상하면 **알린다.**
    if not db_path:
        import sys
        print(f'theme_font.register: db_path 가 비었다 (scope={scope})', file=sys.stderr)
    apply(widget, db_path, scope, script, size_delta)
    if widget is None:
        return
    try:
        _registry.append((weakref.ref(widget), scope, script, size_delta))
    except TypeError:                     # 약한 참조를 못 만드는 위젯
        pass


# ── ★ 박힌 크기를 **base 대비 단계**로 (2026-08-13 · font.md §22) ────────────
# 화면 코드에 `font=('Malgun Gothic', 9)` 이 **537곳** 박혀 있다. 그것들이 base 를
# 가로막아 「기본 하나로 전체 적용」이 그 자리에서 멈춘다.
#
# ★ **역할을 가리려 하지 않는다.** 실측해 보니 `9pt` 274곳 중 Label 이 133곳이라
#   크기로도 위젯 종류로도 역할이 안 갈렸다(§22). 색 literal 과 달리 **`9pt` 에는
#   아무 뜻이 없다.** 그래서 뜻을 짐작하는 대신 **위계만 지킨다** —
#   기준(10pt) 대비 몇 단계인지를 기억했다가 base 에 그 단계를 얹는다.
#     8pt = base−2 · 9pt = base−1 · 11pt = base+1 …
#   기본을 키우면 화면 전체가 **위계를 지킨 채** 함께 커진다.
_ORIG_FONT = '_hagah_orig_font'
_LAST_FONT = '_hagah_last_font'
_ORIG_FAM  = '_hagah_orig_family'   # ★ 화면이 박아 둔 글꼴 이름 (되돌릴 자리)
_LAST_FAM  = '_hagah_last_family'
REF_SIZE = 10                      # 이 크기를 「단계 0」으로 본다


def scale(widget, db_path, _n=None, only_new=False):
    """이 위젯과 그 아래 전부의 **글꼴 이름과 크기**를 설정값 기준으로 다시 잡는다.

    ★ **크기는 단계로, 글꼴 이름은 그대로 덮는다** (2026-08-14).
      크기에는 위계가 있어(제목이 본문보다 크다) 기준 대비 단계를 지켜야 하지만,
      **글꼴 이름에는 위계가 없다** — 「기본 글꼴을 궁서로」는 화면 전체가 궁서라는 뜻이다.
      ⚠ 그전까지 이 함수는 **크기만** 바꿨다. 그래서 통합 폰트 창에서 글꼴을 바꿔도
        `font=('Malgun Gothic', 9)` 이 박힌 442곳은 꼼짝하지 않았고, 사용자에게는
        「폰트가 작동하지 않는다」로 보였다(2026-08-14 지적).

    ⚠ **`register()` 로 등록된 위젯은 건드리지 않는다** — 그쪽은 역할이 통제한다.
    ⚠ 위젯이 처음 갖고 있던 값을 기억해 두므로 설정을 비우면 원본이 되살아난다
      (`ui_theme.paint` 와 같은 방식).
    ⚠ 기준은 `base` 가 아니라 **`ui` 구역**이다 — 역할이 없는 위젯은 전부 화면 크롬이고,
      `resolve` 가 `ui` 에 값이 없으면 base 로 떨어뜨려 주므로 「기본」도 그대로 걸린다.
    """
    n = 0 if _n is None else _n
    d = resolve(db_path, 'ui')
    own = load(db_path)['font']
    # 글꼴 이름은 **누군가 명시했을 때만** 덮는다. 비어 있으면 화면이 정한 것을 지킨다.
    want_fam = ''
    if (own.get('mode') or MODE_ALL) == MODE_ALL:
        want_fam = (own.get('base') or {}).get('family') or ''
    else:
        want_fam = ((own.get('ui') or {}).get('family')
                    or (own.get('base') or {}).get('family') or '')
    if want_fam:
        want_fam = resolve_family(want_fam, 'ko')
    reg = {id(r()) for r, *_ in _registry if r() is not None}
    return _scale(widget, d['size'], want_fam, reg, n, only_new)


_SEEN = '_hagah_scaled_once'    # 글꼴이 없는 위젯(프레임 등)도 재방문을 건너뛰게


def _scale(w, base, want_fam, reg, n, only_new=False):
    # ★ `only_new` — 탭 전환·Map 고리 전용 (2026-08-27 「P1 탭이 깜빡하며
    #   느려졌다」). 한 번 잰 위젯(방문 표식)은 cget/파싱을 생략하고
    #   자식으로만 내려간다 — 지연 빌드가 만든 새 위젯만 온전히 잰다.
    #   전환당 실측 ~90ms → 수 ms. 전체 재기(시작·설정 저장)는 이 모드를 안 쓴다.
    if only_new and getattr(w, _SEEN, False):
        for c in w.winfo_children():
            n = _scale(c, base, want_fam, reg, n, only_new)
        return n
    try:
        setattr(w, _SEEN, True)
    except Exception:
        pass
    # ★ **역할이 관리하는 위젯은 건너뛴다.**
    #   안 그러면 `reapply_all` 이 역할 값으로 입힌 것을 `scale` 이 곧바로
    #   base 기준으로 덮어써서 **두 손이 싸운다** — 실제로 전체 적용으로 바꿔도
    #   P1 본문만 옛 크기로 남았다(2026-08-13).
    if id(w) not in reg and not getattr(w, MANAGED, False):
        try:
            cur = w.cget('font')
        except Exception:
            cur = None
        if cur:
            got = _parse_font(cur)
            if got:
                fam, size, rest = got
                orig = getattr(w, _ORIG_FONT, None)
                last = getattr(w, _LAST_FONT, None)
                if orig is None or (last is not None and size != last):
                    orig = size            # 화면이 새로 정했으면 그것을 원본으로
                    setattr(w, _ORIG_FONT, orig)
                want = max(LIMITS['size'][0],
                           min(LIMITS['size'][1], base + (orig - REF_SIZE)))
                # ── 글꼴 이름 ─────────────────────────────────────────────
                # ⚠ 화면이 스스로 글꼴을 갈아 끼웠는지 알아야 한다. 우리가 넣은 값과
                #   지금 값이 다르면 화면이 바꾼 것이므로 **그것을 새 원본으로** 받는다.
                o_fam = getattr(w, _ORIG_FAM, None)
                l_fam = getattr(w, _LAST_FAM, None)
                if o_fam is None or (l_fam is not None and fam != l_fam):
                    o_fam = fam
                    setattr(w, _ORIG_FAM, o_fam)
                nfam = want_fam or o_fam   # 지정이 없으면 화면이 정한 것으로 되돌린다
                if want != size or nfam != fam:
                    try:
                        w.configure(font=(nfam, want) + rest)
                        n += 1
                    except Exception:
                        pass
                setattr(w, _LAST_FONT, want)
                setattr(w, _LAST_FAM, nfam)
    for c in w.winfo_children():
        n = _scale(c, base, want_fam, reg, n)
    return n


def _parse_font(spec):
    """위젯의 글꼴 설정을 `(이름, 크기, 나머지)` 로. 못 읽으면 None.

    ⚠ Tk 는 `('Malgun Gothic', 9, 'bold')` 를 문자열 `'{Malgun Gothic} 9 bold'` 로
      돌려주기도 한다. **튜플만 다루면 절반을 놓친다.**
    ⚠ `TkDefaultFont` 같은 **이름 글꼴은 건드리지 않는다** — 그건 `apply_ui` 몫이고,
      여기서 크기를 박으면 이름 글꼴의 뜻이 사라진다.
    """
    try:
        parts = list(spec) if isinstance(spec, (list, tuple)) else str(spec).split()
    except Exception:
        return None
    if not parts:
        return None
    # '{Malgun Gothic} 9 bold' → 중괄호 묶음 복원
    if not isinstance(spec, (list, tuple)):
        s = str(spec)
        if s.startswith('{') and '}' in s:
            fam = s[1:s.index('}')]
            parts = [fam] + s[s.index('}') + 1:].split()
        elif len(parts) == 1:
            return None                    # 이름 글꼴(TkDefaultFont 등)
    fam = str(parts[0])
    if len(parts) < 2:
        return None
    try:
        size = int(parts[1])
    except (TypeError, ValueError):
        return None
    if size <= 0:                          # 음수는 픽셀 지정 — 손대지 않는다
        return None
    return fam, size, tuple(str(x) for x in parts[2:])


def reapply_all(db_path, root=None):
    """등록된 위젯 전부에 다시 입힌다. **설정이 바뀔 때 이것 하나만 부르면 된다.**

    ⚠ 이름 붙은 글꼴(UI)과 `ttk.Style`(목록·표)도 여기서 함께 갱신한다 —
      따로 부르게 두면 **그 둘만 안 따라오는** 일이 또 생긴다.
    """
    apply_ui(db_path, root)
    refresh_list_styles(db_path)     # 표준 목록 트리 스타일 일괄 갱신 (2026-08-18)
    live = []
    for ref, scope, script, delta in _registry:
        w = ref()
        if w is None:
            continue
        try:
            if not w.winfo_exists():
                continue
        except Exception:
            continue
        apply(w, db_path, scope, script, delta)
        live.append((ref, scope, script, delta))
    _registry[:] = live
    # ★ **자기 갱신 함수를 가진 위젯도 여기서 부른다** (2026-08-13).
    #   `VerseTextList` 는 글꼴이 바뀌면 절 번호 탭 폭까지 다시 잡아야 해서
    #   `apply_font()` 를 따로 갖고 있다. 그걸 여기서 안 부르면 **P1 본문만
    #   안 따라온다** — 실측에서 실제로 그랬다(다른 화면은 21pt, P1 만 11pt).
    #   ⚠ 호출부가 따로 부르게 두면 **또 두 경로가 된다.**
    if root is not None:
        _poke(root)
    return len(live)


def list_style(style_name, db_path, heading=True, indent=8, delta=0):
    """★ **표준 목록 트리 스타일 — 단일 소스** (2026-08-18 사용자 지시
    「계속 표준 서식 따르도록 수정했는데 왜 이런 일이 생기는지 모르겠다」).

    지금까지 표준(「목록」 역할 글꼴 · 행높이 size×2.2 · indent 8)이 **규칙으로만
    있고 코드로는 없어서**, 화면마다 손으로 베끼다 빠뜨렸다 — 실측(2026-08-18):
    Plan·Lens 는 표준(11pt/24px), Reading·EB·Peri·Links 는 만들 때 박힌
    9pt/22px 그대로. **트리를 만들 때와 `apply_font` 에서 이것 하나만 부른다.**
    글꼴 튜플을 돌려주므로 태그 글꼴(`tag_configure`)에 그대로 쓴다.

    ⚠ 지연 빌드 화면은 시작 시 `reapply_all` 이후에 만들어진다 — 생성부에서
      부르지 않으면 하드코딩 값이 화면에 남는다(빌드 때 + apply_font 둘 다).
    """
    from tkinter import ttk as _ttk
    if not db_path:
        import appdb as _appdb
        db_path = _appdb.MAIN_DB
    d = resolve(db_path, 'list')
    fam = d.get('family') or ''
    size = int(d.get('size') or 11)
    # ★ `delta` = **기준에서 몇 단계**(절대 크기를 적지 않는다). 빽빽한 관리자
    #   목록이 −1·−2 를 쓴다 — 환경설정에서 글꼴을 바꾸면 함께 따라온다.
    size = max(7, size + int(delta or 0))
    f = (fam, size)
    st = _ttk.Style()
    st.configure(style_name, font=f, rowheight=int(size * 2.2), indent=indent)
    if heading:
        st.configure(style_name + '.Heading', font=f)
    # ★ 만든 스타일을 기억해 둔다 — `reapply_all` 이 전부 자동 갱신하므로
    #   화면마다 apply_font 를 만들 필요가 없다(태그에 글꼴을 얹는 화면만 필요).
    _list_styles[style_name] = (db_path, heading, indent, int(delta or 0))
    return f


_list_styles: dict = {}     # style_name → (db_path, heading, indent, delta)


def refresh_list_styles(db_path=None):
    """`list_style` 로 만든 모든 표준 트리 스타일을 현재 설정으로 다시 입힌다."""
    for name, v in list(_list_styles.items()):
        db0, heading, indent = v[0], v[1], v[2]
        delta = v[3] if len(v) > 3 else 0
        try:
            list_style(name, db_path or db0, heading=heading, indent=indent,
                       delta=delta)
        except Exception:
            pass


def _poke(w, seen=None):
    """`apply_font()` 를 스스로 가진 위젯을 찾아 불러 준다."""
    fn = getattr(w, 'apply_font', None)
    if callable(fn):
        try:
            fn()
        except Exception:
            pass
    for c in getattr(w, 'winfo_children', lambda: [])():
        _poke(c)


def registered_count():
    return len(_registry)


def set_if_changed(widget, **opts):
    """값이 **실제로 달라졌을 때만** 위젯에 넣는다. 바꾼 항목 수를 돌려준다.

    ★ 같은 값이어도 `config` 를 부르면 Tk 가 그 위젯을 다시 그린다. 본문처럼 넓은
      위젯은 그 한 번이 **깜빡임**으로 보인다(2026-08-13 사용자 지적
      「클릭할 때마다 P1 구절본문 글자가 흔들린다」).
    ⚠ 「같은 값이니 어차피 무해하다」가 아니다 — **다시 그리는 것 자체가 보인다.**
    """
    chg = {}
    for k, v in opts.items():
        try:
            cur = widget.cget(k)
            if k == 'font':
                # ⚠ **글꼴은 글자로 비교하면 안 된다.** Tk 는 `('맑은 고딕', 11)` 을
                #   `'{맑은 고딕} 11'` 로 돌려주어 **늘 다르게** 보인다 —
                #   그래서 값이 같아도 매번 다시 그렸다(2026-08-13 실측).
                import tkinter.font as _tkf
                if _tkf.Font(widget, font=cur).actual() ==                         _tkf.Font(widget, font=v).actual():
                    continue
                chg[k] = v
                continue
            if str(cur) != str(v):
                chg[k] = v
        except Exception:
            chg[k] = v
    if chg:
        try:
            widget.config(**chg)
        except Exception:
            return 0
    return len(chg)


MANAGED = '_hagah_managed'      # 역할이 관리하는 위젯 — `scale()` 이 건드리면 안 된다
FG_OWNED = '_hagah_fg_owned'    # ★ **글자색을 폰트 쪽이 정한 위젯** — 테마가 덮으면 안 된다


def apply(widget, db_path, scope='base', script='ko', size_delta=0):
    """위젯 종류를 스스로 보고 맞는 항목만 넣는다.

    ⚠ `Text` 계열에만 간격 옵션이 있다. `Label`·`Button` 에 주면 `TclError` 가 난다.
    """
    if widget is None:
        return
    try:
        if not widget.winfo_exists():
            return
    except Exception:
        return
    try:
        d = resolve(db_path, scope, script)
        font = (d['family'], max(7, int(d['size']) + size_delta)) if d['family'] \
            else ('', max(7, int(d['size']) + size_delta))
        opts = {'font': font}
        # ★ 글자색 — **언제나 정한다.** 고른 색이 있으면 그것을, 없으면 테마 색을.
        # ⚠ 예전에는 「있을 때만」 넣었다. 그러면 **색을 비워도 옛 색이 그대로 남는다**
        #   (2026-08-14 사용자 지적 「원복해도 화면에 반응이 없다」).
        #   되돌릴 값을 안 주면 되돌아갈 길이 없다 — 비었을 때도 값을 준다.
        _col = d.get('color')
        if not _col:
            try:
                import ui_theme
                _col = ui_theme.C('fg')
            except Exception:
                _col = ''
        if _col:
            opts['fg'] = _col
            # ★ **테마가 이 글자색을 덮지 못하게 표시한다** (2026-08-14).
            #   ⚠ `ui_theme.paint` 는 색표를 보고 번역하는데, 사용자가 고른 색이
            #     하필 표에 있는 색이면(`#8E44AD` 는 강조색으로 등록돼 있었다)
            #     **누르자마자 딴 색으로 덮였다** — 「아예 반영이 안된다」의 정체다.
            try:
                setattr(widget, FG_OWNED, bool(d.get('color')))
            except Exception:
                pass
        cls = widget.winfo_class()
        if cls == 'Text':
            # ⚠ 예전에는 줄간격(`spacing2`)을 **성경 본문에만** 넣었다. 옛 판단
            #   「설명문은 문단이 길어 줄 사이까지 벌리면 성겨진다」를 그대로 옮긴 것인데,
            #   **설정 화면에 있는 값이 안 먹으면 그건 결함이다**(2026-08-13 사용자 지적).
            #   ⇒ 모든 구역에 넣는다. 성기게 보이는 것은 기본값을 낮게 두어 다룬다.
            # ★ **문단간격은 위(spacing1)에만 — 1:1** (2026-08-17 사용자 지시).
            #   예전에는 spacing3 에도 같은 값을 넣어 **엔터 한 번에 두 배**(6+6=12px)
            #   가 걸렸다 — 「Font 로 조절하면 간격이 너무 커진다」의 theme_font 쪽
            #   원인. 이제 저장값 그대로 한 번만 걸린다(도서/설교·P2 설명·주석 등
            #   등록된 모든 읽기 화면이 함께 바뀐다).
            opts.update(spacing1=d['para_gap'], spacing3=0,
                        spacing2=d['line_gap'], padx=d['margin'])
        set_if_changed(widget, **opts)      # 값이 그대로면 안 건드린다(깜빡임 방지)
        # 역할이 관리한다는 표시 — `scale()` 이 이 위젯을 건드리지 않는다
        try:
            setattr(widget, MANAGED, True)
        except Exception:
            pass
    except Exception:
        pass


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _selftest():
    import tempfile
    bad = []
    db = os.path.join(tempfile.gettempdir(), '_tf_selftest.db')
    if os.path.exists(db):
        os.remove(db)
    c = sqlite3.connect(db)
    c.execute("CREATE TABLE user_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
    c.commit(); c.close()

    # ① 비어 있으면 base 를 따른다
    save(db, 'base', family='Georgia', size=12)
    if resolve(db, 'bible')['size'] != 12:
        bad.append('빈 구역이 base 를 안 따른다')

    # ② 구역 값이 base 를 덮는다 — 지정한 항목만
    # ⚠ **선택 적용 모드에서만** 그렇다. 전체 적용이면 역할 값은 무시된다(⑬).
    set_mode(db, MODE_EACH)
    save(db, 'bible', size=16)
    r = resolve(db, 'bible')
    if r['size'] != 16:
        bad.append('구역 값이 base 를 못 덮는다')
    if r['line_gap'] != resolve(db, 'base')['line_gap']:
        bad.append('덮지 않은 항목까지 바뀌었다')

    # ③ base 를 바꿔도 덮어 둔 항목은 유지, 나머지는 따라온다
    save(db, 'base', size=9, line_gap=7)
    r = resolve(db, 'bible')
    if r['size'] != 16:
        bad.append('구역 값이 base 변경에 밀렸다')
    if r['line_gap'] != 7:
        bad.append('덮지 않은 항목이 base 를 안 따라왔다')

    # ④ clear = 기본으로 되돌리기 (이것이 없으면 통일→개별수정이 깨진다)
    clear(db, 'bible')
    if resolve(db, 'bible')['size'] != 9:
        bad.append('clear 가 기본으로 되돌리지 못한다')
    if not is_default(db, 'bible'):
        bad.append('is_default 가 틀렸다')

    # ⑤ None 은 그 항목만 지운다
    save(db, 'prose', size=20, margin=30)
    save(db, 'prose', size=None)
    d = load(db)['font']['prose']
    if 'size' in d or d.get('margin') != 30:
        bad.append('None 이 그 항목만 지우지 못한다')

    # ⑬ ★★ **두 영역은 배타적이다** (2026-08-13 사용자 설계)
    #    「전체 적용에서 폰트를 수정하면 선택 적용 값이 자동으로 동일하게 따라 반영되고,
    #      선택 적용 값을 수정하면 선택 적용만 작동한다」
    set_mode(db, MODE_EACH)
    save(db, 'base', size=11)
    save(db, 'bible', size=20)
    if resolve(db, 'bible')['size'] != 20:
        bad.append('선택 적용인데 역할 값이 안 쓰인다')
    set_mode(db, MODE_ALL)
    if resolve(db, 'bible')['size'] != 11:
        bad.append('전체 적용인데 역할 값이 아직 이긴다')
    for sc in SCOPES:
        if resolve(db, sc)['size'] != 11:
            bad.append(f'전체 적용인데 {sc} 가 따라오지 않는다')
    # ★ **모드를 바꿔도 값은 지우지 않는다** — 지우면 돌아올 때 잃는다
    set_mode(db, MODE_EACH)
    if resolve(db, 'bible')['size'] != 20:
        bad.append('전체 적용을 거쳤더니 역할 값이 사라졌다')
    set_mode(db, MODE_ALL)
    clear(db, 'bible')

    # ⑤-2 ★ **옛 구역 이름이 새 역할로 이어지는가** (2026-08-13 역할화)
    #      화면 코드가 아직 `'desc'`·`'ref'`·`'book'` 으로 부른다. 여기가 끊기면
    #      그 화면들의 폰트가 **조용히 base 로 떨어진다.**
    set_mode(db, MODE_EACH)
    clear(db, 'prose')
    save(db, 'desc', size=17)
    if resolve(db, 'ref')['size'] != 17:
        bad.append("옛 이름 desc→ref 가 같은 역할(prose)로 안 모인다")
    if resolve(db, 'book')['size'] != 17:
        bad.append("옛 이름 book 이 prose 로 안 모인다")
    if load(db)['font'].get('desc'):
        bad.append('옛 이름으로 저장되어 새 역할과 갈라졌다')
    clear(db, 'prose')
    if resolve(db, 'desc')['size'] == 17:
        bad.append('옛 이름으로 부른 clear 가 안 먹는다')

    # ⑤-3 ★ 글꼴 설정 읽기 — **다섯 형태를 다 받아야 한다**
    #      ⚠ Tk 는 `('Malgun Gothic', 9, 'bold')` 를 문자열로 돌려주기도 한다.
    #        튜플만 다루면 절반을 놓쳐 그 위젯들이 조용히 안 따라온다.
    for spec, want in (
            (('Malgun Gothic', 9, 'bold'), ('Malgun Gothic', 9, ('bold',))),
            (('Malgun Gothic', 9), ('Malgun Gothic', 9, ())),
            ('{Malgun Gothic} 9 bold', ('Malgun Gothic', 9, ('bold',))),
            ('Arial 8 italic', ('Arial', 8, ('italic',))),
            ('TkDefaultFont', None),          # 이름 글꼴 — 건드리지 않는다
            (('Arial', -11), None)):          # 음수 = 픽셀 지정 — 건드리지 않는다
        if _parse_font(spec) != want:
            bad.append(f'글꼴 설정을 잘못 읽는다: {spec!r} → {_parse_font(spec)!r}')

    # ⑤-4 ★ 크기를 **단계**로 옮기는가 (base 를 바꾸면 위계를 지킨 채 따라온다)
    class _W:
        def __init__(self, f, kids=()):
            self._f = f
            self._kids = kids

        def cget(self, o):
            return self._f

        def configure(self, **kw):
            self._f = kw['font']

        def winfo_children(self):
            return self._kids

    save(db, 'base', size=10)
    w8 = _W(('Malgun Gothic', 8))
    w12 = _W(('Malgun Gothic', 12, 'bold'))
    root = _W(('Malgun Gothic', 10), (w8, w12))
    scale(root, db)
    if (w8._f[1], w12._f[1]) != (8, 12):
        bad.append('base 가 기준값일 때 크기가 달라졌다')
    save(db, 'base', size=14)               # 기본을 +4 키운다
    scale(root, db)
    if w8._f[1] != 12 or w12._f[1] != 16:
        bad.append(f'단계가 안 지켜졌다: 8→{w8._f[1]} · 12→{w12._f[1]} (기대 12·16)')
    if w12._f[2:] != ('bold',):
        bad.append('굵기가 사라졌다')
    save(db, 'base', size=10)               # 되돌리면 원래 크기로
    scale(root, db)
    if (w8._f[1], w12._f[1]) != (8, 12):
        bad.append('base 를 되돌렸는데 원래 크기로 안 돌아온다')

    # ⑤-b **글꼴 이름**도 따라와야 한다 (2026-08-14 — 사용자 지적
    #      「글자 사이즈 등이 작동하지 않는다」. 그전까지 크기만 바꿨다).
    #  ⚠ 크기와 달리 **위계가 없다** — 지정하면 전부 그 글꼴, 비우면 전부 원래대로.
    save(db, 'base', family='Consolas', size=10)
    scale(root, db)
    if (w8._f[0], w12._f[0]) != ('Consolas', 'Consolas'):
        bad.append(f'글꼴 이름이 안 따라온다: {w8._f[0]} · {w12._f[0]}')
    if (w8._f[1], w12._f[1]) != (8, 12):
        bad.append('글꼴만 바꿨는데 크기가 흔들렸다')
    save(db, 'base', family='', size=10)    # 비우면 화면이 정한 글꼴로 되돌아온다
    scale(root, db)
    if (w8._f[0], w12._f[0]) != ('Malgun Gothic', 'Malgun Gothic'):
        bad.append(f'글꼴을 비웠는데 원래로 안 돌아온다: {w8._f[0]}')
    # ⑤-c 「선택 적용」에서는 **UI 줄**이 화면 크롬을 통제한다
    set_mode(db, MODE_EACH)
    save(db, 'ui', family='Consolas', size=12)
    scale(root, db)
    if w8._f[0] != 'Consolas' or w8._f[1] != 10:
        bad.append(f'UI 줄이 크롬에 안 걸린다: {w8._f}')
    save(db, 'ui', family='', size=10)
    set_mode(db, MODE_ALL)
    scale(root, db)

    # ⑥ 범위를 벗어난 값은 잘린다
    save(db, 'base', size=999)
    if resolve(db, 'base')['size'] != LIMITS['size'][1]:
        bad.append('상한을 안 지킨다')

    # ⑦ 다크모드 자리를 지운다면 구조 설계가 깨진 것
    if 'dark' not in load(db):
        bad.append('dark 키가 사라졌다')

    # ⑧ 폰트 이름 해결 — 실측 ①의 재발 방지
    try:
        import tkinter as tk
        r0 = tk.Tk(); r0.withdraw()
        fams = families()
        got = resolve_family('Malgun Gothic', 'ko')
        if fams and got and got not in fams:
            bad.append('resolve_family 가 없는 폰트를 돌려준다')
        if fams and not resolve_family('__NoSuchFont__', 'ko') and \
                any(c in fams for c in PREFERRED['ko']):
            bad.append('없는 폰트를 후보로 대체하지 못한다')
        r0.destroy()
    except Exception:
        pass

    # ⑨ 패밀리명 파싱 — 깨지면 **조용히 폰트 목록이 줄어든다**
    #   (첫 구현이 파일명 대조라 히브리를 37개 중 4개만 찾았다. 오류도 안 났다.)
    #   ⚠ 「히브리 폰트가 N개 이상」 같은 검사는 PC 마다 달라 못 쓴다 — 파싱 자체를 본다.
    # ⑪ ★ **실제 앱이 넘기는 경로로 `user_config` 에 닿는가** (읽기만 — 데이터는 안 건드린다)
    #    ⚠ 이 검사가 없어서 2026-08-13 에 통째로 먹통이 됐다.
    #      앱은 `bible_master.db` 를 넘기는데 `user_config` 는 `user_data.db` 에 있어
    #      `sqlite3.connect` 로는 그 표가 없다. **설정 창의 [＋]를 눌러도 숫자조차
    #      안 바뀌었고 오류도 안 났다.** `appdb.connect` 가 ATTACH 해 주어야 한다.
    try:
        import appdb
        if os.path.exists(appdb.MAIN_DB):
            cc = _connect(appdb.MAIN_DB)
            try:
                cc.execute("SELECT 1 FROM user_config LIMIT 1").fetchone()
            except Exception:
                bad.append('앱 DB 경로에서 user_config 를 못 읽는다 — sqlite3 직접 연결 의심')
            finally:
                cc.close()
    except Exception:
        pass

    # ⑩ 번들 폰트가 스캔 대상에 들어 있는가
    #    ⚠ 시스템 폴더만 훑으면 **번들해 두고도 콤보에 못 올린다**(실제로 그랬다).
    #      「콥트 폰트가 N개」 같은 검사는 PC 마다 달라 못 쓴다 — **폴더가 스캔 목록에
    #      들어 있는지**를 본다.
    try:
        import glob as _g
        app = os.path.dirname(os.path.abspath(__file__))
        bd = os.path.join(app, BUNDLE_DIR)
        if os.path.isdir(bd) and _g.glob(os.path.join(bd, '*.tt*')):
            names = set()
            for p in _g.glob(os.path.join(bd, '*.tt*')):
                names |= set(_family_names(p))
            if names and families():
                found = any(n in (fonts_for(k) or []) for k in SCRIPTS for n in names)
                if not found:
                    bad.append('번들 폰트가 어느 문자체계 목록에도 없다')
    except Exception:
        pass

    #   ⚠ 표본을 아무 40개나 잡으면 안 된다 — Tk 목록에 없는 특수 폰트만 걸려
    #     멀쩡한데도 FAIL 이 난다(실제로 그랬다). **Windows 구성요소**를 표본으로 쓴다.
    try:
        probe = [f for f in ('arial.ttf', 'times.ttf', 'segoeui.ttf', 'malgun.ttf')
                 if os.path.exists(os.path.join(_font_dir(), f))]
        if probe:
            names = [n for f in probe for n in _family_names(os.path.join(_font_dir(), f))]
            if not names:
                bad.append('폰트 파일에서 패밀리명을 하나도 못 읽는다')
            elif families() and not (set(names) & families()):
                bad.append('읽어 낸 패밀리명이 Tk 목록과 하나도 안 겹친다')
    except Exception:
        pass

    os.remove(db)
    print('theme_font selftest: ' + ('OK' if not bad else 'FAIL'))
    for b in bad:
        print('  X', b)
    return 1 if bad else 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    if '--fonts' in sys.argv:
        import tkinter as tk
        r0 = tk.Tk(); r0.withdraw()
        for k, (label, _) in SCRIPTS.items():
            got = fonts_for(k)
            print(f'  {label:10s} {len(got):3d}개  ' + ', '.join(got[:6]))
        r0.destroy()
        sys.exit(0)
    print(__doc__)
