"""
ai_sent_view.py — 관리자 「AI 에게 보낸 글」 화면 (2026-10-13 신설 · AI 작업실 탭 · `--selftest`).

사용자 지시 — 「AI 에게 보내는 모든 자료가 관리자의 눈에 전부 다 보여지는지 철저히 점검하라. 하나도 빠지면 안된다」.
보내는 문 셋(`ai_client` · 제미나이 직접 · Claude)이 남긴 기록(`ai_sent_log`)을 **글자 그대로** 보인다.
· 위 띠: [새로 고치기] · 출처 거르개 · 찾기(보낸 글·받은 글·무엇) … 건수
· 왼쪽 목록: 때 · 출처 · 무엇 · 모델 · 글자 수 · 결과
· 오른쪽: 보낸 글 전부 / 받은 글 전부(위아래 · 읽기 전용 · 복사 가능)
⚠ 팝업 없음 · 단추는 위.
"""
import tkinter as tk
from tkinter import ttk

import ai_sent_log as SL

ALL = '(모든 출처)'


class SentView(ttk.Frame):
    def __init__(self, master, path=None, **kw):
        super().__init__(master, **kw)
        self._path = path
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        ttk.Button(bar, text='새로 고치기', command=self.reload).pack(side='left')
        ttk.Label(bar, text='출처').pack(side='left', padx=(10, 2))
        self._src = ttk.Combobox(bar, state='readonly', width=22, values=[ALL])
        self._src.set(ALL)
        self._src.pack(side='left')
        self._src.bind('<<ComboboxSelected>>', lambda _e: self.reload())
        ttk.Label(bar, text='찾기').pack(side='left', padx=(10, 2))
        self._q = tk.StringVar()
        e = ttk.Entry(bar, textvariable=self._q, width=24)
        e.pack(side='left')
        e.bind('<Return>', lambda _e: self.reload())
        self._cnt = ttk.Label(bar, text='', foreground='#7F8C8D')
        self._cnt.pack(side='left', padx=10)
        ttk.Label(self, foreground='#7F8C8D', wraplength=1100, justify='left',
                  text='AI 에게 실제로 나간 글을 글자 그대로 남깁니다(이 PC 에만 · 배포에 실리지 않습니다). '
                       '보내는 문은 셋입니다 — AI 작업실·용어 이름 제안·구절 연결 시험·문의 답변 초안(제미나이) · '
                       '찬양·용어 심사(제미나이 직접) · 문의 유사 질문·용어 심사(Claude).'
                  ).pack(fill='x', padx=6)
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=6)
        left = ttk.Frame(pw)
        pw.add(left, weight=2)
        cols = ('ts', 'src', 'ref', 'model', 'n', 'ok')
        self._tv = ttk.Treeview(left, columns=cols, show='headings', selectmode='browse')
        for k, t, w in (('ts', '때', 130), ('src', '출처', 120), ('ref', '무엇', 170), ('model', '모델', 130),
                        ('n', '글자', 60), ('ok', '결과', 70)):
            self._tv.heading(k, text=t)
            self._tv.column(k, width=w, anchor='w')
        sb = ttk.Scrollbar(left, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._show())
        right = ttk.PanedWindow(pw, orient='vertical')
        pw.add(right, weight=3)
        a = ttk.Frame(right)
        right.add(a, weight=3)
        self._h1 = ttk.Label(a, text='보낸 글 전부', font=('', 9, 'bold'))
        self._h1.pack(anchor='w')
        self._sent = tk.Text(a, wrap='word', height=14)
        s1 = ttk.Scrollbar(a, orient='vertical', command=self._sent.yview)
        self._sent.configure(yscrollcommand=s1.set)
        s1.pack(side='right', fill='y')
        self._sent.pack(fill='both', expand=True)
        b = ttk.Frame(right)
        right.add(b, weight=1)
        ttk.Label(b, text='받은 글', font=('', 9, 'bold')).pack(anchor='w')
        self._resp = tk.Text(b, wrap='word', height=6)
        self._resp.pack(fill='both', expand=True)
        for t in (self._sent, self._resp):
            t.bind('<Key>', self._ro)
        self.reload()

    @staticmethod
    def _ro(e):
        if (e.state & 0x4) and e.keysym.lower() in ('c', 'a'):
            return None
        if e.keysym in ('Up', 'Down', 'Left', 'Right', 'Home', 'End', 'Prior', 'Next'):
            return None
        return 'break'

    def reload(self):
        try:
            self._src.configure(values=[ALL] + SL.sources(self._path))
        except Exception:                                 # noqa: BLE001
            pass
        src = self._src.get()
        rows = SL.rows(500, None if src == ALL else src, (self._q.get() or '').strip() or None, self._path)
        self._tv.delete(*self._tv.get_children())
        for sid, ts, via, source, ref, model, n, ok, why in rows:
            self._tv.insert('', 'end', iid=str(sid), values=(
                (ts or '').replace('T', ' '), source or via, ref, model, n,
                '받음' if ok else ('못 받음' if ok == 0 else '')))
        self._cnt.config(text='%d건%s' % (len(rows), ' (최근 500건)' if len(rows) >= 500 else ''))
        kids = self._tv.get_children()
        if kids:
            self._tv.selection_set(kids[0])
        else:
            self._show()

    def _show(self):
        for t in (self._sent, self._resp):
            t.delete('1.0', 'end')
        sel = self._tv.selection()
        if not sel:
            self._sent.insert('end', '아직 보낸 기록이 없습니다.')
            return
        g = SL.get(int(sel[0]), self._path)
        if not g:
            return
        self._h1.config(text='보낸 글 전부 — #%d · %s · %s · %s · %s · %d자' % (
            g['sent_id'], (g['ts'] or '').replace('T', ' '), g['via'], g['source'] or '', g['model'] or '',
            len(g['prompt'] or '')))
        self._sent.insert('end', g['prompt'] or '')
        self._resp.insert('end', (g['response'] or '') if g['ok'] else '(못 받음) %s%s%s' % (
            g['why'] or '', chr(10), g['response'] or ''))


def selftest():
    import os
    import tempfile
    ok = []
    ck = lambda c, m: (ok.append(bool(c)), print(('PASS ' if c else 'FAIL ') + m))   # noqa: E731
    d = tempfile.mkdtemp()
    p = os.path.join(d, 's.db')
    with SL.tag('시험 출처', 'job 1 · item 1', job_id=1, item_id=1):
        SL.record('ai_client', '[역할] 시험' + chr(10) + '[재료]' + chr(10) + '본문 전부', model='m', ok=True,
                  response='답', path=p)
    SL.record('claude', 'claude 글', model='c', ok=False, why='시간 초과', source='문의 유사 질문(Claude)', path=p)
    r = tk.Tk()
    v = SentView(r, path=p)
    v.pack(fill='both', expand=True)
    r.update()
    ck(len(v._tv.get_children()) == 2, '목록에 둘')
    v._tv.selection_set(v._tv.get_children()[-1])
    r.update()
    v._show()
    ck(v._sent.get('1.0', 'end').strip() == '[역할] 시험' + chr(10) + '[재료]' + chr(10) + '본문 전부',
       '보낸 글을 글자 그대로 보인다')
    ck(v._resp.get('1.0', 'end').strip() == '답', '받은 글')
    v._src.set('문의 유사 질문(Claude)')
    v.reload()
    ck(len(v._tv.get_children()) == 1, '출처 거르개')
    r.destroy()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
