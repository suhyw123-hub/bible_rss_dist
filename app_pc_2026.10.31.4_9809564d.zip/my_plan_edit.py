# -*- coding: utf-8 -*-
"""my_plan_edit.py — 내 플랜 수정 창 (영구, 2026-10-14 신설 · docs/1.txt 87 1단계).

★ 사용자 확정(data.md Z-3l) — **주차는 없다.** 날을 끼우고 빼고 옮기면 뒤가 저절로 밀리고 당겨진다.
  주 제목 대신 **「구간 제목」** — 그 구간이 시작하는 날에 붙어 읽을 거리와 함께 움직인다.
★ 하루 칸 = 「읽을 곳」(한 줄에 하나 · `창 1:1-2:3` · `시 23` · 끝에 ` | 묵상 포인트`) · 구간 제목 · 질문.
★ 「글자」 칸 = 그날 성경 본문의 **공백을 뺀 글자 수**(모든 언어 같은 잣대 · 하루 분량을 눈으로 고르게).
  A4 한 장 ≈ 한국어 1,500자 / 영어·유럽어 약 3,000자 — 상한 옵션은 조립 마법사(2단계)에서.
★ 저장 · 내보내기는 `plan_share` 한 문 — 여기서 표를 직접 쓰지 않는다.
⚠ 단추는 위(§0) · 글꼴·색은 표준(`theme_font`·`ui_theme`).
"""
import json
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import appdb
import i18n
import plan_share as PS

T = i18n.t


def _version(lang):
    try:
        import db_cite_gate
        return db_cite_gate.VERSION_OF.get((lang or 'KO').upper()) or 'BSB'
    except Exception:
        return 'KRV' if (lang or 'KO').upper() == 'KO' else 'BSB'


def day_chars(conn, rows, version):
    """그날 읽을 곳의 본문 글자 수(공백 뺌)."""
    n = 0
    for r in rows:
        v = r.get('v') or []
        if not v:
            continue
        x = conn.execute("SELECT COALESCE(SUM(LENGTH(REPLACE(REPLACE(verse_text,' ',''),char(10),''))),0) "
                         "FROM bible_content WHERE version_code=? AND verse_id BETWEEN ? AND ?",
                         (version, int(v[0]), int(v[1] if len(v) > 1 else v[0]))).fetchone()[0]
        n += x or 0
    return n


class _Look:
    """「바꾼 것」 띠(plan_wizard.OpsStrip)에 줄 색·글꼴 — 테마 역할에서."""
    def __init__(self, db_path='bible_master.db'):
        from plan_wizard import C
        self.c_bg = C('bg', '#F4F7FA')
        self.c_fg = C('fg', '#2C3E50')
        self.c_dim = C('fg_dim', '#6B7B8C')
        self.c_acc = C('accent', '#1A5276')
        self.c_ondark = C('fg_on_dark', '#FFFFFF')
        self.c_ok = C('success_bg', '#E3F2E9')
        self.c_sel = C('select_bg', '#D6EAF8')
        fam, size = '', 10                      # 글꼴은 설정 글꼴(박지 않는다)
        try:
            import theme_font
            f = theme_font.resolve(db_path, 'ui')
            fam = theme_font.resolve_family(f.get('family') or 'Malgun Gothic')
            size = int(f.get('size') or 10)
        except Exception:
            pass
        self.f_bold = (fam, size, 'bold')
        self.f_small = (fam, max(8, size - 1))


class MyPlanEditor(tk.Toplevel):
    """내 플랜 하나를 수정한다. `on_saved(uid)` — 저장하면 부른다(트리 다시 그리기)."""

    def __init__(self, parent, db_path, user_plan_id, lang='KO', on_saved=None, source=None):
        """`source=('SYS'|'USER', id)` 이고 `user_plan_id` 가 없으면 **초안**이다 (2026-10-15 88-8 ·
        사용자 「수정하기 누르고 화면 내용을 수정한 후에 마음에 들 때 저장하면 그때 사용자 플랜이 저장」).
        그 플랜 내용을 이 창 안에만 불러온다 — DB 에는 [저장]을 누를 때 처음 생긴다(닫으면 아무것도 안 남는다)."""
        super().__init__(parent)
        self.db_path, self.uid, self.lang, self.on_saved = db_path, user_plan_id, (lang or 'KO').upper(), on_saved
        self._src = None if user_plan_id else source
        self.title(T('MPE_TITLE', '내 플랜 수정하기'))
        self.geometry('980x640')
        self._ver = _version(self.lang)
        kind, pid = ('USER', user_plan_id) if user_plan_id else tuple(source)
        with appdb.connect(db_path) as conn:
            self._days = PS.days_of(conn, kind, pid, self.lang)
            self._ptitle = PS.title_of(conn, kind, pid, self.lang)
            self._pdesc = PS.desc_of(conn, kind, pid, self.lang)
        if self._src:
            self._ptitle = self._ptitle + T('MPE_COPY_SUFFIX', ' (내 플랜)')
        self._cur = None
        self._dirty = False
        self._build()
        self._fill()
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        self.protocol('WM_DELETE_WINDOW', self._close)

    # ── 화면 ──
    def _build(self):
        top = tk.Frame(self)
        top.pack(fill='x', padx=8, pady=(8, 4))
        tk.Button(top, text=T('MPE_SAVE', '저장'), command=self._save, padx=10).pack(side='left')
        tk.Button(top, text=T('MPE_EXPORT', '파일로 내보내기'), command=self._export, padx=8).pack(side='left', padx=(6, 0))
        self._msg = tk.Label(top, text='', anchor='w')
        self._msg.pack(side='left', padx=12)
        tk.Button(top, text=T('COMMON_CLOSE', '닫기'), command=self._close, padx=8).pack(side='right')

        meta = tk.Frame(self)
        meta.pack(fill='x', padx=8)
        tk.Label(meta, text=T('MPE_NAME', '플랜 이름')).grid(row=0, column=0, sticky='w')
        self._name_v = tk.StringVar(value=self._ptitle)
        tk.Entry(meta, textvariable=self._name_v).grid(row=0, column=1, sticky='we', padx=(6, 0))
        tk.Label(meta, text=T('MPE_DESC', '설명')).grid(row=1, column=0, sticky='nw', pady=(4, 0))
        self._desc = tk.Text(meta, height=3, wrap='word')
        self._desc.grid(row=1, column=1, sticky='we', padx=(6, 0), pady=(4, 0))
        self._desc.insert('1.0', self._pdesc)
        self._desc.edit_modified(False)        # ⚠ 불러온 글을 「바뀜」으로 치지 않는다 — 안 바꾸고 닫아도 묻던 흠(2026-10-15)
        self._desc.bind('<<Modified>>', self._touch_meta)
        meta.columnconfigure(1, weight=1)

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=8)
        left = tk.Frame(pw)
        right = tk.Frame(pw)
        pw.add(left, weight=3)
        pw.add(right, weight=2)

        bar = tk.Frame(left)
        bar.pack(fill='x', pady=(0, 4))
        # ★ 2026-10-15 — 마법사와 같은 [다음 날과 합치기][둘로 나누기][↶ 되돌리기](plan_build 한 문 · 87-3 「페리코프 결합/분리」)
        for key, ko, fn in (('PW_MERGE', '다음 날과 합치기', self._merge), ('PW_SPLIT', '둘로 나누기', self._split),
                            ('PW_UNDO', '↶ 되돌리기', self._undo),
                            ('MPE_ADD', '날 추가', self._add), ('MPE_DEL', '날 지우기', self._del),
                            ('MPE_UP', '▲ 위로', lambda: self._move(-1)), ('MPE_DOWN', '▼ 아래로', lambda: self._move(1))):
            tk.Button(bar, text=T(key, ko), command=fn, padx=6).pack(side='left', padx=(0, 4))
        self._sum = tk.Label(bar, text='', anchor='e')
        self._sum.pack(side='right')
        # ★ 2026-10-15 — 합치기·나누기는 번호 붙은 「바꾼 것」(마법사와 같은 `OpsStrip`) · 되돌릴 것을 선택해야 되돌린다
        from plan_wizard import OpsStrip, CIRCLED, circled
        self._ops, self._op_no = [], 0
        self._circled = circled
        self._CIRCLED = CIRCLED
        self._strip = OpsStrip(left, _Look(self.db_path), on_pick=lambda _n: self._fill(keep=self._cur))
        self._strip.pack(fill='x', pady=(0, 4))

        wrap = tk.Frame(left)
        wrap.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._tv = ttk.Treeview(wrap, columns=('d', 'sec', 'refs', 'n'), show='headings', yscrollcommand=vsb.set)
        vsb.config(command=self._tv.yview)
        for c, ko, w in (('d', T('MPE_DAY', '일차'), 50), ('sec', T('MPE_SEC', '구간 제목'), 150),
                         ('refs', T('MPE_REFS', '읽을 곳'), 330), ('n', T('MPE_CHARS', '글자'), 70)):
            self._tv.heading(c, text=ko)
            self._tv.column(c, width=w, stretch=(c == 'refs'), anchor='e' if c == 'n' else 'w')
        lk = _Look(self.db_path)
        self._tv.tag_configure('op', background=lk.c_ok)
        self._tv.tag_configure('opsel', background=lk.c_sel)
        self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._pick())
        tk.Label(left, anchor='w', justify='left', wraplength=560,
                 text=T('MPE_CHARS_HINT', '글자 = 그날 성경 본문의 공백을 뺀 글자 수입니다. '
                                          'A4 한 장은 대략 한국어·중국어·일본어 1,500자, 영어·유럽어 3,000자(약 500낱말)입니다.')
                 ).pack(fill='x', pady=(4, 0))

        tk.Label(right, text=T('MPE_SEC', '구간 제목'), anchor='w').pack(fill='x')
        self._sec = tk.StringVar()
        tk.Entry(right, textvariable=self._sec).pack(fill='x')
        tk.Label(right, anchor='w', justify='left',
                 text=T('MPE_REFS_HINT', '읽을 곳 — 한 줄에 하나(창 1:1-2:3 · 시 23 · 요 3:16)\n'
                                         '묵상 포인트는 줄 끝에 「 | 」 다음에 적습니다')).pack(fill='x', pady=(8, 0))
        self._refs = tk.Text(right, height=8, wrap='none')
        self._refs.pack(fill='both', expand=True)
        tk.Label(right, text=T('MPE_Q', '묵상 질문'), anchor='w').pack(fill='x', pady=(8, 0))
        self._q = tk.Text(right, height=4, wrap='word')
        self._q.pack(fill='x')
        tk.Button(right, text=T('MPE_APPLY', '이 날에 적용'), command=self._apply, padx=8).pack(anchor='e', pady=(6, 0))
        try:
            import theme_font
            for w in (self._refs, self._q, self._desc):
                theme_font.register(w, self.db_path, 'prose')
        except Exception:
            pass

    def _touch_meta(self, _e=None):
        if self._desc.edit_modified():
            self._dirty = True
            self._desc.edit_modified(False)

    def _ref_line(self, r):
        return (r.get('ref') or '') + ((' | ' + r['f']) if r.get('f') else '')

    def _fill(self, keep=None):
        import plan_build as PB
        self._tv.delete(*self._tv.get_children())
        tot = 0
        cur = self._strip.selected()
        with appdb.connect(self.db_path) as conn:
            om = {}
            for op in self._ops:
                for k in PB.op_days(conn, self._days, op):
                    om.setdefault(k, []).append(op['no'])
            for i, dd in enumerate(self._days):
                n = day_chars(conn, dd.get('r') or [], self._ver)
                dd['_n'] = n
                tot += n
                nos = om.get(i, [])
                tags = ('opsel',) if cur in nos else (('op',) if nos else ())
                self._tv.insert('', 'end', iid=str(i), tags=tags,
                                values=('%d %s' % (i + 1, ' '.join(self._circled(k) for k in nos)), dd.get('sec') or '',
                                        ' · '.join(r.get('ref') or '' for r in dd.get('r') or []), '{:,}'.format(n)))
        avg = tot // len(self._days) if self._days else 0
        self._sum.config(text=T('MPE_SUM', '%d일 · 하루 평균 %s자') % (len(self._days), '{:,}'.format(avg)))
        self._strip.set(self._ops, cur)
        if keep is not None and str(keep) in self._tv.get_children():
            self._tv.selection_set(str(keep))
            self._tv.see(str(keep))

    def _pick(self):
        sel = self._tv.selection()
        if not sel:
            return
        self._cur = int(sel[0])
        nos = [ch for ch in str(self._tv.set(sel[0], 'd')) if ch in self._CIRCLED]
        if nos and self._strip.selected() != self._CIRCLED.index(nos[-1]) + 1:
            self._strip.select(self._CIRCLED.index(nos[-1]) + 1)
            self.after_idle(lambda k=self._cur: self._fill(keep=k))
        dd = self._days[self._cur]
        self._sec.set(dd.get('sec') or '')
        self._refs.delete('1.0', 'end')
        self._refs.insert('1.0', '\n'.join(self._ref_line(r) for r in dd.get('r') or []))
        self._q.delete('1.0', 'end')
        self._q.insert('1.0', dd.get('q') or '')

    def _apply(self):
        if self._cur is None:
            return
        rows, bad = [], []
        with appdb.connect(self.db_path) as conn:
            import scripture_ref_kr
            for ln in self._refs.get('1.0', 'end').split('\n'):
                ln = ln.strip()
                if not ln:
                    continue
                ref, _, f = ln.partition('|')
                a, b = scripture_ref_kr.resolve(conn, ref.strip())
                if a is None:
                    bad.append(ref.strip())
                    continue
                rows.append({'v': [a, b or a], 'ref': PS._ref(conn, a, b) or ref.strip(), 'f': f.strip()})
        if bad:
            self._say(T('MPE_BADREF', '못 읽은 곳: %s') % ', '.join(bad), True)
            return
        if not rows:
            self._say(T('MPE_NOREF', '읽을 곳이 비었습니다 — 날을 지우려면 [날 지우기]'), True)
            return
        dd = self._days[self._cur]
        dd['r'], dd['sec'], dd['q'] = rows, self._sec.get().strip(), self._q.get('1.0', 'end').strip()
        self._dirty = True
        self._fill(keep=self._cur)
        self._say(T('MPE_APPLIED', '%d일차에 적용했습니다 — [저장]을 눌러야 남습니다') % (self._cur + 1))

    def _merge(self):
        import plan_build as PB
        import plan_share as PS2
        if self._cur is None:
            return
        i = self._cur
        with appdb.connect(self.db_path) as conn:
            if i + 1 >= len(self._days):
                self._say(T('PW_LASTDAY', '마지막 날은 다음 날이 없어 합칠 수 없습니다'), True)
                return
            a, b = PB.span(self._days[i]), PB.span(self._days[i + 1])
            nd, op = PB.do_merge(conn, [dict(d) for d in self._days], i)
            if nd is None:
                self._say(T('PW_LASTDAY', '마지막 날은 다음 날이 없어 합칠 수 없습니다'), True)
                return
            text = T('PW_OP_MERGE', '＋ %s · %s 합침') % (PS2._ref(conn, a[0], a[1]), PS2._ref(conn, b[0], b[1]))
        self._op_no += 1
        op.update(no=self._op_no, text=text)
        self._ops.append(op)
        self._days, self._dirty = nd, True
        self._fill(keep=i)
        self._pick()
        self._say(T('MPE_DID', '%s 번으로 적어 두었습니다 — [저장]을 눌러야 남습니다 · 되돌리려면 그 번호를 선택하고 [↶ 되돌리기]')
                  % self._circled(op['no']))

    def _split(self):
        import plan_build as PB
        if self._cur is None:
            return
        i = self._cur
        with appdb.connect(self.db_path) as conn:
            nd, op, info = PB.do_split(conn, self._ver, [dict(d) for d in self._days], i)
            if nd is None:
                self._say(T('PW_NOSPLIT', '이 날은 한 절뿐이라 나눌 수 없습니다'), True)
                return
            text = T('PW_OP_SPLIT', '✂ %s 뒤에서 나눔 (%s자 + %s자)') % (
                PB.ref_of(conn, info[0]), '{:,}'.format(info[1]), '{:,}'.format(info[2]))
        self._op_no += 1
        op.update(no=self._op_no, text=text)
        self._ops.append(op)
        self._days, self._dirty = nd, True
        self._fill(keep=i)
        self._pick()
        self._say(T('MPE_DID', '%s 번으로 적어 두었습니다 — [저장]을 눌러야 남습니다 · 되돌리려면 그 번호를 선택하고 [↶ 되돌리기]')
                  % self._circled(op['no']))

    def _undo(self):
        import plan_build as PB
        no = self._strip.selected()
        op = next((o for o in self._ops if o['no'] == no), None) if no else None
        if op is None:
            self._say(T('PW_UNDO_PICK', '되돌릴 것을 먼저 선택하세요 — 「바꾼 것」의 번호를 누르거나, 표에서 번호가 붙은 날을 선택하세요'), True)
            return
        with appdb.connect(self.db_path) as conn:
            nd = PB.undo_op(conn, self._ver, [dict(d) for d in self._days], op)
        if nd is None:
            self._say(T('PW_UNDO_NO', '%s 은(는) 뒤에 바꾼 것과 겹쳐 되돌릴 수 없습니다 — 겹친 번호를 먼저 되돌리세요')
                      % self._circled(no), True)
            return
        self._ops.remove(op)
        self._strip.select(None)
        self._days, self._dirty = nd, True
        self._fill(keep=self._cur)
        self._say(T('PW_UNDONE2', '%s 을(를) 되돌렸습니다') % self._circled(no))

    def _add(self):
        i = (self._cur + 1) if self._cur is not None else len(self._days)
        last = self._days[i - 1]['r'][-1] if i > 0 and self._days[i - 1].get('r') else None
        self._days.insert(i, {'d': 0, 'r': [dict(last)] if last else []})
        self._dirty = True
        self._fill(keep=i)
        self._pick()

    def _del(self):
        if self._cur is None or len(self._days) <= 1:
            return
        self._days.pop(self._cur)
        self._dirty = True
        self._fill(keep=min(self._cur, len(self._days) - 1))
        self._pick()

    def _move(self, d):
        i = self._cur
        if i is None or not (0 <= i + d < len(self._days)):
            return
        self._days[i], self._days[i + d] = self._days[i + d], self._days[i]
        self._dirty = True
        self._fill(keep=i + d)
        self._pick()

    def _say(self, msg, warn=False):
        self._msg.config(text=msg, fg='#C0392B' if warn else '#1A5276')

    def _save(self):
        name = self._name_v.get().strip()
        if not name:
            self._say(T('MPE_NONAME', '플랜 이름을 적으세요'), True)
            return
        try:
            import plan_builder
            name = plan_builder.check_plan_name(name, self)
        except Exception:
            pass
        if not name:
            return
        days = [dd for dd in self._days if dd.get('r')]
        try:
            with appdb.connect(self.db_path) as conn:
                if self._src:          # 초안 — 여기서 처음 내 플랜이 생긴다
                    self.uid = PS.save_copy(conn, self._src[0], self._src[1], name, days,
                                            desc=self._desc.get('1.0', 'end').strip(), lang=self.lang)
                    self._src = None
                else:
                    PS.save_plan(conn, name, days, desc=self._desc.get('1.0', 'end').strip(),
                                 lang=self.lang, uid=self.uid)
                conn.commit()
        except ValueError as e:
            self._say(str(e), True)
            return
        self._dirty = False
        self._say(T('MPE_SAVED', '저장했습니다'))
        if callable(self.on_saved):
            self.on_saved(self.uid)

    def _export(self):
        if self._dirty or not self.uid:
            self._save()
        if not self.uid:
            return
        export_dialog(self, self.db_path, user_plan_id=self.uid, lang=self.lang)

    def _close(self):
        if self._dirty and not messagebox.askyesno(T('MPE_TITLE', '내 플랜 수정하기'),
                                                   T('MPE_UNSAVED', '저장하지 않은 수정 내용이 있습니다. 닫을까요?'),
                                                   parent=self):
            return
        self.destroy()


def export_dialog(parent, db_path, plan_id=None, user_plan_id=None, lang='KO'):
    """파일로 내보내기 → 저장한 경로(없으면 None). 카카오톡·텔레그램 PC 판에 그 파일을 끌어 넣어 보낸다."""
    with appdb.connect(db_path) as conn:
        made_by = ''
        try:
            r = conn.execute("SELECT config_val FROM user_config WHERE config_key='SHARE_NAME'").fetchone()
            made_by = (r[0] or '').strip() if r else ''
        except Exception:
            pass
        d = PS.export_plan(conn, plan_id=plan_id, user_plan_id=user_plan_id, lang=lang, made_by=made_by)
    path = filedialog.asksaveasfilename(parent=parent, initialfile=PS.file_name(d.get('title')),
                                        defaultextension='.json',
                                        filetypes=[(T('MPE_FILETYPE', '하가 플랜 파일'), '*.json')])
    if not path:
        return None
    PS.write_file(path, d)
    messagebox.showinfo(T('MPE_EXPORT', '파일로 내보내기'),
                        T('MPE_EXPORTED', '저장했습니다.\n%s\n\n이 파일을 카카오톡·텔레그램 같은 메신저로 보내면, 받는 사람이 '
                                          '폰에서 [공유] ▸ 「+Hagah」로 열거나 PC 하가에서 [플랜 파일 가져오기]로 엽니다.') % path,
                        parent=parent)
    return path


def import_dialog(parent, db_path):
    """플랜 파일 가져오기 → 새로 생긴 user_plan_id 목록."""
    path = filedialog.askopenfilename(parent=parent, filetypes=[(T('MPE_FILETYPE', '하가 플랜 파일'), '*.json'),
                                                               ('*', '*.*')])
    if not path:
        return []
    try:
        draft = PS.read_file(path)
        with appdb.connect(db_path) as conn:
            res = PS.import_file(conn, draft)
    except Exception as e:
        messagebox.showerror(T('MPE_IMPORT', '플랜 파일 가져오기'), str(e), parent=parent)
        return []
    lines = []
    for st, _pid, msg, title in res:
        lab = {'NEW': T('MPE_ST_NEW', '내 플랜으로 담았습니다'), 'SAME': T('MPE_ST_SAME', '이미 받은 플랜입니다'),
               'SYS': T('MPE_ST_SYS', '앱에 있는 플랜입니다 — 그 플랜을 여세요'), 'BAD': msg}.get(st, st)
        lines.append('· %s — %s%s' % (title, lab, ('\n   ' + msg) if msg and st == 'NEW' else ''))
    messagebox.showinfo(T('MPE_IMPORT', '플랜 파일 가져오기'), '\n'.join(lines) or '-', parent=parent)
    return [pid for st, pid, _m, _t in res if st == 'NEW']
