# -*- coding: utf-8 -*-
"""db_worldview.py — **세계관·사조**를 주요용어 옆에 세운다
(영구 도구 · §0-5 KEEP · 2026-09-24 · 1.txt 15번 4단계).

사용자 요구(`docs/주요용어확장.txt`) — 「성경에 직접 등장하지 않으나 기독교와
관련한 용어, **기독교를 대적하는 사상들** … 이러한 사조에 대하여 **분별할 수
있는 성경구절을 연결**하고, 유투브 영상을 연결하고 싶다」.

★★★ **잣대 = 낱말이 아니라 자세(posture)다** (2026-09-24 사용자 교정 —
  「**포스트모더니즘이 성경에 나타날 것이라고 기대하면 안된다. 상대주의적
  가치관을 반영한 구절들이 많다** … 내 입은 나의 것이니 마음대로 떠들고
  거짓말을 하겠다는 시편 구절 … 이처럼 **확대 적용**하는 접근을 시도하라」).
  ⚠⚠ 내가 처음 잰 것은 「우리 글이 그 사조 **이름**을 말하는가」였고, 그
    잣대로는 현대 사조 스물아홉이 전부 0 이었다. **잣대가 틀렸다** —
    사조의 이름은 천 년마다 바뀌지만 그것이 딛고 선 사람의 자세는 그대로다.
  ✅ 자세로 찾으니 곧바로 나왔다:
      상대주의   시 12:4  「우리 입술은 우리 것이니 우리를 주관할 자 누구리요」
      상대주의   삿 17:6  「사람마다 자기 소견에 옳은 대로 행하였더라」
      종교다원   왕상 18:21「어느 때까지 두 사이에서 머뭇머뭇 하려느냐」
      종교다원   왕하 17:33「여호와도 경외하고 … 자기의 신들도 섬겼더라」
      유물론     사 22:13 「내일 죽으리니 먹고 마시자」

★★★ **논조 = 「이해 먼저, 답은 나란히」**(2026-09-24 사용자 확정).
    설명문은 **두 문단**이다 —
      ① 그 사조가 **무엇을 묻고 무엇을 주장하는지** 공정하게
      ② 성경이 그 물음에 **무엇이라 답하며 어디서 갈라지는지**
    ⚠ 첫 문단에 판정어(틀렸다·거짓·악하다)를 쓰지 않는다. 그것은 ②의 몫이고,
      물음을 먼저 공정히 들어야 갈라지는 자리가 실제로 보인다.
    ⚠ 교단 중립(§28-11)은 여기서도 그대로다.

★ **유형을 새로 둔 까닭** — `DOCTRINE` 50개는 「교회가 고백해 온 것」이고
  이것은 「교회가 분별해 온 것」이다. 한 단추에 섞으면 훑기 목록에서
  삼위일체와 포스트모더니즘이 나란히 선다(`entity_types.WORLDVIEW`).

⚠ **적재 문을 새로 짜지 않았다** — 표 이름·쓰는 모양을 `db_term_load` 에서
  그대로 빌려 온다(`EV_TABLE`·`_vid`·`_upsert_text`). 두 벌이 되면 한쪽만
  고쳐진다.

쓰는 법
    python db_worldview.py --selftest      ← 의무
    python db_worldview.py --check         구절 본문을 함께 찍는다(사람이 본다)
    python db_worldview.py --apply         멱등
    python db_worldview.py --undo
"""
from __future__ import annotations

import argparse
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb                                              # noqa: E402
import db_term_load as TL                                 # noqa: E402

ETYPE = 'WORLDVIEW'
MARK = 'WORLDVIEW_SEED'          # `--undo` 가 제 것만 지우는 표식
MIN_DESC = 120                   # 이보다 짧으면 「이해 먼저」가 안 된다
MAX_DESC = 900
MIN_WHY = 40                     # 「왜 이 구절인가」 한 줄로는 까닭이 안 선다
MAX_WHY = 400

#: ★★★ **구절의 성격** (1.txt 15번 4) — 사용자 「사조/사상과 관련하여 성경적
#:   대책/해법/분별/성숙을 위한 **권면의 구절 연결도 구분하여** 연결해서
#:   **묵상플랜을 만들어야** 한다」).
#:   `POSTURE` 그 사조의 자세가 **드러난** 구절 · `DISCERN` 성경의 **분별·권면**
#: ⚠⚠ **사조마다 둘 다 하나 이상**이라야 한다 — 진단만 늘어놓은 묵상은 사람을
#:   세우지 못하고, 답만 늘어놓으면 무엇에 대한 답인지 알 수 없다.
#: ⚠ 어휘는 `db_term_load.MEANING_KINDS` 가 단일 소스다(읽는 쪽이 그 목록으로
#:   좁힌다 — 등호로 좁히면 이 절들이 화면에서 조용히 사라진다).
KINDS = ('POSTURE', 'DISCERN')

#: 첫 문단에서 막는 판정어 — 그 자리는 「듣는」 자리다
_VERDICT = ('틀렸', '거짓', '악하다', '악한 사상', '사탄', '이단이다', '해롭')

#: 사조 — `code` 는 있으면 그 엔티티를 **끌어올린다**(중복을 안 만든다).
#: `posture` 는 화면에 안 쓰고 **왜 이 구절인가**를 사람이 검토할 때 쓴다.
SEED = [
  dict(code='T_ATHEISM', KO='무신론', EN='Atheism', era='근현대',
       posture='하나님이 계시지 않는다고 여기고, 그 전제 위에서 살아간다',
       desc_KO='무신론은 신이 존재한다는 증거가 충분하지 않다고 보고, '
               '세계를 신 없이 설명하려 합니다. 도덕도 의미도 사람이 '
               '스스로 세워야 한다고 말하며, 그래서 종교가 답해 온 '
               '물음들을 사람의 몫으로 되돌려 놓습니다.\n성경은 무신론을 '
               '논증의 결론이 아니라 마음의 자리로 다룹니다. 시편은 '
               '「마음에 이르기를 하나님이 없다」고 적어 생각보다 앞선 '
               '자리를 짚고, 로마서는 지으신 만물이 이미 말하고 있다고 '
               '합니다. 그래서 갈라지는 자리는 증거의 양이 아니라 그 '
               '증거를 어떻게 대하느냐입니다.',
       desc_EN='Atheism holds that there is not enough reason to believe '
               'God exists, and seeks to explain the world without him. '
               'Meaning and morality then become something people must '
               'build for themselves.\nScripture treats this less as a '
               'conclusion than as a posture of the heart: the psalmist '
               'writes that the fool "says in his heart, There is no God," '
               'and Romans says creation already speaks. The parting of '
               'ways is not the amount of evidence but what is done with '
               'it.',
       verses=[
         (('시', 10, 4), 'POSTURE',
          '악인이 「그 모든 사상에 하나님이 없다」고 말한다고 시인이 '
          '적습니다. 무신론이 논증의 결론이기 전에 생각이 자리 잡은 '
          '모양임을 보여 줍니다.',
          "The psalmist writes that in all the wicked man's thoughts "
          'there is no God, showing this as a settled posture before '
          'it is an argument.'),
         (('시', 14, 1), 'POSTURE',
          '「어리석은 자는 그 마음에 이르기를 하나님이 없다 '
          '하도다」라고 합니다. 부인이 머리보다 마음에서 먼저 '
          '말해진다고 봅니다.',
          'The fool says in his heart that there is no God. The '
          'denial is spoken in the heart before it is reasoned.'),
         (('롬', 1, 20), 'DISCERN',
          '지으신 만물에 하나님의 영원하신 능력과 신성이 이미 '
          '보인다고 바울은 말합니다. 그래서 갈라지는 자리는 증거의 '
          '양이 아니라 그 증거를 어떻게 대하느냐가 됩니다.',
          "Paul says God's eternal power and nature are already "
          'visible in what he has made, so the question becomes what '
          'is done with that evidence.'),
         (('히', 11, 6), 'DISCERN',
          '하나님께 나아가는 사람은 그가 계신 것을 믿어야 한다고 '
          '말합니다. 믿음이 증명의 끝이 아니라 나아감의 시작이라는 '
          '뜻입니다.',
          'Whoever comes to God must believe that he is. Faith is '
          'where the approach begins, not where proof ends.'),
       ]),
  dict(code='W_MATERIALISM', KO='유물론', EN='Materialism', era='근현대',
       posture='물질이 전부이고 죽으면 끝이니, 지금 누리는 것이 남는 '
               '전부다',
       desc_KO='유물론은 존재하는 것은 물질뿐이며 영혼이나 내세는 없다고 '
               '봅니다. 그래서 삶의 값어치를 지금 누리는 것에서 찾고, 죽음 '
               '뒤를 셈에 넣지 않는 쪽이 정직하다고 여깁니다.\n성경은 그 '
               '결론을 이미 알고 있습니다. 바울은 「죽은 자가 다시 살지 '
               '못할 것이면 내일 죽을 터이니 먹고 마시자」고 적어, 부활이 '
               '없다면 그 결론이 옳다는 것까지 인정합니다. 갈라지는 자리는 '
               '누리는 태도가 아니라 부활이 있느냐입니다.',
       desc_EN='Materialism holds that only matter exists, with no soul '
               'and no life beyond death. Value is therefore sought in '
               'what can be enjoyed now.\nScripture already knows this '
               'conclusion. Paul writes, "If the dead are not raised, let '
               'us eat and drink, for tomorrow we die" granting that the '
               'logic holds if there is no resurrection. The parting of '
               'ways is not enjoyment but whether the dead are raised.',
       verses=[
         (('사', 22, 13), 'POSTURE',
          '예루살렘 사람들이 「내일 죽으리니 먹고 마시자」 하며 '
          '잔치를 벌입니다. 죽음 뒤를 셈에 넣지 않을 때 사람이 실제로 '
          '내리는 결론입니다.',
          'In Jerusalem they feast saying that they will eat and '
          'drink, for tomorrow they die. It is what people actually '
          'conclude when death ends everything.'),
         (('고전', 15, 32), 'DISCERN',
          '바울은 죽은 자가 다시 살지 못한다면 그 결론이 옳다는 '
          '것까지 인정합니다. 갈라지는 자리가 태도가 아니라 부활임을 '
          '분명히 합니다.',
          'Paul grants that if the dead are not raised, that very '
          'conclusion follows. The parting of ways is the '
          'resurrection itself.'),
         (('눅', 12, 19), 'POSTURE',
          '부자가 「여러 해 쓸 물건을 많이 쌓아 두었으니 평안히 쉬고 '
          '먹고 마시고 즐거워하자」고 제 영혼에게 말합니다. 쌓은 것이 '
          '삶을 지켜 준다는 셈입니다.',
          'The rich man tells his own soul that his stored goods will '
          'buy years of ease. It is the reckoning that possessions '
          'keep a life safe.'),
         (('눅', 12, 20), 'DISCERN',
          '「오늘 밤에 네 영혼을 도로 찾으리니 그러면 네 예비한 것이 '
          '뉘 것이 되겠느냐」는 말씀이 그 셈이 빠뜨린 것을 짚습니다.',
          'This night your soul is required of you, and whose will '
          'your goods be. The question names exactly what that '
          'reckoning leaves out.'),
       ]),
  dict(code='W_SCIENTISM', KO='과학주의', EN='Scientism', era='근현대',
       posture='잴 수 있는 것만 참이고, 나머지는 알 수 없는 것으로 미뤄 '
               '둔다',
       desc_KO='과학주의는 과학의 방법으로 다룰 수 있는 것만을 참된 '
               '지식으로 여깁니다. 과학이 이룬 성과가 워낙 커서, 잴 수 '
               '없는 물음은 아직 못 푼 것이거나 물음 자체가 잘못된 '
               '것이라고 보게 됩니다.\n성경은 사람의 앎에 끝이 있다는 것을 '
               '다르게 말합니다. 하나님이 욥에게 「내가 땅의 기초를 놓을 '
               '때에 네가 어디 있었느냐」고 물으실 때, 그 물음은 앎을 '
               '낮추는 것이 아니라 앎이 어디에 서 있는지를 묻습니다. '
               '갈라지는 자리는 과학이 아니라 과학만이라는 말입니다.',
       desc_EN='Scientism treats what science can handle as the only real '
               'knowledge. Because science has achieved so much, questions '
               'it cannot measure come to look either unsolved or '
               'misconceived.\nScripture speaks of the limits of knowing '
               'differently. When God asks Job, "Where were you when I '
               'laid the foundations of the earth?", the question does not '
               'belittle knowledge but asks where it stands. The parting '
               'of ways is not science but only science.',
       verses=[
         (('욥', 38, 4), 'DISCERN',
          '하나님이 욥에게 「내가 땅의 기초를 놓을 때에 네가 어디 '
          '있었느냐」고 물으십니다. 앎을 낮추는 물음이 아니라 앎이 '
          '어디에 서 있는지를 묻는 물음입니다.',
          'God asks Job where he was when the foundations of the '
          'earth were laid. The question does not belittle knowing '
          'but asks where knowing stands.'),
         (('고전', 1, 20), 'DISCERN',
          '「하나님께서 이 세상의 지혜를 미련케 하신 것이 '
          '아니뇨」라고 바울이 묻습니다. 한 시대의 지혜가 마지막 '
          '잣대는 아니라는 말입니다.',
          'Paul asks whether God has not made the wisdom of this '
          "world foolish. An age's wisdom is not the final measure."),
         (('고전', 1, 21), 'POSTURE',
          '이 세상이 자기 지혜로는 하나님을 알지 못했다고 진단합니다. '
          '방법에 힘이 있다는 것과 그 방법이 닿지 못하는 자리가 '
          '있다는 것을 함께 말합니다.',
          'The world did not come to know God through its own wisdom. '
          'Method has real power, and it also has a reach.'),
         (('딤전', 6, 20), 'DISCERN',
          '바울은 디모데에게 「거짓되이 일컫는 지식」의 허한 말을 '
          '피하라고 당부합니다. 지식이라는 이름이 붙었다고 다 지식은 '
          '아니라는 뜻입니다.',
          'Paul tells Timothy to avoid the empty talk of what is '
          'falsely called knowledge. Not everything bearing the name '
          'is knowledge.'),
       ]),
  dict(code='W_RELATIVISM', KO='상대주의', EN='Relativism', era='근현대',
       posture='옳고 그름은 사람마다 다르니 나를 판단할 자가 없다',
       desc_KO='상대주의는 옳고 그름이 시대와 문화와 사람에 따라 '
               '달라진다고 봅니다. 하나의 기준을 모두에게 들이대면 억압이 '
               '된다는 경험이 이 생각을 떠받치고 있고, 그래서 판단을 '
               '삼가는 것이 예의라고 여깁니다.\n성경은 이 자세를 오래전에 '
               '문장으로 적어 두었습니다. 시편은 「우리 입술은 우리 것이니 '
               '우리를 주관할 자 누구리요」라 하고, 사사기는 「사람마다 '
               '자기 소견에 옳은 대로 행하였더라」로 한 시대를 요약합니다. '
               '갈라지는 자리는 관용이 아니라 기준이 사람 밖에 '
               '있느냐입니다.',
       desc_EN='Relativism holds that right and wrong shift with time, '
               'culture and person. The memory of one standard imposed on '
               'all supports it, so withholding judgment feels like '
               'courtesy.\nScripture put this posture into words long ago. '
               'The psalm says, "Our lips are our own; who is lord over '
               'us?", and Judges sums up an era: "everyone did what was '
               'right in his own eyes." The parting of ways is not '
               'tolerance but whether the standard stands outside us.',
       verses=[
         (('시', 12, 4), 'POSTURE',
          '「우리 입술은 우리 것이니 우리를 주관할 자 누구리요」라고 '
          '사람들이 말합니다. 상대주의의 자세가 그대로 한 문장이 된 '
          '자리입니다.',
          'Our lips are our own, and who is lord over us. Here the '
          'posture itself is put into a single sentence.'),
         (('삿', 17, 6), 'POSTURE',
          '「사람마다 자기 소견에 옳은 대로 행하였더라」가 사사 '
          '시대를 요약합니다. 기준이 사람 안으로 들어올 때 무슨 일이 '
          '일어나는지 보여 줍니다.',
          'Everyone did what was right in his own eyes. The sentence '
          'sums up the age of the judges and shows what follows when '
          'the standard moves inside.'),
         (('삿', 21, 25), 'POSTURE',
          '사사기가 마지막 절에서 같은 문장을 다시 적습니다. 되풀이해 '
          '적은 것이 그 시대를 보는 성경의 판단입니다.',
          'Judges repeats the same sentence in its closing verse, and '
          "the repetition is itself the book's verdict on that age."),
         (('사', 5, 20), 'DISCERN',
          '「악을 선하다 하며 선을 악하다 하며」 부르는 자들에게 화가 '
          '선포됩니다. 기준이 사람마다 달라지는 데서 한 걸음 더 '
          '나아가 뒤집히는 자리입니다.',
          'Woe is declared on those who call evil good and good evil, '
          'a step beyond shifting standards to standards inverted.'),
       ]),
  dict(code='W_POSTMODERN', KO='포스트모더니즘', EN='Postmodernism', era='현대',
       posture='큰 이야기는 힘의 산물이니, 진리 주장 앞에서 먼저 의심한다',
       desc_KO='포스트모더니즘은 세상을 통째로 설명하는 큰 이야기를 '
               '의심합니다. 그런 이야기가 흔히 힘 있는 쪽의 것이었다는 '
               '역사를 근거로 삼아, 진리라는 말 앞에서 누가 그렇게 '
               '말하는지를 먼저 묻습니다. 이 물음 자체는 성경도 낯설어하지 '
               '않습니다.\n다만 성경은 진리를 명제이기 전에 한 인격으로 '
               '내놓습니다. 빌라도가 「진리가 무엇이냐」고 물은 그 자리에 '
               '서 계신 분이 스스로 「내가 곧 진리」라 하셨습니다. '
               '갈라지는 자리는 의심의 정당함이 아니라, 의심 끝에 설 '
               '자리가 있느냐입니다.',
       desc_EN='Postmodernism distrusts grand narratives that explain '
               'everything, noting how often such stories belonged to the '
               'powerful. Before "truth" it asks who is speaking. '
               'Scripture is not a stranger to that question.\nYet '
               'Scripture offers truth as a person before a proposition. '
               'In the very place where Pilate asked "What is truth?", the '
               'one standing there had said, "I am the truth." The parting '
               'of ways is not whether suspicion is fair but whether there '
               'is anywhere to stand after it.',
       verses=[
         (('요', 18, 38), 'POSTURE',
          '빌라도가 「진리가 무엇이냐」고 묻습니다. 진리를 물으면서 '
          '정작 진리 앞에 서 있는 자리입니다.',
          'Pilate asks what truth is, standing at that very moment '
          'before the one who had said he is the truth.'),
         (('요', 14, 6), 'DISCERN',
          '예수께서 「내가 곧 길이요 진리요 생명이니」라고 하십니다. '
          '성경은 진리를 명제이기 전에 한 인격으로 내놓습니다.',
          'Jesus says that he is the way and the truth and the life. '
          'Scripture offers truth as a person before a proposition.'),
         (('벧후', 3, 4), 'POSTURE',
          '「만물이 처음 창조할 때와 같이 그냥 있다」는 말이 조롱으로 '
          '인용됩니다. 끝을 향해 가는 이야기 자체를 지워 버리는 '
          '자리입니다.',
          'Everything goes on as it has since the beginning, the '
          'scoffers say. The words erase the very idea of a story '
          'moving toward an end.'),
         (('딤후', 4, 3), 'POSTURE',
          '「귀가 가려워서 자기의 사욕을 좇을 스승을 많이 두고」라고 '
          '바울이 내다봅니다. 듣고 싶은 것이 잣대가 되는 때를 '
          '말합니다.',
          'Paul foresees people gathering teachers to suit their own '
          'desires, a time when what one wishes to hear becomes the '
          'measure.'),
       ]),
  dict(code='W_PLURALISM', KO='종교다원주의', EN='Religious pluralism', era='현대',
       posture='길은 여럿이니 어느 하나만 옳다고 말하지 않는다',
       desc_KO='종교다원주의는 여러 종교가 같은 실재를 저마다의 말로 '
               '가리킨다고 봅니다. 한 종교만 옳다는 주장이 낳은 다툼을 '
               '겪은 자리에서 나온 생각이고, 이웃을 존중하려는 마음이 그 '
               '바닥에 있습니다.\n성경에도 여러 신을 함께 섬기던 자리가 '
               '있습니다. 사마리아 사람들은 「여호와도 경외하고 … 자기의 '
               '신들도 섬겼」고, 엘리야는 「어느 때까지 두 사이에서 '
               '머뭇머뭇 하려느냐」고 물었습니다. 갈라지는 자리는 이웃을 '
               '어떻게 대하느냐가 아니라 구원이 누구에게 달렸느냐입니다.',
       desc_EN='Religious pluralism holds that many religions point to the '
               'same reality in their own words. It arose where exclusive '
               'claims bred conflict, and respect for neighbours lies '
               'beneath it.\nScripture also knows the place where many gods '
               'were served at once. The Samaritans "feared the LORD and '
               'served their own gods," and Elijah asked, "How long will '
               'you waver between two opinions?" The parting of ways is '
               'not how we treat neighbours but on whom salvation rests.',
       verses=[
         (('왕상', 18, 21), 'DISCERN',
          '엘리야가 「어느 때까지 두 사이에서 머뭇머뭇 하려느냐」고 '
          '백성에게 묻고, 백성은 한 말도 대답하지 못합니다.',
          'Elijah asks how long the people will waver between two '
          'opinions, and they answer him not a word.'),
         (('왕하', 17, 33), 'POSTURE',
          '사마리아 사람들이 「여호와도 경외하고 또한 자기의 신들도 '
          '섬겼더라」고 적혀 있습니다. 섞어 섬기는 일이 실제로 있었던 '
          '자리입니다.',
          'The Samaritans feared the LORD and served their own gods '
          'as well. Mixed worship is recorded here as an actual '
          'practice.'),
         (('요', 14, 6), 'DISCERN',
          '「나로 말미암지 않고는 아버지께로 올 자가 없느니라」는 '
          '말씀이 이 물음에 대한 성경의 대답입니다.',
          'No one comes to the Father except through him. This is the '
          'answer Scripture itself gives to the question.'),
         (('행', 4, 12), 'DISCERN',
          '「천하 인간에 구원을 얻을 만한 다른 이름을 우리에게 주신 '
          '일이 없음이니라」고 베드로가 말합니다. 갈라지는 자리가 '
          '이웃을 대하는 태도가 아니라 구원의 근거임을 보여 줍니다.',
          'Peter says there is no other name under heaven by which we '
          'must be saved, showing that the issue is the ground of '
          'salvation, not how we treat our neighbours.'),
       ]),
  dict(code='W_HUMANISM', KO='세속적 인본주의', EN='Secular humanism', era='근현대',
       posture='사람이 제 삶의 척도이니, 하늘에 매인 줄을 끊고 스스로 선다',
       desc_KO='세속적 인본주의는 사람의 존엄과 이성을 중심에 놓고, 신에게 '
               '기대지 않고도 좋은 삶과 좋은 사회를 세울 수 있다고 봅니다. '
               '사람을 높이 보려는 뜻이 그 안에 있고, 그래서 종교가 사람을 '
               '낮춘 역사에 대한 항의이기도 합니다.\n성경에도 사람이 제 '
               '이름을 내려 한 자리가 있습니다. 바벨에서 「우리 이름을 '
               '내고」라 했고, 시편은 「그 맨 것을 끊고 그 결박을 벗어 '
               '버리자」는 말을 옮깁니다. 성경 역시 사람을 높이 보지만 그 '
               '높음이 하나님의 형상에서 온다고 말합니다. 갈라지는 자리는 '
               '사람의 값어치가 아니라 그 값어치가 어디서 오느냐입니다.',
       desc_EN='Secular humanism places human dignity and reason at the '
               'centre, holding that a good life and a good society can be '
               'built without God. It means to honour people, and it '
               'protests a history in which religion belittled '
               'them.\nScripture also knows the place where people sought a '
               'name of their own. At Babel they said, "let us make a name '
               'for ourselves," and the psalm quotes, "Let us burst their '
               'bonds." Scripture too holds people high, but says the '
               'height comes from being made in God’s image. The parting '
               'of ways is not human worth but where that worth comes '
               'from.',
       verses=[
         (('창', 11, 4), 'POSTURE',
          '바벨에서 사람들이 「우리 이름을 내고」라고 말하며 성과 '
          '대를 쌓습니다. 사람이 스스로 이름을 세우려 한 첫 '
          '자리입니다.',
          'At Babel they build a city and a tower so as to make a '
          'name for themselves. It is the first place where people '
          'set out to make a name of their own.'),
         (('단', 4, 30), 'POSTURE',
          '느부갓네살이 「이 큰 바벨론은 내가 능력과 권세로 '
          '건설하여」라고 합니다. 이룬 것을 제 힘으로만 셈할 때의 '
          '말입니다.',
          'Nebuchadnezzar says he built great Babylon by his own '
          'power for his own glory, the speech of one who credits '
          'achievement to himself alone.'),
         (('렘', 17, 5), 'DISCERN',
          '「사람을 믿으며 혈육으로 그 권력을 삼고」 마음이 '
          '여호와에게서 떠난 사람이 저주를 받는다고 합니다. 사람을 '
          '높이는 일과 사람에게 기대는 일을 가릅니다.',
          'Cursed is the one who trusts in man and makes flesh his '
          'strength while his heart turns from the LORD. Honouring '
          'people and leaning on them are not the same thing.'),
         (('시', 2, 3), 'POSTURE',
          '「우리가 그 맨 것을 끊고 그 결박을 벗어 버리자」는 말이 '
          '인용됩니다. 하늘에 매인 줄을 끊는 것을 자유로 여기는 '
          '자세입니다.',
          'Let us burst their bonds and cast away their cords, they '
          'say. Freedom here means cutting every tie to heaven.'),
       ]),
  dict(code='W_NIHILISM', KO='허무주의', EN='Nihilism', era='근현대',
       posture='끝이 없으니 뜻도 없다 — 무엇을 해도 결국 같다',
       desc_KO='허무주의는 삶에 본래 주어진 뜻이 없다고 봅니다. 애써 세운 '
               '것도 시간이 다 지우고 마는 것을 정직하게 바라본 결과이고, '
               '값싼 위로를 거절한다는 점에서는 성실한 자리이기도 '
               '합니다.\n성경에는 그 정직함을 끝까지 밀고 간 책이 있습니다. '
               '전도서는 「헛되고 헛되며 … 모든 것이 헛되도다」로 시작해 '
               '「해 아래서 하는 일이 … 바람을 잡으려는 것」이라 말합니다. '
               '그러나 같은 책이 「일의 결국을 다 들었으니 하나님을 '
               '경외하고」로 닫습니다. 갈라지는 자리는 허무를 보았느냐가 '
               '아니라 그 너머에 누가 계시냐입니다.',
       desc_EN='Nihilism holds that life carries no given meaning. It is '
               'the honest result of watching time erase whatever we '
               'build, and in refusing cheap comfort it is a serious place '
               'to stand.\nScripture contains a book that pressed that '
               'honesty to the end. Ecclesiastes begins, "Vanity of '
               'vanities; all is vanity," and calls work under the sun "a '
               'chasing after wind." Yet the same book closes, "Fear God '
               'and keep his commandments." The parting of ways is not '
               'whether one has seen the emptiness but who stands beyond '
               'it.',
       verses=[
         (('전', 1, 2), 'POSTURE',
          '「헛되고 헛되며 헛되고 헛되니 모든 것이 헛되도다」로 '
          '전도서가 시작합니다. 성경 안에 허무를 끝까지 말하는 책이 '
          '있습니다.',
          'Ecclesiastes opens by calling everything vanity of '
          'vanities. Scripture contains a book that speaks the '
          'emptiness to the end.'),
         (('전', 2, 17), 'POSTURE',
          '해 아래서 하는 일이 「바람을 잡으려는 것」이라고 전도자가 '
          '적습니다. 애써 세운 것을 시간이 지운다는 사실을 정직하게 '
          '바라봅니다.',
          'The Preacher calls work under the sun a chasing after '
          'wind, looking honestly at how time erases what we build.'),
         (('고전', 15, 19), 'DISCERN',
          '「모든 사람 가운데 우리가 더욱 불쌍한 자리라」라고 바울이 '
          '말합니다. 소망이 없을 때의 셈을 바울도 똑같이 합니다.',
          'Paul says that if our hope is for this life only, we are '
          'of all people most to be pitied. He reckons the same way '
          'when hope is gone.'),
         (('전', 12, 13), 'DISCERN',
          '같은 책이 「하나님을 경외하고 그 명령을 지킬지어다」로 '
          '닫힙니다. 허무를 본 사람이 어디에 이르렀는지를 보여 '
          '줍니다.',
          'The same book closes by telling us to fear God and keep '
          'his commandments, showing where the one who saw the '
          'emptiness came to rest.'),
       ]),
  dict(code='W_NEWAGE', KO='뉴에이지', EN='New Age', era='현대',
       posture='내 안에 신성이 있으니, 숨은 지식과 수련으로 그것을 깨운다',
       desc_KO='뉴에이지는 사람 안에 신적인 것이 있고, 수련과 깨달음으로 '
               '그것을 깨울 수 있다고 봅니다. 여러 전통에서 마음에 드는 '
               '것을 선택해 엮고, 제도 종교의 딱딱함에 지친 사람에게 가까이 '
               '다가갑니다.\n성경은 이 약속이 처음 들린 자리를 기록합니다. '
               '「너희가 하나님과 같이 되어」라는 말이 동산에서 있었고, '
               '신명기는 점과 접신을 이스라엘에게 금합니다. 골로새서는 본 '
               '것을 의지해 과장하는 경건을 경계합니다. 갈라지는 자리는 '
               '영적인 것을 찾느냐가 아니라 사람이 신이 되느냐입니다.',
       desc_EN='The New Age holds that something divine lies within, to be '
               'awakened by practice and insight. It weaves together what '
               'it likes from many traditions and appeals to those weary '
               'of institutional religion.\nScripture records where this '
               'promise was first heard: "You will be like God," spoken in '
               'the garden. Deuteronomy forbids divining and consulting '
               'spirits, and Colossians warns of a piety puffed up by what '
               'it claims to have seen. The parting of ways is not seeking '
               'the spiritual but whether a human becomes divine.',
       verses=[
         (('창', 3, 5), 'POSTURE',
          '「너희가 그것을 먹는 날에는 너희 눈이 밝아 하나님과 같이 '
          '되어」라는 약속이 동산에서 처음 들립니다. 사람 안에 신적인 '
          '것이 열린다는 말의 첫 자리입니다.',
          'You will be like God, the promise says, and it is first '
          'heard in the garden. This is the earliest form of the '
          'claim that something divine can open up within.'),
         (('신', 18, 10), 'DISCERN',
          '복술과 길흉을 말하는 일과 요술을 이스라엘에게 금합니다. '
          '숨은 지식을 구하는 길을 이름을 들어 막습니다.',
          'Divination, omens and sorcery are forbidden to Israel, '
          'closing by name the paths that seek hidden knowledge.'),
         (('신', 18, 11), 'DISCERN',
          '「신접자나 박수나 초혼자를 너의 중에 용납하지 말라」고 '
          '이어서 말합니다. 영을 다루는 일을 따로 짚어 금합니다.',
          'Let no medium or spiritist or necromancer be found among '
          'you, the law continues, naming dealings with spirits '
          'separately.'),
         (('골', 2, 18), 'DISCERN',
          '「그 본 것을 의지하여 헛되이 과장하고」 있는 경건을 바울이 '
          '경계합니다. 체험을 근거로 스스로를 높이는 자리를 짚습니다.',
          'Paul warns of a piety puffed up by what it claims to have '
          'seen, marking the point where experience becomes '
          'self-exaltation.'),
       ]),
  dict(code='W_PROSPERITY', KO='번영복음', EN='Prosperity gospel', era='현대',
       posture='믿음은 건강과 부를 얻는 방법이고, 헌금은 그 투자다',
       desc_KO='번영복음은 하나님이 자녀의 형통을 원하신다는 참된 말에서 '
               '출발해, 믿음과 헌금을 건강과 부를 얻는 방법으로 이어 '
               '붙입니다. 가난과 병으로 지친 자리에서 이 말은 따뜻하게 '
               '들리고, 실제로 사람을 일으켜 세우기도 합니다.\n성경은 '
               '경건과 이익이 붙는 자리를 여러 번 짚습니다. 바울은 '
               '「경건을 이익의 재료로 생각하는 자들」을 말하고, 베드로는 '
               '성령의 권능을 돈으로 사려 한 사람에게 「네 은과 네가 함께 '
               '망할지어다」라 합니다. 갈라지는 자리는 하나님이 주시느냐가 '
               '아니라 주시는 분이 수단이 되느냐입니다.',
       desc_EN='The prosperity gospel begins from something true, that God '
               'cares for his children, and joins faith and giving to '
               'health and wealth as a method. To those worn down by '
               'poverty and illness it sounds warm, and it does lift '
               'people up.\nScripture repeatedly marks the place where '
               'godliness is fused to gain. Paul speaks of those "who '
               'think godliness is a means of gain," and Peter tells the '
               'man who would buy the Spirit, "May your silver perish with '
               'you." The parting of ways is not whether God gives but '
               'whether the giver becomes a means.',
       verses=[
         (('딤전', 6, 5), 'POSTURE',
          '「경건을 이익의 재료로 생각하는 자들」의 다툼을 바울이 '
          '말합니다. 경건과 이익이 붙는 자리를 이름을 들어 짚습니다.',
          'Paul speaks of those who think godliness is a means of '
          'gain, naming the place where piety is fused to profit.'),
         (('행', 8, 19), 'POSTURE',
          '시몬이 「이 권능을 내게도 주어」 달라며 돈을 내놓습니다. '
          '은사를 얻는 방법이 따로 있다고 여긴 자리입니다.',
          'Simon offers money and asks that this power be given to '
          'him too, treating the gift as something with a method for '
          'obtaining it.'),
         (('행', 8, 20), 'DISCERN',
          '베드로가 「네 은과 네가 함께 망할지어다」라고 답합니다. '
          '하나님의 선물을 값으로 셈하는 일을 그 자리에서 끊습니다.',
          'Peter answers that his silver perish with him, cutting off '
          "on the spot any reckoning of God's gift as a purchase."),
         (('미', 3, 11), 'POSTURE',
          '제사장이 삯을 위하여 교훈하고 선지자가 돈을 위하여 '
          '점치면서 오히려 여호와를 의뢰한다고 합니다. 섬김이 벌이가 '
          '된 자리를 미가가 고발합니다.',
          'Priests teach for hire and prophets divine for money, yet '
          'still lean on the LORD. Micah exposes the point where '
          'service has become income.'),
       ]),
  dict(code='W_GNOSTICISM', KO='영지주의', EN='Gnosticism', era='고대',
       posture='물질은 낮은 것이고 은밀한 앎을 얻은 사람만 건져진다',
       desc_KO='영지주의는 물질 세계를 낮은 것으로 보고, 소수에게 주어지는 '
               '은밀한 앎이 사람을 건져 낸다고 여겼습니다. 몸과 세상이 '
               '주는 고통을 설명하려는 시도였고, 깊은 것을 찾으려는 갈망이 '
               '그 안에 있었습니다.\n성경은 창조의 첫 장에서 지으신 모든 '
               '것을 보시고 심히 좋았다고 적습니다. 요한은 예수 '
               '그리스도께서 육체로 오신 것을 시인하느냐로 영을 분별하라 '
               '하고, 바울은 사람의 유전을 따르는 철학을 조심하라고 '
               '말합니다. 갈라지는 자리는 깊이를 구하는 마음이 아니라 몸과 '
               '물질을 무엇으로 보느냐입니다.',
       desc_EN='Gnosticism regarded the material world as a lower order '
               'and held that a hidden knowledge given to a few is what '
               'rescues a person. It tried to account for the pain of body '
               'and world, and a longing for depth lay within '
               'it.\nScripture says on its first page that God saw all he '
               'had made and it was very good. John tells us to test the '
               'spirits by whether they confess that Jesus Christ has come '
               'in the flesh, and Paul warns against a philosophy that '
               'follows human tradition. The parting of ways is not the '
               'desire for depth but what the body and matter are taken to '
               'be.',
       verses=[
         (('창', 1, 31), 'DISCERN',
          '하나님이 지으신 모든 것을 보시니 「보시기에 심히 '
          '좋았더라」고 첫 장이 적습니다. 물질을 낮게 보는 자리에서 '
          '성경은 정반대로 출발합니다.',
          'God saw everything he had made, and it was very good. '
          'Scripture starts from the opposite end of any low view of '
          'matter.'),
         (('요일', 4, 2), 'DISCERN',
          '「예수 그리스도께서 육체로 오신 것을 시인하는 영마다 '
          '하나님께 속한 것」이라고 요한이 잣대를 줍니다. 몸을 어떻게 '
          '보느냐가 분별의 자리가 됩니다.',
          'Every spirit that confesses Jesus Christ has come in the '
          'flesh is from God. How the body is regarded becomes the '
          'test.'),
         (('골', 2, 8), 'DISCERN',
          '「철학과 헛된 속임수로 너희를 노략할까 주의하라」고 바울이 '
          '말합니다. 사람의 유전과 세상의 초등 학문을 좇는 가르침을 '
          '가려내라는 뜻입니다.',
          'See to it that no one takes you captive by philosophy and '
          'empty deceit. Paul asks readers to sift teaching that '
          'follows human tradition.'),
         (('딤전', 4, 3), 'POSTURE',
          '혼인을 금하고 음식을 폐하라는 가르침을 두고 「식물은 '
          '하나님이 지으신 바」라고 바울이 답합니다. 몸을 낮추는 '
          '경건이 어디서 어긋나는지 보여 줍니다.',
          'Against those who forbid marriage and foods, Paul answers '
          'that God created them to be received with thanksgiving. It '
          'shows where a piety that demeans the body goes wrong.'),
       ]),
  dict(code='W_DOCETISM', KO='가현설', EN='Docetism', era='고대',
       posture='그리스도의 몸은 겉보기일 뿐이고 참으로 고난받지 않으셨다',
       desc_KO='가현설은 하나님이 참으로 사람의 몸을 입으셨다는 것을 '
               '받아들이기 어려워했습니다. 거룩하신 분이 태어나고 주리고 '
               '죽는 일을 감당하실 수 없다고 여겼고, 하나님을 높이려는 '
               '마음이 그 바탕에 있었습니다.\n성경은 그 자리에서 물러서지 '
               '않습니다. 요한은 말씀이 육신이 되어 우리 가운데 거하셨다고 '
               '적고, 부활하신 예수께서는 도마에게 손과 옆구리를 만져 보라 '
               '하십니다. 갈라지는 자리는 하나님을 높이려는 마음이 아니라 '
               '성육신을 실제로 보느냐입니다.',
       desc_EN='Docetism found it hard to accept that God truly took a '
               'human body. It judged that the Holy One could not be born, '
               'grow hungry and die, and a wish to honour God lay beneath '
               'it.\nScripture does not step back at that point. John '
               'writes that the Word became flesh and dwelt among us, and '
               'the risen Jesus tells Thomas to touch his hands and his '
               'side. The parting of ways is not reverence but whether the '
               'incarnation is taken as real.',
       verses=[
         (('요', 1, 14), 'DISCERN',
          '「말씀이 육신이 되어 우리 가운데 거하시매」라고 요한이 '
          '적습니다. 겉보기가 아니라 실제로 몸을 입으셨다는 '
          '선언입니다.',
          'The Word became flesh and dwelt among us. It is a '
          'declaration of a real body, not an appearance.'),
         (('요일', 4, 3), 'POSTURE',
          '「예수를 시인하지 아니하는 영마다 하나님께 속한 것이 '
          '아니니」라고 요한이 잘라 말합니다. 성육신을 부인하는 '
          '가르침이 그 시대에 실제로 있었음을 보여 줍니다.',
          'Every spirit that does not confess Jesus is not from God. '
          'The warning shows such teaching was actually present in '
          'that age.'),
         (('눅', 24, 39), 'DISCERN',
          '「영은 살과 뼈가 없으되 너희 보는 바와 같이 나는 '
          '있느니라」고 하십니다. 부활하신 몸이 환영이 아님을 스스로 '
          '밝히십니다.',
          'A spirit does not have flesh and bones as you see that I '
          'have. The risen Lord himself rules out a phantom.'),
         (('요', 20, 27), 'DISCERN',
          '도마에게 「네 손가락을 이리 내밀어 내 손을 보고」라고 '
          '하십니다. 의심하는 사람에게 만져 보라고 내어 주시는 '
          '자리입니다.',
          'Put your finger here and see my hands, he says to Thomas, '
          'offering himself to be touched by a doubting man.'),
       ]),
  dict(code='W_LEGALISM', KO='율법주의', EN='Legalism', era='고대',
       posture='믿음에 더해 지켜야 할 것이 있어야 하나님 앞에 선다',
       desc_KO='율법주의는 하나님 앞에 서려면 믿음에 더해 지켜야 할 것이 '
               '있다고 봅니다. 거룩하게 살려는 진지함에서 나오고, 계명을 '
               '가볍게 여기지 않으려는 마음이 그 안에 있습니다.\n성경은 '
               '계명을 가볍게 여기지 않으면서도 의롭다 하심의 근거를 다른 '
               '데 둡니다. 바울은 율법의 행위로는 의롭다 함을 얻을 육체가 '
               '없다고 하고, 예루살렘 회의는 조상도 메지 못하던 멍에를 '
               '다시 지우지 말라고 결정합니다. 갈라지는 자리는 순종의 값이 '
               '아니라 무엇이 우리를 의롭게 하느냐입니다.',
       desc_EN='Legalism holds that standing before God takes faith plus '
               'something that must be kept. It grows from a serious '
               'desire to live holy and from an unwillingness to treat the '
               'commandments lightly.\nScripture does not treat the '
               'commandments lightly either, yet it places the ground of '
               'justification elsewhere. Paul says no flesh is justified '
               'by works of the law, and the council at Jerusalem refuses '
               'to lay again a yoke the fathers could not bear. The '
               'parting of ways is not the worth of obedience but what '
               'makes us righteous.',
       verses=[
         (('갈', 2, 16), 'DISCERN',
          '「율법의 행위로서는 의롭다 함을 얻을 육체가 없느니라」고 '
          '바울이 못 박습니다. 의롭다 하심의 근거를 한 문장으로 '
          '정리합니다.',
          'By works of the law no one will be justified. Paul settles '
          'the ground of justification in a sentence.'),
         (('갈', 3, 3), 'POSTURE',
          '「성령으로 시작하였다가 이제는 육체로 마치겠느냐」고 '
          '묻습니다. 시작과 끝이 서로 다른 힘에 놓이는 것을 '
          '경계합니다.',
          'Having begun by the Spirit, are you now being perfected by '
          'the flesh. Paul warns against resting the end on a '
          'different power than the beginning.'),
         (('행', 15, 10), 'POSTURE',
          '「우리 조상과 우리도 능히 메지 못하던 멍에를 제자들의 목에 '
          '두려느냐」고 베드로가 말합니다. 교회가 그 자리에서 실제로 '
          '내린 결정입니다.',
          'Why place on the neck of the disciples a yoke that neither '
          'our fathers nor we could bear. It is the decision the '
          'church actually made.'),
         (('엡', 2, 8), 'DISCERN',
          '「그 은혜를 인하여 믿음으로 말미암아 구원을 얻었나니 '
          '이것이 너희에게서 난 것이 아니요」라고 합니다. 선물과 삯을 '
          '가르는 자리입니다.',
          'By grace you have been saved through faith, and this is '
          'not your own doing. Here gift and wage are told apart.'),
       ]),
  dict(code='W_ANTINOMIAN', KO='반율법주의', EN='Antinomianism', era='고대',
       posture='은혜 아래 있으니 행실은 더 이상 셈에 들지 않는다',
       desc_KO='반율법주의는 은혜가 값없이 주어졌으니 행실은 더 이상 '
               '문제가 되지 않는다고 봅니다. 공로로 하나님 앞에 서려던 '
               '짐을 벗었다는 기쁨에서 나오고, 은혜의 값없음을 지키려는 '
               '뜻이 그 안에 있습니다.\n성경도 은혜를 값없이 말하면서 바로 '
               '그 자리에서 물음을 던집니다. 바울은 은혜를 더하게 하려고 '
               '죄에 거하겠느냐고 묻고, 야고보는 행함이 없는 믿음은 그 '
               '자체가 죽은 것이라 합니다. 갈라지는 자리는 은혜의 값없음이 '
               '아니라 그 은혜가 사람을 바꾸느냐입니다.',
       desc_EN='Antinomianism holds that since grace is free, conduct no '
               'longer counts. It comes from the joy of release from '
               'earning a standing before God, and it means to guard that '
               'grace is truly free.\nScripture speaks of grace as free and '
               'asks its question at exactly that point. Paul asks whether '
               'we should continue in sin so that grace may abound, and '
               'James says faith without works is dead in itself. The '
               'parting of ways is not whether grace is free but whether '
               'that grace changes a person.',
       verses=[
         (('롬', 6, 1), 'POSTURE',
          '「은혜를 더하게 하려고 죄에 거하겠느뇨」라고 바울이 스스로 '
          '묻습니다. 은혜를 말한 바로 다음 자리에서 나오는 '
          '물음입니다.',
          'Shall we continue in sin that grace may abound. Paul '
          'raises the question immediately after speaking of grace.'),
         (('유', 1, 4), 'POSTURE',
          '「하나님의 은혜를 도리어 색욕거리로 바꾸고」 있는 사람들을 '
          '유다가 지목합니다. 이 자세가 실제로 있었던 일임을 보여 '
          '줍니다.',
          'Jude names those who turn the grace of God into '
          'sensuality, showing that this posture actually appeared.'),
         (('약', 2, 17), 'DISCERN',
          '「행함이 없는 믿음은 그 자체가 죽은 것이라」고 야고보가 '
          '적습니다. 믿음을 재는 것이 아니라 믿음의 상태를 말하는 '
          '자리입니다.',
          'Faith without works is dead in itself. James is not '
          'measuring faith but describing its condition.'),
         (('요일', 2, 4), 'DISCERN',
          '「저를 아노라 하고 그의 계명을 지키지 아니하는 자」를 '
          '요한이 짚습니다. 안다는 말과 사는 모양을 나란히 놓습니다.',
          'John marks the one who says I know him but does not keep '
          'his commandments. Knowing and living are set side by side.'),
       ]),
  dict(code='W_EPICUREAN', KO='에피쿠로스주의', EN='Epicureanism', era='고대',
       posture='신은 사람 일에 관여하지 않으니 두려움을 놓고 즐거움을 '
               '누린다',
       desc_KO='에피쿠로스주의는 신들이 사람의 일에 관여하지 않는다고 '
               '보고, 두려움을 내려놓고 절제된 즐거움 속에 평온을 찾으라고 '
               '가르쳤습니다. 죽음과 진노에 짓눌린 사람을 놓아주려는 뜻이 '
               '그 안에 있었습니다.\n바울은 아덴에서 바로 이 학파와 마주 '
               '섭니다. 성경도 즐거움을 선한 것으로 말하지만, 빌립보서는 '
               '저희의 신은 배라고 하고 전도서는 낙을 누려 본 사람이 '
               '그것도 헛되더라고 적습니다. 갈라지는 자리는 즐거움 자체가 '
               '아니라 즐거움이 삶의 목적이 되느냐입니다.',
       desc_EN='Epicureanism held that the gods take no part in human '
               'affairs and taught people to lay down fear and find calm '
               'in measured pleasure. It meant to release those crushed by '
               'death and by divine anger.\nPaul meets this school face to '
               'face in Athens. Scripture also calls pleasure good, yet '
               'Philippians says their god is their belly, and the '
               'Preacher, having tasted every delight, records that this '
               'too was vanity. The parting of ways is not pleasure itself '
               'but whether pleasure becomes the aim of a life.',
       verses=[
         (('행', 17, 18), 'POSTURE',
          '「어떤 에비구레오와 스도이고 철학자들도 바울과 '
          '쟁론할새」라고 누가가 적습니다. 이 사조가 성경 본문 안에서 '
          '실제로 마주친 자리입니다.',
          'Some Epicurean and Stoic philosophers debated with Paul. '
          'Here the movement is met face to face inside the text '
          'itself.'),
         (('눅', 16, 19), 'POSTURE',
          '「한 부자가 있어 자색 옷과 고운 베옷을 입고 날마다 '
          '호화로이 연락하는데」로 비유가 시작합니다. 누림이 삶의 '
          '전부가 된 사람의 모습입니다.',
          'A rich man was clothed in purple and fine linen and '
          'feasted sumptuously every day. The parable opens with a '
          'life given wholly to enjoyment.'),
         (('빌', 3, 19), 'POSTURE',
          '「저희의 신은 배요 그 영광은 저희의 부끄러움에 있고」라고 '
          '바울이 적습니다. 즐거움이 섬김의 대상이 되는 자리를 '
          '짚습니다.',
          'Their god is their belly, and they glory in their shame. '
          'Paul marks the point where pleasure becomes the thing '
          'served.'),
         (('전', 2, 1), 'DISCERN',
          '「너는 낙을 누리라 하였으나 본즉 이것도 헛되도다」라고 '
          '전도자가 적습니다. 실제로 끝까지 누려 본 사람의 '
          '보고입니다.',
          'I said, come now, I will test you with pleasure, and '
          'behold, this also was vanity. It is the report of one who '
          'actually went all the way.'),
       ]),
  dict(code='W_STOIC', KO='스토아주의', EN='Stoicism', era='고대',
       posture='이치에 순응하고 감정에 흔들리지 않는 것이 덕이다',
       desc_KO='스토아주의는 세상을 다스리는 이치에 순응하고 감정에 '
               '흔들리지 않는 것을 덕으로 삼았습니다. 어쩔 수 없는 일 '
               '앞에서 사람을 단단하게 세워 주었고, 절제와 의무를 귀하게 '
               '여기는 힘이 그 안에 있습니다.\n성경에도 자족이 있지만 그 '
               '뿌리가 다릅니다. 바울의 자족은 감정을 눌러서 얻은 것이 '
               '아니라 붙드시는 분에게서 배운 것이고, 예수께서는 무덤 '
               '앞에서 우셨습니다. 갈라지는 자리는 흔들리지 않는 힘이 '
               '아니라 그 힘이 어디서 오느냐입니다.',
       desc_EN='Stoicism made it a virtue to accept the order that governs '
               'the world and to stay unmoved by passion. It steadied '
               'people before what could not be changed, and a real '
               'strength in self control and duty lies within '
               'it.\nScripture also knows contentment, but its root is '
               "different. Paul's contentment was not won by suppressing "
               'feeling but learned from the one who holds him, and Jesus '
               'wept at a grave. The parting of ways is not steadiness but '
               'where that steadiness comes from.',
       verses=[
         (('행', 17, 18), 'POSTURE',
          '「어떤 에비구레오와 스도이고 철학자들도 바울과 '
          '쟁론할새」라고 누가가 적습니다. 이 학파가 성경 본문 안에서 '
          '실제로 마주친 자리입니다.',
          'Some Epicurean and Stoic philosophers debated with Paul. '
          'The Stoa is met face to face inside the text itself.'),
         (('빌', 4, 11), 'DISCERN',
          '「어떠한 형편에든지 내가 자족하기를 배웠노니」라고 바울이 '
          '적습니다. 자족이 타고난 기질이 아니라 배운 것이라고 '
          '말합니다.',
          'I have learned in whatever situation I am to be content. '
          'Paul calls contentment something learned, not a '
          'temperament.'),
         (('시', 55, 22), 'DISCERN',
          '「네 짐을 여호와께 맡겨 버리라」고 합니다. 짐을 견디는 '
          '것이 아니라 맡기는 자리를 가리킵니다.',
          'Cast your burden on the LORD. The verse points not to '
          'enduring the weight but to handing it over.'),
         (('롬', 12, 15), 'DISCERN',
          '「즐거워하는 자들로 함께 즐거워하고 우는 자들로 함께 '
          '울라」고 바울이 명합니다. 감정을 눌러 없애는 길과 다른 '
          '길입니다.',
          'Rejoice with those who rejoice, weep with those who weep. '
          'It is a different road from extinguishing feeling.'),
         (('요', 11, 35), 'DISCERN',
          '「예수께서 눈물을 흘리시더라」는 짧은 한 절이 있습니다. 곧 '
          '살리실 분이 먼저 우셨습니다.',
          'Jesus wept, says the shortest verse. The one about to '
          'raise the dead first shed tears.'),
       ]),
  dict(code='W_EMPEROR', KO='황제 숭배', EN='Emperor worship', era='고대',
       posture='질서를 지키는 권력에 신성을 입히고 그 앞에 절한다',
       desc_KO='황제 숭배는 나라를 지키고 질서를 세우는 권력에 신성을 '
               '입혔습니다. 흩어진 사람들을 하나로 묶고 충성을 눈에 보이게 '
               '하려는 장치였고, 평화를 지키려는 뜻이 그 '
               '명분이었습니다.\n성경은 권세를 존중하라고 하면서도 그 '
               '자리를 분명히 가릅니다. 예수께서는 가이사의 것과 하나님의 '
               '것을 나누어 말씀하시고, 세 친구는 그리 아니하실지라도 '
               '금신상에 절하지 않겠다고 답합니다. 사도행전은 신의 '
               '소리라는 환호를 받은 헤롯의 끝을 적습니다. 갈라지는 자리는 '
               '나라를 사랑하느냐가 아니라 권력에 절하느냐입니다.',
       desc_EN='Emperor worship clothed with divinity the power that '
               'guarded the realm and kept its order. It bound scattered '
               'peoples together and made loyalty visible, and the keeping '
               'of peace was its stated aim.\nScripture tells us to respect '
               'governing authority and still draws a clear line. Jesus '
               "separates what is Caesar's from what is God's, and the "
               'three friends answer that even if he does not deliver them '
               'they will not bow. Acts records the end of Herod, who was '
               'hailed with the voice of a god. The parting of ways is not '
               'love of country but bowing to power.',
       verses=[
         (('마', 22, 21), 'DISCERN',
          '「가이사의 것은 가이사에게, 하나님의 것은 하나님께 '
          '바치라」고 하십니다. 두 자리를 나누되 어느 쪽도 없애지 '
          '않습니다.',
          "Render to Caesar the things that are Caesar's, and to God "
          'the things that are God’s. Two claims are distinguished '
          'and neither is erased.'),
         (('단', 3, 18), 'DISCERN',
          '「그리 아니하실지라도 왕의 신들을 섬기지도 아니하고」라고 '
          '세 사람이 답합니다. 건져 주심을 조건으로 걸지 않는 '
          '대답입니다.',
          'But if not, we will not serve your gods. The answer does '
          'not make deliverance a condition.'),
         (('행', 12, 22), 'POSTURE',
          '「이것은 신의 소리요 사람의 소리는 아니라」는 환호가 '
          '헤롯에게 쏟아집니다. 권력에 신성을 입히는 말이 그대로 적혀 '
          '있습니다.',
          'The voice of a god, and not of a man, the crowd shouts to '
          'Herod. The words that clothe power with divinity are '
          'recorded as spoken.'),
         (('행', 12, 23), 'DISCERN',
          '「헤롯이 영광을 하나님께로 돌리지 아니하는 고로」 그 '
          '자리에서 무너집니다. 환호와 결말이 한 문장 건너에 '
          '놓입니다.',
          'Because Herod did not give God the glory, he falls on the '
          'spot. The acclaim and the end stand one sentence apart.'),
       ]),
  dict(code='W_FATALISM', KO='운명론', EN='Fatalism', era='고대',
       posture='앞날은 이미 정해졌으니 별과 징조에서 그것을 읽는다',
       desc_KO='운명론은 사람의 삶이 이미 정해진 흐름을 따라간다고 보고, '
               '별과 징조에서 그 흐름을 읽으려 했습니다. 알 수 없는 앞날 '
               '앞에서 무엇이라도 붙들려는 마음이 그 안에 있습니다.\n성경은 '
               '앞날이 하나님의 손에 있다고 말하면서도 사람을 인형으로 '
               '두지 않습니다. 이사야는 별을 보는 자들이 정작 구원하지 '
               '못한다고 하고, 잠언은 사람이 길을 계획할지라도 걸음을 '
               '인도하시는 분이 계시다고 적습니다. 갈라지는 자리는 앞날이 '
               '정해졌느냐가 아니라 누가 그것을 쥐고 계시냐입니다.',
       desc_EN='Fatalism holds that a life runs along a course already '
               'fixed, and it looked to stars and omens to read that '
               'course. Beneath it lies the wish to hold on to something '
               'before an unknown future.\nScripture says the future rests '
               "in God's hand and still does not make people puppets. "
               'Isaiah says those who gaze at the stars cannot save, and '
               'Proverbs says a man plans his way while the LORD directs '
               'his steps. The parting of ways is not whether the future '
               'is settled but who holds it.',
       verses=[
         (('사', 47, 13), 'POSTURE',
          '「별을 보는 자와 월삭에 예고하는 자들로 일어나 네게 임할 '
          '그 일에서 너를 구원케 하여 보라」고 합니다. 앞날을 읽는 '
          '일과 앞날에서 건지는 일을 가릅니다.',
          'Let those who gaze at the stars and predict by the new '
          'moons stand up and save you. Reading the future and '
          'rescuing from it are told apart.'),
         (('렘', 10, 2), 'DISCERN',
          '「열방인은 하늘의 징조를 두려워하거니와 너희는 그것을 '
          '두려워 말라」고 하십니다. 두려움의 대상을 옮기라는 '
          '말씀입니다.',
          'Do not be dismayed at the signs of the heavens, though the '
          'nations are dismayed at them. The verse moves the object '
          'of fear.'),
         (('잠', 16, 9), 'DISCERN',
          '「사람이 마음으로 자기의 길을 계획할지라도 그 걸음을 '
          '인도하는 자는 여호와시니라」고 합니다. 계획과 인도를 함께 '
          '둡니다.',
          'The heart of man plans his way, but the LORD establishes '
          'his steps. Planning and guidance are held together.'),
         (('단', 2, 28), 'DISCERN',
          '「은밀한 것을 나타내실 자는 하늘에 계신 하나님이시라」고 '
          '다니엘이 답합니다. 앞날을 아는 길이 기술이 아니라 계시임을 '
          '말합니다.',
          'There is a God in heaven who reveals mysteries, Daniel '
          'answers, calling knowledge of the future revelation rather '
          'than technique.'),
       ]),
  dict(code='W_ARIANISM', KO='아리우스주의', EN='Arianism', era='고대',
       posture='하나님의 유일하심을 지키려고 아들을 지음받은 존재로 둔다',
       desc_KO='아리우스주의는 하나님이 한 분이심을 지키려고 아들을 '
               '지음받은 존재로 보았습니다. 아버지의 유일하심을 흐리지 '
               '않으려는 뜻이 그 바탕에 있었고, 그 물음은 교회가 오래 '
               '씨름한 진지한 물음이었습니다.\n성경은 아들을 지음받은 '
               '자리에 두지 않습니다. 요한은 이 말씀이 곧 하나님이시라고 '
               '복음서를 열고, 예수께서는 아브라함이 나기 전부터 내가 '
               '있다고 하십니다. 히브리서는 아들을 향해 하나님이여라고 '
               '부릅니다. 갈라지는 자리는 하나님의 유일하심이 아니라 '
               '아들이 그 유일하심 안에 계시냐입니다.',
       desc_EN='Arianism sought to guard that God is one by regarding the '
               "Son as a created being. A concern not to blur the Father's "
               'uniqueness lay beneath it, and the question was one the '
               'church wrestled with seriously.\nScripture does not place '
               'the Son among created things. John opens his Gospel with '
               'the Word was God, and Jesus says that before Abraham was, '
               'I am. Hebrews addresses the Son as God. The parting of '
               'ways is not the oneness of God but whether the Son stands '
               'within it.',
       verses=[
         (('막', 6, 3), 'POSTURE',
          '「이 사람이 마리아의 아들 목수가 아니냐」 하고 고향 '
          '사람들이 예수를 배척합니다. 아들을 사람으로만 재는 자세가 '
          '드러난 자리입니다.',
          'Is not this the carpenter, the son of Mary, say the '
          'townspeople as they take offense. Here is the posture that '
          'measures the Son as a man only.'),
         (('요', 1, 1), 'DISCERN',
          '「이 말씀은 곧 하나님이시니라」로 요한복음이 시작합니다. '
          '아들의 자리를 첫 절에서 정합니다.',
          'And the Word was God. John settles the place of the Son in '
          'his first verse.'),
         (('요', 8, 58), 'DISCERN',
          '「아브라함이 나기 전부터 내가 있느니라」고 하십니다. 시간 '
          '안에서 시작된 존재가 아니라는 말씀입니다.',
          'Before Abraham was, I am. The saying denies a beginning '
          'within time.'),
         (('골', 1, 17), 'DISCERN',
          '「그가 만물보다 먼저 계시고 만물이 그 안에 함께 '
          '섰느니라」고 바울이 적습니다. 지어진 것들과 나란히 세우지 '
          '않습니다.',
          'He is before all things, and in him all things hold '
          'together. Paul does not line him up beside created things.'),
         (('히', 1, 8), 'DISCERN',
          '「아들에 관하여는 하나님이여 주의 보좌가 영영하며」라고 '
          '히브리서가 인용합니다. 아들을 부르는 호칭이 그대로 적혀 '
          '있습니다.',
          'But of the Son he says, Your throne, O God, is forever. '
          'The title given to the Son stands written.'),
       ]),
  dict(code='W_PELAGIAN', KO='펠라기우스주의', EN='Pelagianism', era='고대',
       posture='사람은 마음만 먹으면 스스로 선을 이룰 수 있다',
       desc_KO='펠라기우스주의는 사람이 마음만 먹으면 선을 이룰 수 있다고 '
               '보았습니다. 죄를 핑계 삼아 게으른 삶을 감싸는 태도에 맞선 '
               '것이었고, 책임을 지려는 진지함이 그 안에 '
               '있었습니다.\n성경은 책임을 말하면서도 사람의 형편을 다르게 '
               '진단합니다. 예레미야는 마음이 심히 부패하였다고 하고, '
               '바울은 허물과 죄로 죽었던 우리를 살리셨다고 적습니다. '
               '예수께서는 나를 떠나서는 아무것도 할 수 없다고 하십니다. '
               '갈라지는 자리는 사람이 애써야 하느냐가 아니라 그 힘이 '
               '어디서 오느냐입니다.',
       desc_EN='Pelagianism held that a person can do good by simply '
               'resolving to. It stood against using sin as an excuse for '
               'a slack life, and a serious sense of responsibility lay '
               'within it.\nScripture speaks of responsibility and yet '
               'diagnoses our condition differently. Jeremiah says the '
               'heart is deceitful above all things, and Paul says we were '
               'dead in trespasses and were made alive. Jesus says that '
               'apart from him we can do nothing. The parting of ways is '
               'not whether we must strive but where the strength comes '
               'from.',
       verses=[
         (('눅', 18, 11), 'POSTURE',
          '바리새인이 「나는 다른 사람들과 같지 아니하고」라며 서서 '
          '따로 기도합니다. 자기 힘으로 선에 이르렀다고 여기는 자세가 '
          '그대로 보입니다.',
          'The Pharisee stands and prays that he is not like other '
          'men. The posture that credits itself with goodness is '
          'visible as it is.'),
         (('렘', 17, 9), 'DISCERN',
          '「만물보다 거짓되고 심히 부패한 것은 마음이라」고 '
          '예레미야가 적습니다. 사람의 형편을 진단하는 자리입니다.',
          'The heart is deceitful above all things and desperately '
          'sick. Here the human condition is diagnosed.'),
         (('엡', 2, 1), 'DISCERN',
          '「너희의 허물과 죄로 죽었던 너희를 살리셨도다」라고 바울이 '
          '말합니다. 약해졌다가 아니라 죽었다고 적습니다.',
          'And you he made alive, who were dead in trespasses and '
          'sins. The word is dead, not merely weakened.'),
         (('요', 15, 5), 'DISCERN',
          '「나를 떠나서는 너희가 아무것도 할 수 없음이라」고 '
          '하십니다. 열매의 근원을 가지 밖에 둡니다.',
          'Apart from me you can do nothing. The source of fruit lies '
          'outside the branch.'),
         (('빌', 2, 13), 'DISCERN',
          '「너희 안에서 행하시는 이는 하나님이시니」라고 바울이 '
          '적습니다. 소원과 행함을 함께 주시는 분을 말합니다.',
          'It is God who works in you, both to will and to work. The '
          'willing and the doing are given together.'),
       ]),
  dict(code='W_MERIT', KO='공로주의', EN='Merit theology', era='중세',
       posture='쌓은 선행과 고행이 하나님 앞에서 값을 낸다',
       desc_KO='공로주의는 쌓은 선행과 고행이 하나님 앞에서 값을 낸다고 '
               '봅니다. 신앙이 말에 그치지 않게 하려는 진지함에서 나오고, '
               '힘써 살려는 뜻이 그 안에 있습니다.\n성경은 힘써 사는 일을 '
               '귀하게 여기면서도 셈법을 다르게 둡니다. 바울은 일하는 '
               '자에게 삯이 빚으로 여겨진다고 하며 그와 다른 길을 말하고, '
               '이사야는 우리의 의가 더러운 옷 같다고 적습니다. 갈라지는 '
               '자리는 선행의 가치가 아니라 그것이 값으로 '
               '셈해지느냐입니다.',
       desc_EN='A theology of merit holds that accumulated good works and '
               'penance count for something before God. It comes from a '
               'seriousness that will not let faith remain talk, and a '
               'will to live earnestly lies within it.\nScripture prizes '
               'earnest living and yet keeps a different accounting. Paul '
               'says that to the one who works, wages are counted as a '
               'debt, and he sets another road beside it. Isaiah says our '
               'righteous deeds are like a polluted garment. The parting '
               'of ways is not the value of good works but whether they '
               'are reckoned as payment.',
       verses=[
         (('눅', 18, 12), 'POSTURE',
          '「나는 이레에 두 번씩 금식하고 또 소득의 십일조를 '
          '드리나이다」라고 바리새인이 기도합니다. 쌓은 것을 헤아려 '
          '아뢰는 기도입니다.',
          'I fast twice a week and give tithes of all that I get, the '
          'Pharisee prays. It is a prayer that counts up what has '
          'been accumulated.'),
         (('롬', 4, 4), 'DISCERN',
          '「일하는 자에게는 그 삯을 은혜로 여기지 아니하고 빚으로 '
          '여기거니와」라고 바울이 적습니다. 삯과 선물을 가르는 '
          '자리입니다.',
          'To the one who works, his wages are not counted as a gift '
          'but as his due. Wage and gift are told apart.'),
         (('사', 64, 6), 'DISCERN',
          '「우리의 의는 다 더러운 옷 같으며」라고 이사야가 적습니다. '
          '우리가 내놓을 것의 값을 성경이 스스로 말합니다.',
          'All our righteous deeds are like a polluted garment. The '
          'worth of what we bring is named by Scripture itself.'),
         (('딛', 3, 5), 'DISCERN',
          '「우리의 행한 바 의로운 행위로 말미암지 아니하고 오직 그의 '
          '긍휼하심을 좇아」라고 합니다. 구원의 근거를 한 줄로 '
          '밝힙니다.',
          'Not because of works done by us in righteousness, but '
          'according to his own mercy. The ground of salvation is '
          'stated in a line.'),
       ]),
  dict(code='W_MYSTICISM', KO='신비주의', EN='Mysticism', era='중세',
       posture='직접 겪은 체험이 기록된 말씀 위에 선다',
       desc_KO='신비주의는 하나님을 직접 체험하는 데로 나아가려 합니다. '
               '형식만 남은 신앙에 대한 갈증에서 나오고, 살아 계신 분을 '
               '실제로 만나려는 마음이 그 안에 있습니다.\n성경도 하나님을 '
               '만나는 일을 말하지만 잣대를 함께 줍니다. 베뢰아 사람들은 '
               '들은 말이 그러한가 하여 날마다 성경을 상고했고, 바울은 '
               '하늘로부터 온 천사라도 다른 복음을 전하면 받지 말라고 '
               '합니다. 베드로는 더 확실한 예언이 있다고 적습니다. '
               '갈라지는 자리는 체험을 하느냐가 아니라 체험을 무엇으로 '
               '재느냐입니다.',
       desc_EN='Mysticism presses toward a direct experience of God. It '
               'springs from a thirst that empty form cannot satisfy, and '
               'it means to meet the living One in earnest.\nScripture also '
               'speaks of meeting God, and it supplies a measure. The '
               'Bereans examined the Scriptures daily to see whether what '
               'they heard was so, and Paul says that even an angel from '
               'heaven preaching another gospel is not to be received. '
               'Peter writes that we have the prophetic word more fully '
               'confirmed. The parting of ways is not whether one has '
               'experiences but what they are measured by.',
       verses=[
         (('골', 2, 18), 'POSTURE',
          '「그 본 것을 의지하여 그 육체의 마음을 좇아 헛되이 '
          '과장하고」라고 바울이 적습니다. 체험이 잣대 위로 올라선 '
          '자리입니다.',
          'Puffed up without reason by the mind of the flesh, relying '
          'on what he has seen. Here experience has climbed above the '
          'measure.'),
         (('행', 17, 11), 'DISCERN',
          '베뢰아 사람들이 「이것이 그러한가 하여 날마다 성경을 '
          '상고하므로」 신사적이라 불립니다. 들은 것을 재는 자리를 '
          '보여 줍니다.',
          'The Bereans examined the Scriptures daily to see if these '
          'things were so. Here is the place where what is heard gets '
          'measured.'),
         (('벧후', 1, 19), 'DISCERN',
          '「우리에게 더 확실한 예언이 있어 어두운 데 비취는 등불과 '
          '같으니」라고 베드로가 적습니다. 산에서 본 것을 겪은 사람이 '
          '그렇게 말합니다.',
          'We have the prophetic word more fully confirmed, a lamp '
          'shining in a dark place. The man who saw the mountain says '
          'this.'),
         (('갈', 1, 8), 'DISCERN',
          '「하늘로부터 온 천사라도 다른 복음을 전하면 저주를 '
          '받을지어다」라고 바울이 말합니다. 체험의 출처가 잣대를 '
          '이기지 못합니다.',
          'Even if an angel from heaven should preach another gospel, '
          'let him be accursed. The source of an experience does not '
          'outrank the measure.'),
         (('고후', 11, 14), 'DISCERN',
          '「사단도 자기를 광명의 천사로 가장하나니」라고 바울이 '
          '적습니다. 밝게 보이는 것이 곧 참은 아니라는 말입니다.',
          'Even Satan disguises himself as an angel of light. What '
          'appears bright is not thereby true.'),
       ]),
  dict(code='W_CLERICALISM', KO='성직주의', EN='Clericalism', era='중세',
       posture='하나님께 나아가는 길이 정해진 사람들의 손을 거쳐야 한다',
       desc_KO='성직주의는 하나님께 나아가는 길이 정해진 사람들의 손을 '
               '거쳐야 한다고 봅니다. 거룩한 일을 함부로 다루지 않으려는 '
               '마음에서 나오고, 질서를 지키려는 뜻이 그 안에 '
               '있습니다.\n성경은 섬기는 직분을 세우면서도 중보의 자리를 '
               '하나로 둡니다. 바울은 하나님과 사람 사이의 중보가 한 '
               '분이라 하고, 히브리서는 우리가 예수의 피를 힘입어 성소에 '
               '들어갈 담력을 얻었다고 적습니다. 베드로는 믿는 이들을 왕 '
               '같은 제사장이라 부릅니다. 갈라지는 자리는 직분의 필요가 '
               '아니라 그 직분이 중보를 대신하느냐입니다.',
       desc_EN='Clericalism holds that the way to God must pass through '
               'the hands of an appointed few. It arises from an '
               'unwillingness to handle holy things carelessly, and a '
               'concern for order lies within it.\nScripture appoints '
               'offices of service and still keeps mediation single. Paul '
               'says there is one mediator between God and men, Hebrews '
               'says we have confidence to enter the holy places by the '
               'blood of Jesus, and Peter calls believers a royal '
               'priesthood. The parting of ways is not whether offices are '
               'needed but whether an office takes the place of the '
               'mediator.',
       verses=[
         (('마', 23, 6), 'POSTURE',
          '「잔치의 상석과 회당의 상좌와」를 좋아한다고 예수께서 '
          '이르십니다. 섬기는 자리가 높은 자리가 되어 가는 '
          '모습입니다.',
          'They love the place of honour at feasts and the best seats '
          'in the synagogues. A place of service is turning into a '
          'place of rank.'),
         (('딤전', 2, 5), 'DISCERN',
          '「하나님과 사람 사이에 중보도 한 분이시니 곧 사람이신 '
          '그리스도 예수라」고 바울이 적습니다. 중보의 자리를 하나로 '
          '못 박습니다.',
          'There is one mediator between God and men, the man Christ '
          'Jesus. The place of mediation is fixed as one.'),
         (('히', 10, 19), 'DISCERN',
          '「우리가 예수의 피를 힘입어 성소에 들어갈 담력을 '
          '얻었나니」라고 합니다. 들어가는 담력이 누구에게서 오는지 '
          '말합니다.',
          'We have confidence to enter the holy places by the blood '
          'of Jesus. The verse says where that confidence comes from.'),
         (('벧전', 2, 9), 'DISCERN',
          '「너희는 택하신 족속이요 왕 같은 제사장들이요」라고 '
          '베드로가 믿는 이들을 부릅니다. 제사장이라는 말이 온 '
          '무리에게 붙습니다.',
          'You are a chosen race, a royal priesthood, Peter says to '
          'believers. The word priest is laid on the whole company.'),
         (('마', 23, 9), 'DISCERN',
          '「땅에 있는 자를 아비라 하지 말라」고 하십니다. 사람에게 '
          '돌아가는 호칭을 경계하시는 자리입니다.',
          'Call no man on earth your father. Here titles that settle '
          'on people are warned against.'),
       ]),
  dict(code='W_SUPERSTITION', KO='미신', EN='Superstition', era='중세',
       posture='거룩한 물건과 정해진 절차 자체에 힘이 있다',
       desc_KO='미신은 거룩한 물건이나 정해진 절차 자체에 힘이 있다고 '
               '여깁니다. 눈에 보이지 않는 분을 붙들고 싶은 마음에서 '
               '나오고, 두려운 일 앞에서 무엇이라도 하려는 절박함이 그 '
               '안에 있습니다.\n성경에도 그런 자리가 있습니다. 이스라엘은 '
               '언약궤를 전장으로 가져가면 이길 줄 알았고, 모세의 놋뱀은 '
               '세월이 지나 분향의 대상이 되어 히스기야가 부수었습니다. '
               '에베소 사람들은 마술책을 불살랐습니다. 갈라지는 자리는 '
               '보이는 것을 쓰느냐가 아니라 그것이 하나님을 '
               '대신하느냐입니다.',
       desc_EN='Superstition credits power to holy objects or to a set '
               'procedure itself. It grows from a wish to take hold of the '
               'One who cannot be seen, and from urgency before '
               'frightening things.\nScripture records such places. Israel '
               'thought that carrying the ark into battle would win the '
               'day, and the bronze serpent Moses made had become an '
               "object of incense by Hezekiah's time, so he broke it. The "
               'Ephesians burned their books of magic. The parting of ways '
               'is not whether visible things are used but whether they '
               'take the place of God.',
       verses=[
         (('삼상', 4, 3), 'POSTURE',
          '「여호와의 언약궤를 실로에서 우리에게로 가져다가 그것으로 '
          '우리를 구원하게 하자」고 장로들이 말합니다. 궤를 부적처럼 '
          '여긴 자리입니다.',
          'Let us bring the ark of the covenant here, that it may '
          'save us, the elders say, treating the ark as a charm.'),
         (('왕하', 18, 4), 'POSTURE',
          '「모세가 만들었던 놋뱀을 이스라엘 자손이 이 때까지 향하여 '
          '분향하므로」 히스기야가 그것을 부숩니다. 은혜의 표가 '
          '숭배의 대상이 된 자리입니다.',
          'Because the people had been burning incense to the bronze '
          'serpent Moses had made, Hezekiah broke it. A sign of grace '
          'had become an object of worship.'),
         (('행', 19, 19), 'DISCERN',
          '「마술을 행하던 많은 사람이 그 책을 모아 가지고 와서 '
          '불사르니」라고 누가가 적습니다. 값을 계산한 액수까지 함께 '
          '남깁니다.',
          'Many who had practiced magic brought their books and '
          'burned them. Luke even records what the books were worth.'),
         (('사', 44, 17), 'POSTURE',
          '「너는 나의 신이니 나를 구원하라」고 자기가 만든 것 앞에서 '
          '기도합니다. 손으로 만든 것에 힘을 두는 자리를 그립니다.',
          'You are my god, save me, he prays before what his own '
          'hands have made. The verse pictures power placed in a '
          'handmade thing.'),
       ]),
  dict(code='W_DEISM', KO='이신론', EN='Deism', era='근세',
       posture='하나님은 세상을 지으신 뒤 스스로 돌아가게 두셨다',
       desc_KO='이신론은 하나님이 세상을 지으신 뒤 스스로 돌아가게 '
               '두셨다고 봅니다. 자연이 법칙대로 돌아가는 것을 보고 얻은 '
               '결론이고, 하나님을 변덕스러운 분으로 그리지 않으려는 뜻이 '
               '그 안에 있습니다.\n성경은 세상이 법칙대로 돌아간다는 것을 '
               '부인하지 않으면서 그 법칙을 붙드시는 분을 말합니다. '
               '히브리서는 그의 능력의 말씀으로 만물을 붙드신다고 하고, '
               '예수께서는 참새 한 마리도 아버지께서 허락지 아니하시면 '
               '떨어지지 않는다고 하십니다. 갈라지는 자리는 세상에 질서가 '
               '있느냐가 아니라 그 질서 안에 그분이 계시냐입니다.',
       desc_EN='Deism holds that God made the world and then left it to '
               'run on its own. It is a conclusion drawn from seeing '
               'nature keep to its laws, and it means not to portray God '
               'as capricious.\nScripture does not deny that the world '
               'keeps to its laws, and it names the one who upholds them. '
               'Hebrews says he upholds all things by the word of his '
               'power, and Jesus says not one sparrow falls apart from the '
               'Father. The parting of ways is not whether there is order '
               'but whether he is present within it.',
       verses=[
         (('히', 1, 3), 'DISCERN',
          '「그의 능력의 말씀으로 만물을 붙드시며」라고 히브리서가 '
          '적습니다. 지으신 일과 붙드시는 일을 함께 말합니다.',
          'He upholds the universe by the word of his power. Making '
          'and sustaining are spoken of together.'),
         (('마', 10, 29), 'DISCERN',
          '「너희 아버지께서 허락지 아니하시면 그 하나라도 땅에 '
          '떨어지지 아니하리라」고 하십니다. 가장 작은 일까지 손이 '
          '닿아 있다고 말합니다.',
          'Not one of them will fall to the ground apart from your '
          'Father. The smallest events are said to be within his '
          'reach.'),
         (('시', 121, 4), 'DISCERN',
          '「이스라엘을 지키시는 자는 졸지도 아니하고 주무시지도 '
          '아니하시리로다」라고 합니다. 물러나 계신 분이 아니라는 '
          '말입니다.',
          'He who keeps Israel will neither slumber nor sleep. He is '
          'not one who has withdrawn.'),
         (('습', 1, 12), 'POSTURE',
          '「여호와께서는 복도 내리지 아니하시며 화도 내리지 '
          '아니하시리라」 하는 자를 벌하리라고 하십니다. 이 자세가 '
          '성경 안에 이름을 얻고 있습니다.',
          'I will punish those who say the LORD will do neither good '
          'nor ill. The posture is named within Scripture itself.'),
       ]),
  dict(code='W_RATIONALISM', KO='합리주의', EN='Rationalism', era='근세',
       posture='이성이 참과 그름을 가리는 마지막 법정이다',
       desc_KO='합리주의는 이성이 참과 그름을 가리는 마지막 법정이라고 '
               '봅니다. 권위에 눌려 생각을 멈추던 시대를 지나며 얻은 '
               '힘이고, 스스로 따져 보려는 정직함이 그 안에 '
               '있습니다.\n성경은 생각하는 일을 낮추지 않으면서 이성의 '
               '자리를 다르게 둡니다. 잠언은 마음을 다하여 여호와를 '
               '의뢰하고 네 명철을 의지하지 말라고 하고, 이사야는 하늘이 '
               '땅보다 높음같이 내 생각은 너희 생각보다 높다고 적습니다. '
               '갈라지는 자리는 생각을 쓰느냐가 아니라 생각이 마지막 '
               '법정이 되느냐입니다.',
       desc_EN='Rationalism holds that reason is the final court for what '
               'is true. It is a strength gained in passing out of an age '
               'where authority stopped thought, and an honest wish to '
               'weigh things for oneself lies within it.\nScripture does '
               'not belittle thinking, and it places reason differently. '
               'Proverbs says to trust the LORD with all your heart and '
               'not lean on your own understanding, and Isaiah says that '
               'as the heavens are higher than the earth, so are his '
               'thoughts higher than ours. The parting of ways is not '
               'whether we think but whether thought is the final court.',
       verses=[
         (('사', 47, 10), 'POSTURE',
          '「네 지혜와 네 지식이 너를 유혹하였음이니라」고 바벨론에게 '
          '이르십니다. 앎이 사람을 어디까지 데려가는지 보여 주는 '
          '자리입니다.',
          'Your wisdom and your knowledge led you astray, it is said '
          'to Babylon. The verse shows where knowing can carry a '
          'person.'),
         (('잠', 3, 5), 'DISCERN',
          '「네 명철을 의지하지 말라」고 잠언이 말합니다. 생각을 '
          '버리라는 말이 아니라 무엇에 기대느냐를 묻습니다.',
          'Do not lean on your own understanding. It does not ask us '
          'to stop thinking but asks what we lean on.'),
         (('사', 55, 9), 'DISCERN',
          '「내 길은 너희 길보다 높으며 내 생각은 너희 생각보다 '
          '높으니라」고 하십니다. 사람의 자와 하나님의 자가 다름을 '
          '말합니다.',
          'My ways are higher than your ways and my thoughts than '
          "your thoughts. A human measure and God's measure are not "
          'the same.'),
         (('고전', 2, 14), 'DISCERN',
          '「육에 속한 사람은 하나님의 성령의 일을 받지 '
          '아니하나니」라고 바울이 적습니다. 못 알아듣는 까닭이 '
          '머리에 있지 않다고 봅니다.',
          'The natural person does not accept the things of the '
          'Spirit of God. Paul locates the difficulty elsewhere than '
          'in the intellect.'),
         (('고전', 1, 25), 'DISCERN',
          '「하나님의 미련한 것이 사람보다 지혜 있고」라고 합니다. '
          '잣대를 뒤집어 놓고 보게 하는 문장입니다.',
          'The foolishness of God is wiser than men. The sentence '
          'turns the measure over and lets us look at it.'),
       ]),
  dict(code='W_ENLIGHT', KO='계몽주의', EN='Enlightenment', era='근세',
       posture='스스로 생각하면 전통과 권위의 그늘에서 벗어난다',
       desc_KO='계몽주의는 사람이 스스로 생각할 때 전통과 권위의 그늘에서 '
               '벗어난다고 보았습니다. 물려받은 것을 묻지 않고 따르던 '
               '자리에서 사람을 일으켜 세웠고, 스스로 책임지려는 뜻이 그 '
               '안에 있습니다.\n성경에도 스스로 지혜롭다 여기는 자리를 두고 '
               '하는 말이 있습니다. 이사야는 스스로 지혜롭다 하는 자들에게 '
               '화를 선포하고, 예레미야는 옛적 길 곧 선한 길이 어디인지 '
               '알아보고 그리로 행하라고 권합니다. 갈라지는 자리는 스스로 '
               '생각하느냐가 아니라 물려받은 것을 물음 없이 '
               '버리느냐입니다.',
       desc_EN='The Enlightenment held that people step out from under '
               'tradition and authority when they think for themselves. It '
               'lifted them out of following what was handed down without '
               'question, and a will to take responsibility lies within '
               'it.\nScripture also speaks about those who are wise in '
               'their own eyes. Isaiah pronounces woe on them, and '
               'Jeremiah urges us to ask for the ancient paths, where the '
               'good way is, and walk in it. The parting of ways is not '
               'thinking for oneself but discarding what was handed down '
               'without asking.',
       verses=[
         (('사', 5, 21), 'POSTURE',
          '「스스로 지혜롭다 하며 스스로 명철하다 하는 그들은 화 '
          '있을진저」라고 합니다. 지혜 자체가 아니라 스스로라는 말에 '
          '무게가 있습니다.',
          'Woe to those who are wise in their own eyes. The weight '
          'falls on the words in their own eyes, not on wisdom.'),
         (('창', 3, 6), 'POSTURE',
          '「지혜롭게 할 만큼 탐스럽기도 한 나무인지라」고 적혀 '
          '있습니다. 지혜를 얻는 길이 어디서 갈라졌는지 보여 줍니다.',
          'The tree was to be desired to make one wise. The verse '
          'shows where the road to wisdom forked.'),
         (('렘', 6, 16), 'DISCERN',
          '「옛적 길 곧 선한 길이 어디인지 알아보고 그리로 행하라」고 '
          '하십니다. 물려받은 것을 묻는 일과 버리는 일을 가릅니다.',
          'Ask for the ancient paths, where the good way is, and walk '
          'in it. Questioning what is handed down and discarding it '
          'are not the same.'),
         (('고전', 3, 18), 'DISCERN',
          '「이 세상에서 지혜 있는 줄로 생각하거든 미련한 자가 '
          '되어라」고 바울이 적습니다. 지혜에 이르는 차례를 뒤집어 '
          '말합니다.',
          'If anyone thinks he is wise in this age, let him become a '
          'fool. Paul reverses the order of the road to wisdom.'),
       ]),
  dict(code='W_LIBERALTH', KO='자유주의 신학', EN='Liberal theology', era='근세',
       posture='받아들이기 어려운 것을 덜어 내고 윤리와 정신만 남긴다',
       desc_KO='자유주의 신학은 현대인이 받아들이기 어려운 것을 덜어 내고 '
               '성경의 윤리와 정신을 남기려 했습니다. 믿음이 제 시대와 '
               '말을 섞게 하려는 뜻에서 나왔고, 사람들에게 닿으려는 마음이 '
               '그 안에 있습니다.\n성경은 사건을 덜어 내면 무엇이 남는지 '
               '스스로 셈합니다. 바울은 그리스도께서 다시 사신 것이 없으면 '
               '전파하는 것도 헛것이라 하고, 베드로는 우리가 전한 것이 '
               '공교히 만든 이야기가 아니라 친히 본 것이라고 적습니다. '
               '갈라지는 자리는 시대와 말을 섞느냐가 아니라 일어난 일을 '
               '그대로 두느냐입니다.',
       desc_EN='Liberal theology sought to set aside what a modern person '
               'finds hard to accept and to keep the ethics and spirit of '
               'Scripture. It meant to let faith speak with its own age, '
               'and a desire to reach people lies within it.\nScripture '
               'reckons for itself what remains once the events are '
               'removed. Paul says that if Christ has not been raised our '
               'preaching is in vain, and Peter says that what was '
               'delivered was not a cleverly devised myth but what he saw '
               'with his own eyes. The parting of ways is not speaking to '
               'one’s age but whether what happened is left standing.',
       verses=[
         (('고전', 15, 14), 'DISCERN',
          '「그리스도께서 만일 다시 살지 못하셨으면 우리의 전파하는 '
          '것도 헛것이요」라고 바울이 셈합니다. 남는 것이 무엇인지 '
          '스스로 계산합니다.',
          'If Christ has not been raised, then our preaching is in '
          'vain. Paul does the accounting himself.'),
         (('벧후', 1, 16), 'DISCERN',
          '「공교히 만든 이야기를 좇은 것이 아니요 우리는 그의 크신 '
          '위엄을 친히 본 자라」고 적습니다. 목격을 근거로 '
          '내놓습니다.',
          'We did not follow cleverly devised myths; we were '
          'eyewitnesses of his majesty. Testimony is offered as the '
          'ground.'),
         (('딤후', 3, 5), 'POSTURE',
          '「경건의 모양은 있으나 경건의 능력은 부인하는 자니」라고 '
          '바울이 적습니다. 모양과 능력을 가르는 말입니다.',
          'Having the appearance of godliness but denying its power. '
          'Form and power are told apart.'),
         (('유', 1, 3), 'DISCERN',
          '「성도에게 단번에 주신 믿음의 도를 위하여 힘써 싸우라」고 '
          '유다가 권합니다. 물려받은 것이 있음을 전제하는 권면입니다.',
          'Contend for the faith that was once for all delivered to '
          'the saints. The exhortation assumes there is something '
          'handed down.'),
       ]),
  dict(code='W_SYNCRETISM', KO='혼합주의', EN='Syncretism', era='고대·중세',
       posture='여러 신앙에서 좋아 보이는 것을 선택해 하나로 엮는다',
       desc_KO='혼합주의는 여러 신앙에서 좋아 보이는 것을 선택해 하나로 '
               '엮습니다. 낯선 것을 배척하지 않으려는 마음에서 나오고, '
               '새로운 자리에 뿌리내리려는 실제적인 이유도 '
               '있습니다.\n성경에는 그렇게 엮인 자리가 여럿 적혀 있습니다. '
               '아론은 금송아지를 세우고 내일은 여호와의 절일이라 '
               '공포했고, 여로보암은 같은 방식으로 나라를 나누었습니다. '
               '스바냐는 여호와께 맹세하면서 말감을 가리켜 맹세하는 자를 '
               '짚습니다. 갈라지는 자리는 이웃의 것을 배우느냐가 아니라 '
               '예배의 대상이 섞이느냐입니다.',
       desc_EN='Syncretism picks what looks good from several faiths and '
               'weaves them into one. It comes from an unwillingness to '
               'reject what is unfamiliar, and there are practical reasons '
               'too, such as taking root in a new place.\nScripture records '
               'several such weavings. Aaron set up a golden calf and '
               'proclaimed a feast to the LORD, and Jeroboam divided the '
               'kingdom the same way. Zephaniah names those who swear to '
               'the LORD and also swear by Milcom. The parting of ways is '
               'not learning from neighbours but whether the object of '
               'worship is mixed.',
       verses=[
         (('출', 32, 5), 'POSTURE',
          '아론이 금송아지 앞에 단을 쌓고 「내일은 여호와의 '
          '절일이니라」고 공포합니다. 이름은 그대로 두고 대상이 바뀐 '
          '자리입니다.',
          'Aaron built an altar before the calf and proclaimed a '
          'feast to the LORD. The name stayed while the object '
          'changed.'),
         (('왕상', 12, 28), 'POSTURE',
          '「이스라엘아 이는 너희를 애굽 땅에서 인도하여 올린 너희 '
          '신이라」고 여로보암이 말합니다. 구원의 이야기를 그대로 '
          '빌려 씁니다.',
          'Behold your gods, who brought you up out of Egypt, says '
          'Jeroboam, borrowing the story of salvation intact.'),
         (('습', 1, 5), 'POSTURE',
          '「여호와께 맹세하면서 말감을 가리켜 맹세하는 자」를 '
          '스바냐가 지목합니다. 두 이름을 한 입에 담는 자리입니다.',
          'Those who swear to the LORD and yet swear by Milcom. Two '
          'names are held in one mouth.'),
         (('고후', 6, 14), 'DISCERN',
          '「믿지 않는 자와 멍에를 같이 하지 말라」고 바울이 '
          '말합니다. 사귐을 끊으라는 말이 아니라 방향을 함께 묶지 '
          '말라는 뜻입니다.',
          'Do not be unequally yoked with unbelievers. It does not '
          'command the end of friendship but warns against being '
          'bound to one direction together.'),
       ]),
  dict(code='W_UNIVERSALISM', KO='만인구원론', EN='Universalism', era='근현대',
       posture='사랑이신 하나님이 끝내 아무도 잃지 않으신다',
       desc_KO='만인구원론은 사랑이신 하나님이 끝내 아무도 잃지 '
               '않으시리라고 봅니다. 심판을 말하며 사람을 겁주던 일에 대한 '
               '반작용에서 나오고, 하나님의 선하심을 끝까지 믿으려는 '
               '마음이 그 안에 있습니다.\n성경은 하나님이 아무도 멸망치 '
               '않기를 원하신다고 적으면서 동시에 좁은 문을 말합니다. '
               '예수께서는 생명으로 인도하는 문이 좁다 하시고, 심판의 두 '
               '결말을 한 절에 나란히 두십니다. 갈라지는 자리는 하나님의 '
               '사랑이 아니라 사람의 응답이 값을 가지느냐입니다.',
       desc_EN='Universalism holds that a God who is love will in the end '
               'lose no one. It arises in reaction to preaching that used '
               "judgment to frighten, and a determination to trust God's "
               'goodness to the last lies within it.\nScripture says God '
               'wishes that none should perish and in the same breath '
               'speaks of a narrow gate. Jesus says the gate that leads to '
               'life is narrow, and he sets the two outcomes of judgment '
               'side by side in a single verse. The parting of ways is not '
               'the love of God but whether a human answer carries weight.',
       verses=[
         (('창', 3, 4), 'POSTURE',
          '「너희가 결코 죽지 아니하리라」는 말이 동산에서 처음 '
          '들립니다. 심판이 없으리라는 말의 첫 자리입니다.',
          'You will not surely die is first heard in the garden. It '
          'is the earliest form of the claim that judgment will not '
          'come.'),
         (('벧후', 3, 9), 'DISCERN',
          '「아무도 멸망치 않고 다 회개하기에 이르기를 '
          '원하시느니라」고 베드로가 적습니다. 하나님이 무엇을 '
          '원하시는지 분명히 말합니다.',
          'Not wishing that any should perish, but that all should '
          'reach repentance. What God desires is stated plainly.'),
         (('마', 7, 14), 'DISCERN',
          '「생명으로 인도하는 문은 좁고 길이 협착하여 찾는 이가 '
          '적음이니라」고 하십니다. 원하심과 실제를 함께 두십니다.',
          'The gate is narrow and the way is hard that leads to life, '
          'and those who find it are few. Desire and actuality are '
          'held together.'),
         (('마', 25, 46), 'DISCERN',
          '「저희는 영벌에, 의인들은 영생에 들어가리라」로 비유가 '
          '닫힙니다. 두 결말이 한 문장 안에 나란합니다.',
          'These will go away into eternal punishment, but the '
          'righteous into eternal life. Two outcomes stand side by '
          'side in one sentence.'),
         (('요', 3, 18), 'DISCERN',
          '「믿지 아니하는 자는 벌써 심판을 받은 것이니라」고 합니다. '
          '사람의 응답이 값을 가진다고 말하는 자리입니다.',
          'Whoever does not believe is condemned already. Here the '
          'answer a person gives is said to carry weight.'),
       ]),
  dict(code='W_MARXISM', KO='마르크스주의', EN='Marxism', era='현대',
       posture='역사는 계급의 다툼이고 구조를 바꾸면 사람이 달라진다',
       desc_KO='마르크스주의는 역사를 계급의 다툼으로 읽고, 가진 자와 없는 '
               '자의 구조를 바꾸면 사람의 삶이 달라진다고 봅니다. 억눌린 '
               '사람들의 고통을 정면으로 다루었고, 불의를 견디지 않으려는 '
               '마음이 그 안에 있습니다.\n성경도 불의한 부를 그냥 두지 '
               '않습니다. 야고보는 품꾼에게 주지 않은 삯이 소리 지른다고 '
               '하고, 아모스는 공법을 물같이 흘리라고 외칩니다. 그러면서도 '
               '예수께서는 내 나라가 이 세상에 속한 것이 아니라 하십니다. '
               '갈라지는 자리는 불의를 미워하느냐가 아니라 구조를 바꾸는 '
               '일이 구원을 대신하느냐입니다.',
       desc_EN='Marxism reads history as a struggle between classes and '
               'holds that changing the structure between those who have '
               'and those who do not will change how people live. It faced '
               'the suffering of the oppressed head on, and a refusal to '
               'tolerate injustice lies within it.\nScripture does not '
               'leave unjust wealth alone either. James says the withheld '
               'wages of the harvesters cry out, and Amos calls for '
               'justice to roll down like waters. Yet Jesus says his '
               'kingdom is not of this world. The parting of ways is not '
               'hatred of injustice but whether changing structures takes '
               'the place of salvation.',
       verses=[
         (('약', 5, 4), 'DISCERN',
          '「너희 밭에 추수한 품꾼에게 주지 아니한 삯이 '
          '소리지르며」라고 야고보가 적습니다. 불의한 부를 성경이 '
          '먼저 고발합니다.',
          'The wages you failed to pay the workers are crying out. '
          'Scripture brings the charge against unjust wealth first.'),
         (('암', 5, 24), 'DISCERN',
          '「공법을 물같이, 정의를 하수같이 흘릴지로다」라고 아모스가 '
          '외칩니다. 예배보다 먼저 물어야 할 것을 말합니다.',
          'Let justice roll down like waters. Amos names what must be '
          'asked before worship.'),
         (('요', 18, 36), 'DISCERN',
          '「내 나라는 이 세상에 속한 것이 아니라」고 예수께서 '
          '빌라도에게 답하십니다. 나라를 세우는 방식이 어디서 '
          '갈라지는지 보여 줍니다.',
          'My kingdom is not of this world, Jesus answers Pilate, '
          'showing where the way of building a kingdom parts.'),
         (('시', 2, 2), 'POSTURE',
          '「세상의 군왕들이 나서며 관원들이 서로 꾀하여 여호와와 그 '
          '기름받은 자를 대적하며」라고 합니다. 권력의 다툼 위에 다른 '
          '축이 있음을 말합니다.',
          'The kings of the earth set themselves against the LORD and '
          'against his anointed. Another axis stands above the '
          'contest of powers.'),
       ]),
  dict(code='W_EXISTENTIAL', KO='실존주의', EN='Existentialism', era='현대',
       posture='주어진 의미가 없으니 내가 선택으로 의미를 만든다',
       desc_KO='실존주의는 주어진 의미가 없다면 내가 선택으로 의미를 '
               '만든다고 봅니다. 사람을 부품으로 다루던 시대에 맞서 한 '
               '사람의 책임과 자유를 세웠고, 정직하게 자기 삶을 마주하려는 '
               '힘이 그 안에 있습니다.\n성경은 사람을 부품으로 보지 '
               '않으면서 의미의 출처를 다르게 둡니다. 전도서는 사람에게 '
               '영원을 사모하는 마음을 주셨다고 하고, 시편은 내 형질이 '
               '이루기 전에 주의 눈이 보셨다고 적습니다. 갈라지는 자리는 '
               '선택이 중요하냐가 아니라 의미를 내가 만드느냐 '
               '받느냐입니다.',
       desc_EN='Existentialism holds that if no meaning is given, I make '
               'meaning by my choices. Against an age that treated people '
               'as parts, it raised up the responsibility and freedom of '
               "one person, and an honest facing of one's own life lies "
               'within it.\nScripture does not treat people as parts, and '
               'it places the source of meaning elsewhere. Ecclesiastes '
               'says he has put eternity into the human heart, and the '
               'psalm says your eyes saw my unformed substance. The '
               'parting of ways is not whether choices matter but whether '
               'meaning is made or received.',
       verses=[
         (('전', 3, 11), 'DISCERN',
          '「사람에게 영원을 사모하는 마음을 주셨느니라」고 전도서가 '
          '적습니다. 의미를 찾는 갈망 자체가 주어진 것이라 말합니다.',
          "He has put eternity into man's heart. The very longing for "
          'meaning is said to be given.'),
         (('시', 139, 16), 'DISCERN',
          '「내 형질이 이루기 전에 주의 눈이 보셨으며」라고 시인이 '
          '노래합니다. 내가 있기 전에 먼저 보신 눈을 말합니다.',
          'Your eyes saw my unformed substance. The psalm speaks of a '
          'gaze that came before I did.'),
         (('렘', 1, 5), 'DISCERN',
          '「내가 너를 복중에 짓기 전에 너를 알았고」라고 하십니다. '
          '부르심이 선택보다 앞선 자리입니다.',
          'Before I formed you in the womb I knew you. The call comes '
          'before the choosing.'),
         (('사', 45, 9), 'POSTURE',
          '「질그릇 조각 중 한 조각 같은 자가 자기를 지으신 자로 '
          '더불어 다툴진대」라고 이사야가 적습니다. 만들어진 자와 '
          '만드신 분의 자리를 말합니다.',
          'Woe to him who strives with him who formed him, a pot '
          'among earthen pots. The verse marks the places of the made '
          'and the maker.'),
       ]),
  dict(code='W_PRAGMATISM', KO='실용주의', EN='Pragmatism', era='현대',
       posture='쓸모 있게 작동하는 것이 곧 참이다',
       desc_KO='실용주의는 쓸모 있게 작동하는 것이 참이라고 봅니다. 공허한 '
               '논쟁을 걷어 내고 실제로 사람을 살리는 쪽을 보게 했고, '
               '열매를 보려는 마음이 그 안에 있습니다.\n성경도 열매로 '
               '알라고 하면서 유익만으로 판단하지는 않습니다. 대제사장은 '
               '한 사람이 죽는 것이 유익하다는 셈으로 예수를 넘겼고, '
               '사무엘은 순종이 제사보다 낫다고 말합니다. 잠언은 사람의 '
               '보기에 바른 길이 필경 사망의 길일 수 있다고 적습니다. '
               '갈라지는 자리는 열매를 보느냐가 아니라 유익이 옳음을 '
               '대신하느냐입니다.',
       desc_EN='Pragmatism holds that what works is what is true. It '
               'cleared away hollow argument and turned attention to what '
               'actually helps people, and a concern for fruit lies within '
               'it.\nScripture also says to judge by fruit, and it does not '
               'judge by usefulness alone. The high priest handed Jesus '
               "over by reckoning that one man's death was expedient, and "
               'Samuel says obedience is better than sacrifice. Proverbs '
               'says there is a way that seems right to a man but its end '
               'is death. The parting of ways is not looking at fruit but '
               'whether usefulness takes the place of rightness.',
       verses=[
         (('요', 11, 50), 'POSTURE',
          '「한 사람이 백성을 위하여 죽어서 온 민족이 망하지 않게 '
          '되는 것이 너희에게 유익한 줄」이라고 대제사장이 셈합니다. '
          '유익으로만 재는 판단이 어디까지 가는지 보여 줍니다.',
          'It is expedient that one man should die for the people. '
          'The high priest reckons by usefulness, and the verse shows '
          'how far that can go.'),
         (('삼상', 15, 22), 'DISCERN',
          '「순종이 제사보다 낫고 듣는 것이 숫양의 기름보다 '
          '나으니」라고 사무엘이 말합니다. 좋아 보이는 결과와 순종을 '
          '가릅니다.',
          'To obey is better than sacrifice, and to listen than the '
          'fat of rams. A good looking result and obedience are told '
          'apart.'),
         (('잠', 14, 12), 'DISCERN',
          '「어떤 길은 사람의 보기에 바르나 필경은 사망의 '
          '길이니라」고 합니다. 보기에 맞는 것과 참인 것을 나눕니다.',
          'There is a way that seems right to a man, but its end is '
          'the way of death. What looks right and what is true are '
          'separated.'),
         (('마', 16, 26), 'DISCERN',
          '「사람이 만일 온 천하를 얻고도 제 목숨을 잃으면 무엇이 '
          '유익하리요」라고 하십니다. 유익이라는 말을 그 말의 잣대로 '
          '되묻습니다.',
          'What does it profit a man to gain the whole world and '
          'forfeit his soul. The word profit is turned back on '
          'itself.'),
       ]),
  dict(code='W_NATURALISM', KO='진화론적 자연주의', EN='Evolutionary naturalism', era='현대',
       posture='생명과 사람은 목적 없는 과정과 긴 시간의 결과다',
       desc_KO='진화론적 자연주의는 생명과 사람이 목적 없는 과정과 긴 '
               '시간의 결과라고 봅니다. 관찰한 것으로만 설명하려는 '
               '절제에서 나왔고, 자연을 꼼꼼히 들여다보려는 힘이 그 안에 '
               '있습니다.\n성경은 사람을 하나님의 형상대로 지으셨다고 적고, '
               '시편은 우리를 지으신 자가 그분이라고 노래합니다. 바울은 '
               '피조물을 조물주보다 더 경배하는 자리를 짚습니다. 갈라지는 '
               '자리는 자연을 연구하느냐가 아니라 사람에게 지으신 분과 '
               '목적이 있느냐입니다.',
       desc_EN='Evolutionary naturalism holds that life and humanity are '
               'the outcome of a purposeless process over long time. It '
               'comes from a discipline that explains only by what is '
               'observed, and a careful attention to nature lies within '
               'it.\nScripture says people were made in the image of God, '
               'and the psalm sings that it is he who made us. Paul marks '
               'the point where the creature is worshipped rather than the '
               'Creator. The parting of ways is not the study of nature '
               'but whether a person has a maker and a purpose.',
       verses=[
         (('창', 1, 27), 'DISCERN',
          '「하나님이 자기 형상 곧 하나님의 형상대로 사람을 '
          '창조하시되」라고 첫 장이 적습니다. 사람의 값이 어디서 '
          '오는지 말합니다.',
          'God created man in his own image. The first chapter says '
          'where human worth comes from.'),
         (('시', 100, 3), 'DISCERN',
          '「그는 우리를 지으신 자시요 우리는 그의 것이니」라고 '
          '노래합니다. 우리가 우리를 지은 것이 아니라고 말합니다.',
          'It is he who made us, and we are his. The psalm says we '
          'did not make ourselves.'),
         (('골', 1, 16), 'DISCERN',
          '「만물이 다 그로 말미암고 그를 위하여 창조되었고」라고 '
          '바울이 적습니다. 기원만이 아니라 목적을 함께 말합니다.',
          'All things were created through him and for him. Paul '
          'speaks not only of origin but of purpose.'),
         (('롬', 1, 25), 'POSTURE',
          '「피조물을 조물주보다 더 경배하고 섬김이라」고 바울이 '
          '짚습니다. 자연을 보는 눈이 어디서 어긋나는지 말합니다.',
          'They worshiped and served the creature rather than the '
          'Creator. Paul names where the gaze at nature goes astray.'),
       ]),
  dict(code='W_CONSUMERISM', KO='소비주의', EN='Consumerism', era='현대',
       posture='무엇을 가지고 무엇을 누리느냐가 나를 말해 준다',
       desc_KO='소비주의는 무엇을 가지고 무엇을 누리느냐가 사람을 말해 '
               '준다고 여깁니다. 가난을 겪은 사회가 풍요에 이르며 '
               '자연스럽게 자라났고, 더 나은 삶을 바라는 마음이 그 안에 '
               '있습니다.\n성경은 좋은 것을 주시는 분을 말하면서도 소유와 '
               '생명을 가릅니다. 예수께서는 사람의 생명이 소유의 넉넉한 데 '
               '있지 않다고 하시고, 전도자는 은을 사랑하는 자가 은으로 '
               '만족하지 못한다고 적습니다. 갈라지는 자리는 누리는 일이 '
               '아니라 가진 것이 나를 말하느냐입니다.',
       desc_EN='Consumerism takes what one owns and enjoys as the measure '
               'of who one is. It grew naturally as societies that had '
               'known want came into plenty, and a wish for a better life '
               'lies within it.\nScripture speaks of the God who gives good '
               'things and still separates possessions from life. Jesus '
               'says a life does not consist in the abundance of '
               'possessions, and the Preacher says the lover of money is '
               'never satisfied with money. The parting of ways is not '
               'enjoyment but whether what we own tells us who we are.',
       verses=[
         (('눅', 12, 15), 'DISCERN',
          '「사람의 생명이 그 소유의 넉넉한 데 있지 아니하니라」고 '
          '하십니다. 소유와 생명을 한 문장에서 가릅니다.',
          'One’s life does not consist in the abundance of '
          'possessions. Owning and living are separated in a single '
          'sentence.'),
         (('전', 5, 10), 'POSTURE',
          '「은을 사랑하는 자는 은으로 만족함이 없고」라고 전도자가 '
          '적습니다. 더 가지면 채워진다는 셈이 어디서 어긋나는지 '
          '말합니다.',
          'He who loves money will not be satisfied with money. The '
          'verse names where the reckoning of more goes wrong.'),
         (('딤전', 6, 9), 'POSTURE',
          '「부하려 하는 자들은 시험과 올무와 여러 가지 어리석고 '
          '해로운 정욕에 떨어지나니」라고 합니다. 부 자체가 아니라 '
          '하려 하는 마음을 짚습니다.',
          'Those who desire to be rich fall into temptation and a '
          'snare. It marks the desiring, not wealth itself.'),
         (('마', 6, 21), 'DISCERN',
          '「네 보물 있는 그 곳에는 네 마음도 있느니라」고 하십니다. '
          '무엇을 사느냐가 어디로 가느냐를 말합니다.',
          'Where your treasure is, there your heart will be also. '
          'What we buy tells where we are going.'),
       ]),
  dict(code='W_INDIVIDUALISM', KO='개인주의', EN='Individualism', era='현대',
       posture='신앙은 나와 하나님 사이의 사적인 일이다',
       desc_KO='개인주의는 신앙이 개인과 하나님 사이의 사적인 일이라고 '
               '봅니다. 집단이 사람을 짓누르던 경험에서 나왔고, 한 사람의 '
               '양심을 지키려는 뜻이 그 안에 있습니다.\n성경은 한 사람의 '
               '부르심을 귀하게 여기면서도 믿음을 혼자 두지 않습니다. '
               '히브리서는 모이기를 폐하지 말라고 하고, 바울은 눈이 손더러 '
               '쓸데없다 하지 못한다고 적습니다. 사도행전은 처음 교회가 '
               '함께 배우고 함께 떡을 떼었다고 기록합니다. 갈라지는 자리는 '
               '개인의 양심이 아니라 믿음이 혼자 설 수 있느냐입니다.',
       desc_EN='Individualism holds that faith is a private matter between '
               'a person and God. It comes from the experience of groups '
               'crushing persons, and a care to guard one conscience lies '
               'within it.\nScripture honours the calling of one person and '
               'still does not leave faith alone. Hebrews says not to '
               'neglect meeting together, and Paul says the eye cannot '
               'tell the hand I have no need of you. Acts records that the '
               'first church learned together and broke bread together. '
               'The parting of ways is not personal conscience but whether '
               'faith can stand alone.',
       verses=[
         (('히', 10, 25), 'POSTURE',
          '「모이기를 폐하는 어떤 사람들의 습관과 같이 하지 '
          '말고」라고 히브리서가 권합니다. 혼자 서려는 자세를 '
          '습관이라 부릅니다.',
          'Not neglecting to meet together, as is the habit of some. '
          'The writer calls standing alone a habit.'),
         (('고전', 12, 21), 'DISCERN',
          '「눈이 손더러 내가 너를 쓸데없다 하거나」 하지 못한다고 '
          '바울이 적습니다. 몸이라는 그림으로 서로의 필요를 말합니다.',
          'The eye cannot say to the hand, I have no need of you. '
          'Paul makes the point with the picture of a body.'),
         (('전', 4, 9), 'DISCERN',
          '「두 사람이 한 사람보다 나음은 저희가 수고함으로 좋은 상을 '
          '얻을 것임이라」고 합니다. 함께함의 값을 담담하게 셈합니다.',
          'Two are better than one, because they have a good reward '
          'for their toil. The value of company is reckoned plainly.'),
         (('행', 2, 42), 'DISCERN',
          '처음 교회가 「서로 교제하며 떡을 떼며 기도하기를 전혀 '
          '힘쓰니라」고 적혀 있습니다. 믿음이 자리 잡은 모양을 보여 '
          '줍니다.',
          'They devoted themselves to fellowship, to the breaking of '
          'bread and the prayers. It shows the shape faith took.'),
       ]),
  dict(code='W_NATIONALISM', KO='민족주의', EN='Nationalism', era='현대',
       posture='내 민족과 나라가 삶의 중심이고 마지막 자리다',
       desc_KO='민족주의는 내 민족과 나라를 삶의 중심에 둡니다. 남의 '
               '지배를 겪은 자리에서 사람들을 일으켜 세웠고, 제 것을 '
               '사랑하고 지키려는 마음이 그 안에 있습니다.\n성경은 민족을 '
               '없애지 않으면서 그 위에 다른 자리를 둡니다. 요한은 각 '
               '나라와 족속과 백성과 방언에서 나온 큰 무리를 보았고, '
               '바울은 그리스도 예수 안에서 하나라고 적습니다. 요나서는 '
               '니느웨를 아끼시는 하나님으로 닫힙니다. 갈라지는 자리는 제 '
               '민족을 사랑하느냐가 아니라 그것이 마지막 자리에 '
               '서느냐입니다.',
       desc_EN='Nationalism places one’s own people and country at the '
               'centre of life. It raised people up where they had known '
               'foreign rule, and love for one’s own lies within '
               'it.\nScripture does not abolish nations, and it sets '
               'another place above them. John saw a great multitude from '
               'every nation, tribe, people and tongue, and Paul writes '
               'that we are one in Christ Jesus. Jonah closes with a God '
               'who spares Nineveh. The parting of ways is not love of '
               'one’s people but whether it stands in the last place.',
       verses=[
         (('욘', 4, 1), 'POSTURE',
          '「요나가 심히 싫어하고 노하여」라고 적혀 있습니다. 남의 '
          '민족이 긍휼을 입는 것을 견디지 못하는 자리입니다.',
          'But it displeased Jonah exceedingly, and he was angry. '
          'Here is the place that cannot bear another people '
          'receiving mercy.'),
         (('계', 7, 9), 'DISCERN',
          '「각 나라와 족속과 백성과 방언에서 아무라도 능히 셀 수 '
          '없는 큰 무리가」 보좌 앞에 섭니다. 민족이 지워지지 않은 '
          '채로 한자리에 섭니다.',
          'A great multitude from every nation, tribe, people and '
          'language stands before the throne, their peoples not '
          'erased.'),
         (('갈', 3, 28), 'DISCERN',
          '「유대인이나 헬라인이나 종이나 자주자나 남자나 여자 없이 '
          '다 그리스도 예수 안에서 하나이니라」고 합니다. 하나가 되는 '
          '자리를 말합니다.',
          'Neither Jew nor Greek, slave nor free, male nor female, '
          'for you are all one in Christ Jesus. The verse names where '
          'oneness lies.'),
         (('행', 10, 34), 'DISCERN',
          '「하나님은 사람의 외모를 취하지 아니하시고」라고 베드로가 '
          '깨닫습니다. 고넬료의 집에서 본 것을 한 문장으로 적습니다.',
          'God shows no partiality, Peter realizes, putting into one '
          'sentence what he saw in the house of Cornelius.'),
         (('욘', 4, 11), 'DISCERN',
          '「이 큰 성읍, 니느웨에는 좌우를 분변치 못하는 자가 '
          '십이만여 명이요 … 내가 아끼는 것이 어찌 합당치 '
          '아니하냐」로 요나서가 닫힙니다.',
          'Should I not pity Nineveh, that great city, with more than '
          'a hundred and twenty thousand people who do not know their '
          'right hand from their left. So the book ends.'),
       ]),
  dict(code='W_SELFISM', KO='자기 숭배', EN='Cult of self', era='현대',
       posture='나를 사랑하고 나에게 충실한 것이 으뜸이다',
       desc_KO='자기 숭배는 나를 사랑하고 나에게 충실한 것이 으뜸이라고 '
               '봅니다. 자기를 돌보지 못하고 소진되던 사람들에게 숨 쉴 '
               '자리를 주었고, 사람이 귀하다는 감각이 그 안에 '
               '있습니다.\n성경은 사람을 귀하게 여기면서 중심의 자리를 '
               '다르게 둡니다. 바울은 마지막 때에 사람들이 자기를 사랑하게 '
               '되리라고 적고, 겸손한 마음으로 자기보다 남을 낫게 여기라고 '
               '권합니다. 예수께서는 따라오려거든 자기를 부인하라 '
               '하십니다. 갈라지는 자리는 자기를 돌보느냐가 아니라 자기가 '
               '중심에 서느냐입니다.',
       desc_EN='The cult of self holds that loving oneself and being true '
               'to oneself comes first. It gave room to breathe to people '
               'worn out by never tending to themselves, and a sense of '
               'human worth lies within it.\nScripture holds people '
               'precious and places the centre elsewhere. Paul writes that '
               'in the last days people will be lovers of self, and he '
               'urges us in humility to count others more significant. '
               'Jesus says that whoever would follow him must deny '
               'himself. The parting of ways is not self care but whether '
               'the self stands at the centre.',
       verses=[
         (('딤후', 3, 2), 'POSTURE',
          '「사람들은 자기를 사랑하며 돈을 사랑하며」라고 바울이 '
          '마지막 때를 그립니다. 목록의 맨 앞에 자기 사랑이 놓입니다.',
          'People will be lovers of self, lovers of money. Love of '
          "self stands at the head of Paul's list."),
         (('빌', 2, 3), 'DISCERN',
          '「겸손한 마음으로 각각 자기보다 남을 낫게 여기고」라고 '
          '권합니다. 자기를 재는 자리를 옮깁니다.',
          'In humility count others more significant than yourselves. '
          'The place from which we measure ourselves is moved.'),
         (('눅', 9, 23), 'DISCERN',
          '「아무든지 나를 따라오려거든 자기를 부인하고」라고 '
          '하십니다. 따름의 첫 걸음을 말씀하십니다.',
          'If anyone would come after me, let him deny himself. The '
          'first step of following is named.'),
         (('롬', 12, 3), 'DISCERN',
          '「마땅히 생각할 그 이상의 생각을 품지 말고」라고 바울이 '
          '적습니다. 자기를 낮추라는 말이 아니라 바르게 재라는 '
          '말입니다.',
          'Do not think of yourself more highly than you ought. It '
          'does not say think low but think with sober judgment.'),
       ]),
  dict(code='W_SECULARISM', KO='세속주의', EN='Secularism', era='현대',
       posture='신앙은 사적인 영역에 머물러야 한다',
       desc_KO='세속주의는 신앙이 사적인 영역에 머물러야 한다고 봅니다. '
               '종교가 권력과 얽혀 사람을 누르던 역사에서 나왔고, 서로 '
               '다른 믿음이 함께 살 자리를 만들려는 뜻이 그 안에 '
               '있습니다.\n성경은 믿음을 감추는 쪽으로 가지 않습니다. '
               '다니엘은 조서가 내려진 뒤에도 전에 하던 대로 창을 열고 '
               '기도했고, 베드로는 사람보다 하나님을 순종하는 것이 '
               '마땅하다고 답합니다. 예수께서는 빛을 사람 앞에 비취게 하라 '
               '하십니다. 갈라지는 자리는 서로 다른 믿음이 함께 사느냐가 '
               '아니라 믿음이 공적인 자리에서 말할 수 있느냐입니다.',
       desc_EN='Secularism holds that faith belongs in the private sphere. '
               'It arose from a history in which religion entangled with '
               'power pressed on people, and a wish to make room for '
               'different beliefs to live together lies within '
               'it.\nScripture does not move toward hiding faith. Daniel '
               'kept his windows open and prayed as before even after the '
               'decree, and Peter answers that we must obey God rather '
               'than men. Jesus says to let your light shine before '
               'others. The parting of ways is not whether different '
               'beliefs can live together but whether faith may speak in '
               'public.',
       verses=[
         (('단', 6, 7), 'POSTURE',
          '「삼십 일 동안에 누구든지 왕 외에 어느 신에게나 사람에게 '
          '무엇을 구하면」 사자굴에 던지기로 조서를 세웁니다. 신앙을 '
          '공적인 자리에서 지우는 법이 실제로 세워진 자리입니다.',
          'For thirty days anyone who petitions any god or man except '
          'the king is to be thrown to the lions. A law that erases '
          'faith from public life is actually enacted.'),
         (('단', 6, 10), 'DISCERN',
          '「전에 행하던 대로 하루 세 번씩 무릎을 꿇고 기도하며」라고 '
          '적혀 있습니다. 조서가 내린 뒤에도 달라지지 않은 '
          '자리입니다.',
          'He got down on his knees three times a day and prayed as '
          'he had done previously, even after the decree had been '
          'signed.'),
         (('행', 5, 29), 'DISCERN',
          '「사람보다 하나님을 순종하는 것이 마땅하니라」고 사도들이 '
          '답합니다. 두 명령이 부딪히는 자리에서의 대답입니다.',
          'We must obey God rather than men. It is the answer given '
          'where two commands collide.'),
         (('마', 10, 32), 'DISCERN',
          '「누구든지 사람 앞에서 나를 시인하면」이라고 하십니다. '
          '사람 앞이라는 말이 문장 안에 들어 있습니다.',
          'Everyone who acknowledges me before men. The phrase before '
          'men is part of the sentence itself.'),
         (('마', 5, 16), 'DISCERN',
          '「너희 빛을 사람 앞에 비취게 하여」라고 하십니다. 감추는 '
          '것이 아니라 보이게 하라는 말씀입니다.',
          'Let your light shine before others. The word is show, not '
          'hide.'),
       ]),
  dict(code='W_TRANSHUMAN', KO='트랜스휴머니즘', EN='Transhumanism', era='현대',
       posture='기술로 사람의 한계를 넘어 죽음까지 지운다',
       desc_KO='트랜스휴머니즘은 기술로 사람의 한계를 넘어서려 합니다. '
               '병과 노화와 죽음을 줄여 온 실제 성과 위에 서 있고, 고통을 '
               '덜려는 마음이 그 안에 있습니다.\n성경은 몸이 새로워지는 '
               '날을 말하면서 그 길을 다르게 둡니다. 동산에서는 사람이 '
               '손을 들어 생명나무 실과도 따먹을까 하여 길이 막혔고, 두로 '
               '왕은 나는 신이라 하였으나 너는 사람이라는 말을 듣습니다. '
               '바울은 썩을 것이 썩지 아니할 것을 입으리라고 적습니다. '
               '갈라지는 자리는 한계를 줄이려 하느냐가 아니라 그 한계를 '
               '누가 넘어서게 하느냐입니다.',
       desc_EN='Transhumanism seeks to pass beyond human limits by '
               'technology. It stands on real gains against disease, '
               'ageing and death, and a wish to lessen suffering lies '
               'within it.\nScripture speaks of a day when the body is made '
               'new and sets a different road to it. In the garden the way '
               'was barred lest the man reach out and take also of the '
               'tree of life, and the king of Tyre who said I am a god is '
               'told that he is a man. Paul writes that the perishable '
               'must put on the imperishable. The parting of ways is not '
               'reducing limits but who carries us beyond them.',
       verses=[
         (('창', 3, 22), 'DISCERN',
          '「그가 그 손을 들어 생명나무 실과도 따먹고 영생할까 '
          '하노라」고 하십니다. 영생을 손으로 붙잡으려는 자리가 처음 '
          '막힙니다.',
          'Lest he reach out his hand and take also of the tree of '
          'life and live forever. The grasping of endless life is '
          'barred here first.'),
         (('겔', 28, 2), 'POSTURE',
          '「네 마음이 교만하여 말하기를 나는 신이라 … 너는 사람이요 '
          '신이 아니어늘」이라고 하십니다. 사람이 제 한계를 지우려 할 '
          '때 오는 말씀입니다.',
          'Your heart is proud and you say, I am a god, yet you are '
          'but a man. It is the word that comes when a person erases '
          'his own limit.'),
         (('시', 103, 15), 'DISCERN',
          '「인생은 그 날이 풀과 같으며 그 영화가 들의 꽃과 '
          '같도다」라고 합니다. 사람의 유한함을 담담하게 적습니다.',
          'As for man, his days are like grass; he flourishes like a '
          'flower of the field. Human finitude is stated plainly.'),
         (('고전', 15, 53), 'DISCERN',
          '「이 썩을 것이 불가불 썩지 아니할 것을 입겠고」라고 바울이 '
          '적습니다. 몸이 새로워지는 길을 다른 데 둡니다.',
          'This perishable body must put on the imperishable. Paul '
          'locates the renewal of the body elsewhere.'),
       ]),
]


# ── 재료 ──────────────────────────────────────────────────────────────
def _books(conn):
    return {r[0]: r[1] for r in conn.execute(
        "SELECT short_name, book_code FROM book_names WHERE lang_code='KO'")}


def _verse(conn, bk, ch, vs, books=None):
    """`('시',12,4)` → `(verse_id, 본문)` — 없으면 `(None, '')`."""
    books = books or _books(conn)
    bc = books.get(bk)
    if bc is None:
        return None, ''
    r = conn.execute(
        "SELECT i.verse_id, COALESCE(b.verse_text,'')"
        "  FROM bible_index i"
        "  LEFT JOIN bible_content b ON b.verse_id=i.verse_id"
        "   AND b.version_code='KRV'"
        " WHERE i.bcode=? AND i.chapter=? AND i.verse=?", (bc, ch, vs)).fetchone()
    return (r[0], r[1]) if r else (None, '')


# ── 검사 ──────────────────────────────────────────────────────────────
def check(conn, seed=None):
    """`(오류, 경고, 줄)` — 줄에는 **구절 본문**이 실린다(사람이 본다)."""
    seed = SEED if seed is None else seed
    err, warn, rows = [], [], []
    books = _books(conn)
    seen_code, seen_name = set(), set()
    have = {r[0] for r in conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        " AND lang_code='KO' AND COALESCE(record_status,'LIVE')='LIVE'")}
    for w in seed:
        tag = w.get('code') or w.get('KO')
        for k in ('code', 'KO', 'EN', 'posture', 'desc_KO', 'desc_EN'):
            if not (w.get(k) or '').strip():
                err.append('%s: %s 가 비었다' % (tag, k))
        if w['code'] in seen_code:
            err.append('%s: 코드가 두 번 나온다' % tag)
        seen_code.add(w['code'])
        if w['KO'] in seen_name:
            err.append('%s: 이름이 두 번 나온다' % tag)
        seen_name.add(w['KO'])

        # ★ 이름 겹침 — 그 코드가 **이미 그 이름으로** 있는 것은 겹침이 아니다
        mine = conn.execute(
            "SELECT contents FROM sys_text_asset t"
            "  JOIN sys_entity_master m ON m.entity_id=t.clicked_id"
            " WHERE m.entity_code=? AND t.text_type='ENTITY_NAME'"
            "   AND t.lang_code='KO'", (w['code'],)).fetchone()
        if w['KO'] in have and not (mine and mine[0] == w['KO']):
            err.append('%s: 「%s」 라는 이름이 이미 있다' % (tag, w['KO']))

        for lg in ('KO', 'EN'):
            d = (w['desc_' + lg] or '').strip()
            if not (MIN_DESC <= len(d) <= MAX_DESC):
                err.append('%s[%s]: 설명문 %d자 (%d~%d)'
                           % (tag, lg, len(d), MIN_DESC, MAX_DESC))
            if '—' in d or '→' in d:
                err.append('%s[%s]: 「—」·「→」 를 쓰지 않는다' % (tag, lg))
            paras = [p for p in d.split('\n') if p.strip()]
            if len(paras) != 2:
                err.append('%s[%s]: 두 문단이라야 한다 (지금 %d)'
                           % (tag, lg, len(paras)))
            elif lg == 'KO':
                # ★★ **첫 문단은 듣는 자리** — 판정어를 쓰지 않는다
                bad = [v for v in _VERDICT if v in paras[0]]
                if bad:
                    err.append('%s: 첫 문단에 판정어 %s — 이해가 먼저다'
                               % (tag, bad))
                # ⚠ 「봅니다·여깁니다」도 합니다체다 — 어간을 못 박지 않는다
                if not re.search(r'(니다|니까)', paras[0]):
                    err.append('%s: 합니다체로 적는다' % tag)

        if len(w.get('verses') or ()) < 3:
            err.append('%s: 분별 구절이 셋은 있어야 한다' % tag)
        kinds = [v[1] for v in (w.get('verses') or ())]
        bad_k = [k for k in kinds if k not in KINDS]
        if bad_k:
            err.append('%s: 모르는 성격값 %s' % (tag, sorted(set(bad_k))))
        for want in KINDS:
            if want not in kinds:
                err.append('%s: %s 구절이 하나도 없다' % (tag, want))
        for ref, kind, why_ko, why_en in (w.get('verses') or ()):
            vid, txt = _verse(conn, *ref, books=books)
            if vid is None:
                err.append('%s: 없는 절 %r' % (tag, (ref,)))
                continue
            if not txt.strip():
                warn.append('%s: %s 본문이 비었다' % (tag, ref))
            # ★ 「왜 이 구절인가」도 **설명문과 같은 문체**다(합니다체 산문).
            for lg, why in (('KO', why_ko), ('EN', why_en)):
                y = (why or '').strip()
                if not y:
                    err.append('%s: %s 에 「왜 이 구절인가」(%s)가 없다'
                               % (tag, ref, lg))
                    continue
                if not (MIN_WHY <= len(y) <= MAX_WHY):
                    err.append('%s: %s[%s] 까닭이 %d자 (%d~%d)'
                               % (tag, ref, lg, len(y), MIN_WHY, MAX_WHY))
                if '—' in y or '→' in y:
                    err.append('%s: %s[%s] 까닭에 「—」·「→」' % (tag, ref, lg))
                if lg == 'KO' and not re.search(r'(니다|니까)', y):
                    err.append('%s: %s 까닭을 합니다체로 적는다' % (tag, ref))
            rows.append((w['KO'], '%s %d:%d' % ref, txt, why_ko, kind))
    return err, warn, rows


# ── 적재 ──────────────────────────────────────────────────────────────
def apply(conn, seed=None):
    """멱등 — 그 사조의 **구절 연결만** 지우고 다시 넣는다.

    ⚠ 표 이름·쓰는 모양은 `db_term_load` 에서 빌려 온다(두 벌 금지).
    """
    seed = SEED if seed is None else seed
    cur = conn.cursor()
    books = _books(conn)
    n_new = n_up = n_link = 0
    for w in seed:
        r = cur.execute('SELECT entity_id, entity_type FROM sys_entity_master'
                        ' WHERE entity_code=?', (w['code'],)).fetchone()
        if r:
            eid = r[0]
            # ★ **빈 껍데기를 끌어올린다** — 같은 이름으로 하나 더 만들지 않는다
            cur.execute("UPDATE sys_entity_master SET entity_type=?,"
                        " json_detail=?, record_status='LIVE' WHERE entity_id=?",
                        (ETYPE, '{"seed": "%s", "era": "%s"}'
                         % (MARK, w.get('era', '')), eid))
            n_up += 1
        else:
            cur.execute("INSERT INTO sys_entity_master(entity_code, entity_type,"
                        " importance, json_detail, record_status)"
                        " VALUES(?,?,?,?,'LIVE')",
                        (w['code'], ETYPE, 6, '{"seed": "%s", "era": "%s"}'
                         % (MARK, w.get('era', ''))))
            eid = cur.lastrowid
            n_new += 1
        for lg in ('KO', 'EN'):
            TL._upsert_text(cur, eid, 'ENTITY_NAME', lg, w[lg])
            TL._upsert_text(cur, eid, 'ENTITY_DESC', lg, w['desc_' + lg])

        old = [x[0] for x in cur.execute(
            'SELECT %s FROM %s WHERE %s AND %s=?'
            % (TL.EV_ID, TL.EV_TABLE, TL.EV_WHERE, TL.EV_A), (eid,))]
        for oid in old:
            cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                        " AND text_type='ENTITY_VERSE_DESC'", (oid,))
        cur.execute('DELETE FROM %s WHERE %s AND %s=?'
                    % (TL.EV_TABLE, TL.EV_WHERE, TL.EV_A), (eid,))

        # ★ **대표 절 = 첫 POSTURE** — 그 사조가 실제로 드러난 자리가
        #   대표라야 목록 맨 위가 뜻을 갖는다(없으면 첫 절).
        _vv = list(w.get('verses') or ())
        _key = next((i for i, v in enumerate(_vv) if v[1] == 'POSTURE'), 0)
        for i, (ref, kind, why_ko, why_en) in enumerate(_vv):
            vid, _t = _verse(conn, *ref, books=books)
            if vid is None:
                raise SystemExit('없는 절: %r (%s)' % (ref, w['code']))
            cur.execute(
                'INSERT INTO %s(link_type,%s,%s,rel_code,is_key,record_status)'
                " VALUES('%s',?,?,?,?,'LIVE')"
                % (TL.EV_TABLE, TL.EV_A, TL.EV_B, TL.EV_TYPE),
                (eid, vid, kind, 1 if i == _key else 0))
            lid = cur.lastrowid
            TL._upsert_text(cur, lid, 'ENTITY_VERSE_DESC', 'KO', why_ko)
            TL._upsert_text(cur, lid, 'ENTITY_VERSE_DESC', 'EN', why_en)
            n_link += 1
    conn.commit()
    return n_new, n_up, n_link


def undo(conn):
    """이 도구가 심은 것만 걷는다 — 표식으로 좁힌다."""
    cur = conn.cursor()
    ids = [r[0] for r in cur.execute(
        "SELECT entity_id FROM sys_entity_master WHERE entity_type=?"
        "   AND COALESCE(json_detail,'') LIKE ?", (ETYPE, '%' + MARK + '%'))]
    n = 0
    for eid in ids:
        for oid in [x[0] for x in cur.execute(
                'SELECT %s FROM %s WHERE %s AND %s=?'
                % (TL.EV_ID, TL.EV_TABLE, TL.EV_WHERE, TL.EV_A), (eid,))]:
            cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                        " AND text_type='ENTITY_VERSE_DESC'", (oid,))
        cur.execute('DELETE FROM %s WHERE %s AND %s=?'
                    % (TL.EV_TABLE, TL.EV_WHERE, TL.EV_A), (eid,))
        cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                    " AND text_type IN ('ENTITY_NAME','ENTITY_DESC')", (eid,))
        cur.execute('DELETE FROM sys_entity_master WHERE entity_id=?', (eid,))
        n += 1
    conn.commit()
    return n


# ── 렌즈 묵상 ─────────────────────────────────────────────────────────
#: ★★★ **사조를 묵상으로** (1.txt 15번 4) — 사용자 「별도의 묵상플랜으로 만드는
#:   방법 구상 … 성경적 대책/해법/분별/성숙을 위한 권면의 구절 연결도 구분하여
#:   연결해서 묵상플랜을 만들어야 한다」).
#: ★ **한 마디(노드) = 사조 하나**이고 그 안에서 **드러남 → 분별** 차례로 읽는다.
#:   구절 차례를 손으로 적지 않는다 — **성격값이 정한다.**
#: ⚠ **§0-1 샘플 검수 원칙** — 사조 40 을 한꺼번에 넣지 않는다. 첫 편(열 마디)을
#:   적재해 사람이 본 뒤에 나머지 셋을 같은 방식으로 잇는다.
#: ⚠ **단일 절에는 연결설명문을 안 붙인다**(`db_lens_load` 비대칭 규칙) —
#:   「왜 이 구절인가」는 주요용어에 이미 있다. 여기서 또 적으면 두 자리에 산다.
LENSES = {
 'GODLESS': dict(
  name='하나님이 없다는 세상', cat=106,
  desc_KO='하나님을 셈에 넣지 않는 세상에서 성경은 무엇이라 답하는가. '
          '무신론에서 허무주의까지 열 가지 사조가 딛고 선 자세를 먼저 듣고, '
          '그 물음에 성경이 어떻게 답하는지를 나란히 놓고 읽습니다.',
  desc_EN='What does Scripture answer in a world that reckons without God. '
          'Ten movements, from atheism to nihilism, are first heard on their '
          'own terms, and the answer of Scripture is set beside each one.',
  nodes=[
   ('T_ATHEISM',
    '무신론은 신이 계시다는 증거가 충분하지 않다고 보고 세계를 신 없이 '
    '설명합니다. 성경은 그 말을 마음이 먼저 하는 말로 읽고, 지으신 만물이 이미 '
    '말하고 있다고 답합니다.',
    'Atheism holds there is not enough reason to believe in God and explains '
    'the world without him. Scripture reads that as a word the heart speaks '
    'first, and answers that creation is already speaking.',
    '내가 하나님을 믿기 어려운 자리는 증거가 모자란 자리입니까, 마음이 물러선 '
    '자리입니까?',
    'Where I find it hard to believe, is it evidence that is missing, or a '
    'heart that has stepped back?'),
   ('W_MATERIALISM',
    '유물론은 물질이 전부이고 죽으면 끝이라고 봅니다. 바울은 부활이 없다면 그 '
    '결론이 옳다고까지 인정하며, 갈라지는 자리를 부활 하나로 모읍니다.',
    'Materialism holds that matter is all there is and that death ends '
    'everything. Paul grants that the conclusion would follow if there were no '
    'resurrection, and gathers the whole question into that one point.',
    '내가 오늘 쌓고 있는 것은 오늘 밤을 지나서도 내 것입니까?',
    'What I am storing up today, will it still be mine after tonight?'),
   ('W_SCIENTISM',
    '과학주의는 잴 수 있는 것만 참된 지식으로 여깁니다. 하나님은 욥에게 땅의 '
    '기초를 놓을 때 어디 있었느냐 물으시며, 앎을 낮추는 대신 앎이 선 자리를 '
    '물으십니다.',
    'Scientism treats only what can be measured as real knowledge. God asks '
    'Job where he was when the earth was founded, not belittling knowledge but '
    'asking where it stands.',
    '내가 설명할 수 없다는 이유로 접어 둔 물음이 있습니까?',
    'Is there a question I have set aside only because I could not explain '
    'it?'),
   ('W_NATURALISM',
    '진화론적 자연주의는 생명과 사람을 목적 없는 과정의 결과로 봅니다. 성경은 '
    '사람을 하나님의 형상대로 지으셨다고 적으며, 기원만이 아니라 목적을 함께 '
    '말합니다.',
    'Evolutionary naturalism sees life and humanity as the outcome of a '
    'purposeless process. Scripture says people were made in the image of God, '
    'speaking not only of origin but of purpose.',
    '나는 내 값어치를 무엇에서 찾고 있습니까?',
    'Where am I looking for my own worth?'),
   ('W_DEISM',
    '이신론은 하나님이 세상을 지으신 뒤 물러나셨다고 봅니다. 히브리서는 그가 '
    '능력의 말씀으로 만물을 붙드신다고 하고, 예수께서는 참새 한 마리도 아버지 '
    '없이 떨어지지 않는다고 하십니다.',
    'Deism holds that God made the world and then withdrew. Hebrews says he '
    'upholds all things by the word of his power, and Jesus says not one '
    'sparrow falls apart from the Father.',
    '내 삶에서 하나님이 물러나 계시다고 느끼는 자리는 어디입니까?',
    'Where in my life do I feel that God has withdrawn?'),
   ('W_RATIONALISM',
    '합리주의는 이성이 참을 가리는 마지막 법정이라고 봅니다. 잠언은 네 명철을 '
    '의지하지 말라 하고, 이사야는 그분의 생각이 우리 생각보다 높다고 적습니다.',
    'Rationalism holds that reason is the final court of truth. Proverbs says '
    'not to lean on your own understanding, and Isaiah says his thoughts are '
    'higher than ours.',
    '내가 이해할 수 있어야만 받아들이겠다고 버티는 자리가 있습니까?',
    'Is there a place where I refuse to accept anything until I can understand '
    'it?'),
   ('W_ENLIGHT',
    '계몽주의는 스스로 생각할 때 전통의 그늘에서 벗어난다고 보았습니다. '
    '예레미야는 옛적 길 곧 선한 길이 어디인지 알아보고 그리로 행하라고 '
    '권합니다.',
    'The Enlightenment held that thinking for oneself lifts a person out of '
    'the shadow of tradition. Jeremiah urges us to ask for the ancient paths, '
    'where the good way is, and walk in it.',
    '물려받은 것 가운데 내가 묻지도 않고 버린 것이 있습니까?',
    'Is there something handed down to me that I discarded without even '
    'asking?'),
   ('W_SECULARISM',
    '세속주의는 신앙이 사적인 자리에 머물러야 한다고 봅니다. 다니엘은 조서가 '
    '내린 뒤에도 창을 열고 기도했고, 예수께서는 빛을 사람 앞에 비취게 하라 '
    '하십니다.',
    'Secularism holds that faith belongs in the private sphere. Daniel kept '
    'his window open and prayed after the decree, and Jesus says to let your '
    'light shine before others.',
    '사람들 앞에서 나는 어디까지 나를 밝히고 있습니까?',
    'Before others, how far do I let myself be known?'),
   ('W_LIBERALTH',
    '자유주의 신학은 받아들이기 어려운 것을 덜어 내고 윤리를 남기려 했습니다. '
    '바울은 부활이 없으면 전파하는 것도 헛것이라며 남는 것을 스스로 셈합니다.',
    'Liberal theology sought to set aside what is hard to accept and to keep '
    'the ethics. Paul reckons for himself what remains, saying that without '
    'the resurrection the preaching is in vain.',
    '내 믿음에서 슬그머니 빼 놓은 것이 있다면 무엇입니까?',
    'If something has quietly been left out of my faith, what is it?'),
   ('W_NIHILISM',
    '허무주의는 삶에 주어진 뜻이 없다고 봅니다. 전도서는 그 정직함을 끝까지 '
    '밀고 가서 헛되다고 적고, 같은 책이 하나님을 경외하라는 말로 닫힙니다.',
    'Nihilism holds that life carries no given meaning. Ecclesiastes presses '
    'that honesty to the end and calls it vanity, and the same book closes by '
    'telling us to fear God.',
    '헛되다고 느껴지는 그 자리에서 나는 어디로 가고 있습니까?',
    'From the place that feels empty, where am I heading?'),
  ]),
 'SELFCENTER': dict(
  name='사람이 중심에 설 때', cat=106,
  desc_KO='사람을 높이는 자리에서 하나님을 밀어내면 무엇이 달라지는가. '
          '인본주의에서 트랜스휴머니즘까지 열 가지 사조가 사람을 어디에 '
          '세우는지 먼저 듣고, 성경이 사람의 값어치를 어디에서 찾는지를 '
          '나란히 놓고 읽습니다.',
  desc_EN='What changes when the exalting of humanity pushes God aside. Ten '
          'movements, from humanism to transhumanism, are first heard on where '
          'they place a person, and Scripture is set beside them on where human '
          'worth comes from.',
  nodes=[
   ('W_HUMANISM',
    '세속적 인본주의는 사람의 존엄과 이성으로 좋은 삶을 세울 수 있다고 봅니다. '
    '성경도 사람을 높이 보지만 그 높음이 하나님의 형상에서 온다고 말하고, '
    '바벨에서 제 이름을 내려 한 자리를 함께 적어 둡니다.',
    'Secular humanism holds that human dignity and reason can build a good '
    'life. Scripture also holds humanity high, but says that height comes from '
    'the image of God, and it records Babel where people sought a name of their '
    'own.',
    '내가 나를 귀하게 여기는 근거는 어디에서 옵니까?',
    'Where does my sense of my own worth come from?'),
   ('W_INDIVIDUALISM',
    '개인주의는 신앙이 나와 하나님 사이의 사적인 일이라고 봅니다. 성경은 한 '
    '사람의 부르심을 귀하게 여기면서도 모이기를 폐하지 말라 하고, 눈이 손더러 '
    '쓸데없다 하지 못한다고 적습니다.',
    'Individualism holds that faith is a private matter between me and God. '
    'Scripture honours the calling of each person yet tells us not to forsake '
    'assembling, and says the eye cannot tell the hand it has no need of it.',
    '내 믿음에서 다른 사람이 없어도 되는 자리는 어디입니까?',
    'Where in my faith have I decided that other people are optional?'),
   ('W_SELFISM',
    '자기 숭배는 나를 사랑하고 나에게 충실한 것을 으뜸으로 둡니다. 성경은 '
    '사람을 귀하게 여기면서도 겸손한 마음으로 남을 낫게 여기라 하고, 따라오려면 '
    '자기를 부인하라고 하십니다.',
    'The cult of self puts loving and being true to oneself first. Scripture '
    'holds people precious yet tells us in humility to count others better, and '
    'says that whoever would follow must deny himself.',
    '나를 돌보는 일과 나를 중심에 두는 일은 내 안에서 어떻게 갈립니까?',
    'Where does caring for myself end and centring on myself begin?'),
   ('W_CONSUMERISM',
    '소비주의는 무엇을 가지고 무엇을 누리느냐가 사람을 말해 준다고 여깁니다. '
    '예수께서는 사람의 생명이 소유의 넉넉한 데 있지 않다 하시고, 전도자는 은을 '
    '사랑하는 자가 은으로 만족하지 못한다고 적습니다.',
    'Consumerism treats what a person owns and enjoys as what tells us who they '
    'are. Jesus says life does not consist in the abundance of possessions, and '
    'the Preacher says whoever loves silver is never satisfied by silver.',
    '내가 가진 것을 빼고 나면 나는 무엇으로 설명됩니까?',
    'If what I own were taken away, what would be left to describe me?'),
   ('W_PROSPERITY',
    '번영복음은 믿음과 헌금을 건강과 부를 얻는 방법으로 이어 붙입니다. 바울은 '
    '경건을 이익의 재료로 생각하는 자들을 짚고, 베드로는 성령의 권능을 돈으로 '
    '사려 한 사람에게 네 은과 네가 함께 망하라고 말합니다.',
    'The prosperity gospel ties faith and giving to gaining health and wealth. '
    'Paul names those who suppose that godliness is a means of gain, and Peter '
    'tells the man who tried to buy the power of the Spirit that his money '
    'perish with him.',
    '내가 기도할 때 바라는 것은 그분입니까, 그분이 주시는 것입니까?',
    'When I pray, is it him I want, or what he gives?'),
   ('W_PRAGMATISM',
    '실용주의는 쓸모 있게 작동하는 것이 곧 참이라고 봅니다. 대제사장은 한 사람이 '
    '죽는 것이 유익하다는 셈으로 예수를 넘겼고, 잠언은 사람의 보기에 바른 길이 '
    '필경 사망의 길일 수 있다고 적습니다.',
    'Pragmatism holds that whatever works is true. The high priest handed Jesus '
    'over on the reckoning that it was expedient for one man to die, and '
    'Proverbs says a way that seems right to a person can end in death.',
    '되기만 하면 된다고 여기며 넘어간 자리가 있습니까?',
    'Is there a place where I settled for what worked and asked nothing more?'),
   ('W_EXISTENTIAL',
    '실존주의는 주어진 의미가 없으니 내가 선택으로 의미를 만든다고 봅니다. '
    '전도서는 사람에게 영원을 사모하는 마음을 주셨다 하고, 시편은 내 형질이 '
    '이루기 전에 주의 눈이 보셨다고 적습니다.',
    'Existentialism holds that, with no given meaning, a person makes meaning '
    'by choosing. Ecclesiastes says he has set eternity in the human heart, and '
    'the psalm says his eyes saw my unformed substance.',
    '내 삶의 뜻을 나는 만들고 있습니까, 받고 있습니까?',
    'Am I making the meaning of my life, or receiving it?'),
   ('W_MARXISM',
    '마르크스주의는 구조를 바꾸면 사람이 달라진다고 봅니다. 야고보는 품꾼에게 '
    '주지 않은 삯이 소리 지른다 하고 아모스는 공법을 물같이 흘리라고 외치지만, '
    '예수께서는 내 나라가 이 세상에 속한 것이 아니라 하십니다.',
    'Marxism holds that changing the structures changes people. James says the '
    'withheld wages of the labourers cry out and Amos calls for justice to roll '
    'down like waters, yet Jesus says his kingdom is not of this world.',
    '세상을 바꾸는 일과 사람이 새로워지는 일을 나는 어떻게 이어 놓고 있습니까?',
    'How do I hold together changing the world and a person being made new?'),
   ('W_NATIONALISM',
    '민족주의는 내 민족과 나라를 삶의 마지막 자리에 둡니다. 요한은 각 나라와 '
    '족속에서 나온 큰 무리를 보았고, 요나서는 니느웨를 아끼시는 하나님으로 '
    '닫힙니다.',
    'Nationalism puts my people and my country in the final place. John saw a '
    'great multitude from every nation and tribe, and Jonah closes with a God '
    'who cares for Nineveh.',
    '내가 품기 어려운 사람들은 누구이고, 그 까닭은 무엇입니까?',
    'Who are the people I find hard to embrace, and why?'),
   ('W_TRANSHUMAN',
    '트랜스휴머니즘은 기술로 사람의 한계를 넘어 죽음까지 지우려 합니다. 두로 '
    '왕은 나는 신이라 하였으나 너는 사람이라는 말을 들었고, 바울은 썩을 것이 '
    '썩지 아니할 것을 입으리라고 적습니다.',
    'Transhumanism seeks to pass beyond human limits by technology, even undoing '
    'death. The king of Tyre said I am a god and was told you are a man, and '
    'Paul says this corruptible must put on incorruption.',
    '나는 내 한계를 어떻게 대하고 있습니까?',
    'How am I treating my own limits?'),
  ]),
 'WHATISTRUE': dict(
  name='무엇이 참인가', cat=106,
  desc_KO='참이라는 말이 흔들릴 때 무엇을 붙드는가. 상대주의에서 만인구원론까지 '
          '열 가지 사조가 진리를 어디에 두는지 먼저 듣고, 성경이 진리를 누구로 '
          '내놓는지를 나란히 놓고 읽습니다.',
  desc_EN='What is there to hold when the word true begins to slip. Ten '
          'movements, from relativism to universalism, are first heard on where '
          'they place truth, and Scripture is set beside them on the person it '
          'offers as truth.',
  nodes=[
   ('W_RELATIVISM',
    '상대주의는 옳고 그름이 사람마다 다르다고 봅니다. 시편은 우리를 주관할 자 '
    '누구리요 하는 말을 그대로 옮겨 적었고, 사사기는 사람마다 자기 소견에 옳은 '
    '대로 행하였더라로 한 시대를 요약합니다.',
    'Relativism holds that right and wrong differ from person to person. The '
    'psalm records the words who is lord over us, and Judges sums up an age by '
    'saying everyone did what was right in his own eyes.',
    '내가 판단을 삼가는 자리는 존중입니까, 물러섬입니까?',
    'Where I hold back from judging, is it respect or retreat?'),
   ('W_POSTMODERN',
    '포스트모더니즘은 큰 이야기를 힘의 산물로 보고 진리 주장 앞에서 먼저 '
    '의심합니다. 빌라도가 진리가 무엇이냐고 물은 그 자리에 서 계신 분이 스스로 '
    '내가 곧 진리라 하셨습니다.',
    'Postmodernism reads grand narratives as products of power and meets every '
    'truth claim with suspicion first. The one standing before Pilate when he '
    'asked what is truth had said, I am the truth.',
    '의심한 끝에 내가 서 있는 자리는 어디입니까?',
    'When my questioning is done, where am I standing?'),
   ('W_PLURALISM',
    '종교다원주의는 여러 종교가 같은 실재를 저마다의 말로 가리킨다고 봅니다. '
    '사마리아 사람들은 여호와도 경외하고 자기의 신들도 섬겼고, 엘리야는 어느 '
    '때까지 두 사이에서 머뭇거리겠느냐고 물었습니다.',
    'Pluralism holds that the religions point to one reality in their own words. '
    'The Samaritans feared the Lord and served their own gods, and Elijah asked '
    'how long they would halt between two opinions.',
    '나는 이웃을 존중하는 일과 구원의 길을 말하는 일을 어떻게 함께 붙듭니까?',
    'How do I hold together respect for my neighbour and the way of salvation?'),
   ('W_SYNCRETISM',
    '혼합주의는 여러 신앙에서 좋아 보이는 것을 선택해 하나로 엮습니다. 아론은 '
    '금송아지를 세우고 내일은 여호와의 절일이라 공포했고, 스바냐는 여호와께 '
    '맹세하면서 말감을 가리켜 맹세하는 자를 짚습니다.',
    'Syncretism gathers what looks good from several faiths and weaves it into '
    'one. Aaron set up a calf and proclaimed a feast to the Lord for the next '
    'day, and Zephaniah names those who swear by the Lord and by Malcham.',
    '내 믿음 안에 어디서 왔는지 물어본 적 없는 것이 있습니까?',
    'Is there something in my faith whose origin I have never asked about?'),
   ('W_NEWAGE',
    '뉴에이지는 내 안에 신성이 있고 수련으로 그것을 깨운다고 봅니다. 동산에서 '
    '너희가 하나님과 같이 되리라는 말이 들렸고, 신명기는 점과 접신을 금하며 '
    '골로새서는 본 것을 의지해 과장하는 경건을 경계합니다.',
    'New Age holds that a divine spark lies within and is awakened by practice. '
    'In the garden the words you shall be as gods were heard, Deuteronomy '
    'forbids divination and consulting spirits, and Colossians warns of a piety '
    'that inflates itself on what it has seen.',
    '나는 영적인 것을 찾을 때 무엇을 잣대로 삼습니까?',
    'When I reach for the spiritual, what do I measure it by?'),
   ('W_MYSTICISM',
    '신비주의는 직접 겪은 체험을 기록된 말씀 위에 둡니다. 베뢰아 사람들은 들은 '
    '말이 그러한가 하여 날마다 성경을 상고했고, 바울은 하늘로부터 온 천사라도 '
    '다른 복음을 전하면 받지 말라고 합니다.',
    'Mysticism sets direct experience above the written word. The Bereans '
    'searched the Scriptures daily to see whether what they heard was so, and '
    'Paul says that even an angel from heaven preaching another gospel is not '
    'to be received.',
    '내 체험을 나는 무엇으로 재고 있습니까?',
    'By what do I measure my own experience?'),
   ('W_GNOSTICISM',
    '영지주의는 물질을 낮게 보고 은밀한 앎이 사람을 건진다고 여겼습니다. 창세기 '
    '첫 장은 지으신 모든 것을 보시고 심히 좋았다고 적고, 요한은 예수께서 육체로 '
    '오신 것을 시인하느냐로 영을 분별하라 합니다.',
    'Gnosticism looked down on matter and held that secret knowledge rescues. '
    'The first chapter of Genesis says God saw everything he had made and it was '
    'very good, and John tells us to test the spirits by whether they confess '
    'that Jesus Christ has come in the flesh.',
    '나는 몸으로 사는 일을 신앙에서 어디에 두고 있습니까?',
    'Where does bodily life stand in my faith?'),
   ('W_DOCETISM',
    '가현설은 그리스도의 몸을 겉보기로 보았습니다. 요한은 말씀이 육신이 되어 '
    '우리 가운데 거하셨다고 적고, 부활하신 예수께서는 도마에게 손과 옆구리를 '
    '만져 보라 하십니다.',
    'Docetism took the body of Christ to be only an appearance. John writes that '
    'the Word became flesh and dwelt among us, and the risen Jesus tells Thomas '
    'to touch his hands and his side.',
    '하나님이 사람이 되셨다는 말이 내 하루와 어디서 만납니까?',
    'Where does God becoming man meet my ordinary day?'),
   ('W_ARIANISM',
    '아리우스주의는 하나님의 유일하심을 지키려고 아들을 지음받은 존재로 두었습니다. '
    '요한은 이 말씀이 곧 하나님이시라고 복음서를 열고, 히브리서는 아들을 향해 '
    '하나님이여라고 부릅니다.',
    'Arianism, to guard that God is one, placed the Son among created things. '
    'John opens his Gospel saying the Word was God, and Hebrews addresses the '
    'Son as God.',
    '내가 아는 예수는 누구까지입니까?',
    'How far does the Jesus I know reach?'),
   ('W_UNIVERSALISM',
    '만인구원론은 사랑이신 하나님이 끝내 아무도 잃지 않으시리라고 봅니다. 성경은 '
    '아무도 멸망치 않기를 원하신다고 적으면서, 생명으로 인도하는 문이 좁다는 말을 '
    '같은 입으로 하십니다.',
    'Universalism holds that a God of love will in the end lose no one. Scripture '
    'says he is not willing that any should perish, and the same lips say that '
    'the gate leading to life is narrow.',
    '내가 전하지 않고 미뤄 둔 사람이 있습니까?',
    'Is there someone I have kept putting off telling?'),
  ]),
 'BENDING': dict(
  name='믿음이 굽는 자리', cat=106,
  desc_KO='무엇으로 하나님 앞에 서려 하는가. 율법주의에서 스토아주의까지 열 가지 '
          '사조가 사람을 어디에 기대게 하는지 먼저 듣고, 성경이 우리를 세우는 '
          '근거를 어디에 두는지를 나란히 놓고 읽습니다.',
  desc_EN='On what does a person try to stand before God. Ten movements, from '
          'legalism to Stoicism, are first heard on what they lean upon, and '
          'Scripture is set beside them on the ground it gives us to stand on.',
  nodes=[
   ('W_LEGALISM',
    '율법주의는 믿음에 더해 지켜야 할 것이 있어야 하나님 앞에 선다고 봅니다. '
    '바울은 율법의 행위로는 의롭다 함을 얻을 육체가 없다 하고, 예루살렘 회의는 '
    '조상도 메지 못하던 멍에를 다시 지우지 말라고 결정합니다.',
    'Legalism holds that one stands before God by faith plus something kept. '
    'Paul says no flesh is justified by the works of the law, and the council at '
    'Jerusalem decided not to lay again a yoke the fathers could not bear.',
    '내가 하나님께 받아들여졌다고 느끼는 날은 무엇을 해낸 날입니까?',
    'On what kind of day do I feel accepted by God?'),
   ('W_ANTINOMIAN',
    '반율법주의는 은혜 아래 있으니 행실은 셈에 들지 않는다고 봅니다. 바울은 은혜를 '
    '더하게 하려고 죄에 거하겠느냐고 묻고, 야고보는 행함이 없는 믿음은 그 자체가 '
    '죽은 것이라 합니다.',
    'Antinomianism holds that under grace conduct no longer counts. Paul asks '
    'whether we shall continue in sin that grace may abound, and James says '
    'faith without works is dead in itself.',
    '은혜를 말하며 그냥 두고 있는 자리가 있습니까?',
    'Is there something I leave untouched while calling it grace?'),
   ('W_PELAGIAN',
    '펠라기우스주의는 사람이 마음만 먹으면 스스로 선을 이룰 수 있다고 보았습니다. '
    '바울은 허물과 죄로 죽었던 우리를 살리셨다고 적고, 예수께서는 나를 떠나서는 '
    '아무것도 할 수 없다고 하십니다.',
    'Pelagianism held that a person can achieve good by sheer resolve. Paul '
    'writes that God made us alive when we were dead in trespasses, and Jesus '
    'says that apart from him we can do nothing.',
    '내가 마음만 먹으면 된다고 여겼다가 무너진 자리가 있습니까?',
    'Where did I assume resolve would be enough, and find it was not?'),
   ('W_MERIT',
    '공로주의는 쌓은 선행과 고행이 하나님 앞에서 값을 낸다고 봅니다. 바울은 일하는 '
    '자에게 삯이 빚으로 여겨진다고 하며 다른 길을 말하고, 이사야는 우리의 의가 '
    '더러운 옷 같다고 적습니다.',
    'Merit holds that accumulated good works and austerities count before God. '
    'Paul says wages are reckoned as a debt to the one who works, and points to '
    'another way, while Isaiah says our righteousnesses are as filthy rags.',
    '내가 하나님께 내밀고 있는 값은 무엇입니까?',
    'What am I holding out to God as payment?'),
   ('W_CLERICALISM',
    '성직주의는 하나님께 나아가는 길이 정해진 사람들의 손을 거쳐야 한다고 봅니다. '
    '바울은 하나님과 사람 사이의 중보가 한 분이라 하고, 베드로는 믿는 이들을 왕 '
    '같은 제사장이라 부릅니다.',
    'Clericalism holds that the way to God must pass through appointed hands. '
    'Paul says there is one mediator between God and men, and Peter calls '
    'believers a royal priesthood.',
    '내가 하나님께 직접 나아가기를 미루는 자리가 있습니까?',
    'Is there a place where I put off coming to God myself?'),
   ('W_SUPERSTITION',
    '미신은 거룩한 물건과 정해진 절차 자체에 힘이 있다고 여깁니다. 이스라엘은 '
    '언약궤를 전장으로 가져가면 이길 줄 알았고, 모세의 놋뱀은 세월이 지나 분향의 '
    '대상이 되어 히스기야가 부수었습니다.',
    'Superstition treats holy objects and set procedures as powerful in '
    'themselves. Israel thought carrying the ark into battle would win the day, '
    'and the bronze serpent of Moses became an object of incense until Hezekiah '
    'broke it.',
    '내가 붙들고 있는 것 가운데 그분을 대신하고 있는 것이 있습니까?',
    'Is there something I hold onto that has taken his place?'),
   ('W_FATALISM',
    '운명론은 앞날이 이미 정해졌으니 별과 징조에서 그것을 읽으려 합니다. 이사야는 '
    '별을 보는 자들이 정작 구원하지 못한다 하고, 잠언은 사람이 길을 계획할지라도 '
    '걸음을 인도하시는 분이 계시다고 적습니다.',
    'Fatalism holds that the future is already fixed and reads it in stars and '
    'omens. Isaiah says the stargazers cannot save, and Proverbs says a person '
    'plans the way but the Lord directs the steps.',
    '앞날이 두려울 때 나는 무엇을 먼저 찾습니까?',
    'When the future frightens me, what do I reach for first?'),
   ('W_EMPEROR',
    '황제 숭배는 질서를 지키는 권력에 신성을 입혔습니다. 예수께서는 가이사의 것과 '
    '하나님의 것을 나누어 말씀하시고, 세 친구는 그리 아니하실지라도 금신상에 '
    '절하지 않겠다고 답합니다.',
    'Emperor worship clothed the power that kept order with divinity. Jesus '
    'distinguished what belongs to Caesar from what belongs to God, and the '
    'three friends answered that even if he does not deliver them they will '
    'not bow.',
    '내가 두려워서 고개를 숙이는 자리는 어디입니까?',
    'Where do I bow because I am afraid?'),
   ('W_EPICUREAN',
    '에피쿠로스주의는 신이 사람 일에 관여하지 않으니 두려움을 놓고 즐거움을 '
    '누리라고 가르쳤습니다. 빌립보서는 저희의 신은 배라고 하고, 전도서는 낙을 '
    '누려 본 사람이 그것도 헛되더라고 적습니다.',
    'Epicureanism taught that the gods do not meddle in human affairs, so lay '
    'down fear and enjoy measured pleasure. Philippians says their god is their '
    'belly, and the Preacher, who tasted pleasure, calls it vanity too.',
    '내가 누리는 즐거움은 나를 어디로 데려가고 있습니까?',
    'Where are my pleasures taking me?'),
   ('W_STOIC',
    '스토아주의는 이치에 순응하고 감정에 흔들리지 않는 것을 덕으로 삼았습니다. '
    '바울의 자족은 감정을 눌러 얻은 것이 아니라 붙드시는 분에게서 배운 것이고, '
    '예수께서는 무덤 앞에서 우셨습니다.',
    'Stoicism made a virtue of yielding to reason and remaining unmoved by '
    'feeling. The contentment Paul speaks of was not gained by suppressing '
    'emotion but learned from the one who holds him, and Jesus wept at a tomb.',
    '나는 견디는 힘을 어디에서 얻고 있습니까?',
    'Where does my strength to endure come from?'),
  ]),
}


def lens_draft(key='GODLESS'):
    """`db_lens_load` 초안(dict) — **씨앗에서 짓는다**(구절을 두 번 적지 않는다)."""
    L = LENSES[key]
    by = {w['code']: w for w in SEED}
    nodes = []
    for code, dk, de, qk, qe in L['nodes']:
        w = by[code]
        vs = ([v for v in w['verses'] if v[1] == 'POSTURE']
              + [v for v in w['verses'] if v[1] == 'DISCERN'])
        nodes.append({
            'name': w['KO'],
            'desc': {'KO': dk, 'EN': de},
            'question': {'KO': qk, 'EN': qe},
            'verses': [{'ref': '%s %d:%d' % v[0]} for v in vs],
        })
    return {'lens': L['name'], 'cat': L['cat'],
            'desc': {'KO': L['desc_KO'], 'EN': L['desc_EN']},
            'nodes': nodes}


def lens_write(key='GODLESS'):
    """초안을 `_lens_prep/` 에 쓰고 그 경로를 돌려준다."""
    import json
    import os
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_lens_prep')
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, 'worldview_%s.json' % key.lower())
    io.open(p, 'w', encoding='utf-8').write(
        json.dumps(lens_draft(key), ensure_ascii=False, indent=1))
    return p


# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest():
    """★ 의무. **재료를 만들어서 잰다** — 실 DB 상태를 전제하지 않는다(§0-5)."""
    print('db_worldview 자가 검증')
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    c = appdb.connect()
    err, warn, rows = check(c)
    t('★★★ 씨앗이 검사를 통과한다', not err, err[:3])
    t('★ 구절 본문이 실제로 딸려 나온다',
      rows and all(r[2].strip() for r in rows), len(rows))
    t('★★★ 사조마다 **드러남과 분별이 짝으로** 있다',
      all(set(KINDS) <= {v[1] for v in w['verses']} for w in SEED))
    t('  경고 0', not warn, warn[:2])

    # ★★ 탐지력 — 규칙마다 일부러 어겨 본다
    import copy
    base = copy.deepcopy(SEED[0])

    def bad(mut, why):
        w = copy.deepcopy(base)
        mut(w)
        e, _w, _r = check(c, [w])
        t('★★ %s 를 잡는다' % why, bool(e), e[:1])

    bad(lambda w: w.update(desc_KO=w['desc_KO'].replace('\n', ' ')), '한 문단')
    bad(lambda w: w.update(desc_KO='짧다'), '너무 짧은 설명문')
    bad(lambda w: w.update(desc_KO=w['desc_KO'].replace('무신론은', '무신론은 틀렸고')),
        '첫 문단의 판정어')
    bad(lambda w: w.update(desc_KO=w['desc_KO'].replace('합니다', '한다 —')),
        '「—」 기호')
    bad(lambda w: w.update(verses=w['verses'][:2]), '구절이 셋 미만')
    bad(lambda w: w.update(
        verses=[(('없', 1, 1), 'POSTURE', 'x' * 50, 'y' * 50)]
               + list(w['verses'])), '없는 절')
    bad(lambda w: w.update(verses=[(r, k, '', e)
                                   for r, k, _x, e in w['verses']]),
        '「왜 이 구절인가」 없음')
    bad(lambda w: w.update(verses=[(r, 'DISCERN', x, e)
                                   for r, _k, x, e in w['verses']]),
        '★★ POSTURE 가 하나도 없음')
    bad(lambda w: w.update(verses=[(r, 'POSTURE', x, e)
                                   for r, _k, x, e in w['verses']]),
        '★★ DISCERN 이 하나도 없음')
    bad(lambda w: w.update(verses=[(r, 'NOPE', x, e)
                                   for r, _k, x, e in w['verses']]),
        '모르는 성격값')
    bad(lambda w: w.update(verses=[(r, k, '짧다', e)
                                   for r, k, _x, e in w['verses']]),
        '너무 짧은 까닭')
    bad(lambda w: w.update(
        verses=[(r, k, x.replace('다.', '다 — ', 1), e)
                for r, k, x, e in w['verses']]), '까닭의 「—」')
    bad(lambda w: w.update(
        verses=[(r, k, x.replace('니다', '다'), e)
                for r, k, x, e in w['verses']]), '까닭의 문체')

    # ★ 이름 겹침 — 이미 있는 이름을 다른 코드로 넣으면 막는다
    w = copy.deepcopy(base)
    w['code'] = 'W_NOSUCH_TEST'
    e, _w, _r = check(c, [w])
    t('★★ 이름 겹침을 잡는다', bool(e), e[:1])
    # …그런데 **제 코드로는 안 걸린다**(끌어올리기)
    e2, _w, _r = check(c, [base])
    t('★★ 제 코드면 겹침이 아니다', not e2, e2[:1])

    t('★ 유형이 등록돼 있다', _type_ok(), '')

    # ★★ 렌즈 초안 — **`db_lens_load` 게이트를 그대로 통과해야 한다**
    try:
        import db_lens_load as _LL
        d = lens_draft()
        # ⚠ `validate` 는 **막는 것만** 돌려준다(경고는 찍기만 한다)
        errs2 = _LL.validate(c, d, verbose=False)
        t('★★★ 렌즈 초안이 게이트를 통과한다', not errs2, errs2[:2])
        t('★★ 마디가 규격(7~12) 안', 7 <= len(d['nodes']) <= 12,
          len(d['nodes']))
        # ★ 차례 = **드러남 먼저** — 성격값이 정한다
        by = {w['code']: w for w in SEED}
        first_ok = all(
            by[code]['verses'] and
            n['verses'][0]['ref'] == '%s %d:%d' % next(
                v[0] for v in by[code]['verses'] if v[1] == 'POSTURE')
            for n, (code, *_r) in zip(d['nodes'], LENSES['GODLESS']['nodes']))
        t('★★★ 마디마다 **드러남을 먼저** 읽는다', first_ok)
    except Exception as e:                                # noqa: BLE001
        t('★★ 렌즈 초안 검사', False, repr(e)[:80])
    c.close()
    print('\ndb_worldview selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def _type_ok():
    try:
        import entity_types as ET
        return ETYPE in ET.CODES and ET.label(ETYPE, 'KO') != ETYPE
    except Exception:                                     # noqa: BLE001
        return False


# ── CLI ───────────────────────────────────────────────────────────────
def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--lens', metavar='KEY', nargs='?', const='GODLESS',
                    help='렌즈 묵상 초안을 짓는다(적재는 db_lens_load)')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)

    conn = appdb.connect()
    if a.undo:
        print('걷은 사조 %d개' % undo(conn))
        return
    if a.lens:
        d = lens_draft(a.lens)
        p = lens_write(a.lens)
        print('초안 %s' % p)
        print('렌즈 「%s」 · 마디 %d · 구절 %d'
              % (d['lens'], len(d['nodes']),
                 sum(len(n['verses']) for n in d['nodes'])))
        print('적재 = python db_lens_load.py --apply %s' % p)
        return
    err, warn, rows = check(conn)
    cur = None
    _KN = {'POSTURE': '드러남', 'DISCERN': '분별'}
    for ko, ref, txt, why, kind in rows:
        if ko != cur:
            cur = ko
            print('\n== %s ==' % ko)
        print('  [%s] %-9s %s' % (_KN.get(kind, kind), ref, txt[:60]))
        print('  %-14s ↳ %s' % ('', why))
    print()
    for w in warn:
        print('  ! ' + w)
    for e in err:
        print('  X ' + e)
    if err:
        print('\n검증 FAIL — 오류 %d건' % len(err))
        sys.exit(1)
    _np = sum(1 for r in rows if r[4] == 'POSTURE')
    print('검증 PASS — 사조 %d개 · 구절 %d개 (드러남 %d · 분별 %d)'
          % (len(SEED), len(rows), _np, len(rows) - _np))
    if a.apply:
        n_new, n_up, n_link = apply(conn)
        print('신설 %d · 끌어올림 %d · 구절 연결 %d' % (n_new, n_up, n_link))


if __name__ == '__main__':
    main()
