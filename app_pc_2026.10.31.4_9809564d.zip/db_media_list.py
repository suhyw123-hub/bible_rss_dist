# -*- coding: utf-8 -*-
"""재생목록 — **이 차례로 이어 들을 것**(2026-09-10 신설).

사용자 지시(0.txt 1-2) 「이어듣기 자동재생목록 관리화면이 필요하다. **즐겨찾기
전체가 아니라 즐겨찾기 목록 중에서 선택해서 별도 보관함**을 만들고 보관함에
들어 있는 "성경듣기 + 찬양듣기"에 대하여 이어듣기 버튼을 여기에서 클릭한다」
· 「**재생목록에서 재생순서를 조절할 수 있도록 하라**」.

★★★ **즐겨찾기와 다른 물건이다.**
  | | 즐겨찾기(`user_media_fav`) | 재생목록(여기) |
  |---|---|---|
  | 뜻 | 나중에 볼 것 | **이 차례로** 이어 들을 것 |
  | 차례 | 담은 날 순(바꿀 수 없다) | **사람이 정한다** |
  | 개수 | 한 뭉치 | 여러 개(이름을 붙인다) |
  **차례가 있다**는 것이 갈라지는 자리다 — 즐겨찾기에 차례를 얹으면 「나중에
  볼 것」과 「지금 틀 차례」가 한 값에 섞인다.

⚠⚠ **개인 것이라 `user_*` 에 담는다**(§C-2). 배포용 `bible_master.db` 에 쓰면
  다음 배포에 통째로 날아간다.
⚠ 이 파일은 **데이터 층**이다 — 위젯이 없고 화면은 이 문만 부른다(§121차).
  그래야 화면이 `sys_media_asset` 을 직접 안 읽는다.
⚠ **차례는 성기게 매긴다**(10, 20, 30…) — 가운데 끼워 넣을 때 뒤를 다 안 민다.

명령
  --selftest   자가검증(의무)
  --list       지금 있는 재생목록
"""
import io
import sys

STEP = 10                       # 차례 간격 — 성기게 매긴다
TBL = 'user_media_list'
ITEM = 'user_media_list_item'


def _db():
    import appdb
    return appdb.MAIN_DB


def ensure(conn):
    """표 둘을 만든다(멱등).

    ⚠ `userdb.` 로 못 박는다 — 이름만 쓰면 어느 DB 에 생길지 상황에 달린다.
    """
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.%s ("
        " list_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " name TEXT NOT NULL,"
        " created_at TEXT DEFAULT (datetime('now')),"
        " record_status TEXT DEFAULT 'LIVE')" % TBL)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.%s ("
        " list_id INTEGER NOT NULL,"
        " media_id INTEGER NOT NULL,"
        " sort_order INTEGER NOT NULL DEFAULT 0,"
        " added_at TEXT DEFAULT (datetime('now')),"
        " PRIMARY KEY (list_id, media_id))" % ITEM)
    conn.execute("CREATE INDEX IF NOT EXISTS userdb.idx_media_list_ord"
                 " ON %s(list_id, sort_order)" % ITEM)


# ── 목록 ────────────────────────────────────────────────────────────────
def lists(conn):
    """[(list_id, 이름, 편 수)] — 만든 차례."""
    ensure(conn)
    return [(r[0], r[1], r[2]) for r in conn.execute(
        "SELECT l.list_id, l.name,"
        "       (SELECT COUNT(*) FROM userdb.%s i WHERE i.list_id=l.list_id)"
        "  FROM userdb.%s l"
        " WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
        " ORDER BY l.list_id" % (ITEM, TBL))]


def add_list(conn, name):
    """새 재생목록 → list_id. **이름이 비면 안 만든다.**

    ⚠ 같은 이름을 막지 않는다 — 사람이 「주일」을 둘 만들 수도 있고, 열쇠는
      번호다. 다만 화면이 그 사실을 보이게 이름을 그대로 낸다.
    """
    ensure(conn)
    nm = (name or '').strip()
    if not nm:
        return None
    cur = conn.execute("INSERT INTO userdb.%s(name) VALUES(?)" % TBL, (nm,))
    return cur.lastrowid


def rename(conn, list_id, name):
    nm = (name or '').strip()
    if not nm:
        return False
    ensure(conn)
    conn.execute("UPDATE userdb.%s SET name=? WHERE list_id=?" % TBL,
                 (nm, int(list_id)))
    return True


def drop(conn, list_id):
    """재생목록을 걷는다.

    ⚠ **줄은 지운다** — 목록이 없어졌는데 줄만 남으면 주인 없는 행이 쌓인다.
      목록 자체는 `HIDE` 로 남겨 되살릴 자리를 둔다.
    """
    ensure(conn)
    conn.execute("DELETE FROM userdb.%s WHERE list_id=?" % ITEM, (int(list_id),))
    conn.execute("UPDATE userdb.%s SET record_status='HIDE' WHERE list_id=?"
                 % TBL, (int(list_id),))
    return True


# ── 줄 ──────────────────────────────────────────────────────────────────
def ids(conn, list_id):
    """그 목록의 영상 번호 — **정한 차례 그대로**."""
    ensure(conn)
    return [r[0] for r in conn.execute(
        "SELECT media_id FROM userdb.%s WHERE list_id=?"
        " ORDER BY sort_order, media_id" % ITEM, (int(list_id),))]


def items(conn, list_id, pref=None):
    """[(media_id, 제목, url, 설명문)] — **정한 차례 그대로**.

    ★ 화면이 `sys_media_asset` 을 직접 안 읽는 자리다(§121차).
    ⚠ `pref` = `media_pref.load(...)` — 주면 내가 숨긴 것을 뺀다(§226차).
    ⚠ **승인된 것만**(§194차) · 지워진 영상은 저절로 빠진다(JOIN).
    """
    ensure(conn)
    out = []
    for mid, ti, url, d in conn.execute(
            "SELECT a.media_id, a.title, a.url, COALESCE(a.description,'')"
            "  FROM userdb.%s i"
            "  JOIN sys_media_asset a ON a.media_id=i.media_id"
            " WHERE i.list_id=? AND a.record_status='LIVE' AND a.is_active=1"
            " ORDER BY i.sort_order, i.media_id" % ITEM, (int(list_id),)):
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or ''))
    return out


def add(conn, list_id, media_ids):
    """맨 뒤에 붙인다 → 새로 붙은 수.

    ⚠ 이미 있으면 **차례를 안 건드린다** — 다시 누를 때마다 뒤로 밀리면
      애써 잡아 둔 차례가 무너진다.
    """
    ensure(conn)
    lid = int(list_id)
    have = set(ids(conn, lid))
    r = conn.execute("SELECT MAX(sort_order) FROM userdb.%s WHERE list_id=?"
                     % ITEM, (lid,)).fetchone()
    nxt = int((r[0] or 0)) + STEP
    n = 0
    for m in (media_ids if isinstance(media_ids, (list, tuple, set))
              else [media_ids]):
        if m is None or int(m) in have:
            continue
        conn.execute("INSERT INTO userdb.%s(list_id, media_id, sort_order)"
                     " VALUES(?,?,?)" % ITEM, (lid, int(m), nxt))
        have.add(int(m))
        nxt += STEP
        n += 1
    return n


def remove(conn, list_id, media_ids):
    ensure(conn)
    ms = (media_ids if isinstance(media_ids, (list, tuple, set))
          else [media_ids])
    ms = [int(m) for m in ms if m is not None]
    if not ms:
        return 0
    conn.execute("DELETE FROM userdb.%s WHERE list_id=? AND media_id IN (%s)"
                 % (ITEM, ','.join('?' * len(ms))), [int(list_id)] + ms)
    return len(ms)


def move(conn, list_id, media_id, delta):
    """한 칸 위/아래로 → 옮겼으면 True.

    ★★★ **차례를 사람이 정한다**(2026-09-10 사용자 「재생목록에서 재생순서를
      조절할 수 있도록 하라」).
    ⚠ 끝에서 더 가려 하면 **아무 일도 안 한다**(조용히 자리를 바꾸지 않는다).
    ⚠ 두 줄의 `sort_order` 가 같을 수 있으므로 **번호를 다시 매긴 뒤** 바꾼다 —
      안 그러면 서로 자리를 못 넘는다.
    """
    ensure(conn)
    lid = int(list_id)
    cur = ids(conn, lid)
    if int(media_id) not in cur:
        return False
    i = cur.index(int(media_id))
    j = i + (1 if int(delta) > 0 else -1)
    if j < 0 or j >= len(cur):
        return False
    cur[i], cur[j] = cur[j], cur[i]
    return set_order(conn, lid, cur)


def set_order(conn, list_id, media_ids):
    """차례를 통째로 다시 매긴다 → True.

    ⚠ **목록에 없는 번호는 무시한다** · 빠뜨린 것은 뒤에 그대로 붙인다
      (화면이 실수로 한 줄을 흘려도 그 줄이 사라지면 안 된다).
    """
    ensure(conn)
    lid = int(list_id)
    have = ids(conn, lid)
    want = [int(m) for m in (media_ids or []) if int(m) in have]
    want += [m for m in have if m not in want]
    for k, m in enumerate(want):
        conn.execute("UPDATE userdb.%s SET sort_order=? WHERE list_id=?"
                     " AND media_id=?" % ITEM, ((k + 1) * STEP, lid, m))
    return True


def in_lists(conn, media_id):
    """그 영상이 든 재생목록 [(list_id, 이름)] — 화면이 ★ 를 그린다."""
    ensure(conn)
    return [(r[0], r[1]) for r in conn.execute(
        "SELECT l.list_id, l.name FROM userdb.%s i"
        "  JOIN userdb.%s l ON l.list_id=i.list_id"
        " WHERE i.media_id=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
        " ORDER BY l.list_id" % (ITEM, TBL), (int(media_id),))]


# ── 자가검증 ────────────────────────────────────────────────────────────
def selftest():
    import appdb
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0 if cond else 1] += 1
        print(('  OK   ' if cond else '  실패 ') + name
              + ('' if cond else '  ' + str(extra)))

    conn = appdb.connect(_db())
    try:
        conn.execute('BEGIN')
        ensure(conn)
        ensure(conn)
        t('★ 표를 두 번 만들어도 된다(멱등)', True)
        n0 = len(lists(conn))
        lid = add_list(conn, ' 잠들 때 ')
        t('★ 재생목록을 만든다 · 이름 앞뒤 공백을 걷는다',
          lid and [x for x in lists(conn) if x[0] == lid][0][1] == '잠들 때')
        t('★ 빈 이름은 안 만든다',
          add_list(conn, '   ') is None and len(lists(conn)) == n0 + 1)

        # 실제 영상 넷을 담는다
        mids = [r[0] for r in conn.execute(
            "SELECT media_id FROM sys_media_asset WHERE record_status='LIVE'"
            "   AND is_active=1 AND media_type IN ('WORSHIP','READING')"
            " ORDER BY media_id LIMIT 4")]
        if len(mids) < 4:
            t('★ 표본 영상 넷', False, mids)
        else:
            t('★ 뒤에 붙는다', add(conn, lid, mids) == 4
              and ids(conn, lid) == mids)
            t('★★ **다시 붙여도 차례가 안 바뀐다**',
              add(conn, lid, mids) == 0 and ids(conn, lid) == mids)
            t('★ 편 수를 센다',
              [x for x in lists(conn) if x[0] == lid][0][2] == 4)

            # ★★★ 차례 조절
            t('★★★ **한 칸 아래로**',
              move(conn, lid, mids[0], +1)
              and ids(conn, lid) == [mids[1], mids[0], mids[2], mids[3]])
            t('★★★ **한 칸 위로**',
              move(conn, lid, mids[0], -1) and ids(conn, lid) == mids)
            t('★★ 맨 위에서 더 위로는 **아무 일도 안 한다**',
              move(conn, lid, mids[0], -1) is False
              and ids(conn, lid) == mids)
            t('★★ 맨 아래에서 더 아래로도 마찬가지',
              move(conn, lid, mids[3], +1) is False
              and ids(conn, lid) == mids)
            t('★ 목록에 없는 영상은 못 옮긴다',
              move(conn, lid, -999, +1) is False)
            t('★★ 차례를 통째로 뒤집는다',
              set_order(conn, lid, list(reversed(mids)))
              and ids(conn, lid) == list(reversed(mids)))
            t('★★ **빠뜨린 줄은 사라지지 않는다**(뒤에 붙는다)',
              set_order(conn, lid, [mids[2]])
              and set(ids(conn, lid)) == set(mids)
              and ids(conn, lid)[0] == mids[2])

            set_order(conn, lid, mids)
            got = items(conn, lid)
            t('★★ 본문을 정한 차례 그대로 낸다',
              [g[0] for g in got] == [m for m in mids
                                      if m in [g[0] for g in got]])
            t('★ 제목·주소가 함께 온다', all(g[1] for g in got))

            # 덮개
            import media_pref
            pr = media_pref.Pref(hide_m={mids[0]})
            t('★★ **내가 숨긴 영상은 안 나온다**(§226차 덮개)',
              mids[0] not in [g[0] for g in items(conn, lid, pref=pr)])

            t('★ 그 영상이 어느 목록에 있는지 안다',
              lid in [x[0] for x in in_lists(conn, mids[0])])
            t('★ 한 줄을 뺀다',
              remove(conn, lid, mids[0]) == 1
              and mids[0] not in ids(conn, lid))

        # 지우기
        drop(conn, lid)
        t('★★ 지우면 목록에서 빠지고 **줄도 함께 지운다**',
          lid not in [x[0] for x in lists(conn)]
          and conn.execute("SELECT COUNT(*) FROM userdb.%s WHERE list_id=?"
                           % ITEM, (lid,)).fetchone()[0] == 0)

        # ⚠ 배포 DB 에 쓰지 않는다
        t('★★★ **배포 DB(main)에 표를 만들지 않는다**',
          conn.execute("SELECT COUNT(*) FROM main.sqlite_master"
                       " WHERE name IN (?,?)", (TBL, ITEM)).fetchone()[0] == 0)
        t('★ 개인 DB(userdb)에 있다',
          conn.execute("SELECT COUNT(*) FROM userdb.sqlite_master"
                       " WHERE name IN (?,?)", (TBL, ITEM)).fetchone()[0] == 2)
        # ⚠ **제 글자에 걸리는 함정**(§199차) — 이름을 글로 적어 찾으면 이
        #   검사 코드 자체가 걸린다. 실제로 한 번 걸렸다. ⇒ **import 를 본다.**
        import ast as _ast
        _tree = _ast.parse(io.open(__file__, encoding='utf-8').read())
        _imp = set()
        for _nd in _ast.walk(_tree):
            if isinstance(_nd, _ast.Import):
                _imp |= {al.name.split('.')[0] for al in _nd.names}
            elif isinstance(_nd, _ast.ImportFrom) and _nd.module:
                _imp.add(_nd.module.split('.')[0])
        t('★ 위젯 꾸러미를 안 부른다 — **데이터 층**이다(§121차)',
          not (_imp & {'tk' + 'inter', 'ttk'}), sorted(_imp))
    finally:
        conn.rollback()          # ⚠ 시험 자국을 남기지 않는다
        conn.close()
    print('db_media_list selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


def main():
    import appdb
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(_db())
    try:
        for lid, nm, n in lists(conn):
            print('  %-4d %-24s %d편' % (lid, nm, n))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
