# db_commentary_text_loader.py  --  Commentary MODERN_EN/TRANSLATED/SUMMARY bulk loader
# Usage:
#   python db_commentary_text_loader.py <input.json> [--preview]
#   python db_commentary_text_loader.py --dump <COMMENTARY_CODE> <BCODE> [--limit N]
#
# JSON format:
#   [{"entry_id": 33854, "text_variant": "MODERN_EN", "lang_code": "EN", "body_text": "..."}, ...]
#
# --dump generates a template JSON with entry_id / bcode / chapter / original text preview

import sqlite3, json, sys, argparse

DB_PATH = 'bible_master.db'

COMMENTARY_CODES = {
    'JFB': 1, 'HENRY_MHC': 2, 'BARNES_NT': 3,
    'BARNES_OT': 4, 'CLARKE': 5, 'PULPIT_COM': 6
}


def upsert_text(conn, entry_id, text_variant, lang_code, body_text):
    conn.execute("""
        INSERT INTO sys_commentary_text (entry_id, text_variant, lang_code, body_text, record_status)
        VALUES (?, ?, ?, ?, 'LIVE')
        ON CONFLICT(entry_id, text_variant, lang_code)
        DO UPDATE SET body_text=excluded.body_text, record_status='LIVE'
    """, (entry_id, text_variant, lang_code, body_text))


def run_load(input_file: str, preview: bool):
    with open(input_file, encoding='utf-8') as f:
        items = json.load(f)

    conn = sqlite3.connect(DB_PATH)

    # Verify unique constraint exists — create if missing
    conn.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_ctext_entry_variant_lang
        ON sys_commentary_text(entry_id, text_variant, lang_code)
    """)

    valid_entry_ids = set(
        r[0] for r in conn.execute("SELECT entry_id FROM sys_commentary_entry").fetchall()
    )

    inserted = updated = skipped = 0
    errors = []

    for item in items:
        eid = item.get('entry_id')
        variant = item.get('text_variant', 'MODERN_EN')
        lang = item.get('lang_code', 'EN').upper()
        body = item.get('body_text', '').strip()

        if not eid or not body:
            skipped += 1
            continue
        if eid not in valid_entry_ids:
            errors.append(f"entry_id={eid} not found in sys_commentary_entry")
            skipped += 1
            continue

        existing = conn.execute(
            "SELECT text_id FROM sys_commentary_text WHERE entry_id=? AND text_variant=? AND lang_code=?",
            (eid, variant, lang)
        ).fetchone()

        if preview:
            status = "UPDATE" if existing else "INSERT"
            sys.stdout.buffer.write(
                f"  [{status}] entry_id={eid} variant={variant} lang={lang} body_len={len(body)}\n".encode()
            )
            inserted += (0 if existing else 1)
            updated += (1 if existing else 0)
        else:
            upsert_text(conn, eid, variant, lang, body)
            if existing:
                updated += 1
            else:
                inserted += 1

    if not preview:
        conn.commit()

    conn.close()

    out = (f"{'[PREVIEW] ' if preview else ''}Done — "
           f"inserted={inserted}, updated={updated}, skipped={skipped}\n")
    if errors:
        out += "Errors:\n" + "\n".join(f"  {e}" for e in errors) + "\n"
    sys.stdout.buffer.write(out.encode())


def run_dump(commentary_code: str, bcode: str, limit: int):
    code_upper = commentary_code.upper()
    if code_upper not in COMMENTARY_CODES:
        sys.stdout.buffer.write(f"Unknown commentary: {commentary_code}\n".encode())
        return

    commentary_id = COMMENTARY_CODES[code_upper]
    conn = sqlite3.connect(DB_PATH)

    rows = conn.execute("""
        SELECT ce.entry_id, ce.bcode, ce.chapter, ce.start_vid, ce.end_vid,
               ct.body_text
        FROM sys_commentary_entry ce
        JOIN sys_commentary_text ct ON ct.entry_id=ce.entry_id
        WHERE ce.commentary_id=? AND ct.text_variant='ORIGINAL'
        AND ce.bcode=?
        ORDER BY ce.entry_id
        LIMIT ?
    """, (commentary_id, bcode.upper(), limit)).fetchall()

    conn.close()

    template = []
    for eid, bc, ch, svid, evid, orig in rows:
        template.append({
            "entry_id": eid,
            "bcode": bc,
            "chapter": ch,
            "start_vid": svid,
            "end_vid": evid,
            "original_preview": orig[:300] + ("..." if len(orig) > 300 else ""),
            "original_length": len(orig),
            "text_variant": "MODERN_EN",
            "lang_code": "EN",
            "body_text": ""
        })

    out_file = f"source_texts/{code_upper}_{bcode.lower()}_modern_en_template.json"
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(template, f, ensure_ascii=False, indent=2)

    sys.stdout.buffer.write(
        f"Template written: {out_file} ({len(template)} entries)\n".encode()
    )


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('input', nargs='?', help='JSON file to load')
    parser.add_argument('--preview', action='store_true')
    parser.add_argument('--dump', metavar='COMMENTARY_CODE')
    parser.add_argument('--bcode', metavar='BCODE')
    parser.add_argument('--limit', type=int, default=50)
    args = parser.parse_args()

    if args.dump:
        if not args.bcode:
            sys.stdout.buffer.write(b"--bcode required with --dump\n")
            sys.exit(1)
        run_dump(args.dump, args.bcode, args.limit)
    elif args.input:
        run_load(args.input, args.preview)
    else:
        parser.print_help()
