"""
p1_reading_view.py
------------------
P1 Tab3: 도서읽기 + 설교집 통합 화면

레이아웃:
  상단: 검색 바 (검색유형 콤보 + 키워드 입력 + 검색/초기화 버튼)
  좌측: ttk.Notebook (도서 탭 / 설교집 탭)
    - 도서 탭  : 카테고리 > 도서 > 유닛 트리뷰
    - 설교집 탭: 저자 > 설교집(시리즈) > 설교 트리뷰
  우측: 읽기 패널
    - 메타데이터 (제목 · 저자 · 출판연도 · 핵심구절) + ★ 즐겨찾기
    - 변형/언어 선택 바 (ORIGINAL / MODERN_EN / TRANSLATED / SUMMARY)
    - 본문 Text 위젯
    - 이전 / 다음 네비게이션

공개 API:
  jump_to_unit(unit_id) — 외부에서 특정 유닛으로 직접 이동
                          (미래 "구절 → 관련 설교 오픈" 흐름에서 사용)
"""
import json
import i18n
import re
import sqlite3
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
import link_picker                        # 자산 연결 (§자산간 연결)
import bidi                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)
import verse_ref                          # 구절 약명 표기 (단일 소스)

# 옛 자료가 쓰는 다른 이름 → DB(`book_names` EN)의 정식 이름
# 「장」 접미사는 번역어가 아니라 **문자 체계 관례**다 — 라틴·키릴·아랍 문화권은
# 장 참조를 `Gen 1` 로 적지 접미사를 붙이지 않는다. 그래서 i18n 열쇠가 아니라
# 표로 둔다(바로 위 `sep` 의 CJK/라틴 구분과 같은 계열).
# ⚠ 예전에 `i18n.t('RV_CHAP_SUFFIX', '장')` 이었는데 그 열쇠를 **어느 언어에도
#   등록하지 않아** 영어 화면에 `Gen 1장` 이 나왔다(2026-08-23 실측).
#   i18n 열쇠를 쓸 거면 반드시 그 자리에서 시드까지 넣을 것.
_CHAP_SUFFIX = {'KO': '장', 'JA': '章', 'ZH': '章', 'ZHT': '章'}

_BOOK_ALIAS = {
    'song of solomon': 'song of songs', 'canticles': 'song of songs',
    'psalm': 'psalms', 'revelation of john': 'revelation',
    'the revelation': 'revelation', 'acts of the apostles': 'acts',
}


def _C(role, fallback):
    """색은 역할로 (§36). 폴백 리터럴은 이 꼴 안에서만 쓴다."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


_REF_SOURCE_LABELS = {
    'HEIDELBERG':     '하이델베르크 교리문답',
    'WESTMINSTER_SC': '웨스트민스터 소교리문답',
    'LUTHER_SC':      '루터 소교리문답',
    'TORREY_WBT':     '토레이 주제연구',
    'MEYER_BC':       "Meyer 성경 인물 연구",
    'EASTON_DICT':    "Easton 성경사전",
    'SMITH_DICT':     "Smith 성경사전",
    'EDERSHEIM_LT':   "에더샤임 — 예수의 생애와 시대",
    'EDERSHEIM_TMP':  "에더샤임 — 성전, 그 사역과 예식",
    'EDERSHEIM_JSL':  "에더샤임 — 유대 사회생활",
}
_REF_SRC_TYPE_KO = {
    'CATECHISM': '교리문답',
    'TOPICAL':   '주제연구',
    'DICTIONARY': '성경사전',
    'CHARACTER_STUDY': '인물연구',
    'HISTORICAL': '역사배경',
}

_SECTION_LABELS = {
    'HEID_P1':   '제1부: 비참 (Q1–11)',
    'HEID_P2':   '제2부: 구원 (Q12–85)',
    'HEID_P3':   '제3부: 감사 (Q86–129)',
    'WSC_P1':    '제1부: 하나님과 성경 (Q1–12)',
    'WSC_P2':    '제2부: 죄와 구원·그리스도 (Q13–38)',
    'WSC_P3':    '제3부: 율법·십계명 (Q39–84)',
    'WSC_P4':    '제4부: 은혜의 방편·기도 (Q85–107)',
    'LUTH_P1':   '제1부: 십계명',
    'LUTH_P2':   '제2부: 사도신경·주기도문',
    'LUTH_P3':   '제3부: 성례·고백',
    'TORREY_S1': '제1부: 하나님의 본성',
    'TORREY_S2': '제2부: 예수 그리스도',
    'TORREY_S3': '제3부: 성령',
    'TORREY_S4': '제4부: 구원론',
    'TORREY_S5': '제5부: 신앙생활과 영적 존재',
}

_CATEGORY_LABELS = {
    'DEVOTIONAL':  '일일묵상',
    'SPIRITUALITY': '영성고전',
    'FICTION':     '신앙소설',
    'BIOGRAPHY':   '고백/전기',
    'DOCTRINE':    '교리입문',
    'HISTORY':     '역사 배경',   # 2026-08-18 에더샤임 3권
    # ⚠ 도서 트리는 `book_category != 'SERMON'` 로 걸러 이 이름을 쓸 일이 없었다.
    #   **서재(대시보드)는 35권을 한자리에 놓으므로** 설교집 이름이 필요하다
    #   (없으면 카드에 코드 `SERMON` 이 그대로 나온다 — 2026-08-23 실측).
    'SERMON':      '설교집',
}

_VARIANT_LABELS = {
    'ORIGINAL':   '원문',
    'MODERN_EN':  '현대영어',
    'TRANSLATED': '번역',
    'SUMMARY':    '요약',
}

_VARIANT_ORDER = ['ORIGINAL', 'MODERN_EN', 'TRANSLATED', 'SUMMARY']

_FONT_FAMILIES = ['Georgia', 'Times New Roman', 'Arial',
                  'Malgun Gothic', '돋움', '굴림', '바탕']
_FONT_SIZES    = ['9', '10', '11', '12', '13', '14', '16', '18']
_FONT_SPACINGS = ['기본', '넓게', '아주 넓게']
_FONT_DEFAULTS = {'family': 'Georgia', 'size': '10', 'spacing': '기본'}
_SPACING_PX    = {'기본': 0, '넓게': 3, '아주 넓게': 6}
# (i18n 키, KO, px) — 모듈레벨 dict는 import 시점 평가라 사용처에서 런타임 i18n 적용
_SPACING_CODES = [('RV_SPACE_BASIC', '기본', 0), ('RV_SPACE_WIDE', '넓게', 3), ('RV_SPACE_XWIDE', '아주 넓게', 6)]


def _spacing_values():
    return [i18n.t(k, ko) for k, ko, _ in _SPACING_CODES]


def _spacing_default():
    return i18n.t('RV_SPACE_BASIC', '기본')


def _spacing_px(label):
    for k, ko, px in _SPACING_CODES:
        if label == i18n.t(k, ko) or label == ko:
            return px
    return 0

# 분류라벨 badge 색상 (bg, fg) — green/blue 파스텔
_TAG_TYPE_STYLE = {
    'THEME':      ('#D5F5E3', '#1A7A4A'),   # pastel green
    'KEYWORD':    ('#D6EAF8', '#1A5276'),   # pastel blue
    'DIAG_PHASE': ('#D1F2EB', '#0E6655'),   # pastel teal
    'ENTITY':     ('#EAF2FF', '#2471A3'),   # pastel sky
    'COLLECTION': ('#E8F8F5', '#117A65'),   # pastel green-teal
}
# 연구태그 badge 색상 — yellow/orange 파스텔
_RTAG_BG = '#FEF5E7'
_RTAG_FG = '#B7770D'



# 제목이 스스로 번호를 달고 있는가 (`No. 1 —` · `1.` · `Sermon 3`)
_NUMBERED_HEAD = re.compile(r'^\s*(No\.?\s*\d|\d+\s*[.)]|Sermon\s+\d)', re.I)

class ReadingView(ttk.Frame):

    def __init__(self, parent, db_path, lang_getter=None,
                 version_getter=None,
                 on_research_new=None,
                 on_research_open=None,
                 last_reading: dict | None = None,
                 on_reading_changed=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter    = lang_getter    or (lambda: 'KO')
        self.version_getter = version_getter or (lambda: 'KRV')
        # 2단 bar 콜백 — user_main 이 생성 후 배선한다 (2026-08-18 `0.txt` 1번)
        self.on_enr_pick = None      # 진행중 콤보 선택 → 플랜 탭 점프
        # ★ 이 책의 묵상플랜으로 (2026-08-30) — 호스트가 플랜 화면을 연다.
        self.on_book_plan = None
        self.on_font_open = None     # Font 단추 → 통합 폰트 창
        self.on_download_jump = None  # 서재의 안 받은 자료 → 설정 ▸ 다운로드
        # ★ 2026-08-22 사용자 지적 「도서묵상 하다가 연결구절을 보고 싶은데
        #   단추가 없다」 — 부제에 `창1:5` 라 적어 놓고 누를 수가 없었다.
        self.on_verse_jump = None    # [창1:5 ▸] → 그 구절로 (표준 이동)
        self.on_chapter_compare = None   # 핵심구절 약명 → 역본흐름(장 비교)
        # ★ 연결 자산 칩이 쓰는 길 (2026-08-31) — 없으면 My Edit 으로 물러난다
        self.on_verse_side = None    # 구절 → **P4 구절 연결**(P1 은 그대로 둔다)
        self.on_user_open = None     # 연구자료 → P4 연구자료 탭
        self._last_reading: dict = last_reading or {}
        self._on_reading_changed = on_reading_changed
        # 읽던 도서·설교를 연구자료로 적으러 갈 때 부른다(밖에서 P4 로 보낸다)
        self._on_research_new = on_research_new
        # 연구자료 한 편을 열 때 (P4 연구자료 탭으로) — `user_main._open_ref_detail`
        self.on_research_open = on_research_open

        # runtime state
        self._current_unit: dict | None = None
        self._current_doctrine_unit: dict | None = None
        self._book_units: list[dict] = []
        self._sermon_units: list[dict] = []
        self._book_row: dict = {}      # 갈래 → {키: 자료집 줄 iid}
        self._favorites: list[dict] = []
        self._texts: dict = {}       # (variant, lang_code) → body_text
        self._doctrine_units: list[dict] = []

        # 전역 판본/언어 선택 (모든 유닛에 공통 적용)
        self._g_variant_var = tk.StringVar()
        self._g_lang_var    = tk.StringVar()
        _init_lang = self.lang_getter().upper()
        self._g_variant_var.set('MODERN_EN' if _init_lang == 'EN' else 'TRANSLATED')
        self._g_lang_var.set(_init_lang)

        # Font settings (StringVars created before _build)
        self._font_family_var  = tk.StringVar()
        self._font_size_var    = tk.StringVar()
        self._font_spacing_var = tk.StringVar()
        self._load_font_settings()

        self._reading_history: dict = {'BOOK': [], 'SERMON': [], 'DOCTRINE': []}
        self._load_favorites()
        self._load_history()
        self._build()
        # Traces added after _build so _body_txt exists before first callback
        self._font_family_var.trace_add('write', self._on_font_change)
        self._font_size_var.trace_add('write', self._on_font_change)
        self._font_spacing_var.trace_add('write', self._on_font_change)
        self.apply_font()          # 표준 목록 서식 — 지연 빌드라 생성부에서도 한 번
        self.after(100, self._initial_load)

    def apply_font(self):
        """좌측 트리들을 통합 폰트 「목록」 표준으로 (2026-08-18).
        `theme_font.reapply_all → _poke` 가 이 이름을 찾아 부른다 — 이것이
        없어서 도서/설교 트리만 9pt 로 굳어 있었다. 태그는 색만 갖고 글꼴은
        여기서 입힌다(태그 font 가 스타일을 이기는 함정 — §22 렌즈와 동일)."""
        try:
            import theme_font as _tf
            f = _tf.list_style('Reading.Treeview', self.db_path, heading=False)
            tags = {
                # ★ 2026-10-13 docs/1.txt 79-4 — 굵게를 걷었다(표준 목록 글꼴 · 「볼드체 제거」)
                '_book_tv': (('cat', ()), ('book', ()),
                             ('unit', ()), ('fav', ()),
                             ('no_result', ('italic',))),
                '_sermon_tv': (('author', ()), ('book', ()),
                               ('unit', ()), ('fav', ()),
                               ('no_result', ('italic',))),
                '_doctrine_tv': (('src', ()), ('section', ()),
                                 ('alpha', ()), ('unit', ())),
                '_fav_tv': (('book_item', ()), ('sermon_item', ())),
            }
            for attr, tt in tags.items():
                tv = getattr(self, attr, None)
                if tv is None:
                    continue
                for tag, extra in tt:
                    tv.tag_configure(tag, font=f + tuple(extra))
        except Exception as e:
            print('[reading font] %s' % e)

    # ── 즐겨찾기 ───────────────────────────────────────────────────────────────

    def _load_favorites(self):
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT config_val FROM user_config WHERE config_key='READING_FAVORITES'"
                ).fetchone()
                if row:
                    self._favorites = json.loads(row[0]) or []
        except Exception:
            self._favorites = []

    def _save_favorites(self):
        val = json.dumps(self._favorites, ensure_ascii=False)
        try:
            with appdb.connect(self.db_path) as conn:
                ex = conn.execute(
                    "SELECT rowid FROM user_config WHERE config_key='READING_FAVORITES'"
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE user_config SET config_val=? "
                        "WHERE config_key='READING_FAVORITES'", (val,))
                else:
                    conn.execute(
                        "INSERT INTO user_config (config_key, config_val) "
                        "VALUES ('READING_FAVORITES', ?)", (val,))
        except Exception:
            pass

    # ── 최근 열람 ─────────────────────────────────────────────────────────────

    def _load_history(self):
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT config_val FROM user_config "
                    "WHERE config_key='READING_HISTORY'"
                ).fetchone()
                if row:
                    self._reading_history = json.loads(row[0]) or {}
        except Exception:
            pass
        for key in ('BOOK', 'SERMON', 'DOCTRINE'):
            self._reading_history.setdefault(key, [])

    def _save_history(self):
        val = json.dumps(self._reading_history, ensure_ascii=False)
        try:
            with appdb.connect(self.db_path) as conn:
                ex = conn.execute(
                    "SELECT rowid FROM user_config "
                    "WHERE config_key='READING_HISTORY'"
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE user_config SET config_val=? "
                        "WHERE config_key='READING_HISTORY'", (val,))
                else:
                    conn.execute(
                        "INSERT INTO user_config (config_key, config_val) "
                        "VALUES ('READING_HISTORY', ?)", (val,))
        except Exception:
            pass

    def _update_history(self, tab_type: str, unit_id: int, label: str,
                        src_code: str = ''):
        items = self._reading_history.setdefault(tab_type, [])
        items = [x for x in items if x.get('unit_id') != unit_id]
        entry: dict = {'unit_id': unit_id, 'label': label}
        if src_code:
            entry['src_code'] = src_code
        items.insert(0, entry)
        self._reading_history[tab_type] = items[:3]
        self._save_history()
        self._render_recent(tab_type)

    # ★ **최근 열람을 없애고 그 자리에 걸러보기를 넣었다** (2026-08-15 사용자 지시).
    #   최근 열람은 P1 탭4 「나의 길 ▸ 독서 진행중」에 이미 있었다(§3) — 두 곳에 두면
    #   어긋난다. 기록 자체(`_reading_history`)는 그대로 쌓아 둔다; 그리지 않을 뿐이다.
    _FILTERS = (('ALL', '전체'), ('READ', '● 읽음'), ('UNREAD', '○ 아직'))

    # 갈래마다 다른 것 한 곳에. **여기만 고치면 세 화면이 따라온다.**
    # ⚠ `kind` 가 다르다 — 교리자료는 `sys_ref_unit` 이라 도서 유닛과 번호가
    #   549개 겹친다. 같은 `kind` 로 담으면 서로를 읽음으로 물들인다.
    _TAB_SPEC = {
        'BOOK':     dict(tv='_book_tv',     leaf='U_',  grp='BK_',
                         units='_book_units',     kind='BOOK', key='book_id'),
        'SERMON':   dict(tv='_sermon_tv',   leaf='SU_', grp='SBK_',
                         units='_sermon_units',   kind='BOOK', key='book_id'),
        'DOCTRINE': dict(tv='_doctrine_tv', leaf='DU_', grp='DSRC_',
                         units='_doctrine_units', kind='REF',  key='src_code'),
    }

    def _spec(self, tab_type):
        return self._TAB_SPEC.get(tab_type)

    def _tab_of_unit(self, u):
        """지금 보고 있는 유닛이 어느 갈래인가."""
        if not u:
            return None
        if u.get('src_code'):
            return 'DOCTRINE'
        return 'SERMON' if u.get('source') == 'SERMON' else 'BOOK'

    def _cur_tab(self):
        u = getattr(self, '_current_doctrine_unit', None)
        if u:
            return 'DOCTRINE', u
        return self._tab_of_unit(getattr(self, '_current_unit', None)) or 'BOOK', \
               getattr(self, '_current_unit', None)

    def _render_recent(self, tab_type: str):
        """★★★ **걸러보기 띠를 걷었다** (2026-08-31 사용자 「트리 상단에 있는
        전체/읽음/아직 표시버튼이 **어떤 의미가 있는가**? 유닛 단위 배치를
        팝업으로 이동했는데 아직도 의미가 있는가?」).

        ⚠⚠ **의미가 없었다** — `_set_filter` 가 거르는 대상은 `sp['leaf']`
          (`U_`·`SU_`), 곧 **유닛 줄**이다. 128차에 그 줄을 걷었으므로 이제
          **아무것도 안 걸러진다.** 누르면 숫자만 바뀌고 화면은 그대로다
          — §0-1 이 금지하는 「눌러도 안 달라지는 스위치」다.
        ⇒ 걸러보기는 **목차 팝업**으로 갔다(거기에 유닛이 있다).
        ⚠ `_set_filter`·`_filter_counts`·`_FILTERS` 는 **남긴다** — 팝업이
          그 셋을 쓴다. 화면에서 떼는 것과 지우는 것은 다르다.
        """
        for _a in ('_book_recent_f', '_sermon_recent_f', '_doctrine_recent_f'):
            _f = getattr(self, _a, None)
            if _f is not None and _f.winfo_manager():
                _f.pack_forget()
        return

    def _render_recent_OLD(self, tab_type: str):
        frame_attr = {
            'BOOK':    '_book_recent_f',
            'SERMON':  '_sermon_recent_f',
            'DOCTRINE': '_doctrine_recent_f',
        }.get(tab_type)
        if not frame_attr or not hasattr(self, frame_attr):
            return
        f = getattr(self, frame_attr)
        for w in f.winfo_children():
            w.destroy()
        sp = self._spec(tab_type)
        tv = getattr(self, sp['tv'], None) if sp else None
        if tv is None:
            f.pack_forget()
            return
        tree_f = [w for w in f.master.winfo_children() if w is not f]
        f.pack(fill='x', **({'before': tree_f[0]} if tree_f else {}))

        cur = getattr(self, '_list_filter', {}).get(tab_type, 'ALL')
        counts = self._filter_counts(tab_type)
        for code, ko in self._FILTERS:
            on = (code == cur)
            b = tk.Button(f, text='%s %d' % (i18n.t('PR_FILTER_' + code, ko),
                                             counts.get(code, 0)),
                          font=('', 8), bd=1,
                          relief='sunken' if on else 'raised', cursor='hand2',
                          command=lambda t=tab_type, c=code: self._set_filter(t, c))
            b.pack(side='left', padx=(4 if code == 'ALL' else 2, 0), pady=2)

    def _scope_key(self, tab_type):
        """지금 보고 있는 자료집. 없으면 None(=전부).

        ⚠ 다섯 설교집을 합친 3,573 을 보이면 「스펄전을 3,573편 읽어야 한다」로
          읽힌다. 보고 있는 묶음으로 한정한다(2026-08-15 사용자 지적).
        """
        sp = self._spec(tab_type)
        if not sp:
            return None
        cur_tab, u = self._cur_tab()
        if u and cur_tab == tab_type and u.get(sp['key']):
            return u[sp['key']]
        tv = getattr(self, sp['tv'], None)
        if tv is None:
            return None
        sel = tv.selection()
        if sel and sel[0].startswith(sp['grp']):
            raw = sel[0][len(sp['grp']):]
            if sp['key'] == 'src_code':
                r = self._src_code_of(raw)
                return r
            try:
                return int(raw)
            except ValueError:
                return None
        return None

    def _src_code_of(self, src_id):
        """교리자료 나무의 `DSRC_<ref_src_id>` → `src_code`."""
        try:
            for u in getattr(self, '_doctrine_units', []):
                if str(u.get('src_id')) == str(src_id):
                    return u.get('src_code')
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT src_code FROM sys_ref_source "
                                 "WHERE ref_src_id=?", (src_id,)).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def _filter_counts(self, tab_type):
        sp = self._spec(tab_type)
        if not sp:
            return {'ALL': 0, 'READ': 0, 'UNREAD': 0}
        units = getattr(self, sp['units'], [])
        key = self._scope_key(tab_type)
        if key is not None:
            units = [u for u in units if u.get(sp['key']) == key]
        try:
            import db_read_state
            with appdb.connect(self.db_path) as conn:
                done = db_read_state.read_ids(conn, kind=sp['kind'])
        except Exception:
            done = set()
        n = len(units)
        r = sum(1 for u in units if u.get('unit_id') in done)
        return {'ALL': n, 'READ': r, 'UNREAD': n - r}

    def _set_filter(self, tab_type, code):
        """보이는 것만 줄인다. **순서는 건드리지 않는다.**

        ⚠ Treeview 에는 「감추기」가 없다 — `detach` 로 떼었다가 `reattach` 로
          **원래 자리에** 되돌린다. `move(..., 'end')` 로 붙이면 번호순이 깨진다.
        """
        if not hasattr(self, '_list_filter'):
            self._list_filter = {}
        self._list_filter[tab_type] = code
        sp = self._spec(tab_type)
        tv = getattr(self, sp['tv'], None) if sp else None
        if tv is None:
            return
        try:
            import db_read_state
            with appdb.connect(self.db_path) as conn:
                done = db_read_state.read_ids(conn, kind=sp['kind'])
        except Exception:
            done = set()
        pre = sp['leaf']
        if not hasattr(self, '_detached'):
            self._detached = {}
        # 먼저 떼어 둔 것을 제자리로 (원래 자리 = 저장해 둔 부모·index)
        for iid, (parent, idx) in sorted(self._detached.pop(tab_type, {}).items(),
                                         key=lambda kv: kv[1][1]):
            try:
                tv.reattach(iid, parent, idx)
            except Exception:
                pass
        if code == 'ALL':
            self._render_recent(tab_type)
            return
        keep_read = (code == 'READ')
        saved = {}
        for parent in self._all_parents(tv):
            for idx, iid in enumerate(tv.get_children(parent)):
                if not iid.startswith(pre):
                    continue
                try:
                    uid = int(iid[len(pre):])
                except ValueError:
                    continue
                if (uid in done) != keep_read:
                    saved[iid] = (parent, idx)
        for iid, (parent, idx) in saved.items():
            try:
                tv.detach(iid)
            except Exception:
                pass
        self._detached[tab_type] = saved
        self._render_recent(tab_type)

    @staticmethod
    def _all_parents(tv):
        out = ['']
        i = 0
        while i < len(out):
            out.extend(tv.get_children(out[i]))
            i += 1
        return out

    def _jump_to_history_item(self, tab_type: str, unit_id: int,
                               src_code: str = ''):
        if tab_type in ('BOOK', 'SERMON'):
            all_units = (self._book_units if tab_type == 'BOOK'
                         else self._sermon_units)
            u = next((x for x in all_units if x['unit_id'] == unit_id), None)
            if u:
                self._show_unit(u)
                tv = self._book_tv if tab_type == 'BOOK' else self._sermon_tv
                iid = f'U_{unit_id}' if tab_type == 'BOOK' else f'SU_{unit_id}'
                if tv.exists(iid):
                    self._reveal_and_select(tv, iid)
        elif tab_type == 'DOCTRINE':
            u = next((x for x in self._doctrine_units
                      if x['unit_id'] == unit_id), None)
            if u:
                self._show_doctrine_unit(u)

    def _load_font_settings(self):
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT config_val FROM user_config "
                    "WHERE config_key='READING_FONT'"
                ).fetchone()
                cfg = json.loads(row[0]) if row else {}
        except Exception:
            cfg = {}
        d = {**_FONT_DEFAULTS, **cfg}
        self._font_family_var.set(d['family'])
        self._font_size_var.set(d['size'])
        # 저장값(KO/타언어 무관)을 px로 해석 후 현재 언어 표시값으로 정규화
        _px = _spacing_px(d['spacing'])
        self._font_spacing_var.set(
            next((i18n.t(k, ko) for k, ko, px in _SPACING_CODES if px == _px), _spacing_default()))

    def _save_font_settings(self):
        cfg = {
            'family':  self._font_family_var.get(),
            'size':    self._font_size_var.get(),
            'spacing': self._font_spacing_var.get(),
        }
        val = json.dumps(cfg, ensure_ascii=False)
        try:
            with appdb.connect(self.db_path) as conn:
                ex = conn.execute(
                    "SELECT rowid FROM user_config WHERE config_key='READING_FONT'"
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE user_config SET config_val=? "
                        "WHERE config_key='READING_FONT'", (val,))
                else:
                    conn.execute(
                        "INSERT INTO user_config (config_key, config_val) "
                        "VALUES ('READING_FONT', ?)", (val,))
        except Exception:
            pass

    def _on_font_change(self, *_):
        self._save_font_settings()
        if self._current_unit:
            self._refresh_body()
        elif self._current_doctrine_unit:
            self._show_doctrine_unit(self._current_doctrine_unit)

    def _is_favorite(self, unit_id: int, is_ref: bool = False) -> bool:
        """⚠ 도서 유닛 id 와 교리 유닛 id 는 **겹친다**(549개 실측 — notes.md §0).
        갈래('REF' 여부)를 함께 봐야 교리 찜이 엉뚱한 도서에 뜨지 않는다.

        ⚠ **책 담아두기(`BOOK_ASSET`)는 건너뛴다** — 그 행의 번호는 `book_id`
          라 유닛 번호와 작은 수에서 그대로 겹친다(둘 다 1부터 센다)."""
        return any(f['unit_id'] == unit_id
                   and f.get('type') != self._BOOK_FAV
                   and ((f.get('type') == 'REF') == is_ref)
                   for f in self._favorites)

    # ★★ **책 담아두기 — 1단(2026-08-31 `0.txt` 2번 사용자 지시)**
    #   「유닛의 문장이 짧아서 유닛 단위의 찜하기 의미가 없다. **책 단위로
    #   배치한다**」. 유닛 쪽에는 ★(즐겨찾기)만 남는다(3단).
    #   ⚠ 저장소는 **같은 목록 하나**다(`READING_FAVORITES`) — 표를 따로 두면
    #     담기는 자리가 둘이 되어 「담았는데 목록에 없다」가 난다.
    _BOOK_FAV = 'BOOK_ASSET'

    def _cur_book_id(self):
        """지금 화면이 딛고 선 책 — 유닛을 보든 소개문을 보든 하나로."""
        u = self._current_unit or {}
        return u.get('book_id') or getattr(self, '_current_book_id', None)

    def _is_book_favorite(self, book_id) -> bool:
        return bool(book_id) and any(
            f.get('type') == self._BOOK_FAV and f['unit_id'] == book_id
            for f in self._favorites)

    def _toggle_book_favorite(self):
        bid = self._cur_book_id()
        if not bid:
            return
        if self._is_book_favorite(bid):
            self._favorites = [
                f for f in self._favorites
                if not (f.get('type') == self._BOOK_FAV
                        and f['unit_id'] == bid)]
        else:
            self._favorites.append({'type': self._BOOK_FAV, 'unit_id': bid})
        self._save_favorites()
        # ★★ **♥ 를 누르면 읽을 차례의 후보가 된다** (2026-08-31 사용자 「도서
        #   소개문을 읽어보고 **나중에 읽을 거리로 체크하는 항목이 있어야 이것이
        #   top 10 선정할 후보 목록에 들어갈 것**」).
        #   ⚠ 차례는 **맨 뒤**에 붙는다 — 담을 때마다 앞으로 끼어들면 애써 정한
        #     차례가 매번 뒤집힌다. 위로 올리는 것은 서재에서 손으로 한다.
        try:
            import read_order
            k = 'SERMON' if self._book_cat(bid) == 'SERMON' else 'BOOK'
            with appdb.connect(self.db_path) as c:
                # ⚠ `_favorites` 는 **바로 위에서 이미 바뀌었다** — 지금 담겨
                #   있으면 담은 것이다(반대로 읽으면 정확히 거꾸로 돈다).
                (read_order.add if self._is_book_favorite(bid)
                 else read_order.remove)(c, k, bid)
        except Exception as e:
            print('[order fav] %s' % e)
        self._refresh_book_fav_btn()
        self._refresh_book_counts()       # 자료집 줄의 ♥ 를 그 자리에서
        self._refresh_order_combo()
        self._load_favorites_tree()

    def _refresh_book_fav_btn(self):
        """책 담아두기 — ♡ 아님 · ♥ 담음. **읽음 매트릭스를 안 탄다** —
        한 권의 「읽음」은 진도(%)이지 참·거짓이 아니다(진행 띠가 말한다)."""
        b = getattr(self, '_book_fav_btn', None)
        if b is None:
            return
        bid = self._cur_book_id()
        if not bid:
            b.config(text='♡', fg='#7F8C8D', state='disabled')
            return
        on = self._is_book_favorite(bid)
        b.config(text='♥' if on else '♡',
                 fg='#C0392B' if on else '#7F8C8D', state='normal')

    def _toggle_favorite(self):
        """즐겨찾기 토글 — 도서·설교·**교리자료** 셋 다 (2026-08-19 0.txt ⑤).
        예전에는 교리자료가 빠져 ☆ 이 죽은 장식으로 박혀 있었다."""
        tab, u = self._cur_tab()
        if not u:
            return
        uid = u['unit_id']
        is_ref = (tab == 'DOCTRINE')
        utype = 'REF' if is_ref else u.get('source', 'BOOK')
        if self._is_favorite(uid, is_ref):
            self._favorites = [
                f for f in self._favorites
                if not (f['unit_id'] == uid
                        and ((f.get('type') == 'REF') == is_ref))]
        else:
            self._favorites.append({'type': utype, 'unit_id': uid})
        self._save_favorites()
        self._refresh_fav_btn()
        self._refresh_read_btn()
        # 트리 표식(★●♥○ 매트릭스)을 다시 그린다 — 옛 gold 태그 방식 폐기
        self._refresh_read_mark(uid, None, tab)
        self._load_favorites_tree()

    def _unit_tv_iid(self, unit_id: int, source: str):
        if source == 'SERMON':
            return self._sermon_tv, f'SU_{unit_id}'
        return self._book_tv, f'U_{unit_id}'

    # 왼쪽 서브탭 자리 → 새 글의 유형. 도서·설교·교리자료가 성격이 다르다.
    _SCOPE_REF_TYPE = {0: 'BOOK', 1: 'SERMON', 2: 'STUDY'}   # 출처 칸(▣ 도서·설교·교리) 이름 — 글 유형은 ref_kinds 가 정한다

    def _write_research(self):
        """읽던 자리를 들고 연구자료 새 글로 간다.

        ⚠ **읽기 완료를 기다리지 않는다** (2026-08-15 사용자 지시). 유닛을 열면
          바로 쓸 수 있다 — 읽는 도중에 적어 두는 것이 오히려 흔하다.
        ⚠ 교리자료는 유닛이 `_current_doctrine_unit` 에 따로 담긴다.
        """
        # ★★ **통합 연결팝업으로 연다** (2026-08-30 사용자 지시 0.txt 4번 —
        #   「지금은 P4 로 이동하고 있다. My Edit 클릭해서 통합 연결팝업을
        #   표시하는 방식을 활용하는 것이 더 좋을 것 같다. … 도서 유닛이
        #   출발점으로 세팅, **재고창고에서 연구자료 버튼이 클릭된 상태**」).
        #   ⇒ 이미 이어 둔 다른 자산을 함께 보면서 새 글도 쓴다.
        #   ⚠ 옛 길(P4 로 이동)은 **지우지 않았다** — 아래 폴백이다. 도서·설교가
        #     아닌 자리(교리자료 서브탭)에서는 그쪽이 맞다.
        u0 = getattr(self, '_current_unit', None)
        if u0 and u0.get('unit_id'):
            try:
                import my_edit
                my_edit.open(
                    self, 'BOOK_UNIT', u0['unit_id'],
                    on_changed=lambda *_a: self._refresh_linked_research(
                        u0['unit_id']),
                    pick_kind='USER_REF')
                return
            except Exception as e:
                print('[research picker] %s' % e)
        try:
            idx = self._left_nb.index(self._left_nb.select())
        except Exception:
            idx = 0
        # ★ **편을 골랐을 때만 쓴다** (2026-08-31 사용자 「연구자료, 도서노트
        #   역시 **유닛을 선택한 경우에만** 작성할 수 있다」).
        #   ⚠ 편이 없으면 `unit_id=None` 으로 저장돼 **어디에도 안 붙는 글**이
        #     된다(미아 글). 그것이 조용히 만들어지는 쪽이 더 나쁘다.
        if idx != 2 and not (getattr(self, '_current_unit', None) or {}).get('unit_id'):
            self._need_unit()
            return
        if not callable(self._on_research_new):
            return
        u = (getattr(self, '_current_doctrine_unit', None) if idx == 2
             else getattr(self, '_current_unit', None)) or {}
        self._on_research_new({
            'ref_type':   self._SCOPE_REF_TYPE.get(idx, 'STUDY'),
            'unit_id':    u.get('unit_id'),
            'book_id':    u.get('book_id'),
            'book_title': u.get('book_title') or u.get('src_title') or '',
            'unit_label': u.get('unit_label') or u.get('label') or '',
            'start_vid':  u.get('start_vid'),
        })

    def _toggle_read(self):
        """읽음 켜고 끄기 — 도서·설교집·교리자료 셋 다."""
        tab, u = self._cur_tab()
        sp = self._spec(tab)
        if not u or not sp:
            return
        uid = u.get('unit_id')
        try:
            import db_read_state
            with appdb.connect(self.db_path) as conn:
                done = uid in db_read_state.read_ids(conn, kind=sp['kind'])
                if done:
                    db_read_state.unmark(conn, uid, kind=sp['kind'])
                else:
                    db_read_state.mark(conn, uid, u.get('book_id'), kind=sp['kind'])
        except Exception:
            return
        self._refresh_read_btn()
        if not done:
            self._ai_unlock()                # 「● 읽음」 = 다 읽었다(81)
        self._refresh_fav_btn()          # ♥↔★ 는 읽음 상태에 달렸다(매트릭스)
        self._refresh_read_mark(uid, not done, tab)
        self._refresh_book_counts(tab)
        # ⚠ 걸러보기 띠의 개수도 함께 — 안 부르면 「● 읽음 0」인 채로 남는다(실측으로 잡았다)
        try:
            self._render_recent(tab)
        except Exception:
            pass

    def _cur_read_done(self):
        tab, u = self._cur_tab()
        sp = self._spec(tab)
        if not (u and sp):
            return False
        try:
            import db_read_state
            with appdb.connect(self.db_path) as conn:
                return u.get('unit_id') in db_read_state.read_ids(
                    conn, kind=sp['kind'])
        except Exception:
            return False

    def _refresh_read_btn(self):
        """진행 띠의 단추 하나가 상태를 겸한다 — ✓ 완료 ↔ ● 읽음.

        ⚠ 옛 [○ 읽는중 ↔ ● 읽음] 과 띠의 [✓ 완료]가 **같은 뜻의 단추 둘**이라
          하나로 합쳤다(2026-08-19 사용자 확정). 안 읽었을 때 「○ 읽는중」은
          **상태 서술**이라 눌러야 할 것으로 안 보였다 — 「✓ 완료」는 **할 일**이다.
        """
        if not hasattr(self, '_read_btn'):
            return
        done = self._cur_read_done()
        # ★ 2026-10-13 79-1 — 「완료기호」 하나: ○ 읽음 ↔ ● 읽음(누르면 바뀐다)
        self._read_btn.config(
            text=('● ' if done else '○ ') + i18n.t('PR_READ_MARK', '읽음'),
            fg='#1E8449' if done else '#7F8C8D')
        self._sync_band(recalc=False)

    # ── 진행 띠 — **편 단위** 이전/다음·진도 (2026-08-24 · 파트 폐기) ──────
    #
    # ★★★ **파트를 폐기했다** (사용자 「다시는 파트 따위의 설계를 하지 마라」).
    #   편 안을 ~1,000자로 잘라 「13 / 216」을 세었는데, **경계를 화면에 그리지
    #   않아** 사용자에게는 스크롤과 구별되지 않았고(실측 경계 표시 태그 0개),
    #   그러면서 묵상노트 단추가 늘 보여 **페이지마다 쓸 수 있는 것으로 착각**하게
    #   만들었다. 저자가 안 나눈 자리에 의미를 붙인 대가다.
    #   ⇒ 이제 띠는 **저자가 나눈 편**만 센다 — `◐ 3 / 18편`.
    #   ⇒ 긴 글 안의 특정 대목은 **여백메모**(인용문 닻)가 맡는다.
    # ⚠ 그래서 **스크롤을 자리로 읽지 않는다.** 옛 코드가 틀렸던 자리 셋
    #   (짧은 편에서 yview 가 안 움직임 · 끝에서 잘림 · 깃발로 우리 스크롤을
    #   못 가름)이 통째로 사라진다. 자리는 「지금 보는 편」 하나뿐이다.

    def _on_body_scroll(self, lo, hi):
        """스크롤바만 옮긴다 — 띠는 편 단위라 굴려도 안 바뀐다."""
        try:
            self._body_vsb.set(lo, hi)
        except Exception:
            pass
        try:
            if float(lo) > 0.0 and float(hi) >= 0.995:
                self._ai_unlock()            # 끝까지 읽었다(81)
        except Exception:
            pass

    def _band_ctx(self):
        """`(book_id, unit_id)` — 띠를 그릴 수 있으면. 아니면 None.

        ⚠ **보고 있는 갈래까지 본다** — `_current_unit` 은 교리자료로 옮겨도
          안 지워져(마지막 도서 유닛이 남는다) 띠가 그대로 떠 있었다(실측).
        """
        try:
            if self._left_nb.index(self._left_nb.select()) not in self.SHELF_OF:
                return None
        except Exception:
            pass
        u = getattr(self, '_current_unit', None)
        if u and u.get('book_id') and u.get('unit_id'):
            return u['book_id'], u['unit_id']
        # ★★ **소개문을 보는 중에도 띠를 그린다** (2026-08-31 사용자 「트리에서
        #   다른 책을 선택할 때마다 **진도 버튼의 숫자가 업데이트/리프레시** 되어야
        #   한다」 · 「도서를 클릭하면 **직전에 읽었던 곳을 찾아가지 못한다**」).
        #   ⚠⚠ 그전에는 `_current_unit` 이 없으면 **띠째 감췄다** — 소개문에서는
        #     진도도 안 보이고 직전 자리로 갈 길도 없었다. 두 신고가 같은 뿌리다.
        #   ⇒ 그 책의 **담아 둔 자리**(없으면 첫 편)를 기준으로 그린다.
        bid = getattr(self, '_current_book_id', None)
        if not bid:
            return None
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                uid = rs.get_pos(c, bid)
            if not uid:
                src = (self._sermon_units
                       if self._book_cat(bid) == 'SERMON' else self._book_units)
                first = next((x for x in src if x.get('book_id') == bid), None)
                uid = first and first.get('unit_id')
        except Exception as e:
            print('[band ctx] %s' % e)
            return None
        return (bid, uid) if uid else None

    def _sync_band(self, recalc=True):
        """`◐ 3 / 18편` + 단추 상태. 그릴 수 없으면 띠째 감춘다.

        ⚠ `recalc` 는 **옛 파트 시절의 인자**다 — 부르는 곳이 여럿이라 받기만
          하고 쓰지 않는다(편은 화면에서 다시 읽을 것이 없다).
        """
        if not hasattr(self, '_band'):
            return
        if self._doc_ctx() is not None:
            self._sync_doc_band()
            return
        ctx = self._band_ctx()
        if ctx is None:
            if self._band.winfo_manager():
                self._band.pack_forget()
            return
        self._pack_band()
        bid, uid = ctx
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                pos, total = rs.locate(c, bid, uid)
                read, _t = rs.read_progress(c, bid)
                can_prev = rs.step(c, bid, uid, -1) is not None
                can_next = rs.step(c, bid, uid, +1) is not None
                saved = rs.get_pos(c, bid)
        except Exception as e:
            print('[band] %s' % e)
            return
        # ○ 아직 · ◐ 읽는 중 · ● 다 읽음 — 표식이 **진도**를 말한다
        # ★ 2026-10-13 79-1 — 「2/13편」(책 진도 표식은 왼쪽 목록이 말한다)
        self._band_lbl.config(
            text=i18n.t('PR_UNIT_POS2', '{n}/{t}편').format(n=pos, t=total))
        # ★★ **소개문에서는 이동·완료를 감춘다** (2026-08-31) — 읽고 있는 편이
        #   없는데 「● 읽음」이 떠 있으면 **무엇을 읽었다는 것인지** 알 수 없다.
        #   그 자리는 [읽기 시작]이 맡는다. 진도 숫자는 책의 것이라 그대로 둔다.
        # ★★ **이전/다음은 늘 보인다** (2026-08-31 사용자 「이전 이후 버튼이
        #   사라지는 경우가 있다 … **항상 표시되어야 한다**」). 맞다 — 소개문에서도
        #   담아 둔 자리 기준으로 앞뒤 편이 정해지므로 누르면 그 편이 열린다.
        #   ⚠ **[완료]만 편일 때 보인다** — 읽고 있는 편이 없는데 그것을 누르면
        #     **안 읽은 편을 읽었다고 표시**하게 된다. 「사라지는 단추」가 나쁜
        #     것보다 「엉뚱한 것을 표시하는 단추」가 나쁘다.
        _on_unit = bool(getattr(self, '_current_unit', None))
        for _w in (self._read_btn,):
            try:
                if _on_unit and not _w.winfo_ismapped():
                    _w.pack(side='left', padx=(0, 8), after=self._book_open_box)   # 「읽는 중」 바로 뒤(79-1)
                elif not _on_unit and _w.winfo_ismapped():
                    _w.pack_forget()
            except Exception:
                pass
        self._prev_btn.config(state='normal' if can_prev else 'disabled')
        self._next_btn.config(state='normal' if can_next else 'disabled')
        # ⚠ `saved` 는 이제 화면에 안 쓴다(단추를 걷었다) — 담는 일은 그대로다.
        _ = saved

    # ── 목차 팝업 (2026-08-31) ───────────────────────────────────────────────
    #
    # ★★★ 왜 — 왼쪽 트리의 셋째 층이 **7,228줄**이었고 그중 **두 권이 4,892줄**
    #   이었다(스펄전 3,519 · 마이어 1,373). 사용자 「스펄전 345장 읽다가 마이어
    #   찾으려면 복잡하다」. 트리는 「분류 → 책」까지만 하고 편은 여기서 고른다.
    # ⚠ **본문 공간을 한 픽셀도 안 쓴다**(사용자 조건) — 팝업이고, 문은 이미
    #   있던 라벨이다.
    def _toc_from_tree(self, ev=None):
        """트리 더블클릭 → 그 책의 목차 팝업 (진도 라벨과 같은 효과)."""
        tv = getattr(ev, 'widget', None)
        try:
            iid = tv.identify_row(ev.y) if tv is not None else ''
        except Exception:
            iid = ''
        bid = None
        if iid.startswith('BK_'):
            try:
                bid = int(iid[3:])
            except ValueError:
                return
        elif not iid:
            return
        self._open_toc(bid)
        return 'break'

    def _open_toc(self, book_id=None):
        tab, u = self._cur_tab()
        _doc = (book_id is None and tab == 'DOCTRINE')
        if _doc:
            # ★ 교리자료 목차(79-5 표준화) — 같은 자료집의 글 전부
            dc = self._doc_ctx()
            if dc is None:
                return
            rows = [dict(x, label=x.get('disp') or x.get('label') or x.get('question'),
                         verse_ref='') for x in dc[0]]
        else:
            bid = book_id or (u or {}).get('book_id')                 or getattr(self, '_current_book_id', None)
            if not bid:
                return
            # ⚠ **갈래는 지금 보는 편이 아니라 그 책이 정한다** — 다른 책을 더블클릭
            #   했는데 보던 편의 갈래로 목록을 고르면 **빈 목차**가 뜬다.
            src = (self._sermon_units if self._book_cat(bid) == 'SERMON'
                   else self._book_units)
            rows = [x for x in src if x.get('book_id') == bid]
        if not rows:
            return
        cur = (u or {}).get('unit_id')
        try:
            import db_read_state
            with appdb.connect(self.db_path) as c:
                read = db_read_state.read_ids(
                    c, kind='REF' if _doc else ('SERMON' if tab == 'SERMON' else 'BOOK'))
        except Exception:
            read = set()

        win = tk.Toplevel(self)
        win.title('%s — %s' % (rows[0].get('book_title') or i18n.t(
                               'REFSRC_' + str(rows[0].get('src_code') or ''), rows[0].get('src_code') or ''),
                               i18n.t('PR_TOC', '목차')))
        win.geometry('720x560')
        win.transient(self.winfo_toplevel())
        top = tk.Frame(win)
        top.pack(fill='x', padx=8, pady=(8, 4))
        tk.Label(top, text=i18n.t('COMMON_SEARCH', '찾기')).pack(side='left')
        q = tk.StringVar()
        ent = tk.Entry(top, textvariable=q, width=28)
        ent.pack(side='left', padx=(4, 8))
        cnt = tk.Label(top, text='')
        cnt.pack(side='left')
        # ★★ **걸러보기는 여기로 왔다** (2026-08-31) — 트리에서는 거를 것이
        #   없어졌고(유닛 줄 0), 목차에는 유닛이 있다. 자리가 뜻과 맞다.
        fmode = tk.StringVar(value='ALL')
        fbtn = {}

        def _pick(code):
            fmode.set(code)
            for c2, b2 in fbtn.items():
                b2.config(relief='sunken' if c2 == code else 'raised')
            fill()

        for code, ko in self._FILTERS:
            b = tk.Button(top, text=i18n.t('PR_FILTER_' + code, ko),
                          font=('', 8), bd=1,
                          relief='sunken' if code == 'ALL' else 'raised',
                          cursor='hand2',
                          command=lambda c2=code: _pick(c2))
            b.pack(side='right', padx=(2, 0))
            fbtn[code] = b

        wrap = tk.Frame(win)
        wrap.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        tv = ttk.Treeview(wrap, show='tree', selectmode='browse',
                          yscrollcommand=vsb.set)
        vsb.config(command=tv.yview)
        tv.pack(fill='both', expand=True)
        try:
            import theme_font
            theme_font.list_style('Toc.Treeview', self.db_path)
            tv.config(style='Toc.Treeview')
        except Exception:
            pass

        def fill(*_a):
            tv.delete(*tv.get_children())
            key = (q.get() or '').strip().lower()
            n = 0
            m = fmode.get()
            for x in rows:
                # ⚠ 거르기는 **줄을 안 만드는 것**으로 한다 — Treeview 에는
                #   감추기가 없어 트리에서는 detach/reattach 가 필요했다.
                #   팝업은 그릴 때마다 새로 채우므로 그런 장치가 필요 없다.
                if m == 'READ' and x['unit_id'] not in read:
                    continue
                if m == 'UNREAD' and x['unit_id'] in read:
                    continue
                lab = x.get('label') or ''
                rf = x.get('verse_ref') or ''
                txt = '%s %d. %s%s' % (
                    self._unit_mark(x['unit_id'] in read,
                                    self._is_favorite(x['unit_id'])),
                    x.get('sequence') or 0,
                    ('%s · ' % rf) if rf else '',
                    lab or '(제목 없음)')
                if key and key not in txt.lower():
                    continue
                tv.insert('', 'end', iid='T%d' % x['unit_id'], text=txt)
                n += 1
            cnt.config(text=i18n.t('PR_TOC_N', '{n}편').format(n=n))
            # ⚠ **지금 읽는 편으로 스크롤한다** — 3,519편에서 열자마자 맨 위면
            #   「어디쯤인지」를 다시 찾아야 한다.
            if cur and tv.exists('T%d' % cur):
                tv.selection_set('T%d' % cur)
                tv.see('T%d' % cur)

        def go(_e=None):
            sel = tv.selection()
            if not sel:
                return
            win.destroy()
            if _doc:
                _u = next((x for x in self._doctrine_units
                           if x['unit_id'] == int(sel[0][1:])), None)
                if _u:
                    self._show_doctrine_unit(_u)
            else:
                self.jump_to_unit(int(sel[0][1:]))

        q.trace_add('write', fill)
        tv.bind('<Double-1>', go)
        tv.bind('<Return>', go)
        fill()
        ent.focus_set()
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass

    def _save_pos(self):
        """지금 보는 편을 「읽던 자리」로 담는다 — 책마다 한 줄."""
        ctx = self._band_ctx()
        if ctx is None:
            return
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                rs.set_pos(c, ctx[0], ctx[1])
        except Exception as e:
            print('[band pos] %s' % e)

    # ── 교리자료도 같은 띠 (2026-10-13 docs/1.txt 79-5 「교리자료 표준화」) ──────
    #   왼쪽 목록 = 자료집 이름만 · 문답 사이는 띠의 「3/129문 ◀ ▶」 · 그 글자를 누르면 목차.
    def _pack_band(self):
        if not self._band.winfo_manager():
            self._band.pack(fill='x', padx=10, pady=(0, 2),
                            before=self._body_txt.master)
        # 연결된 자산 줄은 띠 바로 아래
        if self._tag_bar.winfo_manager():
            self._tag_bar.pack_configure(after=self._band)

    def _doc_ctx(self):
        """교리자료 글을 보고 있으면 (같은 자료집 글 목록, 그 안 자리). 아니면 None."""
        try:
            if self._left_nb.index(self._left_nb.select()) != 2:     # 교리자료 갈래만
                return None
        except Exception:
            pass
        u = getattr(self, '_current_doctrine_unit', None)
        if not u:
            return None
        rows = [x for x in getattr(self, '_doctrine_units', [])
                if x.get('src_code') == u.get('src_code')]
        idx = next((i for i, x in enumerate(rows) if x['unit_id'] == u['unit_id']), None)
        if idx is None:
            return None
        return rows, idx

    def _sync_doc_band(self):
        rows, idx = self._doc_ctx()
        self._pack_band()
        self._band_lbl.config(
            text=i18n.t('PR_DOC_POS', '{n}/{t}문').format(n=idx + 1, t=len(rows)))
        if not self._read_btn.winfo_ismapped():
            self._read_btn.pack(side='left', padx=(0, 8), after=self._book_open_box)
        self._prev_btn.config(state='normal' if idx > 0 else 'disabled')
        self._next_btn.config(state='normal' if idx < len(rows) - 1 else 'disabled')

    _DOC_POS_KEY = 'DOCTRINE_POS'

    def _doc_pos(self):
        try:
            import json
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (self._DOC_POS_KEY,)).fetchone()
            return json.loads(r[0]) if r and r[0] else {}
        except Exception:
            return {}

    def _save_doc_pos(self, u):
        """자료집마다 마지막으로 본 글 — 자료집 이름을 누르면 거기로 간다."""
        try:
            import json
            d = self._doc_pos()
            d[str(u.get('src_code'))] = u['unit_id']
            with appdb.connect(self.db_path) as c:
                c.execute("INSERT OR REPLACE INTO user_config (config_key, config_val) VALUES (?,?)",
                          (self._DOC_POS_KEY, json.dumps(d)))
        except Exception as e:
            print('[doc pos] %s' % e)

    def _nav_unit(self, delta):
        """이전/다음 **편** 한 칸."""
        dc = self._doc_ctx()
        if dc is not None:
            rows, idx = dc
            j = idx + delta
            if 0 <= j < len(rows):
                self._show_doctrine_unit(rows[j])
            return
        ctx = self._band_ctx()
        if ctx is None:
            return
        bid, uid = ctx
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                nxt = rs.step(c, bid, uid, delta)
        except Exception as e:
            print('[band nav] %s' % e)
            return
        if nxt is not None:
            self.jump_to_unit(nxt)

    def _resume_unit(self):
        """담아 둔 편으로."""
        ctx = self._band_ctx()
        if ctx is None:
            return
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                saved = rs.get_pos(c, ctx[0])
        except Exception as e:
            print('[band resume] %s' % e)
            return
        if saved and saved != ctx[1]:
            self.jump_to_unit(saved)

    @staticmethod
    def _unit_mark(read, fav):
        """편 표식 — **★ 즐겨찾기 · ● 읽음 · ○ 안 읽음**.

        ★★ **♥ 를 걷었다** (2026-08-31 사용자 신고 「유닛에 별표 클릭했는데
          유닛 제목 왼쪽에 하트표시가 된다. 별표는 불가능하기 때문인가」).
          불가능해서가 아니라 **옛 매트릭스가 남아 있었다** — 안 읽은 편을
          담으면 ♥, 읽은 뒤에 담으면 ★ 이라 **같은 클릭이 때에 따라 다른
          글리프**였다. 117차에 단추에서 걷은 그 규칙이 목록에만 남았다.
        ⇒ **담았으면 ★** (읽었든 아니든). ♥ 는 이제 **책 담아두기**의 글자다 —
          층이 다르므로 글리프도 갈라야 헷갈리지 않는다.
        ⚠ 전부 맑은 고딕 보유 글리프(cmap 실측 — 컬러 이모지 금지 §29).
        """
        if fav:
            return '★'
        return '●' if read else '○'

    _OPEN_BTN_W = 141      # 11언어 최장 라벨 + 여백(실측)

    _MARKS = ('●', '○', '★', '♥')

    def _refresh_read_mark(self, uid, done=None, tab_type=None):
        """목록의 그 줄 앞 표식만 바꾼다(읽음×즐겨찾기 매트릭스).

        ⚠ **목록을 다시 그리지 않는다** — 3,519행을 다시 지으면 화면이 멎고,
          펼쳐 둔 저자·구간이 접히고, 보던 자리를 잃는다.
        `done=None` 이면 DB 에서 다시 읽는다(즐겨찾기 토글 경로).
        """
        tabs = [tab_type] if tab_type else list(self._TAB_SPEC)
        for t in tabs:
            sp = self._spec(t)
            tv = getattr(self, sp['tv'], None) if sp else None
            if tv is None:
                continue
            iid = '%s%d' % (sp['leaf'], uid)
            if not tv.exists(iid):
                continue
            d = done
            if d is None:
                try:
                    import db_read_state
                    with appdb.connect(self.db_path) as conn:
                        d = uid in db_read_state.read_ids(conn,
                                                          kind=sp['kind'])
                except Exception:
                    d = False
            txt = tv.item(iid, 'text')
            if txt[:1] in self._MARKS:
                tv.item(iid, text=self._unit_mark(
                    d, self._is_favorite(uid, sp['kind'] == 'REF')) + txt[1:])

    def _refresh_fav_btn(self):
        """**편** 즐겨찾기 토글 — ☆ 아님 · ★ 이 편이 좋았다.

        ★★ **찜(♥)은 이 단추를 떠났다** (2026-08-31 `0.txt` 2번 사용자 —
          「유닛 단위의 찜하기 의미가 없다. 책 단위로 배치한다」). 이제
          **1단 ♥ = 책을 담아둔다 · 3단 ★ = 이 편이 좋았다** 로 뜻이 갈린다.
        ⚠ 그전에는 한 단추가 읽음 여부에 따라 ♥↔★ 로 바뀌었다 — 같은 클릭이
          때에 따라 다른 이름으로 보여, 눌러 놓고도 무엇을 표시한 것인지
          알 수 없었다.
        ⚠ **목록 표식(`_unit_mark`)의 매트릭스는 그대로다** — 거기서는
          ♥ 이 「안 읽었는데 담아 둔 편」을 뜻하고 그 값은 여전히 쓸모가 있다.
        """
        tab, u = self._cur_tab()
        uid = (u or {}).get('unit_id')
        if not uid:
            self._fav_btn.config(text='☆', fg='#7F8C8D')
            return
        if self._is_favorite(uid, tab == 'DOCTRINE'):
            self._fav_btn.config(text='★', fg='#F39C12')
        else:
            self._fav_btn.config(text='☆', fg='#7F8C8D')
        # 1단 ♥ 은 늘 함께 맞춘다 — 배선을 따로 두면 한쪽만 안 따라온다(§36)
        self._refresh_book_fav_btn()

    # ── UI 구성 ────────────────────────────────────────────────────────────────

    # 왼쪽 갈래 — 상단 단추와 노트북이 **같은 표**를 본다 (2026-08-16)
    # ★ **네 번째 = 서재**(0.txt 8번 탐색 대시보드, 2026-08-23).
    #   ⚠ **뒤에 붙인다** — 사용자 우려 「원래 첫번째에 배치하는 것이 좋은데 탭
    #     순서 바꾸는 것은 영향도가 큰 것 같다」. 뒤에 붙이면 앞의 셋은 번호가
    #     그대로라 저장된 직전 갈래·점프 경로가 하나도 안 어긋난다.
    #   ⚠ 「새로 수집하면 좋을 자료」를 사용자가 물어 훑었다(찬송가·신앙고백서·
    #     기독교 시가·어린이 읽을거리). **찬송가만 갈래급**이고 나머지는 도서
    #     분류로 충분하다 — 그런데 찬송가는 수집 프로젝트라 뒤로 미뤘고,
    #     갈래는 **뒤에 붙는 것**이라 나중에 다섯 번째로 넣어도 순서가 안 흔들린다.
    # ★★ **서재를 갈래에서 뗐다** (2026-08-24 사용자 「도서/설교집 대시보드를
    #   분리한다면 각 서브탭 아래에 버튼을 배치하는 것도 좋겠다」 · 「도서서재,
    #   설교서재 명칭을 구분하자」).
    #   ⚠ 갈래 하나가 둘을 겸할 수 없다 — **거르는 단위가 다르다**: 도서 서재는
    #     「어느 **책**」(35권 카드 격자), 설교 서재는 「어느 **설교**」(3,573편
    #     목록). 그래서 2단 bar 의 단추로 내리고 갈래는 셋으로 되돌린다.
    #   ⚠ 교리자료에는 단추를 두지 않는다 — 자료집이 넷뿐이라 트리로 충분하다
    #     (빈 서랍에 단추를 만들지 않는다, §4-⑤).
    SUBTABS = [('TAB_READING_BOOK', '도서읽기'),
               ('TAB_READING_SERMON', '설교집'),
               ('TAB_READING_DOCTRINE', '교리자료')]
    # 갈래 번호 → 서재 종류. 없으면 그 갈래에는 서재가 없다.
    SHELF_OF = {0: 'BOOK', 1: 'SERMON'}
    SHELF_LABEL = {'BOOK': ('TAB_READING_SHELF_BOOK', '▦ 도서 서재'),
                   'SERMON': ('TAB_READING_SHELF_SERMON', '▦ 설교 서재')}

    def _build(self):
        # ── 상단 bar ─────────────────────────────────────────────────────────
        # ★ **텅 빈 띠에 갈래 단추를 올렸다** (2026-08-16 사용자 지시
        #   「3개 서브탭을 텅빈 상단 bar로 이동 : 도서, 설교집, 교리자료, 언어콤보,
        #   갯수라벨, m버튼」). 왼쪽 칸 270px 안에서 탭 셋이 이름을 다투고 있었다.
        # ★ **검색창을 없앴다** (사용자: 「제목만 검색한다면 별로 의미가 없다」).
        #   실제로 제목·저자·태그만 뒤졌다. 본문 검색은 앱 전체 검색창(§7) 몫이다.
        #   ⚠ `_do_search`/`_clear_search` 는 **남겨 둔다** — 전체 검색창이 생기면
        #     그 함수를 그대로 쓴다. 화면에서 떼는 것과 지우는 것은 다르다.
        # ★ 두 단 구성 (2026-08-18 사용자 지시 `0.txt` 1번) —
        #   1단 = 갈래 단추만 · 2단 = 진행중 콤보 + Font + 언어콤보 + ⓜ.
        #   진행중 콤보는 묵상플랜 탭들과 같은 `plan_active_bar` 한 곳에서 온다.
        search_f = tk.Frame(self, bg='#EBF5FB')
        # ⚠ 위 여백 0 (2026-08-19 0.txt ③) — 묵상플랜 탭은 노트북 탭 줄이 메인 탭
        #   바로 아래 붙는데, 여기만 pady 6 이 있어 「메인 탭과 서브탭 사이 빈
        #   공간」으로 보였다(사용자 지적). 갈래 단추 줄도 같은 자리에서 시작한다.
        # ⚠ 왼쪽 여백 0 (2026-08-19 사용자 「도서읽기 탭 왼쪽 작은 공백 제거」) —
        #   묵상플랜 노트북 탭 줄은 왼쪽 끝에서 시작하는데 여기만 padx 4+6 이었다.
        # ★ 높이 = 노트북 탭 줄과 같은 27px **고정** (2026-08-19 사용자 「서브탭
        #   높이 일치 · 어떤 탭을 눌러도 흔들림 없어야」 — clam 탭 줄 실측 27px).
        #   pack_propagate 를 꺼서 자식(단추 26px)이 높이를 못 바꾼다.
        search_f.pack(fill='x', padx=0, pady=0)
        search_f.config(height=27)
        search_f.pack_propagate(False)

        self._sub_btns = {}
        for i, (key, dflt) in enumerate(self.SUBTABS):
            # ★ 서식 = **묵상플랜 서브탭(TNotebook.Tab)과 동일** (2026-08-18
            #   사용자 「헤더의 크기·폰트·서식을 묵상플랜 서브탭과 통일」):
            #   기본 글꼴 · padding (10,3) · 활성 = 진회색 바탕 + 흰 글자.
            #   색은 `_sync_sub_btns` 가 ui_theme 역할로 칠한다(테마 추종).
            # ⚠ 테두리 없음 (2026-08-19 사용자 「테두리가 검은색이다」) —
            #   노트북 탭에는 검은 윤곽선이 없다. 활성/비활성은 색으로만 가른다.
            b = tk.Button(search_f, text=' %s ' % i18n.t(key, dflt),
                          bd=0, relief='flat', padx=10, pady=3,
                          cursor='hand2',
                          command=lambda n=i: self._pick_sub(n))
            b.pack(side='left', padx=(0 if i == 0 else 2, 0))
            self._sub_btns[i] = b

        self._count_lbl = tk.Label(search_f, text='', bg='#EBF5FB',
                                   font=('', 8), fg='gray')
        self._count_lbl.pack(side='left', padx=(10, 0))

        # ── 2단 bar — 진행중 플랜 콤보 · Font · 언어콤보 · ⓜ ──
        #   규격 = 묵상플랜 액션 bar(`_make_plan_action_bar`)와 동일:
        #   높이 32px 고정 + #EAF2FB.
        bar2 = tk.Frame(self, bg='#EAF2FB', height=32)
        bar2.pack(fill='x', padx=4, pady=(0, 2))
        bar2.pack_propagate(False)
        # ★★★ **진행중 플랜 콤보를 「읽을 차례」로 갈아 끼웠다** (2026-08-31
        #   사용자 「읽을차례 => **진행중 플랜 콤보상자 자리에 배치**하는 것은
        #   어떤가?」 · 그 앞의 물음 「진행중 묵상플랜 콤보상자가 도서/설교
        #   서브탭에서도 표시된다. **이것이 정상인가?**」).
        #   ⚠⚠ 정상이 아니었다 — 그 콤보를 고르면 **이 탭을 떠나 묵상플랜 탭으로
        #     간다.** 이 화면에서 하는 일이 하나도 없었다. 99차에 도서묵상 탭을
        #     걷으며 붙었는데 117차에 [묵상플랜] 단추를 걷으며 짝을 잃었다.
        #     진행중 플랜은 묵상플랜 탭과 「나의 길」 두 곳에 이미 있다.
        #   ⇒ **자리를 늘리지 않고** 쓸모를 잃은 위젯을 바꿔 끼운다(순증 0).
        #   ★ 단추가 아니라 **콤보**다 — 옛 콤보가 하던 일(고르면 그리로 간다)을
        #     그대로 잇는다. 자주 하는 일은 「다음 책 열기」이지 「순서 바꾸기」가
        #     아니다. 차례를 고치는 길은 맨 아래 한 줄로 둔다.
        self._enr_bar = None
        _obg = bar2.cget('bg')
        self._ord_lbl = tk.Label(bar2, text=i18n.t('PR_ORDER', '읽을 차례'),
                                 bg=_obg, fg='#1A5276', font=('', 9, 'bold'))
        self._ord_lbl.pack(side='left', padx=(6, 2), pady=3)
        self._ord_var = tk.StringVar()
        self._ord_cb = ttk.Combobox(bar2, textvariable=self._ord_var,
                                    state='readonly', width=34)
        self._ord_cb.pack(side='left', padx=(0, 6), pady=3)
        self._ord_cb.bind('<<ComboboxSelected>>', self._on_order_pick)
        self._ord_rows = []
        # Font 단추는 그대로 남는다 — 콤보와 함께 걷으면 글꼴 설정 입구가 사라진다
        if callable(getattr(self, 'on_font_open', None)) or True:
            import ui_theme as _ut
            tk.Button(bar2, text=i18n.t('RS_BTN', 'Font'),
                      command=lambda: (callable(self.on_font_open)
                                       and self.on_font_open()),
                      **_ut.flat_btn()).pack(side='left', padx=(0, 4), pady=2)

        tk.Frame(bar2, bg='#BDC3C7', width=1,
                 height=16).pack(side='left', padx=(14, 8), pady=2)
        # ★ **표시 언어 콤보 하나** (2026-08-14 사용자 결정 「판본의 번역본을
        #   표시하거나 설명문의 언어를 표시하는 것은 동일하다」).
        import lang_combo
        self._lang = lang_combo.LangCombo(
            bar2, db_path=self.db_path,
            on_change=lambda _c: self._on_global_variant_change(),
            width=14, gap=0, pady=0,        # 글꼴 미지정 = 표준(0.txt ④)
            default_lang=self.lang_getter().upper(),
            key='LANGSEL_BOOK')
        self._lang.set_items(lang_combo.variant_items())   # 고정 목록
        self._g_lang_cb = self._lang.combo
        self._sync_vars()

        # ⓜ 매뉴얼 — 2단 오른쪽 끝
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar2, 'U_P1_T3',
                               lang_provider=self.lang_getter).pack(side='right', padx=8)
        except Exception as e:
            print('[reading manual] %s' % e)

        # ★ **서재 단추 — 갈래마다 제 서재**(2026-08-24). 이름이 갈래를 말한다.
        #   ⚠ **오른쪽 자리를 ⓜ 다음에 잡는다** — Tk 는 pack 부른 차례대로 자리를
        #     나눠, 왼쪽 것들이 먼저 폭을 먹으면 오른쪽 묶음이 줄 밖으로 나간다
        #     (1024 창에서 녹음·설정 단추가 사라지던 그 사고, §72차).
        self._shelf_btn = tk.Button(bar2, text='', bd=1, relief='raised',
                                    padx=8, pady=0, cursor='hand2',
                                    command=self._toggle_shelf)
        self._shelf_btn.pack(side='right', padx=(0, 4))

        # ── 구분선 ──────────────────────────────────────────────────────────
        tk.Frame(self, bg='#AED6F1', height=1).pack(fill='x')

        # ── 본문 영역 ────────────────────────────────────────────────────────
        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#D5DBDB')
        pw.pack(fill='both', expand=True, padx=4, pady=4)

        left_f = tk.Frame(pw, bg='#FDFEFE')
        pw.add(left_f, width=270)
        self._build_left(left_f)

        right_f = tk.Frame(pw, bg='#FDFEFE')
        pw.add(right_f)
        self._build_right(right_f)
        self._pw = pw

        # ★ **서재는 좌우 나눔 밖이다** — 카드 격자라 **전체 폭**이 필요하다.
        #   왼쪽 270px 안에 넣으면 카드가 한 줄에 하나밖에 안 들어간다.
        #   ⚠ 만들어만 두고 `pack` 하지 않는다 — 고를 때 `pw` 와 갈아 끼운다.
        #     (§3 캔버스/트리뷰 전환과 같은 방식 — `destroy` 하면 스크롤·필터
        #      상태를 잃는다.)
        #   ⚠ 종류마다 한 벌씩 **만들어 두고 갈아 끼운다** — destroy 하면 켠 체크와
        #     스크롤을 잃는다(§3 캔버스/트리뷰 전환과 같은 방식).
        self._shelves = {}          # 'BOOK'|'SERMON' → 위젯
        self._shelf_on = None       # 지금 떠 있는 서재(없으면 None)

    def _build_left(self, f):
        # ★ 탭 줄을 **감춘다** — 갈래는 위 상단 bar 단추가 고른다(2026-08-16).
        #   ⚠ 노트북 자체는 **그대로 둔다.** `select`·`index('current')`·
        #     `<<NotebookTabChanged>>` 를 쓰는 코드가 이미 여럿이라 프레임 교체로
        #     바꾸면 그 배선을 다시 짜야 한다. **보이는 것만** 없앤다.
        st = ttk.Style()
        try:
            st.layout('NoTabs.TNotebook.Tab', [])
        except Exception:
            pass
        self._left_nb = ttk.Notebook(f, style='NoTabs.TNotebook')
        self._left_nb.pack(fill='both', expand=True)

        book_tab = tk.Frame(self._left_nb, bg='#FDFEFE')
        self._left_nb.add(book_tab, text=' '+i18n.t('TAB_READING_BOOK','도서읽기')+' ')
        self._build_book_tree(book_tab)

        sermon_tab = tk.Frame(self._left_nb, bg='#FDFEFE')
        self._left_nb.add(sermon_tab, text=' '+i18n.t('TAB_READING_SERMON','설교집')+' ')
        self._build_sermon_tree(sermon_tab)

        doctrine_tab = tk.Frame(self._left_nb, bg='#FDFEFE')
        self._left_nb.add(doctrine_tab, text=' '+i18n.t('TAB_READING_DOCTRINE','교리자료')+' ')
        self._build_doctrine_tree(doctrine_tab)

        # [Phase 2-C'] ★ 즐겨찾기 서브탭 제거 — 통합 조회는 P1 탭4 '나의 길'에서.
        # 각 도서/설교 본문의 ★ 추가 버튼은 그대로 유지.

        self._left_nb.bind('<<NotebookTabChanged>>', self._on_subtab_change)
        self._left_nb.bind('<<NotebookTabChanged>>', self._sync_sub_btns, add='+')
        self.after_idle(self._sync_sub_btns)

    def _pick_sub(self, n):
        """갈래 단추 — 갈래를 옮기면 **서재는 닫는다**(다른 갈래의 서재였다)."""
        self._show_shelf(None)
        try:
            self._left_nb.select(n)
        except Exception:
            pass
        self._cur_sub = n
        self._sync_sub_btns()
        self._refresh_order_combo()      # 갈래마다 제 차례다(도서/설교 구분)

    # ── 서재 ──────────────────────────────────────────────────────────────
    def _cur_shelf_kind(self):
        try:
            return self.SHELF_OF.get(self._left_nb.index(self._left_nb.select()))
        except Exception:
            return None

    def _toggle_shelf(self):
        kind = self._cur_shelf_kind()
        if not kind:
            return
        self._show_shelf(None if self._shelf_on == kind else kind)

    def _make_shelf(self, kind):
        lg = (lambda: (self.lang_getter() or 'KO')
              if callable(getattr(self, 'lang_getter', None)) else 'KO')
        if kind == 'SERMON':
            import sermon_shelf
            w = sermon_shelf.SermonShelf(
                self, self.db_path, lang_getter=lg,
                on_open=self._sermon_shelf_open,
                on_download=self._shelf_download,
                read_getter=self._read_units)
            w.on_order_changed = self._refresh_order_combo
            return w
        import book_shelf
        w = book_shelf.BookShelf(
            self, self.db_path, lang_getter=lg,
            on_open=self._shelf_open,
            cat_label=self._cat_label,
            read_getter=self._read_count,
            on_download=self._shelf_download,
            # ★ 도서 서재에서 설교집을 뺀다 — 그쪽은 설교 서재가 맡는다
            only_cats=[c for c in _CATEGORY_LABELS if c != 'SERMON'])
        # ▲▼ 로 차례를 고치면 **2단 콤보도 함께** 바뀌어야 한다 — 두 곳이
        # 어긋나면 「고쳤는데 안 바뀐다」가 된다.
        w.on_order_changed = self._refresh_order_combo
        return w

    def _show_shelf(self, kind):
        """`kind` 가 None 이면 닫고 본문으로 돌아간다.

        ⚠ **서재는 좌우 나눔 밖이다** — 카드 격자·긴 목록이라 전체 폭이 필요하다.
          `pw` 와 `pack_forget` 으로 갈아 끼운다(destroy 하면 상태를 잃는다).
        """
        for k, w in self._shelves.items():
            if k != kind and w.winfo_manager():
                w.pack_forget()
        if kind:
            w = self._shelves.get(kind)
            if w is None:
                try:
                    w = self._shelves[kind] = self._make_shelf(kind)
                except Exception as e:
                    print('[shelf %s] %s' % (kind, e))
                    return
            if self._pw.winfo_manager():
                self._pw.pack_forget()
            if not w.winfo_manager():
                w.pack(fill='both', expand=True, padx=4, pady=4)
            try:
                w.reload()
            except Exception as e:
                print('[shelf reload %s] %s' % (kind, e))
        elif not self._pw.winfo_manager():
            self._pw.pack(fill='both', expand=True, padx=4, pady=4)
        self._shelf_on = kind
        self._sync_shelf_btn()

    def _sync_shelf_btn(self):
        """단추 이름은 **그 갈래의 서재 이름**. 서재가 없는 갈래에서는 감춘다."""
        b = getattr(self, '_shelf_btn', None)
        if b is None:
            return
        kind = self._cur_shelf_kind()
        if not kind:
            b.pack_forget()
            return
        if not b.winfo_manager():
            b.pack(side='right', padx=(0, 4))
        ikey, dflt = self.SHELF_LABEL[kind]
        on = (self._shelf_on == kind)
        b.config(text=i18n.t(ikey, dflt), relief='sunken' if on else 'raised',
                 bg=(_C('dark_bg', '#2C4259') if on else _C('panel', '#FFFFFF')),
                 fg=(_C('fg_on_dark', '#FFFFFF') if on else _C('fg', '#2C3E50')))

    def _cat_label(self, code):
        """분류 이름 — **도서 트리와 같은 말**을 쓴다(두 화면이 갈라지지 않게).

        ⚠ `_CATEGORY_LABELS` 는 **모듈 상수**다(클래스 속성이 아니다)."""
        try:
            return _CATEGORY_LABELS.get(code, code) or code
        except Exception:
            return code

    def _read_count(self, book_id):
        """그 책에서 읽은 유닛 수 — 서재 카드의 ●/○ 와 「읽은 것」 정렬용.

        ⚠ 표를 직접 물어보지 않고 `db_read_state` 를 쓴다 — **`kind` 를 빼먹으면
          도서와 교리자료가 서로 물든다**(unit_id 549개가 겹친다).
        """
        try:
            import db_read_state
            with appdb.connect(self.db_path) as c:
                kind = 'SERMON' if self._book_cat(book_id) == 'SERMON' else 'BOOK'
                return len(db_read_state.read_ids(c, book_id=book_id, kind=kind))
        except Exception:
            return 0

    def _book_cat(self, book_id):
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT book_category FROM sys_book_asset "
                              "WHERE book_id=?", (book_id,)).fetchone()
            return (r[0] if r else '') or ''
        except Exception:
            return ''

    def _read_units(self, book_id):
        """그 도서·설교집에서 **읽은 unit_id 집합** — 설교 서재의 ●/○ 용.

        ⚠ `_read_count` 는 개수만 준다. 설교 서재는 **편마다** 표식을 그리므로
          집합이 필요하다. `kind` 를 빼면 도서와 교리자료가 물든다(id 549개 겹침).
        """
        try:
            import db_read_state
            with appdb.connect(self.db_path) as c:
                kind = 'SERMON' if self._book_cat(book_id) == 'SERMON' else 'BOOK'
                return set(db_read_state.read_ids(c, book_id=book_id, kind=kind))
        except Exception:
            return set()

    def _shelf_download(self, book_id):
        """**아직 안 받은 자료** — 도서 탭이 아니라 다운로드 화면으로(사용자 지시).

        ⚠ 임시 페이지를 만들지 않았다 — **설정 ▸ 다운로드**가 이미 그 화면이다
          (`feedback_view._build_download`). 없는 화면을 또 지으면 두 곳이 된다.
        """
        if callable(getattr(self, 'on_download_jump', None)):
            self.on_download_jump(book_id)
        else:
            print('[shelf] 다운로드 화면 경로가 배선되지 않았다 (book_id=%s)' % book_id)

    def _sermon_shelf_open(self, unit_id):
        """설교 서재의 줄을 누르면 **설교집 갈래로 가서 그 편**을 연다."""
        self._pick_sub(1)
        self.after(60, lambda uid=unit_id: self.jump_to_unit(uid))

    def _shelf_open(self, book_id):
        """카드를 누르면 **그 책의 소개문**으로 (2026-08-31 사용자 지적).

        ★★★ 그전에는 **첫 편 본문**을 곧장 폈다. 서재는 「무엇을 읽을까」를
          고르는 자리인데 고르기도 전에 읽기가 시작됐다. 게다가 **안 받은
          책은 소개문을 건너뛰고 다운로드 화면**으로 가서, 소개문을 못 읽으니
          ♥ 를 누를 수 없고 읽을 차례의 후보가 될 길이 아예 없었다.
        ⇒ 소개문 한 화면에서 **읽고 · ♥ 담고 · [읽기 시작] 또는 [↓ 받기]**.
        ⚠ 서재는 닫는다 — 소개문이 그 아래에 있어 안 닫으면 안 보인다.
        """
        cat = self._book_cat(book_id)
        self._show_shelf(None)
        self._pick_sub(1 if cat == 'SERMON' else 0)
        self.after(60, lambda b=book_id: self._show_book_info(b))

    def _open_book_first(self, book_id):
        """[읽기 시작] — 그 책의 첫 편으로. (옛 `_shelf_open` 의 몸통)"""
        cat = self._book_cat(book_id)
        self._pick_sub(1 if cat == 'SERMON' else 0)
        src = self._sermon_units if cat == 'SERMON' else self._book_units
        u = next((x for x in src if x.get('book_id') == book_id), None)
        if u is None:
            print('[shelf open] 유닛이 없다 book_id=%s' % book_id)
            return
        self.after(60, lambda uid=u['unit_id']: self.jump_to_unit(uid))

    def set_branch_buttons(self, visible):
        """갈래 단추 셋(도서읽기·설교집·교리자료)을 보이거나 감춘다(317차-28).

        P1 이 **왼쪽 탭 막대**일 때는 막대가 그 아래에 갈래를 펼치므로 여기 단추는 감춘다
        (사용자 「묵상플랜과 마찬가지 · 두곳에 배치하는 것은 중복」). 개수 글은 남긴다.
        """
        btns = [self._sub_btns[i] for i in sorted(getattr(self, '_sub_btns', {}))]
        try:
            if visible:
                for i, b in enumerate(btns):
                    if not b.winfo_manager():
                        b.pack(side='left', padx=(0 if i == 0 else 2, 0),
                               before=self._count_lbl)
            else:
                for b in btns:
                    b.pack_forget()
        except Exception as e:
            print('[reading branch btns] %s' % e)

    def _sync_sub_btns(self, _e=None):
        """선택한 갈래 단추를 묵상플랜 서브탭(TNotebook.Tab)과 같은 모양으로.

        색은 **ui_theme 역할에서 그때그때 읽는다**(활성 = dark_bg + fg_on_dark,
        비활성 = panel_alt + fg — `apply_notebook_tabs` 의 map 과 동일 값).
        박아 두면 테마를 바꿀 때 그 자리만 굳는다(font.md §36-3).
        """
        try:
            cur = self._left_nb.index(self._left_nb.select())
        except Exception:
            return
        try:
            import ui_theme
            on = (ui_theme.C('dark_bg'), ui_theme.C('fg_on_dark'))
            off = (ui_theme.C('panel_alt'), ui_theme.C('fg'))
        except Exception:
            on, off = ('#5D6D7E', '#FFFFFF'), ('#ECECEC', '#000000')
        for i, b in getattr(self, '_sub_btns', {}).items():
            try:
                bg, fg = on if i == cur else off
                b.config(bg=bg, fg=fg, activebackground=bg,
                         activeforeground=fg, relief='flat')
            except Exception:
                pass
        self._sync_shelf_btn()

    def _build_book_tree(self, f):
        s = ttk.Style()
        # ★ 표준 목록 트리 = `theme_font.list_style` 하나 (2026-08-18 사용자 지시
        #   「계속 표준 서식 따르도록 수정했는데 왜 이런 일이」 — 여기가 9pt/22px
        #   하드코딩으로 남아 있던 자리다. 글꼴·행높이·indent 는 저 함수가 정한다).
        import theme_font as _tf
        _tf.list_style('Reading.Treeview', self.db_path, heading=False)
        s.configure('Reading.Treeview',
                    background='#FDFEFE', fieldbackground='#FDFEFE')
        self._book_recent_f = tk.Frame(f, bg='#EBF5FB')

        tree_f = tk.Frame(f, bg='#FDFEFE')
        tree_f.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(tree_f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._book_tv = ttk.Treeview(tree_f, show='tree', selectmode='browse',
                                     style='Reading.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._book_tv.yview)
        self._book_tv.pack(fill='both', expand=True)
        # 색 표준 = 플랜 트리와 같게(2026-08-18 전수 정리): 묶음 층 = fg_title,
        #   항목(유닛)은 기본색, 빈 줄 = fg_dim.
        # ★ 태그 색은 **채울 때마다 역할로 재적용**(_retag_trees — §36-5b.
        #   2026-08-19 사용자 신고 「P4 [▶ 보기] 점프 직후 카테고리 글자가 안
        #   보인다, 리사이즈하면 정상화」: 탭 전환 paint 가 돌 때 트리가 아직
        #   비어 있어 태그 번역이 안 걸리고, 하드코딩 남색이 어두운 바탕에
        #   그대로 남았다. 리사이즈의 ButtonRelease paint 가 뒤늦게 고쳐 준
        #   것이었다 — 실측으로 잡음).
        self._retag_trees()
        # 'fav' 금색은 폐기(2026-08-18) — ★♥ 표식 매트릭스가 대신한다
        self._book_tv.bind('<<TreeviewSelect>>', self._on_book_select)
        # ★ **더블클릭 = 목차 팝업** (2026-08-31 사용자 「왼쪽 도서목록을
        #   더블클릭하면 진도버튼 클릭한 것과 **동일한 효과**」). 한 번은 고르고
        #   두 번은 펼친다 — 트리의 보통 문법이다.
        self._book_tv.bind('<Double-1>', self._toc_from_tree)

    def _retag_trees(self):
        """세 트리의 태그 색을 **그 시점 테마 역할로** 재적용 (§36-5b).

        ⚠ Treeview 태그는 ui_theme.paint 가 빈 트리에서는 못 잡는다 — 빌드 때와
          **채울 때마다** 이 함수를 부른다. 아직 안 만든 트리는 건너뛴다.
        """
        # ★★ **책 이름은 본문과 같은 글자색**(2026-08-31 사용자 「본문과 같이
        #   표준서식에 맞추어라」). 그전에는 `fg_title` 이라 테마마다 남색·갈색·
        #   하늘색으로 갈렸고, 밝은 테마에서 **흐릿**했다.
        #   ⚠ **묶음(분류) 줄만** 제목 색을 지킨다 — 그 줄은 이름이 아니라
        #     칸막이라, 같은 색이면 책과 분류가 안 갈린다.
        try:
            import ui_theme
            title = ui_theme.C('fg_title') or '#1A5276'
            body = ui_theme.C('fg') or '#2C3E50'
            dim = ui_theme.C('fg_dim') or '#95A5A6'
        except Exception:
            title, body, dim = '#1A5276', '#2C3E50', '#95A5A6'
        for tv_name, tags in (('_book_tv', ('cat', 'book')),
                              ('_sermon_tv', ('author', 'book')),
                              ('_doctrine_tv', ('src', 'section', 'alpha'))):
            tv = getattr(self, tv_name, None)
            if tv is None:
                continue
            try:
                for t in tags:
                    # 묶음(분류·저자·자료집)은 제목 색 · **낱낱(책)은 본문 색**
                    tv.tag_configure(
                        t, foreground=(body if t == 'book' else title))
                tv.tag_configure('no_result', foreground=dim)
            except Exception:
                pass

    def _build_sermon_tree(self, f):
        self._sermon_recent_f = tk.Frame(f, bg='#EBF5FB')

        tree_f = tk.Frame(f, bg='#FDFEFE')
        tree_f.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(tree_f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._sermon_tv = ttk.Treeview(tree_f, show='tree', selectmode='browse',
                                       style='Reading.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._sermon_tv.yview)
        self._sermon_tv.pack(fill='both', expand=True)
        self._retag_trees()                       # 태그 색 = 역할 (§36-5b)
        self._sermon_tv.bind('<<TreeviewSelect>>', self._on_sermon_select)
        # ★ **더블클릭 = 목차 팝업** (2026-08-31 사용자 「왼쪽 도서목록을
        #   더블클릭하면 진도버튼 클릭한 것과 **동일한 효과**」). 한 번은 고르고
        #   두 번은 펼친다 — 트리의 보통 문법이다.
        self._sermon_tv.bind('<Double-1>', self._toc_from_tree)

    def _build_doctrine_tree(self, f):
        self._doctrine_recent_f = tk.Frame(f, bg='#EBF5FB')

        tree_f = tk.Frame(f, bg='#FDFEFE')
        tree_f.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(tree_f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._doctrine_tv = ttk.Treeview(tree_f, show='tree', selectmode='browse',
                                         style='Reading.Treeview',
                                         yscrollcommand=vsb.set)
        vsb.config(command=self._doctrine_tv.yview)
        self._doctrine_tv.pack(fill='both', expand=True)
        self._retag_trees()                       # 태그 색 = 역할 (§36-5b)
        self._doctrine_tv.bind('<<TreeviewSelect>>', self._on_doctrine_select)

    def _build_favorites_tree(self, f):
        vsb = ttk.Scrollbar(f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._fav_tv = ttk.Treeview(f, show='tree', selectmode='browse',
                                    style='Reading.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._fav_tv.yview)
        self._fav_tv.pack(fill='both', expand=True)
        # 즐겨찾기 목록 행은 항목 층 — 기본색(유형은 글머리가 이미 말한다)
        self._fav_tv.bind('<<TreeviewSelect>>', self._on_favorites_select)

    def _build_right(self, f):
        # ★ 헤더 2안 — 상하 구분 (2026-08-18 `0.txt` 3번 사용자 승인):
        #   [상] 제목 / 부제 · [하] 동작 줄(읽음 토글·♥★·연구자료·링크 칩).
        #   라벨은 짧게(「아직 읽지 않았습니다」→「읽는중」, 「✎ 연구자료
        #   기록하기」→「연구자료」 — ✎ 는 맑은 고딕에 없는 글리프이기도 하다).
        meta_f = tk.Frame(f, bg='#FDFEFE')
        meta_f.pack(fill='x', padx=10, pady=(10, 0))
        # ★ 맨 왼쪽 = [Focus]/[Restore] 자리 (2026-09-16 · 1.txt 10번 「P1 모든 탭에서
        #   Focus 버튼이 가장 왼쪽」). 단추는 호스트(user_main)가 심는다 — P4 를 접는
        #   일은 이 화면이 모른다.
        self.focus_slot = tk.Frame(meta_f, bg='#FDFEFE')
        self.focus_slot.pack(side='left', padx=(0, 8))
        self._meta_title = tk.Label(
            meta_f, text='', bg='#FDFEFE',
            font=('', 11, 'bold'), fg='#1A5276',
            anchor='w', wraplength=640, justify='left')
        self._meta_title.pack(side='left')
        # ★★ **책 담아두기(♥)는 1단 오른쪽** — 이 줄이 곧 「책의 정보」다
        #   (2026-08-31 `0.txt` 2번). 편 즐겨찾기(★)는 3단으로 내려갔다.
        self._book_fav_btn = tk.Button(
            meta_f, text='♡', font=('', 11),
            bg='#FDFEFE', bd=0, relief='flat', cursor='hand2',
            command=self._toggle_book_favorite)
        self._book_fav_btn.pack(side='right', padx=(6, 2))

        # ★ 2026-10-13 79-1 — 부제(저자·연도)는 **제목 줄 안에** 붙인다(4줄 → 2줄).
        self._meta_sub = tk.Label(
            meta_f, text='', bg='#FDFEFE',
            font=('', 9), fg='#666', anchor='w')
        self._meta_sub.pack(side='left', fill='x', expand=True, padx=(10, 0))
        # ★ 둘째 줄 = 진행 띠 하나가 **편의 기능까지** 함께 든다(79-1)
        self._band = tk.Frame(f, bg='#FDFEFE')
        self._band.pack(fill='x', padx=10, pady=(0, 2))

        # ── [하] 동작 줄 — 읽음 토글이 상태를 겸한다(○ 읽는중 ↔ ● 읽음) ──
        # ★ 2026-10-13 79-1 — 음각/양각 단추를 걷고 **Font 와 같은 라벨 꼴**(`ui_theme.flat_btn`)
        import ui_theme as _uth
        _BTN = _uth.flat_btn(font=('', 9))
        _BTN.pop('fg', None)
        # ⚠ 옛 3단(`act_f`)은 **화면에 안 붙인다** — ☆ 편 즐겨찾기·[연구/설교노트]·[연결된 자산 보기]·
        #   약명·⇄ 장 비교가 거기 남아 있다(79-1 걷음 · 부르는 코드가 많아 위젯은 둔다).
        act_f = tk.Frame(f, bg='#FDFEFE')
        # ⚠ **읽음 토글은 이 줄을 떠났다** — 진행 띠의 [✓ 완료]와 **같은 뜻의
        #   단추 둘**이 되므로 하나로 합쳤다(2026-08-19 사용자 확정). 만드는 자리는
        #   아래 진행 띠이고, 이름(`_read_btn`)·`_toggle_read`·`_refresh_read_btn`
        #   은 그대로 둔다 — 부르는 곳이 여럿이다.
        self._act_f = act_f               # 진행 띠가 이 앞에 끼어든다(2단)
        # ★★ **별표가 가장 오른쪽 · 단추와 사이에 공백** (2026-08-31 사용자
        #   「별표를 가장 오른쪽으로 배치하라. 별표와 버튼 사이에 공백을 두어라.
        #   그러면 **하트, 별표가 직접 대비된다**」).
        #   ⇒ 1단 ♥(책)과 3단 ★(편)이 **같은 세로줄**에 놓여 층이 눈에 보인다.
        # ⚠ `side='right'` 는 **먼저 pack 한 것이 더 오른쪽**이다 — ★ 를 가장
        #   먼저 붙이고, 공백, 그다음 단추들을 **역순**으로 붙인다.
        self._fav_btn = tk.Button(
            act_f, text='☆', font=('', 11),
            bg='#FDFEFE', bd=0, relief='flat', cursor='hand2',
            command=self._toggle_favorite)
        self._fav_btn.pack(side='right', padx=(0, 2))
        tk.Frame(act_f, bg='#FDFEFE', width=18).pack(side='right')
        # ★★★ **[단순읽기]/[묵상] 갈래를 걷었다 — 둘의 장점을 합친다**
        #   (2026-08-31 `0.txt` 2번 사용자 「두 가지 장점을 통합하고 싶다.
        #   묵상의 장점 : 묵상포커스, 구절과의 풍성한 연결 / 도서읽기의 장점 :
        #   날자 구분 없이 자율진행(이전/다음 버튼)」).
        #   ⇒ **묵상 재료가 있으면 언제나 보이고, 걸음은 늘 자유롭다.**
        #     하루치로 끊는 일은 안 한다 — 그 몫은 진행 띠(2단)가 한다.
        #   ⚠ 갈래를 두면 「고르고 나서야 재료가 있는지 알 수 있는」 스위치가
        #     된다. 재료가 없는 편에서는 단추가 사라져 깜빡이기까지 했다.
        # ★★ **[묵상플랜] 단추도 걷었다** (사용자 「용도가 없는 것 같다.
        #   제거하라」). 하루 진도는 진행 띠가 이미 말하고, 플랜의 알맹이
        #   (묵상 포커스·연결 구절)는 이제 등록 없이도 보인다.
        #   ⚠ **등록해 둔 플랜으로 가는 길은 「나의 길 ▸ 묵상 진행중」 하나만
        #     남는다**(`_book_plan_jump`). `_open_book_plan`·`_book_plans` 는
        #     지우지 않았다 — 되살릴 때 그대로 쓴다.
        self._research_btn = tk.Button(
            act_f, text=i18n.t('PR_RESEARCH_NEW', '연구/설교노트'),
            fg='#2E86C1', command=self._write_research, **_BTN)
        # (아래에서 오른쪽 정렬로 한꺼번에 붙인다)
        # ★ 묵상노트 통합 (2026-08-19) — **닻은 편**이다(2026-08-24 사용자 확정).
        #   기준 구절이 없어도 쓴다 — 그 편에 대한 글이지 구절에 대한 글이 아니다.
        self._note_btn = tk.Button(
            self._band, text=i18n.t('MN_WRITE_BOOK', '도서노트'),
            fg='#1E8449', command=self._write_note, **_BTN)
        
        # ★ **이 책의 여백메모** (2026-08-24 사용자 지시) — 한 권을 되짚어 읽는
        #   자리. 「나의 묵상 ▸ 내 메모」는 전 자료를 한 목록으로 보여 주므로
        #   책 단위로 훑을 길이 따로 필요하다. **메모가 있을 때만 뜬다.**
        self._memos_btn = tk.Button(
            self._band, text=i18n.t('MN_MEMOS_BOOK', '이 책의 여백메모'),
            fg='#8B0000', command=self._open_book_memos, **_BTN)
        # ★ **[연결]** (2026-08-21) — [태그] 단추를 대체한다(0.txt 3번).
        #   도서·설교 유닛과 **교리자료 글** 둘 다 이 단추 하나가 맡는다.
        # ★★ **[연결] → [My Edit]** (2026-08-30 사용자 지시 0.txt 4번
        #   「"연결" 버튼 제거」 + My Edit 통합). 연결은 My Edit 안의 조리대
        #   하나다 — 같은 일에 입구가 둘이면 규칙이 갈라진다.
        #   ⚠ 이름(`_tag_btn`)·`_edit_unit_tags` 는 그대로 둔다 — 부르는 곳이 있다.
        self._tag_btn = tk.Button(
            self._band, text=i18n.t('OE_BTN', 'My Edit'),
            fg='#1A5276', command=self._open_my_edit, **_BTN)
        
        # ★ **[연결된 자산 보기 (n)]** — 옛 `⇄ 장 비교` 가 있던 자리다.
        self._assets_btn = tk.Button(
            act_f, text='', fg='#7D3C98',
            command=self._toggle_assets, **_BTN)
        # ★ 차례 = 왼→오 `연구자료 · 도서노트 · My Edit · 연결된 자산 보기`
        #   (사용자 지시). `side='right'` 이므로 **역순으로** 붙인다.
        # ★ 차례 = 왼→오 `이 책의 여백메모 · 연구자료 · 도서노트 · My Edit ·
        #   연결된 자산 보기`(2026-08-31 사용자 「"이책의 여백메모" 버튼도
        #   연구자료 왼쪽에 배치하라」). `side='right'` 이므로 **역순**으로.
        # ⚠ `_memos_btn` 은 **메모가 있을 때만** 뜬다(`_refresh_memos_btn`) —
        #   여기서는 자리만 잡고 붙이지 않는다.
        # ★ 차례 = 왼→오 `My Edit · (여백메모) · 연구자료 · 도서노트 ·
        #   연결된 자산 보기` (2026-08-31 사용자 「**My Edit 버튼이 같은 행의
        #   가장 왼쪽에** 배치되도록 이동하라」).
        #   ⚠ `side='right'` 는 **먼저 pack 한 것이 더 오른쪽**이라 역순으로
        #     붙인다 — 맨 왼쪽에 놓을 것을 **맨 나중에** 붙인다.
        # 둘째 줄 오른쪽 = (여백메모) · 도서노트 · My Edit — 왼→오
        for _b in (self._tag_btn, self._note_btn):
            _b.pack(side='right', padx=(6, 0))
        # ★ 2026-10-13 docs/1.txt 81 — **[AI 묵상]**: 처음부터 자리는 보이되(흐린 글자 「끝까지 읽으면 열립니다」)
        #   본문을 끝까지 내리거나 「● 읽음」을 누르면 진해지고 반짝인다. 시험 단계라 `AI_BOOK_TEST` 책만.
        self._ai_btn = tk.Button(self._band, text='', command=self._ai_book_click, **_BTN)
        self._ai_open = set()          # 이번에 연 편(다시 와도 열린 채)
        # (2026-10-13 — 옛 [약명 ▸]·[⇄ 장 비교] 단추를 지웠다. 2026-08-31 에 화면에서 걷은 뒤 한 번도 안 붙던
        #  죽은 위젯이었다. 같은 일은 본문 머리의 핵심구절 약명을 누르면 된다 — `_goto_chapter_compare`.)
        # 연결된 연구자료 링크 칩 — 같은 줄 오른쪽으로 이어 붙는다
        self._res_f = act_f                      # 옛 이름 호환(재-pack 불필요)
        self._res_box = tk.Frame(act_f, bg='#FDFEFE')
        self._res_box.pack(side='left', fill='x', expand=True, padx=(10, 0))
        # 옛 상태 라벨(_read_lbl)은 폐기 — 토글 버튼이 상태를 말한다.
        self._read_lbl = None

        # 태그 바: 분류라벨(solid badge) + 연구태그(# bordered badge)
        # ★★★ **연결 자산 줄은 접어 둔다** (2026-08-31 `0.txt` 1번 6) 사용자
        #   「상단 bar에 표시된 연결 목록이 너무 복잡하다. 1단 제목 2단 이동
        #   버튼까지는 항상 표시하자. "연결된 자산 보기(4)"와 같은 버튼을 현재
        #   "장비교" 버튼 자리에 배치하고, 클릭하면 그 아래에 추가로 표시」).
        #   ⚠ 접혀 있어도 **개수는 단추가 말한다** — 「(0)」이면 열어 볼 것이
        #     없다는 뜻이라 헛클릭이 없다(§0-1 빈 서랍 금지의 접이판).
        #   ⚠ 편을 옮기면 **다시 접는다** — 펼친 채로 두면 편마다 3단 높이가
        #     달라져 본문 시작선이 오르내린다.
        self._tag_bar = tk.Frame(f, bg='#FDFEFE')
        self._tag_open = False
        self._tag_bar_ready = False

        # ── 진행 띠 (2026-08-24, `0.txt` 9번 사용자 확정) ──────────────────
        # ★★ **분기(읽기/묵상 고르기)가 아니라 「띠」다** — 도서 화면에 가로줄
        #   하나를 얹는다. 목차·본문은 그대로. 분기를 반대한 이유 둘:
        #   ① 읽어 보기 전에는 못 고른다 ② 도중에 마음이 바뀌면 화면을 건너가야
        #   하고 읽던 자리를 잃는다.
        # ⚠⚠ **날짜 말투를 쓰지 않는다**(사용자) — 「13일차」·「어제/오늘/내일」이
        #   아니라 **`◐ 13 / 216`**.
        # ★ **플랜이 없는 책에서도 돈다** — 유닛 순서 + 읽음 기록만 쓴다
        #   (지금 15/35권에만 플랜이 있다. 「장기적으로는 모든 도서를 이렇게」).
        # ★ **본문은 안 자른다** — 유닛은 **읽는 자리**일 뿐 표시 단위가 아니다.
        #   조각으로 잘라 보이면 ① 각주가 편 끝에 모여 있어 마지막 조각에만 붙고
        #   ② 밑줄 메모가 다른 조각에 있으면 사라져 보이고 ③ 복사·검색이 조각에
        #   갇힌다. 사용자 지시도 그렇다 — 「원래 책과 다르게 장을 나눌 필요는
        #   없다. 그러나 이전/다음으로 구분하기 위해서는 유닛을 나누어야 한다」.
        # ★★ **자리는 2단 — 1단(책) 바로 아래, 3단(편의 기능) 위**
        #   (2026-08-31 `0.txt` 2번 탑다운 배치: 책 → 편 사이 이동 → 편의 기능
        #   → 본문). `before=` 로 끼운다 — 만드는 차례는 `_BTN` 때문에 뒤다.
        # (띠는 위에서 머리 줄 바로 아래에 만들었다 — 79-1)
        # ★★★ **이 라벨이 목차 문이다** (2026-08-31 사용자 확정 「전부 팝업
        #   펼치는 것으로 하자」). 왼쪽 트리에서 편 줄을 걷었으므로 「어느 편으로
        #   갈까」를 여기서 고른다.
        #   ★ **공간이 0 늘어난다** — 라벨이 이미 있고, 그 라벨이 곧 「몇 번째
        #     편인가」다. 그것을 누르면 「어느 편으로」가 나오는 것이 자연스럽다.
        #   ★ 팝업이라 **넓게** 쓴다 — 3,519편을 검색·읽음 표식과 함께 담는다.
        #     트리 251px 안에서는 못 하던 일이다.
        self._band_lbl = tk.Label(self._band, text='', bg='#FDFEFE',
                                  font=('', 9), fg='#1A5276', anchor='w',
                                  cursor='hand2')
        # ★ **[읽기 시작] 은 진도 라벨 왼쪽** (2026-08-31 사용자 지시) —
        #   「이 책을 연다」와 「몇 번째인가」가 나란히 서서 한 동작으로 읽힌다.
        # ⚠ **폭을 못 박는다**(2026-08-31) — 「읽기 시작」과 「읽는 중」은 글자
        #   수가 달라, 자리를 지켜도 **오른쪽 것들이 13px 씩 밀렸다**(실측
        #   x 88 → 75). 사용자가 말한 「위치가 바뀌어 혼란」이 그대로 남는다.
        #   폭은 11언어 최장(`Commencer la lecture` 119px)에 여백을 더해 정했다.
        #   ⚠ `tk.Button(width=N)` 은 **픽셀이 아니라 글자 수**다 — 프레임으로 못 박는다.
        _obf = tk.Frame(self._band, bg='#FDFEFE', width=self._OPEN_BTN_W)
        _obf.pack(side='left', padx=(0, 4))
        self._book_open_box = _obf
        self._book_open_btn = tk.Button(
            _obf, text='', command=self._on_book_open_btn, **_BTN)
        # ⚠⚠ **폭만 못 박고 높이는 단추가 정한다** (2026-08-31 사용자 「읽기시작
        #   버튼이 **일그러졌다**」). `pack_propagate(False)` 만 걸고 `fill='both'`
        #   로 채웠더니 단추가 띠 높이까지 늘어나 모양이 망가졌다.
        #   ⇒ 단추를 먼저 재고(`winfo_reqheight`) 그 높이로 프레임을 못 박는다.
        self.after_idle(self._fit_open_btn_box)
        self._band_lbl.pack(side='left', padx=(0, 0))
        self._band_lbl.bind('<Button-1>', lambda _e: self._open_toc())
        # [◀ 이전] 앞 여백(사용자 지시) — 진도와 이동이 붙어 있으면 잘못 누른다
        tk.Frame(self._band, bg='#FDFEFE', width=20).pack(side='left')
        self._prev_btn = tk.Button(
            self._band, text=i18n.t('PR_UNIT_PREV', '◀ 이전'),
            fg='#1A5276', command=lambda: self._nav_unit(-1), **_BTN)
        self._prev_btn.pack(side='left')
        # ★★ **[이어서 읽기]를 걷었다** (2026-08-31 `0.txt` 1번 사용자 「트리
        #   왼쪽의 표시, 직전값 저장기능으로 충분하다」). 맞다 — 탭에 들어오면
        #   `_restore_last_reading` 이 읽던 편을 이미 골라 준다. 단추는 「이미
        #   와 있는 자리로 가는」 단추라 대개 잠겨 있었다.
        #   ⚠ 담아 두는 일(`_save_pos`)과 `_resume_unit` 은 **남긴다** — 직전값
        #     저장이 그 표(`user_book_pos`)를 쓴다. 입구만 없앤 것이다.
        self._resume_btn = tk.Button(
            self._band, text=i18n.t('PR_UNIT_RESUME', '이어서 읽기'),
            fg='#1E8449', command=self._resume_unit, **_BTN)
        self._next_btn = tk.Button(
            self._band, text=i18n.t('PR_UNIT_NEXT', '다음 ▶'),
            fg='#1A5276', command=lambda: self._nav_unit(+1), **_BTN)
        self._next_btn.pack(side='left', padx=(4, 0))
        # ★ **[완료] = 옛 [○ 읽는중 ↔ ● 읽음]** (사용자 「하나로 합친다」).
        #   ⚠ 사용자가 적은 「✓ 완료」에서 **`✓` 를 뺐다** — 맑은 고딕·굴림·바탕
        #     **셋 다 없는 글자**다(cmap 실측). 글자만으로 뜻이 온전하다.
        #   ★★ **이름이 두 번 바뀌었다** — 「완료」→「유닛읽기 완료」(0.txt 2번
        #     「전체완료와 혼동 우려」)→**「읽기완료 표시하기」**(0.txt 1번
        #     「마치 완료했다는 오해소지가 크다. **상태표시냐 조치기능이냐**의
        #     문제」). 이름이 **하는 일**(표시한다)을 말한다.
        #   ⚠ 「읽는중」으로 되돌리지 말 것 — 그것은 **상태 서술**이라 눌러야 할
        #     것으로 안 보인다(2026-08-19 에 그 이유로 걷어낸 이름이다).
        self._read_btn = tk.Button(
            self._band, text=i18n.t('PR_UNIT_DONE', '읽기완료 표시하기'),
            fg='#7F8C8D', command=self._toggle_read, **_BTN)
        # ★ **[다음 ▶] 오른쪽에 공백을 두고** (2026-08-31 사용자 지시) —
        #   맨 오른쪽에 밀어 두면 이전/다음과 멀어 한 동작으로 안 읽힌다.
        self._read_btn.pack(side='left', padx=(0, 8), after=_obf)

        tk.Frame(f, bg='#D5DBDB', height=1).pack(fill='x', padx=8)

        # 본문 Text
        body_f = tk.Frame(f, bg='#FDFEFE')
        body_f.pack(fill='both', expand=True, padx=8, pady=(4, 20))

        vsb = ttk.Scrollbar(body_f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._body_vsb = vsb
        self._body_txt = tk.Text(
            body_f, wrap='word', font=('', 10),
            bg='#FDFEFE', fg='#2C3E50', relief='flat',
            state='disabled', yscrollcommand=self._on_body_scroll)
        # 폰트는 `theme_font` 「book」 구역을 따른다 (2026-08-13 · font.md 4단계).
        # ⚠ **채울 때마다 다시 불러야 한다** — 내용을 넣으면서 폰트를 덮어쓰는
        #   경로가 있으면 생성 시 한 번 적용한 것이 첫 렌더에 사라진다.
        try:
            import theme_font
            theme_font.register(self._body_txt, self.db_path, 'book')
        except Exception:
            pass
        # ★ **형광펜 + 그 자리 메모** (2026-08-15 사용자 지시).
        #   문장을 드래그하면 노랑이 남고, 메모를 쓰면 바로 뒤에 상자로 붙는다.
        #   ⚠ 닻은 **고른 글 자체**다 — 문단 번호가 아니다. 재수집으로 본문이 밀려도
        #     살아남는다(머레이 24편 재수집에서 문단이 나뉘고 합쳐졌다).
        try:
            import highlight_notes
            self._hl = highlight_notes.HighlightNotes(
                self._body_txt, self.db_path,
                kind_getter=self._hl_kind,
                unit_getter=self._hl_unit,
                lang_getter=lambda: (self.lang_getter() or 'KO'))
        except Exception as e:
            print('[highlight] %s' % e)
            self._hl = None

        vsb.config(command=self._body_txt.yview)
        self._body_txt.pack(fill='both', expand=True)

        # (옛 「이 유닛에 쓴 연구자료」 하단 띠는 2026-08-18 제목 아래 링크
        #  줄(`_res_f`, 위에서 생성)로 이사 — 같은 데이터를 두 곳에 두지 않는다.)

        # 플레이스홀더 (선택 전)
        self._placeholder = tk.Label(
            f, text=i18n.t('PR_SELECTLEFT','왼쪽에서 도서 또는 설교를 선택하세요.'),
            bg='#FDFEFE', fg='gray', font=('', 10))
        self._placeholder.place(relx=0.5, rely=0.5, anchor='center')

    # ── 데이터 로딩 ────────────────────────────────────────────────────────────

    def _initial_load(self):
        self._load_book_tree()
        self._load_sermon_tree()
        self._load_doctrine_tree()
        if getattr(self, '_enr_bar', None) is not None:
            try:
                self._enr_bar.refresh()
            except Exception as e:
                print('[reading enr] %s' % e)
        # [Phase 2-C'] ★ 즐겨찾기 서브탭 제거 — _load_favorites_tree 호출 안 함
        self._restore_last_reading()
        self._refresh_order_combo()      # 읽을 차례 — 처음 한 번
        for tab_type in ('BOOK', 'SERMON', 'DOCTRINE'):
            self._render_recent(tab_type)

    _ref_cache: dict = {}

    def _localize_ref(self, conn, text, lang):
        """`Genesis 1:5` → `창1:5`. 못 알아보면 그대로 돌려준다.

        ⚠ `key_verse_ref` 는 책마다 표기가 갈려 있다(`Joshua 5:12` ·
          `1 Corinthians 11:24` · `시 1편`). **영어 정식 이름 꼴만** 옮기고
          나머지는 손대지 않는다.
        """
        t = (text or '').strip()
        # 절까지 있는 꼴 · **장만 있는 꼴**(절을 못 찾은 편) · `3:1,2` 꼴
        m = re.match(r'^([1-3]?\s?[A-Za-z][A-Za-z ]*?)\s+(\d+)'
                     r'(?::(\d+)((?:\s*[,\-–]\s*\d+)*))?$', t)
        if not m:
            return t
        tail = re.sub(r'\s+', '', m.group(4) or '')
        key = ('L', m.group(1).lower(), m.group(2),
               (m.group(3) or '') + tail, lang)
        if key in self._ref_cache:
            return self._ref_cache[key]
        out = t
        # ⚠ 옛 자료가 DB 와 다른 이름을 쓴다 — `Song of Solomon`(DB 는
        #   `Song of Songs`) · `Psalm`(DB 는 `Psalms`). 별칭으로 받는다.
        nmk = _BOOK_ALIAS.get(m.group(1).lower(), m.group(1).lower())
        try:
            r = conn.execute(
                "SELECT COALESCE(bn.short_name, '') FROM book_names en"
                "  LEFT JOIN book_names bn ON bn.book_code = en.book_code"
                "       AND UPPER(bn.lang_code) = ?"
                " WHERE UPPER(en.lang_code)='EN'"
                "   AND (LOWER(en.full_name) = ? OR LOWER(en.short_name) = ?)",
                (lang, nmk, nmk)).fetchone()
            if r and r[0]:
                nm = r[0]
                if m.group(3):
                    out = verse_ref.label(verse_ref.SCOPE_BOOK, nm,
                                          m.group(2), m.group(3)) + tail
                else:
                    sep = ' ' if (nm and nm[-1].isascii()) else ''
                    out = '%s%s%s%s' % (nm, sep, m.group(2),
                                        _CHAP_SUFFIX.get(lang, ''))
        except Exception:
            pass
        self._ref_cache[key] = out
        return out

    def _unit_ref_label(self, conn, start_vid, end_vid, lang):
        """유닛의 기준 구절을 **그릴 때마다 다시 지어** 준다 — `창1:5` · `창1장`.

        ★ 저장된 글자(`key_verse_ref`)를 그대로 쓰지 않는다(§54 핀 칩과 같은
          원칙) — 그 칸은 책마다 표기가 갈려 있고(`Joshua 5:12` · `시 1편`)
          화면 언어를 안 따라온다.
        ⚠ 범위가 **그 장 전체**면 절을 적지 않고 `창1장` 으로 — 마이어처럼
          장 단위로 걸어 둔 책에서 `창1:1` 이라 적으면 1절만 다루는 것처럼
          읽힌다(2026-08-22 사용자 지적 「책/장 표시가 전혀 없다」).
        """
        if not start_vid:
            return ''
        key = (start_vid, end_vid, lang)
        if key in self._ref_cache:
            return self._ref_cache[key]
        out = ''
        try:
            r = conn.execute(
                "SELECT bi.bcode, bi.chapter, bi.verse,"
                "       COALESCE(bn.short_name, bn2.short_name, '')"
                "  FROM bible_index bi"
                "  LEFT JOIN book_names bn ON bn.book_code = bi.bcode"
                "       AND UPPER(bn.lang_code) = ?"
                "  LEFT JOIN book_names bn2 ON bn2.book_code = bi.bcode"
                "       AND UPPER(bn2.lang_code) = 'EN'"
                " WHERE bi.verse_id = ?", (lang, start_vid)).fetchone()
            if r:
                bc, ch, vs, nm = r
                whole = conn.execute(
                    "SELECT MIN(verse_id), MAX(verse_id) FROM bible_index"
                    " WHERE bcode=? AND chapter=?", (bc, ch)).fetchone()
                if whole and end_vid and whole[0] == start_vid \
                        and whole[1] == end_vid:
                    sep = ' ' if (nm and nm[-1].isascii()) else ''
                    out = '%s%s%s%s' % (nm, sep, ch, _CHAP_SUFFIX.get(lang, ''))
                else:
                    out = verse_ref.label(verse_ref.SCOPE_BOOK, nm, ch, vs)
        except Exception:
            out = ''
        self._ref_cache[key] = out
        return out

    def _reorder(self, tv, key):
        try:
            import tree_reorder
            tree_reorder.enable(tv, key, self.db_path)
            tree_reorder.apply(tv, key, self.db_path)
        except Exception as e:
            print('[reading reorder] %s' % e)

    def _load_book_tree(self):
        self._retag_trees()               # 채울 때마다 태그 색 = 그 시점 테마
        self._book_tv.delete(*self._book_tv.get_children())
        self._book_units = []
        lang = self.lang_getter().upper()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT ba.book_id, ba.book_category,
                           COALESCE(bat.title, ba.title) AS btitle,
                           COALESCE(bat.author, ba.author) AS bauthor,
                           ba.pub_year,
                           bu.unit_id, bu.sequence, bu.unit_label,
                           bu.key_verse_ref, bu.start_vid,
                           COALESCE(ta.contents, bu.unit_label) AS display_label,
                           bu.end_vid,
                           bu.verse_source
                    FROM sys_book_asset ba
                    LEFT JOIN sys_book_asset_text bat
                         ON bat.book_id = ba.book_id
                        AND UPPER(bat.lang_code) = ?
                        AND bat.record_status = 'LIVE'
                    JOIN sys_book_unit bu
                         ON bu.book_id = ba.book_id AND bu.record_status = 'LIVE'
                    LEFT JOIN sys_text_asset ta
                         ON ta.text_type = 'BOOK_UNIT_LABEL'
                        AND ta.clicked_id = bu.unit_id
                        AND UPPER(ta.lang_code) = ?
                        AND ta.record_status = 'LIVE'
                    WHERE ba.book_category != 'SERMON' AND ba.record_status = 'LIVE'
                    -- ★ **받은 것만 트리에 보인다** (2026-08-24 사용자
                    --   「왼쪽 트리구조는 다운로드 받은 것들만 표시된다」).
                    --   트리 = 읽을 수 있는 것 · 서재 = 전체 명단(안 받은 것 포함).
                    --   ⚠ 오늘은 35/35 가 본문을 가져 결과가 같다 — 팩 배포가
                    --     생기는 날 이 한 줄이 저절로 맞는다.
                    --   ⚠ `EXISTS` 로 쓴다. JOIN 하면 편마다 행이 불어난다.
                      AND EXISTS (SELECT 1 FROM sys_book_unit_text x
                                   WHERE x.unit_id = bu.unit_id)
                    ORDER BY ba.book_category, ba.book_id, bu.sequence
                """, (lang, lang)).fetchall()
                import book_langs                 # ★ 2026-10-31 번역 없는 책은 그 언어에서 감춘다(docs/통계_설계.md §9)
                _vis = book_langs.visible(conn, lang)
                rows = [r for r in rows if r[0] in _vis]
                # 트리 = 장 단위(찾기용) · 부제 = 그 책이 인용한 정확한 절
                refs = {r[5]: self._unit_ref_label(conn, r[9], r[11], lang)
                        for r in rows}
                exact = {r[5]: self._localize_ref(conn, r[8], lang)
                         for r in rows}
        except Exception:
            rows, refs, exact = [], {}, {}

        # 읽음 기록은 **한 번에** — 행마다 물으면 그만큼 질의가 난다
        try:
            import db_read_state
            with appdb.connect(self.db_path) as _rc:
                read_ids = db_read_state.read_ids(_rc, kind='BOOK')
        except Exception:
            read_ids = set()
        self._book_row.setdefault('BOOK', {}).clear()

        cat_nodes: dict[str, str] = {}
        book_nodes: dict[int, str] = {}
        for (bid, bcat, btitle, bauthor, pub_year,
             uid, seq, label, vref, vid, display_label, evid,
             vsrc) in rows:
            if bcat not in cat_nodes:
                cat_label = i18n.t('RVCAT_' + str(bcat), _CATEGORY_LABELS.get(bcat, bcat))
                cat_iid = f'CAT_{bcat}'
                self._book_tv.insert('', 'end', iid=cat_iid,
                                     text=f'▶ {cat_label}',
                                     tags=('cat',), open=True)
                cat_nodes[bcat] = cat_iid
            if bid not in book_nodes:
                book_iid = f'BK_{bid}'
                self._book_tv.insert(cat_nodes[bcat], 'end', iid=book_iid,
                                     text=f'  {btitle}  ({bauthor})',
                                     tags=('book',), open=False)
                book_nodes[bid] = book_iid
                self._book_row['BOOK'][bid] = book_iid
            # ★★★ **트리는 「분류 → 책」 두 층까지만** (2026-08-31 사용자
            #   「왼쪽 트리에서는 카테고리 / 책을 선택하고 **장/유닛 등은 다른
            #   화면에서** 선택할 수 있도록」 · 「스펄전 345장 읽다가 마이어
            #   찾으려면 복잡하다」).
            #   실측이 그 불편의 크기를 말한다 — 셋째 층이 **7,228줄**이고
            #   그중 **두 권이 4,892줄**(스펄전 3,519 · 마이어 1,373)이다.
            #   책 두 권 때문에 구조가 무너져 있었다. 이제 **39줄**(분류 6 +
            #   책 33)이라 스펄전에서 마이어까지 두 줄이다.
            # ⚠ **자료(`_book_units`)는 그대로 만든다** — 목차 팝업·진행 띠·
            #   서재·읽을 차례가 전부 이 목록을 읽는다. 화면에서 떼는 것과
            #   지우는 것은 다르다(§0-1).
            rf = refs.get(uid) or ''
            self._book_units.append(dict(
                unit_id=uid, book_id=bid, book_title=btitle,
                author=bauthor, pub_year=pub_year or '',
                sequence=seq, label=display_label or label or '',
                verse_ref=exact.get(uid) or rf or vref or '', start_vid=vid,
                verse_source=vsrc, source='BOOK'))

        self._count_lbl.config(text=f'총 {len(self._book_units)}편')
        self._refresh_book_counts('BOOK')
        # ★ 2026-10-15 — 줄을 끌어 차례를 바꾼다(같은 분류 안에서 · tree_reorder)
        self._reorder(self._book_tv, 'TREE_ORDER_BOOK')

    def _load_sermon_tree(self):
        self._retag_trees()               # 채울 때마다 태그 색 = 그 시점 테마
        self._sermon_tv.delete(*self._sermon_tv.get_children())
        self._sermon_units = []
        lang = self.lang_getter().upper()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT ba.book_id,
                           COALESCE(bat.author, ba.author) AS bauthor,
                           COALESCE(bat.title, ba.title) AS btitle,
                           ba.pub_year,
                           bu.unit_id, bu.sequence, bu.unit_label,
                           bu.key_verse_ref, bu.start_vid,
                           COALESCE(ta.contents, bu.unit_label) AS display_label,
                           bu.verse_source
                    FROM sys_book_asset ba
                    LEFT JOIN sys_book_asset_text bat
                         ON bat.book_id = ba.book_id
                        AND UPPER(bat.lang_code) = ?
                        AND bat.record_status = 'LIVE'
                    JOIN sys_book_unit bu
                         ON bu.book_id = ba.book_id AND bu.record_status = 'LIVE'
                    LEFT JOIN sys_text_asset ta
                         ON ta.text_type = 'BOOK_UNIT_LABEL'
                        AND ta.clicked_id = bu.unit_id
                        AND UPPER(ta.lang_code) = ?
                        AND ta.record_status = 'LIVE'
                    WHERE ba.book_category = 'SERMON' AND ba.record_status = 'LIVE'
                    -- ★ **받은 것만 트리에 보인다** (2026-08-24 사용자
                    --   「왼쪽 트리구조는 다운로드 받은 것들만 표시된다」).
                    --   트리 = 읽을 수 있는 것 · 서재 = 전체 명단(안 받은 것 포함).
                    --   ⚠ 오늘은 35/35 가 본문을 가져 결과가 같다 — 팩 배포가
                    --     생기는 날 이 한 줄이 저절로 맞는다.
                    --   ⚠ `EXISTS` 로 쓴다. JOIN 하면 편마다 행이 불어난다.
                      AND EXISTS (SELECT 1 FROM sys_book_unit_text x
                                   WHERE x.unit_id = bu.unit_id)
                    ORDER BY ba.author, ba.book_id, bu.sequence
                """, (lang, lang)).fetchall()
                import book_langs                 # ★ 2026-10-31 번역 없는 책은 그 언어에서 감춘다
                _vis = book_langs.visible(conn, lang)
                rows = [r for r in rows if r[0] in _vis]
        except Exception:
            rows = []

        self._book_row.setdefault('SERMON', {}).clear()   # key → 자료집 줄 iid
        # 읽음 기록은 **한 번에** 가져온다 — 3,519행에서 행마다 물으면 그만큼 질의가 난다
        try:
            import db_read_state
            with appdb.connect(self.db_path) as _rc:
                read_ids = db_read_state.read_ids(_rc)
        except Exception:
            read_ids = set()

        author_nodes: dict[str, str] = {}
        book_nodes: dict[int, str] = {}
        for (bid, bauthor, btitle, pub_year,
             uid, seq, label, vref, vid, display_label, vsrc) in rows:
            a_slug = re.sub(r'[^a-zA-Z0-9]', '_', bauthor)
            a_iid = f'AUTH_{a_slug}'
            if a_iid not in author_nodes:
                self._sermon_tv.insert('', 'end', iid=a_iid,
                                       text=f'✦ {bauthor}',
                                       tags=('author',), open=True)
                author_nodes[a_iid] = a_iid
            if bid not in book_nodes:
                book_iid = f'SBK_{bid}'
                # 설교집 줄에 **읽은수/전체** — 접어 두어도 진행이 보이고,
                # 숫자가 스스로 「부분」임을 말해 「묶음을 읽었다」는 오해가 사라진다.
                self._sermon_tv.insert(a_iid, 'end', iid=book_iid,
                                       text=btitle,
                                       tags=('book',), open=True)
                self._book_row['SERMON'][bid] = book_iid
                book_nodes[bid] = book_iid
            tags = ('unit',)
            display = display_label or label or f'설교 {seq}'
            # 읽음×즐겨찾기 매트릭스 표식 — `_unit_mark` 참조.
            # ⚠ 컬러 이모지를 쓰지 않는다 — 첫 렌더에서 Segoe UI Emoji 를 콜드로드해
            #   0.6초가 날아간다(§29).
            # ★★★ 도서 트리와 같은 이유로 **편 줄을 안 만든다**(2026-08-31) —
            #   설교집 5권에 3,573편이고 스펄전 한 권이 3,519편이다.
            #   편은 **목차 팝업**(진행 띠의 「n / 전체」 라벨)이 맡는다.
            self._sermon_units.append(dict(
                unit_id=uid, book_id=bid, book_title=btitle,
                author=bauthor, pub_year=pub_year or '',
                sequence=seq, label=display,
                verse_ref=vref or '', start_vid=vid,
                verse_source=vsrc, source='SERMON'))
        self._count_lbl.config(text=f'총 {len(self._sermon_units)}편')
        # 설교집 줄의 `읽은수/전체` — 트리를 다 채운 **뒤**라야 셀 수 있다
        self._refresh_book_counts()
        # ★ 2026-10-15 — 줄을 끌어 차례를 바꾼다(같은 분류 안에서 · tree_reorder)
        self._reorder(self._sermon_tv, 'TREE_ORDER_SERMON')


    # Source codes shown directly (no sub-grouping — ≤200 entries each)
    _DOCTRINE_DIRECT = ('HEIDELBERG', 'WESTMINSTER_SC', 'LUTHER_SC', 'TORREY_WBT')
    # Source codes with A-Z sub-grouping (large dictionaries)
    # ★ **사전을 여기서 뺐다 (2026-08-15 사용자 지시).**
    #   교리문답과 사전은 논리적 관계가 없다 — 문답은 129개를 차례로 **읽는** 것이고
    #   사전은 표제어를 **찾는** 것이다. 읽음 표시·걸러보기·이어서 읽기가 사전에는
    #   전부 무의미하다. 사전만 A~Z 하위 그룹을 따로 만들어야 했던 것 자체가 신호였다.
    #   ⚠ 받는 곳은 이미 있다 — **P4 주요용어 ▸ 사전**이 Easton·Smith·Meyer 를
    #     표제어 단위로 읽는다(`entity_browser._DICT_SRC`). 손실 없음.
    _DOCTRINE_ALPHA  = ()

    def _load_doctrine_tree(self):
        self._retag_trees()               # 채울 때마다 태그 색 = 그 시점 테마
        self._doctrine_tv.delete(*self._doctrine_tv.get_children())
        self._doctrine_units = []
        # ⚠ `kind='REF'` — 교리자료 유닛은 `sys_ref_unit` 이라 도서 유닛과 번호가
        #   549개 겹친다. 갈래를 빼먹으면 서로를 읽음으로 물들인다.
        try:
            import db_read_state
            with appdb.connect(self.db_path) as _rc:
                self._doc_read = db_read_state.read_ids(_rc, kind='REF')
        except Exception:
            self._doc_read = set()
        self._book_row.setdefault('DOCTRINE', {}).clear()

        # ── Part 1: catechism + topical (직접 나열) ─────────────────────────
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT s.ref_src_id, s.src_code, s.src_type,
                           u.ref_unit_id, u.unit_label, u.unit_type,
                           u.unit_question, u.unit_answer, u.sequence,
                           u.section_code
                    FROM sys_ref_source s
                    JOIN sys_ref_unit u ON u.ref_src_id = s.ref_src_id
                    WHERE s.record_status='LIVE' AND u.record_status='LIVE'
                      AND s.src_code IN ('HEIDELBERG','WESTMINSTER_SC',
                                         'LUTHER_SC','TORREY_WBT')
                    ORDER BY s.ref_src_id, u.sequence
                """).fetchall()
        except Exception:
            rows = []

        src_nodes: dict = {}
        section_nodes: dict = {}   # (src_id, section_code) → iid
        for (src_id, src_code, src_type,
             uid, label, unit_type,
             question, answer, seq, section_code) in rows:
            if src_id not in src_nodes:
                src_label = i18n.t('REFSRC_'+str(src_code), _REF_SOURCE_LABELS.get(src_code, src_code))
                self._book_row['DOCTRINE'][src_code] = f'DSRC_{src_id}'
                self._doctrine_tv.insert('', 'end', iid=f'DSRC_{src_id}',
                                         text=src_label,
                                         tags=('src',), open=False)
                src_nodes[src_id] = src_id

            parent_iid = f'DSRC_{src_id}'
            if section_code:
                sec_key = (src_id, section_code)
                if sec_key not in section_nodes:
                    # ★ 79-5 — 구역은 나무에 안 그린다(목차 줄 앞에 이름으로 붙는다)
                    section_nodes[sec_key] = i18n.t('REFSECT_'+str(section_code), _SECTION_LABELS.get(section_code, section_code))
                parent_iid = section_nodes[(src_id, section_code)]

            seq_txt = f'{seq}. ' if seq else ''
            if unit_type == 'QA':
                if label and not re.match(r'^Q\.\d+$', label.strip()):
                    disp = label   # Luther "First Commandment" / Heidelberg "Q.1 — Lord's Day 1"
                elif question:
                    q_short = question[:50].rstrip()
                    if len(question) > 50:
                        q_short += '…'
                    disp = q_short  # WSC: 질문 텍스트가 더 유용
                else:
                    disp = label or f'항목 {uid}'
            else:
                disp = label or question or f'항목 {uid}'
            # 표식 매트릭스 통일 (2026-08-19 0.txt ⑤) — 교리자료도 ★●♥○
            # ★ 79-5 — 글 줄은 나무에 안 그린다(목차 팝업 · 띠의 ◀ ▶ 가 맡는다)
            _sec = section_nodes.get((src_id, section_code)) if section_code else ''
            self._doctrine_units.append(dict(
                src_id=src_id, disp=('%s · %s' % (_sec, disp)) if _sec else disp,
                unit_id=uid, src_code=src_code, src_type=src_type,
                label=label or '', unit_type=unit_type or 'QA',
                question=question or '', answer=answer or '',
                sequence=seq))

        # ★ **사전(Part 2)을 통째로 걷어냈다 (2026-08-15 사용자 지시).**
        #   교리문답과 사전은 논리적 관계가 없다 — 문답은 129개를 차례로 **읽는**
        #   것이고 사전은 표제어를 **찾는** 것이다. 읽음 표시·걸러보기·이어서 읽기가
        #   사전에는 전부 무의미하다. 사전만 A~Z 하위 그룹을 따로 만들어야 했던 것
        #   자체가 「같은 성격이 아니다」라는 신호였다.
        #   ⚠ 받는 곳은 이미 있다 — **P4 주요용어 ▸ 사전**이 Easton·Smith·Meyer 를
        #     표제어 단위로 읽는다(`entity_browser._DICT_SRC`). 옮길 것도 없다.

        self._count_lbl.config(text=f'총 {len(self._doctrine_units)}건')
        self._refresh_book_counts('DOCTRINE')

        # ★ 2026-10-15 — 줄을 끌어 차례를 바꾼다(같은 분류 안에서 · tree_reorder)
        self._reorder(self._doctrine_tv, 'TREE_ORDER_DOCTRINE')
    def _load_favorites_tree(self):
        # [Phase 2-C'] ★ 즐겨찾기 서브탭 제거 — 위젯이 없으면 무동작
        if not hasattr(self, '_fav_tv'):
            return
        self._fav_tv.delete(*self._fav_tv.get_children())
        unit_map = {u['unit_id']: u for u in self._book_units + self._sermon_units}
        # ★★ **담아 둔 책이 먼저** (2026-08-31) — 1단 ♥ 으로 담은 것이
        #   여기 안 나오면 「담았는데 어디에도 없다」가 된다(§0-1 조용한 실패).
        _bids = [f['unit_id'] for f in reversed(self._favorites)
                 if f.get('type') == self._BOOK_FAV]
        if _bids:
            _lang = self.lang_getter().upper()
            try:
                with appdb.connect(self.db_path) as conn:
                    q = ','.join('?' * len(_bids))
                    _tt = dict(conn.execute(
                        "SELECT ba.book_id, COALESCE(bat.title, ba.title) "
                        "FROM sys_book_asset ba "
                        "LEFT JOIN sys_book_asset_text bat "
                        "  ON bat.book_id = ba.book_id "
                        " AND UPPER(bat.lang_code)=? AND bat.record_status='LIVE' "
                        "WHERE ba.book_id IN (%s)" % q,
                        [_lang] + _bids).fetchall())
            except Exception:
                _tt = {}
            for _b in _bids:
                self._fav_tv.insert(
                    '', 'end', iid='FAVB_%d' % _b, tags=('book_item',),
                    text='♥ %s' % (_tt.get(_b) or '#%d' % _b))
        for fav in reversed(self._favorites):
            if fav.get('type') == self._BOOK_FAV:
                continue
            uid = fav['unit_id']
            u = unit_map.get(uid)
            if not u:
                continue
            prefix = '[설교]' if u['source'] == 'SERMON' else '[도서]'
            tag = 'sermon_item' if u['source'] == 'SERMON' else 'book_item'
            self._fav_tv.insert('', 'end', iid=f'FAV_{uid}',
                                text=f'{prefix} {u["label"]}', tags=(tag,))

    def _load_texts(self, unit_id: int):
        self._texts = {}
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT text_variant, lang_code, body_text
                    FROM sys_book_unit_text
                    WHERE unit_id = ? AND record_status = 'LIVE'
                """, (unit_id,)).fetchall()
                for variant, lang, text in rows:
                    self._texts[(variant, lang.upper())] = text
        except Exception:
            pass

    def _restore_last_reading(self):
        lr = self._last_reading
        if not lr or 'unit_id' not in lr:
            return
        # 설교는 직전값 복원 안 함 — 탭 열면 트리 상단부터 표시
        if lr.get('type') == 'SERMON':
            return
        uid = lr['unit_id']
        iid = f'U_{uid}'
        if self._book_tv.exists(iid):
            self.after(50, lambda: self._reveal_and_select(
                self._book_tv, iid))

    def _reveal_and_select(self, tv: ttk.Treeview, iid: str):
        node = tv.parent(iid)
        while node:
            tv.item(node, open=True)
            node = tv.parent(node)
        tv.see(iid)
        tv.selection_set(iid)
        tv.focus(iid)

    # ── 선택 처리 ──────────────────────────────────────────────────────────────

    def _on_book_select(self, _=None):
        # ⚠ `jump_to_unit` 이 책 줄을 드러내며 고르는 동안에는 **안 받는다** —
        #   받으면 방금 연 편을 덮고 소개문이 뜬다(Tk 는 선택 이벤트를 큐에
        #   넣으므로 순서로는 못 막는다).
        if getattr(self, '_syncing', False):
            return
        sel = self._book_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if iid == getattr(self, '_skip_sel', None):       # ★ 317차 — 드러내기가 낸 그 이벤트 하나
            self._skip_sel = None
            return
        if iid.startswith('BK_'):
            try:
                self._show_book_info(int(iid[3:]))
            except ValueError:
                pass
            return
        if not iid.startswith('U_'):
            return
        try:
            uid = int(iid[2:])
        except ValueError:
            return
        u = next((x for x in self._book_units if x['unit_id'] == uid), None)
        if u:
            self._show_unit(u)

    def _refresh_book_counts(self, tab_type=None):
        """자료집 줄의 `읽은수/전체` 를 다시 단다 — 세 갈래 공용."""
        rows = getattr(self, '_book_row', None) or {}
        for t in ([tab_type] if tab_type else list(self._TAB_SPEC)):
            sp = self._spec(t)
            tv = getattr(self, sp['tv'], None) if sp else None
            if tv is None or t not in rows:
                continue
            try:
                import db_read_state
                with appdb.connect(self.db_path) as conn:
                    done = db_read_state.read_ids(conn, kind=sp['kind'])
            except Exception:
                done = set()
            tot, red = {}, {}
            for u in getattr(self, sp['units'], []):
                k = u.get(sp['key'])
                tot[k] = tot.get(k, 0) + 1
                if u.get('unit_id') in done:
                    red[k] = red.get(k, 0) + 1
            for key, iid in rows[t].items():
                if not tv.exists(iid):
                    continue
                base = tv.item(iid, 'text').split('   ')[0].lstrip('♥ ')
                # ★★ **담아 둔 책에 ♥** (2026-08-31) — 1단에서 담은 것이
                #   목록에서 보여야 「담았는데 어디에도 없다」가 안 난다.
                #   ⚠ 교리자료 줄의 열쇠는 자료집 코드라 책 번호가 아니다.
                head = '♥ ' if (isinstance(key, int)
                                and self._is_book_favorite(key)) else ''
                tv.item(iid, text='%s%s   %d/%d' % (
                    head, base, red.get(key, 0), tot.get(key, 0)))

    def _on_sermon_select(self, _=None):
        # ⚠ `jump_to_unit` 이 책 줄을 드러내며 고르는 동안에는 **안 받는다** —
        #   받으면 방금 연 편을 덮고 소개문이 뜬다(Tk 는 선택 이벤트를 큐에
        #   넣으므로 순서로는 못 막는다).
        if getattr(self, '_syncing', False):
            return
        sel = self._sermon_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if iid == getattr(self, '_skip_sel', None):       # ★ 317차 — 드러내기가 낸 그 이벤트 하나
            self._skip_sel = None
            return
        if iid.startswith('SBK_'):
            try:
                self._show_book_info(int(iid[4:]))
            except ValueError:
                pass
            return
        if not iid.startswith('SU_'):
            return
        try:
            uid = int(iid[3:])
        except ValueError:
            return
        u = next((x for x in self._sermon_units if x['unit_id'] == uid), None)
        if u:
            self._show_unit(u)

    def _on_doctrine_select(self, _=None):
        sel = self._doctrine_tv.selection()
        if not sel:
            return
        iid = sel[0]
        # ★ 79-5 — 나무에는 자료집만 있다. 누르면 그 자료집에서 마지막으로 본 글(없으면 첫 글)
        if not iid.startswith('DSRC_'):
            return
        src = self._src_code_of(iid[5:])
        cur = getattr(self, '_current_doctrine_unit', None)
        if cur and cur.get('src_code') == src:
            return
        rows = [x for x in self._doctrine_units if x.get('src_code') == src]
        if not rows:
            return
        want = self._doc_pos().get(str(src))
        u = next((x for x in rows if x['unit_id'] == want), rows[0])
        self._show_doctrine_unit(u)

    def _show_doctrine_unit(self, u: dict):
        self._current_unit = None
        # ⚠ 앞서 보던 책의 번호를 들고 있으면 1단 ♥ 이 **엉뚱한 책**을 담는다
        self._current_book_id = None
        self._current_doctrine_unit = u
        self._texts = {}
        self._close_note_editor()
        self._save_doc_pos(u)
        # 나무는 그 자료집 줄을 고른 채로(이미 그 줄이면 그대로 — 선택 이벤트가 또 돌지 않게)
        try:
            _iid = 'DSRC_%s' % u.get('src_id')
            if self._doctrine_tv.exists(_iid) and self._doctrine_tv.selection() != (_iid,):
                self._doctrine_tv.selection_set(_iid)
        except Exception:
            pass
        src_label = i18n.t('REFSRC_'+str(u['src_code']), _REF_SOURCE_LABELS.get(u['src_code'], u['src_code']))
        src_type_ko = i18n.t('REFSRCTYPE_'+str(u['src_type']), _REF_SRC_TYPE_KO.get(u['src_type'], u['src_type']))
        self._update_history('DOCTRINE', u['unit_id'],
                             u.get('label') or u.get('question') or '',
                             src_code=u.get('src_code', ''))
        self._meta_title.config(text=u['label'] or u['question'] or '')
        self._meta_sub.config(text=f'{src_label}  ·  {src_type_ko}')
        self._render_tags([], [])
        self._refresh_linked_research(u['unit_id'])
        self._sync_unit_bar()            # ★ 갈래를 안 가린다(위 주석)
        self._sync_book_open_btn()
        self._refresh_read_btn()          # 띠(3/129문 · ○ 읽음)도 함께
        self._placeholder.place_forget()

        # 본문 구성
        if u['unit_type'] == 'QA':
            q = u['question'] or ''
            a = re.sub(r'\s*\([a-z]{1,3}\)', '', u['answer'] or '').strip()
            body = ''
            if q:
                body += f'Q. {q}\n\n'
            if a:
                body += f'A. {a}'

            proof = self._load_proof_verses(u['unit_id'])
            if proof:
                body += f'\n\n{"─" * 32}\n증거구절 {len(proof)}개\n\n'
                for short_name, ch, vs, text in proof:
                    ref = f'{short_name} {ch}:{vs}'
                    # ⚠ 한 덩어리로 넣는 글이라 줄마다 정렬은 못 준다 — 차례만 맞춘다
                    body += f'{ref} — {bidi.for_display(text)}\n' if text else f'{ref}\n'

            body = body.strip() or '(내용 없음)'
        else:
            # SECTION — sys_ref_text에서 본문 로드 + 증거구절
            _v = self._g_variant_var.get()
            _l = (self._g_lang_var.get().upper()
                  if _v == 'TRANSLATED' else 'EN')
            body = self._load_ref_text(u['unit_id'], variant=_v, lang=_l)
            proof = self._load_proof_verses(u['unit_id'])
            if proof:
                body += f'\n\n{"─" * 32}\n증거구절 {len(proof)}개\n\n'
                for short_name, ch, vs, text in proof:
                    ref = f'{short_name} {ch}:{vs}'
                    # ⚠ 한 덩어리로 넣는 글이라 줄마다 정렬은 못 준다 — 차례만 맞춘다
                    body += f'{ref} — {bidi.for_display(text)}\n' if text else f'{ref}\n'

        # 폰트는 **지원/설정 ▸ 폰트**(`theme_font` 「book」 구역)가 정한다.
        # ⚠ 채울 때마다 다시 불러야 한다 — 여기서 옛 콤보값을 씌우고 있었다.
        try:
            import theme_font
            theme_font.apply(self._body_txt, self.db_path, 'book')
        except Exception:
            pass
        self._body_txt.config(state='normal')
        self._body_txt.delete('1.0', 'end')
        # ⚠ 심어 둔 폴백 단추도 함께 걷는다(글자만 지우면 위젯이 남는다)
        try:
            import pack_fallback as _FB2
            _FB2.clear_get_buttons(self._body_txt)
        except Exception:
            pass
        self._insert_body(body)
        self._body_txt.config(state='disabled')
        self._body_txt.yview_moveto(0)
        self._hl_reload()
        # ★ 이 길에는 머리·각주가 없다 — 곧바로 본문 약명을 건다.
        self._tag_body_refs()

    def _insert_body(self, body):
        """본문을 넣는다 — **운문은 한 단 안쪽으로** (2026-08-28 사용자 지시
        「시, 인용구절 인덴트를 넣어서 본문과 구별 가능하도록」).

        ⚠ **글자를 건드리지 않는다.** 공백을 넣어 들여쓰는 것이 아니라
          `lmargin1/lmargin2` 로 그린다. 그래야 ① 줄이 접혀도 둘째 줄부터
          들여쓰기가 살고 ② **밑줄·메모의 닻(고른 글 자체)이 어긋나지 않으며**
          ③ 검색·복사에 군더더기 공백이 안 섞인다.
        ⚠ 넣는 글자는 예전과 **한 글자도 다르지 않다** — `_hl_reload` 가 찾는
          인용문이 그대로 있어야 밑줄이 살아난다.
        ⚠ 갈래 판정은 `book_blocks` 한 곳이 한다(플랜 화면도 같은 문을 쓴다).
        """
        # ★★★ **맛보기가 끊긴 자리를 화면이 말한다**(2026-09-25 · 1.txt
        #   16-3 사용자 「맛보기 한계에 도착하면 다운로드 하라는 팝업
        #   메시지가 표시되고 다운로드 탭으로 안내」).
        #   ⚠ 표식은 **떼고** 본다 — 본문에 낯선 기호가 찍히면 안 된다.
        _tasted = False
        try:
            import pack_fallback as _PF
            body, _tasted = _PF.taste_split(body)
            self._taste_cut = _tasted
        except Exception:                                 # noqa: BLE001
            self._taste_cut = False
        try:
            import book_blocks
            parts = book_blocks.blocks(body or '')
        except Exception:
            self._body_txt.insert('1.0', body or '')
            return
        # 운문 여백 — 본문 글꼴 크기에 맞춰 한 단(약 두 글자 폭)
        # ⚠ `theme_font.resolve(db, 역할)` 이다 — `roles` 라는 함수는 없다
        #   (2026-08-28 실측으로 잡음). 실패해도 화면은 그려져야 하므로 폴백.
        try:
            import theme_font
            px = int(theme_font.resolve(self.db_path, 'prose')['size']) * 3
        except Exception:
            px = 30
        self._body_txt.tag_configure('poem', lmargin1=px, lmargin2=px)
        first = True
        for kind, chunk in parts:
            if first:
                first = False
            else:
                self._body_txt.insert('end', '\n')
            self._body_txt.insert('end', chunk,
                                  ('poem',) if kind == 'poem' else ())
        # ★★★ **끊긴 자리에 길을 낸다** — 안 내면 사용자는 글이 그렇게 끝난
        #   줄 안다(§0-1). 「받으러 가기」가 설정 ▸ 다운로드 탭을 연다.
        if _tasted:
            self._taste_tail()

    def _taste_tail(self):
        """맛보기가 끊긴 자리 — 안내 한 줄과 [받으러 가기].

        ⚠ **누를 수 있을 때만 단추를 낸다**(§0-1) — 다운로드 탭으로 가는
          길이 없으면 안내만 적는다.
        ⚠ 길은 이미 있다 — `user_main` 이 `on_download_jump` 를 심는다.
        """
        w = self._body_txt
        # ⚠ 글자는 **11언어**에서 온다 — `self.t` 는 이 화면에 없는 이름이라
        #   그대로 두면 어느 언어로 읽어도 한국어가 나왔다.
        try:
            import pack_fallback as _PF
            msg = _PF.taste_notice(i18n.t)
        except Exception:                                 # noqa: BLE001
            msg = i18n.t('PF_TASTE_END', '맛보기는 여기까지입니다.')
        try:
            import ui_theme as _UT
            fg, bg = _UT.C('fg_title'), _UT.C('panel_alt')
        except Exception:                                 # noqa: BLE001
            fg, bg = '#1A5276', '#EAF2F8'
        w.insert('end', '\n\n')
        w.tag_configure('taste', foreground=fg, background=bg,
                        lmargin1=8, lmargin2=8, spacing1=6, spacing3=6)
        w.insert('end', msg + '\n', ('taste',))
        go = getattr(self, 'on_download_jump', None)
        if not go:
            return
        import tkinter as _tk
        b = _tk.Button(w, text=i18n.t('PF_GO_DOWNLOAD', '받으러 가기'),
                       command=lambda: go(),
                       cursor='hand2', relief='raised', bd=1, padx=10)
        w.window_create('end', window=b)
        w.insert('end', '\n')

    def _load_ref_text(self, ref_unit_id: int,
                       variant: str = 'ORIGINAL', lang: str = 'EN') -> str:
        """글 본문을 한 행 가져온다.

        ⚠ 예전에는 `ORIGINAL` = 영어라고 못 박고 있었다. 이 표에 든 것이
          전부 수입한 영어 저작이었기 때문인데, **우리가 쓴 글은
          `ORIGINAL` + `KO`** 라서 그대로 두면 「(본문 없음)」이 떴다
          (2026-08-03, `STUDY_NOTES` 첫 글에서 실제로 발생).
          그래서 언어를 고정하지 않고 §0-3 폴백 순서로 고른다.
              요청한 변형+언어 → 요청 언어의 다른 변형 → EN → 있는 것 아무거나
          (같은 순위 안에서는 ORIGINAL 을 먼저)
        """
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT body_text FROM sys_ref_text "
                    "WHERE ref_unit_id=? AND record_status='LIVE' "
                    "  AND body_text IS NOT NULL AND body_text<>'' "
                    "ORDER BY CASE WHEN UPPER(text_variant)=? AND UPPER(lang_code)=? THEN 0 "
                    "              WHEN UPPER(lang_code)=? THEN 1 "
                    "              WHEN UPPER(lang_code)='EN' THEN 2 ELSE 3 END, "
                    "         CASE WHEN UPPER(text_variant)='ORIGINAL' THEN 0 ELSE 1 END "
                    "LIMIT 1",
                    (ref_unit_id, (variant or '').upper(),
                     (lang or '').upper(), (lang or '').upper())
                ).fetchone()
            return row[0] if row and row[0] else '(본문 없음)'
        except Exception:
            return '(본문 없음)'

    def _load_proof_verses(self, unit_id: int) -> list[tuple[str, int, int, str]]:
        """sys_ref_verse_link → (short_name, chapter, verse, verse_text) 목록."""
        ver     = self.version_getter()
        variant = self._g_variant_var.get()
        if variant == 'TRANSLATED':
            lang = self._g_lang_var.get().upper()
        else:
            lang = 'EN'
        bn_lang = lang if lang in ('KO', 'EN', 'JA', 'ZH') else 'EN'
        try:
            with appdb.connect(self.db_path) as conn:
                return conn.execute("""
                    SELECT bn.short_name, bi.chapter, bi.verse,
                           COALESCE(bc.verse_text, '') AS verse_text
                    -- ★ 2026-08-24 통합 표(`REFU_VERS`)
                    FROM sys_link_asset vl
                    JOIN bible_index bi ON bi.verse_id = vl.target_id
                    JOIN book_names  bn ON bn.book_code = bi.bcode
                                      AND bn.lang_code  = ?
                    LEFT JOIN bible_content bc ON bc.verse_id    = vl.target_id
                                              AND bc.version_code = ?
                    WHERE vl.link_type = 'REFU_VERS' AND vl.clicked_id = ?
                      AND COALESCE(vl.record_status,'LIVE') = 'LIVE'
                    ORDER BY vl.sort_order, vl.sys_link_id
                """, (bn_lang, ver, unit_id)).fetchall()
        except Exception:
            return []

    def _on_favorites_select(self, _=None):
        sel = self._fav_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if iid.startswith('FAVB_'):           # 담아 둔 책 → 소개문으로
            try:
                self._show_book_info(int(iid[5:]))
            except ValueError:
                pass
            return
        if not iid.startswith('FAV_'):
            return
        try:
            uid = int(iid[4:])
        except ValueError:
            return
        unit_map = {u['unit_id']: u for u in self._book_units + self._sermon_units}
        u = unit_map.get(uid)
        if u:
            self._show_unit(u)

    # ── 읽기 판정 — 기기 안에만 적는다(docs/통계_설계.md §3) ─────────────────
    def _rd_flush(self):
        st = getattr(self, '_rd', None)
        self._rd = None
        if not st:
            return
        try:
            import usage_stats
            usage_stats.read_event(st['code'], st['uid'], st['sec'], st['chars'], st['end'],
                                   (self.lang_getter() or ''))
        except Exception:
            pass

    def _rd_begin(self, u):
        self._rd_flush()
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute('SELECT book_code FROM sys_book_asset WHERE book_id=?', (u.get('book_id'),)).fetchone()
            self._rd = {'code': r[0] if r else '', 'uid': u.get('unit_id'), 'sec': 0, 'chars': 0, 'end': False}
        except Exception:
            self._rd = None
        if not getattr(self, '_rd_on', False):
            self._rd_on = True
            self.after(2000, self._rd_tick)

    def _rd_tick(self):
        """2초마다 — 화면에 보일 때만 시간을 세고 끝까지 내렸는지 본다"""
        try:
            if not self.winfo_exists():
                return
            st = getattr(self, '_rd', None)
            if st and self._body_txt.winfo_viewable():
                st['sec'] += 2
                st['chars'] = int(self._body_txt.count('1.0', 'end', 'chars')[0])
                st['end'] = st['end'] or self._body_txt.yview()[1] >= 0.98
            self.after(2000, self._rd_tick)
        except Exception:
            self._rd_on = False

    def _show_unit(self, u: dict):
        self._rd_begin(u)
        self._current_unit = u
        if getattr(self, '_note_shown_uid', None) != u.get('unit_id'):
            self._close_note_editor()
        self._note_shown_uid = u.get('unit_id')
        # ⚠ 교리 유닛 잔존을 지운다 (2026-08-19 잠복 버그) — 안 지우면 `_cur_tab` 이
        #   도서를 보면서도 DOCTRINE 을 돌려줘 읽음·찜 토글이 교리 유닛을 겨눈다.
        self._current_doctrine_unit = None
        self._load_texts(u['unit_id'])
        self._update_meta(u)
        self._update_variant_selector()
        self._refresh_body()
        self._refresh_fav_btn()
        self._refresh_read_btn()
        self._placeholder.place_forget()
        clabels, rtags = self._load_tags(unit_id=u['unit_id'])
        self._render_tags(clabels, rtags)
        state = {'type': u['source'], 'book_id': u['book_id'],
                 'unit_id': u['unit_id']}
        self._last_reading = state
        if self._on_reading_changed:
            self._on_reading_changed(state)
        tab_type = 'SERMON' if u['source'] == 'SERMON' else 'BOOK'
        self._update_history(tab_type, u['unit_id'], u.get('label', ''))
        self._refresh_linked_research(u['unit_id'])
        # ★★ **묵상경로 줄을 걷었다** (2026-08-31 `0.txt` 1번 사용자 「경로안내
        #   기능이 과연 필요한지 확신이 없다 … 제거」). 실측이 그것을 받쳤다 —
        #   `sys_plan_route` **49행 · 붙은 도서 6/38권**. 32권에서는 아무것도
        #   안 떴다. 이제 그 자리는 3단 [연결된 자산 보기]가 쓴다.
        #   ⚠ `plan_route` 모듈과 `_refresh_book_routes` 는 **남긴다** — 렌즈·
        #     플랜 화면이 같은 경로 표를 쓰고, 되살릴 때 그대로 쓴다.
        self._sync_unit_bar()

    # ── 도서묵상 머리 — 묵상 포커스·연결 구절 (2026-08-24) ─────────────────────
    #
    # ★★ **진행 띠가 대체한 것은 페이싱·완주·진도 셋뿐이었다**(§74차에 그렇게
    #   적어 두고 나머지를 옮기지 않았다). 그래서 도서 화면으로 읽으면
    #   **묵상 포커스 230편 · 연결 구절 2,814행 · 보조 구절 88행**을 통째로 잃었다.
    #   플랜 화면에만 남아 있던 것을 그 편을 읽는 자리로 가져온다.
    #
    # ⚠ 머리 줄에는 `◆`·`▸`·들여쓰기를 붙여 **본문 문단과 겹치지 않게** 한다 —
    #   각주 태그가 줄 번호로 걸리므로 머리는 반드시 그 **뒤에** 끼운다.
    #
    # ⚠ 한 편이 **여러 플랜**에 들 수 있다(마이어는 통독과 66권 플랜 양쪽).
    #   그대로 그리면 같은 포커스가 두 번 뜬다 — 글자로 중복을 접는다.

    _STAGE_LABEL = (('CORE',    'PR_STAGE_CORE',    '핵심 말씀'),
                    ('QUOTED',  'PR_STAGE_QUOTED',  '인용 구절'),
                    ('SUPPORT', 'PR_STAGE_SUPPORT', '보조 구절'))
    PLAN_VERSE_MAX = 6        # 한 구절 묶음에서 보일 절 수 (넘으면 알린다)

    def _unit_plan_head(self, unit_id):
        """그 편이 든 도서묵상 플랜의 (포커스 목록, 구절 묶음 목록).

        구절 묶음 = `(단계 이름, 약명, [(절 번호, 본문)], 남은 수)`.
        플랜에 안 든 편이면 `([], [])` — 75%가 그렇다.
        """
        if not unit_id:
            return [], []
        # ⚠⚠ **구절 행은 `unit_key` 를 갖지 않는다** — 실측 2,902행 전부 비었다
        #   (`BOOK_TEXT` 2,872행만 갖는다). 그 편의 구절을 찾으려면
        #   **같은 (플랜, 일차, 트랙)의 형제 행**을 봐야 한다. `unit_key` 로만
        #   찾으면 **조용히 본문 행 하나**만 잡히고 구절이 통째로 빠진다.
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT s.stage_type, COALESCE(s.meditation_focus,''), "
                    "       s.start_vid, s.end_vid "
                    "FROM sys_plan_schedule b "
                    "JOIN sys_plan_schedule s "
                    "  ON s.plan_id = b.plan_id AND s.day = b.day "
                    " AND COALESCE(s.track,1) = COALESCE(b.track,1) "
                    "JOIN sys_bible_plan p ON p.plan_id = b.plan_id "
                    "WHERE b.unit_key = ? "
                    "  AND COALESCE(p.record_status,'LIVE')='LIVE' "
                    "ORDER BY s.plan_id, s.day, s.sort_order",
                    ('BOOK_%d' % unit_id,)).fetchall()
        except Exception as e:
            print('[plan head] %s' % e)
            return [], []
        if not rows:
            return [], []

        # ⚠⚠ **`meditation_focus` 의 성격이 행마다 다르다**(실측 295행).
        #   · `BOOK_TEXT` 행 = 진짜 묵상 안내문
        #       「하나님은 방법이 아닌 사람을 찾으신다: 오늘 당신은 …인가?」
        #   · `CORE`/`QUOTED` 행 = **그 구절 자체**(인용문 또는 참조)
        #       「Isaiah 43:1」 · 「또 무엇을 하든지 말에나 일에나 …」
        #   구절 행 것을 그대로 그리면 **「묵상 포커스」라는 이름으로 구절 본문이
        #   한 번 더** 뜬다(첫 판이 그랬다). ⇒ 안내문은 `BOOK_TEXT` 행에서만.
        # ⚠ `|` 가 든 것은 「제목 | 구절」 **라벨**이다(스펄전 7건) — 제목도 구절도
        #   화면에 이미 있으므로 안 그린다. 데이터 상태가 아니라 **형식**으로 가른다.
        order = {k: i for i, (k, _, _) in enumerate(self._STAGE_LABEL)}
        focus, seen_f = [], set()
        packs, seen_v = [], set()
        for st, mf, sv, ev in rows:
            mf = (mf or '').strip()
            if st == 'BOOK_TEXT' and mf and '|' not in mf and mf not in seen_f:
                seen_f.add(mf)
                focus.append(mf)
            if st not in order or not sv:
                continue           # BOOK_TEXT 행은 본문 자신이라 안 그린다
            key = (st, sv, ev or sv)
            if key in seen_v:
                continue
            seen_v.add(key)
            packs.append(key)
        packs.sort(key=lambda k: (order[k[0]], k[1]))

        lang = (self.lang_getter() or 'KO')
        ver = self.version_getter()
        out = []
        for st, sv, ev in packs:
            verses, rest = self._plan_verse_text(sv, ev, ver)
            if not verses:
                continue
            try:
                import medi_note
                label = medi_note.verse_label(self.db_path, sv, ev, lang)
            except Exception:
                label = ''
            # ★★ **단계 이름을 안 쓴다** (2026-08-31 사용자 「구절약명 왼쪽에
            #   "인용구절"이라는 라벨이 붙는데 **제거하라. 모든 도서/설교집
            #   공통 방식으로 적용하라**」).
            #   ⇒ 어느 책이든 **`핵심구절  약명  본문`** 한 꼴이다. 플랜이 있는
            #     책만 「핵심 말씀」·「인용 구절」로 달리 불리던 것이 사라진다.
            #   ⚠ `_STAGE_LABEL` 은 **정렬 차례**로 남는다(CORE 먼저) — 이름만
            #     안 쓴다. 지우면 묶음 순서가 흐트러진다.
            # ★★★ **라벨을 아예 안 붙인다** (2026-08-31 사용자 「본문 내부에
            #   핵심구절, 인용구절 등의 표현이 아직도 살아있다. 이것을
            #   **표준화하라** … **스펄전 아침저녁묵상은 매우 깔끔하다. 이것이
            #   표준이다**」). 그 책은 `인용문 / 약명 / 본문` 뿐이고 **이름표가
            #   없다.** 약명은 밑줄·색이 이미 「누를 수 있는 구절」이라 말한다.
            #   ⚠ DB 본문에는 그 낱말이 **0건**이었다 — 전부 우리가 그리던 것이다.
            out.append(('', label, verses, rest))
        return focus, out

    def _plan_verse_text(self, start_vid, end_vid, version):
        """구간의 (절 번호, 본문) 목록과 **잘라 낸 수**.

        ⚠ **조용히 자르지 않는다**(§0) — 마이어처럼 유닛이 장 전체인 책은
          한 묶음이 30절을 넘는다. `PLAN_VERSE_MAX` 까지만 보이고 남은 수를 알린다.
        """
        # ⚠⚠ **번호로 나열하면 안 된다**(§verse_range) — 마이어 「아가서 6장」
        #   편은 끝이 아6:14(vid 31113 · 절체계 이형)라, 번호로 세면 그 사이
        #   **13,488절**(요한계시록까지)이 이 편의 구절로 나온다(실측).
        #   `sort_order` 로 견주면 14절이다.
        import verse_range as _vr
        a, b = start_vid, (end_vid or start_vid)
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT bi.verse, COALESCE(bc.verse_text,'') "
                    "FROM bible_index bi "
                    "LEFT JOIN bible_content bc ON bc.verse_id = bi.verse_id "
                    "                          AND bc.version_code = ? "
                    "WHERE " + _vr.between_sql('bi.verse_id') +
                    " ORDER BY bi.sort_order",
                    [version] + _vr.between_args(a, b)).fetchall()
        except Exception as e:
            print('[plan verse] %s' % e)
            return [], 0
        rows = [(v, (t or '').strip()) for v, t in rows if (t or '').strip()]
        if len(rows) > self.PLAN_VERSE_MAX:
            return rows[:self.PLAN_VERSE_MAX], len(rows) - self.PLAN_VERSE_MAX
        return rows, 0

    # ── 이 책의 묵상플랜 ──────────────────────────────────────────────────────
    def _book_plans(self, book_id):
        """이 도서를 하루치로 나눈 플랜 목록 → [(plan_id, 제목)].

        ⚠ 잇는 열쇠는 **스케줄의 `unit_key`** 다(`BOOK:<unit_id>`) — 도서와
          플랜을 직접 잇는 칸이 없다(`plan_main_view._load_book_plan_map` 과 같은 길).
        """
        if not book_id:
            return []
        # ⚠ **제목은 여기서 읽지 않는다** — `sys_text_asset` 직접 읽기는
        #   `db_overlay_audit` 이 세는 자리이고(화면이 덮개를 건너뛴다),
        #   무엇보다 이름 규칙이 화면마다 갈린다. **`plan_label` 이 이름의 집**이다.
        try:
            import plan_label
            with appdb.connect(self.db_path) as conn:
                ids = [r[0] for r in conn.execute("""
                    SELECT DISTINCT p.plan_id
                      FROM sys_bible_plan p
                      JOIN sys_plan_schedule s
                           ON s.plan_id=p.plan_id AND s.stage_type='BOOK_TEXT'
                      JOIN sys_book_unit u
                           ON u.unit_id = CAST(SUBSTR(s.unit_key, 6) AS INTEGER)
                     WHERE p.record_status='LIVE' AND u.book_id=?
                     ORDER BY p.plan_id""", (book_id,))]
                lang = (self.lang_getter() if callable(self.lang_getter)
                        else 'KO') or 'KO'
                t = plan_label.titles_of(conn, ids, lang)
            return [(i, t.get(i) or str(i)) for i in ids]
        except Exception as e:
            print('[book plans] %s' % e)
            return []

    def _open_book_plan(self):
        """[묵상플랜] — 하나면 바로, 여럿이면 고르게 한다."""
        u = getattr(self, '_current_unit', None) or {}
        plans = self._book_plans(u.get('book_id'))
        if not plans or not callable(self.on_book_plan):
            return
        if len(plans) == 1:
            self.on_book_plan(plans[0][0])
            return
        # ⚠ 마이어는 성경 책별로 **67개**다 — 목록으로 고르게 한다
        import tkinter.simpledialog  # noqa: F401  (Toplevel 만 쓴다)
        win = tk.Toplevel(self)
        win.title(i18n.t('PR_BOOK_PLAN', '묵상플랜'))
        win.transient(self.winfo_toplevel())
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        lb = tk.Listbox(win, width=44, height=min(18, len(plans)))
        for _pid, t in plans:
            lb.insert('end', t)
        lb.pack(fill='both', expand=True, padx=10, pady=(10, 4))
        lb.selection_set(0)

        def _go(_e=None):
            i = (lb.curselection() or [0])[0]
            pid = plans[i][0]
            win.destroy()
            self.on_book_plan(pid)
        lb.bind('<Double-1>', _go)
        tk.Button(win, text=i18n.t('COMMON_OK', '확인'), command=_go
                  ).pack(pady=(0, 10))
        try:
            import ui_theme
            ui_theme.paint(win)
        except Exception:
            pass

    # ── 읽는 방식 갈래는 **폐기**됐다 (2026-08-31 `0.txt` 2번) ────────────────
    #   묵상과 단순읽기의 장점을 합쳤다 — 재료가 있으면 늘 보이고 걸음은 자유.
    #   ⚠ `user_config['READ_MODE']` 는 **지우지 않았다** — 남의 값을 지우는
    #     일이라 되돌릴 때 곤란해진다. 아무도 안 읽으므로 해가 없다(§99차
    #     「지우는 것과 안 쓰는 것은 다르다」).

    def _plan_head_lines(self, unit_id):
        """머리 블록 → `[(태그, 글줄)]`. 없으면 빈 목록."""
        focus, packs = self._unit_plan_head(unit_id)
        L = []
        # ★★ **이 편의 구절 — 4단 맨 위** (2026-08-31 `0.txt` 2번 「성경구절 …
        #   연결된 성경구절이 없는 경우 제외」). 1단에서 내려온 자리다.
        #   ⚠ **근거를 함께 밝힌다**(§78) — 원문에 장:절이 없는 책은 그 구절을
        #     우리가 골랐다. 1단에 있던 이 표시를 잃으면 저자가 인용한 것처럼
        #     읽힌다. 값이 비어 있으면(모름) 아무 말도 안 한다.
        self._keyref = None
        self._keyref_notext = False
        u = self._current_unit or {}
        u = u if u.get('unit_id') == unit_id else {}
        # ★★★ **핵심구절 줄은 한 번만 나온다.** 그전에는 같은 구절이 **네 자리**에
        #   있었다 — ① 1단 부제 ② 3단 약명 단추 ③ 우리 머리 줄 ④ 플랜의 「핵심
        #   말씀」 묶음. ME 류는 **저자의 본문 첫 줄**까지 다섯이었다.
        #   ⇒ 세 갈래로 갈라 **어느 경우에도 하나**가 되게 한다.
        _kv = self._KV_RE.search(u.get('verse_ref') or '')
        if u and self._body_says_verse(u):
            # ⓐ **저자의 본문이 이미 말한다**(ME 732편) — 우리는 안 그리고,
            #    그 구절을 되풀이하는 플랜 묶음도 뺀다.
            packs = [p for p in packs if not self._pack_repeats(p, _kv)]
            # ★★ **그 약명을 「제자리에서」 누를 수 있게 한다** (2026-08-31
            #   사용자 「본문에 핵심말씀 구절 버튼과 본문을 배치한다고 했는데
            #   진행하라」). 줄을 하나 더 그리면 그것이 곧 중복이므로,
            #   **저자가 이미 적어 둔 약명**에 링크를 건다. 각주 참조와 같은
            #   기법이라 새 장치가 없다.
            #   ⚠ 표기가 갈린다 — 원문은 `Joshua 5:12`, 번역본은 `여호수아 5:12`.
            #     **둘 다 찾아본다**(찾는 것은 렌더가 한다).
        elif packs:
            # ⓑ **플랜 묶음이 이미 그린다** — 묶음 머리의 약명을 누르게만 한다.
            #   ⚠ **본문은 덧붙이지 않는다** — 묶음이 절 줄을 바로 아래에
            #     이미 그린다. 붙이면 같은 글이 두 번 뜬다(실측으로 잡았다).
            self._keyref = (packs[0][1] or '').strip() or None
            self._keyref_notext = True
        elif u.get('verse_ref') or u.get('start_vid'):
            # ⓒ **우리 줄 하나** — 실측 4,276편이 여기다(플랜도, 본문 표기도 없다).
            # ⚠ **`start_vid` 만 있어도 그린다**(2026-08-31) — 약명 칸이 빈 395편
            #   (머레이·로렌스·켐피스…)이 그 이유로 통째로 빠져 있었다.
            #   「모든 도서/설교집에 통일된 기준」이라는 사용자 원칙 그대로다.
            _lab = self._key_verse_label(u)
            # ★ 라벨 없이 **약명 + 본문** — ME 표준(2026-08-31 사용자 확정).
            _line = _lab
            _body = self._key_verse_text(u)
            if _body:
                _line = '%s  %s' % (_line, _body)
            if (u.get('verse_source') or '') == 'EDITORIAL':
                _line = '%s  (%s)' % (_line, i18n.t(
                    'PR_VERSE_EDITORIAL', '엮은이가 선택한 구절'))
            self._keyref = _lab          # 렌더가 이 글자를 눌리게 만든다
            L.append(('pkey', _line))
            L.append(('pgap', ''))
        if not focus and not packs:
            return L
        for mf in focus:
            L.append(('phead', '◆ %s' % i18n.t('PR_MFOCUS', '묵상 포커스')))
            L.append(('pfocus', '    %s' % mf))
            L.append(('pgap', ''))
        for name, label, verses, rest in packs:
            # 이름이 없으면 **약명만** — ME 표준과 같은 꼴이 된다.
            L.append(('phead', ('▸ %s   %s' % (name, label)) if name
                      else label))
            for vno, txt in verses:
                L.append(('pverse', '    %d  %s' % (vno, txt)))
            if rest:
                L.append(('pmore', '    %s' % i18n.t(
                    'PR_VERSE_MORE', '… 그 밖에 {n}절').format(n=rest)))
            L.append(('pgap', ''))
        return L

    def _render_plan_head(self, unit_id):
        """본문 맨 앞에 머리 블록을 넣고 태그를 **그때그때** 칠한다(§36).

        ⚠ 색을 박지 않는다 — `ui_theme.C(역할)` 만 읽는다. Text 태그는 `paint`
          가 못 보므로 **그릴 때마다** 다시 건다.
        """
        lines = self._plan_head_lines(unit_id)
        t = self._body_txt
        # ⚠⚠ **머리 줄이 없어도 빠져나가면 안 된다** — 저자가 본문에 이미 적어
        #   둔 약명에 링크를 거는 일이 아래에 있다(ⓐ 갈래는 줄을 안 그린다).
        #   일찍 return 하던 탓에 ME 732편에서 **약명이 안 눌렸다**(실측).
        if lines:
            was = str(t.cget('state'))
            t.config(state='normal')
            for tag, s in reversed(lines):
                t.insert('1.0', s + '\n', tag)
            t.config(state=was)
        for tag, role, dflt in (('phead',  'fg_title', '#1A5276'),
                                ('pfocus', 'fg',       '#2C3E50'),
                                ('pverse', 'fg',       '#2C3E50'),
                                ('pkey',   'fg',       '#2C3E50'),
                                ('pmore',  'fg_dim',   '#95A5A6')):
            try:
                import ui_theme
                col = ui_theme.C(role) or dflt
            except Exception:
                col = dflt
            t.tag_config(tag, foreground=col,
                         spacing1=(6 if tag in ('phead', 'pkey') else 0))
        t.tag_config('pgap', spacing1=0)
        # ★★ **핵심구절의 약명을 누를 수 있게 한다** — 각주 참조(`fnref`)가 쓰는
        #   바로 그 기법이다(태그 + `tag_bind`). 「본문에 링크가 되는가」라는
        #   물음의 답 = **이미 되고 있었다.**
        #   ⚠ 누르면 **역본흐름(장 비교)** 으로 — 사용자 지시. `⇄ 장 비교`
        #     단추가 하던 일을 그 자리에서 한다.
        cands = [x for x in (getattr(self, '_keyref', None),
                             *self._keyref_alts()) if x]
        if cands:
            try:
                t.tag_delete('keyref')
            except Exception:
                pass
            # ⚠ 우리 줄은 맨 위 두세 줄이고, 저자의 약명은 **인용문 다음 줄**
            #   이라 조금 아래다. 여덟 줄까지 본다(그 아래는 본문이다).
            i, ref = '', ''
            # ⚠⚠ **대소문자를 구분하면 못 찾는다** — 머레이는 본문에
            #   `"Abide in me."--JOHN 15:4` 처럼 **대문자**로 적는다(실측).
            #   `nocase` 라 길이는 같으므로 아래 `len(ref)` 가 그대로 맞다.
            for cand in cands:
                i = t.search(cand, '1.0', '9.0', nocase=1)
                if i:
                    ref = cand
                    break
            if i:
                t.tag_add('keyref', i, '%s + %d chars' % (i, len(ref)))
                t.tag_config('keyref', foreground=_C('accent', '#2E86C1'),
                             underline=1)
                t.tag_bind('keyref', '<Button-1>',
                           lambda _e: self._goto_chapter_compare())
                t.tag_bind('keyref', '<Enter>',
                           lambda _e: t.config(cursor='hand2'))
                t.tag_bind('keyref', '<Leave>', lambda _e: t.config(cursor=''))
                # ★★★ **약명 오른쪽에 그 구절 본문** (2026-08-31 사용자 「본문에
                #   구절약명이 표시된다. **그 오른쪽에 본문 내용을 표시하라.
                #   성경버전 설정값에 따라** 표시되어야 한다」).
                #   ⚠ **저자의 글을 고치는 것이 아니다** — 화면에만 덧붙이고
                #     DB 는 한 글자도 안 바뀐다(§0-1b 원문 규칙).
                #   ⚠ **이미 본문이 딸려 있으면 안 붙인다** — ⓑ(플랜 묶음)는
                #     다음 줄에, ⓒ(우리 줄)는 같은 줄에 이미 있다. 두 번 뜬다.
                #   ⚠ **각주 태그를 건 뒤**라 안전하다 — Tk 태그는 글을 끼워도
                #     함께 밀린다(머리 블록을 나중에 넣는 것과 같은 까닭).
                _end = '%s + %d chars' % (i, len(ref))
                _rest = t.get(_end, '%s lineend' % _end).strip()
                # ⚠ **장 단위 표기(`시 107편`)에는 안 붙인다** — 1절 본문을
                #   옆에 놓으면 그 편이 1절만 다루는 것처럼 읽힌다(실측 2/20).
                _has_v = bool(self._KV_RE.search(
                    (self._current_unit or {}).get('verse_ref') or ''))
                if not _rest and _has_v and not getattr(
                        self, '_keyref_notext', False):
                    _vt = self._key_verse_text(self._current_unit or {}, limit=0)
                    if _vt:
                        was2 = str(t.cget('state'))
                        t.config(state='normal')
                        t.insert(_end, '  ' + _vt, 'pkeytext')
                        t.config(state=was2)
                        t.tag_config('pkeytext', foreground=_C('fg', '#2C3E50'))

    # ── 묵상노트 (유닛 기준 구절 닻) — 통합 저장소 (2026-08-19) ────────────────

    def _note_ctx(self, unit_id):
        """그 편의 노트 맥락 — `(후보, 키, 짧은 라벨, 전체 라벨, 닻)`.

        ★★ **닻은 언제나 편이다** (2026-08-24 사용자 확정). 그전에는 그 편의
          **기준 구절**이 닻이라 `start_vid` 가 없으면 단추가 잠겼고, 실측
          **496편(12권 통째)** 이 그 상태였다 — 에더샤임·고백록·팡세에 노트를
          달 수 없었다. 이제 구절은 **참고**일 뿐이고 없어도 쓴다.
        ★ **짧은 라벨과 전체 라벨을 함께 준다** (사용자 「책 제목 짧은 것만
          표시하라. 클릭하면 풍선처럼 전체이름을」) — 실측 영어 제목 최대 49자
          ↔ 한국어 제목 중앙값 9자. 번역 제목이 곧 짧은 이름이다.
        """
        if not unit_id:
            return None
        lang = self.lang_getter() or 'KO'
        try:
            with appdb.connect(self.db_path) as conn:
                # ⚠ 노트 라벨에도 **번역 덮개**를 쓴다 — `book_label` 참조.
                # ★ 2026-10-21 관련구절 = 그 편이 구절에 거는 자리(book_link — 마이어는 주제 구절 한 절 · P2 와 같은 기준)
                import book_link as _BL
                r = conn.execute(
                    "SELECT " + _BL.anchor_sql('u', 'a') + ", u.sequence, "
                    "       COALESCE(ta.contents, u.unit_label), "
                    "       a.book_code, u.book_id "
                    "FROM sys_book_unit u JOIN sys_book_asset a "
                    "  ON a.book_id=u.book_id "
                    "  LEFT JOIN sys_text_asset ta "
                    "         ON ta.text_type='BOOK_UNIT_LABEL' "
                    "        AND ta.clicked_id=u.unit_id "
                    "        AND UPPER(ta.lang_code)=UPPER(?) "
                    "        AND ta.record_status='LIVE' "
                    " WHERE u.unit_id=?", (lang, unit_id)).fetchone()
                if not r:
                    return None
                import book_label
                bshort, bfull = book_label.book_title_short(conn, r[5], lang)
        except Exception as e:
            print('[note ctx] %s' % e)
            return None
        svid, evid, seq, ulabel, bcode, _bid = r
        import medi_note
        cands = []
        if svid:      # 구절이 있으면 참고로 보인다 (없어도 노트는 쓴다)
            cands = [(medi_note.verse_label(self.db_path, svid, evid or svid,
                                            lang), svid, evid or svid)]
        key = 'BOOK:%s:%s' % (bcode, seq)
        head = i18n.t('MN_SRC_BOOK', '도서')
        ul = ulabel or str(seq)
        return (cands, key,
                '%s · %s · %s' % (head, bshort, book_label.shorten(ul, 24)),
                '%s · %s · %s' % (head, bfull or bcode, ul),
                ('BOOK', unit_id))

    def _refresh_note_btn(self, unit_id):
        """단추 상태·개수. ⚠ **구절이 없어도 열린다** — 닻이 편이기 때문."""
        if not hasattr(self, '_note_btn'):
            return
        ctx = self._note_ctx(unit_id) if unit_id else None
        n = 0
        if ctx:
            try:
                import medi_note
                n = len(medi_note.notes_for_context(self.db_path, ctx[1]))
            except Exception:
                pass
        base = i18n.t('MN_WRITE_BOOK', '도서노트')
        self._note_btn.config(
            state=('normal' if ctx else 'disabled'),
            text=(base + (' (%d)' % n if n else '')))

    def _edit_unit_tags(self):
        """[연결] — 지금 보고 있는 글에서 다른 자산으로 잇는다 (2026-08-21).

        ★ **[태그] 단추를 대체한다** — 태그는 그 창 안 갈래 하나다.
        ★ **한 단추가 두 갈래를 맡는다** — 도서·설교(`BOOK_UNIT`)와
          교리자료(`REF_UNIT`). 어느 쪽을 보고 있느냐로 갈린다.
          그전에는 교리자료를 보는 중이면 대상이 없다고만 알렸다.
        ⚠ 함수 이름은 그대로 두었다 — 부르는 곳이 있다."""
        u = self._current_unit
        d = getattr(self, '_current_doctrine_unit', None)
        if u:
            tt, tid, need = 'BOOK_UNIT', u['unit_id'], '도서·설교'
        elif d:
            tt, tid, need = 'REF_UNIT', d['unit_id'], '교리자료'
        else:
            self._need_unit()
            return
        try:
            import link_picker

            def redraw():
                # ★ 넣거나 뺄 때마다 연구자료 칩 줄을 곧바로 되그린다 —
                #   창을 닫기 전에 실제 화면이 바뀌는 것을 본다(사용자 지시).
                if tt == 'BOOK_UNIT':
                    self._refresh_linked_research(tid)
            link_picker.open_picker(
                self, self.db_path, tt, tid,
                lang_getter=(self.lang_getter if callable(
                    getattr(self, 'lang_getter', None)) else None),
                on_open=(self.on_link_open if callable(
                    getattr(self, 'on_link_open', None)) else None),
                on_saved=redraw)
        except Exception as e:
            print(f'[unit link] {e}  ({tt} #{tid} · {need})')

    def _need_unit(self):
        """★★★ **「목록에서 선택하세요」가 상황과 안 맞았다** (2026-08-31 사용자
        「읽기시작 버튼을 누르지 않은 상태에서 My Edit 버튼을 누르니까 **목록에서
        대상을 고르라고 한다. 이미 골랐다.** 읽기시작을 누르지 않았을 뿐이다」).

        맞다 — 책은 이미 골랐고 **편을 안 열었을 뿐**이다. 그런데 「목록에서
        고르세요」는 **아무것도 안 골랐다**는 뜻이라 무엇을 하라는지 알 수 없다.
        ⇒ 하라는 일을 **그대로** 적는다 — 「[읽기 시작]을 누르세요」.
        ⚠ 세 단추(My Edit·연구자료·도서노트)가 **한 말**을 쓴다 — 화면마다 다른
          말은 다른 규칙으로 읽힌다(`tag_picker.need_target` 과 같은 까닭).
        """
        messagebox.showinfo(
            i18n.t('PR_NEED_UNIT_T', '읽을 편을 먼저 여세요'),
            i18n.t('PR_NEED_UNIT',
                   '[읽기 시작]을 눌러 읽을 편을 연 뒤에 쓸 수 있습니다.'),
            parent=self.winfo_toplevel())

    def _open_my_edit(self):
        """[My Edit] — 지금 보고 있는 편(또는 교리자료 글)을 출발지로.

        ⚠ **자기 것을 안 넘기면 엉뚱한 기준이 뜬다**(`my_edit.open` 주석 —
          연구자료가 그래서 창1:1 로 열렸다).
        """
        u = getattr(self, '_current_unit', None)
        d = getattr(self, '_current_doctrine_unit', None)
        if u and u.get('unit_id'):
            kind, tid = 'BOOK_UNIT', u['unit_id']
        elif d and d.get('unit_id'):
            kind, tid = 'REF_UNIT', d['unit_id']
        else:
            self._need_unit()
            return
        try:
            import my_edit
            my_edit.open(self, kind, tid,
                         on_changed=lambda *_a: self._refresh_linked_research(tid)
                         if kind == 'BOOK_UNIT' else None)
        except Exception as e:
            print('[my edit] %s' % e)

    # ── 도서 묵상 AI 도우미 (2026-10-13 docs/1.txt 81 — 한 권 시험 뒤 넓힌다) ──────
    AI_BOOK_TEST = ('SPURGEON_ME',)      # 시험하는 책(아침과 저녁 묵상) — 확인 뒤 A4 이하 책으로 넓힌다
    on_ai_book = None                    # (unit_id) — user_main 이 P4 AI 도우미로 연다

    def _ai_book_ok(self):
        """지금 편에서 AI 묵상을 쓸 수 있나 — 시험 책 · A4 한 장 이하 편."""
        u = getattr(self, '_current_unit', None) or {}
        if not u.get('unit_id') or getattr(self, '_current_doctrine_unit', None):
            return False
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT a.book_code FROM sys_book_unit u JOIN sys_book_asset a ON a.book_id=u.book_id"
                              " WHERE u.unit_id=?", (u['unit_id'],)).fetchone()
                if not r or r[0] not in self.AI_BOOK_TEST:
                    return False
                import user_ai
                return user_ai.book_unit_fits(c, u['unit_id'], self.lang_getter() or 'KO')
        except Exception:
            return False

    def _ai_unlocked(self):
        u = getattr(self, '_current_unit', None) or {}
        return u.get('unit_id') in self._ai_open or self._cur_read_done()

    def _sync_ai_btn(self, flash=False):
        b = getattr(self, '_ai_btn', None)
        if b is None:
            return
        u = getattr(self, '_current_unit', None) or {}
        if not u.get('unit_id') or getattr(self, '_current_doctrine_unit', None):
            if b.winfo_manager():
                b.pack_forget()
            return
        if not b.winfo_manager():
            b.pack(side='right', padx=(6, 0), after=self._note_btn)
        if not self._ai_book_ok():
            # ★ 시험 기간 — 다른 책에서도 자리는 보이고 **까닭을 말한다**(「아무것도 안 보인다」 2026-10-13)
            b.config(text=i18n.t('PR_AI_MEDI_TEST', 'AI 묵상 · 지금은 『아침과 저녁 묵상』에서 시험 중'),
                     state='normal', fg=_C('fg_dim', '#7F8C8D'), cursor='arrow')
            return
        if self._ai_unlocked():
            b.config(text=i18n.t('PR_AI_MEDI', 'AI 묵상'), state='normal', fg=_C('accent', '#1A5276'),
                     cursor='hand2')
            if flash:
                bg0 = b.cget('bg')
                b.config(bg=_C('success_bg', '#D5F5E3'))
                b.after(900, lambda: b.winfo_exists() and b.config(bg=bg0))
        else:
            b.config(text=i18n.t('PR_AI_MEDI_LOCK', 'AI 묵상 · 끝까지 읽으면 열립니다'), state='normal',
                     fg=_C('fg_dim', '#7F8C8D'), cursor='arrow')

    def _ai_unlock(self):
        u = getattr(self, '_current_unit', None) or {}
        uid = u.get('unit_id')
        if uid and uid not in self._ai_open and self._ai_book_ok():
            self._ai_open.add(uid)
            self._sync_ai_btn(flash=True)

    def _ai_book_click(self):
        if not self._ai_book_ok() or not self._ai_unlocked():
            return                      # 잠긴 동안은 눌러도 아무 일 없음(글자가 까닭을 말한다)
        u = getattr(self, '_current_unit', None) or {}
        if u.get('unit_id') and callable(self.on_ai_book):
            self.on_ai_book(u['unit_id'])

    def save_ai_note(self, unit_id, text):
        """AI 도우미 [묵상 기록을 도서노트로] — 그 편의 도서노트 문으로 저장한다. 성공하면 True."""
        ctx = self._note_ctx(unit_id)
        if not ctx:
            return False
        cands, key, label, _full, unit = ctx
        import medi_note
        sv = cands[0][1] if cands else None
        ev = cands[0][2] if cands else None
        medi_note.save_new(self.db_path, sv, ev, text, src_key=key, src_label=label,
                           lang=self.lang_getter() or 'KO', unit=unit)
        u = getattr(self, '_current_unit', None) or {}
        if u.get('unit_id') == unit_id:
            self._refresh_note_btn(unit_id)
        return True

    def _close_note_editor(self):
        """쓰기 칸·노트 목록을 걷는다 — 편이 바뀌거나 소개문·다른 갈래로 가면(79-3)."""
        for a in ('_note_editor_f', '_note_list_f'):
            w = getattr(self, a, None)
            if w is not None:
                try:
                    if w.winfo_exists():
                        w.destroy()
                except Exception:
                    pass
            setattr(self, a, None)

    def _write_note(self, rec=None):
        u = self._current_unit
        if not u:
            # ⚠ 그전에는 **조용히 아무 일도 안 했다**(§0-1) — 눌러도 반응이
            #   없으면 고장으로 읽힌다.
            self._need_unit()
            return
        ctx = self._note_ctx(u['unit_id'])
        if not ctx:
            return
        cands, key, label, _full, unit = ctx
        import medi_note
        old = getattr(self, '_note_editor_f', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        oldl = getattr(self, '_note_list_f', None)
        if oldl is not None and oldl.winfo_exists():
            oldl.destroy()
        host = self._res_f.master

        def _done():
            self._refresh_note_btn(u['unit_id'])
            # ★ 저장·삭제 뒤에 **목록을 다시 그린다** — 안 그리면 방금 쓴 글이
            #   개수(1)로만 늘고 화면에는 안 보인다(사용자 신고 그대로였다).
            self._render_note_list(host, ctx)

        f = medi_note.NoteBar(host, self.db_path, cands, src_key=key,
                              src_label=label,
                              lang=self.lang_getter() or 'KO', rec=rec,
                              on_done=_done,
                              title_text=i18n.t('MN_WRITE_BOOK',
                                                '도서노트'),
                              unit=unit)
        self._note_editor_f = f
        # ⚠ expand 자식보다 pack 순서가 늦으면 1×1 — before= 로 당긴다(경로 줄과 동일)
        kw = {'fill': 'x', 'side': 'bottom', 'padx': 4, 'pady': 4}
        for w in host.pack_slaves():
            if str(w.pack_info().get('expand')) in ('1', 'True', 'true'):
                kw['before'] = w
                break
        f.pack(**kw)
        self._render_note_list(host, ctx)

    on_note_ai = None      # (vid, end_vid) — user_main 이 심는다(79-3)
    on_context = None      # (ctx) — P4 연구/설교노트 자리 거르개(79-2)

    def _render_note_list(self, host, ctx):
        """쓴 노트를 **댓글 방식**으로 — 최근이 위, 안쪽 스크롤 없음(`notes.md`).

        ⚠⚠ **이것이 없었다** (2026-08-30 사용자 신고 「작성하고 저장했는데
          표시되는 곳도 없다. 버튼에 (1)이라고 표시하는데 클릭하면 댓글방식
          목록이 표시되지 않는다」). 단추는 **쓰기 폼만** 열었고, 도서 편에
          닻을 둔 노트는 P2 묵상노트(구절 닻)에도 안 나온다 — 쓴 글이 갈 데가
          없었다. 개수만 세고 있었으니 **있는 줄은 알지만 못 읽는** 상태였다.
        """
        old = getattr(self, '_note_list_f', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        self._note_list_f = None
        try:
            import medi_note
            rows = medi_note.notes_for_context(self.db_path, ctx[1])
        except Exception as e:
            print('[note list] %s' % e)
            return
        if not rows:
            return
        f = tk.Frame(host, bg=_C('bg', '#FDFEFE'))
        self._note_list_f = f
        for i, r in enumerate(rows):
            if i:
                tk.Frame(f, bg=_C('border', '#D5D8DC'), height=1).pack(
                    fill='x', padx=6)
            row = tk.Frame(f, bg=_C('bg', '#FDFEFE'))
            row.pack(fill='x', padx=6, pady=3)
            when = (r.get('updated_at') or r.get('created_at') or '')[:10]
            tk.Label(row, text=when, bg=_C('bg', '#FDFEFE'),
                     fg=_C('fg_dim', '#7F8C8D'),
                     font=('Malgun Gothic', 8)).pack(side='left', anchor='n')
            body = tk.Label(row, text=(r.get('body') or '').strip(),
                            bg=_C('bg', '#FDFEFE'), fg=_C('fg', '#2C3E50'),
                            font=('Malgun Gothic', 9), justify='left',
                            anchor='w', wraplength=520, cursor='hand2')
            body.pack(side='left', padx=(8, 0), fill='x', expand=True)
            # ⚠ **클릭 = 수정** — 지우기 단추를 따로 두지 않는다. `NoteBar` 가
            #   수정 모드에서 [삭제]를 이미 갖고 있다(두 자리에 두면 갈라진다).
            body.bind('<Button-1>', lambda _e, rec=r: self._write_note(rec))
            # ★ 2026-10-13 79-3 (4) — 편에 기준 구절이 있으면 [AI 분석](플랜 노트·P2 와 같은 문)
            _sv = (self._current_unit or {}).get('start_vid')
            if _sv and callable(getattr(self, 'on_note_ai', None)):
                tk.Button(row, text=i18n.t('PFV_NOTE_AI', 'AI 분석'),
                          command=lambda v=_sv: self.on_note_ai(v, None),
                          **__import__('ui_theme').flat_btn(font=('', 8))
                          ).pack(side='right', anchor='n')
        kw = {'fill': 'x', 'side': 'bottom', 'padx': 4, 'pady': (4, 0)}
        ed = getattr(self, '_note_editor_f', None)
        if ed is not None and ed.winfo_exists() and ed.winfo_manager():
            kw['before'] = ed
        f.pack(**kw)
        try:
            import ui_theme
            ui_theme.paint(f)
        except Exception:
            pass

    # ── 이 책의 여백메모 (2026-08-24 사용자 지시) ─────────────────────────────

    def _sync_unit_bar(self):
        """★★★ **편이 바뀌면 3단이 통째로 따라온다 — 갈래를 안 가린다**
        (2026-08-31 사용자 「도서읽기에서 버튼 () 표시가 유닛 변경할 때마다
        자동 수정되었다면 설교집 등등에서 **당연히 적용되어야** 한다. **왜
        일일히 말해야만 수정하는가?**」).

        지적이 맞다. 뿌리는 **갱신 자리가 갈래마다 갈려 있던 것**이다 —
        `_refresh_memos_btn` 은 `_show_unit`(도서·설교)에만 있고
        `_show_doctrine_unit` 에는 없었다. 그래서 교리자료로 옮겨도 `(4)` 가
        그대로였다(실측). **한 곳에 모으면 갈래를 늘려도 안 빠진다.**
        ⚠ 새 단추를 3단에 더할 때는 **여기에 한 줄** 더한다.
        """
        tab, u = self._cur_tab()
        uid = (u or {}).get('unit_id')
        if uid:
            self._refresh_note_btn(uid)
        self._refresh_memos_btn()
        self._refresh_fav_btn()
        self._sync_assets_btn()
        self._sync_ai_btn()
        # ★★★ **읽던 자리는 편을 옮길 때마다 담는다** (2026-09-01 사용자 신고
        #   「다음 버튼을 20~40번 누르다 보면 **5편으로 이동한다**」 ·
        #   「책 트리를 선택하고 **읽기 시작을 누르면 5편이 세팅된다**」 ·
        #   「그래서 **5편으로 돌아가려고 하는 것 같다**」 — 진단이 정확했다).
        #   ⚠⚠ **뜻은 있었는데 배선이 없었다** — `db_read_state.set_pos` 의
        #     주석이 「편을 옮길 때마다 덮어쓴다」라고 적어 두었지만 실제로
        #     `_save_pos()` 를 부르는 곳은 **다른 화면으로 떠날 때 한 자리뿐**
        #     이었다. 그래서 담아 둔 자리가 옛 편에 멈춰 있었고(실측 마이어
        #     `user_book_pos` = unit 6216 = **차례 5**), 두 증상이 다 거기서 나왔다:
        #       · [읽기 시작] → 늘 그 옛 편으로 간다
        #       · 읽는 중 `_current_unit` 을 잠깐 잃으면 `_band_ctx` 가
        #         **담아 둔 자리로 되돌아간다**(§129차 폴백) → 「5편으로 튄다」
        #   ⇒ **여기 한 줄**이면 갈래를 안 가린다(도서·설교·교리자료 모두 이
        #     문을 지난다). 떠날 때 부르던 `_save_pos()` 는 그대로 둔다.
        #   ⚠ **폴백을 쓰지 않는다** — `_band_ctx()` 는 현재 편이 없으면 담아 둔
        #     자리를 돌려주므로, 그것으로 저장하면 옛 값을 제자리에 다시 쓴다.
        bid = (u or {}).get('book_id')
        if uid and bid:
            try:
                import db_read_state as rs
                with appdb.connect(self.db_path) as c:
                    rs.set_pos(c, bid, uid)
            except Exception as e:
                print('[unit pos] %s' % e)

    def _refresh_memos_btn(self, book_id=None):
        """**이 편의** 여백메모 수 — 메모가 있을 때만 단추를 띄운다.

        ★★ 2026-08-31 사용자 「유닛을 보고 있는데 **책 전체의 메모를 표시하면
          안된다. 유닛의 메모만** 표시하라」. 맞다 — 편을 넘겨도 숫자가 안 바뀌어
          **무엇을 세는 것인지** 알 수 없었다(실측 교리자료로 옮겨도 `(4)` 그대로).
        ⚠ 이름도 함께 바꿨다 — 「이 책의」라 적고 편을 세면 거짓말이 된다.
        ⚠ 인자 `book_id` 는 **부르는 곳이 많아** 받기만 하고 안 쓴다.
        """
        b = getattr(self, '_memos_btn', None)
        if b is None:
            return
        n = 0
        try:
            import highlight_notes
            tab, u = self._cur_tab()
            n = highlight_notes.count_unit_notes(
                self.db_path, 'REF' if tab == 'DOCTRINE' else 'BOOK',
                (u or {}).get('unit_id'))
        except Exception as e:
            print('[memos btn] %s' % e)
        if n:
            b.config(text='%s (%d)' % (
                i18n.t('MN_MEMOS_UNIT', '이 편의 여백메모'), n))
            if not b.winfo_ismapped():
                # ★ **연구자료 왼쪽**(2026-08-31 사용자 지시) — 오른쪽 정렬
                #   묶음이라 `before=연구자료` 가 곧 그 왼쪽이다.
                # ★ 연구자료 왼쪽 = My Edit 오른쪽 (사용자 지시 둘을 함께)
                b.pack(side='right', padx=(6, 0), after=self._note_btn)   # 도서노트 왼쪽(79-1)
        elif b.winfo_ismapped():
            b.pack_forget()

    def _open_book_memos(self):
        """책 한 권의 밑줄 메모를 순서대로 — 편 제목을 누르면 그 편으로 간다.

        ⚠ 단추는 **맨 위**(§0). ⚠ 색을 박지 않고 태그를 **그릴 때 칠한다**(§36).
        ⚠ `ui_theme.adopt` 는 **다 지은 뒤 마지막에** — 먼저 부르면 그때 있는
          자식만 칠하고 뒤에 붙는 위젯이 통째로 남는다(§65차).
        """
        u = self._current_unit
        if not u:
            return
        bid = u.get('book_id')
        lang = self.lang_getter() or 'KO'
        try:
            import highlight_notes, book_label
            rows = highlight_notes.load_book_notes(self.db_path, bid, lang)
            with appdb.connect(self.db_path) as conn:
                btitle = book_label.book_title(conn, bid, lang, '')
        except Exception as e:
            print('[book memos] %s' % e)
            return
        if not rows:
            return

        win = tk.Toplevel(self)
        win.title('%s — %s' % (i18n.t('MN_MEMOS_BOOK', '이 책의 여백메모'), btitle))
        win.geometry('720x640')

        bar = tk.Frame(win)
        bar.pack(fill='x', padx=8, pady=6)
        tk.Label(bar, text='%s · %d' % (btitle, len(rows))).pack(side='left')
        tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), bd=1, padx=10,
                  cursor='hand2', command=win.destroy).pack(side='right')

        wrap = tk.Frame(win)
        wrap.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')
        txt = tk.Text(wrap, wrap='word', bd=0, yscrollcommand=vsb.set)
        vsb.config(command=txt.yview)
        txt.pack(fill='both', expand=True)
        try:
            import theme_font
            theme_font.register(txt, self.db_path, 'prose')
        except Exception:
            pass

        def _jump(seq):
            um = {x['unit_id']: x for x in self._book_units + self._sermon_units}
            for x in um.values():
                if x.get('book_id') == bid and x.get('sequence') == seq:
                    win.destroy()
                    self.jump_to_unit(x['unit_id'])
                    return

        last = None
        for seq, ulabel, nid, anchor, body, when in rows:
            if seq != last:
                last = seq
                tag = 'u%s' % seq
                txt.insert('end', '%s. %s\n' % (seq, ulabel or seq),
                           ('mhead', tag))
                txt.tag_bind(tag, '<Button-1>',
                             lambda _e, s=seq: _jump(s))
                txt.tag_config(tag, underline=False)
            try:
                import highlight_notes as HN
                quote = HN.split_anchor(anchor)[1]
            except Exception:
                quote = anchor or ''
            if quote:
                txt.insert('end', '    「%s」\n' % ' '.join(quote.split()),
                           'mquote')
            txt.insert('end', '    %s\n' % ' '.join((body or '').split()), 'mbody')
            txt.insert('end', '    %s\n\n' % (when or '')[:10], 'mdate')

        for tg, role, dflt, extra in (
                ('mhead',  'fg_title', '#1A5276', {'spacing1': 8}),
                ('mquote', 'accent',   '#2E86C1', {}),
                ('mbody',  'fg',       '#2C3E50', {}),
                ('mdate',  'fg_dim',   '#95A5A6', {})):
            try:
                import ui_theme
                col = ui_theme.C(role) or dflt
            except Exception:
                col = dflt
            txt.tag_config(tg, foreground=col, **extra)
        txt.tag_config('mhead', spacing1=8)
        try:
            import reading_pane
            reading_pane.enable_copy(txt)
        except Exception:
            txt.config(state='disabled')
        try:
            import ui_theme
            ui_theme.adopt(win)          # ⚠ 마지막에 한 번
        except Exception:
            pass

    def _refresh_book_routes(self, book_id):
        """묵상경로 — 「이 도서로 하는 묵상」 줄 (2026-08-17). 경로가 있을 때만.
        연구자료 목록과 같은 자리 규칙(본문 아래 bottom)."""
        if getattr(self, '_broute_f', None) is None:
            self._broute_f = tk.Frame(self._res_f.master, bg='#FDFEFE')
        for w in self._broute_f.winfo_children():
            w.destroy()
        routes, prevs = [], []
        if book_id:
            try:
                import plan_route
                with appdb.connect(self.db_path) as conn:
                    lang = self.lang_getter() or 'KO'
                    routes = plan_route.routes_from(conn, 'BOOK', book_id,
                                                    lang=lang)
                    prevs = plan_route.routes_to(conn, 'BOOK', book_id,
                                                 lang=lang)
            except Exception as e:
                print('[book routes] %s' % e)
        # ★ 다음 단계가 없어도 이전 단계만으로 줄을 띄운다 (2026-08-18 지시)
        if ((not routes and not prevs)
                or not callable(getattr(self, 'on_route_jump', None))):
            self._broute_f.pack_forget()
            return
        import plan_route
        if prevs:
            # ★ 이름 없이 「◀ 이전 단계」만 — 하나면 바로, 여럿이면 이름 메뉴
            back = tk.Label(self._broute_f,
                            text=i18n.t('PMV_PREV_STEP', '◀ 이전 단계'),
                            bg='#FDFEFE', fg='#1A5276', cursor='hand2',
                            font=('', 8, 'underline'))
            back.pack(side='left', padx=(10, 12))
            back.bind('<Button-1>',
                      lambda e, pv=prevs:
                      plan_route.prev_click(e, pv, self.on_route_jump))
        if routes:
            tk.Label(self._broute_f,
                     text=i18n.t('ROUTE_BOOK_NEXT', '이 도서로 하는 묵상:'),
                     bg='#FDFEFE', fg='#7F8C8D', font=('', 8)).pack(
                side='left', padx=(10 if not prevs else 0, 4))
            for r in routes:
                lbl = '%s (%s)' % (
                    r['label'],
                    plan_route.KIND_LABEL.get(r['kind'], r['kind']))
                link = tk.Label(self._broute_f, text=lbl, bg='#FDFEFE',
                                fg='#1A5276', cursor='hand2',
                                font=('', 8, 'underline'))
                link.pack(side='left', padx=(0, 8))
                link.bind('<Button-1>',
                          lambda _e, k=r['kind'], i=r['id']:
                          self.on_route_jump(k, i))
        if not self._broute_f.winfo_manager():
            # ⚠ expand 자식보다 pack 순서가 늦으면 남은 공간 0 → 1×1 로 안 보인다.
            #   `before=` 로 순서를 당겨야 bottom 띠가 자리를 받는다.
            kw = {'fill': 'x', 'side': 'bottom'}
            for w in self._broute_f.master.pack_slaves():
                if str(w.pack_info().get('expand')) in ('1', 'True', 'true'):
                    kw['before'] = w
                    break
            self._broute_f.pack(**kw)
        # 동적 링크 줄에도 테마 (0.txt ⑥과 같은 병 — 예방)
        try:
            import ui_theme
            if ui_theme.current() != ui_theme.DEFAULT:
                ui_theme.paint(self._broute_f)
        except Exception:
            pass

    def _refresh_linked_research(self, unit_id):
        """이 유닛의 연구자료·연결을 **모아 둔다** (그리는 것은 판이 한다).

        ⚠ `_res_box`(3단 단추 오른쪽 자리)는 **비워 두었다** — 위젯은 남기되
          아무것도 안 그린다. 지우면 다른 화면 코드가 그 이름을 찾다 죽는다.
        """
        box = getattr(self, '_res_box', None)
        if box is not None:
            for w in box.winfo_children():
                w.destroy()
        rows = []
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT ref_id, COALESCE(NULLIF(title,''), '(제목 없음)') "
                    "FROM user_ref_asset "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE' "
                    "  AND (body_unit_id=? "
                    # 연결 칸으로 붙인 도서/설교 연결(BOOK_UNIT — 2026-08-19)도 칩에
                    # ★ 2026-08-24 통합 표(`UREF_BUNT`)
                    "   OR ref_id IN (SELECT clicked_id FROM userdb.user_link_asset "
                    "        WHERE link_type='UREF_BUNT' AND target_id=? "
                    "          AND COALESCE(record_status,'LIVE')='LIVE') "
                    # ★ 새 연결 표 — 2026-08-21 이후 붙인 것은 여기에 있다.
                    "   OR ref_id IN (%s)) "
                    "ORDER BY ref_id DESC" % link_picker.SQL_REFS_OF_KIND,
                    # ★ 2026-08-24 — 통합 표라 **넉 자 코드**를 넘긴다
                    (unit_id, unit_id,
                     link_picker.CODE['BOOK_UNIT'], unit_id,
                     link_picker.CODE['BOOK_UNIT'], unit_id)).fetchall()
        except Exception as e:
            print('[linked research] %s' % e)
        # ⚠⚠ **가린 것을 존중한다** (2026-08-31 사용자 신고 「My Edit 에는 연결된
        #   것이 전혀 없는데 `dfdf` 가 연결되었다고 표시된다」).
        #   원인 — 위 첫 조건 `body_unit_id=?` 는 「**이 편에서 쓴 글**」이라
        #   연결 표를 안 본다. 그래서 My Edit 에서 그 연결을 숨겨도
        #   (`BUNT_UREF` HIDE 행) 칩이 그대로 남았다. **숨겨도 안 사라지는
        #   표시**는 「눌러도 아무 일이 없다」와 같은 종류의 거짓말이다(§0-1).
        #   ⇒ 가린 짝은 뺀다. 판정은 `link_picker.vetoed` 한 문 — 여기서 SQL 을
        #     또 쓰면 My Edit 과 갈린다.
        try:
            with appdb.connect(self.db_path) as conn:
                _hid = {i for k, i, _e in link_picker.vetoed(
                    conn, 'BOOK_UNIT', unit_id) if k == 'USER_REF'}
            if _hid:
                rows = [r for r in rows if r[0] not in _hid]
        except Exception as e:
            print('[linked research veto] %s' % e)
        # ★★★ **여기서는 그리지 않는다 — 재료만 모은다** (2026-08-31 `0.txt`
        #   1번 2) 사용자 「어떤 것은 버튼 오른쪽에 열거하고 어떤 것은 아래에
        #   열거한다. **모두 버튼 클릭에 반응하도록** 수정하라」).
        #   그전에는 연구자료·링크가 **3단 단추 오른쪽**(`_res_box`)에 늘 떠
        #   있고 태그만 아래 줄에 있었다 — 같은 성격의 것이 두 자리로 갈렸다.
        #   ⇒ 셋(용어·연구자료·그 밖 연결)을 **[연결된 자산 보기] 한 자리**로.
        self._ap_refs = list(rows)
        self._ap_links = self._unit_links(unit_id)
        # ★ 79-2 — P4 연구/설교노트가 이 자리로 미리 걸린다
        if callable(getattr(self, 'on_context', None)):
            try:
                idx = self._left_nb.index(self._left_nb.select())
            except Exception:
                idx = 0
            u = (getattr(self, '_current_doctrine_unit', None) if idx == 2
                 else getattr(self, '_current_unit', None)) or {}
            if u.get('unit_id') == unit_id:
                bt = u.get('book_title') or i18n.t('REFSRC_' + str(u.get('src_code') or ''), u.get('src_code') or '')
                ul = u.get('unit_label') or u.get('label') or ''
                try:
                    self.on_context({
                        'vid': u.get('start_vid'),
                        # 칩은 짧게 — 「아침과 저녁 묵상 7편」 · 「하이델베르크 교리문답 3문」
                        'label': ('%s %s%s' % (bt, u.get('sequence'), '문' if idx == 2 else '편'))
                                 if u.get('sequence') else (bt or ul)[:40],
                        'user_ids': {r[0] for r in rows},
                        'src': {'ref_type': self._SCOPE_REF_TYPE.get(idx, 'STUDY'),
                                'unit_id': u.get('unit_id'), 'book_id': u.get('book_id'),
                                'book_title': bt, 'unit_label': ul, 'start_vid': u.get('start_vid')}})
                except Exception as e:
                    print('[reading ctx] %s' % e)
        # ★ **연구자료 개수를 단추에** (2026-08-31 사용자 「연구자료는 연결된
        #   연구자료 갯수를 표시하면 안되는가?」 — 된다. 재료는 이미 여기 있다).
        #   ⚠ 0이면 **안 적는다** — `(0)` 은 눈만 어지럽히고 알려 주는 것이 없다
        #     (「연결된 자산 보기」는 **접이 단추**라 0을 적어야 열 것이 없다는
        #     뜻이 되지만, 이것은 **만드는 단추**라 0이어도 눌러야 한다).
        try:
            _n = len(rows)
            self._research_btn.config(
                text='%s%s' % (i18n.t('PR_RESEARCH_NEW', '연구/설교노트'),
                               (' (%d)' % _n) if _n else ''))
        except Exception:
            pass
        self._sync_assets_btn()

    def _unit_links(self, unit_id):
        """그 편에 걸린 **그 밖의 연결** → [(종류, 번호, 제목)].

        ⚠ 조회는 `link_picker.links_of` 한 문(§97차) · 태그는 위 갈래가 맡으므로
          연구자료만 뺀다(`_CHIP_SKIP`) — 그쪽은 제 조회가 따로 있다.
        ★★ **태그는 이제 여기서 온다** (2026-08-31) — `db_tag_system.
          fetch_tags_for` 는 **배포 표만** 읽어 내가 만든 태그를 빠뜨렸다
          (실측 편 1 의 「관계」가 판에 없었다). `links_of` 는 배포+개인을
          합쳐 읽으므로 **읽는 문이 하나**가 된다.
        """
        if not unit_id:
            return []
        try:
            import link_picker
            with appdb.connect(self.db_path) as c:
                # ★★★ **읽는 화면에는 가린 것을 안 보인다** (2026-08-31 사용자
                #   「연결자산 목록에서 **(가림)을 표시하면 안된다**」).
                #   §overlay_mark 가 이미 못 박은 규칙이다 — 「H 는 읽는 화면에
                #   뜨면 안 된다. 가린 줄에 표식을 붙여 목록에 남기면 그것은
                #   가린 것이 아니다.」 잠깐 켰다가 되돌린다.
                #   ⇒ 되살리는 자리는 **My Edit 휴지통**이고, 그 화면이 「구절」
                #     갈래를 못 만들던 것을 같은 날 고쳤다(`trash_view`).
                _sh = False
                return [(x['kind'], x['id'], (x['label'] or '').strip(),
                         bool(x.get('hidden')))
                        for x in link_picker.links_of(
                            c, 'BOOK_UNIT', unit_id, self.lang_getter() or 'KO',
                            include_hidden=_sh)
                        if x['kind'] not in self._CHIP_SKIP]
        except Exception as e:
            print('[unit links] %s' % e)
            return []

    #: 이미 화면 다른 곳에 보이는 갈래 — 칩으로 또 그리지 않는다
    _CHIP_SKIP = ('USER_REF',)

    def _open_research(self, ref_id):
        """연구자료 한 편 → P4 연구자료 탭 (`user_main._open_ref_detail`)."""
        cb = getattr(self, 'on_research_open', None)
        if callable(cb):
            cb('USER', ref_id)

    # ── 태그 로딩 및 렌더링 ────────────────────────────────────────────────────

    def _load_tags(self, unit_id=None, book_id=None):
        """이 유닛/도서에 붙은 태그 — **새 태그 체계 하나만 읽는다** (2026-08-18).
        옛 sys_book_unit_tag(분류 코드)·sys_unit_tag_link(연구태그)는
        db_tag_system --migrate 로 이관됐고 원본은 감사용으로만 남는다.
        반환: ([], [(sys_tag_id, 이름, kind, entity_id), ...]) — 첫 값은
        옛 분류라벨 자리(호환), 이제 항상 빈 목록이다."""
        rtags = []
        lang = self.lang_getter().upper()
        try:
            import db_tag_system
            with appdb.connect(self.db_path) as conn:
                if unit_id is not None:
                    rows = db_tag_system.fetch_tags_for(
                        conn, 'BOOK_UNIT', unit_id, lang)
                elif book_id is not None:
                    rows = db_tag_system.fetch_tags_for(
                        conn, 'BOOK', book_id, lang)
                else:
                    rows = []
                rtags = [(tid, nm, kind, eid)
                         for tid, nm, kind, _cat, eid in rows]
        except Exception as e:
            print('[tags] %s' % e)
        return [], rtags

    def _render_tags(self, content_labels, research_tags):
        """용어(태그) 재료를 담아 두고 단추 숫자를 맞춘다 — **그리지 않는다.**

        ★★ 2026-08-31 `0.txt` 1번 2) — 용어·연구자료·그 밖 연결이 **한 자리**
          ([연결된 자산 보기] 아래)에서만 보인다. 그전에는 용어만 아래 줄에,
          나머지는 단추 오른쪽에 늘 떠 있었다.
        """
        self._ap_tags = list(research_tags or [])
        self._sync_assets_btn()

    # ── 연결된 자산 판 — 제목으로, 줄바꿈으로 (2026-08-31 `0.txt` 1번 2)) ─────
    #
    # ★★★ **개수가 아니라 제목을 적는다** (사용자 「제목을 표시하는 것이 아니라
    #   용어1 도서1 묵상플랜1... 이런 표시는 **비상식적**이다」). 맞다 — 「도서 1」
    #   은 무엇이 걸렸는지 하나도 안 알려 준다.
    # ★ **바탕색을 없앤다**(사용자 지시) — 글자만 둔다. 클릭되는 것만 밑줄.
    # ★ **폭을 넘으면 줄을 바꾼다** — 실제 글자 폭을 재어 줄을 나눈다
    #   (`link_picker._ax_reflow` 와 같은 문법. `wraplength` 는 **한 라벨 안**의
    #   줄바꿈이라 여러 라벨을 흘려보내지 못한다).
    def _toggle_assets(self):
        """옛 [연결된 자산 보기] — 단추를 걷었다(79-1). 부르는 곳이 있어 이름만 남긴다."""
        self._sync_assets_btn()

    def _sync_assets_btn(self):
        """연결된 자산 줄 — **있으면 늘 한 줄로**(2026-10-13 docs/1.txt 79-1 「연결된 자산 목록을 기본값으로 ·
        한 줄만 · P1 엔티티 줄과 같은 방식」). 없으면 줄째 감춘다."""
        n = len(self._asset_items())
        bar = self._tag_bar
        if n:
            if not bar.winfo_manager():
                bar.pack(fill='x', padx=10, pady=(0, 2), after=self._band
                         if self._band.winfo_manager() else self._meta_sub.master)
            self._render_assets_panel()
        elif bar.winfo_manager():
            bar.pack_forget()

    # ★★★ **종류별 줄** (2026-08-31 사용자 「연결대상 자산의 종류에 따라 3줄
    #   정도로 배치하는 것은 어떨까? 용어/태그: …, 도서/설교: …, 묵상플랜: …,
    #   기타연결: … **연결대상이 없으면 목록 구분도 표시할 필요 없다**」).
    #   ⇒ 묶음 이름이 종류를 말하므로 **낱낱의 표식(`#`·`◈`)이 필요 없다**
    #     (사용자 물음 「하나님의 속성 앞에만 표식이 붙는 이유는?」의 답 —
    #     그 표식은 「갈 곳이 있다」는 뜻이었는데, 이제 **색**이 그 말을 한다).
    #   ⚠ **빈 묶음은 안 그린다** — 늘 네 줄이면 3단이 그만큼 두꺼워진다.
    #   ★★ **사용자가 만든 것도 종류에 따라 놓는다** (2026-08-31 사용자
    #     「사용자가 입력한 자산도 **자산 종류에 따라서** 배치해야 한다」).
    #     `UTAG`·`ULENS`·`UNODE`·`USER_REF`·`NOTE` 를 「내 자료」로 묶지 않고
    #     각각 제 종류 줄에 넣는다 — 사용자에게는 **누가 만들었나가 아니라
    #     무엇인가**가 먼저다(만든 이는 색·휴지통이 이미 말한다).
    #   ⚠ **「기타연결」이 자주 뜨면 묶음을 덜 나눈 것이다** — 실측에서 흐름과
    #     영상이 거기 떨어져 「이상하다」는 신고가 됐다. 제 이름을 주었다.
    _ASSET_GROUPS = (
        ('PR_G_TERM',  '용어/태그',  ('ENTITY', 'TAG', 'UTAG')),
        ('PR_G_VERSE', '구절',      ('VERSE', 'PERICOPE')),
        ('PR_G_BOOK',  '도서/설교',  ('BOOK', 'BOOK_UNIT')),
        ('PR_G_PLAN',  '묵상플랜',   ('PLAN', 'LENS', 'ULENS', 'NODE', 'UNODE')),
        ('PR_G_REF',   '연구자료',   ('REF_UNIT', 'USER_REF')),
        ('PR_G_NOTE',  '묵상노트',   ('NOTE',)),
        ('PR_G_MEDIA', '영상·링크',  ('MEDIA',)),
        ('PR_G_CHAIN', '구속사 흐름', ('CHAIN',)),
        ('PR_G_ETC',   '기타연결',   ()),          # 남는 것 전부
    )

    def _asset_items(self):
        """판에 놓을 것 → [(종류, 글자, 눌렀을 때, 누를 수 있나)]."""
        out = []
        # ⚠ 태그는 `_ap_links` 안에 함께 온다 — 여기서 또 넣지 않는다.
        for ref_id, title in (getattr(self, '_ap_refs', None) or []):
            out.append(('USER_REF', title or '(제목 없음)',
                        lambda r=ref_id: self._open_research(r), True))
        for row in (getattr(self, '_ap_links', None) or []):
            kind, aid, label = row[0], row[1], row[2]
            hid = row[3] if len(row) > 3 else False
            # ⚠ 태그 이름 뒤의 축(`· THEME`)은 뗀다 — 묶음 이름이 이미
            #   「용어/태그」라고 말하고, 축까지 붙으면 줄이 두 배로 길어진다.
            if kind in ('TAG', 'UTAG'):
                label = (label or '').split('  ·')[0].strip()
            if hid:
                continue          # 읽는 화면에는 안 보인다(§overlay_mark)
            out.append((kind, label or '#%s' % aid,
                        self._asset_go(kind, aid), True))
        return out

    def _asset_go(self, kind, aid):
        """그 자산으로 가는 일 — **도서·설교는 먼저 묻는다.**

        ★★ 2026-08-31 사용자 「연결대상이 도서/설교인 경우 **같은 탭에서
          이동하므로 지금 읽고 있는 맥락이 끊어진다**. 팝업으로 경고하거나
          다른 대안이 필요하다」. 맞다 — 구절·용어·자료는 P2·P4 로 가지만
          도서·설교는 **이 화면 자체**를 갈아 끼운다.
        ⚠ 읽던 자리는 `user_book_pos` 에 담겨 있어 돌아올 수 있다 —
          그 사실을 물음에 함께 적는다(모르면 못 돌아온다고 생각한다).
        """
        jump = getattr(self, 'on_link_open', None)
        if not callable(jump):
            return None

        def go(k=kind, i=aid):
            if k in ('BOOK', 'BOOK_UNIT'):
                self._save_pos()          # 떠나기 전에 읽던 자리를 담는다
                if not messagebox.askyesno(
                        i18n.t('PR_LEAVE_TITLE', '읽던 자리를 떠납니다'),
                        i18n.t('PR_LEAVE_ASK',
                               '이 화면이 다른 책으로 바뀝니다.\n'
                               '읽던 자리는 담아 두었으니 목록에서 다시 '
                               '열면 그 자리로 돌아옵니다.\n\n계속할까요?'),
                        parent=self.winfo_toplevel()):
                    return
            jump(k, i)
        return go

    def _book_orig_lang(self, conn):
        """지금 보고 있는 편의 **원문 언어**. 모르면 빈 글자.

        ★ 약명은 저자가 적은 글자라 **본문의 언어**를 따라야 한다
          (벨직=FR · 도르트=LA · 웨스트민스터=EN — 실측).
        ⚠ 편마다 물으면 넘길 때마다 질의라 **책 단위로 캐시**한다.
        """
        u = getattr(self, '_current_unit', None)
        bid = (u or {}).get('book_id') if isinstance(u, dict) else None
        if bid is None:
            return ''
        cache = getattr(self, '_bref_blang', None)
        if cache is None:
            cache = self._bref_blang = {}
        if bid in cache:
            return cache[bid]
        lg = ''
        try:
            r = conn.execute(
                "SELECT ut.lang_code FROM sys_book_unit_text ut "
                "JOIN sys_book_unit bu ON bu.unit_id = ut.unit_id "
                "WHERE bu.book_id = ? AND ut.text_variant = 'ORIGINAL' "
                "AND COALESCE(ut.lang_code, '') <> '' LIMIT 1", (bid,)).fetchone()
            lg = (r[0] or '').upper() if r else ''
        except Exception:
            lg = ''
        cache[bid] = lg
        return lg

    def _tag_body_refs(self):
        """저자가 본문에 적어 둔 **두 번째 이후** 성구 약명도 누르게 한다
        (2026-08-31 · `data.md` 할일 「본문 안 두 번째 이후 약명」).

        ★ 122차의 `keyref` 는 **그 편의 기준 구절 하나**만 걸었다 — 아는 번호로
          글자를 지어 찾는 방식이라 그럴 수밖에 없었다. 이것은 **반대 방향**
          이다: 글자에서 번호를 읽는다(`book_refs`).
        ⚠ **판정은 `book_refs` 한 곳**이 한다 — 여기에 정규식을 두면 책마다
          다르게 걸린다(`book_blocks` 와 같은 문법).
        ⚠ **이미 걸린 자리는 건너뛴다** — `keyref` 와 겹치면 태그가 포개져
          누를 때 어느 쪽이 도는지 알 수 없다.
        ⚠ **본문을 고치지 않는다** — 자리에 태그만 얹는다(§123차).
        ⚠ 못 읽은 것은 **그냥 둔다** — 탈무드·요세푸스·외경·OCR 오류가 그렇다.
          짐작으로 걸면 「그럴듯한데 엉뚱한 곳으로 가는 링크」가 된다.
        """
        t = getattr(self, '_body_txt', None)
        if t is None:
            return
        try:
            import book_refs
        except Exception:
            return
        try:
            for tg in t.tag_names():
                if tg == 'bref' or tg.startswith('bref_'):
                    t.tag_delete(tg)
        except Exception:
            pass
        try:
            body = t.get('1.0', 'end-1c')
            if not body or len(body.strip()) < 8:
                return
            lang = (self.lang_getter() or 'KO').upper()
            # ⚠ 이름 표는 **캐시한다** — 편마다 다시 지으면 66권 × 두 언어를
            #   매번 훑는다. 언어가 바뀌면 다시 짓는다.
            if getattr(self, '_bref_lang', None) != lang:
                with appdb.connect(self.db_path) as conn:
                    self._bref_tbl = book_refs.names(conn, lang)
                self._bref_lang = lang
            with appdb.connect(self.db_path) as conn:
                got = book_refs.resolve(conn, body, lang, tbl=self._bref_tbl)
                # ★★ **저자가 쓴 글자의 언어로 한 번 더 읽는다** (2026-09-06).
                #   약명은 **저자가 적은 것**이라 화면 언어가 아니라 그 책의
                #   원문 언어를 따른다 — 벨직 신앙고백은 원문이 프랑스어라
                #   `Jean iv. 24`·`Es. xl. 28`·`Apoc. i. 11` 로 적혀 있어
                #   KO/EN 이름표로는 **절반이 안 걸렸다**(실측 493 대 628).
                # ⚠ **이름표를 합치지 않는다** — FR 과 KO 에 같은 약명이 다른
                #   책을 가리키는 것이 있다(실측 `so` = 아가 ↔ 스바냐).
                #   따로 읽고 **겹치는 자리는 아래 `skip` 이 막는다**(화면
                #   언어가 먼저 걸리므로 그쪽이 이긴다).
                blang = self._book_orig_lang(conn)
                if blang and blang != lang:
                    k = '_bref_tbl2_' + blang
                    tb2 = getattr(self, k, None)
                    if tb2 is None:
                        tb2 = book_refs.names(conn, blang)
                        setattr(self, k, tb2)
                    got = list(got) + list(
                        book_refs.resolve(conn, body, blang, tbl=tb2))
            if not got:
                return
            # 이미 걸린 자리(기준 구절 약명)의 글자 범위
            skip = []
            rg = list(t.tag_ranges('keyref'))
            for a, b in zip(rg[0::2], rg[1::2]):
                try:
                    skip.append((t.count('1.0', a, 'chars')[0],
                                 t.count('1.0', b, 'chars')[0]))
                except Exception:
                    pass
            n = 0
            # ⚠ 두 언어를 겹쳐 읽으므로 **긴 것부터** 본다 — 짧은 약명이
            #   먼저 걸리면 긴 이름의 일부만 링크가 된다.
            got = sorted(got, key=lambda g: (g[0], -(g[1] - g[0])))
            for st, en, vid, _bc, _ch, _vs in got:
                if any(st < b and en > a for a, b in skip):
                    continue
                skip.append((st, en))   # 이미 건 자리도 막는다(중복 태그 방지)
                tag = 'bref_%d' % n
                t.tag_add('bref', '1.0 + %d chars' % st, '1.0 + %d chars' % en)
                t.tag_add(tag, '1.0 + %d chars' % st, '1.0 + %d chars' % en)
                t.tag_bind(tag, '<Button-1>',
                           lambda _e, v=vid: self._goto_body_ref(v))
                n += 1
            if not n:
                return
            t.tag_config('bref', foreground=_C('accent', '#2E86C1'),
                         underline=1)
            t.tag_bind('bref', '<Enter>', lambda _e: t.config(cursor='hand2'))
            t.tag_bind('bref', '<Leave>', lambda _e: t.config(cursor=''))
        except Exception as e:
            print('[body refs] %s' % e)

    def _goto_body_ref(self, vid):
        """본문 안 약명을 누르면 **그 구절로** — 각주 구절과 같은 길이다."""
        if vid and callable(self.on_verse_jump):
            self.on_verse_jump(vid)

    def _keyref_alts(self):
        """저자가 본문에 적었을 법한 약명 표기들.

        ⚠⚠ **저장된 글자만 보면 못 찾는다** — `verse_ref` 는 이미 화면 언어의
          **약명**(`수5:12`)인데 저자의 본문은 **정식명 + 공백**(`여호수아 5:12`)
          으로 적는다. 실측으로 잡았다(ME 732편 전부 그 꼴).
        ⇒ **번호에서 다시 짓는다** — 화면 언어의 약명·정식명, 그리고 원문이
          영어일 때를 위해 영어 정식명·약명까지.
        """
        u = self._current_unit or {}
        vid = self._key_verse_vid(u)
        out = []
        raw = (u.get('verse_ref') or '').strip()
        if raw:
            out.append(raw)
        # ⚠⚠ **약명 칸이 비어도 `start_vid` 만 있으면 링크가 걸려야 한다**
        #   (2026-08-31 사용자 「머레이 「내 안에 거하라」는 아직 본문에 표시된
        #   구절이 링크 방식이 아니다」). 실측 — **395편이 그 상태**다
        #   (따로 한적한 곳에서 268 · 그리스도를 본받아 70 · 내 안에 거하라 31 …).
        #   `verse_ref` 가 없다고 물러나면 그 책들은 영영 안 걸린다.
        if not vid:
            return tuple(out)
        try:
            lang = self.lang_getter().upper()
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT bi.bcode, bi.chapter, bi.verse FROM bible_index bi"
                    " WHERE bi.verse_id=?", (vid,)).fetchone()
                if not r:
                    return tuple(out)
                bc, ch, vs = r
                for lg in (lang, 'EN'):
                    n = conn.execute(
                        "SELECT COALESCE(full_name,''), COALESCE(short_name,'')"
                        "  FROM book_names WHERE book_code=?"
                        "   AND UPPER(lang_code)=?", (bc, lg)).fetchone()
                    if not n:
                        continue
                    for nm in n:
                        if not nm:
                            continue
                        # 라틴 이름은 한 칸 띄우고 CJK 는 붙인다(§3-1)
                        for sep in ((' ',) if nm[-1].isascii() else (' ', '')):
                            cand = '%s%s%d:%d' % (nm, sep, ch, vs)
                            if cand not in out:
                                out.append(cand)
        except Exception as e:
            print('[keyref alts] %s' % e)
        return tuple(out)

    def _render_assets_panel(self):
        """한 줄 — 「용어: 하나님의 속성  은혜 │ 도서: 고백록 …」 · 넘치면 옆으로 굴린다(휠 · ›).
        ⚠ P1 엔티티 줄과 같은 문법(가로 캔버스 + 칩) — 줄이 늘지 않는다."""
        bar = self._tag_bar
        if not getattr(self, '_tag_bar_ready', False):
            bg = _C('bg', '#FDFEFE')
            self._as_more = tk.Button(bar, text='›', relief='flat', bd=0, padx=5,
                                      cursor='hand2', bg=bg, fg=_C('fg_dim', '#555555'),
                                      font=('', 11),
                                      command=lambda: self._as_cvs.xview_scroll(3, 'units'))
            self._as_more.pack(side='right', padx=(2, 0))
            self._as_cvs = tk.Canvas(bar, bg=bg, height=24, bd=0, highlightthickness=0)
            self._as_cvs.pack(side='left', fill='x', expand=True)
            self._as_inner = tk.Frame(self._as_cvs, bg=bg)
            self._as_cvs.create_window((0, 0), window=self._as_inner, anchor='nw')
            self._as_inner.bind('<Configure>', lambda _e: self._as_cvs.config(
                scrollregion=self._as_cvs.bbox('all')))
            self._as_wheel = lambda e: self._as_cvs.xview_scroll(-1 if e.delta > 0 else 1, 'units')
            self._as_cvs.bind('<MouseWheel>', self._as_wheel)
            self._tag_bar_ready = True
        for w in self._as_inner.winfo_children():
            w.destroy()
        self._as_cvs.xview_moveto(0)
        items = self._asset_items()
        seen = set()
        first = True
        for key, dflt, kinds in self._ASSET_GROUPS:
            grp = ([x for x in items if x[0] in kinds] if kinds
                   else [x for x in items if x[0] not in seen])
            seen |= set(kinds)
            if not grp:
                continue
            if not first:
                tk.Frame(self._as_inner, width=1, bg=_C('border', '#D5D8DC')).pack(
                    side='left', fill='y', padx=8, pady=4)
            first = False
            hl = tk.Label(self._as_inner, text='%s:' % i18n.t(key, dflt), font=('', 9),
                          bg=_C('bg', '#FDFEFE'), fg=_C('fg_dim', '#7F8C8D'))
            hl.pack(side='left', padx=(0, 4))
            hl.bind('<MouseWheel>', self._as_wheel)
            for _k, text, go, live in grp:
                lb = tk.Label(self._as_inner, text=text, font=('', 9), bg=_C('bg', '#FDFEFE'),
                              fg=_C('accent', '#2E86C1') if live else _C('fg_dim', '#7F8C8D'))
                if go:
                    lb.config(cursor='hand2')
                    lb.bind('<Button-1>', lambda _e, f=go: f())
                lb.bind('<MouseWheel>', self._as_wheel)
                lb.pack(side='left', padx=(0, 10))
        try:
            import ui_theme
            ui_theme.paint(bar)
        except Exception:
            pass

    def _show_book_info(self, book_id: int):
        """도서/설교집 노드 클릭 시 우측에 도서 소개 표시."""
        self._close_note_editor()
        self._note_shown_uid = None
        lang = self.lang_getter().upper()
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute("""
                    SELECT COALESCE(bat.title, ba.title),
                           COALESCE(bat.author, ba.author),
                           ba.pub_year,
                           COALESCE(bat.description, ba.description),
                           ba.source_url,
                           ba.title
                    FROM sys_book_asset ba
                    LEFT JOIN sys_book_asset_text bat
                         ON bat.book_id = ba.book_id
                        AND UPPER(bat.lang_code) = ?
                        AND bat.record_status = 'LIVE'
                    WHERE ba.book_id = ?
                """, (lang, book_id)).fetchone()
        except Exception:
            return
        if not row:
            return
        title, author, pub_year, desc, src_url, orig_title = row
        self._current_unit = None
        self._current_book_id = book_id            # 1단 ♥ 이 딛는 자리
        self._texts = {}
        self._meta_title.config(text=title or '')
        # ★★ **원제를 함께 적는다** (2026-08-31 `0.txt` 2번 사용자 「원어가 더
        #   유명하고 번역된 제목이 일반적이지 않을 가능성을 고려해서 필요하다」).
        #   ⚠ 번역 제목과 **같으면 안 적는다** — 같은 글자를 두 번 적으면
        #     원제가 따로 있는 줄 알게 된다.
        parts = []
        if orig_title and (orig_title or '').strip() != (title or '').strip():
            parts.append(orig_title)
        parts += [p for p in [author, str(pub_year) if pub_year else None] if p]
        self._meta_sub.config(text='  ·  '.join(parts))
        self._placeholder.place_forget()
        self._fav_btn.config(text='☆', fg='#7F8C8D')   # 편 즐겨찾기 — 편이 없다
        self._refresh_book_fav_btn()
        self._sync_book_open_btn(book_id)
        self._sync_band()                 # 진도 숫자는 **책이 바뀔 때마다**
        clabels, rtags = self._load_tags(book_id=book_id)
        self._render_tags(clabels, rtags)
        body_text = desc or '(도서 소개가 없습니다.)'
        # 폰트는 **지원/설정 ▸ 폰트**(`theme_font` 「book」 구역)가 정한다.
        # ⚠ 채울 때마다 다시 불러야 한다 — 여기서 옛 콤보값을 씌우고 있었다.
        try:
            import theme_font
            theme_font.apply(self._body_txt, self.db_path, 'book')
        except Exception:
            pass
        self._body_txt.config(state='normal')
        self._body_txt.delete('1.0', 'end')
        self._body_txt.insert('1.0', body_text)
        self._append_license_link(src_url)
        self._body_txt.config(state='disabled')
        self._body_txt.yview_moveto(0)
        self._hl_reload()
        # ★ 소개문에도 약명이 나온다(우리 글이라 한글 약명 꼴).
        self._tag_body_refs()

    def _append_license_link(self, src_url=None):
        """소개문 끝에 **출처·라이선스 화면으로 가는 줄** 한 줄.

        ★ 소개문에는 어디서 왔는지만 적고, 기관이 요구하는 고지 전문은 한 곳
          (`license_info`)에 둔다. 책마다 베껴 두면 갈라진다.
        ⚠ 색은 그릴 때마다 역할로 다시 입힌다(§36-5b) — 이 본문은 책을 고를
          때마다 새로 그리므로 만들 때 한 번 칠해 두면 테마에서 굳는다.
        """
        url = (src_url or '').lower()
        sect = ('PG' if 'gutenberg.org' in url else
                'CCEL' if 'ccel.org' in url else
                'IA' if 'archive.org' in url else None)
        txt = self._body_txt
        txt.tag_configure('liclink',
                          foreground=_C('accent', '#1565C0'),
                          underline=True)
        txt.insert('end', '\n\n')
        txt.insert('end', i18n.t('PR_LICENSE_LINK', '출처·라이선스 보기 ▸'),
                   'liclink')
        txt.insert('end', '\n')

        def _open(_e=None):
            try:
                import license_info
                license_info.show_license(
                    self.winfo_toplevel(), self.lang_getter() or 'KO', sect)
            except Exception as e:
                print('[license link] %s' % e)

        txt.tag_bind('liclink', '<Button-1>', _open)
        txt.tag_bind('liclink', '<Enter>', lambda e: txt.config(cursor='hand2'))
        txt.tag_bind('liclink', '<Leave>', lambda e: txt.config(cursor='xterm'))

    def _hl_kind(self):
        """지금 본문이 어느 갈래인가 — 형광펜이 담을 자리를 가른다.

        ⚠ 도서 유닛과 교리자료 유닛은 표가 달라 번호가 **549개 겹친다.**
          한 갈래로 담으면 교리자료 메모가 엉뚱한 도서에 뜬다.
        """
        return 'REF' if getattr(self, '_current_doctrine_unit', None) else 'BOOK'

    def _hl_unit(self):
        u = (getattr(self, '_current_doctrine_unit', None)
             or getattr(self, '_current_unit', None) or {})
        return u.get('unit_id')

    def _hl_reload(self):
        """본문을 채운 **뒤에** 부른다. 안 부르면 그 화면에서만 메모가 사라진다."""
        hl = getattr(self, '_hl', None)
        if hl is not None:
            try:
                hl.reload()
            except Exception as e:
                print('[highlight reload] %s' % e)

    # ── 각주 성구 (2026-08-23 사용자 「각주에 구절 내용을 표시하면 편리할 것
    #    같다」 — 채택 안 B). **DB 는 안 건드린다** — 그릴 때만 살을 붙인다.
    #    규약·해석은 `book_footnote.py` 가 단일 소스다.

    def _annotate_footnotes(self, body: str):
        """각주 줄 아래에 구절 본문을 붙인다 → (본문, 자리, 끼운 줄).

        ⚠ 실패해도 **본문은 그대로 보인다** — 각주 살리기는 덤이지 본문이 아니다.
        """
        try:
            import book_footnote
            variant = self._g_variant_var.get()
            lang = (self._g_lang_var.get().upper()
                    if variant == 'TRANSLATED' else 'EN')
            bn_lang = lang if lang in ('KO', 'EN', 'JA', 'ZH') else 'EN'
            with appdb.connect(self.db_path) as conn:
                return book_footnote.annotate(conn, body,
                                              self.version_getter(), bn_lang)
        except Exception as e:
            print('[footnote] %s' % e)
            return body, [], []

    def _tag_footnotes(self, spots, vlines):
        """참조를 누를 수 있게 하고 끼운 구절 줄을 흐리게.

        ⚠ **색은 렌더마다 역할로 다시 준다**(§0) — Text 태그 색은 `ui_theme.paint`
          가 못 보므로 여기서 안 칠하면 검정 테마에서 굳는다.
        """
        txt = self._body_txt
        for t in txt.tag_names():
            if t == 'fnref' or t == 'fnverse' or t.startswith('fn_'):
                txt.tag_delete(t)
        txt.tag_config('fnverse', foreground=_C('fg_dim', '#7F8C8D'))
        txt.tag_config('fnref', foreground=_C('accent', '#2E86C1'), underline=1)
        for ln in vlines:
            txt.tag_add('fnverse', '%d.0' % ln, '%d.end' % ln)
        for i, (ln, cs, ce, vs, _ve) in enumerate(spots):
            tag = 'fn_%d' % i
            txt.tag_add('fnref', '%d.%d' % (ln, cs), '%d.%d' % (ln, ce))
            txt.tag_add(tag, '%d.%d' % (ln, cs), '%d.%d' % (ln, ce))
            txt.tag_bind(tag, '<Button-1>',
                         lambda _e, v=vs: self._footnote_jump(v))
            txt.tag_bind(tag, '<Enter>',
                         lambda _e: txt.config(cursor='hand2'))
            txt.tag_bind(tag, '<Leave>', lambda _e: txt.config(cursor=''))
        # ⚠ 밑줄 메모가 우리 태그에 덮이지 않게 위로 올린다(§notes 와 같은 이유)
        try:
            txt.tag_raise('sel')
        except Exception:
            pass

    def _footnote_jump(self, vid):
        if vid and callable(self.on_verse_jump):
            self.on_verse_jump(vid)

    def _goto_chapter_compare(self):
        """본문 안 **핵심구절 약명**을 누르면 여기로 — 역본흐름(장 비교) 탭.
        (옛 `[⇄ 장 비교]` 단추의 몸통. 단추는 2026-08-31 에 걷었다.)"""
        u = self._current_unit
        vid = self._key_verse_vid(u or {})
        if vid and callable(self.on_chapter_compare):
            self.on_chapter_compare(vid)

    # ── 소개문의 [읽기 시작] / [↓ 받기] (2026-08-31) ─────────────────────────
    #
    # ★★★ 사용자 지적 — 「코어팩 상태에서 클릭하면 **도서소개문을 읽고
    #   다운로드 받을 수 있는 화면**으로 연결되는가?」. 그래야 맞다.
    #   소개문 한 화면이 **읽고 · ♥ 담고 · 열거나 받는** 일을 다 한다.
    # ⚠ **단추 하나가 상태에 따라 이름을 바꾼다** — 둘을 나란히 두면 하나는
    #   늘 회색이고, 회색 단추는 「왜 안 되나」를 묻게 만든다.
    def _book_has_text(self, book_id):
        """그 책의 본문을 실제로 가졌나 — 팩이 생기면 이 한 문이 갈래를 정한다."""
        try:
            with appdb.connect(self.db_path) as c:
                return c.execute(
                    "SELECT 1 FROM sys_book_unit bu JOIN sys_book_unit_text t "
                    "  ON t.unit_id = bu.unit_id AND t.record_status='LIVE' "
                    " WHERE bu.book_id=? LIMIT 1", (int(book_id),)).fetchone() is not None
        except Exception:
            return True          # 모르면 **있다고 본다** — 못 열게 막지 않는다

    def _fit_open_btn_box(self):
        """[읽기 시작] 칸 = **폭 고정 · 높이는 단추 그대로**."""
        b = getattr(self, '_book_open_btn', None)
        f = getattr(self, '_book_open_box', None)
        if b is None or f is None:
            return
        try:
            h = b.winfo_reqheight()
            if h > 1:
                f.config(width=self._OPEN_BTN_W, height=h)
                f.pack_propagate(False)
        except Exception:
            pass

    def _sync_book_open_btn(self, book_id=None):
        """★★★ **자리를 지킨다 — 사라지지 않는다** (2026-08-31 사용자 「읽기시작
        버튼이 읽는 중간에 **사라지면서 경로선택 버튼의 위치가 바뀌니까
        혼란스럽다**」). 맞다 — 단추가 들고 나면 이전/다음이 매번 다른 자리에
        오고, 손이 자리를 기억할 수 없다.
        ⇒ **늘 같은 자리**에 있고 상태만 바꾼다:
          · 소개문 → `읽기 시작`(또는 `↓ 받기`) · 누를 수 있다
          · 편을 보는 중 → **`읽는 중`** · **잠긴다**
        ⚠ 잠긴 단추는 보통 「고장」으로 읽히지만, 여기서는 **이름이 곧 상태**라
          왜 안 눌리는지 그 자리에서 알 수 있다(§0-1 의 예외가 성립하는 꼴).
        """
        b = getattr(self, '_book_open_btn', None)
        if b is None:
            return
        if book_id:
            self._book_open_bid = book_id
        bid = getattr(self, '_book_open_bid', None)
        on_unit = bool(getattr(self, '_current_unit', None)
                       or getattr(self, '_current_doctrine_unit', None))
        # ★★ 2026-10-16 사용자 「한번 살펴보려고 들어간 것일 뿐이다 · 명시적인 구독(읽기시작) 버튼」 —
        #   편을 열어 보는 것은 「살펴보기」이고 「읽는 중」은 [읽기 시작]을 눌러야 된다.
        #   이 자리는 그대로 지키고(폭 고정) 글자만 바뀐다: 읽기 시작 ↔ 읽기 중단.
        if getattr(self, '_current_unit', None):
            ctx = self._band_ctx()
            if ctx:
                bid = ctx[0]
                self._book_open_bid = bid
        reading = False
        if bid and not getattr(self, '_current_doctrine_unit', None):
            try:
                import db_read_state as rs
                with appdb.connect(self.db_path) as c:
                    reading = rs.is_reading(c, bid)
            except Exception as e:
                print('[book reading] %s' % e)
        if getattr(self, '_current_doctrine_unit', None) and not getattr(self, '_current_unit', None):
            b.config(text=i18n.t('PR_BOOK_READING', '읽는 중'),
                     fg='#7F8C8D', state='disabled')
        elif reading:
            b.config(text=i18n.t('PR_BOOK_STOP', '읽기 중단'),
                     fg='#A04000', state='normal')
        elif on_unit and bid:
            b.config(text=i18n.t('PR_BOOK_READ', '읽기 시작'),
                     fg='#1E8449', state='normal')
        elif bid and self._book_has_text(bid):
            b.config(text=i18n.t('PR_BOOK_READ', '읽기 시작'),
                     fg='#1E8449', state='normal')
        elif bid:
            b.config(text=i18n.t('BS_GET', '↓ 받기'),
                     fg='#B7950B', state='normal')
        else:
            b.config(text=i18n.t('PR_BOOK_READ', '읽기 시작'),
                     fg='#7F8C8D', state='disabled')
        if not b.winfo_ismapped():
            b.pack(side='left')
            self.after_idle(self._fit_open_btn_box)

    def _on_book_open_btn(self):
        bid = getattr(self, '_book_open_bid', None)
        if not bid:
            return
        # ★ 2026-10-16 「읽는 중」 = 사람이 정한다 — 중단(읽음·읽던 자리는 남는다) / 시작(이 책을 읽는 중으로)
        try:
            import db_read_state as rs
            with appdb.connect(self.db_path) as c:
                if rs.is_reading(c, bid):
                    rs.stop_reading(c, bid)
                    self._sync_book_open_btn()
                    return
                if self._book_has_text(bid):
                    rs.start_reading(c, bid)
        except Exception as e:
            print('[book start] %s' % e)
        if getattr(self, '_current_unit', None):
            self._sync_book_open_btn()           # 보고 있던 편 그대로 · 단추만 「읽기 중단」으로
            return
        if self._book_has_text(bid):
            # ★★ **직전에 읽던 자리로** (2026-08-31 사용자 「도서를 클릭하면
            #   **직전에 읽었던 곳을 찾아가지 못하는 것 같다**」).
            #   ⚠ 담아 둔 자리가 없으면(처음 여는 책) 첫 편이 맞다.
            uid = None
            try:
                import db_read_state as rs
                with appdb.connect(self.db_path) as c:
                    uid = rs.get_pos(c, bid)
            except Exception as e:
                print('[book open pos] %s' % e)
            if uid:
                self.jump_to_unit(uid)
            else:
                self._open_book_first(bid)
        else:
            # ★★★ **그 자리에서 받는다**(2026-09-04 ⑪) — 그전에는 다운로드
            #   화면으로 보냈고, 거기서 그 책을 다시 찾아야 했다.
            #   ⚠ 서버에 없으면 **그때 다운로드 화면으로** 보낸다(길을 막지
            #     않는다). 왜 그리로 가는지도 말한다.
            code = None
            try:
                with appdb.connect(self.db_path) as c:
                    r = c.execute("SELECT book_code FROM sys_book_asset"
                                  " WHERE book_id=?", (bid,)).fetchone()
                    code = r[0] if r else None
            except Exception:
                code = None
            if code and self._book_fetch(code):
                return
            if callable(getattr(self, 'on_download_jump', None)):
                self.on_download_jump(bid)

    def _book_fetch(self, book_code):
        """그 책을 서버에서 받는다 → 받았나(bool).

        ⚠ 받는 문은 `pack_status.fetch_asset` 하나(폴백·다운로드 화면과 같다).
        """
        from tkinter import messagebox
        import pack_status as _PS
        lang = (self.lang_getter() or 'KO').upper()
        if not messagebox.askyesno(
                i18n.t('SET_DL_GET', '지금 받기'),
                i18n.t('DL_GET_ASK',
                       '「%s」 를 지금 받습니다.\n\n'
                       '받는 동안 앱을 켜 두세요. 인터넷을 씁니다.')
                % str(book_code)[:50]):
            return True                      # 사용자가 그만둔 것 — 안 보낸다
        r = _PS.fetch_asset('BOOK', book_code, lang, self.db_path)
        if not r['ok']:
            return False                     # 부른 쪽이 다운로드 화면으로
        msg = i18n.t('DL_GET_DONE_N', '「%s」 를 받았습니다. (%s개)') \
            % (str(book_code)[:40], format(r['rows'], ','))
        if r.get('sub'):
            msg += chr(10) * 2 + i18n.t(
                'DL_GET_SUBLANG',
                '요청하신 언어는 아직 없어 %s 자료를 받았습니다.') % r.get('lang')
        messagebox.showinfo(i18n.t('SET_DL_GET', '지금 받기'), msg)
        # ★ 받았으면 **그 자리에서 연다** — 다시 찾아 들어가게 하지 않는다
        try:
            self._load_book_tree()
            self._open_book_first(
                self._book_open_bid or getattr(self, '_current_book_id', None))
        except Exception:
            pass
        return True

    # ── 읽을 차례 콤보 (2026-08-31) ──────────────────────────────────────────
    def _shelf_sort_order(self):
        """지금 열린 서재를 **읽을 차례 정렬**로 맞춘다(멱등)."""
        w = self._shelves.get(self._shelf_on)
        if w is None:
            return
        try:
            # ★ 이제 **체크박스**다(2026-08-31) — 정렬 갈래가 아니다.
            if hasattr(w, '_order_on'):
                w._order_on.set(True)
            w._render()
            w._sync_count()
        except Exception as e:
            print('[shelf sort order] %s' % e)

    def _order_kind(self):
        """지금 갈래 — 설교집 탭이면 SERMON, 아니면 BOOK."""
        try:
            return 'SERMON' if self._left_nb.index(
                self._left_nb.select()) == 1 else 'BOOK'
        except Exception:
            return 'BOOK'

    def _refresh_order_combo(self):
        """차례 top 10 을 콤보에 싣는다.

        ⚠ **비어 있으면 왜 비었는지 말한다**(§0-1) — 빈 콤보는 고장으로 읽힌다.
          「서재에서 ♥ 로 담으세요」를 그 자리에 적고, 누르면 서재를 연다.
        ⚠ 받았는지로 **거르지 않는다** — 안 받은 것도 차례에 든다(사용자 확정).
          받은 것만 `●`, 안 받은 것은 `↓` 로 **말해 준다**.
        """
        cb = getattr(self, '_ord_cb', None)
        if cb is None:
            return
        try:
            import read_order
            kind = self._order_kind()
            with appdb.connect(self.db_path) as c:
                # ⚠⚠ **갈래마다 알갱이가 다르다** — 도서는 **책**(book_id),
                #   설교는 **편**(unit_id). 설교집은 5권뿐이고 사용자가 고르는
                #   것은 설교 한 편이라 그것이 맞다(2026-08-31 사용자 확정).
                #   ⇒ 이름을 찾는 문도, 눌렀을 때 가는 길도 갈래를 본다.
                fin = (self._finished_units() if kind == 'SERMON'
                       else self._finished_books())
                rows = read_order.top(c, kind, fin)
                names = {}
                if rows:
                    q = ','.join('?' * len(rows))
                    lg = self.lang_getter().upper()
                    ids = [b for _r, b in rows]
                    if kind == 'SERMON':
                        names = {x['unit_id']: x.get('label') or ''
                                 for x in self._sermon_units
                                 if x['unit_id'] in set(ids)}
                    else:
                        names = dict(c.execute(
                            "SELECT ba.book_id, COALESCE(bat.title, ba.title) "
                            "  FROM sys_book_asset ba "
                            "  LEFT JOIN sys_book_asset_text bat "
                            "    ON bat.book_id = ba.book_id "
                            "   AND UPPER(bat.lang_code)=? AND bat.record_status='LIVE' "
                            " WHERE ba.book_id IN (%s)" % q,
                            [lg] + ids).fetchall())
        except Exception as e:
            print('[order combo] %s' % e)
            return
        self._ord_rows = []
        vals = []
        _sermon = (self._order_kind() == 'SERMON')
        for rank, bid in rows:
            mark = '●' if (_sermon or self._book_has_text(bid)) else '↓'
            vals.append('%d. %s %s' % (rank, mark, names.get(bid) or '#%d' % bid))
            self._ord_rows.append(bid)
        if not vals:
            vals = [i18n.t('PR_ORDER_EMPTY', '서재에서 ♥ 로 담으세요')]
            self._ord_rows = [None]
        vals.append(i18n.t('PR_ORDER_EDIT', '차례 조정…'))
        self._ord_rows.append('EDIT')
        cb.config(values=vals)
        self._ord_var.set(vals[0])

    def _on_order_pick(self, _e=None):
        try:
            i = self._ord_cb.current()
            tgt = self._ord_rows[i]
        except Exception:
            return
        if tgt == 'EDIT' or tgt is None:
            # ⚠⚠ **서재만 열면 조정이 안 뜬다** (2026-08-31 사용자 「콤보에서
            #   차례조정 → 읽을차례 체크 → **어떻게 조정하는가?**」 — 재현했다).
            #   ▲▼ 는 **정렬이 「읽을 차례」일 때만** 나오는데 서재는 직전 정렬
            #   (분류)로 열렸다. 「조정하러 간다」고 해 놓고 조정할 수 없는
            #   상태로 데려간 것이다. ⇒ **정렬까지 맞춰서** 연다.
            self._show_shelf(self._order_kind())
            self._shelf_sort_order()
            return
        self._order_open(tgt)

    def _finished_books(self):
        """다 읽은 책 → set (전편 읽음). 손으로 표시한 것은 `read_order` 가 본다."""
        out = set()
        try:
            import db_read_state
            with appdb.connect(self.db_path) as c:
                for bid, tot in c.execute(
                        "SELECT book_id, COUNT(*) FROM sys_book_unit "
                        " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                        " GROUP BY book_id"):
                    n = c.execute(
                        "SELECT COUNT(*) FROM userdb.user_book_read "
                        " WHERE book_id=?", (bid,)).fetchone()[0]
                    if tot and n >= tot:
                        out.add(bid)
        except Exception as e:
            print('[finished] %s' % e)
        return out

    def _finished_units(self):
        """다 읽은 **설교 편** → set."""
        try:
            import db_read_state
            with appdb.connect(self.db_path) as c:
                return set(db_read_state.read_ids(c, kind='SERMON'))
        except Exception as e:
            print('[finished units] %s' % e)
            return set()

    def _order_open(self, book_id):
        """읽을 차례 콤보에서 선택한 결과 (2026-08-31 사용자 지시).

        ★ **받았으면 본문으로, 안 받았으면 소개문 + [↓ 받기]** — 서재 카드와
          일부러 다르다. 카드는 **아직 고르는 중**이라 소개문이 맞고, 차례는
          **이미 고른 것**이라 바로 읽는 것이 맞다.
        """
        if self._order_kind() == 'SERMON':
            self._show_shelf(None)
            self.jump_to_unit(book_id)       # 설교는 **편**이 담긴다
            return
        if self._book_has_text(book_id):
            self._open_book_first(book_id)
        else:
            self._show_shelf(None)
            self._show_book_info(book_id)

    # ── 핵심구절 한 줄 (2026-08-31 `0.txt` 1번 5)) ────────────────────────────
    #
    # ★★★ 사용자 최선안 — 「본문에 "핵심구절 수5:12 그 땅의 소산을 …" 이렇게
    #   하나로 통합하고, 구절약명을 클릭하면 "장비교" 버튼 누른 것과 같이
    #   역본흐름 탭으로 이동」.
    # ⚠⚠ **본문에 통합하는 것만으로는 12%에서만 성립한다** — 실측: `key_verse_ref`
    #   가 있는 5,959편 중 **본문이 스스로 그 구절을 말하는 책은 Morning and
    #   Evening 732편뿐**이다(표본 40/40). 스펄전 설교 3,482편은 2/40, 마이어
    #   1,353편은 0/40. 나머지 5,227편에서 우리 줄을 지우면 **구절이 통째로
    #   사라진다.** ⇒ **본문이 이미 말하면 안 그리고, 아니면 우리가 한 줄 그린다.**
    #   어느 쪽이든 화면에 **하나**다.
    _KV_RE = re.compile(r'(\d+)\s*[:：]\s*(\d+)')

    def _body_says_verse(self, u: dict) -> bool:
        """본문 첫머리가 그 구절을 스스로 말하나 (ME 류).

        ⚠⚠ **화면(`_body_txt`)을 읽으면 안 된다** — 머리 블록을 그린 **뒤**에
          다시 물으면 방금 우리가 그린 `▸ 핵심 말씀 마 1:21` 을 저자의 본문으로
          착각한다(실측 — 표본 25편 중 21편이 그렇게 뒤집혔다).
          **자기가 그린 것을 재료로 삼지 말 것.** 그래서 원본 글자를 본다.
        """
        m = self._KV_RE.search(u.get('verse_ref') or '')
        if not m:
            return False
        head = (getattr(self, '_body_src', '') or '')[:400]
        return bool(re.search(r'%s\s*[:：]\s*%s' % (m.group(1), m.group(2)),
                              head))

    @staticmethod
    def _pack_repeats(pack, kv):
        """그 플랜 묶음이 편의 핵심 구절을 되풀이하나(장:절이 같은가)."""
        if not kv:
            return False
        m = ReadingView._KV_RE.search(pack[1] or '')
        return bool(m and m.group(1) == kv.group(1)
                    and m.group(2) == kv.group(2))

    def _key_verse_label(self, u: dict):
        """핵심 구절의 약명 — 화면 언어로.

        ⚠⚠ **`start_vid` 로 지으면 안 된다** — 실측 5,611편 중 **1,136편(20%)**
          에서 `key_verse_ref` 와 `start_vid` 가 다르다. 마이어는 `start_vid~
          end_vid` 가 **장 전체 범위**(마1:1~1:25)이고 핵심 구절은 마1:21 이다.
          범위로 적으면 「핵심구절 마1:1」이라는 **틀린 말**이 된다.
        ⇒ `key_verse_ref` 를 화면 언어로 옮긴다(`_localize_ref`). 못 옮기면
          저장된 글자 그대로 — 없는 것보다 낫다.
        """
        ref = (u.get('verse_ref') or '').strip()
        if not ref:
            # ⚠ 약명 칸이 비었으면 **번호로 짓는다** — 그 편에도 구절은 있다.
            vid = u.get('start_vid')
            if not vid:
                return ''
            try:
                with appdb.connect(self.db_path) as conn:
                    return self._unit_ref_label(conn, vid, u.get('end_vid'),
                                                self.lang_getter().upper())
            except Exception:
                return ''
        try:
            with appdb.connect(self.db_path) as conn:
                return self._localize_ref(conn, ref,
                                          self.lang_getter().upper()) or ref
        except Exception:
            return ref

    def _key_verse_vid(self, u: dict):
        """핵심 구절의 `verse_id`. 못 알아보면 `start_vid` 로 물러난다.

        ⚠⚠ **책 이름을 파싱하려 들면 안 된다** — `verse_ref` 는 화면 언어의
          약명(`마1:21`)일 수도, 영어 정식명(`Matthew 1:21`)일 수도 있다.
          영어만 읽던 첫 판은 한국어에서 늘 실패해 `start_vid` 로 떨어졌고,
          그 결과 **「마1:21」이라 적고 마1:1 본문을 붙였다**(실측으로 잡았다).
        ⇒ **책은 `start_vid` 가 안다**(같은 편이니 같은 책이다). 그러므로
          약명에서는 **장:절만** 읽으면 된다 — 언어와 무관하다.
        ⚠ 범위가 장 전체인 책(마이어)에서 `start_vid` 를 그대로 쓰면 **1절
          본문**을 핵심 구절이라고 보이게 된다 — 실측 20%가 그 상태다.
        """
        sv = u.get('start_vid')
        m = self._KV_RE.search(u.get('verse_ref') or '')
        if m and sv:
            try:
                with appdb.connect(self.db_path) as conn:
                    r = conn.execute(
                        "SELECT b.verse_id FROM bible_index a "
                        "  JOIN bible_index b ON b.bcode = a.bcode "
                        " WHERE a.verse_id=? AND b.chapter=? AND b.verse=?",
                        (sv, int(m.group(1)), int(m.group(2)))).fetchone()
                if r:
                    return r[0]
            except Exception as e:
                print('[key verse vid] %s' % e)
        return sv

    def _key_verse_text(self, u: dict, limit=90):
        """그 구절 본문 — **지금 선택한 역본으로**(`version_getter`).

        ★ 사용자 지시 「성경버전 설정값에 따라 표시되어야 한다」 — 역본을 바꾸면
          이 글도 따라온다(`_refresh_body` 가 다시 그린다).
        ⚠ `limit=0` 이면 안 자른다 — 본문 안에 붙일 때는 온전한 절이 맞다.
        ⚠ 고른 역본에 그 절이 없으면(신약만 있는 역본 등) **다른 역본으로
          말없이 갈아타지 않는다** — 빈 값을 돌려 아무것도 안 붙인다.
        """
        vid = self._key_verse_vid(u)
        if not vid:
            return ''
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
                _s = _vt.resolve(conn, vid, self.version_getter(),
                                 self.lang_getter())['text']
        except Exception:
            return ''
        t = ' '.join((_s or '').split())
        if not limit or len(t) <= limit:
            return t
        return t[:limit] + '…'

    def _update_meta(self, u: dict):
        # ⚠ 편을 보는 중에는 [읽기 시작]이 뜻이 없다 — 이미 읽고 있다.
        # 자리는 지키고 상태만 바꾼다(감추지 않는다 — 위 주석)
        self._book_open_bid = u.get('book_id') or getattr(self, '_book_open_bid', None)
        self._sync_book_open_btn()
        self._meta_title.config(text=u['label'] or u['book_title'])
        parts = [u['book_title']]
        if u['author']:
            parts.append(u['author'])
        if u['pub_year']:
            parts.append(str(u['pub_year']))
        # ★★ **구절 번호는 이 줄을 떠났다** (2026-08-31 `0.txt` 2번 사용자
        #   「연도 오른쪽의 구절 번호 => 제거」). 1단은 **책의 정보**만 담는다.
        #   구절은 4단(본문 머리)의 연결 구절 줄과 3단의 약명 단추가 말한다 —
        #   같은 것을 세 자리에서 되풀이하고 있었다.
        #   ⚠ 「엮은이가 고른 구절」 표시는 4단 머리로 넘어갔다(§78 근거 밝히기).
        self._meta_sub.config(text='  ·  '.join(parts))

    # ── 판본/언어 선택 (전역) ──────────────────────────────────────────────────

    def _on_global_variant_change(self, *_):
        self._sync_vars()
        if self._current_unit:
            self._refresh_body()
        elif self._current_doctrine_unit:
            self._show_doctrine_unit(self._current_doctrine_unit)

    def _update_variant_selector(self):
        """표시 언어 목록은 **고정이다** (2026-08-14 설계 확정).

        ⚠ 유닛마다 「있는 판」을 물어 목록을 갈아 끼우면 ① 화면이 느려지고
          ② 유닛을 옮길 때마다 콤보가 들쭉날쭉해 무엇을 고를 수 있는지 알 수 없다.
          없는 판은 **영어로 폴백**해서 보인다.
        """
        self._sync_vars()

    def _sync_vars(self):
        """선택한 것을 옛 이름(`_g_variant_var`·`_g_lang_var`)에도 적어 둔다.

        ⚠ 검색 정렬(`:1083`)과 본문 고르기가 아직 이 두 값을 읽는다 —
          단일 소스는 콤보이고, 이 둘은 그 사본이다.
        """
        cur = self._lang.current() or ('ORIGINAL', 'EN')
        self._g_variant_var.set(cur[0] or 'ORIGINAL')
        self._g_lang_var.set((cur[1] or 'EN').upper())

    def _refresh_body(self):
        variant = self._g_variant_var.get()
        lang    = self._g_lang_var.get().upper()

        # ★ 콤보가 고른 **바로 그 짝**을 꺼내고, 없으면 **영어로 폴백**한다
        #   (2026-08-14 설계 확정 — 폴백은 언제나 영어).
        text = self._texts.get((variant, lang))
        if text is None:
            for (v, lg), body in self._texts.items():
                if v == variant and (lg or 'EN').upper() == lang:
                    text = body
                    break
        if not text:
            for want in (('ORIGINAL', 'EN'), ('MODERN_EN', 'EN'),
                         ('TRANSLATED', 'EN'), ('SUMMARY', 'EN')):
                text = self._texts.get(want)
                if text:
                    break
        # ⚠⚠ **원문이 영어가 아닌 책은 여기서 빈 화면이 됐다** (2026-08-30 —
        #   벨직(佛)·도르트(羅)를 넣고 실측). 위 사슬이 `ORIGINAL/EN` 과
        #   `MODERN_EN/EN` 만 봐서, 영역이 `TRANSLATED/EN` 으로 들어 있으면
        #   못 찾고 「본문 텍스트가 없습니다」가 떴다 — 오류도 안 났다.
        #   ⇒ 영어를 변형 불문으로 넓히고, **그래도 없으면 있는 것을 보인다.**
        #   원문(라틴·프랑스)이라도 보이는 편이 빈 화면보다 낫다(§0-1).
        if not text and self._texts:
            text = next((v for v in self._texts.values() if v), '')
        text = text or ''

        # ⚠ **폴백 표식을 먼저 비운다** — 남겨 두면 받은 책에도 단추가 뜬다
        self._fb_get = None
        if not text:
            # ★★★ **안 받은 책이면 그렇게 말한다**(2026-09-04 ⑦ 폴백).
            #   코어팩이 껍데기(제목·저자·소개)를 담으므로 본문이 없어도
            #   **무슨 책인지는 안다** — 빈 화면 대신 읽을 것과 받는 길을 준다.
            #   ⚠ 본문 자리가 Text 위젯이라 상자를 못 그린다 ⇒ 글로 말한다.
            text = ''
            try:
                import pack_fallback as _FB
                # ⚠ 폴백은 **책 코드**로 판정한다(`book_id` 가 아니라) —
                #   껍데기 조회가 `sys_book_asset.book_code` 를 쓴다.
                _bid = self._cur_book_id()
                if _bid:
                    with appdb.connect(self.db_path) as _c:
                        _r = _c.execute(
                            "SELECT book_code FROM sys_book_asset"
                            " WHERE book_id=?", (_bid,)).fetchone()
                        if _r:
                            _lg = (self._g_lang_var.get() or None)
                            # ★★ **받는 길을 그 자리에 낸다**(2026-09-04 ⑪) —
                            #   글은 여기서, 단추는 본문을 다 그린 뒤에 심는다
                            #   (본문 흐름·각주 처리를 안 건드린다).
                            #   ⚠ 안내문(`where`)을 비운다 — 단추가 그 몫을
                            #     맡으므로 「설정에서 받으세요」가 겹친다.
                            text = _FB.as_text(
                                _c, 'BOOK', _r[0], _lg, t=i18n.t, where='')
                            self._fb_get = ('BOOK', _r[0], _lg)
            except Exception:
                text = ''
            if not text:
                text = i18n.t('PR_NOTEXT', '(본문 텍스트가 없습니다.)')

        # 저자의 본문 원본 — `_body_says_verse` 가 이것을 본다(화면이 아니다)
        self._body_src = text
        text, _spots, _vlines = self._annotate_footnotes(text)

        # 폰트는 **지원/설정 ▸ 폰트**(`theme_font` 「book」 구역)가 정한다.
        # ⚠ 채울 때마다 다시 불러야 한다 — 여기서 옛 콤보값을 씌우고 있었다.
        try:
            import theme_font
            theme_font.apply(self._body_txt, self.db_path, 'book')
        except Exception:
            pass
        self._body_txt.config(state='normal')
        self._body_txt.delete('1.0', 'end')
        self._body_txt.insert('1.0', text)
        self._body_txt.config(state='disabled')
        self._body_txt.yview_moveto(0)
        self._hl_reload()
        # ⚠ 밑줄 메모(`_hl_reload`) **뒤에** 건다 — 먼저 걸면 그쪽이 태그를
        #   다시 훑으며 우리 색을 덮는다.
        self._tag_footnotes(_spots, _vlines)
        # ★★ **도서묵상 머리**(묵상 포커스·연결 구절) — 2026-08-24.
        # ⚠ **각주 태그를 건 뒤**에 넣는다 — 앞에 넣으면 `_tag_footnotes` 의
        #   줄 번호가 머리 높이만큼 밀린다(밑줄 메모는 줄 수를 안 바꾸므로 무관).
        if self._current_unit:
            # ★★ **묵상 재료는 늘 그린다** (2026-08-31 — 갈래 폐기).
            #   있으면 나오고 없으면 안 나온다. 고를 것이 없다.
            self._render_plan_head(self._current_unit.get('unit_id'))
            # ★ 증거 구절은 **본문 끝**에 붙인다 — 위에 넣으면 `_tag_footnotes`
            #   줄 번호가 밀리고, 인쇄본에서도 이것은 아래쪽 자리다.
            self._render_proof_refs(self._current_unit.get('unit_id'))
        # ★ 본문 안 약명은 **맨 마지막에** — 머리·증거구절을 넣은 뒤라야
        #   글자 자리가 최종이다(앞서 걸면 태그가 밀린다).
        self._tag_body_refs()
        # ★★★ **받는 길이 그 자리에 있다**(2026-09-04 ⑪) — 안 받은 책이면
        #   본문 끝에 [지금 받기]. 설정 화면까지 찾아가게 하지 않는다.
        #   ⚠ **맨 마지막에** 심는다 — 위젯이 한 글자를 차지하므로 앞서 심으면
        #     각주·약명 태그의 줄 번호가 밀린다.
        if getattr(self, '_fb_get', None):
            try:
                import pack_fallback as _FB
                import ui_theme as _UT
                _FB.attach_get_button(
                    self._body_txt, self._fb_get[0], self._fb_get[1],
                    self._fb_get[2], on_get=self._on_fb_get,
                    t=i18n.t, C=_UT.C)
            except Exception:
                pass
        self._sync_band()

    def _on_fb_get(self, kind, key, lang):
        """폴백의 [지금 받기] — **받는 문은 `pack_status.fetch_asset` 하나**.

        ⚠ 받은 뒤 **그 화면을 다시 그린다** — 안 그리면 「받았는데 그대로」다.
        ⚠ **왜 안 되는지 말한다**(§0-1) — 조용히 실패하지 않는다.
        """
        from tkinter import messagebox
        import pack_status as _PS
        if not messagebox.askyesno(
                i18n.t('SET_DL_GET', '지금 받기'),
                i18n.t('DL_GET_ASK',
                       '「%s」 를 지금 받습니다.\n\n'
                       '받는 동안 앱을 켜 두세요. 인터넷을 씁니다.')
                % str(key)[:50]):
            return
        r = _PS.fetch_asset(kind, key, lang, self.db_path)
        if not r['ok']:
            messagebox.showinfo(
                i18n.t('SET_DL_GET', '지금 받기'),
                i18n.t('DL_NOT_ON_SERVER',
                       '아직 서버에 올라오지 않은 자료입니다. '
                       '나중에 다시 눌러 주세요.')
                if r['why'] == 'NOT_ON_SERVER'
                else i18n.t('DL_GET_FAIL', '받지 못했습니다: %s') % r['why'])
            return
        msg = i18n.t('DL_GET_DONE_N', '「%s」 를 받았습니다. (%s개)')             % (str(key)[:40], format(r['rows'], ','))
        # ⚠ **바꿔 받았으면 그렇게 말한다** — 조용히 다른 언어를 넣지 않는다
        if r.get('sub'):
            msg += chr(10) * 2 + i18n.t(
                'DL_GET_SUBLANG',
                '요청하신 언어는 아직 없어 %s 자료를 받았습니다.') % r.get('lang')
        messagebox.showinfo(i18n.t('SET_DL_GET', '지금 받기'), msg)
        # ★ 받았으면 **다시 그린다** — 그 자리에서 본문이 나타난다
        try:
            u = self._current_unit
            if u:
                self._show_unit(u)
        except Exception:
            pass

    # ── 증거 구절 (`sys_book_unit.body_ref`) ───────────────────────────────────
    # ★★ 신앙고백은 조항마다 **성경 증거 구절**을 달아 둔다 — 그것이 문서의
    #   일부다(웨스트민스터 1,189 · 벨직 316). 적재할 때 담아 두었는데 화면이
    #   보이지 않아 아무도 읽을 수 없었다(2026-08-30).
    # ⚠ **판(版) 이문(異文) 주와 섞지 않는다** — `[Am. ed. for.]` 처럼 미국판이
    #   달리 읽는 자리를 적어 둔 줄이 46개 섞여 있다(실측 1,510 중). 증거 구절
    #   1,464 와 성격이 다르므로 **갈래를 갈라 제목을 달리 붙인다.**
    # ⚠ **로마 숫자로 갈라선 안 된다** — 요이·유다서처럼 장이 하나인 책은
    #   `2 Jean 10` 이라 로마 숫자가 없어 주(註)로 잘못 갈렸다(실측).
    # ★ 잣대는 **글자**다 — 주는 `[Am. ed. …]` 처럼 대괄호로 열거나, 인용부호로
    #   열거나, `—Ed.` 로 닫거나, **소문자 낱말이 다섯 이상**이다(증거 구절은
    #   책 약명과 숫자뿐이라 거의 0). 실측 1,510줄 → 증거 1,476 · 주 34, 오분류 1.
    # ⚠ 로마 숫자(`viii`·`lxvi`)를 낱말로 세지 않는다.
    _REF_NUM = re.compile(r'^\s*\d{1,5}\s+')          # CCEL 각주 번호 — 닻을 잃었다
    _REF_NOTE = re.compile(r"^\[|^[‘']|—Ed\.")
    _REF_WORD = re.compile(r'\b(?![ivxlcdm]+\b)[a-z]{4,}\b')

    def _proof_lines(self, unit_id):
        """→ (증거 구절, 원문 주). 없으면 빈 목록."""
        if not unit_id:
            return [], []
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT body_ref FROM sys_book_unit WHERE unit_id=?",
                                 (unit_id,)).fetchone()
        except Exception:
            return [], []
        proofs, notes = [], []
        for s in (r[0] if r and r[0] else '').split('\n'):
            t = self._REF_NUM.sub('', s).strip()
            if not t:
                continue
            note = (bool(self._REF_NOTE.search(t))
                    or len(self._REF_WORD.findall(t)) >= 5)
            (notes if note else proofs).append(t)
        return proofs, notes

    def _render_proof_refs(self, unit_id):
        """본문 끝에 증거 구절 블록. **없으면 아무것도 안 그린다**(빈 서랍 금지)."""
        proofs, notes = self._proof_lines(unit_id)
        if not proofs and not notes:
            return
        t = self._body_txt
        was = str(t.cget('state'))
        t.config(state='normal')
        # ⚠ **출처 줄(`— 저자, "제목" …`)보다 앞에** 넣는다 — 뒤에 붙이면 출처가
        #   본문 한가운데 낀 것처럼 읽힌다(처음에 그렇게 나왔다).
        at = t.search(r'^—\s', 'end', '1.0', regexp=True, backwards=True)
        at = ('%s linestart' % at) if at else 'end'
        # ⚠ 한 자리에 여러 번 넣으면 **차례가 뒤집힌다**(먼저 넣은 것이 밀려
        #   내려간다). 글과 태그를 번갈아 **한 번에** 넣는다.
        args = []
        for head, lines in ((i18n.t('RV_PROOFS', '증거 구절'), proofs),
                            (i18n.t('RV_SRCNOTES', '원문의 주'), notes)):
            if not lines:
                continue
            args += [head + '\n', 'prfhead', '\n'.join(lines) + '\n', 'prfline']
        if args:
            t.insert(at, *args)
        t.config(state=was)
        # ⚠ 색은 **그릴 때마다 역할로** 다시 준다 — Text 태그는 paint 가 못 본다(§0).
        for tag, role, dflt in (('prfhead', 'fg_title', '#1A5276'),
                                ('prfline', 'fg_dim', '#7F8C8D')):
            try:
                import ui_theme
                col = ui_theme.C(role) or dflt
            except Exception:
                col = dflt
            t.tag_config(tag, foreground=col,
                         spacing1=(8 if tag == 'prfhead' else 0))

    # ── 검색 ───────────────────────────────────────────────────────────────────

    def _do_search(self):
        # ⚠ 검색창은 화면에서 뗐다(2026-08-16) — 변수가 없을 수 있다.
        #   전체 검색창(§7)이 생기면 이 함수를 그대로 쓰므로 **지우지 않았다.**
        if not hasattr(self, '_search_var'):
            return
        keyword = self._search_var.get().strip().lower()
        stype = self._search_type.get()
        _TAG = i18n.t('RV_SEARCH_TAG', '태그'); _TITLE = i18n.t('RV_SEARCH_TITLE', '제목')
        if not keyword:
            self._clear_search()
            return

        active = self._left_nb.index('current')
        if active in (2, 3):   # 교리/자료, 즐겨찾기는 검색 대상 아님
            return
        try:
            import usage_stats; usage_stats.bump('search_run')
        except Exception:
            pass

        if stype == _TAG:
            # ★★ 통합 표 전환 (2026-08-27 · C 단계 — 연결지도 §8 「살아 있는
            #   독자 1」의 그 자리). 예전에는 옛 표 `sys_book_unit_tag` 의
            #   `tag_value` **코드 글자**(TOP_30 따위)를 LIKE 로 뒤졌다 —
            #   한국어 태그 이름으로는 아무것도 안 걸렸다. 이제 태그 **이름**
            #   (덮개 적용·원어 검색이름 포함 — tag_picker.all_tags)으로 찾고,
            #   유닛은 통합 표(TAG_BUNT·UTAG_BUNT — 내 것 포함)로 모은다.
            #   사용자가 가린(HIDE) sys 연결은 뺀다. 이로써 옛 표는 독자 0.
            matching_ids = set()
            try:
                import tag_picker as TP
                _lg = (self.lang_getter() or 'KO').upper()
                matched = [(s, t) for s, t, disp, _cat, full, *_m
                           in TP.all_tags(self.db_path, _lg)
                           if keyword in (disp or '').lower()
                           or keyword in (full or '').lower()]
                with appdb.connect(self.db_path) as conn:
                    for src, tid in matched:
                        lt = ('TAG_BUNT' if src == 'SYS' else 'UTAG_BUNT')
                        if src == 'SYS':
                            matching_ids.update(r[0] for r in conn.execute(
                                "SELECT target_id FROM sys_link_asset "
                                "WHERE link_type='TAG_BUNT' AND clicked_id=? "
                                "AND COALESCE(record_status,'LIVE')='LIVE'",
                                (tid,)))
                        for uid, st in conn.execute(
                                'SELECT target_id, '
                                "COALESCE(record_status,'LIVE') "
                                'FROM userdb.user_link_asset '
                                'WHERE link_type=? AND clicked_id=?',
                                (lt, tid)):
                            if st == 'HIDE':
                                matching_ids.discard(uid)   # 가림이 이긴다
                            else:
                                matching_ids.add(uid)       # 내가 더한 것
                    # ★★★ 2026-09-01 통합 수술 — 배포 태그는 **용어로 흡수**됐다
                    #   (`db_tag_unify` · 복음23 · 그리스도9 · 성령6 등 도서 편
                    #   라벨이 이제 `BUNT_ENTI` 로 산다). 태그 표만 뒤지면 그
                    #   라벨들이 검색에서 통째로 사라진다 — **용어도 함께**
                    #   찾는다. ⚠ SQL 은 `link_picker` 몫(래칫).
                    import link_picker as _lpk
                    matching_ids.update(
                        _lpk.entity_book_units(conn, keyword))
            except Exception as e:
                print(f'[reading tag search] {e}')

        if active == 0:
            self._book_tv.delete(*self._book_tv.get_children())
            shown = 0
            for u in self._book_units:
                if stype == _TAG:
                    hit = u['unit_id'] in matching_ids
                else:
                    hit = (keyword in u['label'].lower() if stype == _TITLE
                           else keyword in u['author'].lower())
                if hit:
                    self._book_tv.insert(
                        '', 'end', iid=f'U_{u["unit_id"]}',
                        text=f'  {u["label"]}', tags=('unit',))
                    shown += 1
            if shown == 0:
                self._book_tv.insert('', 'end', iid='NO_RESULTS',
                                     text=i18n.t('PR_NORESULT','  (검색 결과가 없습니다.)'),
                                     tags=('no_result',))
            self._count_lbl.config(text=f'{shown}건 검색됨')
        else:
            self._sermon_tv.delete(*self._sermon_tv.get_children())
            shown = 0
            for u in self._sermon_units:
                if stype == _TAG:
                    hit = u['unit_id'] in matching_ids
                else:
                    hit = (keyword in u['label'].lower() if stype == _TITLE
                           else keyword in u['author'].lower())
                if hit:
                    self._sermon_tv.insert(
                        '', 'end', iid=f'SU_{u["unit_id"]}',
                        text=f'  {u["label"]}', tags=('unit',))
                    shown += 1
            if shown == 0:
                self._sermon_tv.insert('', 'end', iid='NO_RESULTS',
                                       text=i18n.t('PR_NORESULT','  (검색 결과가 없습니다.)'),
                                       tags=('no_result',))
            self._count_lbl.config(text=f'{shown}건 검색됨')

    def _clear_search(self):
        self._search_var.set('')
        active = self._left_nb.index('current')
        if active == 0:
            self._load_book_tree()
        elif active == 1:
            self._load_sermon_tree()
            self._count_lbl.config(text=f'총 {len(self._sermon_units)}편')

    def _on_subtab_change(self, _=None):
        active = self._left_nb.index('current')
        if active == 0:
            self._count_lbl.config(text=f'총 {len(self._book_units)}편')
        elif active == 1:
            self._count_lbl.config(text=f'총 {len(self._sermon_units)}편')
        elif active == 2:
            self._count_lbl.config(text=f'총 {len(self._doctrine_units)}항목')
        # [Phase 2-C'] ★ 즐겨찾기 서브탭 제거됨 — 4번째 탭 분기 삭제

    # ── 공개 API ───────────────────────────────────────────────────────────────

    def jump_to_unit(self, unit_id: int):
        """외부에서 특정 유닛으로 직접 이동.

        미래 "구절 클릭 → 참고자료에 관련 설교 표시 → 클릭 시 이 탭 오픈"
        흐름에서 호출된다.
        """
        # ⚠⚠ **트리에 편 줄이 없다**(2026-08-31 — 「분류 → 책」 두 층으로 줄였다).
        #   그전에는 트리 줄을 고르는 것이 곧 편을 여는 길이었다. 이제 그 줄이
        #   없으므로 **직접 연다** — 트리는 책만 드러내 준다.
        #   ⚠ 트리 줄을 찾아 고르는 옛 길을 그냥 두면 `Item U_1 not found` 로
        #     죽고 **아무것도 안 열린다**(실측으로 잡았다).
        u = next((x for x in self._book_units if x['unit_id'] == unit_id), None)
        if u:
            self._left_nb.select(0)
            self._reveal_book(self._book_tv, u.get('book_id'))
            self._show_unit(u)
            return
        u = next((x for x in self._sermon_units if x['unit_id'] == unit_id), None)
        if u:
            self._left_nb.select(1)
            self._reveal_book(self._sermon_tv, u.get('book_id'))
            self._show_unit(u)

    def _reveal_book(self, tv, book_id):
        """트리에서 **그 책 줄**을 드러내 선택한다(편 줄은 없다)."""
        if not book_id:
            return
        # ★★★ 317차 — docs/1.txt 3-5 「페이지를 넘기다 보면 도서소개문이 중간에 표시된다」.
        #   ⚠⚠⚠ 옛 가드는 **시간**(60ms 뒤 `_syncing` 해제)이었다. 편 하나 그리기가
        #     실측 0.2~0.8초라 그동안 [다음]을 또 누르면 [클릭, 60ms 타이머] 가 큐에 쌓이고
        #     두 번째 jump 의 선택 이벤트가 **타이머 뒤에** 들어가 가드가 먼저 풀린다 →
        #     그 이벤트가 책 줄을 보고 소개문을 띄웠다(경합 재현 · 매번 뜸).
        #   ⇒ ① **이미 골라져 있으면 고르지 않는다**(같은 줄을 다시 골라도 이벤트가 난다 · Tk 8.6 실측)
        #     ② 실제로 고를 때만 **그 이벤트 하나를 소모하는 표식**(`_skip_sel`)을 남긴다 — 시간이 아니다.
        #   ⚠ 설교 나무의 줄 이름은 **`SBK_`** 다 — 옛 코드는 `BK_` 를 써서 설교집에서는 드러내기가
        #     통째로 아무 일도 안 했다(그래서 이 경합도 숨어 있었다).
        iid = ('SBK_%d' if tv is getattr(self, '_sermon_tv', None) else 'BK_%d') % int(book_id)
        try:
            if tv.exists(iid):
                node = tv.parent(iid)
                while node:
                    tv.item(node, open=True)
                    node = tv.parent(node)
                tv.see(iid)
                if tuple(tv.selection()) != (iid,):
                    self._skip_sel = iid
                    tv.selection_set(iid)
        except Exception as e:
            print('[reveal book] %s' % e)

    def jump_to_doctrine_unit(self, ref_unit_id: int):
        """P2 참고자료 패널의 '교리 탭으로 이동' 버튼에서 호출.
        교리/자료 탭(index 2)을 열고 해당 항목을 선택·표시한다.
        """
        u = next((x for x in self._doctrine_units
                  if x['unit_id'] == ref_unit_id), None)
        if u:
            self._left_nb.select(2)
            self.after(50, lambda: self._show_doctrine_unit(u))

