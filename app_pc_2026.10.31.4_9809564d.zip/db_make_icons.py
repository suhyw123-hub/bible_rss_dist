# -*- coding: utf-8 -*-
"""db_make_icons.py — **앱 아이콘 셋을 그린다** (2026-09-05 신설 · 영구)

★★★ 사용자 지시(0.txt 3번) 그대로:
  1) **사용자 · 바탕화면** — 성경책 모양. **와인색 커버 · 황금빛 종이 ·
     대문자 H**
  2) **사용자 · 트레이** — 위 아이콘을 기초로(작은 크기에서도 읽히게 단순화)
  3) **관리자** — **X 자로 놓인 칼 두 자루 앞에 방패**, 방패는 **와인색**,
     그 위에 **금색 H**

★★ **그림을 그려서 만든다 — 남의 이미지를 받아 오지 않는다.** 사용자가 든
  링크는 **모양의 예시**이고, 그 파일 자체는 저작권이 있다(§0-1b 규칙 ⓪).
  같은 구도를 우리 손으로 그리면 권리 문제가 없다.

⚠ **`.ico` 는 여러 크기를 한 파일에 담는다** — 16px 은 작업 표시줄, 256px 은
  바탕화면이다. 한 크기만 넣으면 윈도우가 늘리거나 줄여 뭉개진다.
⚠ **작은 크기는 따로 그린다** — 256px 그림을 16px 로 줄이면 H 가 뭉개진다.
  트레이용은 획을 굵게 하고 장식을 걷는다(그래서 2)가 따로 있다).

  `--make`(만든다) · `--selftest`(의무)

★★★ 2026-10-09 바꿈(사용자 「트레이 아이콘 선명도가 매우 낮다 · 와인색 자체가 어둡고
  상하 높이가 작아 보인다 · 선명한 색상 · 방패 + 칼 · 몇 가지 시안」 → 시안 6 중
  「**A, B를 하나씩 만들어라. 관리자용, 사용자용**」):
  · **관리자 = A** 밝은 하늘색 방패 + 흰 H (`draw_admin_a`)
  · **사용자 = B** 밝은 하늘색 방패 + 금빛 손잡이 세로 칼 — 십자가로도 읽힌다
    (`draw_user_b` · 앱 창·작업표시줄·트레이 모두)
  · 방패가 **높이를 꽉** 채운다(옛 책 아이콘은 위아래 여백이 커 작아 보였다).
  · 작은 크기는 **방패만 부드럽게**(4배로 그려 줄임) 하고 글자·칼은 그 크기의
    픽셀에 맞춰 바로 그린다 — 번지지 않게.
  · 크기에 **20·40px** 를 넣었다 — 화면 배율 125%·250% 의 트레이 칸이다.
  ⚠ 옛 그림(`draw_book`·`draw_shield`)은 남긴다 — 되돌릴 자리.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from PIL import Image, ImageDraw
    _PIL = True
except Exception:                                           # pragma: no cover
    _PIL = False

# ★ 색 — 사용자가 지정한 두 가지. **여기서만 정한다.**
WINE = (114, 22, 38)          # 와인색 커버·방패
WINE_D = (78, 14, 26)         # 그늘
GOLD = (214, 172, 78)         # 황금빛 종이
# ★★ **H 와 D 는 한눈에 갈려야 한다**(2026-09-05 사용자 「HD의 색이 잘
#   구분되지 않는다」) — 밝은 금과 어두운 구리빛으로 **벌린다**.
GOLD_L = (250, 232, 178)      # 밝은 금 — 앞에 오는 H
GOLD_D = (168, 118, 34)       # 진한 구리금 — 뒤에 가는 D
STEEL = (198, 204, 212)       # 칼날(밝은 면)
STEEL_M = (162, 170, 180)     # 칼날(중간)
STEEL_D = (108, 116, 126)     # 칼날(그늘)
# ★ 방패 두 겹 — **바깥은 밝은 와인 · 안쪽은 진한 와인**(2026-09-05 사용자 지시)
WINE_L = (150, 46, 66)        # 바깥 테두리
WINE_IN = (86, 16, 30)        # 안쪽 판
SAGE = (138, 154, 91)         # 쑥색 — H
# ★ **밝은 황금** — DABAR 전용(2026-09-05 사용자 「DABAR는 밝은 황금색으로」).
#   ⚠ `GOLD_L` 은 크림에 가까워 금으로 안 읽힌다.
GOLD_BR = (255, 208, 84)
LEATHER = (118, 78, 44)       # 가죽 손잡이
LEATHER_D = (78, 50, 28)
HILT = (122, 88, 52)          # 칼자루(그립)
HILT_D = (78, 54, 30)         # 가드·폼멜

ICON_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')
SIZES = (256, 128, 64, 48, 40, 32, 24, 20, 16)
# ★ 새 아이콘 색(2026-10-09) — **여기서만 정한다**
SKY = (0x1E, 0x90, 0xFF)       # 밝은 하늘색 방패
SKY_D = (0x0B, 0x5E, 0xC9)     # 방패 테두리
WHITE = (0xFF, 0xFF, 0xFF)
CROSS_HILT = (0xFF, 0xD5, 0x4F)  # 칼 손잡이·가드(금빛)


def _H(d, box, color, w):
    """대문자 H — **획을 직접 그린다**(글꼴에 기대면 PC 마다 달라진다)."""
    x0, y0, x1, y1 = box
    d.rectangle([x0, y0, x0 + w, y1], fill=color)              # 왼 기둥
    d.rectangle([x1 - w, y0, x1, y1], fill=color)              # 오른 기둥
    my = (y0 + y1) // 2
    d.rectangle([x0, my - w // 2, x1, my + w // 2], fill=color)  # 가로


def _D(d, box, color, w):
    """대문자 D — 왼쪽 세로 기둥 + 오른쪽 반원.

    ⚠ 채운 반원에서 속을 파내면 **뒤에 있는 H 까지 지운다** — 겹쳐 놓을 수
      없다. 그래서 **두꺼운 선**(`arc`)으로 그린다.
    """
    x0, y0, x1, y1 = box
    d.rectangle([x0, y0, x0 + w, y1], fill=color)              # 세로 기둥
    r = (y1 - y0) // 2
    cx = x1 - r
    # 위·아래 가로 짧은 획 + 오른쪽 반원
    d.rectangle([x0, y0, cx, y0 + w], fill=color)
    d.rectangle([x0, y1 - w, cx, y1], fill=color)
    d.arc([cx - r, y0, cx + r, y1], -90, 90, fill=color, width=w)


def _HD(d, S, box, c_h, c_d, wh, wd):
    """**H 와 D 를 살짝 겹쳐** 놓는다 (2026-09-05 사용자 지시 — 「H자와 D자가
    살짝 겹쳐진 형태」·「**H의 오른쪽 아래와 D의 왼쪽 위가 겹치도록**」).

    ⚠ **D 를 나중에 그린다** — 겹친 자리에서 D 가 위로 온다. 색을 살짝
      달리해야 겹친 것이 보인다(사용자 「글자색은 살짝 다르게」).
    """
    x0, y0, x1, y1 = box
    w_, h_ = x1 - x0, y1 - y0
    # ⚠ **D 를 먼저** 그린다 — 나중에 그린 것이 위에 온다. 사용자 지시
    #   「**H가 앞으로 D가 뒤로**」.
    dx0, dy0 = x0 + int(w_ * 0.44), y0 + int(h_ * 0.30)
    dx1, dy1 = x0 + int(w_ * 0.92), y1
    _D(d, (dx0, dy0, dx1, dy1), c_d, wd)
    # H — 왼쪽 위, **좌우 폭을 좁게**(사용자 「둘다 글자의 좌우 폭을 더 얇게」)
    hx0, hy0 = x0 + int(w_ * 0.04), y0
    hx1, hy1 = x0 + int(w_ * 0.50), y0 + int(h_ * 0.72)
    _H(d, (hx0, hy0, hx1, hy1), c_h, wh)


def draw_book(S, simple=False):
    """성경책 — 와인색 커버 · **아래에 종이 두께** · 겹친 H·D.

    ★★ **책 아랫부분이 보여야 실감이 난다**(2026-09-05 사용자 — 「책의
      아랫부분이 안보이니까 실감이 나지 않는다. **아래 오른쪽이 살짝 열린
      느낌**」). 샘플(icon4)처럼 밑에 종이 층을 깔고 오른쪽을 살짝 연다.
    ⚠ `simple` 은 **작은 크기 전용** — 결·그림자를 걷고 획을 굵게 한다.
      작은 아이콘에서 가는 선은 회색 얼룩이 된다.
    """
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    m = int(S * 0.09)
    top = int(S * 0.12)
    base = int(S * 0.80)                 # 커버 아랫선
    paper_h = max(2, int(S * 0.085))     # 종이 두께
    rad = max(1, int(S * 0.05))

    # ① **아래 종이 층** — 커버보다 살짝 좁게, 오른쪽으로 조금 더 나온다
    d.rounded_rectangle([m + int(S * 0.02), base,
                         S - m + int(S * 0.02), base + paper_h],
                        radius=max(1, rad // 2), fill=GOLD_L)
    if not simple:                        # 낱장 결 — 큰 크기에서만
        for i in range(3):
            yy = base + int(paper_h * (0.3 + 0.22 * i))
            d.line([m + int(S * 0.05), yy, S - m, yy],
                   fill=GOLD, width=max(1, S // 200))

    # ② **오른쪽으로 살짝 열린 책장** — 커버보다 조금 넘어간다
    open_x = S - m + int(S * 0.035)
    d.rounded_rectangle([S - m - int(S * 0.06), top + int(S * 0.02),
                         open_x, base + int(paper_h * 0.4)],
                        radius=rad, fill=GOLD)

    # ③ 커버 — 와인색
    d.rounded_rectangle([m, top, S - m, base], radius=rad, fill=WINE)
    # ④ 책등 — 왼쪽 그늘로 두께
    d.rounded_rectangle([m, top, m + int(S * 0.085), base],
                        radius=rad, fill=WINE_D)

    # ⑤ 겹친 H·D — H 는 **얇게**(사용자 지시), 색을 살짝 달리한다
    # ★ **글자를 왼쪽으로 몰아 오른쪽을 비운다**(2026-09-05 사용자 —
    #   「책의 오른쪽이 열린 모습으로 만들려면 HD가 더 왼쪽으로 이동하면
    #    되겠다」). 비운 자리가 곧 「열린 책장」으로 읽힌다.
    bx0 = m + int(S * 0.11)
    bx1 = S - m - int(S * 0.24)
    by0 = top + int(S * 0.16)
    by1 = base - int(S * 0.14)
    _HD(d, S, (bx0, by0, bx1, by1), GOLD_L, GOLD_D,
        max(2, int(S * (0.075 if simple else 0.055))),
        max(2, int(S * (0.095 if simple else 0.080))))
    return im


def _shield_poly(S, k=1.0):
    """방패 윤곽 — **샘플 icon5 를 눈금까지 재서 그대로** (2026-09-05 사용자
    지시 「icon5 와 똑같이 만들고 그것을 수정하는 방향으로 작업하라」).

    icon5 실측(512px 원본) — 방패 x 155~355 · y 130~395, 아이콘 박스
    x 75~440 · y 65~415. 정규화하면 **폭 55% · 위 19% · 아래 94%** 이고
    옆선이 위 1/3 까지 거의 수직이다가 아래에서 좁아지며 뾰족해진다.

    ⚠ **폭은 icon5(55%)보다 넓게 잡았다**(68%) — 사용자가 「방패가 더 커야
      한다」고 했다. 형태는 icon5, 크기는 그보다 크게. 55% 로 두면 칼이
      시원하게 보이는 대신 방패가 작아 보인다.
    ⚠ 위 모서리는 **평평한 어깨** — icon5 의 특징이다. 둥글리면 알약이 된다.

    `k` 로 크기를 조절한다(1.0 이 바깥 테두리, 작을수록 안쪽).
    """
    cx = S * .5
    L, R = S * .16, S * .84          # 폭 68%
    T, B = S * .10, S * .99
    sh = S * .045                    # 어깨 굴림
    mid = S * .52                    # 여기까지 수직, 아래로 좁아진다
    cy = (T + B) * .5

    pts = [(L, T + sh), (L + sh, T), (R - sh, T), (R, T + sh), (R, mid)]
    for i in range(1, 13):           # 오른쪽 아래 곡선
        t = i / 13.0
        pts.append((R + (cx - R) * (t ** 1.8), mid + (B - mid) * t))
    pts.append((cx, B))
    for i in range(12, 0, -1):       # 왼쪽 아래 곡선
        t = i / 13.0
        pts.append((L + (cx - L) * (t ** 1.8), mid + (B - mid) * t))
    pts.append((L, mid))
    return [(int(cx + (x - cx) * k), int(cy + (y - cy) * k)) for x, y in pts]

def _rivets(d, S, poly, color, r):
    """테두리 위 **동그라미 리벳**(2026-09-05 사용자 지시).

    ⚠ 윤곽 위에 **고르게** 놓는다 — 점 번호로 세면 아래쪽 곡선에 몰린다.
    """
    if r < 1:
        return
    n = len(poly)
    for i in range(0, n, max(1, n // 10)):
        x, y = poly[i]
        d.ellipse([x - r, y - r, x + r, y + r], fill=color)


def _sword(d, S, x0, y0, x1, y1, w):
    """칼 하나 — **강철 날 + 가죽 손잡이**(2026-09-05 사용자 지시).

    `(x0,y0)` 손잡이 쪽 · `(x1,y1)` 칼끝.
    ★ 날은 **밝은 면·중간·그늘 셋**으로 나눠 강철 느낌을 낸다.
    ★ 손잡이는 가죽색에 **감은 자국**을 넣는다.
    """
    import math
    dx, dy = x1 - x0, y1 - y0
    L = math.hypot(dx, dy) or 1
    ux, uy = dx / L, dy / L
    px, py = -uy, ux
    tipl = w * 2.4

    def P(t, o):
        return (x0 + ux * t + px * o, y0 + uy * t + py * o)

    def poly(pts):
        d.polygon([(int(a), int(b)) for a, b in pts], fill=poly.c)
    # ① 날 — 오른쪽 반(그늘) · 왼쪽 반(밝은 면)
    poly.c = STEEL_D
    poly([P(w * 1.8, 0), P(L - tipl, w * .52), (x1, y1), P(L - tipl, 0)])
    poly.c = STEEL
    poly([P(w * 1.8, 0), P(L - tipl, -w * .52), (x1, y1), P(L - tipl, 0)])
    # 가운데 능선
    d.line([P(w * 1.8, 0), (x1, y1)], fill=STEEL_M,
           width=max(1, int(w * .16)))
    # ② 십자 가드 — 금색
    g = w * 2.0
    d.line([P(w * 1.7, -g), P(w * 1.7, g)], fill=GOLD_D,
           width=max(2, int(w * .5)))
    # ③ 가죽 그립
    d.line([P(-w * 2.4, 0), P(w * 1.4, 0)], fill=LEATHER,
           width=max(2, int(w * .82)))
    if S >= 48:
        for k in range(4):
            t = -w * 2.0 + k * w * .95
            d.line([P(t, -w * .42), P(t, w * .42)], fill=LEATHER_D,
                   width=max(1, int(w * .18)))
    # ④ 폼멜 — 금색 구슬
    cxp, cyp = P(-w * 2.7, 0)
    r = w * .6
    d.ellipse([cxp - r, cyp - r, cxp + r, cyp + r], fill=GOLD_D)


def _arc_text(im, S, text, color, cy, rad, size):
    """**U 자로 휘어진 글자**(2026-09-05 사용자 — 「DABAR는 마치 U자처럼
    아래쪽에」). 글자마다 돌려 붙인다.

    ⚠ **작은 크기에서는 안 그린다** — 읽히지 않는 글자는 얼룩이 된다
      (사용자도 「Dabar 글자가 들어가면 보일지 모르겠다」고 했다).
    """
    import math
    try:
        from PIL import ImageFont
        f = None
        for nm in ('georgiab.ttf', 'seguisb.ttf', 'arialbd.ttf', 'malgunbd.ttf'):
            try:
                f = ImageFont.truetype(nm, size)
                break
            except Exception:
                continue
        if f is None:
            return False
        n = len(text)
        span = 76.0                       # 아치가 벌어지는 각도
        for i, ch in enumerate(text):
            a = math.radians(-span / 2 + span * (i / max(1, n - 1)))
            g = Image.new('RGBA', (size * 2, size * 2), (0, 0, 0, 0))
            ImageDraw.Draw(g).text((size // 2, size // 2), ch,
                                   font=f, fill=color)
            g = g.rotate(-math.degrees(a), resample=Image.BICUBIC)
            # ⚠ **아래로 볼록한 U** — 중심이 **위**에 있고 글자가 아래로
            #   내려간다. 부호를 빼면 위로 볼록한 아치가 되어 방패 밖으로
            #   나간다(실측 0px).
            x = S * .5 + rad * math.sin(a) - size
            y = cy + rad * math.cos(a) - size
            im.alpha_composite(g, (int(x), int(y)))
        return True
    except Exception:
        return False


def draw_shield(S):
    """관리자 — **X 자 칼 둘 + 두 겹 방패 + 리벳 + 쑥색 H + 금색 DABAR**."""
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, int(S * .055))
    # ① 칼 둘 — 방패보다 **먼저**(뒤로 간다). 칼끝은 **아래**(칼을 거둔 자세).
    # ★ **icon5 배치** — 자루(둥근 손잡이+십자 가드)가 방패 **어깨 위 바깥**,
    #   칼끝이 **아래 바깥**. 방패 뒤로 지나가므로 가운데는 안 보인다.
    _sword(d, S, S * .96, S * .03, S * .08, S * .99, w)
    _sword(d, S, S * .04, S * .03, S * .92, S * .99, w)
    # ② 방패 — 바깥 밝은 와인 · 안쪽 진한 와인
    outer = _shield_poly(S, 1.0)
    d.polygon(outer, fill=WINE_L)
    inner = _shield_poly(S, 0.88)
    d.polygon(inner, fill=WINE_IN)
    # ③ 밝은 테두리 선 + 리벳
    if S >= 32:
        d.line(outer + [outer[0]], fill=GOLD_L,
               width=max(1, int(S * .012)))
        _rivets(d, S, _shield_poly(S, 0.94), GOLD_L, max(1, int(S * .018)))
    # ④ **H 는 가운데 · 쑥색**
    _H(d, (int(S * .32), int(S * .24), int(S * .68), int(S * .56)),
       SAGE, max(2, int(S * .068)))
    # ⑤ **DABAR 는 아래쪽 U 자 · 금색** — 큰 크기에서만(작으면 얼룩이 된다)
    if S >= 96:
        _arc_text(im, S, 'DABAR', GOLD_BR, S * .28, S * .40,
                  max(9, int(S * .115)))
    return im


def _shield_full(S, k=1.0, wfrac=0.86):
    """높이를 꽉(0 ~ S) 채우는 방패 — 위 평평한 어깨 · 가운데까지 곧게 · 아래 뾰족."""
    cx = S / 2
    w = S * wfrac
    L, R = cx - w / 2, cx + w / 2
    T, B = S * 0.02, S * 0.99
    sh = S * 0.08
    mid = S * 0.50
    pts = [(L, T + sh), (L + sh, T), (R - sh, T), (R, T + sh), (R, mid)]
    for i in range(1, 16):
        t = i / 16
        pts.append((R + (cx - R) * (t ** 1.7), mid + (B - mid) * t))
    pts.append((cx, B))
    for i in range(15, 0, -1):
        t = i / 16
        pts.append((L + (cx - L) * (t ** 1.7), mid + (B - mid) * t))
    pts.append((L, mid))
    cy = (T + B) / 2
    return [(cx + (x - cx) * k, cy + (y - cy) * k) for x, y in pts]


def _sky_shield(S):
    """하늘색 방패(테두리 진한 파랑) — 4배로 그려 줄인다 → RGBA."""
    Z = 4
    big = Image.new('RGBA', (S * Z, S * Z), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    d.polygon([(x * Z, y * Z) for x, y in _shield_full(S)], fill=SKY_D)
    k = 1 - (2.2 if S <= 24 else 2.6) / S
    d.polygon([(x * Z, y * Z) for x, y in _shield_full(S, k)], fill=SKY)
    return big.resize((S, S), Image.LANCZOS)


def draw_admin_a(S):
    """관리자(A) — 하늘색 방패 + 흰 H. H 는 그 크기의 픽셀에 맞춰 그린다."""
    im = _sky_shield(S)
    d = ImageDraw.Draw(im)
    sw = max(2, round(S / 7.5))
    w = max(6, round(S * 0.50))
    if w % 2 != S % 2:
        w += 1
    x0 = (S - w) // 2
    x1 = x0 + w - 1
    y0, y1 = round(S * 0.20), round(S * 0.66)
    d.rectangle([x0, y0, x0 + sw - 1, y1], fill=WHITE)
    d.rectangle([x1 - sw + 1, y0, x1, y1], fill=WHITE)
    m = (y0 + y1) // 2
    d.rectangle([x0, m - sw // 2, x1, m - sw // 2 + sw - 1], fill=WHITE)
    return im


def draw_user_b(S):
    """사용자(B) — 하늘색 방패 + 세로 칼(금빛 손잡이·가드 · 흰 날 · 칼끝 아래).
    칼이 십자가로도 읽힌다."""
    im = _sky_shield(S)
    d = ImageDraw.Draw(im)
    bw = 2 if S <= 24 else max(2, round(S / 9))
    cx0 = (S - bw) // 2
    top = round(S * 0.12)
    guard_y = round(S * 0.30)
    tip = round(S * 0.84)
    gw = max(6, round(S * 0.46))
    gx0 = (S - gw) // 2
    gh = 2 if S <= 24 else max(2, round(S / 12))
    d.rectangle([cx0, top, cx0 + bw - 1, guard_y], fill=CROSS_HILT)               # 손잡이
    d.rectangle([gx0, guard_y, gx0 + gw - 1, guard_y + gh - 1], fill=CROSS_HILT)  # 가드
    d.rectangle([cx0, guard_y + gh, cx0 + bw - 1, tip - 2], fill=WHITE)           # 날
    if bw > 2:
        d.polygon([(cx0, tip - 2), (cx0 + bw - 1, tip - 2), (cx0 + (bw - 1) / 2, tip)], fill=WHITE)
    else:
        d.rectangle([cx0, tip - 2, cx0 + bw - 1, tip - 1], fill=WHITE)
    return im


# ★★★ 사용자 아이콘 C (2026-10-15 사용자 「진행하라」 — 사용자가 제미나이로 만든 그림 ·
#   푸른 방패 + 흰 안쪽 테두리 + 장식 달린 금빛 칼). 원본 = `icons/sword_cross_icon_512.png`.
#   ⚠ 원본은 **흰 바탕이 박힌 RGB** 다 — 모서리에서 흘러 들어가며 **바깥 흰 바탕만** 걷는다
#     (방패 안쪽 흰 테두리는 바깥과 이어지지 않아 남는다) → `icons/app_user_src.png`(투명).
#   ⚠ **48px 아래는 따로 그린다**(`_user_c_small`) — 원본을 줄이면 금빛 칼이 1~2px 선이 되어
#     하늘색 바탕에서 안 보이고 장식은 뭉갠다(실측 16·24px). 색은 원본에서 떴다.
SRC_C = os.path.join(ICON_DIR, 'sword_cross_icon_512.png')
CUT_C = os.path.join(ICON_DIR, 'app_user_src.png')
C_BLUE = (34, 141, 249)        # 원본 방패 바탕
C_BLUE_D = (14, 92, 190)       # 방패 테두리
C_GOLD = (240, 200, 88)        # 원본 칼(밝은 면)
C_GOLD_D = (150, 98, 20)       # 칼 테두리(원본 그늘)
C_SMALL = 48                   # 이보다 작으면 단순화한 그림


def cut_src(src=SRC_C, out=CUT_C):
    """원본의 바깥 흰 바탕을 걷고 그림 둘레에 맞춰 정사각으로 → 저장 경로."""
    import collections
    im = Image.open(src).convert('RGBA')
    W, H = im.size
    px = im.load()
    seen = set()
    q = collections.deque([(0, 0), (W - 1, 0), (0, H - 1), (W - 1, H - 1)])
    while q:
        x, y = q.popleft()
        if (x, y) in seen or not (0 <= x < W and 0 <= y < H):
            continue
        seen.add((x, y))
        p_ = px[x, y]
        if not (p_[0] > 225 and p_[1] > 225 and p_[2] > 225):
            continue
        px[x, y] = (255, 255, 255, 0)
        q.extend([(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)])
    im = im.crop(im.getbbox())
    S = max(im.size)
    sq = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    sq.paste(im, ((S - im.width) // 2, (S - im.height) // 2))
    sq.save(out)
    return out


_C_CACHE = {}


def _c_src():
    if 'im' not in _C_CACHE:
        if not os.path.exists(CUT_C) or (os.path.exists(SRC_C)
                                          and os.path.getmtime(SRC_C) > os.path.getmtime(CUT_C)):
            cut_src()
        _C_CACHE['im'] = Image.open(CUT_C).convert('RGBA')
    return _C_CACHE['im']


def _user_c_small(S):
    """작은 크기(16~40px) — 같은 방패·같은 칼을 굵고 단순하게. 방패는 4배로 그려 줄이고
    (원본처럼 안쪽 흰 테두리 — 24px 부터) 칼은 그 크기의 픽셀에 맞춰 바로 그린다."""
    Z = 4
    big = Image.new('RGBA', (S * Z, S * Z), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    d.polygon([(x * Z, y * Z) for x, y in _shield_full(S)], fill=C_BLUE_D)
    k = 1 - (2.0 if S <= 24 else 2.4) / S
    d.polygon([(x * Z, y * Z) for x, y in _shield_full(S, k)], fill=C_BLUE)
    if S >= 24:
        k2 = 1 - 4.6 / S
        d.line([(x * Z, y * Z) for x, y in _shield_full(S, k2)] + [tuple(v * Z for v in _shield_full(S, k2)[0])],
               fill=WHITE, width=max(Z, round(Z * S / 40)))
    im = big.resize((S, S), Image.LANCZOS)
    d = ImageDraw.Draw(im)
    bw = 2 if S <= 24 else 3                               # 날 굵기
    if (S - bw) % 2:
        bw += 1
    cx0 = (S - bw) // 2
    cx1 = cx0 + bw - 1
    mid = (cx0 + cx1) / 2
    top = round(S * 0.13)
    gy = round(S * 0.31)
    tip = round(S * 0.86)
    gw = max(8, round(S * 0.54))
    if (S - gw) % 2:
        gw += 1
    gx0 = (S - gw) // 2
    gh = 2
    o = 1
    # 테두리(진한 금) → 밝은 금 — 하늘색 바탕과 갈리게
    d.rectangle([cx0 - o, top - o, cx1 + o, gy], fill=C_GOLD_D)                       # 손잡이
    d.rectangle([gx0 - o, gy - o, gx0 + gw - 1 + o, gy + gh - 1 + o], fill=C_GOLD_D)  # 가드
    d.polygon([(cx0 - o, gy + gh), (cx1 + o, gy + gh), (mid, tip + 1)], fill=C_GOLD_D)  # 날(뾰족)
    d.rectangle([cx0, top, cx1, gy - 1], fill=C_GOLD)
    d.rectangle([gx0, gy, gx0 + gw - 1, gy + gh - 1], fill=C_GOLD)
    d.polygon([(cx0, gy + gh), (cx1, gy + gh), (mid, tip - 1)], fill=C_GOLD)
    if S >= 32:
        # 폼멜과 가드 두 끝의 장식을 둥근 점으로(원본의 꽃 장식)
        r = 2 if S < 40 else 3
        for (x, y) in ((mid, top - 1), (gx0 - 1, gy + (gh - 1) / 2), (gx0 + gw, gy + (gh - 1) / 2)):
            d.ellipse([x - r, y - r, x + r, y + r], fill=C_GOLD, outline=C_GOLD_D)
    return im


def draw_user_c(S):
    """사용자(C) — 48px 이상은 원본 그림을 줄이고, 그보다 작으면 단순화한 그림."""
    if S < C_SMALL:
        return _user_c_small(S)
    return _c_src().resize((S, S), Image.LANCZOS)


def build(out_dir=None):
    """세 아이콘을 `.ico` 로 만든다 → `{이름: 경로}`."""
    if not _PIL:
        raise SystemExit('Pillow(PIL) 가 필요합니다.')
    out = out_dir or ICON_DIR
    os.makedirs(out, exist_ok=True)
    made = {}
    # ★ 2026-10-09 — 사용자 = B · 관리자 = A. 바로가기 아이콘(`Hagah Dabar.ico` ·
    #   `Hagah Admin.ico`)도 같은 그림이다(두 벌을 따로 두면 갈린다).
    # ★ 2026-10-15 — 사용자 = C(제미나이 그림). B 는 되돌릴 자리로 남긴다.
    for name, fn in (('app_user', draw_user_c),
                     ('app_tray', draw_user_c),
                     ('Hagah Dabar', draw_user_c),
                     ('app_admin', draw_admin_a),
                     ('Hagah Admin', draw_admin_a)):
        # ⚠ 크기마다 **다시 그린다** — 한 장을 줄이면 작은 데서 H 가 뭉갠다.
        #   `append_images` 로 넘겨야 Pillow 가 그 크기 그림을 그대로 쓴다
        #   (`sizes` 만 주면 큰 그림 하나를 줄인다).
        imgs = [fn(s) for s in SIZES]
        p = os.path.join(out, name + '.ico')
        imgs[0].save(p, format='ICO', sizes=[(s, s) for s in SIZES],
                     append_images=imgs[1:])
        # 미리보기 PNG 도 남긴다(문서·확인용)
        imgs[0].save(os.path.join(out, name + '.png'), format='PNG')
        made[name] = p
    return made


ANDROID = (('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192))


# ★★ 폰 아이콘 = 흰 동그라미 + 얇은 테두리 + 방패(2026-10-15 사용자 「배경색을 흰색으로 동그라미 테두리로 ·
#   방패 바깥쪽은 흰색 · 투명화 처리하지 않는 것이 원칙」). 두 갈래를 함께 둔다:
#   · 옛 꼴(`mipmap-*/ic_launcher.png`) — 흰 동그라미 그림 그대로(안드로이드 7 이하 · 런처가 모양을 안 씌울 때)
#   · 적응형(`mipmap-anydpi-v26/ic_launcher.xml`) — 바탕 = 흰색 · 앞 그림 = 테두리 고리 + 방패
#     (108dp 판 · 런처가 가장자리를 잘라 동그라미 등으로 씌운다 — 고리는 보이는 72dp 안쪽에 둔다)
# ★ 2026-10-25 회색 원형 테두리(RING)를 걷었다(사용자 「테두리를 없애고 방패를 더 키우고 싶다」) — 흰 바탕 + 큰 방패만.


def phone_round(S):
    """옛 꼴 — S×S 흰 동그라미 + 방패(동그라미 밖은 투명).
    ★ 2026-10-25 사용자 「크기가 다른 것보다 작다 · 회색 원형 테두리를 없애고 방패를 더 키우고 싶다」 — 테두리 없음 · 방패 0.66 → 0.80."""
    Z = 4
    big = Image.new('RGBA', (S * Z, S * Z), (0, 0, 0, 0))
    d = ImageDraw.Draw(big)
    d.ellipse([0, 0, S * Z - 1, S * Z - 1], fill=WHITE + (255,))
    im = big.resize((S, S), Image.LANCZOS)
    sh = round(S * 0.80)
    shield = draw_user_c(sh)
    im.alpha_composite(shield, ((S - sh) // 2, (S - sh) // 2))
    return im


#: 적응형 앞 그림의 방패 높이(108dp 판 안) — 48 → 62(2026-10-25 · 삼성 둥근 네모 안에 모서리까지 든다)
FORE_SHIELD_DP = 62


def phone_fore(P):
    """적응형 앞 그림 — P×P(108dp) 투명 판 위에 방패(높이 62dp · 테두리 고리는 2026-10-25 걷었다)."""
    im = Image.new('RGBA', (P, P), (0, 0, 0, 0))
    sh = round(P * FORE_SHIELD_DP / 108)
    shield = draw_user_c(sh)
    im.alpha_composite(shield, ((P - sh) // 2, (P - sh) // 2))
    return im


ANDROID_FORE = (('mdpi', 108), ('hdpi', 162), ('xhdpi', 216), ('xxhdpi', 324), ('xxxhdpi', 432))
ADAPTIVE_XML = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_bg"/>
    <foreground android:drawable="@mipmap/ic_launcher_fg"/>
</adaptive-icon>
"""
COLOR_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_bg">#FFFFFF</color>
</resources>
"""


def build_android(res_dir):
    """폰 앱 아이콘(B · PC 사용자 앱과 같은 그림) — `mipmap-*/ic_launcher.png` (2026-10-10 1.txt 54).
    ⚠ 크기마다 다시 그린다(줄이면 칼이 뭉갠다)."""
    made = []
    for dens, s in ANDROID:
        d = os.path.join(res_dir, 'mipmap-' + dens)
        os.makedirs(d, exist_ok=True)
        fp = os.path.join(d, 'ic_launcher.png')
        im = phone_round(s)
        im.save(fp, format='PNG')
        im.save(os.path.join(d, 'ic_launcher_round.png'), format='PNG')   # roundIcon 옛 꼴(안드로이드 7 이하)
        made.append(fp)
    for dens, P in ANDROID_FORE:
        fp = os.path.join(res_dir, 'mipmap-' + dens, 'ic_launcher_fg.png')
        phone_fore(P).save(fp, format='PNG')
        made.append(fp)
    d = os.path.join(res_dir, 'mipmap-anydpi-v26')
    os.makedirs(d, exist_ok=True)
    for name in ('ic_launcher.xml', 'ic_launcher_round.xml'):
        with open(os.path.join(d, name), 'w', encoding='utf-8') as f:
            f.write(ADAPTIVE_XML)
        made.append(os.path.join(d, name))
    with open(os.path.join(res_dir, 'values', 'ic_launcher_bg.xml'), 'w', encoding='utf-8') as f:
        f.write(COLOR_XML)
    return made


def selftest():
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-50s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-50s %s' % (n, e))

    print('=== db_make_icons selftest')
    t('★ Pillow 가 있다', _PIL)
    if not _PIL:
        print('  %d/%d' % (ok, ok + fail))
        return False
    import tempfile
    tmp = tempfile.mkdtemp(prefix='icotest_')
    made = build(tmp)
    t('★ 다섯을 만든다(사용자 셋 · 관리자 둘)', len(made) == 5, ', '.join(sorted(made)))

    # ★★ 2026-10-09 새 아이콘 — 눈으로 못 보므로 픽셀을 센다
    def _near(p, c, tol=30):
        return all(abs(a - b) <= tol for a, b in zip(p[:3], c))
    for nm, fn in (('사용자 B', draw_user_b), ('관리자 A', draw_admin_a)):
        for S in (16, 20, 256):
            g = fn(S)
            px = list(g.getdata())
            sky = sum(1 for p in px if p[3] > 200 and (_near(p, SKY) or _near(p, SKY_D)))
            rows = [y for y in range(S) if any(g.getpixel((x, y))[3] > 128 for x in range(S))]
            t('★★ %s %dpx — 하늘색 방패가 높이를 꽉 채운다' % (nm, S),
              sky > S * S * 0.35 and rows and rows[0] <= max(1, S * 0.03)
              and rows[-1] >= min(S - 2, S * 0.97),
              '하늘색 %d · 위 %s 아래 %s' % (sky, rows[0] if rows else '-', rows[-1] if rows else '-'))
    g = draw_admin_a(16)
    t('★ 관리자 16px — 흰 H 가 있다', sum(1 for p in g.getdata() if p[3] > 200 and _near(p, WHITE, 10)) >= 20)
    gc = draw_user_c(16)
    t('★ 사용자 C 16px — 금빛 칼이 있다(단순화한 그림)',
      sum(1 for p in gc.getdata() if p[3] > 200 and _near(p, C_GOLD, 30)) >= 8)
    gc = draw_user_c(256)
    t('★★ 사용자 C 256px — 원본 그림 · 모서리가 투명하다',
      gc.getpixel((2, 2))[3] == 0 and gc.getpixel((128, 128))[3] == 255)
    g = draw_user_b(16)
    t('★ 사용자 16px — 금빛 가드·흰 날이 있다',
      sum(1 for p in g.getdata() if p[3] > 200 and _near(p, CROSS_HILT, 10)) >= 8
      and sum(1 for p in g.getdata() if p[3] > 200 and _near(p, WHITE, 10)) >= 8)
    _ic = Image.open(made['app_tray'])
    t('★★ 트레이 아이콘에 20px(125% 배율 트레이 칸)가 들어 있다',
      (20, 20) in _ic.ico.sizes(), str(sorted(_ic.ico.sizes())))
    _ic.close()
    for nm, p in made.items():
        t('  %s 파일이 생긴다' % nm,
          os.path.exists(p) and os.path.getsize(p) > 800,
          '%d bytes' % os.path.getsize(p))
    im = Image.open(made['app_user'])
    t('★★ **여러 크기를 담는다**(16 은 작업표시줄 · 256 은 바탕화면)',
      len(getattr(im, 'ico', None).sizes()) >= 5 if hasattr(im, 'ico')
      else True, str(sorted(im.ico.sizes()) if hasattr(im, 'ico') else '-'))

    # ★ 색이 실제로 지시대로인가 — 눈으로 못 보므로 **픽셀을 센다**
    bk = draw_book(256).convert('RGB')
    px = list(bk.getdata())

    def near(p, c, tol=26):
        return all(abs(a - b) <= tol for a, b in zip(p, c))
    n_wine = sum(1 for p in px if near(p, WINE) or near(p, WINE_D))
    n_gold = sum(1 for p in px if near(p, GOLD) or near(p, GOLD_L))
    t('★★★ **커버가 와인색이다**', n_wine > 256 * 256 * 0.25,
      '%.0f%%' % (100.0 * n_wine / len(px)))
    t('★★★ **종이·글자가 황금빛이다**', n_gold > 256 * 256 * 0.05,
      '%.0f%%' % (100.0 * n_gold / len(px)))

    # ★★ **H 와 D 가 겹쳐 있나** — 눈으로 못 보므로 픽셀로 잰다.
    #   ⚠ 옛 검사(「가운데 줄이 길게 금색」)는 **굵은 H 하나**를 전제했다.
    #     H 를 얇게 하고 D 를 겹치자 그 자리에서 실패했다 — 검사가 옛 모양을
    #     못 박고 있으면 개선을 막는다(§0-5).
    def cnt(c, tol=18):
        return sum(1 for p in px if near(p, c, tol))
    n_h, n_d = cnt(GOLD_L), cnt(GOLD_D)
    t('★★★ **H 와 D 가 둘 다 있고 색이 다르다**(사용자 지시)',
      n_h > 500 and n_d > 500, 'H색 %d px · D색 %d px' % (n_h, n_d))
    # 겹침 — H 오른쪽 아래 자리에 두 색이 이웃해 있다
    ov = 0
    for y in range(96, 176):
        row = [bk.getpixel((x, y)) for x in range(96, 176)]
        if any(near(p, GOLD_L, 18) for p in row) and            any(near(p, GOLD_D, 18) for p in row):
            ov += 1
    t('★★ **겹친 자리가 있다**(H 오른쪽 아래 ↔ D 왼쪽 위)', ov >= 20,
      '%d줄에서 두 색이 만난다' % ov)
    # 책 아랫부분 — 커버 아래에 종이 층이 보인다
    band = [bk.getpixel((x, 212)) for x in range(40, 216)]
    t('★★★ **책 아랫부분이 보인다**(사용자 「실감이 나지 않는다」)',
      sum(1 for p in band if near(p, GOLD_L, 40) or near(p, GOLD, 40)) > 60,
      '아래 띠 금색 %d/176' % sum(1 for p in band
                                if near(p, GOLD_L, 40) or near(p, GOLD, 40)))

    sh = draw_shield(256).convert('RGB')
    spx = list(sh.getdata())
    # ⚠ 옛 검사는 단색 `WINE` 을 봤다 — **두 겹(밝은 바깥·진한 안쪽)** 으로
    #   바뀌자 그 자리에서 실패했다(2026-09-05 사용자 지시).
    n_w = sum(1 for p in spx if near(p, WINE_L) or near(p, WINE_IN))
    t('★★★ **방패가 두 겹 와인색이다**(바깥 밝게 · 안쪽 진하게)',
      n_w > 256 * 256 * 0.20
      and sum(1 for p in spx if near(p, WINE_L)) > 800
      and sum(1 for p in spx if near(p, WINE_IN)) > 3000,
      '%.0f%% (바깥 %d · 안쪽 %d)'
      % (100.0 * n_w / len(spx),
         sum(1 for p in spx if near(p, WINE_L)),
         sum(1 for p in spx if near(p, WINE_IN))))
    # ⚠ 옛 검사는 **칼 둘**을 전제한 픽셀 수였다 — 하나로 줄이자 그 자리에서
    #   실패했다. 뜻은 「칼이 방패 **위아래로** 삐져나온다」이므로 그것을 잰다.
    def band(y0, y1, c=None):
        n = 0
        for y in range(y0, y1):
            for x in range(0, 256, 2):
                p = sh.getpixel((x, y))
                if near(p, STEEL) or near(p, STEEL_D) or near(p, HILT)                         or near(p, HILT_D):
                    n += 1
        return n
    up, dn = band(4, 46), band(214, 252)
    t('★★ **칼이 방패 위아래로 보인다**(손잡이 위 · 칼끝 아래)',
      up > 6 and dn > 4, '위 %d px · 아래 %d px' % (up, dn))
    srow = [sh.getpixel((x, 128)) for x in range(256)]
    t('★★ **H 는 쑥색**(사용자 지시)',
      sum(1 for p in spx if near(p, SAGE)) > 700,
      '%d px' % sum(1 for p in spx if near(p, SAGE)))
    t('★★ **DABAR 는 금색으로 아래쪽에**',
      sum(1 for y in range(150, 230) for x in range(0, 256, 2)
          if near(sh.getpixel((x, y)), GOLD_BR, 40)) > 40,
      '%d px' % sum(1 for y in range(150, 230) for x in range(0, 256, 2)
                    if near(sh.getpixel((x, y)), GOLD_BR, 40)))
    t('★ **리벳·테두리가 있다**(밝은 금)',
      sum(1 for p in spx if near(p, GOLD_L, 22)) > 300,
      '%d px' % sum(1 for p in spx if near(p, GOLD_L, 22)))
    t('★ **칼날이 강철 세 톤이다**(입체감)',
      all(sum(1 for p in spx if near(p, c)) > 60
          for c in (STEEL, STEEL_M, STEEL_D)),
      '밝 %d · 중 %d · 그늘 %d'
      % tuple(sum(1 for p in spx if near(p, c))
              for c in (STEEL, STEEL_M, STEEL_D)))
    t('★ **손잡이가 가죽색이다**',
      sum(1 for p in spx if near(p, LEATHER) or near(p, LEATHER_D)) > 150,
      '%d px' % sum(1 for p in spx
                    if near(p, LEATHER) or near(p, LEATHER_D)))

    # 작은 크기에서 H 가 살아 있나 — **뭉개지면 아이콘이 아니다**
    sm = draw_book(16, simple=True).convert('RGB')
    t('★★ **16px 에서도 금색이 남는다**(뭉개지지 않는다)',
      sum(1 for p in sm.getdata() if near(p, GOLD, 60)
          or near(p, GOLD_L, 60)) >= 12,
      '%d/256 px' % sum(1 for p in sm.getdata()
                        if near(p, GOLD, 60) or near(p, GOLD_L, 60)))

    # ⚠ 열어 둔 이미지를 닫아야 임시 폴더가 지워진다(Windows 파일 잠금).
    try:
        im.close()
    except Exception:
        pass
    import shutil
    shutil.rmtree(tmp, ignore_errors=True)
    t('★ 시험 잔재 0', not os.path.exists(tmp))
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    made = build()
    for nm, p in sorted(made.items()):
        print('%-10s %s  (%d bytes)' % (nm, p, os.path.getsize(p)))


if __name__ == '__main__':
    main()
