# -*- coding: utf-8 -*-
"""오류를 **사용자 동의를 받아** 관리자에게 보낸다.

★★★ 왜 (2026-09-05 사용자 지시 「오류가 났을 때 **스스로 팝업 띄우면서
  동의얻어서 자동으로 보내면** 좋다. **온라인 환경을 설정하라고 요구해야
  된다**」).
  ⚠⚠ 실측 — 이 PC 에 오류가 **194건** 쌓여 있는데 **아무도 못 보고 있다.**
    지금은 사용자가 ① 오류가 났다는 것을 알아차리고 ② 문의 화면을 찾아가
    ③ bug 를 고르고 ④ **로그 파일을 스스로 찾아 붙여야** 한다.
    그 넷을 다 하는 사용자는 없다.

**규칙 넷 — 이 순서를 지킨다**
  ① **묻지 않고 보내지 않는다** — 로그에는 그 사람이 무엇을 읽었는지가 담긴다.
  ② **무엇을 보내는지 보여 준다** — 「이런 내용입니다」를 접어서라도 읽게 한다.
  ③ **온라인이 안 잡혔으면 그것부터 말한다** — 「보내기」를 눌렀는데 조용히
     실패하면 사용자는 보냈다고 믿는다(§0-1).
  ④ **한 번 물으면 그 판까지는 다시 안 묻는다** — 오류가 연달아 나는데 팝업이
     계속 뜨면 앱을 못 쓴다.

⚠ **오류가 난 그 순간에 안 띄운다** — Tk 콜백 안에서 모달을 띄우면 그리는
  중에 창이 겹쳐 더 깨진다. **다음 유휴 시각**에 한 번 띄운다.

`--selftest`(의무).
"""
import os
import sys
import time

#: ⏸⏸ **지금은 실시간으로 안 돈다**(2026-09-05 사용자 지시 「errlog 자동전송은
#:   **구현하고 테스트 한 후, 지금 단계에서는 실시간 작동하도록 하지 말아라**」).
#:   ⇒ 모듈과 시험은 완성해 두고 **화면에 배선하지 않는다.** 켤 때는
#:     ① 이 값을 True 로 ② `user_main` 이 뜬 뒤 `maybe_ask(root)` 한 줄.
#:   ⚠ **켜기 전에 `--status` 로 몇 건이 나갈지 먼저 본다** — 지금 이 PC 에만
#:     194건이 쌓여 있다.
ENABLED = False

#: 한 판(앱 실행)에 이 횟수만 넘게는 안 묻는다.
ASK_ONCE_PER_RUN = True
#: 보낼 로그의 최대 크기 — 너무 크면 통로가 거부한다.
MAX_BYTES = 60 * 1024
#: 사용자가 「다시 묻지 마세요」를 고르면 여기 적는다.
OPT_KEY = 'ERR_SEND_MODE'      # ASK(기본) · AUTO(늘 보냄) · NEVER(안 물음)

_asked = [False]


def get_mode(db_path='bible_master.db'):
    """지금 설정 → `ASK|AUTO|NEVER`."""
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config"
                          " WHERE config_key=?", (OPT_KEY,)).fetchone()
        finally:
            c.close()
        v = (r[0] if r else '') or ''
        return v if v in ('ASK', 'AUTO', 'NEVER') else 'ASK'
    except Exception:
        return 'ASK'


def set_mode(mode, db_path='bible_master.db'):
    """설정을 적는다. ⚠ `ASK` 는 **행을 지운다** — 그것이 「정하지 않음」이다."""
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            if mode == 'ASK':
                c.execute("DELETE FROM user_config WHERE config_key=?",
                          (OPT_KEY,))
            else:
                c.execute("INSERT OR REPLACE INTO user_config(config_key,"
                          " config_val) VALUES(?,?)", (OPT_KEY, mode))
            c.commit()
        finally:
            c.close()
        return True
    except Exception:
        return False


def pending(db_path='bible_master.db'):
    """아직 안 보낸 오류가 몇 건인가.

    ⚠ **보낸 것을 또 세지 않는다** — 그러면 껐다 켤 때마다 같은 것을 묻는다.
      마지막으로 보낸 시각 뒤의 것만 센다.
    """
    import errlog
    try:
        n = errlog.count()
    except Exception:
        return 0
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config"
                          " WHERE config_key='ERR_SENT_N'").fetchone()
        finally:
            c.close()
        sent = int(r[0]) if r and str(r[0]).isdigit() else 0
    except Exception:
        sent = 0
    return max(0, n - sent)


def _note_sent(n, db_path='bible_master.db'):
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            c.execute("INSERT OR REPLACE INTO user_config(config_key,"
                      " config_val) VALUES('ERR_SENT_N',?)", (str(int(n)),))
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def body(db_path='bible_master.db', limit_bytes=MAX_BYTES):
    """보낼 글 → 사람이 읽을 수 있는 여러 줄.

    ★ **사람이 읽을 수 있어야 한다** — 사용자가 「무엇을 보내나」를 볼 수 있고,
      관리자도 그대로 읽는다.
    ⚠ **개인 정보를 넣지 않는다** — 로그의 파일 경로에 사용자 이름이 들어갈 수
      있어 홈 폴더를 `~` 로 가린다.
    """
    import errlog
    try:
        raw = errlog.bundle() or ''
    except Exception as e:                                    # noqa: BLE001
        raw = '(로그를 읽을 수 없습니다: %s)' % str(e)[:60]
    home = os.path.expanduser('~')
    if home and len(home) > 3:
        raw = raw.replace(home, '~')
    if len(raw.encode('utf-8')) > limit_bytes:
        # ⚠ **뒤쪽(최근)을 남긴다** — 앞쪽은 이미 지난 오류다
        raw = raw.encode('utf-8')[-limit_bytes:].decode('utf-8', 'replace')
        raw = '(앞부분은 길어서 잘랐습니다)\n' + raw
    head = []
    try:
        import appdb
        import user_feedback as F
        c = appdb.connect(db_path)
        try:
            head.append('앱 판: %s' % F.app_version(c))
        finally:
            c.close()
    except Exception:
        pass
    head.append('보낸 때: %s' % time.strftime('%Y-%m-%d %H:%M'))
    head.append('운영체제: %s' % sys.platform)
    return '\n'.join(head) + '\n\n' + raw


def can_send(db_path='bible_master.db'):
    """지금 보낼 수 있나 → `(가능?, 이유)`.

    ⚠ **왜 안 되는지 돌려준다** — 조용히 실패하면 사용자는 보냈다고 믿는다.
    """
    try:
        import appdb
        import user_feedback as F
        c = appdb.connect(db_path)
        try:
            if not F.is_configured(c):
                return False, 'NOT_CONFIGURED'
            if not F.endpoint(c):
                return False, 'NO_ENDPOINT'
        finally:
            c.close()
        return True, ''
    except Exception as e:                                    # noqa: BLE001
        return False, str(e)[:60]


def send(db_path='bible_master.db', text=None):
    """실제로 보낸다 → `{'ok','why','n'}`.

    ⚠ 통로는 **문의와 같은 것**(`user_feedback.submit`) — 따로 만들면 관리자가
      두 곳을 봐야 한다. 유형은 `BUG`.
    """
    okc, why = can_send(db_path)
    if not okc:
        return {'ok': False, 'why': why, 'n': 0}
    import appdb
    import errlog
    import user_feedback as F
    n = 0
    try:
        n = errlog.count()
    except Exception:
        pass
    try:
        c = appdb.connect(db_path)
        try:
            F.submit(c, 'BUG', text if text is not None else body(db_path))
        finally:
            c.close()
    except Exception as e:                                    # noqa: BLE001
        return {'ok': False, 'why': str(e)[:80], 'n': 0}
    _note_sent(n, db_path)
    return {'ok': True, 'why': '', 'n': n}


def maybe_ask(parent, db_path='bible_master.db', force=False):
    """오류가 쌓였으면 **묻고** 보낸다 → `'SENT'|'NO'|'SKIP'|'LATER'`.

    ★ 부르는 자리 = 앱이 다 뜬 뒤 한 번(유휴). **오류가 난 그 순간이 아니다.**
    ⚠ 온라인이 안 잡혔으면 **그것부터 말한다**(사용자 지시).
    """
    # ⏸ **꺼져 있으면 아무 일도 안 한다** — 정비 단계의 잠금(위 `ENABLED`)
    if not ENABLED and not force:
        return 'OFF'
    if _asked[0] and not force:
        return 'SKIP'
    mode = get_mode(db_path)
    if mode == 'NEVER' and not force:
        return 'SKIP'
    n = pending(db_path)
    if n <= 0 and not force:
        return 'SKIP'
    _asked[0] = True
    okc, why = can_send(db_path)

    from tkinter import messagebox
    try:
        import i18n

        def _(k, d):
            try:
                return i18n.t(k, d)
            except Exception:
                return d
    except Exception:
        def _(k, d):
            return d

    if not okc:
        # ⚠⚠ **온라인 설정을 요구한다** — 「보내기」가 조용히 실패하지 않게
        messagebox.showinfo(
            _('ERRSEND_TITLE', '오류 보고'),
            _('ERRSEND_NEED_ONLINE',
              '앱에서 오류 %d건이 기록됐습니다.\n\n'
              '보내려면 먼저 온라인 연결을 설정해야 합니다.\n'
              '설정 ▸ 내 문의 에서 한 번만 설정하면 그 뒤로는 자동입니다.')
            % n)
        return 'LATER'

    if mode == 'AUTO':
        r = send(db_path)
        return 'SENT' if r['ok'] else 'LATER'

    if not messagebox.askyesno(
            _('ERRSEND_TITLE', '오류 보고'),
            _('ERRSEND_ASK',
              '앱에서 오류 %d건이 기록됐습니다.\n\n'
              '무엇이 잘못됐는지 고치려면 그 기록이 필요합니다.\n'
              '개발자에게 보내시겠습니까?\n\n'
              '· 보내는 것: 오류 내용과 앱 판 번호\n'
              '· 보내지 않는 것: 성경 읽은 곳·묵상노트·개인 정보')
            % n):
        return 'NO'
    r = send(db_path)
    if r['ok']:
        messagebox.showinfo(
            _('ERRSEND_TITLE', '오류 보고'),
            _('ERRSEND_DONE',
              '보냈습니다. 고맙습니다.\n답변은 설정 ▸ 내 문의 에서 볼 수 있습니다.'))
        return 'SENT'
    messagebox.showinfo(
        _('ERRSEND_TITLE', '오류 보고'),
        _('ERRSEND_FAIL', '보내지 못했습니다: %s') % r['why'])
    return 'LATER'


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import appdb
    import io
    db = 'bible_master.db'
    keep = get_mode(db)
    try:
        t('★ 기본은 ASK 다(정하지 않음)', keep in ('ASK', 'AUTO', 'NEVER'), keep)
        set_mode('NEVER', db)
        t('  설정이 저장된다', get_mode(db) == 'NEVER')
        set_mode('ASK', db)
        t('★ ASK 로 되돌리면 **행을 지운다**', get_mode(db) == 'ASK')

        b = body(db)
        t('★ 보낼 글이 만들어진다', len(b) > 20, '%d자' % len(b))
        t('★★ **앱 판과 시각이 들어간다**', '앱 판' in b and '보낸 때' in b)
        home = os.path.expanduser('~')
        t('★★★ **홈 폴더 경로를 가린다**(개인 정보)',
          home not in b, home[:24])
        t('  크기가 한도 안이다', len(b.encode('utf-8')) <= MAX_BYTES + 200,
          '%.1f KB' % (len(b.encode('utf-8')) / 1024))

        okc, why = can_send(db)
        t('★ 보낼 수 있는지 먼저 잰다', isinstance(okc, bool),
          '%s / %s' % (okc, why or '-'))

        n = pending(db)
        t('★ 안 보낸 건수를 센다', n >= 0, '%d건' % n)

        # ⚠ **보낸 것을 또 세지 않는다** — 표식을 넣고 재본다
        import errlog
        cnt = errlog.count()
        c = appdb.connect(db)
        r0 = c.execute("SELECT config_val FROM user_config"
                       " WHERE config_key='ERR_SENT_N'").fetchone()
        c.close()
        _note_sent(cnt, db)
        t('★★★ **보낸 뒤에는 0 이 된다**(껐다 켜도 또 안 묻는다)',
          pending(db) == 0, '%d건' % pending(db))
        # 원래대로
        c = appdb.connect(db)
        if r0:
            c.execute("INSERT OR REPLACE INTO user_config(config_key,"
                      " config_val) VALUES('ERR_SENT_N',?)", (r0[0],))
        else:
            c.execute("DELETE FROM user_config WHERE config_key='ERR_SENT_N'")
        c.commit()
        c.close()
        t('★ 시험 표식을 되돌렸다', pending(db) == n, '%d건' % pending(db))

        t('★★ **묻는 문이 있다**(화면은 이것을 부른다)',
          callable(maybe_ask))
        t('  한 판에 한 번만 묻는다(빗장)', _asked[0] is False)
        # ⏸ 정비 단계 잠금 — 꺼져 있으면 팝업이 안 뜬다
        t('★★★ **지금은 꺼져 있다**(실시간 작동 안 함)', ENABLED is False)
        t('★★ **꺼져 있으면 아무것도 안 한다**',
          maybe_ask(None, db) == 'OFF')
        t('  화면에 배선돼 있지 않다',
          'errsend' not in io.open('user_main.py', encoding='utf-8').read())
    finally:
        set_mode(keep if keep != 'ASK' else 'ASK', db)
    t('★ 시험 전 설정으로 되돌렸다', get_mode(db) == keep, get_mode(db))
    print('errsend selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--body', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.status:
        print('모드=%s · 안 보낸 오류=%d건 · 보낼 수 있나=%s'
              % (get_mode(), pending(), can_send()))
    if a.body:
        print(body()[:2000])
